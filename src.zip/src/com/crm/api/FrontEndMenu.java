package com.crm.api;

import java.io.File;
import java.io.FileInputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;	
import javax.servlet.http.HttpSession;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.keycloak.KeycloakSecurityContext;
import org.keycloak.adapters.RefreshableKeycloakSecurityContext;
import org.keycloak.representations.AccessToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.bnq.util.menu.JsMenuPreparator;	
import com.gccs.bs.model.BsCompany;
import com.gccs.util.cache.BsCompanyDefinition;

@Controller(value = "/crmapi")
public class FrontEndMenu  {
	private final Logger log = LogManager.getLogger(FrontEndMenu.class);
	
	@Autowired
	private JsMenuPreparator jsMenuPreparator;		
   
	@RequestMapping(value = "/GetCompanyAPI", method = RequestMethod.GET, produces = "application/json")	
 	public @ResponseBody Map<String, Object> GetCompanyAPI(HttpServletRequest request, HttpServletResponse response) {	
		response.setHeader("Access-Control-Allow-Origin", "*");

		HashMap<String, Object> company = new HashMap<String, Object>();
 		if (request.getParameter("url_id_code") != null) {
 			String urlIdCode = request.getParameter("url_id_code"); 
	 		BsCompany bsCompany = BsCompanyDefinition.getBsCompanyByCode(urlIdCode);
	 		if (bsCompany != null) {
	 			company.put("urlIdCode", urlIdCode);
	 			company.put("companyId", bsCompany.getCompanyId());
	 			company.put("companyName", bsCompany.getCompanyName());
				company.put("companyCName", bsCompany.getCompanyCName());
	 		}
	 		
 		}
 		return company;
	}
	
 	// Show Token: Outputs Keycloak token when available
 	// should turn off in production
 	@RequestMapping(value = "/GetTokenAPI", method = RequestMethod.GET, produces = "application/json")	
 	public @ResponseBody Map<String, Object> GetTokenAPI(HttpServletRequest request, HttpServletResponse response) {	
 		
 		HashMap<String, Object> token = new HashMap<String, Object>();
 		
 		// Allow all origin during testing.  On production, should disable and use same domain to pass CORS
 		response.setHeader("Access-Control-Allow-Origin", "*");
 		//response.setHeader("Access-Control-Allow-Origin", "http://localhost:4200");
 				
 		if (request == null) {
 			token.put("HttpServletRequest", "is null");
 			return token;
 		} else {		
 			String userId="";
 			String k = KeycloakSecurityContext.class.getName();
 			RefreshableKeycloakSecurityContext rksc = new RefreshableKeycloakSecurityContext();
 			if (request != null && request.getAttribute(k) != null) 
 				rksc = (RefreshableKeycloakSecurityContext) request.getAttribute(k);
 			else {
 				HttpSession session = request.getSession();
 				if (session != null && session.getAttribute(k) != null)
 					rksc = (RefreshableKeycloakSecurityContext) session.getAttribute(k);
 			}
 			
 			// Check for existence of Keycloak Security Content
 	    	if (rksc == null) {
 				token.put("keycloakSecurityContext", "is null");
 			} else {	
 				// Output Token Information
 				token.put("token", rksc.getTokenString());
 				
 				AccessToken kc_token = rksc.getToken();
 				token.put("PreferredUsername", kc_token.getPreferredUsername());
 				token.put("GetIssuer", kc_token.getIssuer());
 				token.put("Type", kc_token.getType());
 				token.put("Id", kc_token.getId());
 				
 				if (kc_token.isActive())
 					token.put("Token Status", "Active");
 				if (kc_token.isExpired())
 					token.put("Token Status", "Expired");											
 			}	
 		} 
 		return token;
 	}
 	 		
 	// GetMenuCRM for Angular to pull
 	@RequestMapping(value = "/GetMenuAPI", method = RequestMethod.GET, produces = "application/json")
 	public @ResponseBody Map<String, Object> GetMenuAPI(HttpServletRequest request, HttpServletResponse response) throws Exception {		
 		// Validation
 		// Get Company Id from urlIdCode
 		String companyId="";
 		String urlIdCode="";
 		if (request.getParameter("url_id_code") != null)
 			urlIdCode = request.getParameter("url_id_code"); 
 		BsCompany bsCompany = BsCompanyDefinition.getBsCompanyByCode(urlIdCode);
 		if (bsCompany != null)
 			companyId = bsCompany.getCompanyId();
 		
 		// Get user Id from token
 		String userId="";
 		String k = KeycloakSecurityContext.class.getName();
 		RefreshableKeycloakSecurityContext rksc = new RefreshableKeycloakSecurityContext();
 		if (request != null && request.getAttribute(k) != null) 
 			rksc = (RefreshableKeycloakSecurityContext) request.getAttribute(k);
 		else {
 			HttpSession session = request.getSession();
 			if (session != null && session.getAttribute(k) != null)
 				rksc = (RefreshableKeycloakSecurityContext) session.getAttribute(k);
 		}
 					
 		if (rksc != null) {
 			AccessToken token = rksc.getToken();
 			if (rksc.getToken() != null && token.getPreferredUsername() != null && token.isActive()) {
 				userId = rksc.getToken().getPreferredUsername().toUpperCase();
 			}	
 		}
 		
 		String ctxPath=request.getContextPath();
 		// End Validation
 		HashMap<String, Object> menuList = new HashMap<String, Object>();
 		String msg = "";
 		if (companyId.length() == 0 || userId.length() == 0 || ctxPath.length() == 0) {
 			msg = "Validation Failed: urlIdCode=" + urlIdCode + ", companyId=" + companyId + ", userId=" + userId + ", Context=" + ctxPath;
 			log.warn("GetMenuCRM >>> " + msg);
 			menuList.put("0", msg);
 			return menuList ;
 		}
 		
 		log.info("GetMenuCRM >>> Validation Passed: urlIdCode=" + urlIdCode + ", companyId=" + companyId + ", userId=" + userId + ", Context=" + ctxPath);
 		
 		menuList = BuildMenuAPI(companyId, userId, ctxPath);

 		return menuList;
 	}
 	
 	private HashMap<String, Object> BuildMenuAPI(String companyId, String userId, String ctxPath) {
 		HashMap<String, Object> menuList = new HashMap<String, Object>();				// API returning menu list
 		
 		String rtv = jsMenuPreparator.prepare(companyId, userId, ctxPath);				// Get Menu from Database
 		
 		if (rtv.length() == 0) {														// No value returned.  
 			String msg = "User Not Found";
 			menuList.put("0", msg);
 			return menuList;
 		}
 		

 		HashMap<String, String> menuTree = new HashMap<String, String>();				// Parse Menu and put into Hashmap (Hashmap is unsorted)
 		HashMap<String, String> menuTreeSorted = new HashMap<String, String>();			// Used to sort Hashmap and insert into menuList 
 		Stack<String> tree = new Stack<String>();
 		
 		// Split into lines
 		String[] rtvMenu = rtv.split("\\[");

 		// Parse Menu
 		for (int i = 0; i < rtvMenu.length; i++) {	
 			// Step 1: Map menu from OMSCRM to JSON
 			String menuLine = rtvMenu[i];
 			menuLine = menuLine.replaceAll("'", "");
 			String[] menuLineList = menuLine.split(",");
 			
 			if (menuLineList.length >= 3) {		
 				String menuIdName = menuLineList[1];	
 				String menuURL = menuLineList[2];				// URL if exists	
 				String menuType = "item";
 				if (menuURL.toLowerCase().equals("null")) {
 					menuType = "menu";							// includes both root and parent menu
 					menuURL = "";
 				}
 				
 				
 				String parent = menuIdName;						
 				String child = "";								// tree.size() == 0 is root node.  Parent = menuIdName and child = ""
 				if (tree.size() > 0) {							
 					parent = tree.peek();					
 					child = menuIdName + ":" + menuType + ":" + menuURL;	
 														
 					if (menuTree.containsKey(parent)) {
 						// Add new child to existing child
 						String children = menuTree.get(parent);					
 						// Update Child List
 						if (children.length() > 0)
 							child = children + "," + child;		
 					} 										
 				}
 				// Add to Hashmap
 				menuTree.put(parent, child);
 				if (menuTree.size() > menuTreeSorted.size() )
 					menuTreeSorted.put(String.valueOf(menuTreeSorted.size()), parent);		// New Parent: Map menuTree index to parent element
 				
 				// Add to Tree Depth
 				if (menuType.equals("menu"))
 					tree.push(menuIdName);		
 				else {
 					// Remove Tree Depth 
 					// Start at 5
 					for (int k = 5; k < menuLineList.length; k++) {
 						if (menuLineList[k].equals("]")) 
 							tree.pop();	
 					}
 				}
 			}	
 		}
 	
 		// Build Menu (Sorted)
 		for (int j = 0; j < menuTreeSorted.size(); j++) {
 			String key = menuTreeSorted.get(String.valueOf(j));
 			
 			if (menuTree.containsKey(key)) {
 				String[] menuItemList = menuTree.get(key).split(",");
 				
 				// Check For Submenu
 				for (int k=0; k < menuItemList.length; k++) {
 					String[] menuItem = menuItemList[k].split(":");
 					if (menuItem[1].equals("menu") && menuTree.containsKey((menuItem[0]))) {
 							String[] menuItem1List = menuTree.get(menuItem[0]).split(",");	
 							menuTree.remove(menuItem[0]);
 	
 							for (int x = 0; x < menuItem1List.length; x++) {
 								String[] menuItem1 = menuItem1List[x].split(":");
 								
 								// Check next depth
 								if (menuItem1[1].equals("menu") && menuTree.containsKey((menuItem1[0]))) {
 									String[] menuItem2List = menuTree.get(menuItem1[0]).split(",");
 									menuTree.remove(menuItem1[0]);
 									// Tree with Depth = 2
 									// "30"	
 										// "304-商品維修報表"									 	
 											// "30410-商品維修分析表:item:/RFEP/jsp/report/Rpt16.action?formId=PMR001"

 										menuItem1List[x] = menuItem1List[x] + String.join("||", menuItem2List);																				
 								}  
 							} 
 							// Tree with Depth = 1 	
 								// "206-商務會員管理:menu:"
 									// "2061-商務總部維護:item:/RFEP/jsp/member/doIndexBusiness.action?formId=MM203"
 							menuItemList[k] = menuItemList[k] + String.join("|", menuItem1List);
 							
 					} 			
 				}
 				
 				menuList.put(String.valueOf(menuList.size()), Arrays.asList(key, menuItemList));
 			}
 		}
 		
 		return menuList;
 	}				
 	// End
 	
 	@RequestMapping(value = "/downloadECOrderTemplate", method = RequestMethod.GET, produces = "application/json")
	public @ResponseBody void downloadECOrder(HttpServletRequest request, HttpServletResponse response) {
		ServletOutputStream out = null;
		FileInputStream fileInputStream = null;

		try {
			log.info("下載EC館架範例 start");

			String filePath = request.getParameter("filePath");
			String[] pathArray = filePath.split("/");
			String fileName = pathArray[pathArray.length - 1];

			// 設置檔名
			response.setContentType("application/octet-stream");
			String fileNameUTF8 = java.net.URLEncoder.encode(fileName, "UTF-8");
			String attachment = "attachment; filename=" + fileNameUTF8;
			response.setHeader("Content-Disposition", attachment);
			response.setHeader("Access-Control-Expose-Headers", "Content-Disposition");

			log.info("下載EC館架範例Read File");
			File file = new File(filePath);
			// file to byte[]
			byte[] fileByte = new byte[(int) file.length()];

			fileInputStream = new FileInputStream(file);
			out = response.getOutputStream();

			int ch = 0;
			while ((ch = fileInputStream.read(fileByte)) != -1) {
				out.write(fileByte, 0, ch);
			}
			out.flush();

			log.info("下載EC館架範例 success");
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			try {
				if (out != null)
					out.close();
				if (fileInputStream != null)
					fileInputStream.close();
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
		}
	}

 }

