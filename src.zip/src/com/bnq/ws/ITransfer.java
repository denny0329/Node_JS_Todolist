package com.bnq.ws;

import com.bnq.cs.cc.model.MemberComment;
import com.bnq.cs.cc.model.MemberCommentResponse;

/**
 * <b></b>
 * @author kaychen
 * @Date: 2009/3/17 下午 6:49:07
 * @Project Name: bnq
 * @Package Name: com.bnq.ws
 * @File Name: ITransfer.java
 */
public interface ITransfer {
	public String createComment(String xml, String ip) ;
	
	public String createComment(String xml) ;
	
	public MemberCommentResponse createCommentObjectForSom(MemberComment memberComment) ;
}
