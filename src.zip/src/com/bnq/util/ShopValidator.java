/**
 * @(#)ShopValidator.java 2013/11/20
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.bnq.util;

import java.util.Date;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.bs.model.BsDept;
import com.bnq.sc.model.ScSupport;
import com.bnq.sc.model.ScSysuser;
import com.bnq.sc.service.ScSupportService;
import com.bnq.util.cache.BsDeptDefinition;

/** 處理店點判斷
 * @author Administrator
 *
 */
public class ShopValidator {
	
	private static final Logger log = LogManager.getLogger(ShopValidator.class);
	
	private int _user_read_off = 1;	//使用者讀取權限為	否
	private int _user_read_on = 2;	//使用者讀取權限為	是
	private int _unit_on = 2;	//為營利單位
	private int _dept_on = 1;	//Dept正常使用狀態
	
	/** 取得使用者可處理店點，與價格承諾按鈕權限
	 * @param user 登入者
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List getIsValidShop(ScSysuser user) throws Exception{
		int isRead = 0;
		List dataList = new ArrayList();
		try {
			Long readStatus = user.getUserRead();
			isRead = readStatus.intValue();
		} catch(Exception e) {
			log.error(e.getMessage(), e);
		}
		List shopsList = new ArrayList();
		Map shopMap = new TreeMap();
		List hqSupportList = new ArrayList();
		Map hqSupportMap = new TreeMap();
		ScSupportService supportService = (ScSupportService)AppContext.getBean("scSupportService");
		boolean showButton = false;
		List supportList = new ArrayList();
		supportList = supportService.findSupportByUserId(user.getCompanyId(), user.getUserId());
		if (supportList == null || supportList.size() == 0) {
			throw new RuntimeException("此帳戶無權限!");
		}
		
		if(isRead == _user_read_on) {	//所有營業單位
			List depts = BsDeptDefinition.getAllDeptOnUnit2Dept1();	//getUnitStatus 為 2的
			log.info("getIsValidShop user:" + user.getUserId() + ",depts isEmpty:" + depts.isEmpty());
			Iterator iterator = depts.iterator();
			while(iterator.hasNext()) {
				BsDept bsDept = (BsDept)iterator.next();
				Long unitStatus = bsDept.getUnitStatus();
				Long deptStatus = bsDept.getDeptStatus();
				try {
					if(unitStatus.intValue() == _unit_on && deptStatus.intValue() == _dept_on &&
							bsDept.getId().getCompanyId().equals(user.getCompanyId()))
						shopMap.put(bsDept.getDeptId(), bsDept);
				} catch(Exception e) {
					shopMap.put("", this.exceptionDept());
					log.error(e.getMessage(), e);
				}
			}
			try {
				boolean checkDate=false;
				Iterator iterator2 = supportList.iterator();
				while(iterator2.hasNext()) {
					ScSupport support = (ScSupport)iterator2.next();
					BsDept bsDept = support.getBsDept();
					Long unitStatus = bsDept.getUnitStatus();
					Long deptStatus = bsDept.getDeptStatus();
					//帳號是否過期已過期
					Date startdate=support.getStartDate();
					Date enddate=support.getEndDate();
					Date today=new Date();
					if(today.after(enddate)||today.before(startdate)){
						continue;
					}
					checkDate=true;
					try {
						if(unitStatus.intValue() == _unit_on && deptStatus.intValue() == _dept_on) {
							hqSupportMap.put(bsDept.getDeptId(), bsDept);
							showButton = true;
						}	
					} catch(Exception e) {
						hqSupportMap.put("", this.exceptionDept());
						log.error(e.getMessage(), e);
					}
				}
				if(!checkDate){
					throw new RuntimeException("帳號已過期，請洽系統服務人員。");
				}
			} catch (Throwable e) {
				hqSupportMap.put("", this.exceptionDept());
				log.error(e.getMessage(), e);
			}
		} else if(isRead == _user_read_off) {	//本身所在營業單位及支援營業單位
			try {
				Iterator iterator = supportList.iterator();
				while(iterator.hasNext()) {
					ScSupport support = (ScSupport)iterator.next();
					BsDept bsDept = support.getBsDept();
					Long unitStatus = bsDept.getUnitStatus();
					Long deptStatus = bsDept.getDeptStatus();
					try {
						if(unitStatus.intValue() == _unit_on && deptStatus.intValue() == _dept_on) {
							showButton = true;
							shopMap.put(bsDept.getDeptId(), bsDept);
						}
					} catch(Exception e) {
						log.error(e.getMessage(), e);
						shopMap.put("", this.exceptionDept());
						hqSupportMap.put("", this.exceptionDept());
					}
				}
			} catch (Throwable e) {
				shopMap.put("", this.exceptionDept());
				hqSupportMap.put("", this.exceptionDept());
				log.error(e.getMessage(), e);
			}
		} else {	//exception
			shopMap.put("", this.exceptionDept());
			hqSupportMap.put("", this.exceptionDept());
		}
		
		log.info("user:" + user.getUserId() + ",門店 shopMap isEmpty:" + shopMap.isEmpty());
		shopsList.addAll(shopMap.values());
		hqSupportList.addAll(hqSupportMap.values());
		
		if(shopsList.isEmpty())
			shopsList.add(this.exceptionDept());
		if(hqSupportList.isEmpty())
			hqSupportList.add(this.exceptionDept());
		
		if(shopsList.size()!=1) {
			BsDept defaultDept = new BsDept();
			defaultDept.setDeptId("");
			defaultDept.setDeptName("請選擇");
			shopsList.add(0, defaultDept);
		}
		if(hqSupportList.size()!=1) {
			BsDept defaultDept = new BsDept();
			defaultDept.setDeptId("");
			defaultDept.setDeptName("請選擇");
			hqSupportList.add(0, defaultDept);
		}
		
		dataList.add(0, shopsList);
		dataList.add(1, hqSupportList);
		dataList.add(2, showButton);
		
		return dataList;
	}
	
	private BsDept exceptionDept() {
		BsDept defaultDept = new BsDept();
		defaultDept.setDeptId("");
		defaultDept.setDeptName("無資訊");
		return defaultDept;
	}
}
