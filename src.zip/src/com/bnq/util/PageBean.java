package com.bnq.util;

import java.io.Serializable;
import java.util.Collection;

/**
 * 將查詢結果做分頁處理。 
 * @author T2482
 * @param <T>
 */
public class PageBean<T> implements Serializable {
	private static final long serialVersionUID = 125791305602996573L;

	private String name = "pageBean" ;
    private int count = 0; //查詢結果總筆數
    private int pageSize = 10 ; //每頁顯示筆數
    private int pageCount = 0; //總頁數
    private int page = 1; //當前頁數
    
    private String formAction;
    private String columnSum;
    private String pageFirst;
    private String pagePrevious;
    private String pageNext;
	private String pageLast;
    
	private Collection queryList;//結果集
	private String jumpPage; //跳頁
	private String toolsMenu; //分頁元件
    
    public PageBean( ) {
    	
    }
    
    public PageBean(String columnSum,String pageFirst,String pagePrevious,String pageNext,String pageLast) {
		this.columnSum = columnSum;
		this.pageFirst = pageFirst;
		this.pagePrevious = pagePrevious;
		this.pageNext = pageNext;
		this.pageLast = pageLast;
    }
    
    public PageBean(PageBean p) {
		super();
		this.count = p.getCount();
		this.pageSize = p.getPageSize();
		this.pageCount = p.getPageCount();
		this.page = p.getPage();
		this.formAction = p.getFormAction();
		this.pageFirst = p.getPageFirst();
		this.pagePrevious = p.getPagePrevious();
		this.pageNext = p.getPageNext();
		this.pageLast = p.getPageLast();
		this.columnSum = p.getColumnSum();
		this.queryList = p.getQueryList();
		this.jumpPage = p.getJumpPage();
		this.toolsMenu = p.getToolsMenu();
	}

    /**
     * 取得第一頁的
     * @return
     */
	public String getPageFirst() {
		return pageFirst;
	}

	/**
	 * 設定第一頁的
	 * @param pageFirst
	 */
	public void setPageFirst(String pageFirst) {
		this.pageFirst = pageFirst;
	}

	/**
	 * 取得前一頁的
	 * @return
	 */
	public String getPagePrevious() {
		return pagePrevious;
	}

	/**
	 * 設定前一頁的
	 * @param pagePrevious
	 */
	public void setPagePrevious(String pagePrevious) {
		this.pagePrevious = pagePrevious;
	}

	/**
	 * 取得次一頁的
	 * @return
	 */
	public String getPageNext() {
		return pageNext;
	}

	/**
	 * 設定次一頁的
	 * @param pageNext
	 */
	public void setPageNext(String pageNext) {
		this.pageNext = pageNext;
	}

	/**
	 * 取得最後一頁的
	 * @return
	 */
	public String getPageLast() {
		return pageLast;
	}

	/**
	 * 設定最後一頁的
	 * @param pageLast
	 */
	public void setPageLast(String pageLast) {
		this.pageLast = pageLast;
	}

	public String getColumnSum() {
		return columnSum;
	}

	public void setColumnSum(String columnSum) {
		this.columnSum = columnSum;
	}

	public String getFormAction() {
		return formAction;
	}

	public void setFormAction(String formAction) {
		this.formAction = formAction;
	}

	public Collection getQueryList() {
		return queryList;
	}

	public void setQueryList(Collection queryList) {
		this.queryList = queryList;
	}

	public String getJumpPage() {
		return jumpPage;
	}

	public void setJumpPage(String jumpPage) {
		this.jumpPage = jumpPage;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getToolsMenu() {
		return toolsMenu;
	}

	public void setToolsMenu(String toolsMenu) {
		this.toolsMenu = toolsMenu;
	}

	/**
	 * 取得查詢結果總筆數。
	 * @return
	 */
	public int getCount() {
        return count;
    }

	/**
	 * 設定查詢結果總筆數。
	 * 另外會依據總筆數及每分頁要顯示筆數，判斷共有幾頁。
	 * @param count
	 */
    public void setCount(int count) {
        if (pageSize != 0) {
            pageCount = count / pageSize;
            if (count % pageSize != 0) {
                pageCount++;
            }
        }
        this.count = count;
    }

    /**
     * 取得當前頁數。
     * @return
     */
    public int getPage() {
        return page;
    }

    /**
     * 設定當前頁數。
     * @param page
     */
    public void setPage(int page) {
        this.page = page;
    }

    /**
     * 取得總頁數。
     * @return
     */
    public int getPageCount() {
        return pageCount;
    }

    /**
     * 設定總頁數。
     * @param pageCount
     */
    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }

    /**
     * 取得每頁顯示筆數。
     * @return
     */
    public int getPageSize() {
        return pageSize;
    }

    /**
     * 設定每頁顯示筆數。
     * @param pageSize
     */
    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

	/**
	 * 取得分頁查詢起始筆數。
	 * 預設為 1，但若 jumpPage 有值，則改使用 jumpPage 的值。
	 * @return 起始筆數
	 */
	public int getPageNo() {
		int pageNo = 1 ;
		if(this.getJumpPage() != null && !this.getJumpPage().trim().equals("")) {
			pageNo = Integer.parseInt(this.getJumpPage().trim()) ;
		}
		return pageNo ;
	}
	
	public int getStartIndex() {
		return ((getPageNo() - 1) * getPageSize() ) ;
	}
}
