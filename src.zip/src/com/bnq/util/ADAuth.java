/**
 * @(#)ADAuth.java 2013/08/23
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.bnq.util;

import java.util.Hashtable;
import java.util.ResourceBundle;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

/**
 * [功能]
 *      1. 輸入帳號跟密碼，跟 AD 做認證。
 *      
 * [範例]
 *      1. ADAuth.checkAuth("帳號", "密碼") --> 回傳值:（成功:true / 失敗:false）
 * 
 * [對象]
 *      1. For B&Q User。
 *      
 * @author h00607
 */
public class ADAuth {
	private static final Logger log = LogManager.getLogger(ADAuth.class);
	
	private static String AD0_HOST = "AD0";
	private static String AD1_HOST = "AD1";
	private static String AD_PORT = "389";
	
	private static String batchJobServer = "";
	
	static {
		try {
			ResourceBundle rb = ResourceBundle.getBundle("application");
			AD0_HOST = rb.getString("AD0_HOST");
			AD1_HOST = rb.getString("AD1_HOST");
			AD_PORT = rb.getString("AD_PORT");
			
			batchJobServer = rb.getString("BATCH_JOB_SERVER");
		} catch(Exception e) {
			log.error(e.getMessage(), e);
		}
	}
	
	/**
	 * 認證
	 * @param username
	 * @param password
	 * @return
	 */
	public static boolean checkAuth(String username, String password) {
		log.info(StringUtils.center(" checkAuth() START ", 50, "*"));
		
		if (StringUtils.isEmpty(username)) {
			log.info("username Is Null / Empty String");
			return false;
		}

		if (StringUtils.isEmpty(password)) {
			log.info("password Is Null / Empty String");
			return false;
		}
		
		boolean flag = false;
		
		try {
			if (initUserToADAuth(username, password)) {
				flag = true;
			}
		} catch (Exception e) {
			log.error("工號（" + username + "）AD認證失敗！！", e);
		}
		
		log.info(StringUtils.center(" checkAuth() END ", 50, "*"));
		return flag;
	}
	
	private static boolean initUserToADAuth(String username, String password) throws NamingException {
		log.info(StringUtils.center(" initUserToADAuth() START ", 50, "*"));
		
		boolean flag = true;
		
		Hashtable<String, String> env = new Hashtable<String, String>();
		LdapContext ctx = null;
		
		try {
			env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			// 這裡使用DNS，萬一AD IP變更，則程式碼設定不需異動。
			env.put(Context.PROVIDER_URL,            "ldap://"+AD0_HOST+":"+AD_PORT);
			env.put(Context.SECURITY_AUTHENTICATION, "simple"); 
			env.put(Context.SECURITY_PRINCIPAL,      "testritegroup\\" + username);
			env.put(Context.SECURITY_CREDENTIALS ,   password);
	
			ctx = new InitialLdapContext(env, null);
		} catch (NamingException e) {
			try {
				env.remove(Context.PROVIDER_URL);
				env.put(Context.PROVIDER_URL,            "ldap://"+AD1_HOST+":"+AD_PORT);
				ctx = new InitialLdapContext(env, null);
			} catch (NamingException ex) {
				flag = false;
				log.error("認證失敗。", ex);
				throw new NamingException(ex.getMessage());
			}
		} finally {
			if (ctx != null) {
				try {
					ctx.close();
				} catch (NamingException e) {
					flag = false;
					log.error("無法關閉 LdapContext。", e);
					throw new NamingException(e.getMessage());
				}
			}
		}
		
		log.info(StringUtils.center(" initUserToADAuth() END ", 50, "*"));
		return flag;
	}

	public static String getBatchJobServer() {
		return batchJobServer;
	}
}