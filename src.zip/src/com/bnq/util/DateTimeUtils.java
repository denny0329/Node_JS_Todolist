/**
 * @(#) DateTimeUtils.java 2014/4/15
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.bnq.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

/** 
 * 日期轉換工具
 * @author Administrator
 */
public class DateTimeUtils {
	
	private static final Logger log = LogManager.getLogger(DateTimeUtils.class);
	/**yyyy/MM/dd*/
	public static final String DEFAULT_DATE_PATTERN = "yyyy/MM/dd";
	/**HH:mm:ss*/
	public static final String DEFAULT_TIME_PATTERN = "HH:mm:ss";
	/**HHmmss*/
	public static final String DEFAULT_TIME_PATTERN2 = "HHmmss";
	/**yyyy/MM/dd HH:mm:ss*/
	public static final String DEFAULT_DATE_TIME_PATTERN = "yyyy/MM/dd HH:mm:ss";
	/**yy/MM/dd*/
	public static final String DEFAULT_DATE_PATTERN2 = "yy/MM/dd";
	/**yyyy-MM-dd HH:mm:ss*/
	public static final String DEFAULT_DATE_TIME_PATTERN2 = "yyyy-MM-dd HH:mm:ss";
	/**yyyy-MM-dd*/
	public static final String DEFAULT_DATE_TIME_PATTERN3 = "yyyy-MM-dd";
	/**yyyyMMdd HHmmss*/
	public static final String DEFAULT_DATE_TIME_PATTERN4 = "yyyyMMdd HHmmss";
	/**yyyy/MM*/
	public static final String YYYY_MM="yyyy/MM";
	/**yyyy/MM*/
	public static final String yyyyMMddHHmmss="yyyyMMddHHmmss";
	public static final String YYYYMM="yyyyMM";
	
	/**
	 * 取得系統日的字串資料
	 * @return
	 * @throws Exception
	 */
	public static synchronized String getFileNo() throws Exception {
		Thread.sleep(10);
		Date sysDate = DateTimeUtils.getSysDate();
		return DateTimeUtils.getFormatDateStr(sysDate, yyyyMMddHHmmss);
	}
	
	public static Timestamp getSysDate() {

		Date today = Calendar.getInstance().getTime();
		return new Timestamp(today.getTime());
	}
	
	public static String getFormatSysDateStr() throws Exception {
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(DEFAULT_DATE_PATTERN);
		String dateStr = gSimpleDateFormat.format(getSysDate());
		return dateStr;
	}
	
	/**
	 * 取系統時間
	 * Johnson
	 * @return
	 * @throws Exception
	 */
	public static String getFormatSysTimeStr() throws Exception {
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(DEFAULT_TIME_PATTERN);
		String dateStr = gSimpleDateFormat.format(getSysDate());
		return dateStr;
	}
	
	public static String getFormatSysDateStr(String pattern) throws Throwable{
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(pattern);
		String dateStr = gSimpleDateFormat.format(getSysDate()) ;
		return dateStr;
	}
	/**
	 * 將目前系統時間轉化為 yyyy/MM/dd HH:mm:ss。
	 * @return
	 * @throws Throwable
	 */
	public static String getFormatSysDateTimeStr() throws Throwable{
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(DEFAULT_DATE_TIME_PATTERN) ;
		String dateStr = gSimpleDateFormat.format(getSysDate()) ;
		return dateStr;
	}
	
	public static String getFormatSysDateTimeStr(String pattern){
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(pattern) ;
		String dateStr = gSimpleDateFormat.format(getSysDate()) ;
		return dateStr;
	}
	public static String getFormatDateStr(Date date,String pattern) throws Exception {
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(pattern) ;
		String dateStr = gSimpleDateFormat.format(date);
		return dateStr;
	}
	public static String getFormatDateStr(Date date) {
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(DEFAULT_DATE_PATTERN) ;
		String dateStr = gSimpleDateFormat.format(date) ;
		return dateStr;
	}
	public static String getFormatDateTimeStr(Date date) throws Throwable{
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(DEFAULT_DATE_TIME_PATTERN) ;
		String dateStr=gSimpleDateFormat.format(date);
		return dateStr;
	}
	public static Date getFormatSysDate() throws Exception {
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(DEFAULT_DATE_PATTERN) ;
		String dateStr = getFormatSysDateStr();
		return new Timestamp(gSimpleDateFormat.parse(dateStr).getTime());
	}
	/**
	 * Johnson getFormatSysDateTime()與getFormatSysDate()相同,但它有新增時間部份
	 * @param pattern
	 * @return
	 * @throws Throwable 
	 */
	public static Date getFormatSysDateTime() throws Throwable {
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(DEFAULT_DATE_TIME_PATTERN) ;
		String dateStr = getFormatSysDateTimeStr();
		return new Timestamp(gSimpleDateFormat.parse(dateStr).getTime());
	}
	public static Timestamp getDateFormat(String lDate) throws ParseException {
		return getDateFormat(lDate, DEFAULT_DATE_PATTERN);
	}

	public static Timestamp getDateFormat(String ldate, String lPattern) throws ParseException {
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(lPattern) ;
		try {
			return new Timestamp(gSimpleDateFormat.parse(ldate).getTime());
		} catch (ParseException e) {
			throw e;
		}
	}

	public static String subtractDate(Date date ,int days) {
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(DEFAULT_DATE_PATTERN) ;
		return gSimpleDateFormat.format(DateUtils.addDays(date, -days)) ;
	}

	public static Date addYear(Date date,int add){
		Calendar c = Calendar.getInstance() ;
		c.setTime(date) ;
		c.add(Calendar.YEAR, add) ;
		return c.getTime() ;
	}

	public static Date addMonth(Date date,int add){
		Calendar c = Calendar.getInstance() ;
		c.setTime(date) ;
		c.add(Calendar.MONTH, add) ;
		return c.getTime() ;
	}


	public static Date addDate(Date date,int add) {
		Calendar c = Calendar.getInstance() ;
		c.setTime(date) ;
		c.add(Calendar.DATE, add) ;
		return c.getTime() ;
	}

	public static String addDate(String dateString,int add) {
		String rtv = null;
		if(dateString != null && dateString.trim().length() > 0) {
			try {
				Date origDate = getDate(dateString.trim());
				Date newDate = addDate(origDate, add);
				rtv = getFormatDateStr(newDate);
			} catch (Throwable e) {
				log.error(e.getMessage(), e);
			}
		}
		return rtv;
	}

	public static Date getDateTime(String dateTimeString) {
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(DEFAULT_DATE_TIME_PATTERN) ;
		try {
			return gSimpleDateFormat.parse(dateTimeString) ;
		} catch (ParseException e) {
			log.error(e.getMessage(), e);
		}
		return new Date() ;
	}

	/**
	 * 將字串轉換成 yyyy/MM/dd 的日期格式。
	 * @param dateString
	 * @return 若轉換發生錯誤時回傳系統日。
	 */
	public static Date getDate(String dateString) {
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(DEFAULT_DATE_PATTERN) ;
		try {
			return gSimpleDateFormat.parse(dateString) ;
		} catch (ParseException e) {
			log.error(e.getMessage(), e);
		}
		return new Date() ;
	}
	
	public static Date getDate(String dateString, String pattern) {
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(pattern) ;
		try {
			return gSimpleDateFormat.parse(dateString) ;
		} catch (ParseException e) {
			log.error(e.getMessage(), e);
		}
		return new Date() ;
	}
	
	/**
	 * Johnson getDate2()與getDate()相同,但我需要丟出Exception
	 * @param dateString
	 * @param pattern
	 * @return
	 * @throws ParseException
	 */
	public static Date getDate2(String dateString, String pattern) throws ParseException {
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(pattern) ;
			return gSimpleDateFormat.parse(dateString) ;
	}
	
	/**
	 * Johnson
	 * @param dateTimeString
	 * @return
	 */
	public static Date getDate2(String dateTimeString) {
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(DEFAULT_DATE_TIME_PATTERN3) ;
		try {
			return gSimpleDateFormat.parse(dateTimeString) ;
		} catch (ParseException e) {
			log.error(e.getMessage(), e);
		}
		return new Date() ;
	}

	public static String getTime(Date date) {
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(DEFAULT_DATE_TIME_PATTERN);
		return gSimpleDateFormat.format(date) ;
	}
	/**
	 * 將傳入日期 format 成  HHmmss 格式
	 */
	public static String getTime2(Date date) {
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(DEFAULT_TIME_PATTERN2);
		return gSimpleDateFormat.format(date) ;
	}

	/**
	 * 回傳 yyyy/MM/dd 的字串。
	 * @param d
	 * @return
	 */
	public static String getDate(Date d) {
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat(DEFAULT_DATE_PATTERN);
		return gSimpleDateFormat.format(d) ;
	}

	public static long dateDiffToSysDate(String dateStr) {
		Date date = getDate(dateStr);
		return dateDiffToSysDate(date);
	}

	public static long dateDiffToSysDate(Date date) {
		Date sysDate = null;
		try {
			sysDate = DateTimeUtils.getFormatSysDate();
		} catch(Throwable e) {
			log.error(e.getMessage(), e);
		}
		return dateDiff(date, sysDate);
	}

	public static long dateDiff(String dateStr1, String dateStr2) {
		Date date1 = getDate(dateStr1);
		Date date2 = getDate(dateStr2);
		return dateDiff(date1, date2);
	}

	public static long dateDiff(Date date1, Date date2) {
		return ((truncateTime(date1).getTime()/1000-truncateTime(date2).getTime()/1000)/(24*60*60));
	}

	public static Date truncateTime(Date date) {
		Date rtv = null;
		if(date != null) {
			try {
				String dateStr = getFormatDateStr(date);
				rtv = DateTimeUtils.getDate(dateStr);
			} catch(Throwable e) {
				log.error(e.getMessage(), e);
				try {
					rtv = DateTimeUtils.getFormatSysDate();
				} catch(Throwable ee) {}
			}
		}
		return rtv;
	}

	/**
	 * 將Date轉成ROC日期字串
	 * @param date 日期物件
	 * @return
	 * @throws RuntimeException
	 */
	public static String getROCDateStr(Date date) throws RuntimeException {
		return getROCDateStr(date, -1, true);
	}

	/**
	 * 將Date轉成ROC日期字串
	 * @param date 日期物件
	 * @param yearLength 年字串長度,不足部份補零；若為yearLength<=年長度,則不補0
	 * @return
	 * @throws RuntimeException
	 */
	public static String getROCDateStr(Date date, int yearLength, boolean slashSeparate) throws RuntimeException {
		String rtv = null;
		try {
			String dateStr = getFormatDateStr(date!=null? date: new Date());
			if(dateStr != null && dateStr.length() > 0) {
				String mdStr = dateStr.substring(4);
				int rocYear = getROCYear(date);
				String rocYearStr = String.valueOf(rocYear);
				if(rocYearStr.length() >= yearLength)
					rtv = rocYearStr + mdStr;
				else
					rtv = StringUtils.getHeadFilledString(rocYearStr, yearLength, "0") + mdStr;
				if(!slashSeparate)
					rtv = rtv.replaceAll("/", "");
			}
		} catch(Throwable e) {
			throw new RuntimeException(e);
		}
		return rtv;
	}
	
	/**
	 * 將Date轉成ROC日期字串+中華民
	 * @param date 日期物件
	 * @param yearLength 年字串長度,不足部份補零；若為yearLength<=年長度,則不補0
	 * @return
	 * @throws RuntimeException
	 * @param date
	 * @return
	 */
	public static String getROCDateStrFromate(String dd) throws RuntimeException {
		int len = dd.length();
		String result = dd;		
		try {
			switch(len)
		    {
		      case 7:
		    	  result = "中華民國  "+dd.substring(0,3)+" 年 "+dd.substring(3,5)+" 月 "+dd.substring(5,7)+" 日 "; 
		        break;
		      default:
		       break;
		    }
		} catch(Throwable e) {
			throw new RuntimeException(e);
		}		
		return result;		
	}	

	public static int getYear(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date != null? date: new Date());
		return calendar.get(Calendar.YEAR);
	}

	public static int getROCYear(Date date) {
		return getYear(date) - 1911;
	}

	public static Date addUnit(Date date,int calendarType,int add) {
		Calendar c = Calendar.getInstance() ;
		c.setTime(date) ;
		c.add(calendarType, add) ;
		return c.getTime() ;
	}

	public static Date getLastDate(Date date)throws Exception{
		Calendar c = Calendar.getInstance() ;
		c.setTime(date) ;
		c.set(Calendar.DATE, c.getActualMaximum(Calendar.DAY_OF_MONTH));
		return c.getTime();
	}

	public static Date getFirstDate(Date date)throws Exception{
		Calendar c = Calendar.getInstance() ;
		c.setTime(date) ;
		c.set(Calendar.DATE, c.getActualMinimum(Calendar.DAY_OF_MONTH));
		return c.getTime();
	}
	
    /**
	 * getTheEndOfADay : 取得傳入日期的開始
	 * @param date : 傳入Date日期
	 * @return date : 回傳Date日期
	 */
    public static Date getTheStartOfADay(Date date) {
    	Calendar calendar = Calendar.getInstance() ;
    	calendar.setTime(date);
    	calendar.set(Calendar.HOUR_OF_DAY, 00);
    	calendar.set(Calendar.MINUTE, 00);
    	calendar.set(Calendar.SECOND, 00);
    	calendar.set(Calendar.MILLISECOND, 000);
		return calendar.getTime();
    }
	
    /**
	 * getTheEndOfADay : 取得傳入日期的最後
	 * @param date : 傳入Date日期
	 * @return date : 回傳Date日期
	 */
    public static Date getTheEndOfADay(Date date) {
    	Calendar calendar = Calendar.getInstance() ;
    	calendar.setTime(date);
    	calendar.set(Calendar.HOUR_OF_DAY, 23);
    	calendar.set(Calendar.MINUTE, 59);
    	calendar.set(Calendar.SECOND, 59);
    	calendar.set(Calendar.MILLISECOND, 999);
		return calendar.getTime();
    }
    
    public static boolean beforeAndInclude(Date date1 , String dateString){
    	Date date2 = getDate(dateString);
    	if(DateUtils.isSameDay(date1, date2)){
    		return true;
    	}
    	else {
    		return  date1.before(date2);
    	}
    }
    
    /**
     * 依當前系統日期,取上個月,或下個月
     * @param month -1:上個月,1:下個月
     * @param pattern DateTimeUtils.YYYY_MM
     * @return
     * @throws Exception 
     */

    public static String getLastOrNextMonth(int month,String pattern) throws Exception{
    	return DateTimeUtils.getFormatDateStr(DateTimeUtils.addMonth(DateTimeUtils.getSysDate(), month),pattern);
    }
    
    /**
     * 二個日期相差天數
     * @param startDate
     * @param endDate
     * @return
     */
	public static int subDate(Date startDate,Date endDate){
		if(startDate==null || endDate==null)
			return 0;
		Calendar c1=Calendar.getInstance();
		c1.setTime(startDate);
		Calendar c2=Calendar.getInstance();
		c2.setTime(endDate);
		int count=0;
		while(c1.before(c2)){
			c1.add(Calendar.DATE, 1);
			count++;
		}
		return count;
	}
	
	/**
	 * 計算相差月數
	 * @param begin	相差月數起  yyyy/mm
	 * @param end	相差月數迄 yyyy/mm
	 * @return int 相差月數
	 * @throws Exception
	 */
	public static int getDifferMonth(String begin, String end) throws Exception	{
		SimpleDateFormat sdf = new SimpleDateFormat(DateTimeUtils.YYYY_MM);
		Date beginDate = sdf.parse(begin);
		Date endDate = sdf.parse(end);
	
		Calendar calBegin = Calendar.getInstance();
		Calendar calEnd = Calendar.getInstance();
		
		calBegin.setTime(beginDate);
		calEnd.setTime(endDate);
		
		int beginYear = calBegin.get(Calendar.YEAR);
		int beginMonth = calBegin.get(Calendar.MONDAY);
	
		int endYear = calEnd.get(Calendar.YEAR);
		int endMonth = calEnd.get(Calendar.MONDAY);
		
		return (endYear - beginYear) * 12 + (endMonth - beginMonth); 
	}	
	
	/**
	 * 增加或減少 月
	 * @param yearMonth 年月基數 yyyy/mm
	 * @param value		增加或減少 月數
	 * @return String "yyyy/mm"
	 * @throws Exception
	 */
	public static String addMonth(String yearMonth, int value) throws Exception	{
		SimpleDateFormat sdf = new SimpleDateFormat(DateTimeUtils.YYYY_MM);
		Date date = sdf.parse(yearMonth);
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.MONTH, value);
		return getFormatDateStr(cal.getTime(), DateTimeUtils.YYYY_MM);
	}
	
	/**
	 * 取得指定時間的年與月
	 */
	public static Date getYearMonth(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		String yearMonthStr = sdf.format(date);
		Date yearMonth = null;
		try {
			yearMonth = sdf.parse(yearMonthStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return yearMonth;
	}
	
	/**
	 * 取得指定時間的年/月/日
	 */
	public static Date getYearMonthDay(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String yearMonthDayStr = sdf.format(date);
		Date yearMonthDay = null;
		try {
			yearMonthDay = sdf.parse(yearMonthDayStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return yearMonthDay;
	}
	
	/**
	 * 回傳兩日期比對至日期是否相等
	 */
	public static boolean isSameDate(Date date1, Date date2) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String date1Str = sdf.format(date1);
		String date2Str = sdf.format(date2);
		return date1Str.equals(date2Str);
	}
	
	// 每個月的第一天日期
	public static Calendar getFirstDayofMonth(Calendar calendar) {
		calendar.set(Calendar.DATE, calendar.getActualMinimum(Calendar.DATE));
		return calendar;
	}
	
	// 當前年的最後一天
	public static Date getLastDateOfYear(int year) {
		Calendar calendar = Calendar.getInstance();
		calendar.clear();
		calendar.set(Calendar.YEAR, year);
		calendar.roll(Calendar.DAY_OF_YEAR, -1);
		return calendar.getTime();
	}
	
	public static String getLastMonthDayStr(Date date) {
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.MONTH, -1);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		return sdf.format(c.getTime());
	}
	
	// 取月份第一天
	public static Date getFisrtDayOfMonth(int year, int month) {
		Calendar cal = Calendar.getInstance();
		// 設置年份
		cal.set(Calendar.YEAR, year);
		// 設置月份
		cal.set(Calendar.MONTH, month - 1);
		// 獲取某月最小天數
		int firstDay = cal.getActualMinimum(Calendar.DAY_OF_MONTH);
		// 設置日歷中月份的最小天數
		cal.set(Calendar.DAY_OF_MONTH, firstDay);
		return cal.getTime();
	}
	
	// 取月份最後一天
	public static Date getLastDayOfMonth(int year, int month) {
		Calendar cal = Calendar.getInstance();
		// 設置年份
		cal.set(Calendar.YEAR, year);
		// 設置月份
		cal.set(Calendar.MONTH, month - 1);
		// 獲取某月最大天數
		int lastDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		// 設置日歷中月份的最大天數
		cal.set(Calendar.DAY_OF_MONTH, lastDay);
		return cal.getTime();
	}
}
