package com.bnq.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;


public class PropertyConfigUtils {

	private static final Logger log = LogManager.getLogger(PropertyConfigUtils.class);
	
	//SINGLETON
	private static PropertyConfigUtils instance = new PropertyConfigUtils();
	private static Map<String,PropertiesConfiguration> pCfgMap = new HashMap<String,PropertiesConfiguration>();
	
	private PropertyConfigUtils() {
		
	}
	
	public static String getProperty(String propertyFile, String key) {
		String value = null;
		try {
			String realName = getRealName(propertyFile);
			PropertiesConfiguration pCfg = instance.getPropertiesConfiguration(propertyFile);
			if(pCfg == null) {
				pCfg = instance.loadPropertyFile(propertyFile);
				if(pCfg != null)
					pCfgMap.put(realName, pCfg);
			}
			if(pCfg != null) {
				value = pCfg.getString(key);
			} else {
				throw new Exception("無法取得設定: "+propertyFile);
			}
		} catch(Exception e) {
			log.error(e.getMessage(), e);
		}
		return value;
	}
	
	public static Map<String,String> getProperties(String propertyFile) {
		Map<String,String> rtv = new HashMap<String,String>();
		try {
			String realName = getRealName(propertyFile);
			PropertiesConfiguration pCfg = instance.getPropertiesConfiguration(propertyFile);
			if(pCfg == null) {
				pCfg = instance.loadPropertyFile(propertyFile);
				if(pCfg != null) {
					pCfgMap.put(realName, pCfg);
				}
			}
			if(pCfg != null) {
				Iterator<String> keyIter = pCfg.getKeys();
				while(keyIter.hasNext()) {
					String key = keyIter.next();
					rtv.put(key, pCfg.getString(key));
				}
			} else {
				throw new Exception("無法取得設定: "+propertyFile);
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
		return rtv;
	}
	
	private PropertiesConfiguration loadPropertyFile(String propertyFile) {
		PropertiesConfiguration pCfg = null;
		try {
			String realName = getRealName(propertyFile);
			pCfg = new PropertiesConfiguration(realName);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return pCfg;
	}
	
	private PropertiesConfiguration getPropertiesConfiguration(String propertyFile) {
		return (PropertiesConfiguration)pCfgMap.get(propertyFile);
	}
	
	private static String getRealName(String propertyFile) {
		String realName = propertyFile;
		if(realName.indexOf(".properties") == -1)
			realName += ".properties";
		return realName;
	}
	
	public static String[] getPropertyArray(String propertyFile, String key) {
		String[] itemsArray = null;
		try {
			String realName = getRealName(propertyFile);
			PropertiesConfiguration pCfg = instance.getPropertiesConfiguration(propertyFile);
			if (pCfg == null) {
				pCfg = instance.loadPropertyFile(propertyFile);
				if (pCfg != null)
					pCfgMap.put(realName, pCfg);
			}
			if (pCfg != null) {
				itemsArray = pCfg.getStringArray(key);
			} else {
				throw new Exception("無法取得設定: " + propertyFile);
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		
		return itemsArray;
	}
	
}
