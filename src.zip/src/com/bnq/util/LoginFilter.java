/**
 * @(#) LoginFilter.java 2015/12/02
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.bnq.util;

import java.io.IOException;
import java.util.Set;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.sc.dao.hibernate.ScSysuserDAO;
import com.bnq.sc.model.ScSysuser;
import com.bnq.util.cache.ScFormDefinition;
import com.gccs.bs.model.BsCompany;
import com.gccs.util.cache.BsCompanyDefinition;
import com.trg.oms.utils.IpUtil;

/**
 * 登入檢查過濾器，檢查使用者是否已登入以使用系統
 */
public class LoginFilter implements Filter {
	
	private final Logger log = LogManager.getLogger(LoginFilter.class);

	/**登入頁面路徑及檔名*/
	private String LOGIN_PAGE;
	/**重導向頁面路徑及檔名*/
	private String REDIRECT_PAGE;
	/**首頁頁面路徑及檔名*/
	private String INDEX_PAGE;

	private String url_id_code = "";
	private String urlIdCode = "";
	/**
	 * 初始化過濾器參數設定
	 */
	public void init(FilterConfig config) throws ServletException {
		LOGIN_PAGE = config.getInitParameter("loginPage");
		REDIRECT_PAGE = config.getInitParameter("redirectPage");
		INDEX_PAGE = config.getInitParameter("indexPage");
		
		url_id_code = "url_id_code";
		urlIdCode = "";
	}

	/**
	 * 過濾檢查
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		
		HttpServletRequest httpRequest = (HttpServletRequest)request;
		
		String requestURI = httpRequest.getRequestURI().trim(); 
				
		String contextPath = httpRequest.getContextPath(); 
				
		if(LOGIN_PAGE == null || LOGIN_PAGE.trim().length() == 0) {		
			LOGIN_PAGE = contextPath + "/jsp/login.jsp";				
		}
		
		if(REDIRECT_PAGE == null || REDIRECT_PAGE.trim().length() == 0) {	
			REDIRECT_PAGE = contextPath + "/jsp/redirect.jsp";			
		}
		
		if(INDEX_PAGE == null || INDEX_PAGE.trim().length() == 0) {			
			INDEX_PAGE = contextPath + "/jsp/index.jsp";					
		}

		
		HttpSession session = httpRequest.getSession();
		ScSysuser userProfile = (ScSysuser)session.getAttribute("user");
		HttpServletResponse httpResponse = (HttpServletResponse)response;
						
		if(requestURI.indexOf(LOGIN_PAGE) != -1 || requestURI.indexOf(REDIRECT_PAGE) != -1 || requestURI.indexOf("/jsp/login.action") != -1 || requestURI.indexOf("/jsp/logout.action") != -1) {						
			// 檢核 URL
			if ((requestURI.indexOf(LOGIN_PAGE) != -1 || requestURI.indexOf(REDIRECT_PAGE) != -1) && !checkUrl(httpRequest)) {
				httpResponse.sendError(HttpServletResponse.SC_NOT_FOUND, "Session Timeout. 請再次點選單或重新登入");
				return;
			}
			//do nothing, prevent looping, but if user already logon, when the page is login page, go to index.jsp 
			if(requestURI.indexOf(LOGIN_PAGE) != -1 && userProfile != null) {				
				httpResponse.sendRedirect(INDEX_PAGE);
				return;
			}
		} else {
			//do login check
			if(userProfile == null) {//not login
				if(requestURI.length() > 0 && !(requestURI.equals(contextPath+"/") || requestURI.equals(contextPath)) && (requestURI.indexOf("/jsp/index.jsp") == -1)) {
					StringBuffer reqURISB = new StringBuffer(requestURI);
					Map reqParamMap = httpRequest.getParameterMap();
					StringBuffer paramsSB = new StringBuffer();
					if(reqParamMap != null && reqParamMap.size() > 0) {
						Set<String> reqParams = reqParamMap.keySet();
						for(String reqParam: reqParams) {
							String[] paramVal = (String[])reqParamMap.get(reqParam);
							if(paramVal != null && paramVal.length > 0) {
								if(paramsSB.length() > 0)
									paramsSB.append("&");
								
								if (reqParam.equals(url_id_code))
									urlIdCode = paramVal[0];	
								
								paramsSB.append(reqParam);
								paramsSB.append("=");
								paramsSB.append(paramVal[0]);
							}
						}
					}
					
					if(paramsSB.length() > 0) {
						reqURISB.append("?");
						reqURISB.append(paramsSB);
					}
										
					session.setAttribute("reqURI", reqURISB.toString());
				}
				
				if (urlIdCode.length() > 0) {
					String url = LOGIN_PAGE + "?" + url_id_code + "=" + urlIdCode;
					httpResponse.sendRedirect(url);
				}else
					httpResponse.sendRedirect(LOGIN_PAGE);
				
				return;
			} else { //already login, do record action data
				try {													
					String userId = userProfile.getUserId();
					String formId = ScFormDefinition.getFormIdByURI(requestURI);
					if("Unknow".equalsIgnoreCase(formId)) {
						chain.doFilter(request, response);
						return;
					}
					String userIP = IpUtil.getUserIP(httpRequest);
					String serverIP = IpUtil.getServerIP(httpRequest);
					String[] actionNames = requestURI.substring(requestURI.lastIndexOf("/") + 1).split("\\?");
					
					ScSysuserDAO dao = (ScSysuserDAO)AppContext.getBean("scSysuserDAO");
					dao.saveUserFormLog(userId, formId, userIP, serverIP, actionNames[0]);
				} catch(Exception e) {
					log.error("無法記錄 SC_SYSUSER_FORM_LOG, userId:" + userProfile.getUserId() + ", URI:" + requestURI + ", userIP:" + IpUtil.getUserIP(httpRequest), e);
				}
			}
		}
		chain.doFilter(request, response);
	}

	/**
	 * 資源釋放
	 */
	public void destroy() {
		
	}

	/**
	 * 依據 URL 判斷網域名稱若使用 IP，則還必須判斷附加參數 url_id_code 是否符合網址識別碼（TLW、TRCB）。
	 * @param request HttpServletRequest
	 * @return 若檢核通過，回傳 true。
	 */
	@SuppressWarnings("unchecked")
	private boolean checkUrl(HttpServletRequest request) {
		String url = request.getRequestURL().toString();// 使用者輸入的 URL
		String domainPrefix = url.substring(url.indexOf("://") + 3, url.indexOf("."));// 取得網域的第一段
		// 若 domainPrefix 可以被轉型成 Integer，則代表使用者是輸入 IP，否則為網域名稱
		boolean isDomain = !NumberUtils.isDigits(domainPrefix);
		if (isDomain) {
			return true;
		} else {
			Map<String, String[]> parameterMap = request.getParameterMap();	// 取得 URL 附加參數
			
			// 判斷是否有附加參數 url_id_code 與其是否符合網址識別碼
			if (parameterMap.containsKey(url_id_code)) {
				urlIdCode = ((String[]) parameterMap.get(url_id_code))[0];
				BsCompany bsCompany = BsCompanyDefinition.getBsCompanyByCode(urlIdCode);
				if (bsCompany != null) {
					return true;
				}
			} else {
				// 因 Session Timeout 時，會導頁至 redirect.jsp 後，並關掉整個瀏覽器，所以回傳 true 避免導至 404 頁面
				if (request.getRequestURL().toString().contains(REDIRECT_PAGE)) {
					return true;
				}
			}
		}
		return false;
	}
}