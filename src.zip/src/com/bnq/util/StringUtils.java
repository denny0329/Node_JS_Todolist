/**
 * @(#)StringUtils.java 2014/07/21
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.bnq.util;

import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Collection;
import java.util.Map;
import java.util.regex.Pattern;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bnq.bs.model.BsCode;
import com.bnq.util.cache.BsCodeDefinition;

public class StringUtils {
	private static final Log log = LogFactory.getLog(StringUtils.class);
	private static final String regx = "^[-+]?(\\d+(\\.\\d*)?|\\.\\d+)([eE][-+]?\\d+)?[dD]?$";// 科學計數法正則表達式
	private static final String regx_num = "\\d*";// 匹配數字字符串
	private static Pattern pattern = Pattern.compile(regx);
	private static final DecimalFormat DF = new DecimalFormat("0");
	
	public static String formateDouble(Double d) {
		return DF.format(d);
	}

	public static String trimToNumber(String str) {
		return str.replaceAll("\\D", "");
	}
	
	/**
	 * 替換斷行[\r\n]為HTML的[&lt;br&gt;]代碼
	 * @param result
	 * @return
	 */
	public static String transRNToBr(String result){
		if( result != null ){
			String temp = result.replaceAll("\r\n", "<br>"); 
			return temp.replaceAll("\r\n", "<br/>");
		}else
			return result;
	}
	
	/**
	 * 替換[HTML]的[&lt;br&gt;]為斷行\r\n代碼
	 * @param result
	 * @return
	 */
	public static String transBrToRN(String result){
		if( result != null ){
			String temp =  result.replaceAll("<br/>", "\r\n");
			return temp.replaceAll("<br>", "\r\n");
		}else
			return result;
	}

	/**
	 * 傳入電話號碼字串，移除phone number中的非數字字元，回傳全數字。
	 * @param phone
	 * @return
	 */
	public static String formatPhone(String phone) {
		return trimToNumber(phone);
	}

	public static String formatMoney(Double value) {
		if(value != null) {
			return formatMoney(value.doubleValue());
		} else {
			return "0";
		}
	}

	public static String formatMoney(double value) {
		return NumberFormat.getInstance().format(value);
	}

	public static String trim(String str) {
		return str!=null?str.trim():null;
	}
	
	/**
	 * 將 object.toString() 去除"["、"]" 及前後多餘的空白後回傳。
	 * @param object 來源集合
	 * @return 若 object 為空值回傳 null。
	 */
	@SuppressWarnings("rawtypes")
	public static String clearString(Collection object) {
		if(CollectionUtils.isEmpty(object)) return null;
		
		return object.toString().replace("[", "").replace("]", "").trim();
	}

	public static String blankToNull(String str) {
		String rtv = trim(str);
		if(rtv != null && rtv.length() == 0) {
			rtv = null;
		}
		return rtv;
	}

	public static String transNull(Object o) {
		if(o == null) {
			return "" ;
		}
		String rtv = trim(o.toString());
		return rtv == null ? "" :rtv ;
	}
	
	public static String getByteString(String text,int pos,int length,String encoding) {
		if(text == null || text.trim().equals("")) {
			return "" ;
		}
		byte[] source = null ;
		if(encoding != null && !encoding.trim().equals("")) {
			try {
				source = text.getBytes(encoding) ;
			} catch (UnsupportedEncodingException e) {
				log.error(e.getMessage(), e);
				source = text.getBytes() ;
			}
		}else{
			source = text.getBytes() ;
		}
		if(source.length >= (pos+length)) {
			byte[] target = new byte[length] ;
			System.arraycopy(source,pos,target,0,length);
			return new String(target) ;
		}else{
			log.debug("String length is shorter than required.");
			return "" ;
		}
	}

	public static String getStringUtil(String str,int size) throws UnsupportedEncodingException {
		if(size == 0) {
			return str+"\n" ;
		}
		if(str == null) {
			str = "" ;
		}
		int strLength = str.length() ;
		int strSize = 0 ;
		StringBuffer sb = new StringBuffer() ;
		for(int i=0;i<strLength;i++) {
			int temp = (String.valueOf((str.charAt(i))).getBytes()).length ;
			int current = 0 ;
			if(temp != 1) {
				current = 2 ;
			}else{
				current = 1 ;
			}
			strSize += current ;
			if(strSize <= size) {
				sb.append(str.charAt(i)) ;
			}else{
				strSize -= current ;
				break ;
			}
		}
		int appendSize = sb.length() + (size - strSize) ;
		return org.apache.commons.lang.StringUtils.rightPad(sb.toString(), appendSize) ;
	}

	public static String getPasswordFormat(String s) {
		if(s == null || s.trim().equals("")) {
			return "" ;
		}
		int start = 1 ;
		int reserve = 4 ;
		char c = '●' ;
		StringBuffer sb = new StringBuffer() ;
		try {
			for (int i = 0; i < (s.length()-(start+reserve)); i++) {
				sb.append(c) ;
			}
		} catch(Exception e) {
			for (int i = 0; i < s.length(); i++) {
				sb.append(c) ;
			}
			return sb.toString() ;
		}
		CharSequence cs1 = s.subSequence(start, s.length()-reserve) ;
		return s.replace(cs1, sb) ;
	}

	public static String getHeadFilledString(String origStr, int totalLength, String filledChar) {
		String rtv = origStr;

		if(origStr.length() < totalLength) {
			StringBuffer sb = new StringBuffer();
			for(int i=0; i<totalLength-origStr.length(); i++) {
				sb.append(filledChar);
			}
			rtv = sb.toString() + origStr;
		}

		return rtv;
	}

	/**
	 * @param addr1
	 * @param addr2
	 * @param addr3
	 * @param addr4
	 * @param addr5
	 * @return
	 */
	public static String getAddressString(String addr1,String addr2,String addr3,String addr4,String addr5){
		String address = "";
		if(org.apache.commons.lang.StringUtils.isNotBlank(addr1)){
			BsCode bsCode = BsCodeDefinition.findAllMemberByCodeClassAndCodeNo("CY",addr1);
			if (bsCode!=null){
				address += (bsCode.getCodeExplain()+" ");
			}
		}
		if(org.apache.commons.lang.StringUtils.isNotBlank(addr2)){
			address += (addr2+" ");
		}
		if(org.apache.commons.lang.StringUtils.isNotBlank(addr3)){
			BsCode bsCode = BsCodeDefinition.findAllMemberByCodeClassAndCodeNo("AD",addr3);
			if (bsCode!=null){
				address += bsCode.getCodeExplain();
			}
		}
		if(org.apache.commons.lang.StringUtils.isNotBlank(addr4)){
			BsCode bsCode = BsCodeDefinition.findAllMemberByCodeClassAndCodeNo("AD",addr4);
			if (bsCode!=null){
				address += bsCode.getCodeExplain();
			}
		}
		if(org.apache.commons.lang.StringUtils.isNotBlank(addr5)){
			address += addr5;
		}
		return address;
	}

	public static String processChinaAmt(Double value,StringBuffer returnVal)throws Exception{
		if (value==null){
			return returnVal.toString();
		}
		Double newValue = Math.abs(value);
		if (newValue.compareTo(1000000000d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue/1000000000d)))
				.append("拾");
		}
		if (newValue.compareTo(100000000d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue/100000000d)))
				.append("億");
		}
		if (newValue.compareTo(10000000d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue/10000000d)))
				.append("仟");
		}
		if (newValue.compareTo(1000000d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue/1000000d)))
				.append("佰");
		}
		if (newValue.compareTo(100000d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue/100000d)))
				.append("拾");
		}
		if (newValue.compareTo(10000d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue/10000d)))
				.append("萬");
		}
		if (newValue.compareTo(1000d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue/1000d)))
				.append("仟");
		}
		if (newValue.compareTo(100d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue/100d)))
				.append("佰");
		}
		if (newValue.compareTo(10d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue/10d)))
				.append("拾");
		}
		if (newValue.compareTo(0d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue*1d)))
				.append("元");
		}
		return returnVal.toString();
	}
	
	public static String[] chinaAmt = new String[]{"零","壹","貳","參","肆","伍","陸","柒","捌","玖"};
	
	private static String processChinaAmtDetail(int value)throws Exception{
		if (value>9){
			value=value%10;
		}
		return chinaAmt[value];
	}
	
	/**
	 * 將字串格式的金錢加上千分位逗號
	 * 
	 * @param target
	 * @return
	 */
	public static  String addCommanThousandSeparator(String target) {
		StringBuilder result = new StringBuilder();
		result.append(target);
		if (target != null && target.length() > 3) {
			int count = target.length() / 3;
			int preNum = target.length() % 3;
			int commanCount = 0;
			if (preNum != 0) {
				result.insert(preNum, ",");
				commanCount++;
			}
			for (int i = 1; i < count; i++) {
				result.insert(i * 3 + preNum + commanCount, ",");
				commanCount++;
			}
		}

		return result.toString();
	}
	
	/**
	 *  用途: 用於依Parameter Name從QueryConditionMap中取值
	 *  限制:  所取之值必須為String或String[]類型, 若是其他物件類型回傳null;
	 *  @param queryCondition 封裝查詢條件的資料MAP
	 *  @param parameterName 存取查詢條件的資料MAP的Key值
	 *  @return 1. 若值為String類型, 不為null, 回傳Trim value.  
	 *          2. 若值為String[]類型, [0]不是null, 回傳Trim value.
	 *          3. 非上述兩種情況或Value為其他物件類型, 回傳null
	 */
	@SuppressWarnings("rawtypes")
	public static String getValueFromQueryCondition(Map queryCondition, String parameterName) {
		String paramValue = null;
		Object paramValObj = queryCondition.get(parameterName);
		if(paramValObj != null) {
			if(paramValObj instanceof String) {
				//如果是String類型, 回傳trim value
				paramValue = ((String)paramValObj).trim();
			} else if(paramValObj instanceof String[]) {
				//如果是String[]而且[0]不是null, 取[0]
				String[] paramValArray = (String[])paramValObj;
				if(paramValArray.length > 0 && paramValArray[0] != null)
					paramValue = paramValArray[0].trim();
			}
		}
        return paramValue==null?"":paramValue;
	}
	
	public static final int LEFT = 0;
	public static final int CENTER = 1;
	public static final int RIGHT = 2;
	private static final char SPACE = ' ';	
	public static String fillStr(String str, int posLen, int pos) {		
		if(posLen<=0) return "";
		
		if(str == null) str = "";		
		char[] list = str.toCharArray();
		
		StringBuilder sb = new StringBuilder();
		int sbLen = 0; //sb的佔位長度
		
		for(char c : list) {
			sbLen += (String.valueOf(c).getBytes().length==1 ? 1 : 2); //char的佔位長度(1或2)	
			
			if(sbLen == posLen) {
				sb.append(c);
				return sb.toString();
			} else if(sbLen > posLen) {
				if(pos == LEFT) {
					sb.insert(0, SPACE);										
				} else {
					sb.append(SPACE);
				}				
				return sb.toString();
			} else {
				sb.append(c);
			}
		}		
		
		int defLen = posLen-sbLen; //不足的長度		
		if(pos == LEFT) {
			for(int i=0; i<defLen; i++) {
				sb.insert(0, SPACE);
			}						
		} else if(pos == CENTER) {	
			for(int i=0,len=defLen/2; i<len; i++) {
				sb.insert(0, SPACE);				
			}
			for(int i=0,len=defLen-defLen/2; i<len; i++) {
				sb.append(SPACE);
			}
		} else {
			for(int i=0; i<defLen; i++) {
				sb.append(SPACE);
			}
		}
		
		return sb.toString();
	}
	
	public static String processChinaAmtSpace(Double value,StringBuffer returnVal)throws Exception{
		String space = "　";
		if (value==null){
			return returnVal.toString();
		}
		Double newValue = Math.abs(value);
		if (newValue.compareTo(1000000000d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue/1000000000d)))
				.append(space).append("拾").append(space);
		}
		if (newValue.compareTo(100000000d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue/100000000d)))
				.append(space).append("億").append(space);
		}
		if (newValue.compareTo(10000000d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue/10000000d)))
				.append(space).append("仟").append(space);
		}
		if (newValue.compareTo(1000000d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue/1000000d)))
				.append(space).append("佰").append(space);
		}
		if (newValue.compareTo(100000d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue/100000d)))
				.append(space).append("拾").append(space);
		}
		if (newValue.compareTo(10000d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue/10000d)))
				.append(space).append("萬").append(space);
		}
		if (newValue.compareTo(1000d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue/1000d)))
				.append(space).append("仟").append(space);
		}
		if (newValue.compareTo(100d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue/100d)))
				.append(space).append("佰").append(space);
		}
		if (newValue.compareTo(10d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue/10d)))
				.append(space).append("拾").append(space);
		}
		if (newValue.compareTo(0d)>=0){
			returnVal
				.append(processChinaAmtDetail((int)(newValue*1d)))
				.append(space).append("元");
		}
		return returnVal.toString();
	}
	
	/**
	 * 半型字轉全型字
	 * 不可以用於JSP轉字,否則' and " 會變成 ?
	 * @param QJstr
	 * @return
	 */
	public static final String covertToDoubleByte(String QJstr){
		 String outStr="";
	     String Tstr="";
	     byte[] b=null;
	     for(int i=0;i<QJstr.length();i++){
	    	 try{
	    		 Tstr=QJstr.substring(i,i+1);
	    		 b=Tstr.getBytes("unicode");
	    	 }catch(java.io.UnsupportedEncodingException e){
	    		 log.error(e.getMessage(), e);
	    	 }     
	   
	       //if (b[3]==-1) 全型轉半型
	    	 if(b[3]==0){
	       //b[2]=(byte)(b[2]+32);
	       //空白作跳脫處理
	    	  if(b[2]!=32&&b[2]!=126){
	    		  b[2]=(byte)(b[2]-32);
	    		  b[3]=-1;
	    	  }
	    	  try{       
	    		  outStr=outStr+new String(b,"unicode");
	    	  }catch(java.io.UnsupportedEncodingException e){
	    		  log.error(e.getMessage(), e);
	    	  }      
	    	 }else outStr=outStr+Tstr;
	     }
	     //防止出錯無字串問題
	     if("".equals(outStr)) return ""; 
	     return outStr; 
	}
	
	/**
	 * 特殊字元由半型字轉全型字
	 * @param sStr 來源字串
	 * @return
	 */
	public static final String covertSpecialToHolomorph(String sStr) {
		// 轉換後字串
		String outStr = "";
		// 處理中字元
		String tStr = "";
		byte[] b = null;
		
		for(int i = 0; i < sStr.length(); i++) {
			tStr = sStr.substring(i, i + 1);
			// 英數字或空白不作全形轉換
			if(org.apache.commons.lang.StringUtils.isAlphanumericSpace(tStr)) {
				outStr += tStr;
			} else {
				try {
		    		b = tStr.getBytes("unicode");
		    	} catch(java.io.UnsupportedEncodingException e) {
		    		log.error(e.getMessage(), e);
		    	}
		    	
		    	if(b[3] == 0) {
		    		//空白作跳脫處理
		    		if(b[2] != 32 && b[2] != 126) {
		    			b[2]=(byte)(b[2]-32);
		    			b[3]=-1;
		    		}
		    	  
		    		try {
		    			outStr=outStr+new String(b,"unicode");
		    		} catch(java.io.UnsupportedEncodingException e) {
		    			log.error(e.getMessage(), e);
		    		}      
		    	} else {
		    		outStr += tStr;
		    	}
			}
		}
		//防止出錯無字串問題
		if(org.apache.commons.lang.StringUtils.isBlank(outStr)) return ""; 
		return outStr; 
	}
	
	/**
	 * 科學計數法轉換為普通數字
	 * @return String 要轉換的字符串
	 */
	public static String formatNumber(String str) {
		if (str != null && !str.matches(regx_num)) {
			if (pattern.matcher(str).matches()) {
				NumberFormat fomatter = new DecimalFormat();
				String[] dataList = fomatter.format(Double.parseDouble(String.valueOf(str))).split(",");
				StringBuffer sb = new StringBuffer();
				for (int i = 0; i < dataList.length; i++) {
					sb.append(dataList[i]);
				}
				return sb.toString();
			}
		}
		return str;
	}
	
	/**
	 * 將姓名中間的字轉換，隱藏起來
	 * */
	public static String formatName(String name){
		if(name == null || "".equals(name)){
			return "";
		}
		
		name = name.trim();
		StringBuffer formatName = new StringBuffer();
		
		formatName.append(name.substring(0, 1));
		for(int i = 1; i<name.length() - 1; i ++){
			formatName.append("O");
		}
		
		if(name.length() > 1){
			if(name.length() != 2)
				formatName.append(name.substring(name.length()-1, name.length()));
			else
				formatName.append("O");
		}
		
		return formatName.toString();
	}
	
	
	/**
	 * 替換換行符號為""
	 * @param result
	 * @return
	 */
	public static String strReplace(String result){
		if( result != null || !"".equals(result)){
			return result.replaceAll("\\\\r\\\\n", "").replaceAll("\\\\n", "").replaceAll("\\r\\n", "").replaceAll("\\n", "").replaceAll("\r\n", "").replaceAll("\n", ""); 
		}else
			return result;
	}
	
	/**
	 * 將 Collection 依據 symbol 重組字串，並移除 collection 內 blank 字串。
	 * @param collection 來源
	 * @param symbol 分隔符號
	 * @return
	 */
	public static String splitCollection(Collection<String> collection, String symbol) {
		StringBuilder msg = new StringBuilder();
		for(String contect : collection) {
			if(org.apache.commons.lang.StringUtils.isNotBlank(contect) && !"null".equalsIgnoreCase(contect)) {
				if(msg.length() > 0)
					msg.append(symbol);
				msg.append(contect);
			}
		}
		return msg.toString();
	}
	
	/**
	 * 先將傳入的字串，去除換行符號，再根據傳入的字數限制，將超過的字串去除。
	 * @param str 欲處理的字串
	 * @param maxLimit 字數長度限制
	 * @return 去除換行及長度限制處理後的字串
	 */
	public static String replaceEnterAndStringLimit(String str, int maxLimit){
		String result = strReplace(str);
		if(org.apache.commons.lang.StringUtils.isNotBlank(result) && result.length() > maxLimit){
			result = result.substring(0, maxLimit);
		}
		return result;
	}
	
	public static String replaceNullToEmptyString(String string) {
		return org.apache.commons.lang.StringUtils.isBlank(string) ? "" : string;
	}
}