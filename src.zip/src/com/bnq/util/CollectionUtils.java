package com.bnq.util;

import java.util.*;

public class CollectionUtils {

	/**
	 * 轉換List物件成Set物件, 返回的Set不會依List順序排序
	 * @param list
	 * @return
	 * @throws Exception
	 */
	public static Set listToSet(List list) throws Exception {
		return listToSet(list, null);
	}

	/**
	 * 轉換List物件成Set物件, 返回的Set會依Comparator排序
	 * @param list
	 * @return
	 * @throws Exception
	 */
	public static Set listToSet(List list, Comparator comparator) throws Exception{
		Set set = null;
		if(list != null) {
			if(comparator == null) {
				set = new HashSet(list);
			} else {
				set = new TreeSet(comparator);
				set.addAll(list);
			}
		}
		return set;
	}
	
	public static List setToList(Set set) {
		List list = null;
		if(set != null) {
			list = new ArrayList(set);
		}
		return list;
	}
	
	public static void show(Collection coll) {
		for(Object obj: coll)
			System.out.println(obj);
	}
	
	public static void main(String[] args) throws Exception {
		List<String> list = new ArrayList<String>();
		list.add("1");
		list.add("3");
		list.add("2");
		list.add("5");
		list.add("4");
		
		/*
		Comparator myComparator = new Comparator<String>() {
			public int compare(String str1, String str2) {
				int s1 = Integer.parseInt(str1);
				int s2 = Integer.parseInt(str2);
				return s1-s2;
			}
			public boolean equals(String str1, String str2) {
				if(str1.equals(str2))
					return true;
				else
					return false;
			}
		};
		
		//會排序
		Set set = listToSet(list, myComparator);
		*/

		//不會排序
		Set set = listToSet(list);
		show(set);
		
		System.out.println("\n\n");
		
		List list1 = setToList(set);
		show(list1);
		
		
	}
}
