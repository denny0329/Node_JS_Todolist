package com.bnq.util;

import java.io.Serializable;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

public class StringId implements Serializable {
	private static final long serialVersionUID = -2916207071594696734L;

	private String id;
	private String name;
	public StringId(){
		
	}
	
	public StringId(String id, String name) {
		this.id = id;
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public boolean equals(Object other) {
		if (other != null && other instanceof StringId) {
			StringId castOther = (StringId) other;
			return new EqualsBuilder().append(this.getId(),
							castOther.getId()).isEquals();
		}
		return false;
	}

	public int hashCode() {
		return new HashCodeBuilder().append(this.getId()).toHashCode();
	}
}
