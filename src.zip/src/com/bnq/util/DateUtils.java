/**
 * @(#)DateUtils.java 2014/05/02
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.bnq.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.sc.model.ScSysuser;
import com.gccs.bs.model.BsStore;
import com.gccs.util.cache.BsStoreDefinition;
import com.rfep.bs.model.BsCalendar;
import com.rfep.bs.service.BsCalendarService;
import com.rfep.iv.model.IvBaseEntity;
import com.trg.oms.factory.ArrivalDateFactory;
import com.trg.oms.factory.DateFactory;
import com.trg.oms.utils.UserUtil;

public class DateUtils {
	private static final Logger log = LogManager.getLogger(DateUtils.class);

	/**
	 * 回傳 inDate 依日期 offset 後的日期, ex: 2010/3/6, -2, 則回傳 2010/3/4  
	 * @param inDate
	 * @param offset
	 * @return
	 */
	public static Date addDay(Date inDate, int offset){
		if(inDate==null) return null;
		
		try {
			Calendar cal = Calendar.getInstance();
			cal.setTime(inDate);
			cal.add(Calendar.DATE, offset);
			return cal.getTime();
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 第 N 個工作日: n=0為 inDate
	 * @param inDate
	 * @param offset
	 * @return
	 */
	public static Date getWorkDay(String storeId, Date inDate, int offset){
		if(inDate==null) return null;
		
		//取行事曆代碼
		BsStore bsStore = BsStoreDefinition.getByStoreId(storeId);
		String calId = bsStore.getCalId();
		
		BsCalendarService bsCalendarService = (BsCalendarService)AppContext.getBean("bsCalendarService");
		List<BsCalendar> bsCalendars = bsCalendarService.findBsCalendars(calId, true, inDate, 1, Math.abs(offset), offset>=0);
		if(bsCalendars != null && !bsCalendars.isEmpty()){
			return bsCalendars.iterator().next().getId().getDateVal();
		}
		
		return null;
	}
	
	/**
	 * 比較日期  date1 > date2
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static boolean after(Date date1, Date date2){
		if(date1==null && date2==null) return false;
		
		if(date1==null) return false;
		if(date2==null) return true;
		return date1.after(date2);
	}
	
	/**
	 * 將傳入日期 format 成 yyyy/MM/dd 格式
	 * @param dt
	 * @return
	 */
	public static String cdateFormat(Date dt){
		if(dt==null) return "";
		return new SimpleDateFormat("yyyy/MM/dd").format(dt);
	}
	
	/**
	 * 將傳入日期 format 成 yyyyMMdd 格式
	 * @param dt
	 * @return
	 */
	public static String cdateFormat2(Date dt){
		if(dt==null) return "";
		return new SimpleDateFormat("yyyyMMdd").format(dt);
	}
	
	/**
	 * 將傳入日期 format 成 yyMMdd 格式
	 * @param dt
	 * @return 若 dt 為 null 則傳回空字串
	 */
	public static String cdateFormatYYMMDD(Date dt){
		if(dt==null) return "";
		return new SimpleDateFormat("yyMMdd").format(dt);
	}
	
	/**
	 * 將傳入日期 format 成 pattern 格式
	 * @param dt
	 * @return
	 */
	public static String cdateFormat(Date dt, String pattern){
		if(dt==null) return "";
		DateFormat _df = new SimpleDateFormat(pattern);
		return _df.format(dt);
	}
	
	/**
	 * 將傳入日期 source 依 DateFormat 回傳日期
	 * @param source
	 * @param pattern
	 * @return [格式錯誤,回傳當下日期]
	 */
	public static Date stringParse(String source, DateFormat _df){
		if( _df != null ){
			try {
				return _df.parse(source);
			} catch (ParseException e) {
				return new Date();
			}
		}else{
			return new Date(); 
		}
	}
	
	/**
	 * trim 掉 dt 的時間部份
	 * @param dt
	 * @return
	 */
	public static Date trunc(Date dt){
		if(dt==null) return null;
		try {
			return new SimpleDateFormat("yyyy/MM/dd").parse(new SimpleDateFormat("yyyy/MM/dd").format(dt));
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 傳入 "yyyy/MM/dd" 格式字串, 回傳 Date
	 * @param cdate 
	 * @return 當 cdate = null 或發生轉換異常，都傳回 null。
	 */
	public static Date getDate(String cdate){
		if(org.apache.commons.lang.StringUtils.isBlank(cdate) || cdate.indexOf("/") == -1) return null;
		try {
			return new SimpleDateFormat("yyyy/MM/dd").parse(cdate);
		} catch (Exception e) {
			return null;
		}
	}
	
	/**
	 * 傳入 "yyyy/MM/dd hh:mm:ss" 格式字串, 回傳 Date
	 * @param cdate 
	 * @return 當 cdate = null 或長度不為 19 碼或分隔符號不為 / 或發生轉換異常，都傳回 null。
	 */
	public static Date getDateTime(String cdate){
		if(cdate==null || cdate.length()!=19 || cdate.indexOf("/")==-1) return null;
		try{
			return new SimpleDateFormat("yyyy/MM/dd hh:mm:ss").parse(cdate);
		}catch(Exception e){
			return null;
		}
	}
	
	/**
	 * 將字串轉換為 Date。
	 * @param dateTime 傳入字串格式：yyyy/MM/dd HH:mm:ss(24小時制)
	 * @return 轉換失敗傳回 null
	 */
	public static Date transformStringToDateTime(String dateTime) {
		try{
			return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(dateTime);
		}catch(Exception e){
			return null;
		}
	}
	
	/**
	 * 將DB的SYSDATE轉為java.util.Date
	 * 
	 * @param sysDate 2013-07-19 15:20:41
	 * @return
	 */
	public static Date getDBSysDate(String sysDate){
	    if(sysDate == null) return null;
	    try{
	        return new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse(sysDate);
	    }catch(Exception e){
            return null;
        }
	}
	
	/**
	 * 回傳今日日期(無時間)
	 * @return
	 */
	public static Date getToday(){
		return trunc(Calendar.getInstance().getTime());
	}
	
	/**
	 * 回傳目前 日期+時間
	 * @return
	 */
	public static Date getNow(){
		return Calendar.getInstance().getTime();
	}
	
	/**
	 * 依據 type 設定建立人員及時間或最後修改者及時間。
	 * @param entity
	 * @param type 1=set create only, 2=set modify only, 3=set create+modify both
	 * @param user 使用者物件
	 */
	public static void prepareDateInfoForCurrentUser(IvBaseEntity entity, ScSysuser user) {
		if(entity == null || user == null) return;
		entity.initUser(user);
	}

	/**
	 * @param entity
	 * @author pei
	 */
	public static void prepareDateInfoForCurrentUser(IvBaseEntity entity) {
		ScSysuser user = UserUtil.getUserObject();
		prepareDateInfoForCurrentUser(entity, user);
	}
	
	/**
	 * 取得廠商預計到貨日
	 * @param createTime	計算預計到貨日起始時間	
	 * @param dcType		供應商類別
	 * @param vendorId		廠商編號
	 * @param companyId		公司別代碼
	 * @return Date			預計到貨日
	 */
	public static synchronized Date getVendorArrivalDate(Date createTime, Object dcType, Object vendorId, Object companyId) {
		DateFactory dateFactory = (DateFactory)AppContext.getBean("arrivalDateFactory");
		HashMap<String, Object> params = new HashMap<String, Object>();
		
		params.put(ArrivalDateFactory.PARAM_CREATEFORMDATE, createTime);
		params.put(ArrivalDateFactory.PARAM_DCTYPE, dcType);
		params.put(ArrivalDateFactory.PARAM_VENDORID, vendorId);
		params.put(ArrivalDateFactory.PARAM_COMPANYID, companyId);
		
		//2021.03新增，(相比方法 getVendorArrivalDateForIsland)
		params.put(ArrivalDateFactory.PARAM_STOREID, null);
		params.put(ArrivalDateFactory.PARAM_SKU, null);
		
		log.debug("取得廠商預計到貨日:createTime[" + createTime + "], dcType[" + dcType + "], vendorId[" + vendorId + "], companyId[" + companyId + "]");
		
		dateFactory.prepare(params);
		// 廠商預計到貨日
		return dateFactory.getDate();
	}
	
	/**
	 * 取得廠商預計到貨日
	 * (有判斷離島店)
	 * @param createTime	計算預計到貨日起始時間	
	 * @param dcType		供應商類別
	 * @param vendorId		廠商編號
	 * @param companyId		公司別代碼
	 * @param storeId		通路店別
	 * @param sku			商品編號
	 * @return Date			預計到貨日
	 */
	public static synchronized Date getVendorArrivalDateForIsland(Date createTime, Object dcType, Object vendorId, Object companyId, Object storeId, Object sku) {
		DateFactory dateFactory = (DateFactory)AppContext.getBean("arrivalDateFactory");
		HashMap<String, Object> params = new HashMap<String, Object>();
		
		params.put(ArrivalDateFactory.PARAM_CREATEFORMDATE, createTime);
		params.put(ArrivalDateFactory.PARAM_DCTYPE, dcType);
		params.put(ArrivalDateFactory.PARAM_VENDORID, vendorId);
		params.put(ArrivalDateFactory.PARAM_COMPANYID, companyId);
		params.put(ArrivalDateFactory.PARAM_STOREID, storeId);
		params.put(ArrivalDateFactory.PARAM_SKU, sku);
		
		log.debug("取得廠商預計到貨日:createTime[" + createTime + "], dcType[" + dcType + "], vendorId[" + vendorId + "]"
				+ ", companyId[" + companyId + "], storeId[" + storeId + "], sku[" + sku + "]");
		
		dateFactory.prepare(params);
		// 廠商預計到貨日
		return dateFactory.getDate();
	}
	
	/**
	 * 返回兩個日期中最晚的那個日期。
	 * @param d1
	 * @param d2
	 * @return 若來源都是 null，就返回 null。
	 */
	public static Date returnLasterDate(Date d1, Date d2) {
		if(d1 == null && d2 == null) {
			return null;
		} else if(d1 == null && d2 != null) {
			return d2;
		} else if(d1 != null && d2 == null) {
			return d1;
		} else {
			if(d1.compareTo(d2) >= 0) {
				return d1;
			} else {
				return d2;
			}
		}
	}
	
	/**
	 * 移除毫秒
	 * @param source
	 * @return
	 */
	public static Date truncMillisecond(Date source) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(source);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}
}