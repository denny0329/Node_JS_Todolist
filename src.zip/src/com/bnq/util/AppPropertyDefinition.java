/**
 * @(#) AppPropertyDefinition.java 2016/02/24
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.bnq.util;

import java.util.Map;
import java.util.HashMap;

public class AppPropertyDefinition {
    
	private static Map<String,String> PROP_LIST = new HashMap<String,String>(); 
	
	private final static String APP_PROP_FILE = "application.properties";
	
	private AppPropertyDefinition() {
		
	}
	
	static {
		init();
	}
	
	private static void init() {
		PROP_LIST = PropertyConfigUtils.getProperties(APP_PROP_FILE);
	}
	
	public static String getValue(String propertyName) {
		return PROP_LIST.get(propertyName);
	}
	
	/**
	 * 取得目前版本。
	 * @return
	 */
	public static String getAppVersion() {
		return PropertyConfigUtils.getProperties("version.properties").get("APP_VERSION");
	}
	
}
