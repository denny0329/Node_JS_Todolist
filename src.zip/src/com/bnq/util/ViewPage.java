package com.bnq.util;

import com.gccs.util.cache.BsCompanyDefinition;
import com.trg.oms.utils.UserUtil;

public class ViewPage {
	
	private static String contextPath;
	
	public static String getContextPath() {
		String rtv = null;
		if(contextPath!=null && contextPath.trim().length() > 0)
			rtv = contextPath;
		return rtv;
	}

	public static void setContextPath(String contextPath) {
		ViewPage.contextPath = contextPath;
	}

	/**
	 * @param p
	 * p.getFormName()指定表單名稱
	 * pageBean
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static String getToolsMenuByDefault(PageBean p) {
		return getToolsMenuByPicLayer(p,2) ;
	}

	@SuppressWarnings("rawtypes")
	public static String getToolsMenuByPicLayer(PageBean p,int layer, String btnHTML) {
		String urlIdCode = BsCompanyDefinition.getBsCompanyById(UserUtil.getUserObject().getCompanyId()).getUrlIdCode().toLowerCase();
		String layerStr = contextPath;//getPicLayer(layer) ;
		StringBuffer str = new StringBuffer("");
		int next, prev;
		prev = p.getPage() - 1;
		next = p.getPage() + 1;
		
		str.append("<table width=\"100%\" cellSpacing=\"0\" cellPadding=\"0\" border=\"0\">");
		str.append("	<tr>");
		str.append("		<th align=\"left\" class=\"thdDown\">");
		str.append("		").append(btnHTML);
		str.append("			<span style=\"font-weight: 400\">");
		str.append("				"+p.getColumnSum()+":" + p.getCount());
		str.append("			</span>");
		str.append("		</th>");
		str.append("		<th align=\"right\" class=\"thdDown\">");
		str.append("			<span style=\"font-weight: 400\">");
				if (p.getPage() > 1) {					
					str.append("<a id='firstPage' href='#' onclick='document.getElementsByName(\""+p.getName()+".jumpPage\")[0].value=1;document.getElementsByName(\"isBtnQuery\")[0].value=\"no\"; document.forms[\""+p.getFormAction()+"\"].submit();'><img class='style1' alt='"+p.getPageFirst()+"' src='"+layerStr+"/images/"+urlIdCode+"/start.gif' /></a>");
					str.append("<a id='prePage' href='#' onclick='document.getElementsByName(\""+p.getName()+".jumpPage\")[0].value=" + prev + ";document.getElementsByName(\"isBtnQuery\")[0].value=\"no\";document.forms[\""+p.getFormAction()+"\"].submit();'><img class='style1' alt='"+p.getPagePrevious()+"' src='"+layerStr+"/images/"+urlIdCode+"/left.gif' /></a>");
				} else {					
					str.append("<img alt='' src='"+layerStr+"/images/"+urlIdCode+"/start1.gif' />");
					str.append("<img alt='' src='"+layerStr+"/images/"+urlIdCode+"/left1.gif' />");
				}
				str.append("&nbsp;&nbsp;&nbsp;<SELECT id='selectPage' class=row12 size=1 name=Pagelist onchange='document.getElementsByName(\""+p.getName()+".jumpPage\")[0].value=this.value;document.getElementsByName(\"isBtnQuery\")[0].value=\"no\";document.forms[\""+p.getFormAction()+"\"].submit();'>");
				for (int i = 1; i < p.getPageCount() + 1; i++) {
					if (i == p.getPage()) {
						str.append("<OPTION value=" + i + " selected>" + i
								+ "</OPTION>");
					} else {
						str.append("<OPTION value=" + i + ">" + i + "</OPTION>");
					}
					if(i >= 1000) {
						break ;
					}
				}
				str.append("</SELECT>"+"&nbsp;&nbsp;&nbsp;");
				if (p.getPageCount() > 1 && p.getPage() < p.getPageCount()) {   //目前頁數 < 總頁數 
					str.append("<a id='nextPage' href='#' onclick='document.getElementsByName(\""+p.getName()+".jumpPage\")[0].value="+ next + ";document.getElementsByName(\"isBtnQuery\")[0].value=\"no\"; document.forms[\""+p.getFormAction()+"\"].submit();'><img class='style1' alt='"+p.getPageNext()+"' src='"+layerStr+"/images/"+urlIdCode+"/right.gif' /></a>");
					str.append("<a id='lastPage' href='#' onclick='document.getElementsByName(\""+p.getName()+".jumpPage\")[0].value="+ p.getPageCount()+ ";document.getElementsByName(\"isBtnQuery\")[0].value=\"no\";document.forms[\""+p.getFormAction()+"\"].submit();'><img class='style1' alt='"+p.getPageLast()+"' src='"+layerStr+"/images/"+urlIdCode+"/end.gif' /></a>");
				} else {    //目前頁數 == 總頁數
					str.append("<img alt='' src='"+layerStr+"/images/"+urlIdCode+"/right1.gif' />");
					str.append("<img alt='' src='"+layerStr+"/images/"+urlIdCode+"/end1.gif' />");
				}
		str.append("			</span>");
		str.append("		</th>");
		str.append("	</tr>");
		str.append("</table>");
		
		return str.toString();
	}
	
	@SuppressWarnings("rawtypes")
	public static String getToolsMenuByPicLayer(PageBean p,int layer) {
		return getToolsMenuByPicLayer(p,layer,"");
	}
}
