package com.bnq.util;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.bnq.base.action.BaseAction;
import com.bnq.bs.model.BsDept;
import com.bnq.cs.util.SelectItemBean;
import com.bnq.sc.model.ScSysuser;
import com.bnq.util.cache.BsDeptDefinition;
import com.bnq.util.cache.BsVariableDefinition;
import com.bnq.util.cache.CompetitorDefinition;
import com.bnq.util.competitor.model.vo.CompetitorBranchVO;
import com.bnq.util.competitor.model.vo.CompetitorVO;
import com.gccs.bs.dao.hibernate.BsChannelDAO;
import com.gccs.bs.model.BsChannel;
import com.gccs.bs.model.BsStore;
import com.gccs.util.cache.CcSettingMstDefinition;

/**
 * <b></b>
 * @author kaychen
 * @Date: 2009/1/5 上午 11:48:44
 * @Project Name: bnq
 * @Package Name: com.bnq.util
 * @File Name: SelectItemAction.java
 */
public class SelectItemAction extends BaseAction {
	private static final long serialVersionUID = 3845352813407080276L;

	private SelectItemBean property = SelectItemBean.getInstatnce() ;
	private Date dateFrom ;
	private Map<String,TreeMap<String,String>> list2 = new HashMap<String, TreeMap<String,String>>();
	private BsChannelDAO bsChannelDao; 
	
	public BsChannelDAO getBsChannelDao() {
		return bsChannelDao;
	}

	public void setBsChannelDao(BsChannelDAO bsChannelDao) {
		this.bsChannelDao = bsChannelDao;
	}
	
	public Map<String, TreeMap<String, String>> getList2() {
		return list2;
	}

	public void setList2(Map<String, TreeMap<String, String>> list2) {
		this.list2 = list2;
	}

	public SelectItemBean getProperty() {
		return property;
	}

	public Date getDateFrom() {
		Calendar c = Calendar.getInstance() ;
		c.add(Calendar.DATE, BsVariableDefinition.getqueryDays()) ;
		dateFrom = c.getTime() ;
		return dateFrom;
	}
	
	public Date getdefaultDateFrom(){
		Calendar c = Calendar.getInstance() ;
		String channelId = "";
		List list = this.getChannelStoresForCRM();
		if(list.size()>1){ //代表總公司
			channelId = "OTHER";
		}else{
			channelId = ((BsChannel)list.get(0)).getChannelId();
		}
		System.out.println("======"+channelId);
		CcSettingMstDefinition.getCcSettingMst(channelId);
		c.add(Calendar.DATE, CcSettingMstDefinition.getqueryDays()) ;
		dateFrom = c.getTime() ;
		return dateFrom;
	}
	
	public Date getDateFrom2Year() {
		Calendar c = Calendar.getInstance() ;
		c.add(Calendar.YEAR, -2) ;
		dateFrom = c.getTime() ;
		return dateFrom;
	}
	
	/** 取得所有正常營業店
	 * @return
	 */
	public List getShopList() {
		List shopList = BsDeptDefinition.getAllDeptOnUnit2Dept1();
		if(shopList.isEmpty()) {
			BsDept bsDept = new BsDept();
			bsDept.setDeptId("");
			bsDept.setDeptName("無資訊");
			shopList.add(bsDept);
		}
		return shopList;
	}
	
	/** 維修頁面處理店點
	 * @return
	 */
	public List getMaintainSupportDeptList() {
		List supportDeptList = null;
		ScSysuser user = (ScSysuser)this.getSessionMap().get("user");
		try {
			Date sysDate = DateTimeUtils.getFormatSysDate();
			if(user.getLoginTime().after(sysDate)) {
				if(user.getUserRead()==2)
					supportDeptList = user.getSupportDeptList();
				else
					supportDeptList = user.getSupportDeptList();
			} else {
				ShopValidator validate = (ShopValidator)AppContext.getBean("ShopValidator");
				List dataList = validate.getIsValidShop(user);
				List supportList = (List)dataList.get(0);
				List hqSupportList = (List)dataList.get(1);
				boolean showPcBtn = (Boolean)dataList.get(2);
				if(user.getUserRead()==2)
					supportDeptList = hqSupportList;
				else
					supportDeptList = supportList;
				user.setSupportDeptList(supportDeptList);
				user.setHqSupportDeptList(hqSupportList);
				user.setShowPcBtn(showPcBtn);
				this.getSessionMap().put("user", user);
			}
		} catch (Throwable e) {
			supportDeptList = new ArrayList();
			BsDept bsDept = new BsDept();
			bsDept.setDeptId("");
			bsDept.setDeptName("無資訊");
			supportDeptList.add(bsDept);
			e.printStackTrace();
		}
		return supportDeptList;
	}
	
	/**
	 * for 301
	 */
	@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
	public List getChannelStoresForCRM(){
		List<BsChannel> channelList = new ArrayList<BsChannel>();
		LinkedHashSet<BsChannel> result = new LinkedHashSet<BsChannel>();
		List supportDeptList = null;
		boolean isoption = false;
		try{
			ScSysuser user = (ScSysuser)this.getSessionMap().get("user");
			Date sysDate = DateTimeUtils.getFormatSysDate();
			if(user.getLoginTime().after(sysDate)) {
				if(user.getUserRead()==2){
					supportDeptList = user.getSupportDeptList();
					isoption = true; 
				}else{
					supportDeptList = user.getSupportDeptList();}
			} else {
				ShopValidator validate = (ShopValidator)AppContext.getBean("ShopValidator");
				List dataList = validate.getIsValidShop(user);
				List supportList = (List)dataList.get(0);
				List hqSupportList = (List)dataList.get(1);
				boolean showPcBtn = (Boolean)dataList.get(2);
				if(user.getUserRead()==2){
					supportDeptList = hqSupportList;
					isoption = true;
				}else{
					supportDeptList = supportList;}
				user.setSupportDeptList(supportDeptList);
				user.setHqSupportDeptList(hqSupportList);
				user.getstores();
				user.setShowPcBtn(showPcBtn);
				this.getSessionMap().put("user", user);
			}
			for (BsStore b : user.getBsStorelList()) {
				result.add(b.getBsChannel());
				if(this.list2.containsKey(b.getId().getChannelId())){
					this.list2.get(b.getId().getChannelId()).put(b.getId().getStoreId(),b.getId().getStoreId()+"-"+b.getStoreName1());
				}else{
					TreeMap map = new TreeMap();
					map.put(" ","-請選擇-");
					map.put(b.getId().getStoreId(),b.getId().getStoreId()+"-"+b.getStoreName1());					
					this.list2.put(b.getId().getChannelId(), map);
				}
			}
			if(isoption){
				BsChannel b = new BsChannel();
				b.setChannelId(" ");
				b.setChannelName1("請選擇-");
				channelList.add(b);
				TreeMap map = new TreeMap();
				map.put(" ","-請選擇-");
				this.list2.put(" ", map);
			}
			for (String key : this.list2.keySet()) {
				Map map = (Map)this.list2.get(key);
				if(map.size()==2){
					map.remove(" ");
				}
			}
			channelList.addAll(result);
		}catch(Exception e){
			supportDeptList = new ArrayList();
			BsChannel bschannel = new BsChannel();
			bschannel.setChannelId("");
			bschannel.setChannelName1("無資訊");
			supportDeptList.add(bschannel);
			e.printStackTrace();
		}
		return channelList;
	}
	
	/**
	 * for 323,321
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
	public List getChannelStoresFor3(){
		List<BsChannel> channelList = new ArrayList<BsChannel>();
		LinkedHashSet<BsChannel> result = new LinkedHashSet<BsChannel>();
		List supportDeptList = null;
		boolean isoption = false;
		try{
			ScSysuser user = (ScSysuser)this.getSessionMap().get("user");
			Date sysDate = DateTimeUtils.getFormatSysDate();
			if(user.getLoginTime().after(sysDate)) {
				if(user.getUserRead()==2){
					supportDeptList = user.getSupportDeptList();
					isoption = true; 
				}else{
					supportDeptList = user.getSupportDeptList();}
			} else {
				ShopValidator validate = (ShopValidator)AppContext.getBean("ShopValidator");
				List dataList = validate.getIsValidShop(user);
				List supportList = (List)dataList.get(0);
				List hqSupportList = (List)dataList.get(1);
				boolean showPcBtn = (Boolean)dataList.get(2);
				if(user.getUserRead()==2){
					supportDeptList = hqSupportList;
					isoption = true;
				}else{
					supportDeptList = supportList;}
				user.setSupportDeptList(supportDeptList);
				user.setHqSupportDeptList(hqSupportList);
				user.getstores();
				user.setShowPcBtn(showPcBtn);
				this.getSessionMap().put("user", user);
			}
			for (BsStore b : user.getBsStorelList()) {
				result.add(b.getBsChannel());
				if(this.list2.containsKey(b.getId().getChannelId())){
					this.list2.get(b.getId().getChannelId()).put(b.getId().getStoreId(),b.getId().getStoreId()+"-"+b.getStoreName1());
				}else{
					TreeMap map = new TreeMap();
					map.put(" ","-請選擇-");
					map.put(b.getId().getStoreId(),b.getId().getStoreId()+"-"+b.getStoreName1());					
					this.list2.put(b.getId().getChannelId(), map);
				}
			}
			
			if(this.list2.get("TLW")!=null && user.getUserRead()==2)
				this.list2.get("TLW").put("99999", "99999-轉入作業-TLW總公司");
			
			if(this.list2.get("HOLA")!=null && user.getUserRead()==2)
				this.list2.get("HOLA").put("99998", "99998-轉入作業-HOLA總公司");
			
			
			if(isoption){
				BsChannel b = new BsChannel();
				b.setChannelId(" ");
				b.setChannelName1("請選擇-");
				channelList.add(b);
				TreeMap map = new TreeMap();
				map.put(" ","-請選擇-");
				this.list2.put(" ", map);
			}
			for (String key : this.list2.keySet()) {
				Map map = (Map)this.list2.get(key);
				if(map.size()==2){
					map.remove(" ");
				}
			}
			channelList.addAll(result);
		}catch(Exception e){
			supportDeptList = new ArrayList();
			BsChannel bschannel = new BsChannel();
			bschannel.setChannelId("");
			bschannel.setChannelName1("無資訊");
			supportDeptList.add(bschannel);
			e.printStackTrace();
		}
		return channelList;
	}
	
	
	
	/** 非維修頁面處理店點
	 * @return
	 */
	public List getSupportDeptList() {
		List supportDeptList = null;
		ScSysuser user = (ScSysuser)this.getSessionMap().get("user");
		try {
			Date sysDate = DateTimeUtils.getFormatSysDate();
			if(user.getLoginTime().after(sysDate)) {
				supportDeptList = user.getSupportDeptList();
			} else {
				ShopValidator validate = (ShopValidator)AppContext.getBean("ShopValidator");
				List dataList = validate.getIsValidShop(user);
				List supportList = (List)dataList.get(0);
				List hqSupportList = (List)dataList.get(1);
				boolean showPcBtn = (Boolean)dataList.get(2);
				supportDeptList = supportList;
				user.setSupportDeptList(supportDeptList);
				user.setHqSupportDeptList(hqSupportList);
				user.setShowPcBtn(showPcBtn);
				this.getSessionMap().put("user", user);
			}
		} catch (Throwable e) {
			supportDeptList = new ArrayList();
			BsDept bsDept = new BsDept();
			bsDept.setDeptId("");
			bsDept.setDeptName("無資訊");
			supportDeptList.add(bsDept);
			e.printStackTrace();
		}
		return supportDeptList;
	}
	
	/** 競爭者清單
	 * @return
	 */
	public List getCompetitorList() {
		BsDept bean = (BsDept)this.getMaintainSupportDeptList().get(0);
		List competitorList = null;
		if(bean.getDeptId().equals("")) {
			competitorList = new ArrayList();
			CompetitorVO vo = new CompetitorVO();
			vo.setCompetitorId("");
			vo.setCompetitorName("無資訊");
			competitorList.add(vo);
		} else {
			competitorList = CompetitorDefinition.getCompetitorListByStoreNo(bean.getDeptId());
			if(competitorList == null) {
				competitorList = new ArrayList();
				CompetitorVO vo = new CompetitorVO();
				vo.setCompetitorId("");
				vo.setCompetitorName("無資訊");
				competitorList.add(vo);
			}
		}
		return competitorList;
	}
	
	/** 競爭者分店清單
	 * @return
	 */
	public List getCompetitorBranchList() {
		CompetitorVO vo = (CompetitorVO)this.getCompetitorList().get(0);
		
		if(!vo.getCompetitorBranchVOList().isEmpty()) {
			return vo.getCompetitorBranchVOList();
		} else {
			List competitorBranchList = new ArrayList();
			CompetitorBranchVO bvo = new CompetitorBranchVO();
			bvo.setCompetitorBranchId("");
			bvo.setCompetitorBranchName("無資訊");
			competitorBranchList.add(bvo);
			return competitorBranchList;
		}
	}
	
}
