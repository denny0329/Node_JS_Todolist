package com.bnq.util;

public class WebServiceUtils 
{
	private final static String PROPERTY_FILE = "webService.properties";
	
	public static String getServiceURL(String serviceName) {
		return PropertyConfigUtils.getProperty(PROPERTY_FILE, "SERVER_URL") + 
			PropertyConfigUtils.getProperty(PROPERTY_FILE, serviceName);
	}
	
	public static String getProperty(String key) {
		return PropertyConfigUtils.getProperty(PROPERTY_FILE, key);
	}
	
	
	public static String[] getPropertyArray(String key) {
		return PropertyConfigUtils.getPropertyArray(PROPERTY_FILE, key);
	}
	
}
