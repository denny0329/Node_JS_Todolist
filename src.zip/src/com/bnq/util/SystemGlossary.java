package com.bnq.util;

/** 系統參數
 * @author Administrator
 *
 */
public class SystemGlossary {
	public static final String _sys_customer_service = "CS";
	
	public static final String _mod_customer_comment = "CC";
	public static final String _mod_price_promise = "PC";
	public static final String _mod_product_service = "PM";
	
	public static final String _BsArea = "BAR";
	public static final String _BsAuth = "BAU";
	public static final String _BsCategory = "BC";
	public static final String _BsCategoryMail = "BCM";
	public static final String _BsClassify = "BCL";
	public static final String _BsCode = "BCD";
	public static final String _BsDept = "BD";
	public static final String _BsException = "BE";
	public static final String _BsTitle = "BT";
	public static final String _BsVariable = "BV";
	public static final String _Competitor = "CP";
	public static final String _ScForm = "SF";
	public static final String _ScModule = "SM";
	public static final String _ScPosIp = "SP";
	public static final String _ScSubsystem = "SS";
	public static final String _BsStoreSystemInfo = "SSI";
	
}
