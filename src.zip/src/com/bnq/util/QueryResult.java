package com.bnq.util;

import java.io.Serializable;
import java.util.List;

/**
 * <b>查詢結果物件</b>
 * @author kaychen
 * @Date: 2009/4/5 下午 11:14:05
 * @Project Name: bnq
 * @Package Name: com.bnq.cs.comment.util
 * @File Name: QueryResult.java
 */
public class QueryResult implements Serializable {
	private static final long serialVersionUID = -7181431532579891868L;

	private Integer count ;
	private List result ;
	
	public QueryResult() {
		
	}
	
	public QueryResult(Integer count ,List result) {
		this.count = count ;
		this.result = result ;
	}
	
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public List getResult() {
		return result;
	}
	public void setResult(List result) {
		this.result = result;
	}
	
}
