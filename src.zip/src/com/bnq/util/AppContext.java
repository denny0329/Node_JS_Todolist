package com.bnq.util;

import java.io.Serializable;

import javax.servlet.ServletContext;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.context.ContextLoader;

/**
 * Spring工具程式，用來取得Spring環境中的Bean物件。Singleton物件。
 *
 */
public final class AppContext implements Serializable {
	private static final long serialVersionUID = 4363718991758510117L;

	private static final Logger log = LogManager.getLogger(AppContext.class) ;
	private final static AppContext instance = new AppContext();
	private ApplicationContext appContext;
	private ServletContext servletContext;
	public static String contextPath ;
	
	/**
	 * private建構子，不允許自創建本類別物件實例
	 */
	private AppContext() {
		
	}

	public ServletContext getServletContext() {
		return servletContext;
	}

	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}

	public synchronized static AppContext getInstance() {
		return instance;
	}

	/**
	 * 取得本工具類別物件實例
	 * @return 工具類別物件實例
	 */
	public static ApplicationContext getAppContext() {
		if(getInstance().appContext == null) {
			getInstance().loadAppContext();
		}
		return getInstance().appContext;
	}

	/**
	 * 載入Spring環境設定
	 */
	private void loadAppContext() {
		getInstance().appContext = ContextLoader.getCurrentWebApplicationContext();
		if(appContext == null) {
			String[] path = {"classpath:applicationContext*.xml"};
			getInstance().appContext = new ClassPathXmlApplicationContext(path);
		}
		log.debug(">>>>>>>>>>> [AppContext] appContext: "+getInstance().appContext);
	}

	/**
	 * 依指定bean名稱，自Spring環境中取得該bean的物件實例
	 * @param name Spring設定檔中所定義的bean名稱
	 * @return 該bean名稱所對應的物件實例
	 */
	public static Object getBean(String name) {
		return getAppContext().getBean(name);
	}
}
