/**
 * @(#)LoginAction.java 2013/11/20
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.bnq.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import org.keycloak.KeycloakSecurityContext;
import org.keycloak.adapters.KeycloakDeployment;
import org.keycloak.adapters.RefreshableKeycloakSecurityContext;
import org.keycloak.adapters.ServerRequest;
import org.keycloak.representations.AccessToken;

import com.bnq.base.action.BaseAction;
import com.bnq.sc.service.ScSysuserService;
import com.bnq.util.menu.JsMenuPreparator;
import com.gccs.bs.dao.hibernate.BsManagerDao;
import com.gccs.bs.model.BsChannel;
import com.gccs.bs.model.BsCompany;
import com.gccs.bs.model.BsStaff;
import com.gccs.bs.model.BsStore;
import com.gccs.bs.model.vo.BsChannelAutVo;
import com.gccs.bs.service.BsManagerService;
import com.gccs.bs.service.IBsChannelAuthorityService;
import com.gccs.util.cache.BsCompanyDefinition;
import com.gccs.util.cache.BsStoreDefinition;
import com.opensymphony.xwork2.ActionContext;
import com.sdk.privilege.model.ScButton;
import com.sdk.privilege.service.UserPrivilegeService;

/**
 * 登入/登出頁面功能對應之Struts Action類別
 */
@SuppressWarnings("deprecation")
public class LoginAction extends BaseAction{
	private static final long serialVersionUID = 7332667950361182589L;

	private static final Logger log = LogManager.getLogger(LoginAction.class);

	private static final String APP_PROPERTY_FILE = "application.properties";

	private static PropertiesConfiguration pCfg = null;

	private static final String SESSION_USER = "user";
	/**於SESSION內存入使用者可以操作的表單資料*/
	public static final String SESSION_MENU = "menu";

	private static final String REQ_URI = "reqURI";

	private static final String ENABLE_AD_AUTH = "ENABLE_AD_AUTH";
	private static final String KEYCLOAK_AUTH_FAIL = "Session 逾時. 請登出後再登入.";
	private static final String AD_AUTH_FAIL = "AD_AUTH_FAIL";
	private static final String ACCOUNT_DISABLED = "ACCOUNT_DISABLED";
	private static final String ACCOUNT_NOT_EXIST = "ACCOUNT_NOT_EXIST";
	private static final String ACCOUNT_EXPIRED = "ACCOUNT_EXPIRED";

	private ScSysuserService scSysuserService;
	private ShopValidator shopValidator;
	private IBsChannelAuthorityService bsChannelAuthorityService;
	private JsMenuPreparator jsMenuPreparator;
	private BsManagerService bsManagerService;
	private UserPrivilegeService userPrivilegeService;
	private BsManagerDao bsManagerDao;

	/** 使用者帳號 */
	private String userId;
	/** 使用者密碼 */
	private String password;
	/** 使用者登入店別通路 */
	private String channelId;
	/** 使用者登入店別 */
	private String storeId;
	/** 網址識別碼 */
	private String urlIdCode;

	/**
	 * 取得使用者帳號
	 * @return 使用者帳號
	 */
	public String getUserId() {
		return userId != null ? userId.trim() : null;
	}

	/**
	 * 設定使用者帳號
	 * @param userId 使用者帳號
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * 取得使用者密碼
	 * @return 使用者密碼
	 */
	public String getPassword() {
		return password != null ? password.trim() : null;
	}

	/**
	 * 設定使用者密碼
	 * @param userId 使用者密碼
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * 取得使用者登入店別通路
	 * @return
	 */
	public String getChannelId() {
		return channelId;
	}

	/**
	 * 設定使用者登入店別通路
	 * @param channelId
	 */
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	/**
	 * 取得使用者登入店別
	 * @return
	 */
	public String getStoreId() {
		return storeId;
	}

	/**
	 * 設定使用者登入店別
	 * @param storeId
	 */
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	/**
	 * 網址識別碼
	 * @return
	 */
	public String getUrlIdCode() {
		return urlIdCode;
	}

	/**
	 * 網址識別碼
	 * @param urlIdCode
	 */
	public void setUrlIdCode(String urlIdCode) {
		this.urlIdCode = urlIdCode;
	}

	public ScSysuserService getScSysuserService() {
		return scSysuserService;
	}

	public void setScSysuserService(ScSysuserService scSysuserService) {
		this.scSysuserService = scSysuserService;
	}

	public ShopValidator getShopValidator() {
		return shopValidator;
	}

	public void setShopValidator(ShopValidator shopValidator) {
		this.shopValidator = shopValidator;
	}

	public IBsChannelAuthorityService getBsChannelAuthorityService() {
		return bsChannelAuthorityService;
	}

	public void setBsChannelAuthorityService(
			IBsChannelAuthorityService bsChannelAuthorityService) {
		this.bsChannelAuthorityService = bsChannelAuthorityService;
	}

	public JsMenuPreparator getJsMenuPreparator() {
		return jsMenuPreparator;
	}

	public void setJsMenuPreparator(JsMenuPreparator jsMenuPreparator) {
		this.jsMenuPreparator = jsMenuPreparator;
	}

	public BsManagerService getBsManagerService() {
		return bsManagerService;
	}

	public void setBsManagerService(BsManagerService bsManagerService) {
		this.bsManagerService = bsManagerService;
	}

	public UserPrivilegeService getUserPrivilegeService() {
		return userPrivilegeService;
	}

	public void setUserPrivilegeService(
			UserPrivilegeService userPrivilegeService) {
		this.userPrivilegeService = userPrivilegeService;
	}
	/**
	 * 設定。
	 * @param bsManagerDao
	 */
	public void setBsManagerDao(BsManagerDao bsManagerDao) {
		this.bsManagerDao = bsManagerDao;
	}

	/**
	 * 建構子
	 */
	public LoginAction() {
		init();
	}

	/**
	 * 初始化參數設定
	 */
	private void init() {
		if (pCfg == null) {
			try {
				pCfg = new PropertiesConfiguration(APP_PROPERTY_FILE);
				pCfg.setReloadingStrategy(new FileChangedReloadingStrategy());
			} catch (Exception e) {
				log.error("無法取得初始化參數。", e);
			}
		}
	}

	/**
	 * 讀取AD認證設定
	 * @return true(AD認證開啟) / false(AD認證關閉)
	 */
	private final boolean isADAuthEnabled() {
		boolean adAuthEnabled = true;
		try {
			adAuthEnabled = pCfg.getBoolean(ENABLE_AD_AUTH, true);
		} catch (Exception e) {
			log.error("無法讀取AD認證設定。", e);
		}
		return adAuthEnabled;
	}

	// osmcrm: task/ui_angular.24
	// Logout
	public RefreshableKeycloakSecurityContext GetKeycloakSecurityContext () {
		String k = KeycloakSecurityContext.class.getName();				
		HttpServletRequest request = (HttpServletRequest) ServletActionContext.getRequest();
		
		RefreshableKeycloakSecurityContext rksc = new RefreshableKeycloakSecurityContext();
		if (request != null && request.getAttribute(k) != null)									// Get Attribute from request
			rksc = (RefreshableKeycloakSecurityContext) request.getAttribute(k);					
		else {	
			HttpSession session = request.getSession();		
			if (session != null && session.getAttribute(k) != null)								// Sometime the request is in session and not in request	
				rksc = (RefreshableKeycloakSecurityContext) session.getAttribute(k);	
		}
		
		if (rksc.getRefreshToken() != null)
			log.info("LoginAction >> GetKeycloakSecurityContext: Successful");
		else
			log.warn("LoginAction >> GetKeycloakSecurityContext: Unable to obtain Keycloak Security Context");
		
		return rksc;
	}
	
	public AccessToken GetToken() {
		AccessToken token = new AccessToken();
		RefreshableKeycloakSecurityContext ksc = GetKeycloakSecurityContext();
		if (ksc != null) {
			token = ksc.getToken();
			log.info("LoginAction >> GetToken: Successful");
		} else
			log.warn("LoginAction >> GetToken: Unable to obtian Keycloak Token");
		
		return token;
	}
 	
	/**
	 * 進行登入檢查
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String execute() {
		String rtv = LOGIN;
		
		AccessToken token = GetToken();
		if (token != null)
			userId = token.getPreferredUsername().toUpperCase();
		// Read urlIdCode before session is reset
		String url_id_code = "url_id_code";
		if (urlIdCode == null || urlIdCode.length() == 0) 
			urlIdCode = (String) getSessionMap().get(url_id_code);
		// end
		
		// 保留REQ_URI
		String reqURI = (String) getSessionMap().get(REQ_URI);

		RefreshableKeycloakSecurityContext ksc = GetKeycloakSecurityContext();

		// 先清空Session，再進行登入
		getSessionMap().clear();

		// session 塞token
		HttpServletRequest request = (HttpServletRequest) ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		session.setAttribute("KCToken", ksc);
		// 版本控制(時間)
		session.setAttribute("versions", System.currentTimeMillis());
		// osmcrm: task/ui_angular.24
		// Add urlIdCode back after session has been reset
		// Used by body.jsp to load the correct page
		if (urlIdCode != null && urlIdCode.length() > 0)
			getSessionMap().put(url_id_code, urlIdCode);
		// end
		
		if (reqURI != null) {
			getSessionMap().put(REQ_URI, reqURI);
		}		


		// Added logic to check for token
//		if (password == null || password.length() == 0) {
//			if (userId == null || userId.length() == 0) {
//				addActionError(getText(KEYCLOAK_AUTH_FAIL));
//				return rtv;
//			}
//		} else {
//			// AD檢查! 如果檢查失敗, 顯示 "使用者名稱或密碼錯誤!"，並返回登入頁
//			if (isADAuthEnabled() && !ADAuth.checkAuth(userId, password)) {
//				addActionError(getText(AD_AUTH_FAIL));
//				return rtv;
//			}			
//		}
		// end

		
		// 登入頁面的公司別
		
		if (urlIdCode == null)
			urlIdCode = (String) getSessionMap().get(REQ_URI);
		BsCompany bsCompany = BsCompanyDefinition.getBsCompanyByCode(urlIdCode);

		// 依登入之店別反查通路
		if (StringUtils.isNotBlank(storeId) && StringUtils.isBlank(channelId)) {
			BsStore bsStore = BsStoreDefinition.getIncludeHQ(bsCompany.getCompanyId(), storeId);
			if (bsStore != null)
				channelId = bsStore.getId().getChannelId();
		}
		log.debug("channelId: " + channelId);

		if (bsCompany == null) {
			addActionError(getText("invalid parameter: url_id_code"));
			return rtv;
		} else 
			this.getSessionMap().put("urlIdCode", urlIdCode);  	// osmcrm: task/ui_angular, Store urlIdCode 
		
		// AD pass, check帳戶是否停用
		// If 帳戶停用, show error "您的帳戶已被停用!", 拒絕進入首頁!
		com.bnq.sc.model.ScSysuser scSysuser = scSysuserService.find(userId.trim().toUpperCase(), bsCompany.getCompanyId());
		if (scSysuser != null) {
			if (scSysuser.getUserStatus() != null && scSysuser.getUserStatus().longValue() == 1) {
				// 登入頁面的公司別須符合登入帳號的公司別
				if (scSysuser.getCompanyId().equals(bsCompany.getCompanyId())) {
					// 正常
					List dataList = new ArrayList();
					try{
						dataList = shopValidator.getIsValidShop(scSysuser);
					}catch (RuntimeException e) {
						log.error(scSysuser.getUserId() + " 帳號已過期，請洽系統服務人員。", e);
						addActionError(e.getMessage());
						return rtv;
					}catch (Exception e) {
						log.error(scSysuser.getUserId() + " 帳號已過期，請洽系統服務人員。", e);
						addActionError(getText(ACCOUNT_EXPIRED));
						return rtv;
					}

					this.getSessionMap().put(BsCompanyDefinition.SESSION_BS_COMPANY_ID, bsCompany.getCompanyId());

					List supportList = (List) dataList.get(0);
					log.info("user:" + scSysuser.getUserId() + ",supportList isEmpty: " + supportList.isEmpty());
					
					if(scSysuser.getUserRead() != 2){
						if("".equals(storeId) || "".equals(channelId)){
							addActionError(getText("請選擇通路店別!"));
							return rtv;
						}
						//竹君說:門店人員只要判斷是否有該門店權限就行，無須管是否有沒有設定職務
						List bsStaffList = bsManagerDao.findBsStaffForUser( scSysuser.getCompanyId(), userId, channelId, storeId);
						boolean isHasStore = false;
						for(Object bsStaff :bsStaffList){
							if(storeId.equals(((BsStaff)bsStaff).getStoreId())){
								isHasStore = true;
							}
						}
						if(!isHasStore){
							addActionError(getText("沒有此門店權限!"));
							return rtv;
						}
					}
					//end
					List hqSupportList = (List) dataList.get(1);
					boolean showPcBtn = (Boolean) dataList.get(2);
					scSysuser.setSupportDeptList(supportList);
					scSysuser.setHqSupportDeptList(hqSupportList);
					scSysuser.setLoginTime(new java.util.Date());
					scSysuser.setShowPcBtn(showPcBtn);
					scSysuser.setPassword(password);
					scSysuser.setLoginChannelId(channelId);
					scSysuser.setLoginStoreId(storeId);
					scSysuser.getstores();
					BsStore bsStore = BsStoreDefinition.getBsStoreByStoreNo(storeId, scSysuser.getCompanyId());
					if(bsStore != null)
						scSysuser.setLoginStoreChannel(bsStore.getId().getChannelId());

					// 通路權限
					log.info("login with user : " + scSysuser.getUserId());
					BsChannelAutVo vo = bsChannelAuthorityService.findEffectiveAuthorizedChannelByUserId(scSysuser.getCompanyId(), scSysuser.getUserId());
					if (vo != null) {
						List<BsChannel> authBsChannel = vo.getChannels();
						scSysuser.setAuthChannel(authBsChannel);
						log.info("user.getAuthChannel().size() : " + scSysuser.getAuthChannel().size());
					}

					// 準備功能清單
					String jsMenu = null;
					try {
						jsMenu = jsMenuPreparator.prepare(scSysuser.getCompanyId(), scSysuser.getUserId(), getContextPath());
						this.getSessionMap().put(SESSION_MENU, jsMenu);
					} catch (Exception e) {
						log.error(scSysuser.getUserId() + " 無法取得功能清單。", e);
					}
					
					if(CollectionUtils.isEmpty(jsMenuPreparator.getGroupList()) || CollectionUtils.isEmpty(jsMenuPreparator.getFromList())) {
						if(CollectionUtils.isEmpty(jsMenuPreparator.getGroupList())) {
							this.addActionError("未設定職稱-群組關係，請洽系統管理員");
						} else {
							this.addActionError("未設定群組-功能關係，請洽系統管理員");
						}
						return rtv;
					}
					// 準備button使用權限
					Map<String, List<ScButton>> buttonMap = getUserPrivilegeService().getAllButton(jsMenuPreparator.getGroupList(), jsMenuPreparator.getFromList());
					if (buttonMap != null) {
						scSysuser.setFormButtonMap(buttonMap);
					}

					// SESSION
					this.getSessionMap().put(SESSION_USER, scSysuser);
					rtv = SUCCESS;
				} else {
					addActionError(getText(ACCOUNT_NOT_EXIST));// 此帳戶不存在
				}
			} else {
				addActionError(getText(ACCOUNT_DISABLED));// 此帳戶已被停用
			}
		} else {
			addActionError(getText(ACCOUNT_NOT_EXIST));// 此帳戶不存在
		}

		return rtv;
	}

	/**
	 * 系統登出
	 * @return Struts導頁設定，導至登入頁面
	 */
	
	public boolean LogoutToken() {

		String userId = "";
		RefreshableKeycloakSecurityContext rksc = GetKeycloakSecurityContext();
		
		if (rksc != null)	
		try {
			userId = rksc.getToken().getPreferredUsername();		
			KeycloakDeployment deployment = rksc.getDeployment();
			String rToken = rksc.getRefreshToken();		
        	ServerRequest.invokeLogout(deployment, rToken);    	
        	
        	log.info("LoginAction >> LogoutToken: Logout User=[" + userId + "] Sucessful ");
        } catch (Exception e) {
            log.warn("LoginAction >> LogoutToken: Logout User=[" + userId + "] Failed ");
            return false;
        }
				
		return true;
	}
	
	public String logout() {

		LogoutToken();
		// omscrm logout
		this.getSessionMap().clear();
		ServletActionContext.getRequest().getSession().invalidate();
		return LOGIN;
	}

}