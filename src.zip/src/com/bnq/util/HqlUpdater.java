package com.bnq.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.HibernateTemplate;

import com.gccs.member.model.MmCommission;
import com.gccs.ws.service.BaseWebService;

public class HqlUpdater 
{
	public static void main(String[] args) {
		MmCommission vo = new MmCommission();
		vo.setOid("123");
		vo.setActivityId("abc");		
		
		HqlUpdater hql = new HqlUpdater(vo);
		System.out.println(hql.getHql());
	}	    
	
	private static final Object[] types;	
	private String className;
	private Object vo;	
	private String pk;	
	private String hql;
	private Object[] params;
	
	static {
		types = new Object[]{
		    new java.lang.String(),
		    new java.lang.Integer(0),
		    new java.util.Date()		    
		};
	}
		
	public String getHql() {
		return hql;
	}
	public Object[] getParams() {
		return params;
	}
	
	public HqlUpdater(String className, Object vo, String pk) {
		this.className = className;
		this.vo = vo;
    	this.pk = pk;  
    	
    	try {    		
    		if(vo instanceof Map) {    			
    			this.initForMap();
    		} else {    			
    			this.initForBean();
    		}
    	} catch (Throwable t) {
			throw new RuntimeException(t);
		}
	}	
	public HqlUpdater(String className, Object vo) {		    	
	    this(className, vo, "oid");		
	}	
    public HqlUpdater(Object vo, String pk) {		
    	this(vo.getClass().getSimpleName(), vo, pk);	
	}	
    public HqlUpdater(Object vo) {		    	
    	this(vo.getClass().getSimpleName(), vo, "oid");		
	}  
    		
	
	private void initForBean() throws Exception {		
		StringBuilder sb = new StringBuilder();
		List<Object> list = new ArrayList<Object>();		
		
		Class clazz = this.vo.getClass();
		Class fieldType = null;
		String fieldName = null;
		Object fieldValue = null;
		
		Field[] fields = clazz.getDeclaredFields();
		Object pkVal = null;
		boolean isFirst = true;
		
		sb.append(" update from ").append(this.className);		
		for(Field field : fields) {
			field.setAccessible(true);
			fieldType = field.getType();
			fieldName = field.getName();
			fieldValue = field.get(vo);
						
			if(fieldName.equals(this.pk)) {				
				if(BaseWebService.isEmpty(fieldValue)) {
					throw new RuntimeException(this.pk + " is empty");
				}
				pkVal = fieldValue;
			} else {
				if(fieldValue!=null && checkFieldType(fieldType)) {
					if(isFirst) {
						sb.append(" set ").append(fieldName).append("=?");
						isFirst = false;
					} else {
						sb.append(",").append(fieldName).append("=?");							
					}
					list.add(fieldValue);
				}
			}						
		}		
		sb.append(" where ").append(this.pk).append("=?");
		list.add(pkVal);	
		
		this.hql = sb.toString();
		this.params = list.toArray();	
	}
	
    private void initForMap() {
    	StringBuilder sb = new StringBuilder();
		List<Object> list = new ArrayList<Object>();	
		
    	Map map = (Map)this.vo;
    	String fieldName = null;
		Object fieldValue = null;
		
    	Object pkVal = null;
		boolean isFirst = true;
		
    	Set<String> set = map.keySet();
    	
    	sb.append(" update from ").append(this.className);
		for(String key : set) {
			fieldName = key;
			fieldValue = map.get(key);
			
			if(fieldName.equals(this.pk)) {				
				if(BaseWebService.isEmpty(fieldValue)) {
					throw new RuntimeException(this.pk + " is empty");
				}
				pkVal = fieldValue;
			} else {				
				if(isFirst) {
					sb.append(" set ").append(fieldName).append("=?");
					isFirst = false;
				} else {
					sb.append(",").append(fieldName).append("=?");							
				}
				list.add(fieldValue);				
			}
		}		
		sb.append(" where ").append(this.pk).append("=?");
		list.add(pkVal);
		
		this.hql = sb.toString();
		this.params = list.toArray();
	}
	
	public int executeUpdate(HibernateTemplate hibernateTemplate) {
		final String hql = this.hql;
		final Object[] params = this.params;
		
		return (Integer)hibernateTemplate.execute(
		    new HibernateCallback() {
		        public Object doInHibernate(Session session) {		     			        			        			        			    		  	        			        				        			        		        				        			        		
		        	Query query = session.createQuery(hql);
		        	for(int i=0; i<params.length; i++) {
        				query.setParameter(i, params[i]);
        			}	 		        	
		    		return query.executeUpdate();
		        }		        	
		    }
	    );	
	}
	
	private boolean checkFieldType(Class clazz) {		
		for(Object type : types) {
			if(clazz.isInstance(type)) return true;
		}
		return false;
	}

}
