package com.bnq.util;

import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.sql.Blob;
import java.sql.Clob;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Hibernate;

import com.bnq.cs.cc.model.vo.CommentAttachVO;
import com.bnq.cs.cc.model.vo.ProcessRecordVO;
import com.bnq.cs.pm.model.ProductServiceRecord;
import com.bnq.cs.ps.model.FileVo;
import com.bnq.cs.ps.model.PsSetupFurnVo;
import com.bnq.cs.ps.model.PsSetupLog;
import com.bnq.util.file.model.AttchFileInfo;
import com.bnq.util.serial.SerialService;
import com.gccs.member.action.MemberBusinessAccountAction;

public class FileTools {
	private static final Logger log = LogManager.getLogger(FileTools.class) ;
	
	public static AttchFileInfo convertToAttchFileForCommentAttach(CommentAttachVO vo) throws Exception {
		AttchFileInfo info = new AttchFileInfo() ;
		info.setCreateDate(new Date()) ;
		info.setFileName(vo.getAttachFileName()) ;
		File file = vo.getAttach();
		info.setLength(file.length()) ;
		
		String codeNo = "CC09_" + vo.getDocType();
		info.setFileFolderType(codeNo);
		String filePath = convertFile(codeNo, new Date(), vo.getAttachFileName(), vo.getSeqNo(), file);
		info.setFilePath(filePath);
		
		return info ;
	}
	
	public static AttchFileInfo convertToAttchFileForProcessRecord(ProcessRecordVO vo) throws Exception {
		AttchFileInfo info = new AttchFileInfo() ;
		info.setCreateDate(new Date()) ;
		info.setFileName(vo.getAttachFileName()) ;
		File file = vo.getAttach();
		info.setLength(file.length()) ;
		
		String codeNo = "CC05_" + vo.getProcessCodeNo();
		info.setFileFolderType(codeNo);
		String filePath = convertFile(codeNo, new Date(), vo.getAttachFileName(), vo.getSeqNo(), file);
		info.setFilePath(filePath);
		
		return info ;
	}
	
	public static AttchFileInfo convertToAttchFileForProductServiceRecord(ProductServiceRecord vo) throws Exception {
		AttchFileInfo info = new AttchFileInfo() ;
		info.setCreateDate(new Date()) ;
		info.setFileName(vo.getAttachFileName()) ;
		File file = vo.getAttach();
		info.setLength(file.length()) ;
		String seqNo = SerialService.getSerial("CC");
		String codeNo = "CC13_" + vo.getProcessTypeNo();
		info.setFileFolderType(codeNo);
		info.setReference_key(vo.getOid());
		info.setReference_type("3");
		String filePath = convertFile(codeNo, new Date(), vo.getAttachFileName(), seqNo, file);
		info.setFilePath(filePath);
		
		return info ;
	}
	
	public static AttchFileInfo convertToAttchFileForPsSetUpLogRecord(PsSetupLog vo) throws Exception {
		AttchFileInfo info = new AttchFileInfo() ;
		info.setCreateDate(new Date()) ;
		info.setFileName(vo.getAttachFileName()) ;
		File file = vo.getAttach();
		info.setLength(file.length()) ;
		String seqNo = SerialService.getSerial("CC");
		String codeNo = "CC14_" + vo.getProcessTypeNo();
		info.setFileFolderType(codeNo);
		info.setReference_key(vo.getOid());
		info.setReference_type("4");
		String filePath = convertFile(codeNo, new Date(), vo.getAttachFileName(), seqNo, file);
		info.setFilePath(filePath);
		
		return info ;
	}

	public static AttchFileInfo convertToAttchFileForFurnitureRepair(FileVo fileVo, PsSetupFurnVo vo) throws Exception {
		AttchFileInfo info = new AttchFileInfo();
		info.setCreateDate(new Date());
		info.setFileName(fileVo.getAttachFileName());
		File file = fileVo.getAttach();
		info.setLength(file.length());
		String seqNo = SerialService.getSerial("CC");
		String codeNo = "CC110205";
		info.setFileFolderType(codeNo);
		info.setReference_key(vo.getOid());
		info.setReference_type("4");
		String filePath = convertFile(codeNo, new Date(), fileVo.getAttachFileName(), seqNo, file);
		info.setFilePath(filePath);

		return info;
	}
	
	private static String convertFile(String codeNo, Date createDate, String attchFileName, String seqNo, File file) throws Exception {
		String filePath = "";
		ResourceBundle bundle = ResourceBundle.getBundle("crmCommon");
		SimpleDateFormat df = new SimpleDateFormat("yyyy");
		
		String path = bundle.getString("CommentService.Path") + File.separator
		+ codeNo
		+ File.separator + df.format(createDate);

		File folder = new File(path);
		if(!folder.exists()){
			folder.mkdirs();
		}

		// 取得流水號
		String[] filesCount = folder.list();
		
		// 副檔名，db中有沒有副檔名的情況
		String extension = "";
		try {
			extension = attchFileName.substring(attchFileName.lastIndexOf("."), attchFileName.length());
		} catch (Exception e) {
			
		}
		
		// 新檔名
		String fileName = codeNo
			+ seqNo
			+ String.format("%03d", (filesCount.length + 1))
			+ extension;
		
		// 新檔
		File newfile = new File(path + File.separator + fileName);
		FileOutputStream out = new FileOutputStream(newfile);
		byte[] byteFile = File2Byte(file);
		// 產檔
		out.write(byteFile, 0, byteFile.length);
		out.flush();
		out.close();
		
		filePath = path + File.separator + fileName;
		
		return filePath;
	}
	
	public static Map<String, String> exchangeFileName(Date createDate, String attchFileName, int seqNo) throws Exception {
	    String filePath = "";
	    ResourceBundle bundle = ResourceBundle.getBundle("crmCommon");
	    SimpleDateFormat df = new SimpleDateFormat("yyyy");

	    String path = bundle.getString("CommentService.Path") + File.separator + df.format(createDate);

	    File folder = new File(path);
	    if (!folder.exists()) {
	        folder.mkdirs();
	    }

	    // 取得流水號
	    String[] filesCount = folder.list();

	    // 副檔名，db中有沒有副檔名的情況
	    String extension = "";
	    try {
	        extension = attchFileName.substring(attchFileName.lastIndexOf("."), attchFileName.length());
	    } catch (Exception e) {

	    }

	    // 新檔名
	    String fileName = "ACC_" +
	        String.valueOf(seqNo) +
	        String.format("%03d", (filesCount.length + 1)) +
	        extension;
	    filePath = path + File.separator + fileName;

	    Map<String, String> result = new HashMap<>();
	    result.put("path", path);
	    result.put("fileName", fileName);
	    result.put("filePath", filePath);
	    
	    return result;
	}

	public static void newFile(File file, String path, String fileName)
			throws FileNotFoundException, Exception, IOException {
		File newfile = new File(path + File.separator + fileName);
	    FileOutputStream out = new FileOutputStream(newfile);
	    byte[] byteFile = File2Byte(file);
	    // 產檔
	    out.write(byteFile, 0, byteFile.length);
	    out.flush();
	    out.close();
	}
	
    public static byte[] File2Byte(File file) throws Exception {
        InputStream is = new FileInputStream(file);
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        int length;
        byte[] buffer = new byte[1024];
        while ((length = is.read(buffer)) != -1) {
            bo.write(buffer, 0, length);
        }
        bo.close();
        is.close();
        return bo.toByteArray();
    }

    public static void Byte2File(byte[] content, File file) {
        try {
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(content);
            BufferedOutputStream bufOutputStream = new BufferedOutputStream(new FileOutputStream(file));
            byte[] tmp = new byte[1];
            while (byteArrayInputStream.read(tmp) != -1) {
                bufOutputStream.write(tmp);
            }
            byteArrayInputStream.close();
            bufOutputStream.flush();
            bufOutputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static byte[] Blob2Byte(Blob blob) throws Exception {
        byte[] out = null;
        InputStream in = blob.getBinaryStream();
        out = new byte[(int) blob.length()];
        in.read(out);
        in.close();
        return out;
    }

    public static void XML2File(File file, String strContent) {
        FileOutputStream fos = null;
        OutputStreamWriter outw = null;
        try {
            fos = new FileOutputStream(file);
            outw = new OutputStreamWriter(fos, "UTF-8");

            outw.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + strContent);
            outw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static String getExtendName(String fileName) {
        int index = fileName.lastIndexOf(".");
        if (index != -1) {
            return fileName.substring(index + 1);
        }
        return "";
    }

	public static Clob createClob(String data) {
		return Hibernate.createClob(data) ;
	}
	
	public static int getStartRowIndex(int page,int rows) {
		return ((page - 1) * rows ) ; 
	}

	public static String download(String url, String filepath) {
		try {
			log.info("download EC下載開始");
			SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
				public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
					return true;
				}
			}).build();
			SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, new String[] { "TLSv1.2" }, null,
					NoopHostnameVerifier.INSTANCE);
			HttpClient client = new DefaultHttpClient();
			client = HttpClients.custom().setSSLSocketFactory(sslsf).build();
			HttpGet httpget = new HttpGet(url);
			HttpResponse response = client.execute(httpget);

			HttpEntity entity = response.getEntity();
			InputStream is = entity.getContent();
			
			File file = new File(filepath);
			file.getParentFile().mkdirs();
			FileOutputStream fileout = new FileOutputStream(file);
			/**
			 * 根據實際執行效果 設定緩衝區大小
			 */
			byte[] buffer=new byte[1024];
			int ch = 0;
			while ((ch = is.read(buffer)) != -1) {
				fileout.write(buffer,0,ch);
			}
			is.close();
			fileout.flush();
			fileout.close();

			log.info("download EC下載完成");
		} catch (Exception e) {
			log.info("download EC照片失敗");
			log.error(e.getMessage(), e);
		}
		return null;
	}
}
