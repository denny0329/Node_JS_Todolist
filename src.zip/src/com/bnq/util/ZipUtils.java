package com.bnq.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Enumeration;

import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipFile;
import org.apache.tools.zip.ZipOutputStream;

public class ZipUtils {
	private final static int BUFFER_SIZE = 1024;
	
	/**
	 * 壓縮指定路徑下的檔案
	 * @param zipFilePath 產生的壓縮檔路徑及檔名(Path)
	 * @param srcPath 來源路徑
	 * @throws Exception
	 */
	public static void zip(String zipFilePath, String srcPath) throws Exception {
		if(srcPath == null || srcPath.trim().length() == 0 || srcPath.equals(".")) {
			srcPath = System.getProperty("user.dir");
		}
		//System.out.println("srcPath: "+srcPath);			  
		FileOutputStream fos = new FileOutputStream(zipFilePath);
		ZipOutputStream zos = new ZipOutputStream(fos); 
		String rootSrcPath = srcPath; 
		zipDir(rootSrcPath, srcPath, zos);
		zos.flush();
		zos.close();
		fos.close(); 
	}
	
	/**
	 * 壓縮檔案
	 * @param zipFilePath 產生的壓縮檔路徑及檔名(Path)
	 * @param srcFile 來源檔案
	 * @throws Exception
	 */
	public static void zipFile(String zipFilePath, File srcFile) throws Exception {
		byte[] readBuffer = new byte[BUFFER_SIZE];
		int bytesIn = 0;
		//System.out.println(">>>" + srcFilePath);
		FileInputStream fis = new FileInputStream(srcFile);
		FileOutputStream fos = new FileOutputStream(zipFilePath);
		ZipOutputStream zos = new ZipOutputStream(fos);
		//System.out.println(srcFile.getName());
		ZipEntry anEntry = new ZipEntry(srcFile.getName());
		zos.putNextEntry(anEntry);
		while ((bytesIn = fis.read(readBuffer)) != -1) {
			zos.write(readBuffer, 0, bytesIn);
		}
		fis.close();
		zos.closeEntry();
		zos.flush();
		zos.close();
		fos.close();
	}
	
	/**
	 * 壓縮指定目錄下的檔案(Recursively)
	 * @param rootSrcPath 產生的壓縮檔路徑及檔名(Path)
	 * @param srcFilePath 來源路徑
	 * @param zos	Zip輸出流
	 * @throws Exception
	 */
	private static void zipDir(String rootSrcPath, String srcFilePath, ZipOutputStream zos) throws Exception {
    	File zipDir = new File(srcFilePath);
		String[] dirList = zipDir.list();
		byte[] readBuffer = new byte[BUFFER_SIZE];
		int bytesIn = 0;
		//System.out.println(">>>" + srcFilePath);
		for (int i = 0; i < dirList.length; i++) {
			File f = new File(zipDir, dirList[i]);
			if (f.isDirectory()) {
				String filePath = f.getPath();
				zipDir(rootSrcPath, filePath, zos);
				continue;
			}
			FileInputStream fis = new FileInputStream(f);
			String entryPath = f.getPath().substring(rootSrcPath.length());
			if (entryPath.indexOf("/") == 0 || entryPath.indexOf("\\") == 0) {
				entryPath = entryPath.substring(1);
			}
			//System.out.println(entryPath);
			ZipEntry anEntry = new ZipEntry(entryPath);
			zos.putNextEntry(anEntry);
			while ((bytesIn = fis.read(readBuffer)) != -1) {
				zos.write(readBuffer, 0, bytesIn);
			}
			fis.close();
			zos.closeEntry();
		}				
	}

	/**
	 * 解壓Zip檔到指定路徑下
	 * @param zipFilePath 壓縮檔路徑及檔名(String Path)
	 * @param destPath	目的路徑
	 * @throws Exception
	 */
	public static void unzip(String zipFilePath, String destPath) throws Exception {
		unzip(new File(zipFilePath), destPath);
	}
	
	/**
	 * 解壓Zip檔到指定路徑下
	 * @param srcZipFile 壓縮Zip檔(File型態) 
	 * @param destPath	目的路徑
	 * @throws Exception
	 */
	public static void unzip(File srcZipFile, String destPath) throws Exception {
		ZipFile zipFile = new ZipFile(srcZipFile);
		unzip(zipFile, destPath);
	} 

	/**
	 * 解壓Zip檔到指定路徑下
	 * @param zipFile 壓縮Zip檔(ZipFile型態)
	 * @param destPath	目的路徑
	 * @throws Exception
	 */
	public static void unzip(ZipFile zipFile, String destPath) throws Exception {
		if (destPath.lastIndexOf("\\") != destPath.length()
				|| destPath.lastIndexOf("/") != destPath.length()) {
			destPath += "/";
		}
		Enumeration emu = zipFile.getEntries();
		while (emu.hasMoreElements()) {
			ZipEntry entry = (ZipEntry) emu.nextElement();
			if (entry.isDirectory()) {
				new File(destPath + entry.getName()).mkdirs();
				continue;
			}
			BufferedInputStream bis = new BufferedInputStream(zipFile
					.getInputStream(entry));
			File file = new File(destPath + entry.getName());
			File parent = file.getParentFile();
			if (parent != null && (!parent.exists())) {
				parent.mkdirs();
			}
			FileOutputStream fos = new FileOutputStream(file);
			BufferedOutputStream bos = new BufferedOutputStream(fos, BUFFER_SIZE);

			int count;
			byte[] buf = new byte[BUFFER_SIZE];
			while ((count = bis.read(buf)) != -1) {
				bos.write(buf, 0, count);
			}
			bos.flush();
			bos.close();
			bis.close();
		}
		zipFile.close();
	} 

}
