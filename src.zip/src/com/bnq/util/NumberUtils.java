/**
 * @(#)NumberUtils.java 2014/01/09
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.bnq.util;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Map;

public class NumberUtils {
	public static final BigDecimal ZERO_BIG_DECIMAL = new BigDecimal("0");
	private static final DecimalFormat decFmt_00 = new DecimalFormat("0.00");
	
	//BigDecimal add
	public static BigDecimal add(BigDecimal a, BigDecimal b) {
		if(a==null && b==null) return null;
		if(a==null){a = ZERO_BIG_DECIMAL;}
		if(b!=null){
			a = a.add(b);
		}
		return a;
	}
	//BigDecimal subtract
	public static BigDecimal subtract(BigDecimal a, BigDecimal b) {
		if(a==null && b==null) return null;
		if(a==null){a = ZERO_BIG_DECIMAL;}
		if(b!=null){
			a = a.subtract(b);
		}
		return a;
	}
	//BigDecimal multiply
	public static BigDecimal multiply(Number a, Number b) {
		if(a==null && b==null) return null;
		if(a==null || b==null){return ZERO_BIG_DECIMAL;}
		BigDecimal a1 = new BigDecimal(""+a);
		BigDecimal b1 = new BigDecimal(""+b);
		return a1.multiply(b1);
	}
	//BigDecimal divide
	public static BigDecimal divide(BigDecimal a, BigDecimal b) {
		if(a==null && b==null) return null;
		if(a==null){a = ZERO_BIG_DECIMAL;}
		if(b!=null && b.longValue()!=0){
			a = a.divide(b, BigDecimal.ROUND_UP);
		}
		return a;
	}
	
	public static String formatBigDecimal_00(Number val){
		if(val==null) return null;
		return decFmt_00.format(new BigDecimal(""+val).doubleValue());
	}
	
	public static BigDecimal safeBigDecimal(BigDecimal bd){
		if(bd==null) return ZERO_BIG_DECIMAL;
		return bd;
	}
	
	/**
	 * 安全轉換浮點數物件至 double 型態。
	 * @param d 任意浮點數
	 * @return 若來源為 null，傳回 0，其餘轉成 double。
	 */
	public static double safeDouble(Double d){
		if(d==null) return 0d;
		return d.doubleValue();
	}
	
	/**
	 * 將來源物件安全轉換為整數值。
	 * @param i 來源物件，目前可轉換類型：String、Integer、Double、BigDecimal
	 * @return 若有異常一率轉換為 0
	 */
	public static int safeInt(Object i) {
		if(i == null) return 0;

		if(i instanceof String) {
			String s = (String)i;
			if("".equals(s) || "null".equalsIgnoreCase(s)) return 0;
			try{
				return Integer.parseInt(s);
			}catch(Exception e){return 0;}
		} else if(i instanceof Integer) {
			return ((Integer)i).intValue();
		} else if(i instanceof Double) {
			return ((Double)i).intValue();
		} else if(i instanceof BigDecimal) {
			return ((BigDecimal)i).intValue();
		} else if (i instanceof Long) {
			return ((Long) i).intValue();
		} else {
			return 0;
		}
	}
	
	/**
	 * 將來源物件安全轉換為浮點數值。
	 * @param i 來源物件，目前可轉換類型：String、Integer、Double、BigDecimal
	 * @return 若有異常一率轉換為 0.0
	 */
	public static double safeDouble(Object i) {
		if(i == null) return 0d;
		
		if(i instanceof String) {
			String s = (String)i;
			if("".equals(s) || "null".equalsIgnoreCase(s)) return 0d;
			try{
				return Double.parseDouble(s);
			}catch(Exception e){return 0d;}
		} else if(i instanceof Integer) {
			return ((Integer)i).doubleValue();
		} else if(i instanceof Double) {
			return ((Double)i).doubleValue();
		} else if(i instanceof BigDecimal) {
			return ((BigDecimal)i).doubleValue();
		} else {
			return 0d;
		}
	}
	
	/**
	 * 將來源物件安全轉換為整數值。
	 * @param i
	 * @return 若有異常一率轉換為 0
	 */
	public static int safeInt(Integer i){
		return safeInt((Object)i);
	}
	
	/**
	 * 將來源物件安全轉換為整數值。
	 * @param i
	 * @return 若有異常一率轉換為 0
	 */
	public static int safeInt(String i){
		return safeInt((Object)i);
	}
	
	/**
	 * 將來源物件安全轉換為整數值。
	 * @param i
	 * @return 若有異常一率轉換為 0
	 */
	public static int safeInt(Double i){
		return safeInt((Object)i);
	}
	
	/**
	 * 四捨五入至個位數
	 * @param value
	 * @return
	 */
	public static double getRoundValue(Double value){
		return getRoundValue(value, 0);
	}
	
	/**
	 * 四捨五入至指定的小數位數
	 * @param value
	 * @param decimals 取值至小數點後幾位
	 * @return
	 */
	public static double getRoundValue(Double value, int decimals) {
		double result = safeDouble(value);
		double multiply = 1;
		for(int i=0;i<decimals;i++) {
			multiply = multiply * 10 ;
		}
		return Math.round(result * multiply) / multiply ;
	}
	
	/**
	 * 無條件捨去
	 * @param value
	 * @param decimals 小數點後幾位全捨去
	 * @return
	 */
	public static double getFloorValue(Double value, int decimals) {
		double result = safeDouble(value);
		double multiply = 1;
		for(int i=0;i<decimals;i++) {
			multiply = multiply * 10 ;
		}
		return Math.floor(result * multiply) / multiply ;
	}
	
	/**
	 * 無條件進位
	 * @param value
	 * @param decimals 小數點後幾位無條件進位
	 * @return
	 */
	public static double getCeilValue(Double value, int decimals) {
		double result = safeDouble(value);
		double multiply = 1;
		for(int i=0;i<decimals;i++) {
			multiply = multiply * 10 ;
		}
		return Math.ceil(result * multiply) / multiply ;
	}
	
	public static Number addNum(Number num1, Number num2){
		Double d1 = num1==null?0d:num1.doubleValue();
		Double d2 = num2==null?0d:num2.doubleValue();
		return (Number)(d1+d2);
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void addDoubleToMap(Map srcMap, String key, Double value){
		if(srcMap == null || key == null) return;
		double orgVal = 0d;
		if(srcMap.get(key) !=null ){
			orgVal = new Double(""+srcMap.get(key)).doubleValue();
		}
		orgVal += safeDouble(value);
		srcMap.put(key, orgVal);
	}
	
	/**
	 * 將 srcMap 內鍵值為 key 的數值加上 value。
	 * @param srcMap 來源集合
	 * @param key srcMap Key 內容
	 * @param value 待累加數值
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void addIntToMap(Map srcMap, String key, Integer value){
		if(srcMap == null || key == null) return;
		int orgVal = 0;
		if(srcMap.get(key) !=null ){
			orgVal = new Integer(""+srcMap.get(key)).intValue();
		}
		orgVal += safeInt(value);
		srcMap.put(key, orgVal);
	}
	
	public static Double max(Number a, Number b){
		double a1 = a==null?0d:a.doubleValue();
		double b1 = b==null?0d:b.doubleValue();
		return Math.max(a1, b1);
	}
	
	public static float safeFloat(String num) {
		try {
			return Float.parseFloat(num);
		} catch(Exception e) {
			return 0.0f;
		}
	}
	
	/**
	 * 比較兩筆浮點數值是否相同。
	 * @param d1
	 * @param d2
	 * @return true:相同、false:不同
	 */
	public static boolean isSame(Double d1, Double d2) {
		if(d1 == null && d2 == null) return true;
		else if(d1 == null && d2 != null) return false;
		else if(d1 != null && d2 == null) return false;
		else return d1.equals(d2);
	}
	
	/**
	 * 取得數值格式化後的字串資料。
	 * @param inputNumber 待格式化的浮點數
	 * @param decimalPlace 取小數點後幾位
	 * @return 若 inputNumber 為空則傳回 null
	 */
	public static String getNumberFormat(String inputNumber,String decimalPlace){
		String rtResult = null;
		if(inputNumber!= null && inputNumber.length()>0){
			NumberFormat nf = NumberFormat.getInstance();
			// 小數後幾位
	        nf.setMaximumFractionDigits( Integer.parseInt(decimalPlace) );
	        rtResult =  nf.format(Float.parseFloat(inputNumber));
		}
		return rtResult;
	}
	
	/**
	 * 取得數值格式化後的字串資料(無千分符號)。
	 * @param inputNumber 待格式化的浮點數
	 * @return 若 inputNumber 為空則傳回 ""
	 */
	public static String getNumberToString(String inputNumber){
		String rtResult = "";
		if(inputNumber!= null && inputNumber.length()>0){
			DecimalFormat df1 = new DecimalFormat("###");
	        rtResult =  df1.format(Float.parseFloat(inputNumber));
		}
		return rtResult;
	}
}