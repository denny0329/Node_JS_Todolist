package com.rfep.so;

/**
 * @author kaychen
 * @Date: 2010/6/22 下午3:43:26
 * @Project Name: RFEP2
 */
public interface ISoService {

}
