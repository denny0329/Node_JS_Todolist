/**
 * @(#)BsVendorUtil.java 2014/10/06
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.rfep.util;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.AppContext;
import com.rfep.bs.model.BsVendor;
import com.rfep.bs.service.BsVendorService;

/**
 * @author Bamboo
 * @date 2011-03-10
 */
public class BsVendorUtil {

	private static final Logger log = LogManager.getLogger(BsVendorUtil.class);

	/**
	 * 用廠商編號取得廠商名稱
	 * 
	 * @param vendorId 廠商編號
	 * @return
	 */
	public static String getVendorNameByVendorId(final String vendorId) {
		log.debug("查詢廠商名稱:");
		log.debug("\tvendorId:" + vendorId);
		BsVendorService service = (BsVendorService) AppContext.getBean("bsVendorService");
		BsVendor vendor = service.getVendor(vendorId);
		log.debug("\t廠商名稱:" + (vendor != null ? vendor.getVendorName() : ""));
		return vendor != null ? vendor.getVendorName() : "";
	}

	/**
	 * 用廠商編號取得廠商簡稱
	 * 
	 * @param vendorId 廠商編號
	 * @return
	 */
	public static String getVendorShortNameByVendorId(final String vendorId) {
		log.debug("查詢廠商簡稱:");
		log.debug("\tvendorId:" + vendorId);
		BsVendorService service = (BsVendorService) AppContext.getBean("bsVendorService");
		BsVendor vendor = service.getVendor(vendorId);
		log.debug("\t廠商簡稱:" + (vendor != null ? vendor.getShortName() : ""));
		return vendor != null ? vendor.getShortName() : "";
	}

	/**
	 * 用廠商編號查詢廠商資料。
	 * @param vendorId 廠商編號。
	 * @param companyId 公司別代碼。
	 * @return 找不到拋出 NullPointerException。
	 */
	public static BsVendor getBsVendorByVendorId(String vendorId, String companyId) {
		BsVendorService service = (BsVendorService) AppContext.getBean("bsVendorService");
		BsVendor vendor = service.getVendor(vendorId, companyId);
		return vendor;
	}
}
