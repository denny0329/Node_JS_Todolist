package com.rfep.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.BeanUtils;

import com.gccs.bs.model.BsStore;
import com.gccs.bs.model.BsStoreId;
import com.rfep.so.bs.vo.AreaStoreCheckableVO;
import com.rfep.so.bs.vo.BsStoreCheckableVO;
import com.rfep.so.bs.vo.ChannelStoreCheckableVO;

/**
 * @author richard
 */
public class BsStoreWrapper {
	public BsStoreWrapper() {
	}
	
	public static String getStoreId(BsStoreId id){
		return id.getChannelId() + "#" + id.getStoreId();
	}
		
	public static List<ChannelStoreCheckableVO> wrapStoresInChannel(List<BsStore> storeList, List<String> storeIds){
		List<ChannelStoreCheckableVO> result = new ArrayList<ChannelStoreCheckableVO>();
		try{			
			Comparator<BsStore> comparator = new Comparator<BsStore>(){
				public int compare(BsStore o1,
						BsStore o2) {
					int result = o1.getId().getChannelId().compareTo(o2.getId().getChannelId());
					if (result == 0){
						result = o1.getAreaId().compareTo(o2.getAreaId());
					}
					if (result == 0){
						result = o1.getId().getStoreId().compareTo(o2.getId().getStoreId());
					}
					return result;
				}			
			};
			Collections.sort(storeList, comparator);
			String priorChannelId = null;
			String priorAreaId = null;
			ChannelStoreCheckableVO channelVO = null;
			AreaStoreCheckableVO areaVO = null;
			for (BsStore store : storeList){			
				if (!store.getId().getChannelId().equals(priorChannelId)){
					channelVO =  new ChannelStoreCheckableVO();
					channelVO.setChannelId(store.getId().getChannelId());
					channelVO.setChannelName(store.getBsChannel().getChannelName1());
					result.add(channelVO);
					//換通路時,清除Area相關設定
					priorAreaId = null;
					areaVO = null;
				}
				if (!store.getAreaId().equals(priorAreaId)){
					areaVO = new AreaStoreCheckableVO();
					areaVO.setAreaId(store.getAreaId());
					areaVO.setAreaName(store.getBsArea().getAreaName());
					channelVO.getAreaList().add(areaVO);
				}			
				BsStoreCheckableVO vo = new BsStoreCheckableVO();
				BeanUtils.copyProperties(store, vo);
				if (storeIds != null && storeIds.contains(getStoreId(store.getId()))){
					vo.setChecked(true);
				}
				areaVO.getStoreList().add(vo);
				priorChannelId = store.getId().getChannelId();
				priorAreaId = store.getAreaId();
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}	
}
