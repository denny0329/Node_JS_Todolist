package com.rfep.util;

import com.bnq.util.AppContext;
import com.gccs.bs.model.BsClass;
import com.gccs.bs.service.BsClassService;

/**
 * 
 * @author san
 *
 */
public class BsClassUtil {
	
	public static String getDeptName(String _dept){
		return getBsClassByName1(_dept, null, null, null);
	}
	
	public static String getSubDeptName(String _dept, String _subDept){
		return getBsClassByName1(_dept, _subDept, null, null);
	}

	public static String getClassName(String _dept, String _subDept, String _class){
		return getBsClassByName1(_dept, _subDept, _class, null);
	}
	
	public static String getSubClassName(String _dept, String _subDept, String _class, String _subClass){
		return getBsClassByName1(_dept, _subDept, _class, _subClass);
	}

	private static BsClassService getBsclassService() {
		return (BsClassService)AppContext.getBean("bsClassService");
	}
		
	private static String getBsClassByName1(String _dept, String _subDept, String _class, String _subClass){
		BsClass bsClass = getBsclassService().getBsClass(_dept, _subDept, _class, _subClass);
		if( bsClass != null )
			return bsClass.getName1();
		else
			return "";
	}
	
//	public static String findBsClassName2(String _dept, String _subDept, String _class, String _subClass){
//		BsClass bsClass = getBsclassService().getBsClass(_dept, _subDept, _class, _subClass);
//		return bsClass.getName2();
//	}
	
}