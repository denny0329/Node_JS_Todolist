package com.rfep.util;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;
/**
 * @author Van Wang
 *
 */
public abstract class ComparatorUtil implements Comparator{
	public static boolean ASC = true;
	public static boolean DESC = false;

	public ComparatorUtil(){

	}
	/**
	 * 排序欄位Index ,第一個欄位是1, 第二個欄位是2...
	 */
	private int columnIdx;
	/**
	 * 排序種類
	 */
	private boolean sortType;
	/**
	 * 指定排序欄位數量
	 */
	private int columnSize;

	/**
	 * 建構式
	 * @param sortType 排序種類
	 */
	public ComparatorUtil(boolean sortType){
		this.sortType = sortType;
	}

	/**
	 * 取得排序型態(正排序或是逆排序)
	 * @return 排序型態
	 */
	public boolean isSortType() {
		return sortType;
	}

	/**
	 * 設定排序型態
	 * @param sortType 排序型態
	 */
	public void setSortType(boolean sortType) {
		this.sortType = sortType;
	}




	/**
	 * abstract compare
	 * @param o1 Object
	 * @param o2 Object
	 * @return int
	 */
	public abstract int compare(Object o1, Object o2);
	/**
	 * 整數型態資料比對
	 * @param obj1 整數1
	 * @param obj2 整數2
	 * @param sortType 升降冪排序
	 * @return int 順序
	 */
	public int compare(int obj1, int obj2, boolean sortType) {
		if (sortType) {
			if (obj1 > obj2)
				return 1;
			else if (obj1 < obj2)
				return -1;
			else
				return 0;
		} else {
			if (obj2 > obj1)
				return 1;
			else if (obj2 < obj1)
				return -1;
			else
				return 0;
		}
	}

	/**
	 * 長整數型態資料比對
	 * @param obj1 整數1
	 * @param obj2 整數2
	 * @param sortType 升降冪排序
	 * @return int 順序
	 */
	public int compare(long obj1, long obj2, boolean sortType) {
		if (sortType) {
			if (obj1 > obj2)
				return 1;
			else if (obj1 < obj2)
				return -1;
			else
				return 0;
		} else {
			if (obj2 > obj1)
				return 1;
			else if (obj2 < obj1)
				return -1;
			else
				return 0;
		}
	}

	/**
	 * BigDecimal型態資料比對
	 * @param obj1 BigDecimal1
	 * @param obj2 BigDecimal2
	 * @param sortType 升降冪排序
	 * @return int 順序
	 */
	public int compare(BigDecimal obj1, BigDecimal obj2, boolean sortType) {
		if (obj1 == null)
			obj1 = new BigDecimal(0);
		if (obj2 == null)
			obj2 = new BigDecimal(0);
		if (sortType) {
			return obj1.compareTo(obj2);
		} else {
			return obj2.compareTo(obj1);
		}
	}

	/**
	 * 字串型態資料比對
	 * @param obj1 字串1
	 * @param obj2 字串2
	 * @param sortType 升降冪排序
	 * @return int 順序
	 */
	public int compare(String obj1, String obj2, boolean sortType) {
		if (obj1 == null)
			obj1 = "";
		if (obj2 == null)
			obj2 = "";
		if (sortType) {

			return obj1.compareTo(obj2);
		} else {

			return obj2.compareTo(obj1);

		}
	}




	/**
	 * 時間型態資料比對
	 * @param obj1 時間1
	 * @param obj2 時間2
	 * @param sortType 升降冪排序
	 * @return int 順序
	 * @throws Exception 程序發生錯誤時，丟出錯誤訊息
	 */
	public int compare(Date obj1, Date obj2, boolean sortType)
	                   throws Exception {
		if (obj1 == null)
			obj1 = getDefaultDate();
		if (obj2 == null)
			obj2 = getDefaultDate();
		if (sortType) {
			if (obj1.after(obj2))
				return 1;
			else if (obj1.before(obj2))
				return -1;
			else
				return 0;
		} else {
			if (obj2.after(obj1))
				return 1;
			else if (obj2.before(obj1))
				return -1;
			else
				return 0;
		}
	}

	/**
	 * 浮點數型態資料比對
	 * @param obj1 浮點數1
	 * @param obj2 浮點數2
	 * @param sortType 升降冪排序
	 * @return int 順序
	 * @throws Exception 程序發生錯誤時，丟出錯誤訊息
	 */
	public int compare(Double obj1, Double obj2, boolean sortType)
			throws Exception {
		if (obj1 == null)
			obj1 = new Double(0);
		if (obj2 == null)
			obj2 = new Double(0);
		if (sortType) {
			return obj1.compareTo(obj2);
		} else {
			return obj2.compareTo(obj1);
		}
	}

	/**
	 * 取得時間最小值(初始值)
	 * @return date
	 * @throws Exception exception
	 */
	private Date getDefaultDate() throws Exception {
		SimpleDateFormat sdm = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss");
		String sTime = "0001.01.01 00:00:00";
		Date date = sdm.parse(sTime);
		return date;
	}


}
