package com.rfep.util;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import com.bnq.util.AppContext;
import com.rfep.base.BaseUtil;
import freemarker.template.Configuration;
import freemarker.template.Template;

/**
 * 
 * @author T2482
 * @deprecated 不得再使用本物件去連結資料庫，請使用正規的 Hibernate 方法取得。
 */
public class SqlUtil {
	// FIXME Need to delete
	private static Configuration cf;
	private static Map<String,String> map = new HashMap<String,String>();
	public static NamedParameterJdbcTemplate jdbc;
	
	static {		
		try {
			//File file1 = ResourceUtils.getFile("classpath:com/rfep/util/sql/");
			File file = BaseUtil.getFileSpring("classpath:com/rfep/util/sql/");
			cf = new Configuration();
			cf.setDefaultEncoding("UTF-8");
			cf.setDirectoryForTemplateLoading(file); 
			jdbc = new NamedParameterJdbcTemplate((DataSource)AppContext.getBean("dataSource"));
		} catch (Exception e) {
			e.printStackTrace();			
		}			
	}
	
	private static Template getTemplate(String fileName) {
		try {
			return cf.getTemplate(fileName);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}	
	}
	
	private static String loadSql(String id, Map params) {
		try {
			if(params == null) params = new HashMap();
			
			String[] list = id.split("\\.");
			Template t = getTemplate(list[0]+".ftl");
			Writer out = new StringWriter();
			
			params.put("_id", list[1]);		
			t.process(params, out);	
			params.remove("_id");
			
			return out.toString();
		} catch(Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public static String getDynamicSql(String id, Map params) {
		return loadSql(id, params);
	}
		
	public static String getStaticSql(String id) {			
		String sql = map.get(id);			
		if(sql == null) {	
			sql = loadSql(id, null);
			map.put(id, sql);
		}			
		
		return sql;		
	}		
	
	public static Map staticQueryForMap(String id, Map params) {
		return jdbc.queryForMap(getStaticSql(id), params);
	}
	
	public static List staticQueryForList(String id, Map params) {
		return jdbc.queryForList(getStaticSql(id), params);
	}
	
	public static <T> T staticQueryForObject(String id, Map params, Class<T> clazz) {
	    return (T)jdbc.queryForObject(getStaticSql(id), params, clazz);
	}
	
	public static void staticUpdate(String id, Map params) {
		jdbc.update(getStaticSql(id), params);
	}
	
	
	
}
