/**
 * @(#)StoreInfoUtil.java 2013/08/14
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.rfep.util;

import java.net.InetAddress;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.rfep.bs.model.StoreSystemInfo;
import com.rfep.util.cache.StoreSystemInfoDefinition;

public class StoreInfoUtil {
	private static final Logger log = LogManager.getLogger(StoreInfoUtil.class);

	public static String getIP() throws Exception {
		String _ip = InetAddress.getLocalHost().getHostAddress();
		if ("127.0.0.1".equals(_ip.trim())) {
			log.info(" WORRING InetAddress.getLocalHost().getHostAddress():"
					+ _ip);
		}
		return _ip;
	}
	public static Map<String, List<StoreSystemInfo>> getCurrentStoreInfoIpMap() throws Exception{
		return StoreSystemInfoDefinition.getIp_map();
	}

	public static List<StoreSystemInfo> getCurrentStoreInfo() throws Exception {
		return StoreSystemInfoDefinition.getStoreSystemInfo(getIP());
	}

	public static List<StoreSystemInfo> getStoreInfoByApIP(String apIp) {
		return StoreSystemInfoDefinition.getStoreSystemInfo(apIp);
	}

	public static StoreSystemInfo getStoreInfo(String storeId) {
		return StoreSystemInfoDefinition.getStoreSystemInfoByStore(storeId);
	}

	/**
	 * 是否為跨主機查詢(即非本機)
	 * 
	 * @param channelId
	 * @param storeId
	 * @return
	 */
	public static boolean isCrossHost(String storeId) {
		boolean rtv = false;
		try {
			StoreSystemInfo storeInfo = getStoreInfo(storeId);
			if (storeInfo != null) {
				if (!getIP().equals(storeInfo.getApIp()))
					rtv = true;
			}
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage(), e);
		}
		return rtv;
	}

	/**
	 * 抓取當下 IP 進而取得系統所在特力屋店別資訊<br/>
	 * 未上線前先寫死特力屋新店店
	 * 
	 * @return
	 */
	public static StoreSystemInfo getCurrentTLWStoreSystemInfo() {
		StoreSystemInfo storeInfo = null;
		try {
			List<StoreSystemInfo> storeInfoList = getCurrentStoreInfo();
			if (storeInfoList != null && storeInfoList.size() > 0) {

				for (StoreSystemInfo info : storeInfoList) {
					if ("TLW".equals(info.getChannelId())) {
						storeInfo = info;
						break;
					}
				}
			}
			
			if (storeInfo == null) {
				storeInfo = new StoreSystemInfo();
			}
			storeInfo.setChannelId("TLW");
			storeInfo.setStoreId("01900");
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return storeInfo;
	}
}