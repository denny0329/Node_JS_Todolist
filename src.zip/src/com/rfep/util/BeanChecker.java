package com.rfep.util;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

import com.rfep.so.bs.vo.Checkable;

/**
 * @author richard
 */
public class BeanChecker {
	public static <T extends Checkable> T check(Class<T> clazz, List<? extends Serializable> list, Serializable entity){
		try{					
			T result = clazz.newInstance();
			BeanUtils.copyProperties(result, entity);
			if (list.contains(entity)){				
				result.setChecked(true);
			}
			return result;
		}catch(Exception e){
			throw new RuntimeException(e);
		}
	}
}
