package com.rfep.util;

import javax.servlet.ServletContext;

import org.springframework.web.context.ServletContextAware;

public class ServletContextWrapper implements ServletContextAware {

	private ServletContext servletContext;
	
	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}

	public ServletContext getServletContext() {
		return servletContext;
	}

}
