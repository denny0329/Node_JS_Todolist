package com.rfep.util;

/**
 * 區分編輯頁面的資料狀態值，最後每筆個是屬於哪種類別。
 * @author T2482
 */
public enum Classification {
	/**新增*/
	Create,
	/**更新修改資料*/
	Update_Modify,
	/**更新原始資料*/
	Update_Original,
	/**刪除*/
	Delete;
}
