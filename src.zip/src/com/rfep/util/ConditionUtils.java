package com.rfep.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Criterion;

/**
 * @author richard
 */
public class ConditionUtils {
	public static final String DATE_FORMAT = "yyyy/MM/dd";
	
	/**
	 * 
	 * @param condition 頁面輸入的查詢條件集合
	 * @param key 欄位名稱
	 * @return
	 */
	public static Object getConditionValue(Map<String, Object> condition, String key){
		if (condition != null && condition.get(key) != null){
			Object value = condition.get(key);
			if (value instanceof Object[]){
				return ((Object[])condition.get(key))[0];
			}else {
				return value;
			}
		}
		return null;
	}
	
	/**
	 * 依據 key 值取得 condition 內相符的資料。
	 * @param condition 頁面輸入的查詢條件集合
	 * @param key 欄位名稱
	 * @return 若資料是字串就傳回，否則傳回 null。
	 */
	public static String getConditionString(Map<String, Object> condition, String key){
		Object value = ConditionUtils.getConditionValue(condition, key);
		if (value != null && value instanceof String){
			return (String)value;
		}
		return null;
	}
	
	public static Integer getConditionInteger(Map<String, Object> condition, String key){
		Object value = ConditionUtils.getConditionValue(condition, key);
		if (value != null){
			if (value instanceof Integer){
				return (Integer)value;
			}else if (value instanceof String){
				if (StringUtils.isNotBlank((String)value)){
					return Integer.valueOf((String)value);	
				}				
			}			
		}
		return null;
	}
	
	public static Date getConditionDate(Map<String, Object> condition, String key){
		return getConditionDate(condition, key, ConditionUtils.DATE_FORMAT);
	}
	
	public static Date getConditionDate(Map<String, Object> condition, String key, String format){
		Object value = ConditionUtils.getConditionValue(condition, key);
		condition.put(key, value);
		if (value != null){
			SimpleDateFormat sdf = new SimpleDateFormat(format);
			if (value instanceof Date){
				return (Date)value;
			}else if (value instanceof String){
				try {
					if (StringUtils.isNotBlank((String)value)){
						return sdf.parse((String)value);	
					}					
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}			
		}
		return null;
	}
	
	public static void setConditionDate(Map<String, Object> condition, String key, Date value){
		if (condition != null){
			condition.put(key, new Date[]{value});
		}
	}
	
	public static void setCondition(Map<String, Object> condition, String key, Object value){
		if (condition != null){
			condition.put(key, new Object[]{value});
		}
	}
	
	public static void setParameters(Query query, WhereClause clause){
		int paramIdx = 0;
		for (Object param : clause.getParameters()){
			query.setParameter(paramIdx ++, param);
		}
	}
	
	public static void setCriteria(Criteria criteria, WhereClause clause){
		for (Criterion criterion : clause.getCriteria()){
			criteria.add(criterion);
		}
	}
	
	/**
	 * 記錄查詢時要用到的 where 子句內容。
	 * 為了讓每個不同的查詢子句都能共用，所以每次使用時都要儲存 sql, parameters, criteria，才可以依順序取出每筆資料。
	 * 
	 * @author T2482
	 */
	public static class WhereClause{
		private StringBuffer sql;
		private List<Criterion> criteria;
		private List<Object> parameters;
		
		public WhereClause(){
			this.sql = new StringBuffer();
			this.criteria = new ArrayList<Criterion>();
			this.parameters = new ArrayList<Object>();
		}
		
		/**
		 * 取得 where 所需的 SQL 語法。
		 * 每次 append 時必須以 " and XXXX " 的格式加入。
		 * @return
		 */
		public StringBuffer getSql() {
			return sql;
		}
		
		/**
		 * 設定 where 所需的 SQL 語法。
		 * @param sql
		 */
		public void setSql(StringBuffer sql) {
			this.sql = sql;
		}
		
		/**
		 * 取得每個 sql 條件所帶的參數。
		 * 需要對應 sql 的 append 順序，否則取值時會發生錯誤。
		 * @return
		 */
		public List<Object> getParameters() {
			return parameters;
		}
		
		/**
		 * 設定每個 sql 條件所帶的參數。
		 * @param parameters
		 */
		public void setParameters(List<Object> parameters) {
			this.parameters = parameters;
		}

		public List<Criterion> getCriteria() {
			return criteria;
		}
		public void setCriteria(List<Criterion> criteria) {
			this.criteria = criteria;
		}		
	}
	
	/**
	 * 建立新的 WhereClause 物件。
	 * @return
	 */
	public static WhereClause createWhereClause(){		
		return new WhereClause();
	}
}
