package com.rfep.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Properties;

public class IniReader {
	protected HashMap sections = new HashMap(); 
    private transient String currentSecion; 
    private transient Properties current; 
    
    public IniReader(String filename) throws IOException { 
          BufferedReader reader = new BufferedReader(new FileReader(filename)); 
          read(reader); 
          reader.close(); 
    }
    
    public IniReader(InputStream is) throws IOException { 
        BufferedReader reader = new BufferedReader(new InputStreamReader(is)); 
        read(reader); 
        reader.close();
        is.close();
    } 

    protected void read(BufferedReader reader) throws IOException { 
          String line; 
          while ((line = reader.readLine()) != null) { 
              parseLine(line); 
          } 
          if(current != null){
        	  sections.put(currentSecion, current);
          }
    } 

    protected void parseLine(String line) { 
          line = line.trim(); 
          if (line.matches("\\[.*\\]")) { 
              if (current != null) { 
                    sections.put(currentSecion, current); 
              } 
              currentSecion = line.replaceFirst("\\[(.*)\\]", "$1"); 
              current = new Properties(); 
          } else if (line.matches(".*=.*")) { 
              int i = line.indexOf('='); 
              String name = line.substring(0, i); 
              String value = line.substring(i + 1); 
              current.setProperty(name.trim(), value.trim()); 
          } 
    } 
    
    public Enumeration<?>  getPropertyNames(String section){
    	Properties p = (Properties) sections.get(section); 
    	if( p == null )
    		return null;
    	return p.propertyNames();	
    }

    public String getValue(String section, String name) { 
          Properties p = (Properties) sections.get(section); 

          if (p == null) { 
              return null; 
          } 

          String value = p.getProperty(name); 
          return value; 
    } 
}