/**
 * @(#)RfepStringUtils.java 2016/02/16
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.rfep.util;

import java.io.UnsupportedEncodingException;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;


/**
 * 處理字串的工具：<br/>
 * 1.將字串刪減至符合限定 byte 長度<br/>
 * 2.將字串後面補空白至符合限定 byte 長度<br/>
 * 3.將字串前面補'0'至符合限定 byte 長度<br/>
 * 
 * @author bamboo
 * @version 1.0
 * @date 2010-08-31
 */
public class RfepStringUtils {
	private static final Logger log = LogManager.getLogger(RfepStringUtils.class);
	/**
	 * 刪減字串使其 byte 長度在限定的長度內
	 * 
	 * @param input 欲調整的字串
	 * @param limitByteCodeLength 限定的長度(以 byte 長度計算)
	 * @return
	 */
	public static String trimStringInLimitSize(String input,
			final int limitByteCodeLength) {
		if (input == null) {
			input = "";
		}
		StringBuilder result = new StringBuilder("");
		int length = 0;
		for (int i = 0; i < input.length(); i++) {
			int byteLength;
			try {
				byteLength = input.substring(i, i + 1).getBytes("utf-8").length;
				if ((length + byteLength) <= limitByteCodeLength) {
					length += byteLength;
					result.append(input.substring(i, i + 1));
				} else {
					break;
				}
			} catch (UnsupportedEncodingException e) {
				log.error(e.getMessage(), e);
			}
		}
		return result.toString();
	}

	/**
	 * 將字串後面補空白至指定長度。<br/>
	 * 若字串長度超過指定長度，則先刪減至符合長度，再視情況加空白
	 * 
	 * @param input
	 *            傳入字串
	 * @param length
	 *            指定長度(以 byte 長度計算)
	 * @return String
	 */
	public static String addSpaceAfterString(String input, final int length) {
		if (input == null) {
			input = "";
		}
		input = trimStringInLimitSize(input, length);
		StringBuilder result = new StringBuilder(input);
		int diff = length - input.getBytes().length;
		for (int i = 0; i < diff; i++) {
			result.append(" ");
		}

		return result.toString();
	}

	/**
	 * 將字串前面補'0'至指定長度。<br/>
	 * 若字串長度超過指定長度，則先刪減至符合長度，再視情況加'0'
	 * 
	 * @param input
	 *            傳入字串
	 * @param length
	 *            指定長度(以 byte 長度計算)
	 * @return String
	 */
	public static String addZeroBeforeString(String input,
			final int length) {
		if (input == null) {
			input = "";
		}
		input = trimStringInLimitSize(input, length);
		StringBuilder result = new StringBuilder(input);
		int diff = length - input.getBytes().length;
		for (int i = 0; i < diff; i++) {
			result.insert(0, '0');
		}

		return result.toString();
	}
}
