package com.rfep.util;

/**
 * @author richard
 */
public class SpringNamingRule {
	public static String getBeanId(Class<? extends Object> clazz){
		String name = clazz.getSimpleName();
		char[] ca = name.toCharArray();		
		ca[0] = Character.toLowerCase(ca[0]);		
		return new String(ca);
	}
}
