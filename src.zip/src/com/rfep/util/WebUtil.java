package com.rfep.util;

import javax.servlet.ServletContext;

import org.springframework.web.util.WebUtils;

import com.bnq.util.AppContext;

public class WebUtil {

	private static ServletContextWrapper servletContextWrapper = (ServletContextWrapper)AppContext.getBean("servletCtxWrapper");
	
	public static ServletContext getServletContext() {
		if(servletContextWrapper != null) {
			return servletContextWrapper.getServletContext();
		} else {
			return null;
		}
	}
	
	public static String getRealPath(String path) throws RuntimeException {
		String rtv = null;
		try {
			ServletContext ctx = getServletContext();
			if(ctx != null) {
				rtv = WebUtils.getRealPath(ctx, path);
			}
		} catch(Exception e) {
			throw new RuntimeException(e);
		}
		return rtv;
	}
	
}
