/**
 * @(#)SapPoType.java 2013/12/04
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.rfep.util;

/**
 * SAP 所代表的採購單類型。 
 * @author T2482
 */
public enum SapPoType {
	/** 天貓現貨宅配 */
	ZS09,
	/** 天貓現貨安裝 */
	ZS10,
	/** 天貓預購宅配 */
	ZS11,
	/** 天貓預購安裝 */
	ZS12,
	/** EC DIP預購調撥單 */
	ZS16, //2021.02新增
	/** DDC 庫送品預購調撥 */
	ZS18, //2021.05新增
	/**DIP 採購單*/
	ZP01,
	/**DDC 代辦進口採購單*/
	ZP02,
	/**MD 國內入庫採購單*/
	ZP03,
	/**MD 入店採購單*/
	ZP04,
	/**MD 新開店採購單*/
	ZP05,
	/**MD 委外加工單*/
	ZP06,
	/**MD 展示品採購單*/
	ZP07,
	/**MD 帳上進貨單*/
	ZP08,
	/**加工原料採購單*/
	ZP09,
	/**合營專櫃訂單*/
	ZP11,
	/**門店採購單*/
	ZP41,
	/**門店 XD 採購單（匯單）*/
	ZP42,
	/**門店客訂採購單*/
	ZP43,
	/**門店客訂 XD 採購單*/
	ZP44,
	/**門店客製委外加工單*/
	ZP45,
	/**SD 供應商直送顧客採購單*/
	ZP46,
	/**SD 供應商直送寄售客戶採購單*/
	ZP47,
	/**SD 供應商直送物流採購單*/
	ZP48,
	/**CASA 客製委外加工單（成本需確認）*/
	ZP49,
	/**SO 供應商直送客戶訂單*/
	ZP50,
	/**MINI 客製委外加工單*/
	ZP51,
	/**蛋黃預購採購單*/
	ZP53, //2021.02新增
	/**票券銷售採購單*/
	ZP54, //2021-11-11新增
	/** PO單 poType='ZP55' */
	ZP55, //2021-12-01新增
	/**固定資產採購單*/
	ZP61,
	/**費用性採購單*/
	ZP62,
	/**期初訂單（國外）*/
	ZP91,
	/**期初訂單（國內計算扣款）*/
	ZP92,
	/**期初訂單（國內不計算扣款）*/
	ZP93,
	/**特別訂單（國內不扣款）*/
	ZP94,
	/**期初訂單（已收貨未開發票）*/
	ZP95,
	/**XD 物流退貨單*/
	ZR01,
	/**MD 指定退貨單*/
	ZR02,
	/**MD 委外加工退貨單*/
	ZR03,
	/**MD 帳上退貨單*/
	ZR04,
	/**MD 展示品退貨單*/
	ZR05,
	/**門店供應商退貨單*/
	ZR06,
	/**SD 供應商直送寄售客戶退貨單*/
	ZR07,
	/**合營專櫃退貨單*/
	ZR11,
	/**XD 調撥單*/
	ZS01,
	/**門店對 DC 調撥單*/
	ZS02,
	/**店對店調撥單*/
	ZS03,
	/**MD 指定店對店調撥單*/
	ZS04,
	/**客訂門店調撥單(DC送貨至店)*/
	ZS05,
	/**客訂宅配調撥單*/
	ZS06,
	/**特賣進場調撥單*/
	ZS07,
	/**XD 調撥單（MD）*/
	ZS08,
	/**XD 退貨調撥單*/
	ZS71,
	/**門店退 DC 調撥單*/
	ZS72,
	/**MD 指定退貨調撥單*/
	ZS73,
	/**不良品退倉調撥單*/
	ZS74,
	/**報廢調撥單*/
	ZS75,
	/**特賣退場調撥單*/
	ZS76,
	/**期初客訂調撥單*/
	ZS91;
	
	/**
	 * 比較 SapPoType 轉成文字後，與 source 比較(忽略大小寫、剃除空白)是否相同。
	 * @param source 來源文字
	 * @return 若 source 為 null 或 ""，傳回 false。
	 */
	public boolean equals(String source) {
		if(source == null || source.equals("")) {
			return false;
		} else {
			return this.toString().equalsIgnoreCase(source.trim());
		}
	}
}