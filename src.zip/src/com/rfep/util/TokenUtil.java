/**
 * @(#) TokenUtil.java 2016/7/18
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.rfep.util;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.struts2.util.TokenHelper;
import org.directwebremoting.WebContext;
import org.directwebremoting.WebContextFactory;

import com.opensymphony.xwork2.ActionContext;

/**
 * 金鑰處理程式。
 * @author T2482
 */
public class TokenUtil {
	/**
	 * <pre>
	 * 專供 Action method 呼叫，檢查頁面金鑰與 Struts Session 所存是否一致；
	 * Action 執行後尚須執行 action，故頁面金鑰與 session 所存一致時不需刪除 session。<br>
	 * </pre>
	 * @throws NullPointerException pageToken 不存在時拋出
	 * @throws RuntimeException 頁面金鑰與 session 內保存者不一致時拋出
	 */
	public synchronized static void checkTokenPreAction() throws NullPointerException, RuntimeException {
		String tokenName = TokenHelper.getTokenName();
		if (tokenName == null) {
			throw new RuntimeException("無法取得頁面金鑰");
		}
		
		String token = TokenHelper.getToken(tokenName);
		if (token == null) {
			throw new RuntimeException("無法取得頁面金鑰");
		}
		checkToken(token, false);
	}
	
	/**
	 * <pre>
	 * 專供 DWR method 呼叫，檢查頁面金鑰與 Struts Session 所存是否一致；
	 * DWR 執行後尚須執行 action，故頁面金鑰與 session 所存一致時不需刪除 session。<br>
	 * </pre>
	 * @param pageToken 頁面金鑰
	 * @throws NullPointerException pageToken 不存在時拋出
	 * @throws RuntimeException 頁面金鑰與 session 內保存者不一致時拋出
	 */
	public synchronized static void checkTokenPreAction(String pageToken) throws NullPointerException, RuntimeException {
		checkToken(pageToken, false);
	}
	
	/**
	 * <pre>
	 * 專供 DWR method 呼叫，檢查頁面金鑰與 Struts Session 所存是否一致；
	 * DWR 執行後不須執行 action，故頁面金鑰與 session 所存一致時需刪除 session。
	 * </pre>
	 * @param pageToken 頁面金鑰
	 * @throws NullPointerException pageToken 不存在時拋出
	 * @throws RuntimeException 頁面金鑰與 session 內保存者不一致時拋出
	 */
	public synchronized static void checkTokenOnlyDwr(String pageToken) throws NullPointerException, RuntimeException {
		checkToken(pageToken, true);
	}
	
	/**
	 * <pre>
	 * 專供 DWR method 呼叫，檢查頁面金鑰與 Struts Session 所存是否一致。
	 * 若頁面金鑰與 session 所存一致時要依據 needDelSession 決定是否刪除該 session token 資料。
	 * </pre>
	 * @param pageToken 頁面金鑰
	 * @param needDelSession 是否需要刪除Session
	 * @throws NullPointerException pageToken 不存在時拋出
	 * @throws RuntimeException 頁面金鑰與 session 內保存者不一致時拋出
	 */
	@SuppressWarnings("unchecked")
	private static void checkToken(String pageToken, boolean needDelSession) throws NullPointerException, RuntimeException {
		if(StringUtils.isBlank(pageToken)) {
			throw new NullPointerException("未設定頁面金鑰!");
		}
		String tokenName = "struts.token";
		Map<String, Object> session = ActionContext.getContext().getSession();
		HttpSession httpSession = null;
		String sessionToken = null;
		if(session == null) {
			WebContext dwrContext = WebContextFactory.get();
			if(dwrContext != null) {
				httpSession = dwrContext.getSession();
				sessionToken = (String)httpSession.getAttribute(tokenName);
			}
		} else {
			sessionToken = (String)session.get(tokenName);
		}
		
		if(!pageToken.equals(sessionToken)) {
			throw new RuntimeException("頁面金鑰與所存金鑰不相同。");
		}
		
		if(needDelSession) {
			if(session == null) {
				httpSession.removeAttribute(tokenName);
			} else {
				session.remove(tokenName);
			}
		}
	}
}