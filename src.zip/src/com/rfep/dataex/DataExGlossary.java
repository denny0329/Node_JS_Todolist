package com.rfep.dataex;

import com.bnq.util.ftp.SftpSender;
import com.bnq.util.mq.QmReceiver;
import com.bnq.util.mq.QmSender;

public interface DataExGlossary {
	
	//INBOUND_DIR_PATH
	public static String INBOUND_DIR_PATH = QmReceiver.getInboundDirPath();
	//INBOUND_COMPLETED_DIR_PATH
	//public static String COMPLETED_DIR_PATH = QmReceiver.getCompletedDirPath();
	//INBOUND_FAIL_DIR_PATH
	public static String FAILED_DIR_PATH = QmReceiver.getFailedDirPath();
	
	//OUTBOUND_DIR_PATH  傳送檔案(含ACK)時會用到
	public static String OUTBOUND_DIR_PATH = QmSender.getOutboundDirPath();
	//OUTBOUND_ACK_DIR_PATH
	public static String ACK_DIR_PATH = OUTBOUND_DIR_PATH;
	//OUTBOUND_DIR_PATH  檔案傳送完成後,將檔案移至此目錄
	//public static String COMPLETED_DIR_PATH = QmSender.getCompletedDirPath();
	//OUTBOUND_FAIL_DIR_PATH
	public static String OUT_FAILED_DIR_PATH = QmSender.getFailedDirPath();
	
	//僅供電子標籤使用
	public static String SFTP_OUT_DIR_PATH = SftpSender.getSftpDirPath();
	//僅供電子標籤使用
	public static String SFTP_OUT_FAILED_DIR_PATH = SftpSender.getFailedDirPath();
}
