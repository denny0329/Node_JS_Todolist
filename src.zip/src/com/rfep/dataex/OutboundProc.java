/**
 * @(#) OutboundProc.java 2016/05/11
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.rfep.dataex;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.AppContext;
import com.rfep.dataex.util.FileUtils;
import com.rfep.dataex.util.SdSerialUtils;
import com.trg.oms.utils.dao.OmsMailDao;

public abstract class OutboundProc {
	protected static final String _MODIFIER = "MW" ;
	private static final int _CUT_LENGTH = 132 ;
	//LOG
	protected static final Logger log = LogManager.getLogger("dataex");

	/**
	 * 取得系統日的字串資料(yyyyMMddHHmmssSSS)。
	 * @return
	 */
	protected String getDateTimeStr() {
		try {
			return SdSerialUtils.getFileNo() ;
		} catch (Exception e) {
			throw new RuntimeException(e) ;
		}
	}
	/**
	 * 資料轉入主執行程序
	 * 1. 獲取傳入的檔案並解析檔案資料
	 * 2. 將資料轉入OMS DB
	 * 3. 產生並傳送ACK檔
	 * @param dataFile inbound資料檔
	 * @return 處理結果(成功: true; 失敗: false)
	 */
	public abstract void execute() throws RuntimeException;
	
	public void send(File srcFile) throws RuntimeException {
		OutboundManager mgr = (OutboundManager)AppContext.getBean("outboundManager");
		try{
			mgr.send(srcFile);
		}catch(Exception re) {
			log.error(re.getMessage(), re) ;
			try {
				org.apache.commons.io.FileUtils.moveFileToDirectory(srcFile, new File(DataExGlossary.OUT_FAILED_DIR_PATH), true) ;
				srcFile.delete() ;
			} catch (IOException e) {
				log.error(e.getMessage(), e) ;
			}
			throw new RuntimeException(re) ;
		}
	}
	
	/**
	 * 將檔案傳送至MQ
	 * @param srcFile 檔案來源
	 * @param no 單據號碼、據點代碼、文件編號
	 * @throws RuntimeException
	 */
	public void send(File srcFile, String no) throws RuntimeException {
		OutboundManager mgr = (OutboundManager)AppContext.getBean("outboundManager");
		try{
			mgr.send(srcFile, null, no);
		}catch(Exception re) {
			log.error(re.getMessage(), re) ;
			try {
				org.apache.commons.io.FileUtils.moveFileToDirectory(srcFile, new File(DataExGlossary.OUT_FAILED_DIR_PATH), true) ;
				srcFile.delete() ;
			} catch (IOException e) {
				log.error(e.getMessage(), e) ;
			}
			throw new RuntimeException(re) ;
		}
	}
	
	protected List<String> getCutStringList(String str) {
		List<String> list = new ArrayList<String>() ;
		while(str.length() >= _CUT_LENGTH) {
			list.add(str.substring(0,_CUT_LENGTH)) ;
			str = str.substring(132) ;
		}
		list.add(str) ;
		return list ;
	}
	
	protected List<String> getCutStringList(String str , int length) {
		List<String> list = new ArrayList<String>() ;
		String chLineStr = "\n";
		if(str.contains(FileUtils.CH_LINE_STR)){
			str = str.replace(FileUtils.CH_LINE_STR, chLineStr);
		}
		String[] strLine = str.split(chLineStr);
		for(String tempStr : strLine){
			tempStr = tempStr.replaceAll("\t", " ");	//將文字裡的TAB改成一個空白
			while(tempStr.length() >= length) {
				list.add(tempStr.substring(0,length)) ;
				tempStr = tempStr.substring(length) ;
			}
			list.add(tempStr) ;
		}
		return list ;
	}

	/**
	 * 將 prod 值補滿 18 碼，不足的補零。
	 * @param prod
	 * @return
	 */
	protected String getProdStr(String prod) {
		if(!StringUtils.isBlank(prod)) {
			//int i = Integer.parseInt(prod.trim()) ;
			Long l = Long.parseLong(prod.trim()) ;
			return new DecimalFormat("000000000000000000").format(l) ;
		}
		return "" ;
	}
	
	/**
	 * 移除 str 內的換行字元。 
	 * @param str
	 * @return
	 */
	protected String getTrimedStr(String str) {
		if(StringUtils.isNotBlank(str)) {
			return str.replaceAll("\\r|\\n", "") ;
		}
		return str ;
	}
	
	/**
	 * 將需要寄出的郵件，寫入OMS_MAIL
	 * @param className 程式類別名稱
	 * @param content 郵件內容
	 */
	protected void sendMail(String className, String content) {
		log.debug("===========insert OMS_Mail");
		OmsMailDao omsMailDao = (OmsMailDao)AppContext.getBean("omsMailDao");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		//組織郵件內文
		String mailContent = "";
		if(StringUtils.isNotBlank(content)){
			mailContent += content;
		}
		if(StringUtils.isNotBlank(mailContent)){
			//寫入郵件資料表
			try{
				omsMailDao.create(className, className+"_ERROR "+sdf.format(new Date()), mailContent, "OMS_IT", "1010");
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
		}
	}
}
