/**
 * @(#)OutboundManager.java 2013/09/26
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.rfep.dataex;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.StopWatch;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.AppContext;
import com.bnq.util.mq.OmsMqUtils;
import com.bnq.util.mq.QmSender;
import com.rfep.dataex.mm.outbound.SapPoBatch;
import com.rfep.dataex.util.service.MessageCountService;

public class OutboundManager {
	private static final Logger log = LogManager.getLogger("dataex");
	private static boolean sendFlag = true ;
	static {
		ResourceBundle bundle = ResourceBundle.getBundle("application") ;
		try{
			String flag = bundle.getString("TESTING") ;
			if(StringUtils.isNotBlank(flag) && flag.equals("TRUE")) {
				sendFlag = false ;
			}
		}catch(Exception e){
			log.error(e.getMessage(), e);
		}
		log.info("[OutboundManager] SEND : "+sendFlag) ;
	}

	private String ackQueueName ;
	
	public String getAckQueueName() {
		return ackQueueName;
	}

	public void setAckQueueName(String ackQueueName) {
		this.ackQueueName = ackQueueName;
	}

	/**
	 * 指定QueueName傳送訊息(by File)
	 */
	public void send(File srcFile, String queueName) throws RuntimeException {
		MessageCountService messageCountService = (MessageCountService)AppContext.getBean("messageCountService");
		log.info(">>>開始傳送檔案("+srcFile.getName()+")至MQ... >> sendFlag:"+sendFlag);
		try {
			if(sendFlag) {
				StopWatch stopWatch = new StopWatch();
				stopWatch.start();
				Date unzipTime = new Date();
				if(StringUtils.isNotBlank(queueName)) {
					OmsMqUtils.sendMsgToMw(srcFile, queueName);
				}else{
					OmsMqUtils.sendMsgToMw(srcFile);
				}
				stopWatch.stop();
				String code = srcFile.getName() ;
				if(code.length() > 10) {
					code = code.substring(0, 10) ;
				}
				if(StringUtils.isBlank(queueName)) {
					messageCountService.addMessageCount(srcFile.getName().toUpperCase().replace(".CSV", ".ZIP"), unzipTime , stopWatch.getTime(), srcFile.getName(), new Date(), code);
				}
				log.info(">>>檔案("+srcFile.getName()+")搬移 :"+this.getCompletedPath(code));
				org.apache.commons.io.FileUtils.moveFileToDirectory(srcFile, new File(this.getCompletedPath(code)), true) ;
				if(srcFile.exists()) {
					log.info(">>>檔案("+srcFile.getName()+")刪除");
					srcFile.delete() ;
				}
			}
		} catch(Exception e) {
			log.error(">>>檔案("+srcFile.getName()+")傳送至MQ失敗: "+e.getMessage(), e);
			throw new RuntimeException(e);
		}
		log.info(">>>檔案("+srcFile.getName()+")傳送至MQ成功");
	}
	
	/**
	 * 將檔案傳送至MQ
	 * @param srcFile 檔案來源
	 * @param queueName MQ佇列名稱
	 * @param no 單據號碼、據點代碼、文件編號
	 * @throws RuntimeException
	 * @see {@link com.rfep.dataex.OutboundProc#send(File, String)}
	 */
	public void send(File srcFile, String queueName, String no) throws RuntimeException {
		MessageCountService messageCountService = (MessageCountService)AppContext.getBean("messageCountService");
		log.info(">>>開始傳送檔案("+srcFile.getName()+")至MQ... >> sendFlag:"+sendFlag);
		try {
			if(sendFlag) {
				StopWatch stopWatch = new StopWatch();
				stopWatch.start();
				Date unzipTime = new Date();
				if(StringUtils.isNotBlank(queueName)) {
					OmsMqUtils.sendMsgToMw(srcFile, queueName);
				}else{
					OmsMqUtils.sendMsgToMw(srcFile);
				}
				stopWatch.stop();
				String code = srcFile.getName() ;
				if(code.length() > 10) {
					code = code.substring(0, 10) ;
				}
				if(StringUtils.isBlank(queueName)) {
					messageCountService.addMessageCount(srcFile.getName().toUpperCase().replace(".CSV", ".ZIP"), unzipTime , stopWatch.getTime(), srcFile.getName(), new Date(), code, no);
				}
				log.info(">>>檔案("+srcFile.getName()+")搬移 :"+this.getCompletedPath(code));
				org.apache.commons.io.FileUtils.moveFileToDirectory(srcFile, new File(this.getCompletedPath(code)), true) ;
				if(srcFile.exists()) {
					log.info(">>>檔案("+srcFile.getName()+")刪除");
					srcFile.delete() ;
				}
			}
		} catch(Exception e) {
			log.error(">>>檔案("+srcFile.getName()+")傳送至MQ失敗: "+e.getMessage(), e);
			throw new RuntimeException(e);
		}
		log.info(">>>檔案("+srcFile.getName()+")傳送至MQ成功");
	}
	
	/**
	 * 傳送訊息(by File)
	 */
	public void send(File srcFile) throws RuntimeException {
		this.send(srcFile, null) ;
	}

	/**
	 * 傳送所有Outbound目錄下的檔案至MQ
	 * @throws Exception
	 */
	public void sendAllMsgs() throws RuntimeException {
		log.info("Start SendAllMsgs ...["+Thread.currentThread().getId()+"]");

		try{
			OutboundProc omsb2b1=(OutboundProc)AppContext.getBean("outbound-CRMNMB2B01");
			omsb2b1.execute();
		}catch(Exception e){
			log.error(e.getMessage(), e) ;
		}

		try{
			OutboundProc omsb2b3=(OutboundProc)AppContext.getBean("outbound-CRMNMB2B03");
			omsb2b3.execute();
		}catch(Exception e){
			log.error(e.getMessage(), e) ;
		}		
		
		// 04/10 add by Cooper : HOLA SO
		try{
			OutboundProc sapPoBatch = new SapPoBatch() ;
			sapPoBatch.execute() ;
		}catch(Exception e){
			log.error(e.getMessage(), e) ;
		}
		
		File fileList = new File(DataExGlossary.OUTBOUND_DIR_PATH+"manual/");
		for(File srcFile: fileList.listFiles()) {
			try {
				log.debug("file name: " + srcFile.getName());
				send(srcFile);
			} catch(Exception e) {
				log.error(e.getMessage(), e);
				try {
					org.apache.commons.io.FileUtils.moveFileToDirectory(srcFile, new File(DataExGlossary.OUT_FAILED_DIR_PATH), true);
					srcFile.delete();
				} catch (IOException ex) {
					log.error(ex.getMessage(), ex);
				}
			}
		}
		log.info("End Send File to MQ By Manual ...["+Thread.currentThread().getId()+"]");
	}

	private static final DecimalFormat _DF = new DecimalFormat("00") ;
	
	private String getCompletedPath(String code) {
		Calendar c = Calendar.getInstance() ;
		StringBuilder sb = new StringBuilder(QmSender.getCompletedDirPath()) ;
		sb.append(c.get(Calendar.YEAR)).append("/") ;
		sb.append(_DF.format(c.get(Calendar.MONTH)+1)).append("/") ;
		sb.append(_DF.format(c.get(Calendar.DATE))).append("/") ;
		sb.append(code).append("/") ;
		return sb.toString() ;
	}
}