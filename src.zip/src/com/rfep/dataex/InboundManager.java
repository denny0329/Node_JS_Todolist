/**
 * @(#)InboundManager.java 2015/05/25
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.rfep.dataex;

import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.time.StopWatch;
import org.apache.log4j.Logger;

import com.bnq.util.AppContext;
import com.bnq.util.ZipUtils;
import com.bnq.util.cache.MqConfigDefinition;
import com.bnq.util.mq.QmReceiver;
import com.rfep.bs.dao.hibernate.BsParaDao;
import com.rfep.bs.model.BsPara;
import com.rfep.dataex.util.service.MessageCountService;
import com.trg.oms.utils.service.OmsMailService;

/**
 * 處理OMS Inbound資料管理員
 * 1. 讀取inbound目錄中的ZIP壓縮檔
 * 2. 解壓縮取出檔案, 並呼叫對應的inbound處理器執行資料轉入
 * 3. 依執行結果, 將解壓檔歸檔入對應目錄(成功: completed目錄;  失敗: fail目錄)
 * @author Administrator
 */
public class InboundManager {
	
	private static Logger log = Logger.getLogger("dataex");
	
	private BsParaDao bsParaDao;
	private OmsMailService omsMailService;

	/**
	 * 執行多筆電文，每筆電文間隔 1ms。
	 * @param files 電文檔案列表
	 */
	public void execute(List<File> files) {
		log.info("Inbound MQ Process started : "+ new Date());
		try {
			for(final File file: files) {
				mainProcess(file);
				Thread.sleep(1);
			}
		} catch(Exception e) {
			log.error("MQ ProcessFailed: "+e.getMessage(), e);
		} finally {
			files = null;
			System.gc();
		}
		log.info("MQ ProcessCompleted: "+new Date());
	}
	
	/**
	 * 
	 * @param file 電文檔案
	 */
	private void mainProcess(File file) {
		MessageCountService messageCountService = (MessageCountService)AppContext.getBean("messageCountService");
		//檢查是否為ZIP檔, ZIP檔才處理
		File unzipDir = null ;
		try {
			int idx = file.getName().toUpperCase().lastIndexOf(".ZIP"); 
			if(idx != -1) {
				//解壓ZIP檔
				String destPath = file.getAbsolutePath();
				log.info("unZIP File : " + file.getName() +" destPath("+destPath+")");
				destPath = destPath.substring(0, destPath.toUpperCase().lastIndexOf(".ZIP"));
				StopWatch stopWatch = new StopWatch();
				stopWatch.start();
				Date unzipTime = new Date();
				ZipUtils.unzip(file, destPath);

				Long unzipDuration = stopWatch.getTime();
				log.debug("delete Zip File : " + file.getName());
				file.delete();
				
				File completedFile = null ;
				unzipDir = new File(destPath);
				if(unzipDir.isDirectory() && unzipDir.exists()) { //解壓成功
					log.debug(" unzipDir.isDirectory() : " + unzipDir.isDirectory());
					File[] uzFiles = unzipDir.listFiles();
					for(File uzFile: uzFiles) {
						//檢查電文代碼, 並呼叫對應的inbound處理器
						String fileName = uzFile.getName();
						String code = fileName.substring(0,10) ;
						log.debug(" InBoundproc >> fileName("+fileName+") code("+code+")");
						//依據檔案名呼叫正確的處理器
						InboundProc proc = null ;
						try {
							proc = (InboundProc)AppContext.getBean(code) ;
						} catch (Exception e) {
							log.error("GetBean failed : "+code+" , "+fileName + "("+file.getName()+")", e) ;
							continue ;
						}

						boolean pass = false;
						if(proc != null) {
							String exeClassName = proc.getClass().getName();
							long l1 = System.currentTimeMillis() ;
							log.info(exeClassName + " starts to process file(" + fileName + ") code(" + code + ") at " + l1);
							messageCountService.addMessageCount(file.getName() , unzipTime , unzipDuration , fileName , new Date(), code);
							long l2 = System.currentTimeMillis() ;
							log.info("Point 0 - after addMessageCount(" + code + ") spent: " + (l2 - l1));
							pass = proc.execute(uzFile);
							long l3 = System.currentTimeMillis() ;
							log.info("Point 1 - after execute(" + code + ")  spent: " + (l3 - l2));
							messageCountService.updateMessageCountEndTime(file.getName() , fileName , new Date());
							long l4 = System.currentTimeMillis() ;
							log.info("Point 2 - after updateMessageCountEndTime(" + code + ") : " + (l4 - l3));
							log.info(exeClassName + " finish to process file(" + fileName + ") code(" + code + ") at " + l4);
						}else{
							log.error(" executeProd(" + code + ") is null");
						}

						//如果inbound處理器處理成功, 將解壓檔移至completed目錄; 如果失敗將解壓檔移至fail目錄
						if(pass) {
							log.debug(" File Move to :" + getCompletedPath(code));
							completedFile = new File(getCompletedPath(code)) ;
							org.apache.commons.io.FileUtils.moveFileToDirectory(uzFile, completedFile, true) ;
						} else {
							log.info(" File Move to :" + DataExGlossary.FAILED_DIR_PATH + fileName);
							completedFile = new File(DataExGlossary.FAILED_DIR_PATH + fileName) ;
							uzFile.renameTo(completedFile);
							if(!"OMSSMMSUMY".equals(proc.getClass().getName())){
								omsMailService.createForInboundToOmsIT(fileName, proc.getMailTitle(), proc.getErrMsg());
							}
						}
						uzFile = null ;
						completedFile = null ;
					}
					//刪除解壓目錄
					if(unzipDir != null && unzipDir.exists()){
						log.debug("準備刪除 unZipDir : " + file.getName());
						unzipDir.delete();
					}	
					uzFiles = null ;
				} else { //解壓檔案失敗
					log.error("unZip failed : " + file.getName());
				}
			}
		} catch(Exception e) {
			log.error("ProcessFailed(" + file.getName() + "): " + e.getMessage(), e);
		} finally {
			file = null ;
			unzipDir = null ;
		}
	}
	
	/**
	 * 抓 inbound/manual 目錄內的所有檔案，若屬於 sys_ftpconfig_master.status = 3 的資料，將每筆 zip 依據 bs_para.code_class = 'MAX_THREAD_NUMBER' and code_no = 'NIGHT_RUN' 所設定數量切割 thread 可處理的檔案數：否則另起單一 thread 處理。
	 */
	private static boolean process = false ;
	public void execute() {
		if(process) {
			return ;
		}
		long start = System.currentTimeMillis() ;
		try {
			process = true ;
			// 已啟動的 thread
			ArrayList<Thread> threads = new ArrayList<Thread>();
			//掃描inbound/manual目錄中的ZIP檔案清單
			File inboundDir = new File(DataExGlossary.INBOUND_DIR_PATH + "manual/");
			File[] files = inboundDir.listFiles();
			
			if(!ArrayUtils.isEmpty(files)) {
				// 存放不需要多工處理的電文
				ArrayList<File> zips = new ArrayList<File>();
				zips.addAll(Arrays.asList(files));
				// 存放檔名符合 SysFtpconfigMaster.status = 3(Multi-MQ) 的電文(key = beanId, value = files)
				Map<String, List<File>> multiZips = new HashMap<String, List<File>>();
				Set<String> multiMqNames = MqConfigDefinition.getBeanIdWithMultiMQ();
				
				// 將 manual 內的電文區分為需要多工處理與不需要多工處理
				Iterator<File> zipsIter = zips.iterator();
				while(zipsIter.hasNext()) {
					File file = zipsIter.next();
					for(String beanId : multiMqNames) {
						if(file.getName().contains(beanId)) {
							if(multiZips.containsKey(beanId)) {
								multiZips.get(beanId).add(file);
							} else {
								List<File> multiFiles = new ArrayList<File>();
								multiFiles.add(file);
								multiZips.put(beanId, multiFiles);
							}
							zipsIter.remove();
							break;
						}
					}
				}
				
				// 依據每一 thread 最大可處理檔案數切割
				double maxThread = findMaxThreadNumber();
				for(String beanId : multiZips.keySet()) {
					int maxFilesInThread = new Double(Math.ceil(multiZips.get(beanId).size() / maxThread)).intValue();
					for(int i = 0; i < multiZips.get(beanId).size(); i++) {
						List<File> subMultiFiles = null;
						if(i + maxFilesInThread > multiZips.get(beanId).size()) {
							subMultiFiles = multiZips.get(beanId).subList(i, multiZips.get(beanId).size());
						} else {
							subMultiFiles = multiZips.get(beanId).subList(i, i + maxFilesInThread);
						}
						i += maxFilesInThread - 1;
						
						threads.add(openThread(subMultiFiles));
					}
				}
				
				threads.add(openThread(zips));
				
				for(Thread thread : threads) {
					thread.join();
				}
			}
		} catch(Exception e) {
			log.error("ProcessFailed: " + e.getMessage(), e);
		} finally {
			process = false ;
		}
		long end = System.currentTimeMillis() ;
		log.info("ProcessCompleted: "+(end - start));
	}
	
	/**
	 * 將需要多工處理的電文另開 thread 執行。
	 * @param subFiles
	 * @return 已啟動的 thread
	 * @throws InterruptedException 
	 */
	public Thread openThread(final List<File> subFiles) throws InterruptedException {
		Thread thread = new Thread(new Runnable(){
			public void run() {
				execute(subFiles);
			}
		});
		thread.start();
		return thread;
	}

	/**
	 * 取得可分割的最大 thread 數量。<br>
	 * 來自 Bs_para 內 codeClass= MAX_THREAD_NUMBER, codeNo = NIGHT_RUN。
	 * @return 查無資料預設回傳 10。
	 */
	public double findMaxThreadNumber() {
		List<BsPara> bsParas = bsParaDao.findBsParaList("MAX_THREAD_NUMBER", "NIGHT_RUN");
		if(CollectionUtils.isNotEmpty(bsParas)) {
			return new Double(bsParas.get(0).getLimitValue());
		} else {
			return 10.0;
		}
	}
	
	private static final DecimalFormat _DF = new DecimalFormat("00") ;
	private String getCompletedPath(String code) {
		Calendar c = Calendar.getInstance() ;
		StringBuilder sb = new StringBuilder(QmReceiver.getCompletedDirPath()) ;
		sb.append(c.get(Calendar.YEAR)).append("/") ;
		sb.append(_DF.format(c.get(Calendar.MONTH)+1)).append("/") ;
		sb.append(_DF.format(c.get(Calendar.DATE))).append("/") ;
		sb.append(code).append("/") ;
		return sb.toString() ;
	}

	public void setBsParaDao(BsParaDao bsParaDao) {
		this.bsParaDao = bsParaDao;
	}

	public void setOmsMailService(OmsMailService omsMailService) {
		this.omsMailService = omsMailService;
	}
}