/**
 * @(#)InboundProc.java 2013/11/19
 * <p>
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 * <p>
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.rfep.dataex;

import com.bnq.util.AppContext;
import com.rfep.dataex.util.DataBlock;
import com.rfep.dataex.util.FileUtil;
import com.rfep.dataex.util.FileUtils;
import com.rfep.dataex.util.model.MessageCount;
import com.rfep.dataex.util.service.MessageCountService;
import com.trg.oms.utils.SkuUtil;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import java.io.File;
import java.text.DecimalFormat;
import java.util.List;
import java.util.UUID;

/**
 * 基礎Inbound資料交換處理器, 供各資料交換處理器繼承使用
 *
 * @author Administrator
 */
public abstract class InboundProc {
	
	protected static final Logger log = LogManager.getLogger("dataex");
	protected static final String _MODIFIER = "MW" ;
	protected static final String BEAN_OUTBOUND_MANAGER = "outboundManager";
	public static final String _NO_MORE_DATA = "***NO_MORE_DATA***" ;
    /**
     * 錯誤訊息
     */
	private StringBuilder errMsg = new StringBuilder();
    /**
     * 客製化郵件主旨
     */
	private String mailTitle;

	/**
	 * 資料轉入主執行程序
	 * 1. 獲取傳入的檔案並解析檔案資料
	 * 2. 將資料轉入OMS DB
	 * 3. 產生並傳送ACK檔
     *
	 * @param dataFile inbound資料檔
	 * @return 處理結果(成功: true; 失敗: false)
	 */
	public abstract boolean execute(File dataFile);
	
	protected String[] split(String sourceStr) {
		return sourceStr.split("\t", -1) ;
	}
	
	private String getAckFileName(File dataFile) {
		String fileName = dataFile.getName();
		fileName = fileName.split("\\.")[0] + "_ack.csv";	
		return DataExGlossary.ACK_DIR_PATH + fileName ;
	}
	
	/**
	 * 傳送ACK FILE 至M/W
     *
	 * @param fileName 原Inbound檔名或ACK檔名，如果傳入原始檔名會自動加_ack
	 * @param dataBlocks 資料區段物件
	 */
	protected void sendAckFile(final String fileName, final List<DataBlock> dataBlocks) {
		String ackFileName = fileName;
		try {
			if(ackFileName.indexOf(FileUtils.ACK) == -1)
				ackFileName = FileUtils.getAckFileName(ackFileName);
			File ackFile = FileUtils.createAckFile(DataExGlossary.OUTBOUND_DIR_PATH + ackFileName, dataBlocks);
			OutboundManager outboundManager = (OutboundManager)AppContext.getBean(BEAN_OUTBOUND_MANAGER);
			outboundManager.send(ackFile, outboundManager.getAckQueueName());
		} catch(Exception e) {
			log.error("SEND ACK ERROR ("+ackFileName+"): "+e.getMessage(), e);
		}
	}
	
	/**
	 * 在 SKU 編號取最右邊九碼，不足位數左邊補 0
     *
	 * @param sku
	 * @return
	 */
	protected String getSku(String sku) {
		return SkuUtil.transferSapSkuToOmsSku(sku);
	}
	
	protected String getUpc(String upc) {
		if(StringUtils.isNotBlank(upc)) {
			try{
				Long upcNum = Long.parseLong(upc) ;
				upc = new DecimalFormat("0000000000000").format(upcNum) ;
			}catch(Exception e){
				log.error(e.getMessage(), e) ;
			}
		}
		return upc ;
	}

	protected String getVendorId(String vendorId) {
		if(StringUtils.isNotBlank(vendorId)) {
			try{
				Long vendorIdNum = Long.parseLong(vendorId) ;
				vendorId = new DecimalFormat("0000000000").format(vendorIdNum) ;
			}catch(Exception e){
				log.error(e.getMessage(), e) ;
			}
		}
		return vendorId ;
	}
	
	protected void sendAckFile(
			final String headSegment, 
			final String footSegment, 
			final List<String> errorSegments, 
			final File dataFile) {
		FileUtil fileUtil = new FileUtil() ;
		// 組織ACK內容，產生ACK檔案
		fileUtil.setHeadSegment(headSegment);
		fileUtil.setFootSegment(footSegment);
		fileUtil.setDataSegment(errorSegments);
		try{
			File ackFile = fileUtil.createFile(getAckFileName(dataFile));
			OutboundManager outboundManager = (OutboundManager)AppContext.getBean(BEAN_OUTBOUND_MANAGER);
			outboundManager.send(ackFile, outboundManager.getAckQueueName());
		}catch(Exception e){
			log.error("Send Ack Error : "+e.getMessage(), e) ;
		}finally{
			fileUtil.setHeadSegment(null);
			fileUtil.setFootSegment(null);
			fileUtil.setDataSegment(null);
			fileUtil = null ;
		}
	}
	
	/**
	 * 更新電文檔明細
     *
	 * @param filename	電文檔名
	 * @param executeCount 電文數量
	 * @param readDuration 讀檔花費時間
	 * @param dbDuration db花費時間
	 * @throws Exception 
	 */
	protected void updateMessageCount(String filename , Long executeCount , Long readDuration , Long dbDuration) {
		updateMessageCount(filename, executeCount, readDuration, dbDuration, null, null, null);
	}
	
	/**
	 * 更新電文檔明細
     *
	 * @param filename	電文檔名
	 * @param executeCount 電文數量
	 * @param readDuration 讀檔花費時間
	 * @param dbDuration db花費時間
	 * @param no 單號
	 * @param success 成功1 失敗0 or null
	 * @throws Exception 
	 */
	protected void updateMessageCount(String filename , Long executeCount , Long readDuration , Long dbDuration , String no , String success) {
		updateMessageCount(filename, executeCount, readDuration, dbDuration, no, success, null);
	}
	
	/**
	 * 更新電文檔明細
     *
	 * @param filename	電文檔名
	 * @param executeCount 電文數量
	 * @param readDuration 讀檔花費時間
	 * @param dbDuration db花費時間
	 * @param no 單號
	 * @param success 成功1 失敗0 or null
	 * @param note 備註(異動類型)
	 * @throws Exception 
	 */
	protected void updateMessageCount(String filename, Long executeCount, Long readDuration, Long dbDuration, String no, String success, String note) {
		try{
			MessageCountService messageCountService = (MessageCountService)AppContext.getBean("messageCountService");
			messageCountService.updateMessageCount(filename, executeCount, readDuration, dbDuration, no, success, note);
		}catch(Exception e){
			log.error("filename:" + filename + ", executeCount:" + executeCount + ", readDuration:" + readDuration + ", dbDuration:" + dbDuration + ", no:" + no + ", success:" + success + ", note:" + note);
			log.error("update message count error : " + e.getMessage(), e) ;
		}
	}
	
    protected List<MessageCount> selectMessageCount(String no, String note) throws Exception {
        MessageCountService messageCountService = (MessageCountService) AppContext.getBean("messageCountService");
        return messageCountService.selectMessageCountByNoAndNote(no, note);
    }

	protected String getOid() {
		return UUID.randomUUID().toString().replaceAll("-", "") ;
	}

	/**
	 * 取得錯誤訊息。
     *
	 * @return 
	 */
	protected StringBuilder getErrMsg() {
		return errMsg;
	}

	/**
	 * 取得客製化郵件主旨。
     *
	 * @return 
	 */
	protected String getMailTitle() {
		return mailTitle;
	}

	/**
	 * 設定客製化郵件主旨。
     *
	 * @param mailTitle 
	 */
	protected void setMailTitle(String mailTitle) {
		this.mailTitle = mailTitle;
	}
}