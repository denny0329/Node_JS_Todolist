package com.rfep.dataex;

import java.io.File;

public abstract class HeavyProc extends InboundProc {

	@Override
	public abstract boolean execute(File dataFile) ;

	public abstract void execute(String dataString) throws Exception ;

}
