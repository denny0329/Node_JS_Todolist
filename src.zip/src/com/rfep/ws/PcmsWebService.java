package com.rfep.ws;

public interface PcmsWebService 
{
	public String updateInstallationInstallInfo(
			String installationId, String storeId,
			String partnerNo, String partnerName, 
			String constructorId, String constructorName,
			String fDate, String tDate, String duration);
	
	public String closeInstallationProcess(
			String soNo, String installationId, String storeId, 
			String fDate, String tDate, 
			String workerName, String systemName,
			String transportFee, String closed);
	
	public String poStorageIn(String poNo);
}
