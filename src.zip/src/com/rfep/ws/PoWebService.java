package com.rfep.ws;

/**
 * PO 的 WebService,提供刪除各類 PO 單的功能
 * 
 * @author Bamboo
 * @date 2011-11-21
 */
public interface PoWebService {
	/**
	 * 回傳狀態-成功
	 */
	public static final String MESSAGE_SUCCESS = "1";
	/**
	 * 回傳狀態-失敗
	 */
	public static final String MESSAGE_FAIL = "0";

	/**
	 * 刪除 PO 單
	 * 
	 * @param poType PO 種類('PO','TRF','PO_RTV','TRF_RTV')
	 * @param poNo PO 單號
	 * @param user 使用者
	 * @return
	 */
	public String deletePo(String poType, String poNo, String user)
			throws Exception;
}
