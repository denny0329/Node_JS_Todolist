/**
 * @(#)TransSequenceService.java 2015/12/25
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.rfep.ws;

/**
 * @author kaychen
 * @Date: 2010/7/5 下午5:20:44
 * @Project Name: RFEP2
 */
public interface TransSequenceService {
	public String getBillNoSequence(String channelId, String storeId ,String systemType) throws Exception;
	public String getReFundSequence(String channelId, String storeId) throws Exception ;
	public String getSaleNosSequence(String channelId, String storeId,String pos) throws Exception ;
	public String getTransNosSequence(String channelId , String storeId ,String pos) throws Exception ;
	public String getPosNosSequence(String channelId, String storeId , String pos) throws Exception ;
	/**[庫存]取得 PR 單號: 採購單, "P"+YY+7碼 */
	public String getPrSequence() throws Exception ;
	/** PO: 門店採購單, PO_TYPE = ZP41, "11" + 8 碼 */
	public String getPoSequence() throws Exception;
	/** SO_PO: 門店客訂採購單(SO轉下單PO單), PO_TYPE = ZP43, "13" + 8 碼 */
	public String getSoPoSequence() throws Exception;
	/** PO_RTV: PO退貨, PO_TYPE = ZR06, "46" + 8 碼  */
	public String getPoRtvSequence() throws Exception;
	/** XD_TRF: XD調撥單(對倉), PO_TYPE = ZS01, "51" + 8 碼 */
	public String getXdTrfSequence() throws Exception;
	/** DC_TRF: DC調撥單(對倉), PO_TYPE = ZS02, "52" + 8 碼 */
	public String getDcTrfSequence() throws Exception;
	/** XD_RTV: XD TRF退貨, PO_TYPE = ZS71, "71" + 8 碼 */
	public String getXdRtvSequence() throws Exception;
	/** DC_RTV: DC TRF退貨, PO_TYPE = ZS72, "72" + 8 碼*/
	public String getDcRtvSequence() throws Exception;
	/** TRF: 店對店調撥, PO_TYPE = ZS03, "53" + 8 碼 */
	public String getTrfSequence() throws Exception;
	/** SO_XD: 門店客訂採購單(SO轉下單 for XD), PO_TYPE = ZP44, "14" + 8 碼 */
	public String getSoXdSequence() throws Exception;
	/** SO_VD_PO: SO廠送採購單(SO轉下單 for VD), PO_TYPE = ZP50, "105" + 7 碼 */
	public String getSoVdPoSequence() throws Exception;
	/** SO_VD_TRF: SO廠送調撥單(SO轉調撥 for VD), PO_TYPE = ZS06, "56" + 8 碼 */
	public String getSoVdTrfSequence() throws Exception;
	/** SO_DC: 客訂門店調撥單(SO轉下單 for DC), PO_TYPE = ZS05, "55" + 8 碼 */
	public String getSoDcSequence() throws Exception;
	/**庫調, "A"+YY+7碼*/
	public String getSaSequence() throws Exception;
	/**移倉, "T"+YY+7碼*/
	public String getStSequence() throws Exception;
	/**領用, "U"+YY+7碼*/
	public String getSdSequence() throws Exception;
	/**歸還單號, "W"+YY+7碼*/
	public String getSrSequence() throws Exception;
	/**退貨清單, "Z"+YY+7碼*/
	public String getRtvSequence() throws Exception;
	/** 門店客製委外加工單, PO_TYPE = ZP49, "109" + 7 碼 */
	public String getSoCstPoSequence() throws Exception;

	public String getExchangeSequence(String channelId, String storeId) throws Exception;

	/**
	 * 取得禮券出售單號
	 * @param storeId
	 * @return
	 * @throws Exception
	 * @throws Throwable
	 */
	public String getGcSaleSequence(String storeId) throws Exception,Throwable ;
	/**
	 * 取得禮券贈送單號
	 * @param storeId
	 * @return
	 * @throws Exception
	 * @throws Throwable
	 */
	public String getGcPresSequence(String storeId) throws Exception,Throwable ;
	/**
	 * 取得禮券退回單號
	 * @param storeId
	 * @return
	 * @throws Exception
	 * @throws Throwable
	 */
	public String getGcReturnSequence(String storeId) throws Exception,Throwable ;

	/**
	 * 取得企業員購序號
	 * @return
	 * @throws Exception
	 * @throws Throwable
	 */
	public String getGcEmpShopSN() throws Exception,Throwable ;

	/**
	 * 取得政府標案序號
	 * @return
	 * @throws Exception
	 * @throws Throwable
	 */
	public String getGcGovTdrSN() throws Exception,Throwable ;

	/**
	 * 取得廠商借用序號
	 * @return
	 * @throws Exception
	 * @throws Throwable
	 */
	public String getGcVendorBorrowSN() throws Exception,Throwable ;
	
	/**
	 * 取得庫存單據編碼
	 * ex. 退貨清單編號 = 傳"RTV" 則取得 "Z + 西元年前兩碼 + 後7碼流水號。
	 * @param code
	 * @return
	 * @throws Exception
	 * @throws Throwable
	 */
	public String getGcIvSequence(String code) throws Exception,Throwable ;
	
	/** [天貓現貨宅配]取得 TRF 單號: 店對店調撥, PO_TYPE = ZS09, "57" + 8 碼 */
	public String getSkyCatHomeSequence() throws Exception;
	
	/** [天貓現貨安裝]取得 TRF 單號: 店對店調撥, PO_TYPE = ZS10, "57" + 8 碼 */
	public String getSkyCatHomeInsSequence() throws Exception;
	
	/**24 [天貓現貨安裝]取得 TRF 單號: 店對店調撥, PO_TYPE = ZS11, "58" + 8 碼 */
	public String getSkyCatPrOrderHomeSequence() throws Exception;
	
	/** [天貓預購安裝]取得 TRF 單號: 店對店調撥, PO_TYPE = ZS12, "59" + 8 碼 */
	public String getSkyCatPrOrderInstallSequence() throws Exception;
	
	/** [EC DIP預購調撥單]取得 TRF 單號: 店對店調撥,PO_TYPE = ZS16, "585" + 7碼 */
	public String getEcDipPrOrderSequence() throws Exception; //2021.02新增
	
	/** [DDC 庫送品預購調撥]取得 TRF 單號: 店對店調撥,PO_TYPE = ZS18, "595" + 7碼 */
	public String getDdcPrOrderSequence() throws Exception; //2021.05新增
	
	/**[蛋黃預購採購單] ,PO_TYPE = ZP53, "16" + 8碼 */
	public String getYolkPrePoSequence() throws Exception; //2021.02新增
	
	/**[票券銷售採購單] ,PO_TYPE = ZP54, "102" + 7碼 */
	public String getTickSalesPoSequence() throws Exception; //2021-11-11新增
	
	/** PO_TYPE = ZP55, "102" + 7碼 */
	public String getZP55PoSequence() throws Exception; //2021-12-01新增

}
