package com.rfep.ws;

/**
 * 更新OMS庫存的web Service服務，
 * 以供異質系統(SO/TTS,EPOS,CASA SO)呼叫後，
 * 則即時更新OMS庫存
 * @author san
 *
 */
public interface UpdateIVStoreInventoryWebService {
	/**
	 * 此功能會先依照CHANNEL_ID, STORE_ID, SKU做為查詢庫存檔的條件。
	 * 若查詢不到任何資料，則直接insert庫存檔資料, 但各庫存欄位值均為0。
	 * 最後再依倉別更新庫存檔資料。
	 * @param channelId	:	通路
	 * @param store_id	:	店別代碼
	 * @param sku		:	商品代碼
	 * @param storage	:	倉別  
	 * @param qty		:	數量	(可正、負)
	 * @param user		:	呼叫者(使用者)
	 * @return
	 * @throws Exception
	 */
	public ReturnMsg updateIVStoreInventory(final String channelId, final String storeId, final String sku, final String storage, final Integer transQty, final String user);
}
