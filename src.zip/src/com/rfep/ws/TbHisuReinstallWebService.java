package com.rfep.ws;

import java.util.List;

import com.rfep.so.model.TblHisuReinstall;

public interface TbHisuReinstallWebService {
	public String save(List<TblHisuReinstall> list);
}
