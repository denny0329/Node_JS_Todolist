package com.rfep.ws;

/**
 * @author kaychen
 * @Date: 2010/7/5 下午5:20:44
 * @Project Name: RFEP2
 */
public interface SoSequenceService {
	
	public String getMeasuringSequence(String caseCode) throws Exception ;
	
	public String getQuotationSequence(String caseCode) throws Exception ;

	public String getSoSequence() throws Exception ;
	
	public String getSoInstallSequence(String soNos) throws Exception ;

	public String getDeliveryOrderSequence(String soNos) throws Exception ;
	
}
