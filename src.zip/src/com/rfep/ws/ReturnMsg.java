package com.rfep.ws;

/**
 * 回傳訊息物件
 * @author san
 *
 */
public class ReturnMsg {
	
	private String success;
	
	private String message;
	
	/**
	 * 是否成功 0:失敗,1:成功
	 * @return
	 */
	public String getSuccess() {
		return success;
	}
	/**
	 * 是否成功 0:失敗,1:成功
	 * @param success
	 */
	public void setSuccess(String success) {
		this.success = success;
	}
	/**
	 * 其它訊息
	 * @return
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * 其它訊息
	 * @param message
	 */
	public void setMessage(String message) {
		this.message = message;
	}
}