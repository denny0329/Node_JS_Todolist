package com.rfep.base;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;

/**
 * @author Johnson
 * @Date: 2011/01/02 上午 13:00:00
 * @param <T> POJO實體物件
 */
public interface BaseDaoI<T> {
	
	/* HQL基本操作 */
    public int bulkUpdate(String hql);
    public int bulkUpdate(String hql, Object[] paramsValue);
    
	/* HQL基本find */
	public List find(String hql);
	public List find(String hql,Object paramsValue);
	public List find(String hql, Object[] paramsValue);
	
	/* POJO基本操作 */
	public void deleteById(Class<T> entityClass,String id);
	public void save(T transientInstance);
	public void delete(T persistentInstance);
	public void saveOrUpdate(T transientInstance);
	public void saveOrUpdateAll(Collection<T> transientInstance);
	public void deleteAll(Collection<T> transientInstance);

	/* POJO基本find */
	public T findById(Class<T> entityClass,String id);
	public List<T> findByHQLProperty(Class<T> entityClass,String propertyName, Object value) ;
	public List<T> findByHQLProperty(Class<T> entityClass,String propertyName, Object value,String hqlSort) ;
	public List<T> findByExample(T entityClass) ;
	
	/* HQL */
	/* 第1組-抓資料,以下method到最後都是呼叫createHQLQuery */
	public List createHQLQuery1_1	(String hql) ;
	public List createHQLQuery1_2	(String hql,Object paramsValue) ;
	public List createHQLQuery1_2_1	(String hql,List<Object> paramsValue) ;
	public List createHQLQuery1_2_2	(String hql,Map<String,Object> paramsValue) ;
	public List createHQLQuery1_3	(String hql,Object[] paramsValue) ;
	
	/* 第2組-抓資料,並指定起始值和抓的數量,以下method到最後都是呼叫createHQLQuery */
	public List createHQLQuery2_1(int index,int pageSize,String hql) ;
	public List createHQLQuery2_2(int index,int pageSize,String hql,Object paramsValue) ;
	public List createHQLQuery2_2_1(int index,int pageSize,String hql,List<Object> paramsValue) ;
	public List createHQLQuery2_2_2(int index,int pageSize,String hql,Map<String,Object> paramsValue) ;
	public List createHQLQuery2_3(int index,int pageSize,String hql,Object[] paramsValue) ;
	
	/* 第3組-抓資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createHQLQueryCount */
	public Long createHQLQueryCount3_1(String hql) ;
	public Long createHQLQueryCount3_2(String hql,Object paramsValue) ;
	public Long createHQLQueryCount3_2_1(String hql,List<Object> paramsValue) ;
	public Long createHQLQueryCount3_2_2(String hql,Map<String,Object> paramsValue) ;
	public Long createHQLQueryCount3_3(String hql,Object[] paramsValue) ;

	/* 第4組-抓資料和資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createHQLQueryPage */
	public QueryResultBean createHQLQueryPage4_1(int index,int pageSize,boolean isCount,String hql) throws Exception;
	public QueryResultBean createHQLQueryPage4_2(int index,int pageSize,boolean isCount,String hql,Object paramsValue) throws Exception;
	public QueryResultBean createHQLQueryPage4_2_1(int index,int pageSize,boolean isCount,String hql,List<Object> paramsValue) throws Exception;
	public QueryResultBean createHQLQueryPage4_2_2(int index,int pageSize,boolean isCount,String hql,Map<String,Object> paramsValue) throws Exception;
	public QueryResultBean createHQLQueryPage4_3(int index,int pageSize,boolean isCount,String hql,Object[] paramsValue) throws Exception;
	
	/* 第5組-執行基本操作的HQL語法,以下method到最後都是呼叫createHQLExecuteUpdate */
	public Integer createHQLExecuteUpdate5_1(String hql) ;
	public Integer createHQLExecuteUpdate5_2(String hql,Object paramsValue) ;
	public Integer createHQLExecuteUpdate5_2_1(String hql,List<Object> paramsValue) ;
	public Integer createHQLExecuteUpdate5_2_2(String hql,Map<String,Object> paramsValue) ;
	public Integer createHQLExecuteUpdate5_3(String hql,Object[] paramsValue) ;

	/* SQL */	
	/* 第1組-抓Map資料,以下method到最後都是呼叫createSQLQueryMap */
	public List createSQLQueryMap1_1(String sql) ;
	public List createSQLQueryMap1_2(String sql,Object paramsValue) ;
	public List createSQLQueryMap1_2_1(String sql,List<Object> paramsValue) ;
	public List createSQLQueryMap1_2_2(String sql,Map<String,Object> paramsValue) ;	
	public List createSQLQueryMap1_3(String sql,Object[] paramsValue) ;
	public List createSQLQueryMap1_3_1(Map map) ;
	public List createSQLQueryMap1_3_2(Map map,String sqlKey,String paramsKey) ;
	/* 第2組-抓Map資料,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryMap */
	public List createSQLQueryMap2_1(int index,int pageSize,String sql) ;
	public List createSQLQueryMap2_2(int index,int pageSize,String sql,Object paramsValue) ;
	public List createSQLQueryMap2_2_1(int index,int pageSize,String sql,List<Object> paramsValue) ;
	public List createSQLQueryMap2_2_2(int index,int pageSize,String sql,Map<String,Object> paramsValue) ;	
	public List createSQLQueryMap2_3(int index,int pageSize,String sql,Object[] paramsValue) ;
	public List createSQLQueryMap2_3_1(int index,int pageSize,Map map) ;
	public List createSQLQueryMap2_3_2(int index,int pageSize,Map map,String sqlKey,String paramsKey) ;
	public List createSQLQueryMap2_4(String sql) ;
	/* 第1組-抓Entity資料,以下method到最後都是呼叫createSQLQueryEntity */
	public List createSQLQueryEntity1_1(String sql,Class entityClass) ;
	public List createSQLQueryEntity1_2(String sql,Object paramsValue,Class entityClass) ;
	public List createSQLQueryEntity1_2_1(String sql,List<Object> paramsValue,Class entityClass) ;
	public List createSQLQueryEntity1_2_2(String sql,Map<String,Object> paramsValue,Class entityClass) ;	
	public List createSQLQueryEntity1_3(String sql,Object[] paramsValue,Class entityClass) ;
	public List createSQLQueryEntity1_3_1(Map map,Class entityClass) ;
	public List createSQLQueryEntity1_3_2(Map map,String sqlKey,String paramsKey,Class entityClass) ;
	/* 第2組-抓Entity資料,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryEntity */
	public List createSQLQueryEntity2_1(int index,int pageSize,String sql,Class entityClass) ;
	public List createSQLQueryEntity2_2(int index,int pageSize,String sql,Object paramsValue,Class entityClass) ;
	public List createSQLQueryEntity2_2_1(int index,int pageSize,String sql,List<Object> paramsValue,Class entityClass) ;
	public List createSQLQueryEntity2_2_2(int index,int pageSize,String sql,Map<String,Object> paramsValue,Class entityClass) ;	
	public List createSQLQueryEntity2_3(int index,int pageSize,String sql,Object[] paramsValue,Class entityClass) ;
	public List createSQLQueryEntity2_3_1(int index,int pageSize,Map map,Class entityClass) ;
	public List createSQLQueryEntity2_3_2(int index,int pageSize,Map map,String sqlKey,String paramsKey,Class entityClass) ;
	
	/* 第2組-抓NoManagerEntity資料,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryNoManagerEntity */
	public List createSQLQueryNoManagerEntity2_0(String sql,Class entityClass) ;
	public List createSQLQueryNoManagerEntity2_1(int index,int pageSize,String sql,Class entityClass) ;
	public List createSQLQueryNoManagerEntity2_2(int index,int pageSize,String sql,Object paramsValue,Class entityClass) ;
	public List createSQLQueryNoManagerEntity2_2_1(int index,int pageSize,String sql,List<Object> paramsValue,Class entityClass) ;
	public List createSQLQueryNoManagerEntity2_2_2(int index,int pageSize,String sql,Map<String,Object> paramsValue,Class entityClass) ;	
	public List createSQLQueryNoManagerEntity2_3(int index,int pageSize,String sql,Object[] paramsValue,Class entityClass) ;
	public List createSQLQueryNoManagerEntity2_3_1(int index,int pageSize,Map map,Class entityClass) ;
	public List createSQLQueryNoManagerEntity2_3_2(int index,int pageSize,Map map,String sqlKey,String paramsKey,Class entityClass) ;
	
	/* 第1組-抓Scalar資料,以下method到最後都是呼叫createSQLQueryScalar */
	public List createSQLQueryScalar1_1(String sql,Object scalarValue) ;
	public List createSQLQueryScalar1_2(String sql,Object paramsValue,Object scalarValue) ;
	public List createSQLQueryScalar1_2_1(String sql,List<Object> paramsValue,Object scalarValue) ;
	public List createSQLQueryScalar1_2_2(String sql,Map<String,Object> paramsValue,Object scalarValue) ;	
	public List createSQLQueryScalar1_3(String sql,Object[] paramsValue,Object scalarValue) ;
	public List createSQLQueryScalar1_3_1(Map map,Object scalarValue) ;
	public List createSQLQueryScalar1_3_2(Map map,String sqlKey,String paramsKey,Object scalarValue) ;
	/* 第2組-抓Scalar資料,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryScalar */
	public List createSQLQueryScalar2_1(int index,int pageSize,String sql,Object scalarValue) ;
	public List createSQLQueryScalar2_2(int index,int pageSize,String sql,Object paramsValue,Object scalarValue) ;
	public List createSQLQueryScalar2_2_1(int index,int pageSize,String sql,List<Object> paramsValue,Object scalarValue) ;
	public List createSQLQueryScalar2_2_2(int index,int pageSize,String sql,Map<String,Object> paramsValue,Object scalarValue) ;	
	public List createSQLQueryScalar2_3(int index,int pageSize,String sql,Object[] paramsValue,Object scalarValue) ;
	public List createSQLQueryScalar2_3_1(int index,int pageSize,Map map,Object scalarValue) ;
	public List createSQLQueryScalar2_3_2(int index,int pageSize,Map map,String sqlKey,String paramsKey,Object scalarValue) ;
	
	/* 第3組-抓資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryCount */
	public Long createSQLQueryCount3_1(String sql) ;
	public Long createSQLQueryCount3_2(String sql,Object paramsValue) ;
	public Long createSQLQueryCount3_2_1(String sql,List<Object> paramsValue) ;
	public Long createSQLQueryCount3_2_2(String sql,Map<String,Object> paramsValue) ;
	public Long createSQLQueryCount3_3(String sql,Object[] paramsValue) ;
	public Long createSQLQueryCount3_3_1(Map map) ;
	public Long createSQLQueryCount3_3_2(Map map,String sqlKey,String paramsKey) ;
	
	/* 第4組-抓Map資料和資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryPageMap */
	public QueryResultBean createSQLQueryPageMap4_1(int index,int pageSize,boolean isCount,String sql) throws Exception;
	public QueryResultBean createSQLQueryPageMap4_2(int index,int pageSize,boolean isCount,String sql,Object paramsValue) throws Exception;
	public QueryResultBean createSQLQueryPageMap4_2_1(int index,int pageSize,boolean isCount,String sql,List<Object> paramsValue) throws Exception;
	public QueryResultBean createSQLQueryPageMap4_2_2(int index,int pageSize,boolean isCount,String sql,Map<String,Object> paramsValue) throws Exception;
	public QueryResultBean createSQLQueryPageMap4_3(int index,int pageSize,boolean isCount,String sql,Object[] paramsValue) throws Exception;
	public QueryResultBean createSQLQueryPageMap4_3_1(int index,int pageSize,boolean isCount,Map map) throws Exception;
	public QueryResultBean createSQLQueryPageMap4_3_2(int index,int pageSize,boolean isCount,Map map,String sqlKey,String paramsKey) throws Exception;
	/* 第4組-抓Entity資料和資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryPageEntity */
	public QueryResultBean createSQLQueryPageEntity4_1(int index,int pageSize,boolean isCount,String sql,Class entityClass) throws Exception;
	public QueryResultBean createSQLQueryPageEntity4_2(int index,int pageSize,boolean isCount,String sql,Object paramsValue,Class entityClass) throws Exception;
	public QueryResultBean createSQLQueryPageEntity4_2_1(int index,int pageSize,boolean isCount,String sql,List<Object> paramsValue,Class entityClass) throws Exception;
	public QueryResultBean createSQLQueryPageEntity4_2_2(int index,int pageSize,boolean isCount,String sql,Map<String,Object> paramsValue,Class entityClass) throws Exception;
	public QueryResultBean createSQLQueryPageEntity4_3(int index,int pageSize,boolean isCount,String sql,Object[] paramsValue,Class entityClass) throws Exception;
	public QueryResultBean createSQLQueryPageEntity4_3_1(int index,int pageSize,boolean isCount,Map map,Class entityClass) throws Exception;
	public QueryResultBean createSQLQueryPageEntity4_3_2(int index,int pageSize,boolean isCount,Map map,String sqlKey,String paramsKey,Class entityClass) throws Exception;
	
	/* 第4組-抓Scalar資料和資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryPageScalar */
	public QueryResultBean createSQLQueryPageScalar4_1(int index,int pageSize,boolean isCount,String sql,Object scalarValue) throws Exception;
	public QueryResultBean createSQLQueryPageScalar4_2(int index,int pageSize,boolean isCount,String sql,Object paramsValue,Object scalarValue) throws Exception;
	public QueryResultBean createSQLQueryPageScalar4_2_1(int index,int pageSize,boolean isCount,String sql,List<Object> paramsValue,Object scalarValue) throws Exception;
	public QueryResultBean createSQLQueryPageScalar4_2_2(int index,int pageSize,boolean isCount,String sql,Map<String,Object> paramsValue,Object scalarValue) throws Exception;
	public QueryResultBean createSQLQueryPageScalar4_3(int index,int pageSize,boolean isCount,String sql,Object[] paramsValue,Object scalarValue) throws Exception;
	public QueryResultBean createSQLQueryPageScalar4_3_1(int index,int pageSize,boolean isCount,Map map,Object scalarValue) throws Exception;
	public QueryResultBean createSQLQueryPageScalar4_3_2(int index,int pageSize,boolean isCount,Map map,String sqlKey,String paramsKey,Object scalarValue) throws Exception;
	
	/* 第4組-抓NoManagerEntity資料和資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryPageNoManagerEntity */
	public QueryResultBean createSQLQueryPageNoManagerEntity4_1(int index,int pageSize,boolean isCount,String sql,Class entityClass) throws Exception;
	public QueryResultBean createSQLQueryPageNoManagerEntity4_2(int index,int pageSize,boolean isCount,String sql,Object paramsValue,Class entityClass) throws Exception;
	public QueryResultBean createSQLQueryPageNoManagerEntity4_2_1(int index,int pageSize,boolean isCount,String sql,List<Object> paramsValue,Class entityClass) throws Exception;
	public QueryResultBean createSQLQueryPageNoManagerEntity4_2_2(int index,int pageSize,boolean isCount,String sql,Map<String,Object> paramsValue,Class entityClass) throws Exception;
	public QueryResultBean createSQLQueryPageNoManagerEntity4_3(int index,int pageSize,boolean isCount,String sql,Object[] paramsValue,Class entityClass) throws Exception;
	public QueryResultBean createSQLQueryPageNoManagerEntity4_3_1(int index,int pageSize,boolean isCount,Map map,Class entityClass) throws Exception;
	public QueryResultBean createSQLQueryPageNoManagerEntity4_3_2(int index,int pageSize,boolean isCount,Map map,String sqlKey,String paramsKey,Class entityClass) throws Exception;
	
	
	/* 第5組-執行基本操作的SQL語法,以下method到最後都是呼叫createSQLExecuteUpdate */
	public Integer createSQLExecuteUpdate5_1(String sql) ;
	public Integer createSQLExecuteUpdate5_2(String sql,Object paramsValue) ;
	public Integer createSQLExecuteUpdate5_2_1(String sql,List<Object> paramsValue) ;
	public Integer createSQLExecuteUpdate5_2_2(String sql,Map<String,Object> paramsValue) ;
	public Integer createSQLExecuteUpdate5_3(String sql,Object[] paramsValue) ;

	/* Criteria查詢 */
    public Criteria createCriteria(Class<T> entityClass);
    public DetachedCriteria createDetachedCriteria(Class<T> entityClass);
    public List findByCriteria(DetachedCriteria criteria);
    public List findByCriteria(DetachedCriteria criteria, int index, int pageSize);
	
    /* 其它 */
    public Map getClassPropertyNames(Class<T> entityClass);
    public QueryResultBean createSQLQueryPageNoManagerEntity2( final String sql,
			final Object paramsValue,final Class entityClass) throws Exception ;
 
}
