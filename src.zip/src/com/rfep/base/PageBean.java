package com.rfep.base;

import java.io.Serializable;
import java.util.Collection;

/**
 * @author Johnson
 * @Date: 2010/10/01 上午 13:00:00
 */
public class PageBean implements Serializable {
	private static final long serialVersionUID = -860985856784577018L;

	private String name = "pageBean" ;
    private Long rowCount = 0L; //總筆數
    private int pageSize = 0; //每頁顯示記錄數
    private int pageCount = 0; //總頁數
    private int pageCurrent = 0; //當前頁數
	private Collection queryList;//結果集
	private int jumpPage; //跳頁
	
    private Integer nextPage;		// 下一頁的頁碼
    private Integer previousPage;	// 上一頁的頁碼
    
    public Integer getNextPage() {
		return pageCurrent+1;
	}

	public void setNextPage(Integer nextPage) {
		this.nextPage = nextPage;
	}

	public Integer getPreviousPage() {
		return pageCurrent-1;
	}

	public void setPreviousPage(Integer previousPage) {
		this.previousPage = previousPage;
	}

	public PageBean( ) {
    	
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getRowCount() {
		return rowCount;
	}

	/**
	 * 每次更新"總筆數"時,"總頁數"也要跟著更新
	 * @param rowCount
	 */
	public void setRowCount(Long rowCount) {
		if(rowCount!=null){
			//如果每頁顯示記錄數不是0
	        if (pageSize != 0) {
	        	//總頁數=總筆數/每頁顯示記錄數
	            pageCount = rowCount.intValue() / pageSize;
	            //如果總筆數%每頁顯示記錄數,沒有整除時,總頁數就加1
	            if (rowCount % pageSize != 0) {
	                pageCount++;
	            }
	        }	
		}
        this.rowCount = rowCount;
	}


	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getPageCount() {
		return pageCount;
	}

	public void setPageCount(int pageCount) {
		this.pageCount = pageCount;
	}

	public int getPageCurrent() {
		return pageCurrent;
	}

	public void setPageCurrent(int pageCurrent) {
		this.pageCurrent = pageCurrent;
	}

	public Collection getQueryList() {
		return queryList;
	}

	public void setQueryList(Collection queryList) {
		this.queryList = queryList;
	}

	public int getJumpPage() {
		return jumpPage;
	}

	public void setJumpPage(int jumpPage) {
		this.jumpPage = jumpPage;
	}

	@Override
	public String toString() {
		return "PageBean [跳到=" + jumpPage + ", 當前頁=" + pageCurrent + ", 每頁的筆數=" + pageSize
				+ ", 總筆數=" + rowCount +", 總頁數=" + pageCount+ "]";
	}
}
