package com.rfep.base;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.springframework.transaction.support.TransactionTemplate;

/**
 * 將Dao注入到Service
 * 
 * @author Johnson
 * @Date: 2010/10/01 上午 13:00:00
 */
public class BaseServiceImpl<T> implements BaseServiceI<T> {
	private static BaseDaoI baseDaoI;
	private static TransactionTemplate transactionTemplate;

	/*Spring注入*/
	public BaseDaoI getBaseDaoI() {
		return baseDaoI;
	}

	public void setBaseDaoI(BaseDaoI baseDaoI) {
		this.baseDaoI = baseDaoI;
	}

	public TransactionTemplate getTransactionTemplate() {
		return transactionTemplate;
	}

	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}
	
	/* HQL基本操作 */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#bulkUpdate(java.lang.String)
	 */

	public int bulkUpdate(String hql) {
		// TODO Auto-generated method stub
		return baseDaoI.bulkUpdate(hql);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#bulkUpdate(java.lang.String, java.lang.Object[])
	 */

	public int bulkUpdate(String hql, Object[] paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.bulkUpdate(hql, paramsValue);
	}

	/* HQL基本find */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#find(java.lang.String)
	 */

	public List find(String hql) {
		// TODO Auto-generated method stub
		return baseDaoI.find(hql);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#find(java.lang.String, java.lang.Object)
	 */

	public List find(String hql, Object paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.find(hql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#find(java.lang.String, java.lang.Object[])
	 */

	public List find(String hql, Object[] paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.find(hql, paramsValue);
	}

	/* POJO基本操作 */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#deleteById(java.lang.Class, java.lang.String)
	 */

	public void deleteById(Class<T> entityClass, String id) {
		// TODO Auto-generated method stub
		baseDaoI.deleteById(entityClass, id);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#save(java.lang.Object)
	 */

	public void save(T transientInstance) {
		// TODO Auto-generated method stub
		baseDaoI.save(transientInstance);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#delete(java.lang.Object)
	 */

	public void delete(T persistentInstance) {
		// TODO Auto-generated method stub
		baseDaoI.delete(persistentInstance);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#saveOrUpdate(java.lang.Object)
	 */

	public void saveOrUpdate(T transientInstance) {
		// TODO Auto-generated method stub
		baseDaoI.saveOrUpdate(transientInstance);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#saveOrUpdateAll(java.util.Collection)
	 */

	public void saveOrUpdateAll(Collection<T> transientInstance) {
		// TODO Auto-generated method stub
		baseDaoI.saveOrUpdateAll(transientInstance);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#deleteAll(java.util.Collection)
	 */

	public void deleteAll(Collection<T> transientInstance) {
		// TODO Auto-generated method stub
		baseDaoI.deleteAll(transientInstance);
	}

	/* POJO基本find */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#findById(java.lang.Class, java.lang.String)
	 */

	public T findById(Class<T> entityClass, String id) {
		// TODO Auto-generated method stub
		return (T)baseDaoI.findById(entityClass, id);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#findByHQLProperty(java.lang.Class, java.lang.String, java.lang.Object)
	 */

	public List<T> findByHQLProperty(Class<T> entityClass, String propertyName,
			Object value) {
		// TODO Auto-generated method stub
		return baseDaoI.findByHQLProperty(entityClass, propertyName, value);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#findByHQLProperty(java.lang.Class, java.lang.String, java.lang.Object, java.lang.String)
	 */

	public List<T> findByHQLProperty(Class<T> entityClass, String propertyName,
			Object value, String hqlSort) {
		// TODO Auto-generated method stub
		return baseDaoI.findByHQLProperty(entityClass, propertyName, value, hqlSort);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#findByExample(java.lang.Object)
	 */

	public List<T> findByExample(T instance) {
		// TODO Auto-generated method stub
		return baseDaoI.findByExample(instance);
	}

	/* HQL */
	/* 第1組-抓資料,以下method到最後都是呼叫createHQLQuery */
	
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQuery1_1(java.lang.String)
	 */

	public List createHQLQuery1_1(String hql) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQuery1_1(hql);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQuery1_2(java.lang.String, java.lang.Object)
	 */

	public List createHQLQuery1_2(String hql, Object paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQuery1_2(hql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQuery1_2_1(java.lang.String, java.util.List)
	 */

	public List createHQLQuery1_2_1(String hql, List<Object> paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQuery1_2_1(hql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQuery1_2_2(java.lang.String, java.util.Map)
	 */

	public List createHQLQuery1_2_2(String hql, Map<String, Object> paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQuery1_2_2(hql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQuery1_3(java.lang.String, java.lang.Object[])
	 */

	public List createHQLQuery1_3(String hql, Object[] paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQuery1_3(hql, paramsValue);
	}

	/* 第2組-抓資料,並指定起始值和抓的數量,以下method到最後都是呼叫createHQLQuery */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQuery2_1(int, int, java.lang.String)
	 */

	public List createHQLQuery2_1(int index, int pageSize, String hql) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQuery2_1(index, pageSize, hql);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQuery2_2(int, int, java.lang.String, java.lang.Object)
	 */

	public List createHQLQuery2_2(int index, int pageSize, String hql,
			Object paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQuery2_2(index, pageSize, hql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQuery2_2_1(int, int, java.lang.String, java.util.List)
	 */

	public List createHQLQuery2_2_1(int index, int pageSize, String hql,
			List<Object> paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQuery2_2_1(index, pageSize, hql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQuery2_2_2(int, int, java.lang.String, java.util.Map)
	 */

	public List createHQLQuery2_2_2(int index, int pageSize, String hql,
			Map<String, Object> paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQuery2_2_2(index, pageSize, hql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQuery2_3(int, int, java.lang.String, java.lang.Object[])
	 */

	public List createHQLQuery2_3(int index, int pageSize, String hql,
			Object[] paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQuery2_3(index, pageSize, hql, paramsValue);
	}

	/* 第3組-抓資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createHQLQueryCount */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQueryCount3_1(java.lang.String)
	 */

	public Long createHQLQueryCount3_1(String hql) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQueryCount3_1(hql);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQueryCount3_2(java.lang.String, java.lang.Object)
	 */

	public Long createHQLQueryCount3_2(String hql, Object paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQueryCount3_2(hql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQueryCount3_2_1(java.lang.String, java.util.List)
	 */

	public Long createHQLQueryCount3_2_1(String hql, List<Object> paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQueryCount3_2_1(hql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQueryCount3_2_2(java.lang.String, java.util.Map)
	 */

	public Long createHQLQueryCount3_2_2(String hql,
			Map<String, Object> paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQueryCount3_2_2(hql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQueryCount3_3(java.lang.String, java.lang.Object[])
	 */

	public Long createHQLQueryCount3_3(String hql, Object[] paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQueryCount3_3(hql, paramsValue);
	}

	/* 第4組-抓資料和資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createHQLQueryPage */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQueryPage4_1(int, int, boolean, java.lang.String)
	 */

	public QueryResultBean createHQLQueryPage4_1(int index, int pageSize,
			boolean isCount, String hql) throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQueryPage4_1(index, pageSize, isCount, hql);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQueryPage4_2(int, int, boolean, java.lang.String, java.lang.Object)
	 */

	public QueryResultBean createHQLQueryPage4_2(int index, int pageSize,
			boolean isCount, String hql, Object paramsValue) throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQueryPage4_2(index, pageSize, isCount, hql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQueryPage4_2_1(int, int, boolean, java.lang.String, java.util.List)
	 */

	public QueryResultBean createHQLQueryPage4_2_1(int index, int pageSize,
			boolean isCount, String hql, List<Object> paramsValue)
			throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQueryPage4_2_1(index, pageSize, isCount, hql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQueryPage4_2_2(int, int, boolean, java.lang.String, java.util.Map)
	 */

	public QueryResultBean createHQLQueryPage4_2_2(int index, int pageSize,
			boolean isCount, String hql, Map<String, Object> paramsValue)
			throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQueryPage4_2_2(index, pageSize, isCount, hql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLQueryPage4_3(int, int, boolean, java.lang.String, java.lang.Object[])
	 */

	public QueryResultBean createHQLQueryPage4_3(int index, int pageSize,
			boolean isCount, String hql, Object[] paramsValue) throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLQueryPage4_3(index, pageSize, isCount, hql, paramsValue);
	}

	/* 第5組-執行基本操作的SQL語法,以下method到最後都是呼叫createHQLExecuteUpdate */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLExecuteUpdate5_1(java.lang.String)
	 */

	public Integer createHQLExecuteUpdate5_1(String hql) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLExecuteUpdate5_1(hql);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLExecuteUpdate5_2(java.lang.String, java.lang.Object)
	 */

	public Integer createHQLExecuteUpdate5_2(String hql, Object paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLExecuteUpdate5_2(hql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLExecuteUpdate5_2_1(java.lang.String, java.util.List)
	 */

	public Integer createHQLExecuteUpdate5_2_1(String hql,
			List<Object> paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLExecuteUpdate5_2_1(hql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLExecuteUpdate5_2_2(java.lang.String, java.util.Map)
	 */

	public Integer createHQLExecuteUpdate5_2_2(String hql,
			Map<String, Object> paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLExecuteUpdate5_2_2(hql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createHQLExecuteUpdate5_3(java.lang.String, java.lang.Object[])
	 */

	public Integer createHQLExecuteUpdate5_3(String hql, Object[] paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createHQLExecuteUpdate5_3(hql, paramsValue);
	}

	/* SQL */	
	/* 第1組-抓Map資料,以下method到最後都是呼叫createSQLQueryMap */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryMap1_1(java.lang.String)
	 */

	public List createSQLQueryMap1_1(String sql) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryMap1_1(sql);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryMap1_2(java.lang.String, java.lang.Object)
	 */

	public List createSQLQueryMap1_2(String sql, Object paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryMap1_2(sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryMap1_2_1(java.lang.String, java.util.List)
	 */

	public List createSQLQueryMap1_2_1(String sql, List<Object> paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryMap1_2_1(sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryMap1_2_2(java.lang.String, java.util.Map)
	 */

	public List createSQLQueryMap1_2_2(String sql,
			Map<String, Object> paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryMap1_2_2(sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryMap1_3(java.lang.String, java.lang.Object[])
	 */

	public List createSQLQueryMap1_3(String sql, Object[] paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryMap1_3(sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryMap1_3_1(java.util.Map)
	 */

	public List createSQLQueryMap1_3_1(Map map) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryMap1_3_1(map);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryMap1_3_2(java.util.Map, java.lang.String, java.lang.String)
	 */

	public List createSQLQueryMap1_3_2(Map map, String sqlKey, String paramsKey) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryMap1_3_2(map, sqlKey, paramsKey);
	}

	/* 第2組-抓Map資料,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryMap */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryMap2_1(int, int, java.lang.String)
	 */

	public List createSQLQueryMap2_1(int index, int pageSize, String sql) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryMap2_1(index, pageSize, sql);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryMap2_2(int, int, java.lang.String, java.lang.Object)
	 */

	public List createSQLQueryMap2_2(int index, int pageSize, String sql,
			Object paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryMap2_2(index, pageSize, sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryMap2_2_1(int, int, java.lang.String, java.util.List)
	 */

	public List createSQLQueryMap2_2_1(int index, int pageSize, String sql,
			List<Object> paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryMap2_2_1(index, pageSize, sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryMap2_2_2(int, int, java.lang.String, java.util.Map)
	 */

	public List createSQLQueryMap2_2_2(int index, int pageSize, String sql,
			Map<String, Object> paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryMap2_2_2(index, pageSize, sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryMap2_3(int, int, java.lang.String, java.lang.Object[])
	 */

	public List createSQLQueryMap2_3(int index, int pageSize, String sql,
			Object[] paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryMap2_3(index, pageSize, sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryMap2_3_1(int, int, java.util.Map)
	 */

	public List createSQLQueryMap2_3_1(int index, int pageSize, Map map) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryMap2_3_1(index, pageSize, map);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryMap2_3_2(int, int, java.util.Map, java.lang.String, java.lang.String)
	 */

	public List createSQLQueryMap2_3_2(int index, int pageSize, Map map,
			String sqlKey, String paramsKey) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryMap2_3_2(index, pageSize, map, sqlKey, paramsKey);
	}

	/* 第1組-抓Entity資料,以下method到最後都是呼叫createSQLQueryEntity */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryEntity1_1(java.lang.String, java.lang.Class)
	 */

	public List createSQLQueryEntity1_1(String sql, Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryEntity1_1(sql, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryEntity1_2(java.lang.String, java.lang.Object, java.lang.Class)
	 */

	public List createSQLQueryEntity1_2(String sql, Object paramsValue,
			Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryEntity1_2(sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryEntity1_2_1(java.lang.String, java.util.List, java.lang.Class)
	 */

	public List createSQLQueryEntity1_2_1(String sql, List<Object> paramsValue,
			Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryEntity1_2_1(sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryEntity1_2_2(java.lang.String, java.util.Map, java.lang.Class)
	 */

	public List createSQLQueryEntity1_2_2(String sql,
			Map<String, Object> paramsValue, Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryEntity1_2_2(sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryEntity1_3(java.lang.String, java.lang.Object[], java.lang.Class)
	 */

	public List createSQLQueryEntity1_3(String sql, Object[] paramsValue,
			Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryEntity1_3(sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryEntity1_3_1(java.util.Map, java.lang.Class)
	 */

	public List createSQLQueryEntity1_3_1(Map map, Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryEntity1_3_1(map, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryEntity1_3_2(java.util.Map, java.lang.String, java.lang.String, java.lang.Class)
	 */

	public List createSQLQueryEntity1_3_2(Map map, String sqlKey,
			String paramsKey, Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryEntity1_3_2(map, sqlKey, paramsKey, entityClass);
	}

	/* 第2組-抓Entity資料,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryEntity */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryEntity2_1(int, int, java.lang.String, java.lang.Class)
	 */

	public List createSQLQueryEntity2_1(int index, int pageSize, String sql,
			Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryEntity2_1(index, pageSize, sql, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryEntity2_2(int, int, java.lang.String, java.lang.Object, java.lang.Class)
	 */

	public List createSQLQueryEntity2_2(int index, int pageSize, String sql,
			Object paramsValue, Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryEntity2_2(index, pageSize, sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryEntity2_2_1(int, int, java.lang.String, java.util.List, java.lang.Class)
	 */

	public List createSQLQueryEntity2_2_1(int index, int pageSize, String sql,
			List<Object> paramsValue, Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryEntity2_2_1(index, pageSize, sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryEntity2_2_2(int, int, java.lang.String, java.util.Map, java.lang.Class)
	 */

	public List createSQLQueryEntity2_2_2(int index, int pageSize, String sql,
			Map<String, Object> paramsValue, Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryEntity2_2_2(index, pageSize, sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryEntity2_3(int, int, java.lang.String, java.lang.Object[], java.lang.Class)
	 */

	public List createSQLQueryEntity2_3(int index, int pageSize, String sql,
			Object[] paramsValue, Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryEntity2_3(index, pageSize, sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryEntity2_3_1(int, int, java.util.Map, java.lang.Class)
	 */

	public List createSQLQueryEntity2_3_1(int index, int pageSize, Map map,
			Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryEntity2_3_1(index, pageSize, map, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryEntity2_3_2(int, int, java.util.Map, java.lang.String, java.lang.String, java.lang.Class)
	 */

	public List createSQLQueryEntity2_3_2(int index, int pageSize, Map map,
			String sqlKey, String paramsKey, Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryEntity2_3_2(index, pageSize, map, sqlKey, paramsKey, entityClass);
	}

	/* 第1組-抓Scalar資料,以下method到最後都是呼叫createSQLQueryScalar */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryScalar1_1(java.lang.String, java.lang.Object)
	 */

	public List createSQLQueryScalar1_1(String sql, Object scalarValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryScalar1_1(sql, scalarValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryScalar1_2(java.lang.String, java.lang.Object, java.lang.Object)
	 */

	public List createSQLQueryScalar1_2(String sql, Object paramsValue,
			Object scalarValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryScalar1_2(sql, paramsValue, scalarValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryScalar1_2_1(java.lang.String, java.util.List, java.lang.Object)
	 */

	public List createSQLQueryScalar1_2_1(String sql, List<Object> paramsValue,
			Object scalarValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryScalar1_2_1(sql, paramsValue, scalarValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryScalar1_2_2(java.lang.String, java.util.Map, java.lang.Object)
	 */

	public List createSQLQueryScalar1_2_2(String sql,
			Map<String, Object> paramsValue, Object scalarValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryScalar1_2_2(sql, paramsValue, scalarValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryScalar1_3(java.lang.String, java.lang.Object[], java.lang.Object)
	 */

	public List createSQLQueryScalar1_3(String sql, Object[] paramsValue,
			Object scalarValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryScalar1_3(sql, paramsValue, scalarValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryScalar1_3_1(java.util.Map, java.lang.Object)
	 */

	public List createSQLQueryScalar1_3_1(Map map, Object scalarValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryScalar1_3_1(map, scalarValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryScalar1_3_2(java.util.Map, java.lang.String, java.lang.String, java.lang.Object)
	 */

	public List createSQLQueryScalar1_3_2(Map map, String sqlKey,
			String paramsKey, Object scalarValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryScalar1_3_2(map, sqlKey, paramsKey, scalarValue);
	}

	/* 第2組-抓Scalar資料,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryScalar */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryScalar2_1(int, int, java.lang.String, java.lang.Object)
	 */

	public List createSQLQueryScalar2_1(int index, int pageSize, String sql,
			Object scalarValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryScalar2_1(index, pageSize, sql, scalarValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryScalar2_2(int, int, java.lang.String, java.lang.Object, java.lang.Object)
	 */

	public List createSQLQueryScalar2_2(int index, int pageSize, String sql,
			Object paramsValue, Object scalarValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryScalar2_2(index, pageSize, sql, paramsValue, scalarValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryScalar2_2_1(int, int, java.lang.String, java.util.List, java.lang.Object)
	 */

	public List createSQLQueryScalar2_2_1(int index, int pageSize, String sql,
			List<Object> paramsValue, Object scalarValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryScalar2_2_1(index, pageSize, sql, paramsValue, scalarValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryScalar2_2_2(int, int, java.lang.String, java.util.Map, java.lang.Object)
	 */

	public List createSQLQueryScalar2_2_2(int index, int pageSize, String sql,
			Map<String, Object> paramsValue, Object scalarValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryScalar2_2_2(index, pageSize, sql, paramsValue, scalarValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryScalar2_3(int, int, java.lang.String, java.lang.Object[], java.lang.Object)
	 */

	public List createSQLQueryScalar2_3(int index, int pageSize, String sql,
			Object[] paramsValue, Object scalarValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryScalar2_3(index, pageSize, sql, paramsValue, scalarValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryScalar2_3_1(int, int, java.util.Map, java.lang.Object)
	 */

	public List createSQLQueryScalar2_3_1(int index, int pageSize, Map map,
			Object scalarValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryScalar2_3_1(index, pageSize, map, scalarValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryScalar2_3_2(int, int, java.util.Map, java.lang.String, java.lang.String, java.lang.Object)
	 */

	public List createSQLQueryScalar2_3_2(int index, int pageSize, Map map,
			String sqlKey, String paramsKey, Object scalarValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryScalar2_3_2(index, pageSize, map, sqlKey, paramsKey, scalarValue);
	}
	
	/* 第2組-抓NoManagerEntity資料,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryNoManagerEntity */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryNoManagerEntity2_1(int, int, java.lang.String, java.lang.Class)
	 */
	public List createSQLQueryNoManagerEntity2_0(String sql, Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryNoManagerEntity2_0(sql, entityClass);
	}
	
	public List createSQLQueryNoManagerEntity2_1(int index, int pageSize,
			String sql, Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryNoManagerEntity2_1(index, pageSize, sql, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryNoManagerEntity2_2(int, int, java.lang.String, java.lang.Object, java.lang.Class)
	 */
	public List createSQLQueryNoManagerEntity2_2(int index, int pageSize,
			String sql, Object paramsValue, Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryNoManagerEntity2_2(index, pageSize, sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryNoManagerEntity2_2_1(int, int, java.lang.String, java.util.List, java.lang.Class)
	 */
	public List createSQLQueryNoManagerEntity2_2_1(int index, int pageSize,
			String sql, List<Object> paramsValue, Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryNoManagerEntity2_2_1(index, pageSize, sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryNoManagerEntity2_2_2(int, int, java.lang.String, java.util.Map, java.lang.Class)
	 */
	public List createSQLQueryNoManagerEntity2_2_2(int index, int pageSize,
			String sql, Map<String, Object> paramsValue, Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryNoManagerEntity2_2_2(index, pageSize, sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryNoManagerEntity2_3(int, int, java.lang.String, java.lang.Object[], java.lang.Class)
	 */
	public List createSQLQueryNoManagerEntity2_3(int index, int pageSize,
			String sql, Object[] paramsValue, Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryNoManagerEntity2_3(index, pageSize, sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryNoManagerEntity2_3_1(int, int, java.util.Map, java.lang.Class)
	 */
	public List createSQLQueryNoManagerEntity2_3_1(int index, int pageSize,
			Map map, Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryNoManagerEntity2_3_1(index, pageSize, map, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryNoManagerEntity2_3_2(int, int, java.util.Map, java.lang.String, java.lang.String, java.lang.Class)
	 */
	public List createSQLQueryNoManagerEntity2_3_2(int index, int pageSize,
			Map map, String sqlKey, String paramsKey, Class entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryNoManagerEntity2_3_2(index, pageSize, map, sqlKey, paramsKey, entityClass);
	}

	/* 第3組-抓資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryCount */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryCount3_1(java.lang.String)
	 */

	public Long createSQLQueryCount3_1(String sql) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryCount3_1(sql);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryCount3_2(java.lang.String, java.lang.Object)
	 */

	public Long createSQLQueryCount3_2(String sql, Object paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryCount3_2(sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryCount3_2_1(java.lang.String, java.util.List)
	 */

	public Long createSQLQueryCount3_2_1(String sql, List<Object> paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryCount3_2_1(sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryCount3_2_2(java.lang.String, java.util.Map)
	 */

	public Long createSQLQueryCount3_2_2(String sql,
			Map<String, Object> paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryCount3_2_2(sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryCount3_3(java.lang.String, java.lang.Object[])
	 */

	public Long createSQLQueryCount3_3(String sql, Object[] paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryCount3_3(sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryCount3_3_1(java.util.Map)
	 */

	public Long createSQLQueryCount3_3_1(Map map) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryCount3_3_1(map);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryCount3_3_2(java.util.Map, java.lang.String, java.lang.String)
	 */

	public Long createSQLQueryCount3_3_2(Map map, String sqlKey,
			String paramsKey) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryCount3_3_2(map, sqlKey, paramsKey);
	}

	/* 第4組-抓Map資料和資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryPageMap */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageMap4_1(int, int, boolean, java.lang.String)
	 */

	public QueryResultBean createSQLQueryPageMap4_1(int index, int pageSize,
			boolean isCount, String sql) throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageMap4_1(index, pageSize, isCount, sql);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageMap4_2(int, int, boolean, java.lang.String, java.lang.Object)
	 */

	public QueryResultBean createSQLQueryPageMap4_2(int index, int pageSize,
			boolean isCount, String sql, Object paramsValue) throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageMap4_2(index, pageSize, isCount, sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageMap4_2_1(int, int, boolean, java.lang.String, java.util.List)
	 */

	public QueryResultBean createSQLQueryPageMap4_2_1(int index, int pageSize,
			boolean isCount, String sql, List<Object> paramsValue)
			throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageMap4_2_1(index, pageSize, isCount, sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageMap4_2_2(int, int, boolean, java.lang.String, java.util.Map)
	 */

	public QueryResultBean createSQLQueryPageMap4_2_2(int index, int pageSize,
			boolean isCount, String sql, Map<String, Object> paramsValue)
			throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageMap4_2_2(index, pageSize, isCount, sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageMap4_3(int, int, boolean, java.lang.String, java.lang.Object[])
	 */

	public QueryResultBean createSQLQueryPageMap4_3(int index, int pageSize,
			boolean isCount, String sql, Object[] paramsValue) throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageMap4_3(index, pageSize, isCount, sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageMap4_3_1(int, int, boolean, java.util.Map)
	 */

	public QueryResultBean createSQLQueryPageMap4_3_1(int index, int pageSize,
			boolean isCount, Map map) throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageMap4_3_1(index, pageSize, isCount, map);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageMap4_3_2(int, int, boolean, java.util.Map, java.lang.String, java.lang.String)
	 */

	public QueryResultBean createSQLQueryPageMap4_3_2(int index, int pageSize,
			boolean isCount, Map map, String sqlKey, String paramsKey)
			throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageMap4_3_2(index, pageSize, isCount, map, sqlKey, paramsKey);
	}

	/* 第4組-抓Entity資料和資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryPageEntity */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageEntity4_1(int, int, boolean, java.lang.String, java.lang.Class)
	 */

	public QueryResultBean createSQLQueryPageEntity4_1(int index, int pageSize,
			boolean isCount, String sql, Class entityClass) throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageEntity4_1(index, pageSize, isCount, sql, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageEntity4_2(int, int, boolean, java.lang.String, java.lang.Object, java.lang.Class)
	 */

	public QueryResultBean createSQLQueryPageEntity4_2(int index, int pageSize,
			boolean isCount, String sql, Object paramsValue, Class entityClass)
			throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageEntity4_2(index, pageSize, isCount, sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageEntity4_2_1(int, int, boolean, java.lang.String, java.util.List, java.lang.Class)
	 */

	public QueryResultBean createSQLQueryPageEntity4_2_1(int index,
			int pageSize, boolean isCount, String sql,
			List<Object> paramsValue, Class entityClass) throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageEntity4_2_1(index, pageSize, isCount, sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageEntity4_2_2(int, int, boolean, java.lang.String, java.util.Map, java.lang.Class)
	 */

	public QueryResultBean createSQLQueryPageEntity4_2_2(int index,
			int pageSize, boolean isCount, String sql,
			Map<String, Object> paramsValue, Class entityClass)
			throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageEntity4_2_2(index, pageSize, isCount, sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageEntity4_3(int, int, boolean, java.lang.String, java.lang.Object[], java.lang.Class)
	 */

	public QueryResultBean createSQLQueryPageEntity4_3(int index, int pageSize,
			boolean isCount, String sql, Object[] paramsValue, Class entityClass)
			throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageEntity4_3(index, pageSize, isCount, sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageEntity4_3_1(int, int, boolean, java.util.Map, java.lang.Class)
	 */

	public QueryResultBean createSQLQueryPageEntity4_3_1(int index,
			int pageSize, boolean isCount, Map map, Class entityClass)
			throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageEntity4_3_1(index, pageSize, isCount, map, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageEntity4_3_2(int, int, boolean, java.util.Map, java.lang.String, java.lang.String, java.lang.Class)
	 */

	public QueryResultBean createSQLQueryPageEntity4_3_2(int index,
			int pageSize, boolean isCount, Map map, String sqlKey,
			String paramsKey, Class entityClass) throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageEntity4_3_2(index, pageSize, isCount, map, sqlKey, paramsKey, entityClass);
	}

	/* 第4組-抓Scalar資料和資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryPageScalar */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageScalar4_1(int, int, boolean, java.lang.String, java.lang.Object)
	 */

	public QueryResultBean createSQLQueryPageScalar4_1(int index, int pageSize,
			boolean isCount, String sql, Object scalarValue) throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageScalar4_1(index, pageSize, isCount, sql, scalarValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageScalar4_2(int, int, boolean, java.lang.String, java.lang.Object, java.lang.Object)
	 */

	public QueryResultBean createSQLQueryPageScalar4_2(int index, int pageSize,
			boolean isCount, String sql, Object paramsValue, Object scalarValue)
			throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageScalar4_2(index, pageSize, isCount, sql, paramsValue, scalarValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageScalar4_2_1(int, int, boolean, java.lang.String, java.util.List, java.lang.Object)
	 */

	public QueryResultBean createSQLQueryPageScalar4_2_1(int index,
			int pageSize, boolean isCount, String sql,
			List<Object> paramsValue, Object scalarValue) throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageScalar4_2_1(index, pageSize, isCount, sql, paramsValue, scalarValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageScalar4_2_2(int, int, boolean, java.lang.String, java.util.Map, java.lang.Object)
	 */

	public QueryResultBean createSQLQueryPageScalar4_2_2(int index,
			int pageSize, boolean isCount, String sql,
			Map<String, Object> paramsValue, Object scalarValue)
			throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageScalar4_2_2(index, pageSize, isCount, sql, paramsValue, scalarValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageScalar4_3(int, int, boolean, java.lang.String, java.lang.Object[], java.lang.Object)
	 */

	public QueryResultBean createSQLQueryPageScalar4_3(int index, int pageSize,
			boolean isCount, String sql, Object[] paramsValue,
			Object scalarValue) throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageScalar4_3(index, pageSize, isCount, sql, paramsValue, scalarValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageScalar4_3_1(int, int, boolean, java.util.Map, java.lang.Object)
	 */

	public QueryResultBean createSQLQueryPageScalar4_3_1(int index,
			int pageSize, boolean isCount, Map map, Object scalarValue)
			throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageScalar4_3_1(index, pageSize, isCount, map, scalarValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageScalar4_3_2(int, int, boolean, java.util.Map, java.lang.String, java.lang.String, java.lang.Object)
	 */

	public QueryResultBean createSQLQueryPageScalar4_3_2(int index,
			int pageSize, boolean isCount, Map map, String sqlKey,
			String paramsKey, Object scalarValue) throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageScalar4_3_2(index, pageSize, isCount, map, sqlKey, paramsKey, scalarValue);
	}

	/* 第5組-執行基本操作的HQL語法,以下method到最後都是呼叫createSQLExecuteUpdate */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLExecuteUpdate5_1(java.lang.String)
	 */

	public Integer createSQLExecuteUpdate5_1(String sql) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLExecuteUpdate5_1(sql);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLExecuteUpdate5_2(java.lang.String, java.lang.Object)
	 */

	public Integer createSQLExecuteUpdate5_2(String sql, Object paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLExecuteUpdate5_2(sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLExecuteUpdate5_2_1(java.lang.String, java.util.List)
	 */

	public Integer createSQLExecuteUpdate5_2_1(String sql,
			List<Object> paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLExecuteUpdate5_2_1(sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLExecuteUpdate5_2_2(java.lang.String, java.util.Map)
	 */

	public Integer createSQLExecuteUpdate5_2_2(String sql,
			Map<String, Object> paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLExecuteUpdate5_2_2(sql, paramsValue);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLExecuteUpdate5_3(java.lang.String, java.lang.Object[])
	 */

	public Integer createSQLExecuteUpdate5_3(String sql, Object[] paramsValue) {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLExecuteUpdate5_3(sql, paramsValue);
	}

	/* Criteria查詢 */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createCriteria(java.lang.Class)
	 */

	public Criteria createCriteria(Class<T> entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createCriteria(entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createDetachedCriteria(java.lang.Class)
	 */

	public DetachedCriteria createDetachedCriteria(Class<T> entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.createDetachedCriteria(entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#findByCriteria(org.hibernate.criterion.DetachedCriteria)
	 */

	public List findByCriteria(DetachedCriteria criteria) {
		// TODO Auto-generated method stub
		return baseDaoI.findByCriteria(criteria);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#findByCriteria(org.hibernate.criterion.DetachedCriteria, int, int)
	 */

	public List findByCriteria(DetachedCriteria criteria, int index,
			int pageSize) {
		// TODO Auto-generated method stub
		return baseDaoI.findByCriteria(criteria, index, pageSize);
	}
	
	 /* 其它 */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#getEntityPropertyNames(java.lang.Class)
	 */

	public Map getClassPropertyNames(Class<T> entityClass) {
		// TODO Auto-generated method stub
		return baseDaoI.getClassPropertyNames(entityClass);
	}
	
	/* 第4組-抓NoManagerEntity資料和資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryPageNoManagerEntity */
	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageNoManagerEntity4_1(int, int, boolean, java.lang.String, java.lang.Class)
	 */
	public QueryResultBean createSQLQueryPageNoManagerEntity4_1(int index,
			int pageSize, boolean isCount, String sql, Class entityClass)
			throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageNoManagerEntity4_1(index, pageSize, isCount, sql, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageNoManagerEntity4_2(int, int, boolean, java.lang.String, java.lang.Object, java.lang.Class)
	 */
	public QueryResultBean createSQLQueryPageNoManagerEntity4_2(int index,
			int pageSize, boolean isCount, String sql, Object paramsValue,
			Class entityClass) throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageNoManagerEntity4_2(index, pageSize, isCount, sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageNoManagerEntity4_2_1(int, int, boolean, java.lang.String, java.util.List, java.lang.Class)
	 */
	public QueryResultBean createSQLQueryPageNoManagerEntity4_2_1(int index,
			int pageSize, boolean isCount, String sql,
			List<Object> paramsValue, Class entityClass) throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageNoManagerEntity4_2_1(index, pageSize, isCount, sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageNoManagerEntity4_2_2(int, int, boolean, java.lang.String, java.util.Map, java.lang.Class)
	 */
	public QueryResultBean createSQLQueryPageNoManagerEntity4_2_2(int index,
			int pageSize, boolean isCount, String sql,
			Map<String, Object> paramsValue, Class entityClass)
			throws Exception {
		// TODO Auto-generated method stub
		return baseDaoI.createSQLQueryPageNoManagerEntity4_2_2(index, pageSize, isCount, sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageNoManagerEntity4_3(int, int, boolean, java.lang.String, java.lang.Object[], java.lang.Class)
	 */
	public QueryResultBean createSQLQueryPageNoManagerEntity4_3(int index,
			int pageSize, boolean isCount, String sql, Object[] paramsValue,
			Class entityClass) throws Exception {
		return baseDaoI.createSQLQueryPageNoManagerEntity4_3(index, pageSize, isCount, sql, paramsValue, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageNoManagerEntity4_3_1(int, int, boolean, java.util.Map, java.lang.Class)
	 */
	public QueryResultBean createSQLQueryPageNoManagerEntity4_3_1(int index,
			int pageSize, boolean isCount, Map map, Class entityClass)
			throws Exception {
		return baseDaoI.createSQLQueryPageNoManagerEntity4_3_1(index, pageSize, isCount, map, entityClass);
	}

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryPageNoManagerEntity4_3_2(int, int, boolean, java.util.Map, java.lang.String, java.lang.String, java.lang.Class)
	 */
	public QueryResultBean createSQLQueryPageNoManagerEntity4_3_2(int index,
			int pageSize, boolean isCount, Map map, String sqlKey,
			String paramsKey, Class entityClass) throws Exception {
		return baseDaoI.createSQLQueryPageNoManagerEntity4_3_2(index, pageSize, isCount, map, sqlKey, paramsKey, entityClass);
	}


    public QueryResultBean createSQLQueryPageNoManagerEntity2( final String sql,
			final Object paramsValue,final Class entityClass) throws Exception {
    	return baseDaoI.createSQLQueryPageNoManagerEntity2(sql, paramsValue, entityClass);
    }

	/* (non-Javadoc)
	 * @see com.rfep.base.BaseDaoI#createSQLQueryMap2_4(java.lang.String)
	 */
	public List createSQLQueryMap2_4(String sql) {
		return baseDaoI.createSQLQueryMap2_4(sql);
	}
}
