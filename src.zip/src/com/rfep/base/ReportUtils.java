/**
 * @(#)ReportUtils.java 2013/08/18
 * <p>
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 * <p>
 * This software is the confidential and proprietary information of Test Rite
 * Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.rfep.base;

import com.rfep.rm.model.RptPoolmgt;
import com.rfep.util.sys.job.SkuTransReportJob;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.export.*;
import net.sf.jasperreports.engine.util.JRGraphEnvInitializer;
import net.sf.jasperreports.engine.util.JRProperties;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import javax.imageio.ImageIO;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.awt.image.BufferedImage;
import java.io.*;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;

/**
 * @author Johnson
 * @Date: 2011/01/15 上午 13:00:00
 */
public class ReportUtils extends BaseActionImpl {
    private static final long serialVersionUID = 8493308897579885228L;
    private Logger log = LogManager.getLogger(ReportUtils.class);

    /**
     * 相對於 Web 應用根路徑
     */
    public static final String WEB_PATH = "/jrxml/";
    public final static String JASPER = ".jasper";
    public final static String JRXML = ".jrxml";
    public final static String PDF = ".pdf";
    public final static String XLS = ".xls";
    public final static String HTML = ".html";
    /**
     * 子報表目錄
     */
    public final static String SUBREPORT_DIR = "SUBREPORT_DIR";

    /**
     * 報表要輸出的格式:PDF檔(1)
     *
     * @deprecated 改用 RptPoolmgt.FILE_TYPE_PDF
     */
    public final static String EXPORT_TYPE_PDF = "1";
    /**
     * 報表要輸出的格式:Excel檔(2)
     *
     * @deprecated 改用 RptPoolmgt.FILE_TYPE_EXCEL
     */
    public final static String EXPORT_TYPE_EXCEL = "2";
    /**
     * 報表要輸出的格式:HTML檔(3)
     *
     * @deprecated 改用 RptPoolmgt.FILE_TYPE_HTML
     */
    public final static String EXPORT_TYPE_HTML = "3";
    /**
     * 輸出格式：PRINTER(4)
     */
    public final static String EXPORT_TYPE_PRINTER = "4";
    /**
     * 輸出格式：OCTET_STREAM(5)
     */
    public final static String EXPORT_TYPE_OCTET_STREAM = "5";
    /**
     * 輸出格式：IMAGE(6)
     */
    public final static String EXPORT_TYPE_IMAGE = "6";

    /**
     * 產生報表的類型：檔案(1)
     */
    public final static String REPORT_TYPE_FILE = "1";
    /**
     * 產生報表的類型：串流(2)
     */
    public final static String REPORT_TYPE_STREAM = "2";

    /**
     * 報表要輸出的方式(內崁頁面上)
     */
    public final static String CONTENT_DISPOSITION_IN_LINE = "1";
    /**
     * 報表要輸出的方式(附加檔案)
     */
    public final static String CONTENT_DISPOSITION_ATTACHMENT = "2";

    /**
     * 顯示列印視窗參數名稱
     */
    public static final String SHOW_PRINT_DIALOG = "showPrintDialog";

    /**
     * 列印方向參數名稱
     */
    public static final String PRINT_ORIENTATION = "PrintOrientation";
    /**
     * 列印方向:直印
     */
    public static final String PRINT_ORIENTATION_PORTRAIT = "PORTRAIT";
    /**
     * 列印方向:橫印
     */
    public static final String PRINT_ORIENTATION_LANDSCAPE = "LANDSCAPE";

    private static DataSource dataSource;

    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        ReportUtils.dataSource = dataSource;
    }

    /**
     * 由 DataSource 內建立一個 Connection。<br>
     * 請務必要自行撰寫關閉程式碼。
     *
     * @return
     * @throws Exception
     */
    public Connection getConnection() throws Exception {
        Connection conn = null;
        try {
            conn = dataSource.getConnection();
            if (conn == null) {
                throw new Exception("取得connection為：" + conn);
            }
            return conn;
        } catch (SQLException ex) {
            throw new Exception("取得connection其失敗原因：" + ex.getMessage());
        }
    }

    private ReportBean reportBean;

    public ReportBean getReportBean() {
        return reportBean;
    }

    public void setReportBean(ReportBean reportBean) {
        this.reportBean = reportBean;
    }

    public String processSubReportPath(Map<String, String> parameterMap, String reportPath) {
        //設定子報表路徑
        try {
            parameterMap.put(SUBREPORT_DIR, getFilePathSpring(reportPath));
            return "";
        } catch (IOException ex) {
            log.error(ex.getMessage(), ex);
            this.setDspMessage("設定子報表路徑其失敗原因：：" + handleError1(ex) + "<br>");
            return ERROR;
        }
    }

    /**
     * 設定子報表路徑
     *
     * @param parameterMap 報表參數集合
     * @param reportPath   子報表路徑
     * @return "error" 代表設定失敗
     */
    public String processSubReportPath2(Map<String, Object> parameterMap, String reportPath) {
        //設定子報表路徑
        try {
            parameterMap.put(SUBREPORT_DIR, getFilePathSpring(reportPath));
            return "";
        } catch (IOException ex) {
            log.error(ex.getMessage(), ex);
            this.setDspMessage("設定子報表路徑其失敗原因：：" + handleError1(ex) + "<br>");
            return ERROR;
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public JasperPrint getJasperPrint(ReportBean reportBean) throws Exception {
        if (reportBean == null) {
            throw new Exception("reportBean為null<br>");
        }
        this.setReportBean(reportBean);

        if (StringUtils.isBlank(getReportBean().getExportType())) {
            throw new Exception("請設定exportType<br>");
        }
        log.debug(" Start : reportFileName >> " + reportBean.getReportFileName());

        if (getReportBean().getParameterMap() == null) {
            getReportBean().setParameterMap(new HashMap());
        }

        // 用於Excel匯出時的額外設定
        if (RptPoolmgt.FILE_TYPE_EXCEL.equals(getReportBean().getExportType())) {
            getReportBean().getParameterMap().put(
                    JRParameter.IS_IGNORE_PAGINATION,
                    getReportBean().getIsIgnorePagination());
        }

        return getJasperPrint();
    }

    /**
     * 輸出報表。<p>
     * <i>使用本 method，務必於外部程式實作 connection.close，請參看  {@link com.rfep.iv.report.IvReportActionImpl#printStoPallet} 寫法。</i>
     *
     * @param fileName           報表檔名
     * @param exportType         報表型態 (PDF, EXCEL, HTML)
     * @param contentDisposition 檔案採內嵌還是附加
     * @param jasperPrintList    報表物件list
     * @throws Exception
     */
    public void processJasperReport(String fileName, String exportType, String contentDisposition, List<JasperPrint> jasperPrintList) throws Exception {
        
		String fileNameUTF8 = java.net.URLEncoder.encode(fileName, "UTF-8");
		fileName = fileNameUTF8;
        OutputStream outputStream = null;
        try {
            outputStream = setupJasperReportResponseHeader(exportType, fileName, contentDisposition);

            JRPdfExporter exporter = new JRPdfExporter();
            exporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, fileName);
            exporter.setParameter(JRExporterParameter.JASPER_PRINT_LIST, jasperPrintList);
            exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outputStream);
            exporter.exportReport();
        } catch (Exception e) {
            throw e;
        } finally {
            if (outputStream != null) {
                outputStream.flush();
                outputStream.close();
            }
        }
    }

    /**
     * 配置Html Reponse Header
     *
     * @param exportType         報表型態 (PDF, EXCEL, HTML)
     * @param fileName           報表檔名
     * @param contentDisposition 檔案採內嵌還是附加
     * @return
     * @throws IOException
     */
    private OutputStream setupJasperReportResponseHeader(String exportType, String fileName, String contentDisposition) throws IOException {
        HttpServletResponse response = getReportBean().getResponse();
        response.reset();
        // 將 Server 連 Client 改為短連接，避免 java.net.SocketException:Connection reset
        response.addHeader("Connection", "Close");

        OutputStream outputStream = response.getOutputStream();

        String extensionName = null;
        if (RptPoolmgt.FILE_TYPE_PDF.equals(exportType)) {
            response.setContentType("application/pdf");
            extensionName = PDF;
        } else if (RptPoolmgt.FILE_TYPE_EXCEL.equals(exportType)) {
            response.setContentType("application/vnd.ms-excel");
            extensionName = XLS;
        } else if (RptPoolmgt.FILE_TYPE_HTML.equals(exportType)) {
            response.setContentType("text/html");
            response.addHeader("Title", fileName);
            extensionName = HTML;
        }

        String fileNameUTF8 = java.net.URLEncoder.encode(fileName, "UTF-8");
        if (CONTENT_DISPOSITION_IN_LINE.equals(contentDisposition)) {
            response.addHeader("Content-disposition", "inline ; filename*=utf-8''" + fileNameUTF8 + extensionName);// 附加檔案
            //response.addHeader("Content-disposition", "inline ; filename=" + fileName + extensionName);// 內崁檔案
        } else if (CONTENT_DISPOSITION_ATTACHMENT.equals(contentDisposition)) {
            response.addHeader("Content-disposition", "attachment ; filename*=utf-8''" + fileNameUTF8 + extensionName);// 附加檔案
            //response.addHeader("Content-disposition", "attachment ; filename=" + fileName + extensionName);// 附加檔案
        }

        return outputStream;
    }

    /**
     * 處理JasperReport
     *
     */
    public void processJasperReport(ReportBean reportBean) throws Exception {
    	//2021.05.06 [bug fix] 多request同時產報表時，全域變數reportBean被覆蓋問題
    	ReportUtils reportUtils = new ReportUtils();
    	reportUtils.setReportBean(reportBean);
    	reportUtils.processJasperReport();
    }
    
    /**
     * 處理JasperReport
     *
     * @throws Exception
     * @author Johnson
     * @Date: 2011/01/15 上午 13:00:00
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private void processJasperReport() throws Exception {
        if (reportBean == null) {
            throw new Exception("reportBean為null<br>");
        }
        try {
            if (StringUtils.isBlank(getReportBean().getExportType())) {
                throw new Exception("請設定exportType<br>");
            }
            log.debug(" Start : reportFileName >> " + reportBean.getReportFileName());

            if (getReportBean().getParameterMap() == null) {
                getReportBean().setParameterMap(new HashMap());
            }

            // 用於Excel匯出時的額外設定
            if (RptPoolmgt.FILE_TYPE_EXCEL.equals(getReportBean().getExportType())) {
                getReportBean().getParameterMap().put(JRParameter.IS_IGNORE_PAGINATION, getReportBean().getIsIgnorePagination());
            }

            if (RptPoolmgt.FILE_TYPE_PDF.equals(getReportBean().getExportType())) {
                genPDFtoWeb(setPdfParameter());
            } else if (RptPoolmgt.FILE_TYPE_EXCEL.equals(getReportBean().getExportType())) {
                genEXCELtoWeb(setXlsParameter());
            } else if (RptPoolmgt.FILE_TYPE_HTML.equals(getReportBean().getExportType())) {
                genHTMLtoWeb(setHtmlParameter());
            }
        } finally {
            if (this.getReportBean().getSourceConn() != null) {
                this.getReportBean().getSourceConn().close();
            }
        }
    }
    
    
    /**
     * 處理processJasperReportToFile
     *
     * @throws Exception
     * @author Johnson
     * @Date: 2011/01/15 上午 13:00:00
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    public File processJasperReportToFile(ReportBean reportBean) throws Exception {
        if (reportBean == null) {
            throw new Exception("reportBean為null<br>");
        }
        this.setReportBean(reportBean);

        try {
            if (StringUtils.isBlank(getReportBean().getExportType())) {
                throw new Exception("請設定exportType<br>");
            }

            if (getReportBean().getParameterMap() == null) {
                getReportBean().setParameterMap(new HashMap());
            }

            // 用於Excel匯出時的額外設定
            if (RptPoolmgt.FILE_TYPE_EXCEL.equals(getReportBean().getExportType())) {
                getReportBean().getParameterMap().put(
                        JRParameter.IS_IGNORE_PAGINATION,
                        getReportBean().getIsIgnorePagination());
            }

            if (RptPoolmgt.FILE_TYPE_PDF.equals(getReportBean().getExportType())) {
                return genPDFtoFile(setPdfParameter());
            } else if (RptPoolmgt.FILE_TYPE_EXCEL.equals(getReportBean().getExportType())) {
                return genEXCELtoFile(setXlsParameter());
            } else if (RptPoolmgt.FILE_TYPE_HTML.equals(getReportBean().getExportType())) {
                return genHTMLtoFile(setHtmlParameter());
            } else {
                return null;
            }
        } finally {
            if (this.getReportBean().getSourceConn() != null) {
                this.getReportBean().getSourceConn().close();
            }
        }
    }
    

    /**
     * 處理processJasperReportToDb
     */
    public byte[] processJasperReportToDb(ReportBean reportBean) throws Exception {
    	//2021.05.06 [bug fix] 多request同時產報表時，全域變數reportBean被覆蓋問題
    	ReportUtils reportUtils = new ReportUtils();
    	reportUtils.setReportBean(reportBean);
    	return reportUtils.processJasperReportToDb();
    }
    

    /**
     * 處理processJasperReportToDb
     *
     * @throws Exception
     * @author Johnson
     * @Date: 2011/01/15 上午 13:00:00
     */
    @SuppressWarnings({"unchecked", "rawtypes"})
    private byte[] processJasperReportToDb() throws Exception {
        if (reportBean == null) {
            throw new Exception("reportBean為null<br>");
        }
        try {
            if (StringUtils.isBlank(getReportBean().getExportType())) {
                throw new Exception("請設定exportType<br>");
            }

            if (getReportBean().getParameterMap() == null) {
                getReportBean().setParameterMap(new HashMap());
            }

            // 用於Excel匯出時的額外設定
            if (getReportBean().getExportType().equals(RptPoolmgt.FILE_TYPE_EXCEL)) {
                getReportBean().getParameterMap().put(
                        JRParameter.IS_IGNORE_PAGINATION,
                        getReportBean().getIsIgnorePagination());
            }

            if (RptPoolmgt.FILE_TYPE_PDF.equals(getReportBean().getExportType())) {
                return setPdfParameter();
            } else if (RptPoolmgt.FILE_TYPE_EXCEL.equals(getReportBean().getExportType())) {
                return setXlsParameter();
            } else if (RptPoolmgt.FILE_TYPE_HTML.equals(getReportBean().getExportType())) {
                return setHtmlParameter();
            }
        } finally {
            if (this.getReportBean().getSourceConn() != null) {
                this.getReportBean().getSourceConn().close();
            }
        }
        return null;
    }

    /**
     * 取得JasperPrint
     *
     * @return
     * @throws Exception
     * @author Johnson
     * @Date: 2011/01/15 上午 13:00:00
     */
    public JasperPrint getJasperPrint() throws Exception {

        if (getReportBean().getIsCompile() == null) {
            throw new Exception("請設定isCompile為true或false<br>");
        }
        if (getReportBean().getIsConnection() == null) {
            throw new Exception("請設定isConnection為true或false<br>");
        }

        // 判斷報表模版的設定,只能選其中一種
        if (StringUtils.isBlank(getReportBean().getJrxmlPathFileName())
                && StringUtils.isBlank(getReportBean().getJasperPathFileName())) {
            throw new Exception(
                    "請設定jrxmlPathFileName或jasperPathFileName其中一種<br>");
        } else if (StringUtils.isNotBlank(getReportBean()
                .getJrxmlPathFileName())
                && StringUtils.isNotBlank(getReportBean()
                .getJasperPathFileName())) {
            throw new Exception("請在jrxmlPathFileName和jasperPathFileName二選一<br>");
        }

        JasperPrint jasperPrint = null;
        InputStream jrxmlInputStream = null;
        InputStream jasperInputStream = null;
        try {
            if (getReportBean().getIsCompile()) {
                println("讀取未編譯的>>" + getReportBean().getJrxmlPathFileName());
                if (StringUtils.isBlank(getReportBean().getJrxmlPathFileName())) {
                    throw new Exception("請設定jrxmlPathFileName<br>");
                }
                // 讀取.jrxml檔案
                jrxmlInputStream = fileInputStream(getReportBean().getJrxmlPathFileName());
                // 將.jrxml檔案放到JasperDesign
                JasperDesign jasperDesign = JRXmlLoader.load(jrxmlInputStream);
                // 編譯Report
                JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
                if (getReportBean().getIsConnection()) {
                    println("讀取Connection的>>" + getReportBean().getSourceConn());
                    if (getReportBean().getSourceConn() == null) {
                        throw new Exception("請設定sourceConn<br>");
                    }
                    jasperPrint = JasperFillManager.fillReport(jasperReport, getReportBean().getParameterMap(), getReportBean().getSourceConn());
                    getReportBean().getSourceConn().close();
                } else {
                    println("讀取List的>>" + getReportBean().getSourceList());
                    if (getReportBean().getSourceList() == null) {
                        throw new Exception("請設定sourceList<br>");
                    }
                    jasperPrint = JasperFillManager.fillReport(jasperReport, getReportBean().getParameterMap(), new JRBeanCollectionDataSource(getReportBean().getSourceList()));
                }

            } else {
                println("讀取已編譯的>>" + getReportBean().getJasperPathFileName());
                if (StringUtils.isBlank(getReportBean().getJasperPathFileName())) {
                    throw new Exception("請設定jasperPathFileName<br>");
                }
                // 讀取.jasper檔案
                jasperInputStream = fileInputStream(getReportBean().getJasperPathFileName());
                if (getReportBean().getIsConnection()) {
                    println("讀取Connection的>>" + getReportBean().getSourceConn());
                    if (getReportBean().getSourceConn() == null) {
                        throw new Exception("請設定sourceConn<br>");
                    }
                    jasperPrint = JasperFillManager.fillReport(jasperInputStream, getReportBean().getParameterMap(), getReportBean().getSourceConn());

                    getReportBean().getSourceConn().close();
                } else {
                    println("讀取List的>>" + getReportBean().getSourceList());
                    if (getReportBean().getSourceList() == null) {
                        throw new Exception("請設定sourceList<br>");
                    }
                    jasperPrint = JasperFillManager.fillReport(jasperInputStream, getReportBean().getParameterMap(), new JRBeanCollectionDataSource(getReportBean().getSourceList()));
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        } finally {
            if (jrxmlInputStream != null) {
                jrxmlInputStream.close();
            }
            if (jasperInputStream != null) {
                jasperInputStream.close();
            }
        }
        return jasperPrint;
    }

    /**
     * 讀取模版
     *
     * @param PathFileName 可以傳入jrxmlPathFileName或jasperPathFileName
     * @return
     * @throws Exception
     * @author Johnson
     * @Date: 2011/01/15 上午 13:00:00
     */
    public InputStream fileInputStream(String PathFileName) throws Exception {
        InputStream inputStream = null;
        try {
            inputStream = getInputStreamSpring(PathFileName);
        } catch (FileNotFoundException ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception("讀取模版其失敗原因：" + ex.getMessage() + "<br>");
        } catch (IOException ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception("讀取模版其失敗原因：" + ex.getMessage() + "<br>");
        }

        return inputStream;
    }

    /**
     * 處理內容配置
     *
     * @throws Exception
     * @author Johnson
     * @Date: 2011/01/15 上午 13:00:00
     */
    private void processContentDisposition() throws Exception {
        String extensionName = "";
        getReportBean().getResponse().reset();
        // 將 Server 連 Client 改為短連接，避免 java.net.SocketException:Connection reset
        getReportBean().getResponse().addHeader("Connection", "Close");

        if (RptPoolmgt.FILE_TYPE_PDF.equals(getReportBean().getExportType())) {
            getReportBean().getResponse().setContentType("application/pdf");
            extensionName = PDF;
        } else if (RptPoolmgt.FILE_TYPE_EXCEL.equals(getReportBean().getExportType())) {
            getReportBean().getResponse().setContentType("application/vnd.ms-excel");
            extensionName = XLS;
        } else if (RptPoolmgt.FILE_TYPE_HTML.equals(getReportBean().getExportType())) {
            getReportBean().getResponse().setContentType("text/html");
            getReportBean().getResponse().addHeader("Title", processReportFileName());
            extensionName = HTML;
        } else {
            throw new Exception("exportType設定錯誤<br>");
        }

        if (StringUtils.isBlank(getReportBean().getContentDisposition())) {
            throw new Exception("請設定contentDisposition<br>");
        }

        if (getReportBean().getContentDisposition().equals(CONTENT_DISPOSITION_IN_LINE)) {
            getReportBean().getResponse().addHeader("Content-disposition", "inline ; filename*=utf-8''" + processReportFileName() + extensionName);// 內崁檔案
        } else if (getReportBean().getContentDisposition().equals(CONTENT_DISPOSITION_ATTACHMENT)) {
            getReportBean().getResponse().addHeader("Content-disposition", "attachment ; filename*=utf-8''" + processReportFileName() + extensionName);// 附加檔案
        } else {
            throw new Exception("contentDisposition設定錯誤<br>");
        }
    }

    /**
     * 處理報表檔案名稱的轉碼
     *
     * @return
     * @throws Exception
     * @author Johnson
     * @Date: 2011/01/15 上午 13:00:00
     */
    private String processReportFileName() throws Exception {
        if (StringUtils.isBlank(getReportBean().getReportFileName())) {
            throw new Exception("請設定reportFileName<br>");
        }

        try {
            return java.net.URLEncoder.encode(getReportBean().getReportFileName(), "UTF-8");
            //return new String(getReportBean().getReportFileName().getBytes("big5"), "ISO8859-1");// 中文時會有亂數
        } catch (UnsupportedEncodingException ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception("報表名稱轉碼其失敗原因：" + ex.getMessage() + "<br>");
        }
    }

    /**
     * PDF的內部參數設定
     *
     * @return
     * @throws JRException
     * @throws Exception
     * @author Johnson
     * @Date: 2011/01/15 上午 13:00:00
     */
    private byte[] setPdfParameter() throws JRException, Exception {
        return JasperExportManager.exportReportToPdf(getJasperPrint());
    }

    /**
     * PDF的內部參數設定<br>
     * 帶入JasperPrint
     *
     * @param jasperPrint
     * @return
     * @throws JRException
     * @throws Exception
     */
    public byte[] setPdfParameter(JasperPrint jasperPrint) throws JRException, Exception {
        return JasperExportManager.exportReportToPdf(jasperPrint);
    }

    /**
     * Excel的內部參數設定
     *
     * @return
     * @throws JRException
     * @throws Exception
     * @author Johnson
     * @Date: 2011/01/15 上午 13:00:00
     */
    private byte[] setXlsParameter() throws JRException, Exception {
        byte bytes[] = null;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            JExcelApiExporter exporter = new JExcelApiExporter();
            exporter.setParameter(JExcelApiExporterParameter.JASPER_PRINT, getJasperPrint());
            exporter.setParameter(JExcelApiExporterParameter.OUTPUT_STREAM, byteArrayOutputStream);

            exporter.setParameter(JExcelApiExporterParameter.IS_WHITE_PAGE_BACKGROUND, getReportBean().getIsWhitePageBackground());

            //下面這行是讓excel的字串變成數值
            exporter.setParameter(JExcelApiExporterParameter.IS_DETECT_CELL_TYPE, Boolean.TRUE);
            exporter.exportReport();
            bytes = byteArrayOutputStream.toByteArray();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw e;
        } finally {
            if (byteArrayOutputStream != null) {
                byteArrayOutputStream.flush();
                byteArrayOutputStream.close();
            }

        }

        return bytes;
    }

    /**
     * Excel的內部參數設定
     */
    protected byte[] setXlsParameter(JasperPrint jasperPrint) throws JRException, Exception {
        byte bytes[] = null;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            JExcelApiExporter exporter = new JExcelApiExporter();
            exporter.setParameter(JExcelApiExporterParameter.JASPER_PRINT, jasperPrint);
            exporter.setParameter(JExcelApiExporterParameter.OUTPUT_STREAM, byteArrayOutputStream);

            exporter.setParameter(JExcelApiExporterParameter.IS_WHITE_PAGE_BACKGROUND, getReportBean().getIsWhitePageBackground());

            //下面這行是讓excel的字串變成數值
            exporter.setParameter(JExcelApiExporterParameter.IS_DETECT_CELL_TYPE, Boolean.TRUE);
            exporter.exportReport();
            bytes = byteArrayOutputStream.toByteArray();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw e;
        } finally {
            byteArrayOutputStream.flush();
            byteArrayOutputStream.close();
        }

        return bytes;
    }

    /**
     * Excel的內部參數設定(不需要ReportBean)
     *
     * @param jasperPrint
     * @return
     * @throws JRException
     * @throws Exception
     */
    protected byte[] setXlsParameterNoReportBean(JasperPrint jasperPrint) throws JRException, Exception {
        byte bytes[] = null;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            JExcelApiExporter exporter = new JExcelApiExporter();
            exporter.setParameter(JExcelApiExporterParameter.JASPER_PRINT, jasperPrint);
            exporter.setParameter(JExcelApiExporterParameter.OUTPUT_STREAM, byteArrayOutputStream);

            exporter.setParameter(JExcelApiExporterParameter.IS_WHITE_PAGE_BACKGROUND, false);

            //下面這行是讓excel的字串變成數值
            exporter.setParameter(JExcelApiExporterParameter.IS_DETECT_CELL_TYPE, Boolean.TRUE);
            exporter.exportReport();
            bytes = byteArrayOutputStream.toByteArray();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw e;
        } finally {
            byteArrayOutputStream.flush();
            byteArrayOutputStream.close();
        }

        return bytes;
    }

    /**
     * HTML的內部參數設定
     *
     * @return
     * @throws Exception
     * @author Johnson
     * @Date: 2011/01/15 上午 13:00:00
     */
    private byte[] setHtmlParameter() throws Exception {
        byte bytes[] = null;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try {
            JRHtmlExporter exporter = new JRHtmlExporter();
            exporter.setParameter(JRHtmlExporterParameter.JASPER_PRINT, getJasperPrint());
            exporter.setParameter(JRHtmlExporterParameter.OUTPUT_STREAM, byteArrayOutputStream);
            exporter.setParameter(JRHtmlExporterParameter.CHARACTER_ENCODING, "Big5");
            exporter.setParameter(JRHtmlExporterParameter.IS_USING_IMAGES_TO_ALIGN, Boolean.FALSE);
            exporter.setParameter(JRHtmlExporterParameter.IMAGES_MAP, null);
            exporter.setParameter(JRHtmlExporterParameter.IMAGES_URI, "image?image=");
            exporter.setParameter(JRHtmlExporterParameter.BETWEEN_PAGES_HTML, "<div style='page-break-before:always;'></div>");
            exporter.setParameter(JRHtmlExporterParameter.IS_USING_IMAGES_TO_ALIGN, Boolean.FALSE);
            exporter.setParameter(JRHtmlExporterParameter.HTML_HEADER, "<table width=\"100%\" cellpadding=\"1\" cellspacing=\"0\" border=\"1\"><tr><td>");
            exporter.setParameter(JRHtmlExporterParameter.HTML_FOOTER, "</td></tr></table>");
            exporter.exportReport();
            bytes = byteArrayOutputStream.toByteArray();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw e;
        } finally {
            byteArrayOutputStream.flush();
            byteArrayOutputStream.close();
        }
        return bytes;
    }

    /**
     * 將PDF輸出到Client端瀏覽器
     *
     * @param bytes
     * @throws Exception
     * @author Johnson
     * @Date: 2011/01/15 上午 13:00:00
     */
    public void genPDFtoWeb(byte[] bytes) throws Exception {
        try {
            processWebOutput(bytes);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception("產生PDF檔發生錯誤:" + ex.getMessage());
        }
    }

    /**
     * 產生影像檔並轉換成 Base64 格式。
     *
     * @param jasperPrint 報表物件
     * @param zoom        放大比率(因使用原始大小，之後使用標籤機列印會失真，所以要先放大，預設帶 10 倍)
     * @return
     * @throws Exception
     */
    public byte[] genImageToByteArray(JasperPrint jasperPrint, int zoom) throws Exception {
        byte bytes[] = null;
        // 預設帶 10 倍
        if (zoom <= 0) zoom = 10;

        JRGraphEnvInitializer.initializeGraphEnv();

        BufferedImage pageImage = new BufferedImage(
                (int) (jasperPrint.getPageWidth() * zoom),
                (int) (jasperPrint.getPageHeight() * zoom),
                BufferedImage.TYPE_3BYTE_BGR
        );

        JRGraphics2DExporter exporter = new JRGraphics2DExporter();
        exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
        exporter.setParameter(JRGraphics2DExporterParameter.GRAPHICS_2D, pageImage.createGraphics());
        exporter.setParameter(JRExporterParameter.PAGE_INDEX, new Integer(0));
        exporter.setParameter(JRGraphics2DExporterParameter.ZOOM_RATIO, new Float(zoom));

        exporter.exportReport();

        ByteArrayOutputStream result = new ByteArrayOutputStream();
        try {
            ImageIO.write(pageImage, "png", result);
            bytes = result.toByteArray();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw e;
        } finally {
            result.flush();
            result.close();
        }
        return bytes;
    }

    /**
     * 將EXCEL輸出到Client端瀏覽器
     *
     * @param bytes
     * @throws Exception
     * @author Johnson
     * @Date: 2011/01/15 上午 13:00:00
     */
    public void genEXCELtoWeb(byte[] bytes) throws Exception {
        try {
            processWebOutput(bytes);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception("產生Excel檔發生錯誤:" + ex.getMessage());
        }
    }

    /**
     * 將HTML輸出到Client端瀏覽器
     *
     * @param bytes
     * @throws Exception
     * @author Johnson
     * @Date: 2011/01/15 上午 13:00:00
     */
    public void genHTMLtoWeb(byte[] bytes) throws Exception {
        try {
            processWebOutput(bytes);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception("產生HTML檔發生錯誤:" + ex.getMessage());
        }
    }

    /**
     * 將PDF輸出到Server端的硬碟某一個位置
     *
     * @param bytes
     * @throws Exception
     * @author Johnson
     * @Date: 2011/01/15 上午 13:00:00
     */
    public File genPDFtoFile(byte[] bytes) throws Exception {

        File file = null;
        try {
            file = processFileOutput(bytes);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            throw new Exception("Server端,產生PDF檔發生錯誤:" + ex.getMessage());
        }
        return file;
    }

    /**
     * 將EXCEL輸出到Server端的硬碟某一個位置
     *
     * @param bytes
     * @throws Exception
     * @author Johnson
     * @Date: 2011/01/15 上午 13:00:00
     */
    public File genEXCELtoFile(byte[] bytes) throws Exception {

        File file = null;
        try {
            file = processFileOutput(bytes);
        } catch (Exception ex) {
            log.error("Server端,產生Excel檔發生錯誤:" + ex.getMessage(), ex);
        }
        return file;
    }

    /**
     * 將HTML輸出到Server端的硬碟某一個位置
     *
     * @param bytes
     * @throws Exception
     * @author Johnson
     * @Date: 2011/01/15 上午 13:00:00
     */
    public File genHTMLtoFile(byte[] bytes) throws Exception {

        File file = null;
        try {
            file = processFileOutput(bytes);
        } catch (Exception ex) {
            log.error("Server端,產生Excel檔發生錯誤:" + ex.getMessage(), ex);
        }
        return file;
    }

    /**
     * 報表將輸出在Server端
     *
     * @param bytes
     * @throws FileNotFoundException
     * @throws Exception
     * @author Johnson
     * @Date: 2011/01/15 上午 13:00:00
     */
    private synchronized File processFileOutput(byte[] bytes) throws FileNotFoundException, Exception {

        FileOutputStream fileOutputStream = null;
        File file = null;

        try {
            //將暫存檔存至WEB-INF/classes/tmp目錄
            String path = ReportUtils.class.getResource("/").getPath() + "tmp/";
            File createFile = new File(path);
            if (!createFile.exists()) {
                createFile.mkdirs();
            }

            String fileName = getReportBean().getReportFileName();
			int idx = fileName.indexOf('-') + 1;
            if (idx > 0)
            	fileName = fileName.substring(idx);
			
            if (fileName.length() > 9)
            	fileName = fileName.substring(0, 9);
			
            if (RptPoolmgt.FILE_TYPE_PDF.equals(getReportBean().getExportType())) 
                fileName = fileName + PDF;
			else if (RptPoolmgt.FILE_TYPE_EXCEL.equals(getReportBean().getExportType())) 
                fileName = fileName + XLS;
			else if (RptPoolmgt.FILE_TYPE_HTML.equals(getReportBean().getExportType())) 
                fileName = fileName + HTML;

            String fileNameUTF8 = "=?UTF-8?B?" + java.util.Base64.getEncoder().encodeToString(fileName.getBytes()) + "?=";
            file = new File(path + fileNameUTF8);
            fileOutputStream = new FileOutputStream(file);
            fileOutputStream.write(bytes);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw e;
        } finally {
            if (fileOutputStream != null) {
                fileOutputStream.flush();
                fileOutputStream.close();
            }
        }

        return file;
    }

    /**
     * 報表將輸出在Client端
     *
     * @param bytes
     * @throws Exception
     * @author Johnson
     * @Date: 2011/01/15 上午 13:00:00
     */
    private void processWebOutput(byte[] bytes) throws Exception {
        processContentDisposition();
        OutputStream ouputStream = null;
        try {
            ouputStream = getReportBean().getResponse().getOutputStream();
            log.debug(" \nEnd : reportFileName >> " + getReportBean().getReportFileName() + " \nouputStream >> " + ouputStream + " bytes.length >> " + bytes.length);
            ouputStream.write(bytes);

        } catch (Exception e) {
            log.error(e.getMessage(), e);
            throw e;
        } finally {
            if (ouputStream != null) {
                ouputStream.flush();
                log.debug(" outputStream.flush ! ");
                ouputStream.close();
                log.debug(" outputStream.close ! ");
            }
        }
    }

    @SuppressWarnings("rawtypes")
    public String processStrDateBetween(Map queryCondition, String fromStart, String toEnd) {
        String fromStart1 = getMapValueToString(queryCondition, fromStart);
        String toEnd1 = getMapValueToString(queryCondition, toEnd);
        if (StringUtils.isBlank(fromStart1) && StringUtils.isBlank(toEnd1)) {
            return "";
        } else {
            return fromStart1 + "~" + toEnd1;
        }
    }

    /**
     * 建立狀態為執行中的 RptPoolmgt 物件。
     *
     * @param systemId       子系統代碼
     * @param queryCondition 查詢條件
     * @param rptPoolmgt
     * @param reportFileName 報表名稱
     * @param exportType     報表類型(1:PDF、2:Excel)
     * @return
     * @deprecated 改用 new RptPoolmgt()
     */
    @SuppressWarnings("rawtypes")
    public RptPoolmgt procDbData(String systemId, Map queryCondition, RptPoolmgt rptPoolmgt, String reportFileName, String exportType) {
        //FIXME 改實作方法
        rptPoolmgt.setChannelId(getMapValueToString(queryCondition, "channelId"));
        rptPoolmgt.setStoreId(getMapValueToString(queryCondition, "storeId"));
        rptPoolmgt.setSystemId(systemId);
        rptPoolmgt.setFileName(reportFileName);
        if (RptPoolmgt.FILE_TYPE_PDF.equals(exportType)) {
            rptPoolmgt.setFileType(1);
        } else if (RptPoolmgt.FILE_TYPE_EXCEL.equals(exportType)) {
            rptPoolmgt.setFileType(2);
        }
        rptPoolmgt.setPrtId(getMapValueToString(queryCondition, "rptId"));
        rptPoolmgt.setPrtName(reportFileName);
        rptPoolmgt.setRunDate(new Date());
        rptPoolmgt.setRunUserid(getMapValueToString(queryCondition, "userId"));
        rptPoolmgt.setRunUsername(getMapValueToString(queryCondition, "userName"));
        rptPoolmgt.setStatus(0);
        return rptPoolmgt;
    }

    /**
     * 將sql裡的 ? 替換成參數
     *
     * @param sql
     * @param params
     * @return
     */
    public String injectAllParams(String sql, Object[] params) {

        if (params.length == 0) {
            return sql;
        }

        int arrayIndex = 0;

        while (sql.indexOf("?") != -1) {
            sql = sql.replaceFirst("\\?", String.valueOf(params[arrayIndex++]));
        }

        return sql;
    }

    /**
     * 依據副檔名為 jrxml 的 reportFileName 產生 JasperPrint。
     *
     * @param reportFileName : 檔案名稱
     * @param result         : 報表資料
     * @param parameterMap   :　報表參數
     * @throws Exception
     */
    @SuppressWarnings("rawtypes")
    public JasperPrint genJasperPrint(String reportFileName, List result, Map parameterMap) throws Exception {
        String CompilePath = JRProperties.getProperty(JRProperties.COMPILER_TEMP_DIR);
        JRProperties.setProperty(JRProperties.COMPILER_CLASSPATH, CompilePath + "/jasperreports-3.0.0.jar");
        InputStream reportStream = null;
        try {
            String printOrientation = (String) parameterMap.get(PRINT_ORIENTATION);
            // 載入JRXML檔案
            reportStream = ServletActionContext.getServletContext().getResourceAsStream(WEB_PATH + reportFileName + JRXML);
            JasperDesign jasperDesign = JRXmlLoader.load(reportStream);
            JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
            // 將資料載入
            JRBeanCollectionDataSource ds = new JRBeanCollectionDataSource(result);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameterMap, ds);
            if (StringUtils.isNotBlank(printOrientation)) {
                if (printOrientation.equals(PRINT_ORIENTATION_PORTRAIT))
                    jasperPrint.setOrientation(JRReport.ORIENTATION_PORTRAIT);
                else
                    jasperPrint.setOrientation(JRReport.ORIENTATION_LANDSCAPE);
            }

            return jasperPrint;
        } catch (JRException jre) {
            log.error("無法產生報表:" + reportFileName, jre);
            return null;
        } catch (Exception e) {
            log.error("無法產生報表:" + reportFileName, e);
            return null;
        } finally {
            if (reportStream != null) {
                reportStream.close();
            }
        }
    }

    /**
     * processReport : 依報表型態產生報表
     *
     * @param reportName     : 報表中文名稱
     * @param reportFileName : 檔案名稱
     * @param result         : 報表資料
     * @param parameterMap   :　報表參數
     * @param response       ： HttpServletResponse
     * @throws Exception
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    public void processReport(String reportName, String reportFileName, List result, Map parameterMap, HttpServletResponse response) throws Exception {
        PrintWriter out = null;
        // 載入JRXML檔案
        String CompilePath = JRProperties.getProperty(JRProperties.COMPILER_TEMP_DIR);
        JRProperties.setProperty(JRProperties.COMPILER_CLASSPATH, CompilePath + "/jasperreports-3.0.0.jar");
        FileInputStream inputStream = null;
        InputStream reportStream = null;

        try {
            String reportType = (String) parameterMap.get("reportType") != null ? (String) parameterMap.get("reportType") : REPORT_TYPE_STREAM;
            String exportType = (String) parameterMap.get("exportType") != null ? (String) parameterMap.get("exportType") : EXPORT_TYPE_PDF;
            String contentDisposition = (String) parameterMap.get("contentDisposition") != null ? (String) parameterMap.get("contentDisposition") : CONTENT_DISPOSITION_IN_LINE;
            boolean showPrintDialog = (Boolean) parameterMap.get(SHOW_PRINT_DIALOG) != null ? ((Boolean) parameterMap.get(SHOW_PRINT_DIALOG)).booleanValue() : false;
            String printOrientation = (String) parameterMap.get(PRINT_ORIENTATION);

            // 中文時有亂數
            //reportName = new String((reportName.getBytes("big5")), "ISO8859-1");

            // 商品變價報表特別處理Night Run, 因 night run 無法藉由 ServletContext 取 path, 改用 Hot Code 強制規定路徑。
            if ("SkuTransReport".equals(reportFileName)) {
                //inputStream = new FileInputStream(ResourceUtils.getFile(SkuTransReportJob.CLASS_PATH + reportFileName + JRXML));
                inputStream = new FileInputStream(BaseUtil.getFileSpring(SkuTransReportJob.CLASS_PATH + reportFileName + JRXML));
            } else {
                reportStream = ServletActionContext.getServletContext().getResourceAsStream(WEB_PATH + reportFileName + JRXML);
            }
            JasperDesign jasperDesign = null;
            if (reportStream != null) {
                jasperDesign = JRXmlLoader.load(reportStream);
            } else {
                jasperDesign = JRXmlLoader.load(inputStream);
            }
            JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);

            // 將資料載入
            JRBeanCollectionDataSource ds = new JRBeanCollectionDataSource(result);
            JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameterMap, ds);

            if (StringUtils.isNotBlank(printOrientation)) {
                if (printOrientation.equals(PRINT_ORIENTATION_PORTRAIT))
                    jasperPrint.setOrientation(JRReport.ORIENTATION_PORTRAIT);
                else
                    jasperPrint.setOrientation(JRReport.ORIENTATION_LANDSCAPE);
            }

            if (exportType.equals(EXPORT_TYPE_EXCEL)) {
                // Excel每頁不要有表頭
                parameterMap.put(JRParameter.IS_IGNORE_PAGINATION, Boolean.TRUE);
            }

            if (reportType.equals(REPORT_TYPE_STREAM)) {
                if (exportType.equals(EXPORT_TYPE_PDF)) {
                    genPDF(jasperPrint, response, reportName, contentDisposition);
                } else if (exportType.equals(EXPORT_TYPE_HTML)) {
                    genHTML(jasperPrint, response, reportName, contentDisposition);
                } else if (exportType.equals(EXPORT_TYPE_EXCEL)) {
                    genEXCEL(jasperPrint, response, reportName, contentDisposition);
                } else if (exportType.equals(EXPORT_TYPE_PRINTER)) {
                    autoPrint(jasperPrint, showPrintDialog);
                } else if (exportType.equals(EXPORT_TYPE_OCTET_STREAM)) {
                    printForApplet(jasperPrint, response);
                }
            } else if (reportType.equals(REPORT_TYPE_FILE)) {
                if (exportType.equals(EXPORT_TYPE_PDF)) {
                    genPDFtoFile(jasperPrint, response, reportName);
                } else if (exportType.equals(EXPORT_TYPE_HTML)) {
                    genHTMLtoFile(jasperPrint, response, reportName);
                } else if (exportType.equals(EXPORT_TYPE_EXCEL)) {
                    genEXCELtoFile(jasperPrint, response, reportName);
                }
            }
        } catch (JRException jre) {
            log.error("無法產生報表:" + new String((reportName.getBytes("ISO8859-1")), "big5"), jre);
            response.setContentType("text/html");
            response.setCharacterEncoding("UTF-8");
            out = response.getWriter();
            out.println("<html>");
            out.println("\t<body>");
            out.println("\t\t<br /><br />");
            out.println("\t\t無法產生報表");
            out.println("\t\t<br /><br />");
            out.println("\t\t錯誤訊息 ==> " + jre.getLocalizedMessage());
            out.println("\t\t<br />");
            out.println("\t\t錯誤原因 ==> " + jre.getCause());
            out.println("\t</body>");
            out.println("\t</html>");
        } catch (Exception e) {
            log.error("無法產生報表:" + new String((reportName.getBytes("ISO8859-1")), "big5"), e);
            response.setContentType("text/html");
            response.setCharacterEncoding("UTF-8");
            out = response.getWriter();
            out.println("<html>");
            out.println("\t<body>");
            out.println("\t\t<br /><br />");
            out.println("\t\t無法產生報表");
            out.println("\t\t<br /><br />");
            out.println("\t\t錯誤訊息 ==> " + e.getLocalizedMessage());
            out.println("\t\t<br />");
            out.println("\t\t錯誤原因 ==> " + e.getCause());
            out.println("\t</body>");
            out.println("</html>");
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
            if (reportStream != null) {
                reportStream.close();
            }
        }
    }

    /**
     * genPDF : 產生Pdf報表
     *
     * @param jasperPrint        : JasperPrint
     * @param response           : HttpServletResponse
     * @param fileName           : 檔案名稱
     * @param contentDisposition : response header格式
     */
    private void genPDF(JasperPrint jasperPrint, HttpServletResponse response,
                        String fileName, String contentDisposition) {
        ServletOutputStream outstream = null;
        try {
            byte bytes[] = JasperExportManager.exportReportToPdf(jasperPrint);
            outstream = response.getOutputStream();

            response.setContentType("application/pdf");
            response.setContentLength(bytes.length);

            String fileNameUTF8 = java.net.URLEncoder.encode(fileName, "UTF-8");
            if (contentDisposition.equals(CONTENT_DISPOSITION_IN_LINE)) {
                response.setHeader("Content-disposition", "inline ; filename*=utf-8''" + fileNameUTF8 + ".pdf");// 附加檔案
                //response.setHeader("Content-disposition", "inline ; filename=" + fileName + ".pdf");// 內崁檔案
            } else if (contentDisposition.equals(CONTENT_DISPOSITION_ATTACHMENT)) {
                response.setHeader("Content-disposition", "attachment ; filename*=utf-8''" + fileNameUTF8 + ".pdf");// 附加檔案
                //response.setHeader("Content-disposition", "attachment ; filename=" + fileName + ".pdf");// 附加檔案
            }
            outstream.write(bytes);

        } catch (Exception ex) {
            log.error("產生PDF檔發生錯誤:" + ex.getMessage(), ex);
            return;
        } finally {
            if (outstream != null) {
                try {
                    outstream.flush();
                    outstream.close();
                } catch (IOException e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
    }

    /**
     * genHTML : 產生Html報表
     *
     * @param jasperPrint        : JasperPrint
     * @param response           : HttpServletResponse
     * @param fileName           : 檔案名稱
     * @param contentDisposition : response header格式
     */
    private void genHTML(JasperPrint jasperPrint, HttpServletResponse response, String fileName, String contentDisposition) {
        ByteArrayOutputStream htmlOutStream = new ByteArrayOutputStream();
        OutputStream ouputStream = null;
        try {
            JRHtmlExporter exporter = new JRHtmlExporter();

            exporter.setParameter(JRHtmlExporterParameter.JASPER_PRINT, jasperPrint);
            exporter.setParameter(JRHtmlExporterParameter.OUTPUT_STREAM, htmlOutStream);
            exporter.setParameter(JRHtmlExporterParameter.CHARACTER_ENCODING, "Big5");
            exporter.setParameter(JRHtmlExporterParameter.IS_USING_IMAGES_TO_ALIGN, Boolean.FALSE);
            exporter.setParameter(JRHtmlExporterParameter.IMAGES_MAP, null);
            exporter.setParameter(JRHtmlExporterParameter.IMAGES_URI, "image?image=");
            exporter.setParameter(JRHtmlExporterParameter.BETWEEN_PAGES_HTML, "<div style='page-break-before:always;'></div>");
            exporter.setParameter(JRHtmlExporterParameter.IS_USING_IMAGES_TO_ALIGN, Boolean.FALSE);
            exporter.setParameter(JRHtmlExporterParameter.HTML_HEADER, "<table width=\"100%\" cellpadding=\"1\" cellspacing=\"0\" border=\"1\"><tr><td>");
            exporter.setParameter(JRHtmlExporterParameter.HTML_FOOTER, "</td></tr></table>");
            exporter.exportReport();

            byte bytes[] = htmlOutStream.toByteArray();
            htmlOutStream.close();
            response.reset();
            response.setContentType("text/html");
            response.setHeader("Title", fileName);

            String fileNameUTF8 = java.net.URLEncoder.encode(fileName, "UTF-8");
            if (contentDisposition.equals(CONTENT_DISPOSITION_IN_LINE)) {
                response.setHeader("Content-disposition", "inline ; filename*=utf-8''" + fileNameUTF8 + ".html");// 附加檔案
                //response.setHeader("Content-disposition", "inline ; filename=" + fileName + ".html");// 內崁檔案
            } else if (contentDisposition.equals(CONTENT_DISPOSITION_ATTACHMENT)) {
                response.setHeader("Content-disposition", "attachment ; filename*=utf-8''" + fileNameUTF8 + ".html");// 附加檔案
                //response.setHeader("Content-disposition", "attachment ; filename=" + fileName + ".html");// 附加檔案
            }
            ouputStream = response.getOutputStream();
            ouputStream.write(bytes, 0, bytes.length);

        } catch (Exception ex) {
            log.error("產生Html檔發生錯誤:" + ex.getMessage(), ex);
        } finally {
            try {
                if (htmlOutStream != null) {
                    htmlOutStream.flush();
                    htmlOutStream.close();
                }

                if (ouputStream != null) {

                    ouputStream.flush();
                    ouputStream.close();
                }
            } catch (IOException e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    /**
     * genEXCEL : 產生Excel報表
     *
     * @param jasperPrint        : JasperPrint
     * @param response           : HttpServletResponse
     * @param fileName           : 檔案名稱
     * @param contentDisposition : response header格式
     */
    private void genEXCEL(JasperPrint jasperPrint, HttpServletResponse response, String fileName, String contentDisposition) {
        OutputStream ouputStream = null;
        ByteArrayOutputStream xlsOutStream = new ByteArrayOutputStream();
        try {
            JExcelApiExporter exporter = new JExcelApiExporter();
            exporter.setParameter(JExcelApiExporterParameter.JASPER_PRINT, jasperPrint);
            exporter.setParameter(JExcelApiExporterParameter.OUTPUT_STREAM, xlsOutStream);
            exporter.exportReport();
            byte bytes[] = xlsOutStream.toByteArray();

            response.reset();
            response.setContentType("application/vnd.ms-excel");
            String fileNameUTF8 = java.net.URLEncoder.encode(fileName, "UTF-8");
            if (contentDisposition.equals(CONTENT_DISPOSITION_IN_LINE)) {
                response.setHeader("Content-disposition", "inline ; filename*=utf-8''" + fileNameUTF8 + ".xls");// 附加檔案
                //response.setHeader("Content-disposition", "inline ; filename=" + fileName + ".xls");// 內崁檔案
            } else if (contentDisposition.equals(CONTENT_DISPOSITION_ATTACHMENT)) {
                response.setHeader("Content-disposition", "attachment ; filename*=utf-8''" + fileNameUTF8 + ".xls");// 附加檔案
                //response.setHeader("Content-disposition", "attachment ; filename=" + fileName + ".xls");// 附加檔案
            }
            ouputStream = response.getOutputStream();
            ouputStream.write(bytes, 0, bytes.length);

        } catch (Exception ex) {
            log.error("產生Excel檔發生錯誤:" + ex.getMessage(), ex);
            return;
        } finally {
            try {
                if (ouputStream != null) {
                    ouputStream.flush();
                    ouputStream.close();
                }
            } catch (IOException e) {
                log.error(e.getMessage(), e);
            }
            if (xlsOutStream != null) {
                try {
                    xlsOutStream.flush();
                    xlsOutStream.close();
                } catch (IOException e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
    }

    private void autoPrint(JasperPrint jasperPrint, boolean showPrintDialog) {
        try {
            JasperPrintManager.printReport(jasperPrint, showPrintDialog);
        } catch (JRException e) {
            log.error(e.getMessage(), e);
        }
    }

    private void printForApplet(JasperPrint jasperPrint, HttpServletResponse response) {
        List<JasperPrint> prints = new ArrayList<JasperPrint>();
        prints.add(jasperPrint);

        response.setContentType("application/octet-stream");
        ServletOutputStream ouputStream = null;
        ObjectOutputStream oos = null;
        try {
            ouputStream = response.getOutputStream();
            oos = new ObjectOutputStream(ouputStream);
            oos.writeObject(prints);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        } finally {
            if (oos != null) {
                try {
                    oos.flush();
                    oos.close();
                } catch (IOException e) {
                    log.error(e.getMessage(), e);
                }
            }
            if (ouputStream != null) {
                try {
                    ouputStream.flush();
                    ouputStream.close();
                } catch (IOException e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
    }

    /**
     * genPDFtoFile : 產生Pdf報表檔案
     *
     * @param jasperPrint : JasperPrint
     * @param response    : HttpServletResponse
     * @param fileName    : 檔案名稱
     */
    private void genPDFtoFile(JasperPrint jasperPrint, HttpServletResponse response, String fileName) {
        FileOutputStream fileOutputStream = null;
        try {
            byte bytes[] = JasperExportManager.exportReportToPdf(jasperPrint);
            fileOutputStream = new FileOutputStream(new File("C:\\" + fileName + ".pdf"));
            fileOutputStream.write(bytes, 0, bytes.length);

        } catch (Exception ex) {
            log.error("產生PDF檔發生錯誤:" + ex.getMessage(), ex);
            return;
        } finally {
            if (fileOutputStream != null) {
                try {
                    fileOutputStream.flush();
                    fileOutputStream.close();
                } catch (IOException e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
    }

    /**
     * genHTMLtoFile : 產生Html報表檔案
     *
     * @param jasperPrint : JasperPrint
     * @param response    : HttpServletResponse
     * @param fileName    : 檔案名稱
     */
    private void genHTMLtoFile(JasperPrint jasperPrint, HttpServletResponse response, String fileName) {
        FileOutputStream fileOutputStream = null;
        try {
            JRHtmlExporter exporter = new JRHtmlExporter();
            ByteArrayOutputStream htmlOutStream = new ByteArrayOutputStream();
            exporter.setParameter(JRHtmlExporterParameter.JASPER_PRINT, jasperPrint);
            exporter.setParameter(JRHtmlExporterParameter.OUTPUT_STREAM, htmlOutStream);
            exporter.setParameter(JRHtmlExporterParameter.CHARACTER_ENCODING, "Big5");
            exporter.setParameter(JRHtmlExporterParameter.IS_USING_IMAGES_TO_ALIGN, Boolean.FALSE);
            exporter.setParameter(JRHtmlExporterParameter.IMAGES_MAP, null);
            exporter.setParameter(JRHtmlExporterParameter.IMAGES_URI, "image?image=");
            exporter.setParameter(JRHtmlExporterParameter.BETWEEN_PAGES_HTML, "<div style='page-break-before:always;'></div>");
            exporter.setParameter(JRHtmlExporterParameter.IS_USING_IMAGES_TO_ALIGN, Boolean.FALSE);
            exporter.setParameter(JRHtmlExporterParameter.HTML_HEADER, "<table width=\"100%\" cellpadding=\"1\" cellspacing=\"0\" border=\"1\"><tr><td>");
            exporter.setParameter(JRHtmlExporterParameter.HTML_FOOTER, "</td></tr></table>");
            exporter.exportReport();

            byte bytes[] = htmlOutStream.toByteArray();
            fileOutputStream = new FileOutputStream(new File("C:\\" + fileName + ".html"));
            fileOutputStream.write(bytes, 0, bytes.length);
            fileOutputStream.close();
        } catch (Exception ex) {
            log.error("產生Html檔發生錯誤:" + ex.getMessage(), ex);
        } finally {
            if (fileOutputStream != null) {
                try {
                    fileOutputStream.flush();
                    fileOutputStream.close();
                } catch (IOException e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
    }

    /**
     * genEXCELtoFile : 產生Excel報表檔案
     *
     * @param jasperPrint : JasperPrint
     * @param response    : HttpServletResponse
     * @param fileName    : 檔案名稱
     */
    private void genEXCELtoFile(JasperPrint jasperPrint, HttpServletResponse response, String fileName) {
        FileOutputStream fileOutputStream = null;
        try {
            JExcelApiExporter exporter = new JExcelApiExporter();
            ByteArrayOutputStream xlsOutStream = new ByteArrayOutputStream();
            exporter.setParameter(JExcelApiExporterParameter.JASPER_PRINT, jasperPrint);
            exporter.setParameter(JExcelApiExporterParameter.OUTPUT_STREAM, xlsOutStream);
            exporter.exportReport();

            byte bytes[] = xlsOutStream.toByteArray();
            fileOutputStream = new FileOutputStream(new File("C:\\" + fileName + ".xls"));
            fileOutputStream.write(bytes, 0, bytes.length);

        } catch (Exception ex) {
            log.error("產生Excel檔發生錯誤:" + ex.getMessage(), ex);
            return;
        } finally {
            if (fileOutputStream != null) {
                try {
                    fileOutputStream.flush();
                    fileOutputStream.close();
                } catch (IOException e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
    }

    /**
     * 將 jasperPrints 物件轉成 ObjectOutputStream 後存入 response。
     *
     * @param jasperPrints
     * @param response
     */
    public void printForApplet(List<JasperPrint> jasperPrints, HttpServletResponse response) {
        response.setContentType("application/octet-stream");
        ServletOutputStream ouputStream = null;
        ObjectOutputStream oos = null;
        try {
            ouputStream = response.getOutputStream();
            oos = new ObjectOutputStream(ouputStream);
            oos.writeObject(jasperPrints);
        } catch (Exception e) {
            log.error(e.getMessage(), e);

        } finally {
            if (oos != null) {
                try {
                    oos.flush();
                    oos.close();
                } catch (IOException e) {
                    log.error(e.getMessage(), e);
                }
            }
            if (ouputStream != null) {
                try {
                    ouputStream.flush();
                    ouputStream.close();
                } catch (IOException e) {
                    log.error(e.getMessage(), e);
                }
            }
        }
    }
}