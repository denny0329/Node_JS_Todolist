package com.rfep.base;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

/**
 * @author Johnson
 */
public class UtilString {
	
	/**
	 * 通常用於sql語法的in()
	 * 將集合內的元素,轉成單一字串
	 * @param value 可以是Map,List,Objcect[],Objcect
	 * @return
	 */
	public static String uS001(Object value){
		if(value==null){
			return null;
		}
		
		StringBuilder sb = new StringBuilder("(") ;
		if(value instanceof Map){
			Map<String,Object> map=(Map<String,Object>)value;
			Iterator<String> keyIter = map.keySet().iterator();
			while(keyIter.hasNext()) {
				sb.append(","+"'"+map.get(keyIter.next())+"'");
			}
		}else if(value instanceof List){
			Object[] objArray=((List)value).toArray();
			for(int i = 0; i < objArray.length; i++){
				sb.append(","+"'"+objArray[i]+"'") ;
			}
		}else if(value instanceof Object[]){
			Object[] objArray=(Object[])value;
			for(int i = 0; i < objArray.length; i++){
				sb.append(","+"'"+objArray[i]+"'") ;
			}
		}else if(value instanceof char[]){
			char[] charArray=(char[])value;
			for(int i = 0; i < charArray.length; i++){
				sb.append(","+"'"+charArray[i]+"'") ;
			}
		}else if(value instanceof Object){
			sb.append(","+"'"+value+"'") ;
		}else{
			return null;
		}
		if( sb.length() > 1 )
			sb.deleteCharAt(1) ;
		sb.append(")");
		return  sb.toString();
	}
	
	/**
	 * 清除String陣列元素內前後的空字串
	 * @param value
	 * @return
	 */
	public static String[] uS002(String[] value){
		for(int i=0;i<value.length;i++){
			value[i]=value[i].trim();
		}
		return value;
	}
	
	/**
	 * 處理前端多選項的值,將 1, 2, 3轉成('1','2','3')
	 * @param value
	 * @return
	 */
	public static String uS003(String value){
		if(StringUtils.isNotBlank(value)){
			return uS001(uS002(value.split(",")));
		}
		return value;
	}
	
	
	/**
	 * 將value,依token,並轉成List
	 * @param value
	 * @param token ","
	 * @return
	 */
	public static List<String> uS004(String value,String token) {
		List<String> result = new ArrayList<String>();
		if(StringUtils.isBlank(value)) return result;
		
		String[] list = uS002(value.split(token));
		for(String str : list) {
			if(StringUtils.isNotBlank(str)) result.add(str);
		}
		
		return result;
 	}
	
	private static final DecimalFormat DF = new DecimalFormat("0");
	/**
	 * 將double其小數點第一位,四捨五入後,取整數String
	 * @param d
	 * @return
	 */
	public static String uS004(Double d) {
		return DF.format(d);
	}
	
	/**
	 * 將字串內,不是數字字元的清除掉
	 * @param str
	 * @return
	 */
	public static String us005(String str) {
		return str.replaceAll("\\D", "");
	}
	
	/**
	 * 將字串格式的金錢加上千分位逗號,且當有負號時
	 * @param target
	 * @return
	 */
	public static String us006(String target) {
		StringBuilder result = new StringBuilder();
		result.append(target);
		if (target != null && target.length() > 3) {
			int count = target.length() / 3;
			int preNum = target.length() % 3;
			int commanCount = 0;
			if (preNum != 0) {
				result.insert(preNum, ",");
				commanCount++;
			}
			for (int i = 1; i < count; i++) {
				result.insert(i * 3 + preNum + commanCount, ",");
				commanCount++;
			}
			
			//-,123,456如果前面字元是-,就去除,
			String str=result.charAt(0)+""+result.charAt(1);
			if(str.equals("-,")){
				result.deleteCharAt(1);
			}
		}

		return result.toString();
	}
	
	
	
	
	private static void test001(){
		System.out.println("test001>>");
		Map map = new HashMap();
		map.put("1", 1);
		map.put("2", "2");
		map.put("3", 3.03D);
		map.put("4", 4.44F);
		map.put("5", 5L);
		map.put("6", true);
		map.put("7", "abc中文");
		System.out.println("map>>"+uS001(map));//('1','2','3')
		
		List list= new ArrayList();
		list.add(4);
		list.add("2");
		list.add(6.7);
		System.out.println("list>>"+uS001(list));//('1','2','3')
		System.out.println("Array>>"+uS001(list.toArray()));//('1','2','3')
		System.out.println("數字123>>"+uS001(123));//('123')
		System.out.println("字串1,2, 3,4>>"+uS001("1,2, 3,4".split(",")));//('123')
		System.out.println("\"\">>"+uS001("".split(",")));//('')
	}
	private static void test003(){
		System.out.println("test003>>");
		System.out.println("字串1,2, 3,4>>"+uS001(uS002("1,2, 3,4".split(","))));//('123')
	}
	private static void test004(){
		System.out.println(uS004(1.2));
		System.out.println(uS004(1.5));
		System.out.println(uS004(1.35));
		System.out.println(uS004(1.55));
	}
	private static void test005(){
		System.out.println(us005("1ａ2b3ff4５６７"));
	}
	
	public static void main(String[] args) {
		test001();
		test003();
		test004();
		test005();
	}
}
