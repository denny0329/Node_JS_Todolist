/**
 * @(#)ReportBean.java 2013/07/10
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.rfep.base;

import java.io.Serializable;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import com.bnq.util.DateTimeUtils;
import com.rfep.rm.model.RptPoolmgt;

/**
 * @author Johnson
 * @Date: 2011/01/15 上午 13:00:00
 */
public class ReportBean implements Serializable {
	private static final long serialVersionUID = 319040137198081036L;

	private ReportBean(){
		this.reportFileName = DateTimeUtils.getFormatSysDateTimeStr(DateTimeUtils.DEFAULT_DATE_TIME_PATTERN4);
		this.exportType = RptPoolmgt.FILE_TYPE_PDF;
		this.contentDisposition = ReportUtils.CONTENT_DISPOSITION_ATTACHMENT;
	}

	public ReportBean(Connection sourceConn,String jasperPathFileName) throws Exception{
		this();
		if(sourceConn==null){
			throw new Exception("sourceConn為null<br>");
		}
		if(jasperPathFileName==null){
			throw new Exception("jasperPathFileName為null<br>");
		}
		this.sourceConn=sourceConn;
		this.jasperPathFileName=jasperPathFileName;
		this.isConnection=true;
		this.isCompile=false;
	}
	
	@SuppressWarnings("rawtypes")
	public ReportBean(List sourceList,String jasperPathFileName) throws Exception{
		this();
		if(sourceList==null){
			throw new Exception("sourceList為null<br>");
		}
		if(jasperPathFileName==null){
			throw new Exception("jasperPathFileName為null<br>");
		}
		this.sourceList=sourceList;
		this.jasperPathFileName=jasperPathFileName;
		this.isConnection=false;
		this.isCompile=false;
	}
	
	public ReportBean(String jrxmlPathFileName,Connection sourceConn) throws Exception{
		this();
		if(sourceConn==null){
			throw new Exception("sourceConn為null<br>");
		}
		if(jrxmlPathFileName==null){
			throw new Exception("jrxmlPathFileName為null<br>");
		}
		this.sourceConn=sourceConn;
		this.jrxmlPathFileName=jrxmlPathFileName;
		this.isConnection=true;
		this.isCompile=true;
	}
	
	@SuppressWarnings("rawtypes")
	public ReportBean(String jrxmlPathFileName,List sourceList) throws Exception{
		this();
		if(sourceList==null){
			throw new Exception("sourceList為null<br>");
		}
		if(jrxmlPathFileName==null){
			throw new Exception("jrxmlPathFileName為null<br>");
		}
		this.sourceList=sourceList;
		this.jrxmlPathFileName=jrxmlPathFileName;
		this.isConnection=false;
		this.isCompile=true;
	}

	@SuppressWarnings("rawtypes")
	public ReportBean(Connection sourceConn,String jasperPathFileName,String reportFileName,Map parameterMap,String exportType) throws Exception{
		this(sourceConn,jasperPathFileName);
		if(reportFileName==null){
			throw new Exception("reportFileName為null<br>");
		}
		if(exportType==null){
			throw new Exception("exportType為null<br>");
		}
		this.reportFileName=reportFileName;
		this.parameterMap = parameterMap;
		this.exportType=exportType;
	}
	
	@SuppressWarnings("rawtypes")
	public ReportBean(List sourceList,String jasperPathFileName,String reportFileName,Map parameterMap,String exportType) throws Exception{
		this(sourceList,jasperPathFileName);
		if(reportFileName==null){
			throw new Exception("reportFileName為null<br>");
		}
		if(exportType==null){
			throw new Exception("exportType為null<br>");
		}
		this.reportFileName=reportFileName;
		this.parameterMap = parameterMap;
		this.exportType=exportType;
	}
	
	@SuppressWarnings("rawtypes")
	public ReportBean(String jrxmlPathFileName,Connection sourceConn,String reportFileName,Map parameterMap,String exportType) throws Exception{
		this(jrxmlPathFileName,sourceConn);
		if(reportFileName==null){
			throw new Exception("reportFileName為null<br>");
		}
		if(exportType==null){
			throw new Exception("exportType為null<br>");
		}
		this.reportFileName=reportFileName;
		this.parameterMap = parameterMap;
		this.exportType=exportType;
	}
	
	@SuppressWarnings("rawtypes")
	public ReportBean(String jrxmlPathFileName,List sourceList,String reportFileName,Map parameterMap,String exportType) throws Exception{
		this(jrxmlPathFileName,sourceList);
		if(reportFileName==null){
			throw new Exception("reportFileName為null<br>");
		}
		if(exportType==null){
			throw new Exception("exportType為null<br>");
		}
		this.reportFileName=reportFileName;
		this.parameterMap = parameterMap;
		this.exportType=exportType;
	}

	/**資料來源1*/
	private Connection sourceConn;

	/**資料來源2*/
	@SuppressWarnings("rawtypes")
	private List sourceList;

	/**報表頁面參數,要與ireport定義的$P{}或$P!{}對應*/
	@SuppressWarnings("rawtypes")
	private Map parameterMap;

	/**設定報表存檔時的名稱,預設為(yyyy-MM-dd HH:mm:ss)*/
	private String reportFileName;

	/**報表要輸出的格式,預設為(PDF)*/
	private String exportType;

	/**報表要輸出的方式,預設為(附加檔案)*/
	private String contentDisposition;

	/**用於Excel匯出時的額外設定,true:不要有分頁,false:有分頁,預設為(有分頁)*/
	private Boolean isIgnorePagination = false;

	/**用於Excel匯出時的額外設定,true:背景白底,false:拿掉背景白底,預設為(顯示格線)*/
	private Boolean isWhitePageBackground = false;

	/**載入已編譯的jasper檔案名稱*/
	private String jasperPathFileName;

	/**載入未編譯的jrxml檔案名稱*/
	private String jrxmlPathFileName;

	/**模版是否需要編譯,true:表示要載入.jrxml檔來編譯,false:表示直接用.jasper檔*/
	private Boolean isCompile;

	/**是否需要Connection連線,true:表示傳入Connection,false:表示直接用List*/
	private Boolean isConnection;

	/**由 ServletActionContext 取得 HttpServletResponse*/
	private HttpServletResponse response = ServletActionContext.getResponse();

	/**
	 * 取得資料來源1。
	 * @return
	 */
	public Connection getSourceConn() {
		return sourceConn;
	}

	/**
	 * 設定資料來源1。
	 * @param sourceConn
	 */
	public void setSourceConn(Connection sourceConn) {
		this.sourceConn = sourceConn;
	}

	/**
	 * 取得資料來源2。
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public List getSourceList() {
		return sourceList;
	}

	/**
	 * 設定資料來源2。
	 * @param sourceList
	 */
	@SuppressWarnings("rawtypes")
	public void setSourceList(List sourceList) {
		this.sourceList = sourceList;
	}

	/**
	 * 取得報表頁面參數,要與ireport定義的$P{}或$P!{}對應。
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public Map getParameterMap() {
		return parameterMap;
	}

	/**
	 * 設定報表頁面參數,要與ireport定義的$P{}或$P!{}對應。
	 * @param parameterMap
	 */
	@SuppressWarnings("rawtypes")
	public void setParameterMap(Map parameterMap) {
		this.parameterMap = parameterMap;
	}

	/**
	 * 取得設定報表存檔時的名稱,預設為(yyyy-MM-dd HH:mm:ss)。
	 * @return
	 */
	public String getReportFileName() {
		return reportFileName;
	}

	/**
	 * 設定設定報表存檔時的名稱,預設為(yyyy-MM-dd HH:mm:ss)。
	 * @param reportFileName
	 */
	public void setReportFileName(String reportFileName) {
		this.reportFileName = reportFileName;
	}

	/**
	 * 取得報表要輸出的格式,預設為(PDF)。
	 * @return
	 */
	public String getExportType() {
		return exportType;
	}

	/**
	 * 設定報表要輸出的格式,預設為(PDF)。
	 * @param exportType
	 */
	public void setExportType(String exportType) {
		this.exportType = exportType;
	}

	/**
	 * 取得報表要輸出的方式,預設為(附加檔案)。
	 * @return
	 */
	public String getContentDisposition() {
		return contentDisposition;
	}

	/**
	 * 設定報表要輸出的方式,預設為(附加檔案)。
	 * @param contentDisposition
	 */
	public void setContentDisposition(String contentDisposition) {
		this.contentDisposition = contentDisposition;
	}

	/**
	 * 取得Excel匯出時是否忽略分頁。
	 * @return true:不要有分頁、false:要有分頁
	 */
	public Boolean getIsIgnorePagination() {
		return isIgnorePagination;
	}

	/**
	 * 設定Excel匯出時是否忽略分頁。
	 * @param isIgnorePagination true:不要有分頁、false:要有分頁
	 */
	public void setIsIgnorePagination(Boolean isIgnorePagination) {
		this.isIgnorePagination = isIgnorePagination;
	}

	/**
	 * 取得Excel匯出時是否顯示背景白底，預設為(顯示格線)。
	 * @return true:背景白底、false:拿掉背景白底
	 */
	public Boolean getIsWhitePageBackground() {
		return isWhitePageBackground;
	}

	/**
	 * 設定Excel匯出時是否顯示背景白底，預設為(顯示格線)。
	 * @param isWhitePageBackground true:背景白底、false:拿掉背景白底
	 */
	public void setIsWhitePageBackground(Boolean isWhitePageBackground) {
		this.isWhitePageBackground = isWhitePageBackground;
	}

	/**
	 * 取得載入已編譯的jasper檔案名稱。
	 * @return
	 */
	public String getJasperPathFileName() {
		return jasperPathFileName;
	}

	/**
	 * 設定載入已編譯的jasper檔案名稱。
	 * @param jasperPathFileName
	 */
	public void setJasperPathFileName(String jasperPathFileName) {
		this.jasperPathFileName = jasperPathFileName;
	}

	/**
	 * 取得載入未編譯的jrxml檔案名稱。
	 * @return
	 */
	public String getJrxmlPathFileName() {
		return jrxmlPathFileName;
	}

	/**
	 * 設定載入未編譯的jrxml檔案名稱。
	 * @param jrxmlPathFileName
	 */
	public void setJrxmlPathFileName(String jrxmlPathFileName) {
		this.jrxmlPathFileName = jrxmlPathFileName;
	}

	/**
	 * 取得模版是否需要編譯。
	 * @return true:表示要載入.jrxml檔來編譯、false:表示直接用.jasper檔
	 */
	public Boolean getIsCompile() {
		return isCompile;
	}

	/**
	 * 設定模版是否需要編譯。
	 * @param isCompile true:表示要載入.jrxml檔來編譯、false:表示直接用.jasper檔
	 */
	public void setIsCompile(Boolean isCompile) {
		this.isCompile = isCompile;
	}

	/**
	 * 取得是否需要Connection連線。
	 * @return true:表示傳入Connection、false:表示直接用List
	 */
	public Boolean getIsConnection() {
		return isConnection;
	}

	/**
	 * 設定是否需要Connection連線。
	 * @param isConnection true:表示傳入Connection、false:表示直接用List
	 */
	public void setIsConnection(Boolean isConnection) {
		this.isConnection = isConnection;
	}

	/**
	 * 由 ServletActionContext 取得 HttpServletResponse。
	 * @return 
	 */
	public HttpServletResponse getResponse() {
		return response;
	}

	/**
	 * 由 ServletActionContext 取得 HttpServletResponse。
	 * @param response 
	 */
	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}
}