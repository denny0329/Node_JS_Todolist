package com.rfep.base;

import com.bnq.util.DateTimeUtils;
import com.bnq.util.LongId;
import com.bnq.util.StringId;
import com.gccs.util.cache.BsChannelDefinition;
import com.gccs.util.cache.BsStoreDefinition;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.jboss.vfs.VirtualFile;
import org.springframework.core.io.Resource;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.ResourceUtils;
import org.springframework.web.context.support.ServletContextResource;

import java.io.*;
import java.math.BigDecimal;
import java.net.URL;
import java.util.*;

/**
 * @author Johnson
 */
public class BaseUtil extends ActionSupport {
    private static final Logger log = LogManager.getLogger(BaseUtil.class);
    private static final long serialVersionUID = -3752789486087184600L;
    public static final String ERROR_MSG = "程式發生錯誤，請洽系統人員！";
    public static final String CLASS_PATH = "classpath:";//相對於classpath路徑
    public static final String SEPARATE = "<br>";
    public static final String ALERT_SEPARATE = "\\r\\n";

    /**
     * 處理錯誤訊息
     *
     * @param ex
     * @return
     */
    public static String handleError1(Exception ex) {
        if (ex == null) return "null";
        return ex.getMessage();
    }

    public static String handleError1(Throwable ex) {
        if (ex == null) return "null";
        return ex.getMessage();
    }

    public static List<StringId> getSelectHTML(String str) {
        if (str.equals("selectIv002Type")) {
            return getSelectIv002Type();
        }
        return null;
    }

    /**
     * 取得畫面元件Select
     * 格式代碼
     *
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static List<StringId> getSelectReportFormat() {
        //畫面的語法<s:select theme="simple" name="list[%{#status.index}].reportFormat" list="selectReportFormat" cssClass="text" listKey="id" listValue="name"/>
        List<StringId> temp = new ArrayList<StringId>();
        temp.add(new StringId("", "請選擇"));//RFEP_UI_媒體申報20101220,此需求新增
        temp.add(new StringId("32", "32-發票"));
        temp.add(new StringId("34", "34-折讓"));
        return temp;
    }

    /**
     * 取得畫面元件Select
     * 課稅別
     *
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static List<StringId> getSelectTaxFlag() {
        //畫面的語法<s:select theme="simple" name="list[%{#status.index}].taxFlag" list="selectTaxFlag" cssClass="text" listKey="id" listValue="name"/>
        List<StringId> temp = new ArrayList<StringId>();
        temp.add(new StringId("1", "1-應稅"));
        temp.add(new StringId("2", "2-零稅"));
        temp.add(new StringId("3", "3-免稅"));
        temp.add(new StringId("D", "D-空白"));
        temp.add(new StringId("F", "F-作廢"));
        return temp;
    }

    /**
     * 取得畫面元件Select
     * 扣款項目
     *
     * @return
     * @author Johnson
     * @Date: 2011/01/12 上午 13:00:00
     */
    public static List<StringId> getSelectChargType() {
        //畫面的語法<s:select theme="simple" id="chargType" name="chargType" list="selectChargType" cssClass="text" listKey="id" listValue="name"  multiple="true"/>
        List<StringId> temp = new ArrayList<StringId>();
        temp.add(new StringId("1", "扣款項目1"));
        temp.add(new StringId("2", "扣款項目2"));
        temp.add(new StringId("3", "扣款項目3"));
        temp.add(new StringId("4", "扣款項目4"));
        temp.add(new StringId("5", "扣款項目5"));
        return temp;
    }

    /**
     * 取得畫面元件Select
     * 有庫存、無庫存或全部。
     *
     * @return
     * @author Johnson
     * @Date: 2011/01/12 上午 13:00:00
     */
    public static List<StringId> getSelectIv001Type() {
        //畫面的語法<s:select theme="simple" id="iv001Type" name="iv001Type" list="selectIv001Type" cssClass="text" listKey="id" listValue="name"  multiple="true"/>
        List<StringId> temp = new ArrayList<StringId>();
        temp.add(new StringId("1", "有身份無庫存"));
        temp.add(new StringId("2", "有庫存無身份"));
        return temp;
    }

    /**
     * 取得畫面元件Select
     * 有排面、無排面或全部
     *
     * @return
     * @author Johnson
     * @Date: 2011/01/12 上午 13:00:00
     */
    public static List<StringId> getSelectIv002Type() {
        //畫面的語法<s:select theme="simple" id="iv002Type" name="iv002Type" list="selectIv002Type" cssClass="text" listKey="id" listValue="name"  multiple="true"/>
        List<StringId> temp = new ArrayList<StringId>();
        temp.add(new StringId("", "全部"));
        temp.add(new StringId("1", "有排面"));
        temp.add(new StringId("2", "無排面"));
        return temp;
    }

    /**
     * 取得畫面元件Select
     * 有促銷、無促銷或全部。
     *
     * @return
     * @author Johnson
     * @Date: 2011/01/12 上午 13:00:00
     */
    public static List<StringId> getSelectIv003Type() {
        //畫面的語法<s:select theme="simple" id="iv003Type" name="iv003Type" list="selectIv003Type" cssClass="text" listKey="id" listValue="name"  multiple="true"/>
        List<StringId> temp = new ArrayList<StringId>();
        temp.add(new StringId("", "全部"));
        temp.add(new StringId("1", "有促銷"));
        temp.add(new StringId("2", "無促銷"));
        return temp;
    }


    /**
     * 取得畫面元件Select
     * 有庫存、無庫存或全部。
     *
     * @return
     * @author Johnson
     * @Date: 2011/01/12 上午 13:00:00
     */
    public static List<StringId> getSelectIv004Type() {
        //畫面的語法<s:select theme="simple" id="iv001Type" name="iv001Type" list="selectIv001Type" cssClass="text" listKey="id" listValue="name"  multiple="true"/>
        List<StringId> temp = new ArrayList<StringId>();
        temp.add(new StringId("", "請選擇"));
        temp.add(new StringId("1", "一般商品"));
        temp.add(new StringId("2", "DC商品"));
        temp.add(new StringId("3", "XD商品"));
        return temp;
    }

    /**
     * 取得畫面元件Select
     * 依品類、依課別或依可用週數排序
     *
     * @return
     * @author Johnson
     * @Date: 2011/01/12 上午 13:00:00
     */
    public static List<StringId> getSelectPrintSort1() {
        //畫面的語法<s:select theme="simple" id="printSort1" name="queryCondition['printSort1']" list="selectPrintSort1" cssClass="text" listKey="id" listValue="name" />
        List<StringId> temp = new ArrayList<StringId>();
        temp.add(new StringId("1", "依品類"));
        temp.add(new StringId("2", "依課別"));
        temp.add(new StringId("3", "依可用週數"));
        return temp;
    }

    public static List<StringId> getSelectPrintSort2() {
        //畫面的語法<s:select theme="simple" id="printSort2" name="queryCondition['printSort2']" list="selectPrintSort2" cssClass="text" listKey="id" listValue="name" />
        List<StringId> temp = new ArrayList<StringId>();
        temp.add(new StringId("1", "依品類"));
        temp.add(new StringId("2", "依課別"));
        temp.add(new StringId("3", "依廠編"));
        return temp;
    }

    public static List<StringId> getSelectPrintSort3() {
        //畫面的語法<s:select theme="simple" id="printSort3" name="queryCondition['printSort3']" list="selectPrintSort3" cssClass="text" listKey="id" listValue="name" />
        List<StringId> temp = new ArrayList<StringId>();
        temp.add(new StringId("1", "依大類"));
        temp.add(new StringId("2", "依課別"));
        return temp;
    }

    public static List<StringId> getSelectPrintSort4() {
        //畫面的語法<s:select theme="simple" id="printSort4" name="queryCondition['printSort4']" list="selectPrintSort4" cssClass="text" listKey="id" listValue="name" />
        List<StringId> temp = new ArrayList<StringId>();
        temp.add(new StringId("1", "至品類"));
        temp.add(new StringId("2", "至明細"));
        return temp;
    }

    public static List<StringId> getSelectPrintSort5() {
        //畫面的語法<s:select theme="simple" id="printSort5" name="queryCondition['printSort5']" list="selectPrintSort5" cssClass="text" listKey="id" listValue="name" />
        List<StringId> temp = new ArrayList<StringId>();
        temp.add(new StringId("1", "依廠編"));
        temp.add(new StringId("2", "依退廠單號"));
        temp.add(new StringId("3", "依立單日"));
        temp.add(new StringId("4", "依出庫日"));
        return temp;
    }

    /**
     * 取得畫面元件Select
     * SO專案狀態：已結案、未結案，預設已結案。
     *
     * @return
     * @author Johnson
     * @Date: 2011/01/12 上午 13:00:00
     */
    public static List<StringId> getSelectProjectStatus() {
        //畫面的語法<s:select theme="simple" id="projectStatus" name="queryCondition['projectStatus']" list="selectProjectStatus" cssClass="text" listKey="id" listValue="name" />
        List<StringId> temp = new ArrayList<StringId>();
        temp.add(new StringId("1", "已結案"));
        temp.add(new StringId("2", "未結案"));
        return temp;
    }

    /**
     * 取得畫面元件Select
     * 調撥單狀態：下拉選單，由使用者選擇申請、調出，不選擇則為全部。
     *
     * @return
     * @author Johnson
     * @Date: 2011/01/12 上午 13:00:00
     */
    public static List<StringId> getSelectTrfStatus() {
        //畫面的語法<s:select theme="simple" id="selectTrfStatus" name="queryCondition['selectTrfStatus']" list="selectTrfStatus" cssClass="text" listKey="id" listValue="name" />
        List<StringId> temp = new ArrayList<StringId>();
        temp.add(new StringId("", "全部"));
        temp.add(new StringId("1", "申請"));
        temp.add(new StringId("2", "調出"));
        return temp;
    }

    /**
     * 取得畫面元件Select
     * 列印選項：選擇「不列印SKU明細 、列印SKU明細
     *
     * @return
     */
    public static List<StringId> getSelectPrintDetail() {
        //畫面的語法<s:select theme="simple" id="selectPrintDetail" name="queryCondition['selectPrintDetail']" list="selectPrintDetail" cssClass="text" listKey="id" listValue="name" />
        List<StringId> temp = new ArrayList<StringId>();
        temp.add(new StringId("0", "不列印SKU明細"));
        temp.add(new StringId("1", "列印SKU明細"));
        return temp;
    }

    /**
     * 取得畫面元件Select
     * 選擇,是、否
     *
     * @return
     */
    public static List<StringId> getSelectYesNo() {
        //畫面的語法<s:select theme="simple" id="selectYesNo" name="queryCondition['selectYesNo']" list="selectYesNo" cssClass="text" listKey="id" listValue="name" />
        List<StringId> temp = new ArrayList<StringId>();
        temp.add(new StringId("", "全部"));
        temp.add(new StringId("0", "否"));
        temp.add(new StringId("1", "是"));
        return temp;
    }

    /**
     * 取得畫面元件Select
     *
     * @return
     */
    public static List<StringId> getSelectBrand() {
        //畫面的語法<s:select theme="simple" id="selectBrand" name="queryCondition['selectBrand']" list="selectBrand" cssClass="text" listKey="id" listValue="name"/>
        List<StringId> temp = new ArrayList<StringId>();
        temp.add(new StringId("", "全部"));
        temp.add(new StringId("10", "FE通路"));
        temp.add(new StringId("11", "WW通路"));
        temp.add(new StringId("12", "FR通路"));
        temp.add(new StringId("13", "DI通路"));
        return temp;
    }

    /**
     * 取得畫面元件Radio
     * 列印格式
     *
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static List<LongId> getRadioPDFOrExcel() {
        //畫面的語法<s:radio theme="simple" list="radioPDFOrExcel" listKey="id" listValue="name" name="變數" value="變數" />
        List<LongId> temp = new ArrayList<LongId>();
        temp.add(new LongId(1L, "PDF"));//PDF
        temp.add(new LongId(2L, "Excel"));//Excel
        return temp;
    }

    /**
     * 取得畫面元件Radio
     * 來源選項3
     *
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static List<LongId> getRadioSourceName3() {
        //畫面的語法<s:radio theme="simple" list="radioSourceName3" listKey="id" listValue="name" name="radioSourceName3" value="變數" />
        List<LongId> temp = new ArrayList<LongId>();
        temp.add(new LongId(1L, "銷售資料(一般)"));
        temp.add(new LongId(2L, "銷售資料(財務)"));
        temp.add(new LongId(3L, "二聯式收銀機發票資料"));
        temp.add(new LongId(4L, "全部"));
        return temp;
    }

    /**
     * 取得畫面元件Radio
     * 營收報表類型
     *
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static List<LongId> getRadioEarningReport01() {
        //畫面的語法<s:radio theme="simple" list="radioEarningReport01" listKey="id" listValue="name" name="queryCondition['radioEarningReport01']" value="變數" />
        List<LongId> temp = new ArrayList<LongId>();
        temp.add(new LongId(1L, "每日營收差異明細表"));
        temp.add(new LongId(2L, "每日營收機台差異彙總表(獨立)"));
        temp.add(new LongId(3L, "每日營收帳務調整明細表"));
        return temp;
    }

    public static List<LongId> getRadioEarningReport02() {
        //畫面的語法<s:radio theme="simple" list="radioEarningReport02" listKey="id" listValue="name" name="queryCondition['radioEarningReport02']" value="變數" />
        List<LongId> temp = new ArrayList<LongId>();
        temp.add(new LongId(1L, "IN"));
        temp.add(new LongId(2L, "OUT"));
        return temp;
    }

    /**
     * 取得畫面元件Radio
     * 調撥狀態
     *
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static List<LongId> getRadioTrfStatus2() {
        //畫面的語法<s:radio theme="simple" list="radioTrfStatus2" listKey="id" listValue="name" name="變數" value="變數" />
        List<LongId> temp = new ArrayList<LongId>();
        temp.add(new LongId(1L, "調入"));
        temp.add(new LongId(2L, "調出"));
        return temp;
    }

    public static String getShowTrfStatus2(String id) {
        //畫面的語法<s:property value="%{showTrfStatus(變數)}" />
        return forIterator2(getRadioTrfStatus2(), id);
    }

    /**
     * 取得畫面元件Select,其中的值
     * 格式代碼
     *
     * @param id
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static String getShowReportFormat(String id) {
        //畫面的語法<s:property value="%{showReportFormat(變數)}" />
        return forIterator1(getSelectReportFormat(), id);
    }

    /**
     * 取得畫面元件Select,其中的值
     * 課稅別
     *
     * @param id
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static String getShowTaxFlag(String id) {
        //畫面的語法<s:property value="%{showTaxFlag(變數)}" />
        return forIterator1(getSelectTaxFlag(), id);
    }

    /**
     * 取得畫面元件Select,其中的值
     * 通路名稱
     *
     * @param channelId
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static String getShowChannelDesc(String channelId) {
        //畫面的語法<s:property value="%{showChannelDesc(channelId)}" />
        return BsChannelDefinition.getChannelDesc(channelId);
    }

    /**
     * 取得畫面元件Select,其中的值
     * 店別名稱
     *
     * @param channelId
     * @param storeId
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static String getShowStrorDesc(String channelId, String storeId) {
        //畫面的語法<s:property value="%{showStrorDesc(channelId,storeId)}" />
        return BsStoreDefinition.getStoreDesc(storeId);
    }

    /**
     * 取得畫面元件Select,其中的值
     * 有無庫存
     *
     * @param id
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static String getShowIv001Type(String id) {
        //畫面的語法<s:property value="%{showIv001Type(變數)}" />
        return forIterator1(getSelectIv001Type(), id);
    }

    /**
     * 取得畫面元件Select,其中的值
     * 有無排面
     *
     * @param id
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static String getShowIv002Type(String id) {
        //畫面的語法<s:property value="%{showIv002Type(變數)}" />
        return forIterator1(getSelectIv002Type(), id);
    }

    /**
     * 取得畫面元件Select,其中的值
     * 有無促銷
     *
     * @param id
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static String getShowIv003Type(String id) {
        //畫面的語法<s:property value="%{showIv003Type(變數)}" />
        return forIterator1(getSelectIv003Type(), id);
    }


    /**
     * 取得畫面元件Select,其中的值
     * 有無庫存
     *
     * @param id
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static String getShowIv004Type(String id) {
        //畫面的語法<s:property value="%{showIv004Type(變數)}" />
        //濾掉請選擇
        String desc = "";
        if (StringUtils.isNotBlank(id)) {
            desc = forIterator1(getSelectIv004Type(), id);
        }
        return desc;
    }

    /**
     * 取得畫面元件Select,其中的值
     * 列印排序
     *
     * @param id
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static String getShowPrintSort1(String id) {
        //畫面的語法<s:property value="%{showPrintSort1(變數)}" />
        return forIterator1(getSelectPrintSort1(), id);
    }

    public static String getShowPrintSort2(String id) {
        //畫面的語法<s:property value="%{showPrintSort2(變數)}" />
        return forIterator1(getSelectPrintSort2(), id);
    }

    public static String getShowPrintSort3(String id) {
        //畫面的語法<s:property value="%{showPrintSort3(變數)}" />
        return forIterator1(getSelectPrintSort3(), id);
    }

    public static String getShowPrintSort4(String id) {
        //畫面的語法<s:property value="%{showPrintSort4(變數)}" />
        return forIterator1(getSelectPrintSort4(), id);
    }

    public static String getShowPrintSort5(String id) {
        //畫面的語法<s:property value="%{showPrintSort5(變數)}" />
        return forIterator1(getSelectPrintSort5(), id);
    }

    /**
     * 取得畫面元件Select,其中的值
     * SO專案狀態：已結案、未結案，預設已結案。
     *
     * @param id
     * @return
     */
    public static String getShowProjectStatus(String id) {
        //畫面的語法<s:property value="%{showProjectStatus(變數)}" />
        return forIterator1(getSelectProjectStatus(), id);
    }

    /**
     * 取得畫面元件Select,其中的值
     * 調撥單狀態：下拉選單，由使用者選擇申請、調出，不選擇則為全部。
     *
     * @param id
     * @return
     */
    public static String getShowTrfStatus(String id) {
        //畫面的語法<s:property value="%{showTrfStatus(變數)}" />
        return forIterator1(getSelectTrfStatus(), id);
    }

    /**
     * 取得畫面元件Select,其中的值
     * 列印選項：選擇「不列印SKU明細 、列印SKU明細
     *
     * @param id
     * @return
     */
    public static String getShowPrintDetail(String id) {
        //畫面的語法<s:property value="%{showPrintDetail(變數)}" />
        return forIterator1(getSelectPrintDetail(), id);
    }

    /**
     * 取得畫面元件Select,其中的值
     * 選擇,是 、否
     *
     * @param id
     * @return
     */
    public static String getShowYesNo(String id) {
        //畫面的語法<s:property value="%{showYesNo(變數)}" />
        return forIterator1(getSelectYesNo(), id);
    }

    /**
     * 取得畫面元件Select,其中的值
     * 選擇,	FR通路、WW通路、FE通路、DI通路
     *
     * @param id
     * @return
     */
    public static String getShowBrand(String id) {
        //畫面的語法<s:property value="%{showBrand(變數)}" />
        return forIterator1(getSelectBrand(), id);
    }

    /**
     * 取得畫面元件Radio,其中的值
     * 列印格式
     *
     * @param id
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static String getShowPDFOrExcel(String id) {
        //畫面的語法<s:property value="%{showPDFOrExcel(變數)}" />
        return forIterator2(getRadioPDFOrExcel(), id);
    }

    /**
     * 取得畫面元件Radio,其中的值
     * 來源選項3
     *
     * @param id
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static String getShowSourceName3(String id) {
        //畫面的語法<s:property value="%{showSourceName3(變數)}" />
        return forIterator2(getRadioSourceName3(), id);
    }

    /**
     * 取得畫面元件Radio,其中的值
     * 營收報表類型
     *
     * @param id
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static String getShowEarningReport01(String id) {
        //畫面的語法<s:property value="%{showEarningReport01(變數)}" />
        return forIterator2(getRadioEarningReport01(), id);
    }

    /**
     * 抓Date.toString()時的前10碼yyyy/MM/dd
     *
     * @param id
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static String getShowDate(String id) {
        //畫面的語法<s:property value="%{getShowDate(變數)}" />
        if (id == null) return "";
        return id.substring(0, 10);
    }

    /**
     * 禮卷狀態
     *
     * @return
     */
    public static List<StringId> getSelectGiftStatus() {
        List<StringId> temp = new ArrayList<StringId>();
        temp.add(new StringId("0", "0-新增"));
        temp.add(new StringId("1", "1-調撥"));
        temp.add(new StringId("2", "2-流通在外"));
        temp.add(new StringId("3", "3-抵用"));
        temp.add(new StringId("4", "4-作廢"));
        return temp;
    }

    /**
     * 取出取得畫面元件Select,其中的值
     * 禮卷型態
     *
     * @param id
     * @return
     */
    public static String getShowGiftStatus(String id) {
        return forIterator1(getSelectGiftStatus(), id);
    }

    private static String forIterator1(List<StringId> list, String id) {
        if (id == null) {
            return "";
        } else {
            for (StringId stringId : list) {
                if (stringId.getId().equals(id)) {
                    return stringId.getName();
                }
            }
        }
        return id;
    }

    private static String forIterator2(List<LongId> list, String id) {
        if (id == null) {
            return "";
        } else {
            for (LongId longId : list) {
                if (longId.getId() == new Long(id)) {
                    return longId.getName();
                }
            }
        }
        return id;
    }

    /**
     * 6碼轉5碼,西元轉民國
     *
     * @param forDate 請輸入6碼,例:201011,回傳09911
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static String yeay6To5(String forDate) {
        if (StringUtils.isNotBlank(forDate)) {
            String str1 = forDate.substring(0, 4);//2010
            String str2 = forDate.substring(4, 6);//11

            int year = Integer.parseInt(str1);
            int y1 = year - 1911;
            if (y1 <= 9) {
                return "00" + y1 + str2;
            }
            if (y1 <= 99) {
                return "0" + y1 + str2;
            }
            return y1 + str2;
        }
        return "";
    }

    /**
     * 讀取文字檔的內容
     *
     * @param filePath
     * @return
     * @throws IOException
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static String readTextFile(String filePath) throws IOException {
        if (StringUtils.isNotBlank(filePath)) {
            return FileCopyUtils.copyToString(new BufferedReader(new InputStreamReader(new FileInputStream(getFileSpring(filePath)), "utf-8")));
        }
        return "";
    }

    /**
     * 使用Spring的方式取得檔案
     *
     * @param filePath 前置詞如果是classpath:,就從classpath抓檔案,比方classpath:com/aaa/bbb/ccc/XXXX.sql,,否則就從相對於Web 應用根路徑去抓檔案
     * @return
     * @throws IOException
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static File getFileSpring(String filePath) throws IOException {

        if (!filePath.startsWith(CLASS_PATH)) {
            Resource res = new ServletContextResource(ServletActionContext.getServletContext(), filePath);
            return res.getFile();
        }

        URL rootUrl = ResourceUtils.getURL(filePath);
        if (!rootUrl.getProtocol().startsWith(ResourceUtils.URL_PROTOCOL_VFS)) {
            return ResourceUtils.getFile(filePath);
        }

        // jboss7 vfs 檔案路徑處理
        org.jboss.vfs.VirtualFile jbossVirtualFile = (org.jboss.vfs.VirtualFile) rootUrl.getContent();
        File fileSystemFile = jbossVirtualFile.getPhysicalFile();
        return fileSystemFile;
    }

    public static InputStream getInputStreamSpring(String filePath) throws IOException {
        if (!filePath.startsWith(CLASS_PATH)) {
            Resource res = new ServletContextResource(ServletActionContext.getServletContext(), filePath);
            return new FileInputStream(res.getFile());
        }

        URL rootUrl = ResourceUtils.getURL(filePath);
        if (!rootUrl.getProtocol().startsWith(ResourceUtils.URL_PROTOCOL_VFS)) {
            return new FileInputStream(ResourceUtils.getFile(filePath));
        }

        // jboss7 vfs 檔案路徑處理
        InputStream is = null;
        Object tmpFile = rootUrl.getContent();
        if (tmpFile instanceof VirtualFile) {
            File file = ((VirtualFile) tmpFile).getPhysicalFile();
            try {
                is = new FileInputStream(file);
            } catch (FileNotFoundException e) {
                log.error(e.getMessage(), e);
            }
        }
        //jboss-eap-7.2針對image類型處理
        else {
            is = rootUrl.openStream();
        }
        return is;
    }

    /**
     * 使用Spring的方式取得檔案路徑
     *
     * @param filePath
     * @return
     * @throws IOException
     */
    public static String getFilePathSpring(String filePath) throws IOException {

        if (!filePath.startsWith(CLASS_PATH)) return "";
        URL rootUrl = ResourceUtils.getURL(filePath);
        if (!rootUrl.getProtocol().startsWith(ResourceUtils.URL_PROTOCOL_VFS)) {
            return ResourceUtils.getURL(filePath).getPath();
        }

        // jboss7 vfs 檔案路徑處理
        org.jboss.vfs.VirtualFile jbossVirtualFile = (org.jboss.vfs.VirtualFile) rootUrl.getContent();
        File fileSystemFile = jbossVirtualFile.getPhysicalFile();
        String absolutePathToFile = fileSystemFile.getPath();
        if (jbossVirtualFile.isDirectory()) {
            absolutePathToFile += File.separator;
        }

        return absolutePathToFile;
    }


    /**
     * 前端值傳進到Action時,資料需轉換String
     * Action傳進到Dao時,資料需轉換String
     *
     * @param map
     * @param key
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public static String getMapValueToString(Map map, String key) {
        if (map == null) return null;
        String rtv = null;
        Object obj = map.get(key);
        if (obj != null) {
            if (obj instanceof String) {
                // 如果是String, 回傳trim之後的value
                rtv = ((String) obj).trim();
            } else if (obj instanceof String[]) {
                rtv = ((String[]) obj)[0].trim();
            }
        }
        log.info(">>前端傳進的值>" + key + "=" + rtv);
        return rtv;
    }

    /**
     * 使用SQL取值時,資料需轉換String
     *
     * @param obj
     * @param key
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public String getMapValueToString(Object obj, String key) {
        if (obj == null) return null;
        String rtv = (String) ((Map) obj).get(key);
        if (rtv == null) return null;
        return rtv.trim();
    }

    /**
     * 使用SQL取值時,資料需轉換BigDecimal
     *
     * @param obj
     * @param key
     * @return
     * @author Johnson
     * @Date: 2010/10/01 上午 13:00:00
     */
    public BigDecimal getMapValueToBigDecimal(Object obj, String key) {
        if (obj == null) return null;
        BigDecimal rtv = (BigDecimal) ((Map) obj).get(key);
        if (rtv == null) return null;
        return new BigDecimal(Math.abs(rtv.intValue())).setScale(0, BigDecimal.ROUND_HALF_UP);
    }

    /**
     * 顯示SQL以及問號參數值,用於除錯
     *
     * @param str
     * @param paramsValue
     * @author Johnson
     * @Date: 2010/12/27 上午 13:00:00
     */
    public static void printSql(String str, List<Object> paramsValue) {
        String sqlPrint = str.toString();
        if (paramsValue != null) {
            for (int i = 0; i < paramsValue.size(); i++) {
                sqlPrint = sqlPrint.replaceFirst("\\?", "'" + (String) paramsValue.get(i) + "'");
            }
        }
        log.debug("=====================================================================================");
        log.debug("sqlPrint>>");
        log.debug(sqlPrint);
        log.debug("");
    }

    /**
     * 控制台輸出
     *
     * @param obj
     */
    public static void println(Object obj) {
        log.debug("=====================================================================================");
        log.debug("print>>");
        log.debug(obj);
        log.debug("");
    }

    /**
     * 轉換Map裡面的KEY值,由大寫字母(TRANS_DATE)變成駝峰字(transDate)
     * 1.如果Map裡面的元素類型與Bean的元素類型不同時,要在這先轉換成Bean的類型
     *
     * @param map
     * @return
     */
    public static void changeMapKey(Map map) {
        Object[] objKeys = map.keySet().toArray();
        String strFieldName = "";
        Object objTemp;
        for (Object objkey : objKeys) {
            strFieldName = objkey.toString();
            objTemp = map.get(strFieldName);

            //Map裡面的元素類型為java.sql.Date,Bean的元素類型為java.util.Date
            if (objTemp != null && objTemp instanceof java.sql.Date) {
                println(strFieldName + ">>" + objTemp);
                map.put(changeName(strFieldName), DateTimeUtils.getDate2(objTemp.toString()));
            } else {
                map.put(changeName(strFieldName), objTemp);
            }

            map.remove(strFieldName);
        }
    }

    /**
     * 改變DB欄位名稱為駝峰字,原理:先全部變小寫後,將底現後面的第1個字母變大寫,
     * 比方:TRANS_DATE==>transDate
     * OID==>oid
     *
     * @param str
     * @return
     */
    public static String changeName(String str) {
        String changeName = "";
        //全部變小寫
        changeName = str.toLowerCase();
        //分割底線
        String[] changeNameArray = changeName.split("_");
        String sum = "";
        //將底現後面的第1個字母變大寫
        for (int i = 1; i < changeNameArray.length; i++) {
            sum = sum + changeNameArray[i].substring(0, 1).toUpperCase() + changeNameArray[i].substring(1, changeNameArray[i].length());
        }
        return changeNameArray[0] + sum;
    }

    /**
     * 判斷前端查詢參數Map是否有值
     *
     * @param queryCondition
     * @return
     */
    public static boolean isNoQueryCondition(Map queryCondition) {
        if (queryCondition == null) {
            return true;//代表沒有輸入任何查詢條件
        }
        Set<String> reqkeys = queryCondition.keySet();
        Iterator<String> iterator = reqkeys.iterator();
        int i = 0;

        while (iterator.hasNext()) {
            String key = iterator.next();
            if (queryCondition.get(key) instanceof String) {
                String value = (String) queryCondition.get(key);
                if (StringUtils.isBlank(value)) {
                    ++i;
                }
            } else if (queryCondition.get(key) instanceof String[]) {
                String[] value = (String[]) queryCondition.get(key);
                if (value == null || value[0] == null || value[0].trim().equals("")) {
                    ++i;
                }
            }
        }
        if (i == queryCondition.size()) {
            return true;//代表沒有輸入任何查詢條件
        } else {
            return false;
        }
    }

    /**
     * 接收前端傳進的queryCondition,然後自動產生"and key = '"+value+"'"或"and key = ?" 或"and key = :key",
     *
     * @param dbField        DB的欄位名稱
     * @param frontKey       前端的key
     * @param queryCondition 前端的map值
     * @param str            sql或hql
     * @param paramsValue    傳入空String 			將產生'結合參數'
     *                       傳入List<Object>			將產生'位置參數?'
     *                       傳入Map<String,Object>	將產生'命名參數:'
     */
    public static void addParams_EQ1(String[] dbField, String[] frontKey, Map queryCondition, StringBuilder str, Object paramsValue) {
        if (isNoQueryCondition(queryCondition)) {
            return;
        }
        String frontValue = null;
        for (int i = 0; i < dbField.length; i++) {
            frontValue = getMapValueToString(queryCondition, frontKey[i]);
            if (StringUtils.isNotBlank(frontValue)) {
                if (paramsValue instanceof String) {
                    str.append(" and " + dbField[i] + " = '" + frontValue + "'");
                } else if (paramsValue instanceof Map) {
                    str.append(" and " + dbField[i] + " = :" + dbField[i]);
                    ((Map) paramsValue).put(dbField[i], frontValue);
                } else if (paramsValue instanceof List) {
                    str.append(" and " + dbField[i] + " = ?");
                    ((List) paramsValue).add(frontValue);
                }
            }
        }
    }

    /**
     * 取得區域查詢(只要是from-end的資料符合都要查詢出來)
     * 用於查詢雙日期區間,且DB是一個日期欄位
     *
     * @param dbField1       資料庫對應的Date欄位1
     * @param frontKeyStart  前端key-起
     * @param frontKeyEnd    前端key-迄
     * @param parrern        日期格式
     * @param queryCondition 前端值的map
     * @param str            sql或hql
     * @param paramsValue    傳入空String 			將產生'結合參數'
     *                       傳入List<Object>			將產生'位置參數?'
     *                       傳入Map<String,Object>	將產生'命名參數:'
     */
    public static void addParams_DateBetween1(String dbField1, String frontKeyStart, String frontKeyEnd, String parrern, Map queryCondition, StringBuilder str, Object paramsValue) {
        if (isNoQueryCondition(queryCondition)) {
            return;
        }

        String frontValueStart = getMapValueToString(queryCondition, frontKeyStart);
        if (StringUtils.isNotBlank(frontValueStart)) {
            if (paramsValue instanceof String) {
                str.append(" AND  TO_DATE('" + frontValueStart + "','" + parrern + "') <= (" + dbField1 + ")");
            } else if (paramsValue instanceof Map) {
                str.append(" AND  TO_DATE(:" + frontKeyStart + ",'" + parrern + "') <= (" + dbField1 + ")");
                ((Map) paramsValue).put(frontKeyStart, frontValueStart);
            } else if (paramsValue instanceof List) {
                str.append(" AND  TO_DATE(?,'" + parrern + "') <= (" + dbField1 + ")");
                ((List) paramsValue).add(frontValueStart);
            }
        }

        String frontValueEnd = getMapValueToString(queryCondition, frontKeyEnd);

        if (StringUtils.isNotBlank(frontValueEnd)) {
            if (parrern.equalsIgnoreCase(DateTimeUtils.DEFAULT_DATE_PATTERN)) {
                parrern = "yyyy/MM/dd HH24:mi:ss";
                frontValueEnd = frontValueEnd + " 23:59:59";
            }

            if (paramsValue instanceof String) {
                str.append(" AND  TO_DATE('" + frontValueEnd + "','" + parrern + "') >= (" + dbField1 + ")");
            } else if (paramsValue instanceof Map) {
                str.append(" AND  TO_DATE(:" + frontKeyEnd + ",'" + parrern + "') >= (" + dbField1 + ")");
                ((Map) paramsValue).put(frontKeyEnd, frontValueEnd);
            } else if (paramsValue instanceof List) {
                str.append(" AND  TO_DATE(?,'" + parrern + "') >= (" + dbField1 + ")");
                ((List) paramsValue).add(frontValueEnd);
            }
        }
    }

    /**
     * 取得區域查詢2(只要是from-end的資料符合都要查詢出來)
     * 用於查詢雙日期區間,且DB是有兩個日期欄位
     *
     * @param dbField1       資料庫對應的Date欄位1 from
     * @param dbField2       資料庫對應的Date欄位2 to
     * @param frontKeyStart  前端key-起
     * @param frontKeyEnd    前端key-迄
     * @param parrern        日期格式
     * @param queryCondition 前端值的map
     * @param str            sql或hql
     * @param paramsValue    傳入空String 			將產生'結合參數'
     *                       傳入List<Object>			將產生'位置參數?'
     *                       傳入Map<String,Object>	將產生'命名參數:'
     */
    public static void addParams_DateBetween2(String dbField1, String dbField2, String frontKeyStart, String frontKeyEnd, String parrern, Map queryCondition, StringBuilder str, Object paramsValue) {
        if (isNoQueryCondition(queryCondition)) {
            return;
        }

        String frontValueStart = getMapValueToString(queryCondition, frontKeyStart);
        if (StringUtils.isNotBlank(frontValueStart)) {
            if (paramsValue instanceof String) {
                str.append(" AND  TO_DATE('" + frontValueStart + "','" + parrern + "') >= TO_DATE(TO_CHAR(" + dbField1 + ",'" + parrern + "'),'" + parrern + "')");
            } else if (paramsValue instanceof Map) {
                str.append(" AND  TO_DATE(:" + frontKeyStart + ",'" + parrern + "') >= TO_DATE(TO_CHAR(" + dbField1 + ",'" + parrern + "'),'" + parrern + "')");
                ((Map) paramsValue).put(frontKeyStart, frontValueStart);
            } else if (paramsValue instanceof List) {
                str.append(" AND  TO_DATE(?,'" + parrern + "') >= TO_DATE(TO_CHAR(" + dbField1 + ",'" + parrern + "'),'" + parrern + "')");
                ((List) paramsValue).add(frontValueStart);
            }
        }

        String frontValueEnd = getMapValueToString(queryCondition, frontKeyEnd);
        if (StringUtils.isNotBlank(frontValueEnd)) {
            if (paramsValue instanceof String) {
                str.append(" AND  TO_DATE('" + frontValueEnd + "','" + parrern + "') <= TO_DATE(TO_CHAR(" + dbField2 + ",'" + parrern + "'),'" + parrern + "')");
            } else if (paramsValue instanceof Map) {
                str.append(" AND  TO_DATE(:" + frontKeyEnd + ",'" + parrern + "') <= TO_DATE(TO_CHAR(" + dbField2 + ",'" + parrern + "'),'" + parrern + "')");
                ((Map) paramsValue).put(frontKeyEnd, frontValueEnd);
            } else if (paramsValue instanceof List) {
                str.append(" AND  TO_DATE(?,'" + parrern + "') <= TO_DATE(TO_CHAR(" + dbField2 + ",'" + parrern + "'),'" + parrern + "')");
                ((List) paramsValue).add(frontValueEnd);
            }
        }
    }

    /**
     * 取得區域查詢3(只要是from的資料符合都要查詢出來)
     * 用於查詢單一日期,且DB是一個日期欄位
     *
     * @param dbField1       資料庫對應的Date欄位1 from Start
     * @param frontKeyStart  前端key-起
     * @param parrern        日期格式
     * @param queryCondition 前端值的map
     * @param str            sql或hql
     * @param paramsValue    傳入空String 			將產生'結合參數'
     *                       傳入List<Object>			將產生'位置參數?'
     *                       傳入Map<String,Object>	將產生'命名參數:'
     */
    public static void addParams_DateBetween3(String dbField1, String frontKeyStart, String parrern, Map queryCondition, StringBuilder str, Object paramsValue) {
        if (isNoQueryCondition(queryCondition)) {
            return;
        }

        String frontValueStart = getMapValueToString(queryCondition, frontKeyStart);
        if (StringUtils.isNotBlank(frontValueStart)) {
            if (paramsValue instanceof String) {
                str.append(" AND  TO_DATE('" + frontValueStart + "','" + parrern + "') = TO_DATE(TO_CHAR(" + dbField1 + ",'" + parrern + "'),'" + parrern + "')");
            } else if (paramsValue instanceof Map) {
                str.append(" AND  TO_DATE(:" + frontKeyStart + ",'" + parrern + "') = TO_DATE(TO_CHAR(" + dbField1 + ",'" + parrern + "'),'" + parrern + "')");
                ((Map) paramsValue).put(frontKeyStart, frontValueStart);
            } else if (paramsValue instanceof List) {
                str.append(" AND  TO_DATE(?,'" + parrern + "') = TO_DATE(TO_CHAR(" + dbField1 + ",'" + parrern + "'),'" + parrern + "')");
                ((List) paramsValue).add(frontValueStart);
            }
        }
    }

    public static void addParams_LIKE1(String[] dbField, String[] frontKey, Map queryCondition, StringBuilder str, Object paramsValue) {
        if (isNoQueryCondition(queryCondition)) {
            return;
        }
        String frontValue = null;
        for (int i = 0; i < dbField.length; i++) {
            frontValue = getMapValueToString(queryCondition, frontKey[i]);
            if (StringUtils.isNotBlank(frontValue)) {
                if (paramsValue instanceof String) {
                    str.append(" and " + dbField[i] + " like '%" + frontValue + "%'");
                } else if (paramsValue instanceof Map) {
                    str.append(" and " + dbField[i] + " like :" + dbField[i]);
                    ((Map) paramsValue).put(dbField[i], "%" + frontValue + "%");
                } else if (paramsValue instanceof List) {
                    str.append(" and " + dbField[i] + " like ?");
                    ((List) paramsValue).add("%" + frontValue + "%");
                }
            }
        }
    }

    public static void addParams_LIKE2(String[] dbField, String[] frontKey, Map queryCondition, StringBuilder str, Object paramsValue) {
        if (isNoQueryCondition(queryCondition)) {
            return;
        }
        String frontValue = null;
        for (int i = 0; i < dbField.length; i++) {
            frontValue = getMapValueToString(queryCondition, frontKey[i]);
            if (StringUtils.isNotBlank(frontValue)) {
                if (paramsValue instanceof String) {
                    str.append(" and " + dbField[i] + " = '" + frontValue + "'");
                } else if (paramsValue instanceof Map) {
                    str.append(" and " + dbField[i] + " like :" + dbField[i]);
                    ((Map) paramsValue).put(dbField[i], "%" + frontValue + "%");
                } else if (paramsValue instanceof List) {
                    str.append(" and " + dbField[i] + " like ?");
                    ((List) paramsValue).add("%" + frontValue + "%");
                }
            }
        }
    }

    /**
     * 用於報表
     *
     * @param frontKey
     * @param queryCondition
     * @param parameterMap
     */
    public static void addToParameterMap(String[] frontKey, Map queryCondition, Map<String, String> parameterMap) {
        if (isNoQueryCondition(queryCondition)) {
            return;
        }
        String frontValue = null;
        for (int i = 0; i < frontKey.length; i++) {
            frontValue = getMapValueToString(queryCondition, frontKey[i]);
            if (StringUtils.isNotBlank(frontValue)) {
                parameterMap.put(frontKey[i], frontValue);
            }
        }
    }

    /**
     * 用於報表2
     *
     * @param frontKey
     * @param queryCondition
     * @param parameterMap
     */
    public static void addToParameterMap2(String[] frontKey, Map queryCondition, Map<String, Object> parameterMap) {
        if (isNoQueryCondition(queryCondition)) {
            return;
        }
        String frontValue = null;
        for (int i = 0; i < frontKey.length; i++) {
            frontValue = getMapValueToString(queryCondition, frontKey[i]);
            if (StringUtils.isNotBlank(frontValue)) {
                parameterMap.put(frontKey[i], frontValue);
            }
        }
    }

    /**
     * 處裡JxlExcel其BigDecimal轉int
     *
     * @param bigDecimal
     * @return
     */
    public static int procBigDecToInt(BigDecimal bigDecimal) {
        if (bigDecimal == null) return 0;
        return bigDecimal.intValue();
    }

    /**
     * 處裡JxlExcel其String轉""或trim()之後的值
     *
     * @param str
     * @return
     */
    public static String procStringNull(String str) {
        if (str == null) return "";
        return str.trim();
    }
}