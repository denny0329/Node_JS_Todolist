package com.rfep.base;

import javax.servlet.http.HttpServletResponse;

import com.bnq.util.DateTimeUtils;

/**
 * @author Johnson
 * @Date: 2011/01/15 上午 13:00:00
 */
public class JxlExcelBean {


	private JxlExcelBean(){

		this.jxlExcelFileName = DateTimeUtils.getFormatSysDateTimeStr(DateTimeUtils.DEFAULT_DATE_TIME_PATTERN4);
		this.contentDisposition = JxlExcelUtils.CONTENT_DISPOSITION_ATTACHMENT;
	}
	
	public JxlExcelBean(String jxlExcelFileName) throws Exception{
		this();
		if(jxlExcelFileName==null){
			throw new Exception("jxlExcelFileName為null<br>");
		}
		this.jxlExcelFileName=jxlExcelFileName;
	}

	// 設定Excel存檔時的名稱,預設為(yyyy-MM-dd HH:mm:ss)
	private String jxlExcelFileName;

	// 報表要輸出的方式,預設為(附加檔案)
	private String contentDisposition;

	private HttpServletResponse response ;

	public String getJxlExcelFileName() {
		return jxlExcelFileName;
	}

	public void setJxlExcelFileName(String jxlExcelFileName) {
		this.jxlExcelFileName = jxlExcelFileName;
	}

	public String getContentDisposition() {
		return contentDisposition;
	}

	public void setContentDisposition(String contentDisposition) {
		this.contentDisposition = contentDisposition;
	}

	public HttpServletResponse getResponse() {
		return response;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}

	public static void main(String[] args) {

	}
}
