package com.rfep.base;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;

import jxl.format.Alignment;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.format.Colour;
import jxl.format.VerticalAlignment;
import jxl.write.NumberFormat;
import jxl.write.NumberFormats;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;

import org.apache.commons.lang.StringUtils;

/**
 * @author Johnson
 */
public class JxlExcelUtils extends BaseActionImpl{
	private static final long serialVersionUID = -4769849756047276052L;

	public final static String XLS = ".xls";
	public final static String CONTENT_DISPOSITION_IN_LINE = "1"; // Excel要輸出的方式(內崁頁面上)
	public final static String CONTENT_DISPOSITION_ATTACHMENT = "2"; // Excel要輸出的方式(附加檔案)
	 WritableCellFormat wcf_While = null;
	 WritableCellFormat wcf_While_Align_L = null;
	 WritableCellFormat wcf_While_Align_R = null;
	 WritableCellFormat wcf_YELLOW = null;
	 WritableCellFormat wcf_GRAY_25 = null;
	 WritableCellFormat wcf_While_Medium1 = null;
	 WritableCellFormat wcf_While_Medium1_Align_R = null;
	 WritableCellFormat wcf_While_Medium2 = null;
	 WritableCellFormat wcf_While_Medium3 = null;
	 WritableCellFormat wcf_While_Medium4 = null;
	 WritableCellFormat wcf_While_Thin_T_B_Medium_L_R = null;
	 WritableCellFormat wcf_While_Thin_T_B_Medium_L_R_Align_R = null;
	 WritableCellFormat wcf_While_Thin_L_R_Medium_T_B = null;
	 WritableCellFormat wcf_While_Thin_L_R_Medium_T_B_Align_R = null;
	 WritableCellFormat wcf_Thin_B_R_Medium_T_L = null;
	 WritableCellFormat wcf_While_Thin_B_L_R_Medium_T = null;
	 WritableCellFormat wcf_While_Thin_T_R_B_Medium_L = null;
	 WritableCellFormat wcf_While_Thin_T_R_Medium_L_B = null;
	 WritableCellFormat wcf_While_Medium5 = null;
	 WritableCellFormat wcf1_2 = null;
	 WritableCellFormat wcf1_2_RIGHT = null;
	 WritableCellFormat wcf1_2_LEFT = null;
	 WritableCellFormat wcf1_3_LEFT = null;
	 WritableCellFormat wcf2 = null;
	 WritableCellFormat wcf2_black_left = null;
	 WritableCellFormat wcf3 = null;
	 WritableCellFormat wcf3_highlight = null;
	 WritableCellFormat wcf3_left = null;
	 WritableCellFormat wcf4 = null;
	 WritableCellFormat wcf5 = null;
	 WritableCellFormat wcf6 = null;

	/**
	 * 有框線,無加粗,白色,
	 * @param colour
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_While() throws Throwable {

		wcf_While = this.processStyle(WritableFont.class, null, null, null, null, Border.ALL,jxl.format.BorderLineStyle.THIN,null, null,null);
		wcf_While.setWrap(true);//加這一條可以在字串/n
		return wcf_While;
	}
	
	/**
	 * 有框線,無加粗,白色,靠左
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_While_Align_L() throws Throwable {
		wcf_While_Align_L = this.processStyle(WritableFont.class, null, null, null, Alignment.LEFT, Border.ALL,jxl.format.BorderLineStyle.THIN,null, null,null);
		wcf_While_Align_L.setWrap(true);//加這一條可以在字串/n
		return wcf_While_Align_L;
	}
	
	/**
	 * 有框線,無加粗,白色,靠右
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_While_Align_R() throws Throwable {
		wcf_While_Align_R = this.processStyle(WritableFont.class, null, null, null, Alignment.RIGHT, Border.ALL,jxl.format.BorderLineStyle.THIN,null, null,null);
		wcf_While_Align_R.setWrap(true);//加這一條可以在字串/n
		return wcf_While_Align_R;
	}
	
	/**
	 * 有框線,無加粗,黃色,Colour.YELLOW
	 * @param colour
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_YELLOW() throws Throwable {
		wcf_YELLOW = this.processStyle(WritableFont.class, null, Colour.YELLOW.getValue(), null, null, Border.ALL,jxl.format.BorderLineStyle.THIN,null, null,null);
		wcf_YELLOW.setWrap(true);//加這一條可以在字串/n
		return wcf_YELLOW;
	}
	
	/**
	 * 有框線,無加粗,灰色,Colour.GRAY_25
	 * @param colour
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_GRAY_25() throws Throwable {
		wcf_GRAY_25 = this.processStyle(WritableFont.class, null, Colour.GRAY_25.getValue(), null, null, Border.ALL,jxl.format.BorderLineStyle.THIN,null, null,null);
		wcf_GRAY_25.setWrap(true);//加這一條可以在字串/n
		return wcf_GRAY_25;
	}
	
	/**
	 * 有框線,加粗,白色,
	 * @param colour
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_While_MediumALL() throws Throwable {
		wcf_While_Medium1 = this.processStyle(WritableFont.class, null, null, null, null, Border.ALL,jxl.format.BorderLineStyle.MEDIUM,null, null,null);
		wcf_While_Medium1.setWrap(true);//加這一條可以在字串/n
		return wcf_While_Medium1;
	}
	
	/**
	 * 有框線,加粗,白色,
	 * @param colour
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_While_MediumALL_Align_R() throws Throwable {
		wcf_While_Medium1_Align_R = this.processStyle(WritableFont.class, null, null, null, Alignment.RIGHT, Border.ALL,jxl.format.BorderLineStyle.MEDIUM,null, null,null);
		wcf_While_Medium1_Align_R.setWrap(true);//加這一條可以在字串/n
		return wcf_While_Medium1_Align_R;
	}
	
	/**
	 * 框線是上,左,右
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_While_MediumT_L_R() throws Throwable {
		wcf_While_Medium2 = this.processStyleT_L_R(WritableFont.class, null, null, null, null,jxl.format.BorderLineStyle.MEDIUM,null, null,null);
		wcf_While_Medium2.setWrap(true);//加這一條可以在字串/n
		return wcf_While_Medium2;
	}
	
	/**
	 * 框線是左,右
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_While_MediumL_R() throws Throwable {
		wcf_While_Medium3 = this.processStyleL_R(WritableFont.class, null, null, null, null,jxl.format.BorderLineStyle.MEDIUM,null, null,null);
		wcf_While_Medium3.setWrap(true);//加這一條可以在字串/n
		return wcf_While_Medium3;
	}
	/**
	 * 框線是上,左,下
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_While_MediumT_L_B() throws Throwable {
		wcf_While_Medium4 = this.processStyleT_L_B(WritableFont.class, null, null, null, null,jxl.format.BorderLineStyle.MEDIUM,null, null,null);
		wcf_While_Medium4.setWrap(true);//加這一條可以在字串/n
		return wcf_While_Medium4;
	}
	
	/**
	 * 框線是上,下
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_While_MediumT_B() throws Throwable {
		wcf_While_Medium4 = this.processStyleT_B(WritableFont.class, null, null, null, null,jxl.format.BorderLineStyle.MEDIUM,null, null,null);
		wcf_While_Medium4.setWrap(true);//加這一條可以在字串/n
		return wcf_While_Medium4;
	}
	/**
	 * 框線是上,右,下
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_While_MediumT_R_B() throws Throwable {
		wcf_While_Medium5 = this.processStyleT_R_B(WritableFont.class, null, null, null, null,jxl.format.BorderLineStyle.MEDIUM,null, null,null);
		wcf_While_Medium5.setWrap(true);//加這一條可以在字串/n
		return wcf_While_Medium5;
	}

	/**
	 * 有框線,下右有線,上左粗線
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_While_Thin_B_R_Medium_T_L() throws Throwable {
		wcf_Thin_B_R_Medium_T_L = this.processStyle_Thin_B_R_Medium_T_L(WritableFont.class, null, null, null,null,null, null,null);
		wcf_Thin_B_R_Medium_T_L.setWrap(true);//加這一條可以在字串/n
		return wcf_Thin_B_R_Medium_T_L;
	}
	
	/**
	 * 有框線,下左右有線,上粗線,並另外指定文字靠中
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_While_Thin_B_L_R_Medium_T() throws Throwable {
		wcf_While_Thin_B_L_R_Medium_T = this.processStyle_Thin_B_L_R_Medium_T(WritableFont.class, null, null, null, Alignment.CENTRE,null, null,null);
		wcf_While_Thin_B_L_R_Medium_T.setWrap(true);//加這一條可以在字串/n
		return wcf_While_Thin_B_L_R_Medium_T;
	}
	
	/**
	 * 有框線,上右下有線,左粗線
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_While_Thin_T_R_B_Medium_L() throws Throwable {
		wcf_While_Thin_T_R_B_Medium_L = this.processStyle_Thin_T_R_B_Medium_L(WritableFont.class, null, null, null, null,null, null,null);
		wcf_While_Thin_T_R_B_Medium_L.setWrap(true);//加這一條可以在字串/n
		return wcf_While_Thin_T_R_B_Medium_L;
	}
	
	/**
	 * 有框線,上右有線,左下粗線
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_While_Thin_T_R_Medium_L_B() throws Throwable {
		wcf_While_Thin_T_R_Medium_L_B = this.processStyle_Thin_T_R_Medium_L_B(WritableFont.class, null, null, null, null,null, null,null);
		wcf_While_Thin_T_R_Medium_L_B.setWrap(true);//加這一條可以在字串/n
		return wcf_While_Thin_T_R_Medium_L_B;
	}
	
	/**
	 * 有框線,上下有線,左右粗線
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_While_Thin_T_B_Medium_L_R() throws Throwable {
		wcf_While_Thin_T_B_Medium_L_R = this.processStyle_Thin_T_B_Medium_L_R(WritableFont.class, null, null, null, null,null, null,null);
		wcf_While_Thin_T_B_Medium_L_R.setWrap(true);//加這一條可以在字串/n
		return wcf_While_Thin_T_B_Medium_L_R;
	}
	
	/**
	 * 有框線,上下有線,左右粗線,文字靠右
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_While_Thin_T_B_Medium_L_R_Align_R() throws Throwable {
		wcf_While_Thin_T_B_Medium_L_R_Align_R = this.processStyle_Thin_T_B_Medium_L_R(WritableFont.class, null, null, null, Alignment.RIGHT,null, null,null);
		wcf_While_Thin_T_B_Medium_L_R_Align_R.setWrap(true);//加這一條可以在字串/n
		return wcf_While_Thin_T_B_Medium_L_R_Align_R;
	}
	
	/**
	 * 有框線,上下粗線,左右有線
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_While_Thin_L_R_Medium_T_B() throws Throwable {
		wcf_While_Thin_L_R_Medium_T_B = this.processStyle_Thin_L_R_Medium_T_B(WritableFont.class, null, null, null, null,null, null,null);
		wcf_While_Thin_L_R_Medium_T_B.setWrap(true);//加這一條可以在字串/n
		return wcf_While_Thin_L_R_Medium_T_B;
	}
	
	/**
	 * 有框線,上下粗線,左右有線
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf_While_Thin_L_R_Medium_T_B_Align_R() throws Throwable {
		wcf_While_Thin_L_R_Medium_T_B_Align_R = this.processStyle_Thin_L_R_Medium_T_B(WritableFont.class, null, null, null, Alignment.RIGHT,null, null,null);
		wcf_While_Thin_L_R_Medium_T_B_Align_R.setWrap(true);//加這一條可以在字串/n
		return wcf_While_Thin_L_R_Medium_T_B_Align_R;
	}
	
	/**
	 * 無框線,並另外指定文字靠至中
	 * @param align
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf1_2_CENTRE() throws Throwable {
		wcf1_2_RIGHT = this.processStyle(WritableFont.class, null, null, null,Alignment.CENTRE, null,null,12,null, null);
		return wcf1_2_RIGHT;
	}
	
	/**
	 * 無框線,並另外指定文字靠右
	 * @param align
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf1_2_RIGHT() throws Throwable {
		wcf1_2_RIGHT = this.processStyle(WritableFont.class, null, null, null,Alignment.RIGHT, null,null,12,null, null);
		return wcf1_2_RIGHT;
	}
	
	/**
	 * 無框線,並另外指定文字字靠左
	 * @param align
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf1_2_LEFT() throws Throwable {
		wcf1_2_LEFT = this.processStyle(WritableFont.class, null, null, null,Alignment.LEFT, null,null,12,null, null);
		return wcf1_2_LEFT;
	}
	
	/**
	 * 無框線,並另外指定文字對齊方式,外加有底線(要有值,底線才會出來),
	 * @param align
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf1_3_LEFT() throws Throwable {
		wcf1_3_LEFT = this.processStyle(WritableFont.class, null, null, null,Alignment.LEFT, null,null,12,null, jxl.format.UnderlineStyle.SINGLE);
		return wcf1_3_LEFT;
	}
	
	/**
	 * 字紅色,右靠,有框線,無粗,字大小10
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf2() throws Throwable {
		wcf2 = this.processStyle(WritableFont.class, Colour.RED, null,null, Alignment.RIGHT, Border.ALL, jxl.format.BorderLineStyle.THIN, 10, null, null);
		return wcf2;
	}
	
	/**
	 * 有框線,無粗,字大小12
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf3() throws Throwable {
		wcf3 = this.processStyle(WritableFont.class, null, null, null,null, Border.ALL,jxl.format.BorderLineStyle.THIN,12,null,null);
		return wcf3;
	}
	/**
	 * 有框線,無粗,字大小前端傳入
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf3(int match) throws Throwable {
		wcf3 = this.processStyle(WritableFont.class, null, null, null,null, Border.ALL,jxl.format.BorderLineStyle.THIN,match,null,null);
		return wcf3;
	}
	/**
	 * 有框線,無粗,字大小12,灰底
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf3_highlight() throws Throwable {
		//wcf3_highlight = this.processStyle(WritableFont.class, null, null, null,null, Border.ALL,jxl.format.BorderLineStyle.THIN,12,null,null);
		wcf3_highlight = this.processStyle(WritableFont.class, null, Colour.GRAY_50.getValue(), null,null, Border.ALL,jxl.format.BorderLineStyle.THIN,12,null,null);
		return wcf3_highlight;
	}
	
	/**
	 * 有框線,無粗,字大小12,LEFT
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf3_left() throws Throwable {
		wcf3_left = this.processStyle(WritableFont.class, null, null, null,Alignment.LEFT, Border.ALL,jxl.format.BorderLineStyle.THIN,12,null,null);
		return wcf3_left;
	}
	
	/**
	 * 標題
	 * 無框線,字大小16
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat getWcf4() throws Throwable {
		wcf4 = this.processStyle(WritableFont.class, null, null, null, null, null,null,16, null, null);
		return wcf4;
	}
	

//	
//	public WritableCellFormat getWcf2_black_left() throws Throwable {
//		if(wcf2_black_left!=null) return wcf2_black_left;
//		wcf2_black_left = this.processStyle(WritableFont.class, Colour.BLACK, null,null, Alignment.LEFT, Border.ALL, jxl.format.BorderLineStyle.THIN, 10, null, null);
//		return wcf2_black_left;
//	}
//

//
//	public WritableCellFormat getWcf6() throws Throwable {
//		if(wcf6!=null) return wcf6;
//		wcf6 = this.processStyle(NumberFormat.class, null, null, null, Alignment.RIGHT, Border.ALL,jxl.format.BorderLineStyle.THIN,12, null, null);
//		return wcf6;
//	}
	


//	private void createSummy(WritableSheet sheet,Integer[] intArray,String summyName) throws Throwable {
//		if(intArray!=null){
//			int rIndex = 0;
//			int cIndex = 0;
//			rIndex= sheet.getRows();
//			sheet.addCell(new Label(cIndex++,rIndex,summyName,getWcf5()));
//			sheet.addCell(new jxl.write.Number(cIndex++, rIndex,intArray[0]	,getWcf6()));
//			sheet.addCell(new jxl.write.Number(cIndex++, rIndex,intArray[1]	,getWcf6()));
//			sheet.addCell(new jxl.write.Number(cIndex++, rIndex,intArray[2]	,getWcf6()));
//			sheet.addCell(new jxl.write.Number(cIndex++, rIndex,intArray[3]	,getWcf6()));
//			sheet.addCell(new jxl.write.Number(cIndex++, rIndex,intArray[4]	,getWcf6()));
//			sheet.addCell(new jxl.write.Number(cIndex++, rIndex,intArray[5]	,getWcf6()));		
//		}
//	}
	
	private JxlExcelBean jxlExcelBean;

	public JxlExcelBean getJxlExcelBean() {
		return jxlExcelBean;
	}

	public void setJxlExcelBean(JxlExcelBean jxlExcelBean) {
		this.jxlExcelBean = jxlExcelBean;
	}
	
	/**
	 * 手動指定Excel上面欄位的代號,比方:A,AA,AB,代號目前只支援到1~2位數
	 * @param str
	 * @return
	 */
	public int getX(String str){
		if(StringUtils.isBlank(str)){
			return 0;
		}
		str = str.trim().toUpperCase();
		if(str.length()==1){
			int value = (int)str.toCharArray()[0];
			return value-65;
		}
		
		if(str.length()==2){
			int value1 = (int)str.toCharArray()[0];
			int value2 = (int)str.toCharArray()[1];
			return (26*(value1-64))+(value2-65);
		}
		return 0;
	}
	/**
	 * 手動指定Excel左邊欄位的index
	 * @param i
	 * @return
	 */
	public int getY(int i){
		if(i<=0) return 0;
		return i-1;
	}
	
	public WritableCellFormat processStyle(
			Class classType,
			Colour fontColor, 
			Integer backgroundColor,
			VerticalAlignment vStyle, 
			Alignment cStyle, 
			Border borderStyle,
			BorderLineStyle borderLineStyle,
			Integer fontSize, 
			String numberFormat,
			jxl.format.UnderlineStyle underLine) throws Throwable {
		
		WritableCellFormat returnVal = null;
		if (WritableFont.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new WritableFont(
									WritableFont.createFont("細明體"), 
									(fontSize != null ? fontSize : 12),
									jxl.write.WritableFont.NO_BOLD, 
									false,
									(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
									(fontColor != null ? fontColor : Colour.BLACK)
							)
						);

		} else if (NumberFormat.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(
									StringUtils.isNotBlank(numberFormat) ? numberFormat : "#,##0_"));
		} else if (NumberFormats.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00"));
		} else if (Number.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00%"));
		}

		if (returnVal != null) {
			if (backgroundColor != null) {
				returnVal.setBackground(Colour.getInternalColour(backgroundColor));
			}
			
			returnVal.setVerticalAlignment(vStyle != null ? vStyle: VerticalAlignment.CENTRE);
			returnVal.setAlignment(cStyle != null ? cStyle : Alignment.CENTRE);
			returnVal.setFont(
					new WritableFont(
							WritableFont.createFont("細明體"),
							(fontSize != null ? fontSize : 12),
							jxl.write.WritableFont.NO_BOLD,
							false,
							(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
							(fontColor != null ? fontColor : Colour.BLACK)
					)
			);
			
			if(borderStyle!=null){
				returnVal.setBorder(borderStyle, borderLineStyle);
			}
		}
		return returnVal;
	}
	
	/**
	 * 框線是上,左,右
	 * @param classType
	 * @param fontColor
	 * @param backgroundColor
	 * @param vStyle
	 * @param cStyle
	 * @param borderLineStyle
	 * @param fontSize
	 * @param numberFormat
	 * @param underLine
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat processStyleT_L_R(
			Class classType,
			Colour fontColor, 
			Integer backgroundColor,
			VerticalAlignment vStyle, 
			Alignment cStyle, 
			BorderLineStyle borderLineStyle,
			Integer fontSize, 
			String numberFormat,
			jxl.format.UnderlineStyle underLine) throws Throwable {
		
		WritableCellFormat returnVal = null;
		if (WritableFont.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new WritableFont(
									WritableFont.createFont("細明體"), 
									(fontSize != null ? fontSize : 12),
									jxl.write.WritableFont.NO_BOLD, 
									false,
									(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
									(fontColor != null ? fontColor : Colour.BLACK)
							)
						);

		} else if (NumberFormat.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(
									StringUtils.isNotBlank(numberFormat) ? numberFormat : "#,##0_"));
		} else if (NumberFormats.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00"));
		} else if (Number.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00%"));
		}

		if (returnVal != null) {
			if (backgroundColor != null) {
				returnVal.setBackground(Colour.getInternalColour(backgroundColor));
			}
			
			returnVal.setVerticalAlignment(vStyle != null ? vStyle: VerticalAlignment.CENTRE);
			returnVal.setAlignment(cStyle != null ? cStyle : Alignment.CENTRE);
			returnVal.setFont(
					new WritableFont(
							WritableFont.createFont("細明體"),
							(fontSize != null ? fontSize : 12),
							jxl.write.WritableFont.NO_BOLD,
							false,
							(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
							(fontColor != null ? fontColor : Colour.BLACK)
					)
			);
			returnVal.setBorder(Border.TOP, borderLineStyle);
			returnVal.setBorder(Border.LEFT, borderLineStyle);
			returnVal.setBorder(Border.RIGHT, borderLineStyle);
		}
		return returnVal;
	}
	
	/**
	 * 框線是下,左,右
	 * @param classType
	 * @param fontColor
	 * @param backgroundColor
	 * @param vStyle
	 * @param cStyle
	 * @param borderLineStyle
	 * @param fontSize
	 * @param numberFormat
	 * @param underLine
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat processStyleB_L_R(
			Class classType,
			Colour fontColor, 
			Integer backgroundColor,
			VerticalAlignment vStyle, 
			Alignment cStyle, 
			BorderLineStyle borderLineStyle,
			Integer fontSize, 
			String numberFormat,
			jxl.format.UnderlineStyle underLine) throws Throwable {
		
		WritableCellFormat returnVal = null;
		if (WritableFont.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new WritableFont(
									WritableFont.createFont("細明體"), 
									(fontSize != null ? fontSize : 12),
									jxl.write.WritableFont.NO_BOLD, 
									false,
									(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
									(fontColor != null ? fontColor : Colour.BLACK)
							)
						);

		} else if (NumberFormat.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(
									StringUtils.isNotBlank(numberFormat) ? numberFormat : "#,##0_"));
		} else if (NumberFormats.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00"));
		} else if (Number.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00%"));
		}

		if (returnVal != null) {
			if (backgroundColor != null) {
				returnVal.setBackground(Colour.getInternalColour(backgroundColor));
			}
			
			returnVal.setVerticalAlignment(vStyle != null ? vStyle: VerticalAlignment.CENTRE);
			returnVal.setAlignment(cStyle != null ? cStyle : Alignment.CENTRE);
			returnVal.setFont(
					new WritableFont(
							WritableFont.createFont("細明體"),
							(fontSize != null ? fontSize : 12),
							jxl.write.WritableFont.NO_BOLD,
							false,
							(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
							(fontColor != null ? fontColor : Colour.BLACK)
					)
			);
			returnVal.setBorder(Border.BOTTOM, borderLineStyle);
			returnVal.setBorder(Border.LEFT, borderLineStyle);
			returnVal.setBorder(Border.RIGHT, borderLineStyle);
		}
		return returnVal;
	}
	
	/**
	 * 框線是上,下
	 * @param classType
	 * @param fontColor
	 * @param backgroundColor
	 * @param vStyle
	 * @param cStyle
	 * @param borderLineStyle
	 * @param fontSize
	 * @param numberFormat
	 * @param underLine
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat processStyleT_B(
			Class classType,
			Colour fontColor, 
			Integer backgroundColor,
			VerticalAlignment vStyle, 
			Alignment cStyle, 
			BorderLineStyle borderLineStyle,
			Integer fontSize, 
			String numberFormat,
			jxl.format.UnderlineStyle underLine) throws Throwable {
		
		WritableCellFormat returnVal = null;
		if (WritableFont.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new WritableFont(
									WritableFont.createFont("細明體"), 
									(fontSize != null ? fontSize : 12),
									jxl.write.WritableFont.NO_BOLD, 
									false,
									(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
									(fontColor != null ? fontColor : Colour.BLACK)
							)
						);

		} else if (NumberFormat.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(
									StringUtils.isNotBlank(numberFormat) ? numberFormat : "#,##0_"));
		} else if (NumberFormats.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00"));
		} else if (Number.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00%"));
		}

		if (returnVal != null) {
			if (backgroundColor != null) {
				returnVal.setBackground(Colour.getInternalColour(backgroundColor));
			}
			
			returnVal.setVerticalAlignment(vStyle != null ? vStyle: VerticalAlignment.CENTRE);
			returnVal.setAlignment(cStyle != null ? cStyle : Alignment.CENTRE);
			returnVal.setFont(
					new WritableFont(
							WritableFont.createFont("細明體"),
							(fontSize != null ? fontSize : 12),
							jxl.write.WritableFont.NO_BOLD,
							false,
							(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
							(fontColor != null ? fontColor : Colour.BLACK)
					)
			);
			
			returnVal.setBorder(Border.TOP, borderLineStyle);
			returnVal.setBorder(Border.BOTTOM, borderLineStyle);
		}
		return returnVal;
	}
	
	/**
	 * 框線是左,右
	 * @param classType
	 * @param fontColor
	 * @param backgroundColor
	 * @param vStyle
	 * @param cStyle
	 * @param borderLineStyle
	 * @param fontSize
	 * @param numberFormat
	 * @param underLine
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat processStyleL_R(
			Class classType,
			Colour fontColor, 
			Integer backgroundColor,
			VerticalAlignment vStyle, 
			Alignment cStyle, 
			BorderLineStyle borderLineStyle,
			Integer fontSize, 
			String numberFormat,
			jxl.format.UnderlineStyle underLine) throws Throwable {
		
		WritableCellFormat returnVal = null;
		if (WritableFont.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new WritableFont(
									WritableFont.createFont("細明體"), 
									(fontSize != null ? fontSize : 12),
									jxl.write.WritableFont.NO_BOLD, 
									false,
									(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
									(fontColor != null ? fontColor : Colour.BLACK)
							)
						);

		} else if (NumberFormat.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(
									StringUtils.isNotBlank(numberFormat) ? numberFormat : "#,##0_"));
		} else if (NumberFormats.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00"));
		} else if (Number.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00%"));
		}

		if (returnVal != null) {
			if (backgroundColor != null) {
				returnVal.setBackground(Colour.getInternalColour(backgroundColor));
			}
			
			returnVal.setVerticalAlignment(vStyle != null ? vStyle: VerticalAlignment.CENTRE);
			returnVal.setAlignment(cStyle != null ? cStyle : Alignment.CENTRE);
			returnVal.setFont(
					new WritableFont(
							WritableFont.createFont("細明體"),
							(fontSize != null ? fontSize : 12),
							jxl.write.WritableFont.NO_BOLD,
							false,
							(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
							(fontColor != null ? fontColor : Colour.BLACK)
					)
			);
			
			returnVal.setBorder(Border.LEFT, borderLineStyle);
			returnVal.setBorder(Border.RIGHT, borderLineStyle);
		}
		return returnVal;
	}

	/**
	 * 框線是上,左,下
	 * @param classType
	 * @param fontColor
	 * @param backgroundColor
	 * @param vStyle
	 * @param cStyle
	 * @param borderLineStyle
	 * @param fontSize
	 * @param numberFormat
	 * @param underLine
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat processStyleT_L_B(
			Class classType,
			Colour fontColor, 
			Integer backgroundColor,
			VerticalAlignment vStyle, 
			Alignment cStyle, 
			BorderLineStyle borderLineStyle,
			Integer fontSize, 
			String numberFormat,
			jxl.format.UnderlineStyle underLine) throws Throwable {
		
		WritableCellFormat returnVal = null;
		if (WritableFont.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new WritableFont(
									WritableFont.createFont("細明體"), 
									(fontSize != null ? fontSize : 12),
									jxl.write.WritableFont.NO_BOLD, 
									false,
									(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
									(fontColor != null ? fontColor : Colour.BLACK)
							)
						);

		} else if (NumberFormat.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(
									StringUtils.isNotBlank(numberFormat) ? numberFormat : "#,##0_"));
		} else if (NumberFormats.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00"));
		} else if (Number.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00%"));
		}

		if (returnVal != null) {
			if (backgroundColor != null) {
				returnVal.setBackground(Colour.getInternalColour(backgroundColor));
			}
			
			returnVal.setVerticalAlignment(vStyle != null ? vStyle: VerticalAlignment.CENTRE);
			returnVal.setAlignment(cStyle != null ? cStyle : Alignment.CENTRE);
			returnVal.setFont(
					new WritableFont(
							WritableFont.createFont("細明體"),
							(fontSize != null ? fontSize : 12),
							jxl.write.WritableFont.NO_BOLD,
							false,
							(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
							(fontColor != null ? fontColor : Colour.BLACK)
					)
			);
			
			returnVal.setBorder(Border.TOP, borderLineStyle);
			returnVal.setBorder(Border.LEFT, borderLineStyle);
			returnVal.setBorder(Border.BOTTOM, borderLineStyle);
		}
		return returnVal;
	}
	
	/**
	 * 框線是上,右,下
	 * @param classType
	 * @param fontColor
	 * @param backgroundColor
	 * @param vStyle
	 * @param cStyle
	 * @param borderLineStyle
	 * @param fontSize
	 * @param numberFormat
	 * @param underLine
	 * @return
	 * @throws Throwable
	 */
	public WritableCellFormat processStyleT_R_B(
			Class classType,
			Colour fontColor, 
			Integer backgroundColor,
			VerticalAlignment vStyle, 
			Alignment cStyle, 
			BorderLineStyle borderLineStyle,
			Integer fontSize, 
			String numberFormat,
			jxl.format.UnderlineStyle underLine) throws Throwable {
		
		WritableCellFormat returnVal = null;
		if (WritableFont.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new WritableFont(
									WritableFont.createFont("細明體"), 
									(fontSize != null ? fontSize : 12),
									jxl.write.WritableFont.NO_BOLD, 
									false,
									(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
									(fontColor != null ? fontColor : Colour.BLACK)
							)
						);

		} else if (NumberFormat.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(
									StringUtils.isNotBlank(numberFormat) ? numberFormat : "#,##0_"));
		} else if (NumberFormats.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00"));
		} else if (Number.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00%"));
		}

		if (returnVal != null) {
			if (backgroundColor != null) {
				returnVal.setBackground(Colour.getInternalColour(backgroundColor));
			}
			
			returnVal.setVerticalAlignment(vStyle != null ? vStyle: VerticalAlignment.CENTRE);
			returnVal.setAlignment(cStyle != null ? cStyle : Alignment.CENTRE);
			returnVal.setFont(
					new WritableFont(
							WritableFont.createFont("細明體"),
							(fontSize != null ? fontSize : 12),
							jxl.write.WritableFont.NO_BOLD,
							false,
							(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
							(fontColor != null ? fontColor : Colour.BLACK)
					)
			);
			
			returnVal.setBorder(Border.TOP, borderLineStyle);
			returnVal.setBorder(Border.RIGHT, borderLineStyle);
			returnVal.setBorder(Border.BOTTOM, borderLineStyle);
		}
		return returnVal;
	}

	public WritableCellFormat processStyle_Thin_B_R_Medium_T_L(
			Class classType,
			Colour fontColor, 
			Integer backgroundColor,
			VerticalAlignment vStyle, 
			Alignment cStyle, 
			Integer fontSize, 
			String numberFormat,
			jxl.format.UnderlineStyle underLine) throws Throwable {
		
		WritableCellFormat returnVal = null;
		if (WritableFont.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new WritableFont(
									WritableFont.createFont("細明體"), 
									(fontSize != null ? fontSize : 12),
									jxl.write.WritableFont.NO_BOLD, 
									false,
									(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
									(fontColor != null ? fontColor : Colour.BLACK)
							)
						);

		} else if (NumberFormat.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(
									StringUtils.isNotBlank(numberFormat) ? numberFormat : "#,##0_"));
		} else if (NumberFormats.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00"));
		} else if (Number.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00%"));
		}

		if (returnVal != null) {
			if (backgroundColor != null) {
				returnVal.setBackground(Colour.getInternalColour(backgroundColor));
			}
			
			returnVal.setVerticalAlignment(vStyle != null ? vStyle: VerticalAlignment.CENTRE);
			returnVal.setAlignment(cStyle != null ? cStyle : Alignment.CENTRE);
			returnVal.setFont(
					new WritableFont(
							WritableFont.createFont("細明體"),
							(fontSize != null ? fontSize : 12),
							jxl.write.WritableFont.NO_BOLD,
							false,
							(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
							(fontColor != null ? fontColor : Colour.BLACK)
					)
			);
			returnVal.setBorder(Border.TOP, BorderLineStyle.MEDIUM);
			returnVal.setBorder(Border.BOTTOM, BorderLineStyle.THIN);
			returnVal.setBorder(Border.LEFT, BorderLineStyle.MEDIUM);
			returnVal.setBorder(Border.RIGHT, BorderLineStyle.THIN);
		}
		return returnVal;
	}
	
	public WritableCellFormat processStyle_Thin_B_L_R_Medium_T(
			Class classType,
			Colour fontColor, 
			Integer backgroundColor,
			VerticalAlignment vStyle, 
			Alignment cStyle, 
			Integer fontSize, 
			String numberFormat,
			jxl.format.UnderlineStyle underLine) throws Throwable {
		
		WritableCellFormat returnVal = null;
		if (WritableFont.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new WritableFont(
									WritableFont.createFont("細明體"), 
									(fontSize != null ? fontSize : 12),
									jxl.write.WritableFont.NO_BOLD, 
									false,
									(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
									(fontColor != null ? fontColor : Colour.BLACK)
							)
						);

		} else if (NumberFormat.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(
									StringUtils.isNotBlank(numberFormat) ? numberFormat : "#,##0_"));
		} else if (NumberFormats.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00"));
		} else if (Number.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00%"));
		}

		if (returnVal != null) {
			if (backgroundColor != null) {
				returnVal.setBackground(Colour.getInternalColour(backgroundColor));
			}
			
			returnVal.setVerticalAlignment(vStyle != null ? vStyle: VerticalAlignment.CENTRE);
			returnVal.setAlignment(cStyle != null ? cStyle : Alignment.CENTRE);
			returnVal.setFont(
					new WritableFont(
							WritableFont.createFont("細明體"),
							(fontSize != null ? fontSize : 12),
							jxl.write.WritableFont.NO_BOLD,
							false,
							(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
							(fontColor != null ? fontColor : Colour.BLACK)
					)
			);
			
			returnVal.setBorder(Border.TOP, BorderLineStyle.MEDIUM);
			returnVal.setBorder(Border.BOTTOM, BorderLineStyle.THIN);
			returnVal.setBorder(Border.LEFT, BorderLineStyle.THIN);
			returnVal.setBorder(Border.RIGHT, BorderLineStyle.THIN);
		}
		return returnVal;
	}
	
	public WritableCellFormat processStyle_Thin_T_R_B_Medium_L(
			Class classType,
			Colour fontColor, 
			Integer backgroundColor,
			VerticalAlignment vStyle, 
			Alignment cStyle, 
			Integer fontSize, 
			String numberFormat,
			jxl.format.UnderlineStyle underLine) throws Throwable {
		
		WritableCellFormat returnVal = null;
		if (WritableFont.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new WritableFont(
									WritableFont.createFont("細明體"), 
									(fontSize != null ? fontSize : 12),
									jxl.write.WritableFont.NO_BOLD, 
									false,
									(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
									(fontColor != null ? fontColor : Colour.BLACK)
							)
						);

		} else if (NumberFormat.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(
									StringUtils.isNotBlank(numberFormat) ? numberFormat : "#,##0_"));
		} else if (NumberFormats.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00"));
		} else if (Number.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00%"));
		}

		if (returnVal != null) {
			if (backgroundColor != null) {
				returnVal.setBackground(Colour.getInternalColour(backgroundColor));
			}
			
			returnVal.setVerticalAlignment(vStyle != null ? vStyle: VerticalAlignment.CENTRE);
			returnVal.setAlignment(cStyle != null ? cStyle : Alignment.CENTRE);
			returnVal.setFont(
					new WritableFont(
							WritableFont.createFont("細明體"),
							(fontSize != null ? fontSize : 12),
							jxl.write.WritableFont.NO_BOLD,
							false,
							(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
							(fontColor != null ? fontColor : Colour.BLACK)
					)
			);

			returnVal.setBorder(Border.TOP, BorderLineStyle.THIN);
			returnVal.setBorder(Border.BOTTOM, BorderLineStyle.THIN);
			returnVal.setBorder(Border.LEFT, BorderLineStyle.MEDIUM);
			returnVal.setBorder(Border.RIGHT, BorderLineStyle.THIN);
		}
		return returnVal;
	}
	
	public WritableCellFormat processStyle_Thin_T_B_Medium_L_R(
			Class classType,
			Colour fontColor, 
			Integer backgroundColor,
			VerticalAlignment vStyle, 
			Alignment cStyle, 
			Integer fontSize, 
			String numberFormat,
			jxl.format.UnderlineStyle underLine) throws Throwable {
		
		WritableCellFormat returnVal = null;
		if (WritableFont.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new WritableFont(
									WritableFont.createFont("細明體"), 
									(fontSize != null ? fontSize : 12),
									jxl.write.WritableFont.NO_BOLD, 
									false,
									(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
									(fontColor != null ? fontColor : Colour.BLACK)
							)
						);

		} else if (NumberFormat.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(
									StringUtils.isNotBlank(numberFormat) ? numberFormat : "#,##0_"));
		} else if (NumberFormats.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00"));
		} else if (Number.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00%"));
		}

		if (returnVal != null) {
			if (backgroundColor != null) {
				returnVal.setBackground(Colour.getInternalColour(backgroundColor));
			}
			
			returnVal.setVerticalAlignment(vStyle != null ? vStyle: VerticalAlignment.CENTRE);
			returnVal.setAlignment(cStyle != null ? cStyle : Alignment.CENTRE);
			returnVal.setFont(
					new WritableFont(
							WritableFont.createFont("細明體"),
							(fontSize != null ? fontSize : 12),
							jxl.write.WritableFont.NO_BOLD,
							false,
							(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
							(fontColor != null ? fontColor : Colour.BLACK)
					)
			);
			
			returnVal.setBorder(Border.TOP, BorderLineStyle.THIN);
			returnVal.setBorder(Border.BOTTOM, BorderLineStyle.THIN);
			returnVal.setBorder(Border.LEFT, BorderLineStyle.MEDIUM);
			returnVal.setBorder(Border.RIGHT, BorderLineStyle.MEDIUM);
		}
		return returnVal;
	}
	
	public WritableCellFormat processStyle_Thin_T_R_Medium_L_B(
			Class classType,
			Colour fontColor, 
			Integer backgroundColor,
			VerticalAlignment vStyle, 
			Alignment cStyle, 
			Integer fontSize, 
			String numberFormat,
			jxl.format.UnderlineStyle underLine) throws Throwable {
		
		WritableCellFormat returnVal = null;
		if (WritableFont.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new WritableFont(
									WritableFont.createFont("細明體"), 
									(fontSize != null ? fontSize : 12),
									jxl.write.WritableFont.NO_BOLD, 
									false,
									(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
									(fontColor != null ? fontColor : Colour.BLACK)
							)
						);

		} else if (NumberFormat.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(
									StringUtils.isNotBlank(numberFormat) ? numberFormat : "#,##0_"));
		} else if (NumberFormats.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00"));
		} else if (Number.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00%"));
		}

		if (returnVal != null) {
			if (backgroundColor != null) {
				returnVal.setBackground(Colour.getInternalColour(backgroundColor));
			}
			
			returnVal.setVerticalAlignment(vStyle != null ? vStyle: VerticalAlignment.CENTRE);
			returnVal.setAlignment(cStyle != null ? cStyle : Alignment.CENTRE);
			returnVal.setFont(
					new WritableFont(
							WritableFont.createFont("細明體"),
							(fontSize != null ? fontSize : 12),
							jxl.write.WritableFont.NO_BOLD,
							false,
							(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
							(fontColor != null ? fontColor : Colour.BLACK)
					)
			);
			
			returnVal.setBorder(Border.TOP, BorderLineStyle.THIN);
			returnVal.setBorder(Border.BOTTOM, BorderLineStyle.MEDIUM);
			returnVal.setBorder(Border.LEFT, BorderLineStyle.MEDIUM);
			returnVal.setBorder(Border.RIGHT, BorderLineStyle.THIN);
		}
		return returnVal;
	}
	
	public WritableCellFormat processStyle_Thin_L_R_Medium_T_B(
			Class classType,
			Colour fontColor, 
			Integer backgroundColor,
			VerticalAlignment vStyle, 
			Alignment cStyle, 
			Integer fontSize, 
			String numberFormat,
			jxl.format.UnderlineStyle underLine) throws Throwable {
		
		WritableCellFormat returnVal = null;
		if (WritableFont.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new WritableFont(
									WritableFont.createFont("細明體"), 
									(fontSize != null ? fontSize : 12),
									jxl.write.WritableFont.NO_BOLD, 
									false,
									(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
									(fontColor != null ? fontColor : Colour.BLACK)
							)
						);

		} else if (NumberFormat.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(
									StringUtils.isNotBlank(numberFormat) ? numberFormat : "#,##0_"));
		} else if (NumberFormats.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00"));
		} else if (Number.class.equals(classType)) {
			returnVal = new WritableCellFormat(
							new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00%"));
		}

		if (returnVal != null) {
			if (backgroundColor != null) {
				returnVal.setBackground(Colour.getInternalColour(backgroundColor));
			}
			
			returnVal.setVerticalAlignment(vStyle != null ? vStyle: VerticalAlignment.CENTRE);
			returnVal.setAlignment(cStyle != null ? cStyle : Alignment.CENTRE);
			returnVal.setFont(
					new WritableFont(
							WritableFont.createFont("細明體"),
							(fontSize != null ? fontSize : 12),
							jxl.write.WritableFont.NO_BOLD,
							false,
							(underLine != null ? underLine: jxl.format.UnderlineStyle.NO_UNDERLINE),
							(fontColor != null ? fontColor : Colour.BLACK)
					)
			);
			returnVal.setBorder(Border.LEFT, BorderLineStyle.THIN);
			returnVal.setBorder(Border.RIGHT, BorderLineStyle.THIN);
			returnVal.setBorder(Border.TOP, BorderLineStyle.MEDIUM);
			returnVal.setBorder(Border.BOTTOM, BorderLineStyle.MEDIUM);
		}
		return returnVal;
	}
	
	/**
	 * 處理內容配置
	 * 
	 * @author Johnson
	 * @Date: 2011/01/15 上午 13:00:00
	 * @throws Exception
	 */
	private void processContentDisposition() throws Exception {
		// 1620 
		// 1621
		
		getJxlExcelBean().getResponse().reset();
		getJxlExcelBean().getResponse().setContentType("application/vnd.ms-excel");

		if (StringUtils.isBlank(getJxlExcelBean().getContentDisposition())) {
			throw new Exception("請設定contentDisposition<br>");
		}

		String fileNameUTF8 = processJxlExcelFileName();
		if (getJxlExcelBean().getContentDisposition().equals(CONTENT_DISPOSITION_IN_LINE)) {
			getJxlExcelBean().getResponse().setHeader("Content-disposition","inline ; filename*=utf-8''" + fileNameUTF8 + XLS);// 內崁檔案
			//getJxlExcelBean().getResponse().setHeader(
			//		"Content-disposition",
			//		"inline ; filename=" + processJxlExcelFileName()+ XLS);// 內崁檔案
		} else if (getJxlExcelBean().getContentDisposition().equals(CONTENT_DISPOSITION_ATTACHMENT)) {
			getJxlExcelBean().getResponse().setHeader("Content-disposition","attachment ; filename*=utf-8''" + fileNameUTF8 + XLS);// 附加檔案
			//getJxlExcelBean().getResponse().setHeader(
			//		"Content-disposition",
			//		"attachment ; filename=" + processJxlExcelFileName()+ XLS);// 附加檔案
		} else {
			throw new Exception("contentDisposition設定錯誤<br>");
		}
	}

	/**
	 * 處理報表檔案名稱的轉碼
	 * 
	 * @author Johnson
	 * @Date: 2011/01/15 上午 13:00:00
	 * @return
	 * @throws Exception
	 */
	private String processJxlExcelFileName() throws Exception {
		if (StringUtils.isBlank(getJxlExcelBean().getJxlExcelFileName())) {
			throw new Exception("請設定excelFileName<br>");
		}

		try {
			return java.net.URLEncoder.encode(getJxlExcelBean().getJxlExcelFileName(), "UTF-8");
			//return new String(getJxlExcelBean().getJxlExcelFileName().getBytes(
			//		"big5"), "ISO8859-1");// 中文時會有亂數
		} catch (UnsupportedEncodingException ex) {
			ex.printStackTrace();
			throw new Exception("報表名稱轉碼其失敗原因：" + ex.getMessage() + "<br>");
		}
	}

	/**
	 * 將EXCEL輸出到Client端瀏覽器
	 * 
	 * @author Johnson
	 * @Date: 2011/01/15 上午 13:00:00
	 * @param bytes
	 * @throws Exception
	 */
	public void genEXCELtoWeb(JxlExcelBean jxlExcelBean,byte[] bytes) throws Exception {
		try {
			if (jxlExcelBean == null) {
				throw new Exception("jxlExcelBean為null<br>");
			}
			this.setJxlExcelBean(jxlExcelBean);
			processWebOutput(bytes);
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new Exception("產生Excel檔發生錯誤:" + ex.getMessage());
		}
	}
	
	/**
	 * 將EXCEL輸出到Server端的硬碟某一個位置
	 * 
	 * @author Johnson
	 * @Date: 2011/01/15 上午 13:00:00
	 * @param bytes
	 * @throws Exception
	 */
	public void genEXCELtoFile(JxlExcelBean jxlExcelBean,byte[] bytes) throws Exception {
		try {
			if (jxlExcelBean == null) {
				throw new Exception("jxlExcelBean為null<br>");
			}
			this.setJxlExcelBean(jxlExcelBean);
			processFileOutput(bytes);
		} catch (Exception ex) {
			System.out.print("Server端,產生Excel檔發生錯誤:" + ex.getMessage());
			ex.printStackTrace();
			return;
		}
	}
	
	/**
	 * Excel將輸出在Server端
	 * 
	 * @author Johnson
	 * @Date: 2011/01/15 上午 13:00:00
	 * @param bytes
	 * @throws FileNotFoundException
	 * @throws Exception
	 */
	private void processFileOutput(byte[] bytes) throws FileNotFoundException,Exception {
		FileOutputStream fileOutputStream = new FileOutputStream(new File("C:\\"+ processJxlExcelFileName() + XLS));
		fileOutputStream.write(bytes);
		fileOutputStream.flush();// ?
		fileOutputStream.close();
	}

	/**
	 * Excel將輸出在Client端
	 * 
	 * @author Johnson
	 * @Date: 2011/01/15 上午 13:00:00
	 * @param bytes
	 * @throws Exception
	 */
	private void processWebOutput(byte[] bytes) throws Exception {
		processContentDisposition();
		OutputStream ouputStream = this.getJxlExcelBean().getResponse().getOutputStream();
		System.out.println("ouputStream>>"+ouputStream);
		ouputStream.write(bytes);
		ouputStream.flush();
		ouputStream.close();
	}
	
	/**
	 * @param args
	 * @throws Throwable 
	 */
	public static void main(String[] args) throws Throwable {
		// TODO Auto-generated method stub
		System.out.println(new JxlExcelUtils().getX("a"));//0
		System.out.println(new JxlExcelUtils().getX("aa"));//26
		System.out.println(new JxlExcelUtils().getX("ba"));//52
	}
}
