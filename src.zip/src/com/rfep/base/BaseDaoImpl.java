/**
 * @(#)BaseDaoImpl.java 2014/01/13
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.rfep.base;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.transform.Transformers;
import org.hibernate.type.Type;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * 資料存取層Hibernate的基礎類別，提供對Hibernate資料存取之共用方法
 * 
 * @author Johnson
 * @Date: 2010/10/01 上午 13:00:00
 */
public class BaseDaoImpl<T> extends HibernateDaoSupport implements BaseDaoI<T> {
	private final Logger log = LogManager.getLogger(BaseDaoImpl.class);
	/* HQL基本操作 */
    /**
     * 使用HQL語句,新增、更新、刪除實體
     * @param hql			hql語法
     * @return				返回值小於0,即失敗
     */
    public int bulkUpdate(String hql){
    	log.debug("bulkUpdate");
        return getHibernateTemplate().bulkUpdate(hql);
    }

    /**
     * 使用帶參數的HQL語句,新增、更新、刪除實體
	 * @param hql			hql語法
	 * @param paramsValue	查詢參數
     * @return				返回值小於0,即失敗
     */
    public int bulkUpdate(String hql, Object[] paramsValue){
    	log.debug("bulkUpdate");
        return getHibernateTemplate().bulkUpdate(hql, paramsValue);
    }
    
	/* HQL基本find */
    /**
     * 使用HQL語句,查詢實體
	 * @param hql			hql語法
     * @return
     */
    @SuppressWarnings("rawtypes")
	public List find(String hql){
    	log.debug("find");
        return getHibernateTemplate().find(hql);
    }
    
    /**
     * 使用帶參數的HQL語句,查詢實體
	 * @param hql			hql語法
	 * @param paramsValue	查詢參數
     * @return
     */
    @SuppressWarnings("rawtypes")
	public List find(String hql,Object paramsValue){
    	log.debug("find");
        return getHibernateTemplate().find(hql,paramsValue);
    }

    /**
     * 使用帶參數的HQL語句,查詢實體
	 * @param hql			hql語法
	 * @param paramsValue	查詢參數
     * @return
     */
    @SuppressWarnings("rawtypes")
	public List find(String hql, Object[] paramsValue){
    	log.debug("find");
        return getHibernateTemplate().find(hql, paramsValue);
    }
    
	/* POJO基本操作 */
	/**
	 * 根據entityClass和id來刪除POJO實體物件
	 * @param entityClass 	POJO實體物件的class
	 * @param id 			這裡的id是指主鍵,也就是*.hbm.xml檔內<id></id>標籤
	 * @return
	 */
	public void deleteById(Class<T> entityClass, String id) {
		log.debug("deleteById");
		try {
			delete(findById(entityClass, id));
		} catch (RuntimeException re) {
			log.error("deleteById failed", re);
			throw re;
		}
	}
	
	/**
	 * 儲存POJO實體物件
	 * @param transientInstance
	 */
	public void save(T transientInstance) {
		log.debug("save");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}
	
	/**
	 * 刪除POJO實體物件
	 * @param persistentInstance
	 */
	public void delete(T persistentInstance) {
		log.debug("delete");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}
	
	/**
	 * 儲存或更新 POJO實體物件
	 * @param transientInstance
	 */
	public void saveOrUpdate(T transientInstance) {
		log.debug("saveOrUpdate");
		try {
			getHibernateTemplate().saveOrUpdate(transientInstance);
			log.debug("saveOrUpdate successful");
		} catch (RuntimeException re) {
			log.error("saveOrUpdate failed", re);
			throw re;
		}
	}

	/**
	 * 儲存或更新全部的POJO實體物件
	 * @param transientInstance
	 */
	public void saveOrUpdateAll(Collection<T> transientInstance) {
		log.debug("saveOrUpdateAll");
		try {
			getHibernateTemplate().saveOrUpdateAll(transientInstance);
			log.debug("saveOrUpdateAll successful");
		} catch (RuntimeException re) {
			log.error("saveOrUpdateAll failed", re);
			throw re;
		}
	}

	/**
	 * 刪除全部的POJO實體物件
	 * @param transientInstance
	 */
	public void deleteAll(Collection<T> transientInstance) {
		log.debug("deleteAll");
		try {
			getHibernateTemplate().deleteAll(transientInstance);
			log.debug("deleteAll successful");
		} catch (RuntimeException re) {
			log.error("deleteAll failed", re);
			throw re;
		}
	}

	/* POJO基本find */
	/**
	 * 根據entityClass和id來尋找POJO實體物件
	 * @param entityClass 	POJO實體物件的class
	 * @param id 			這裡的id是指主鍵,也就是*.hbm.xml檔內<id></id>標籤
	 * @return 				當記錄不存在時候，get方法返回null
	 */
	public T findById(Class<T> entityClass, String id) {
		log.debug("findById");
		try {
			return (T) getHibernateTemplate().get(entityClass, id);
		} catch (RuntimeException re) {
			log.error("findById failed", re);
			throw re;
		}
	}
	
	/**
	 * 根據entityClass,propertyName,value來尋找全部的POJO實體物件
	 * 通常用於尋找單一外鍵
  	 * find查詢有你自己定義hql語句和查詢條件，如果數據庫中數據字段為null，查詢後會報錯。 
	 * @param entityClass 	POJO實體物件的class
	 * @param propertyName 	POJO實體物件的某一個屬性名稱
	 * @param value			要尋找的屬性值
	 * @return
	 */
	public List<T> findByHQLProperty(Class<T> entityClass, String propertyName,
			Object value) {
		return this.findByHQLProperty(entityClass, propertyName, value, null);
	}
	
	/**
	 * 根據entityClass,propertyName,value來尋找全部的POJO實體物件,並排序
	 * @param entityClass 	POJO實體物件的class
	 * @param propertyName 	POJO實體物件的某一個屬性名稱
	 * @param value			要尋找的屬性值
	 * @param hqlSort 		排序的hql,例如:"oid asc"
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<T> findByHQLProperty(Class<T> entityClass, String propertyName,
			Object value, String hqlSort) {
		try {
			StringBuilder hql = new StringBuilder("from "+ entityClass.getSimpleName() + " where " + propertyName+ "= ? ");
			if (StringUtils.isNotBlank(hqlSort)) {
				hql.append(" order by " + hqlSort);
			}
			return find(hql.toString(), value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	/**
	 * 根據entityClass來尋找全部的POJO實體物件
	 * findByExample查詢的where條件會自動加上數據庫中，所有不能為null的字段。
	 * 如果數據庫中數據字段為null，查詢的時候不會報錯，但是查詢不出數據，因為這種查詢的條件是數據庫中不能為null的所有字段。
	 * @param entityClass
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<T> findByExample(T entityClass) {
		try {
			return getHibernateTemplate().findByExample(entityClass);
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	/* HQL */
	/* 第1組-抓資料,以下method到最後都是呼叫createHQLQuery */
	@SuppressWarnings("rawtypes")
	public List createHQLQuery1_1(String hql) {
		return this.createHQLQuery(0, 0, hql, null);
	}
	@SuppressWarnings("rawtypes")
	public List createHQLQuery1_2(String hql, Object paramsValue) {
		return this.createHQLQuery(0, 0, hql, paramsValue);
	}
	@SuppressWarnings("rawtypes")
	public List createHQLQuery1_3(String hql, Object[] paramsValue) {
		return this.createHQLQuery(0, 0, hql, paramsValue);
	}
	@SuppressWarnings("rawtypes")
	public List createHQLQuery1_2_2(String hql, Map<String, Object> paramsValue) {
		return this.createHQLQuery(0, 0, hql, paramsValue);
	}
	@SuppressWarnings("rawtypes")
	public List createHQLQuery1_2_1(String hql, List<Object> paramsValue) {
		return this.createHQLQuery(0, 0, hql, paramsValue);
	}
	
	/* 第2組-抓資料,並指定起始值和抓的數量,以下method到最後都是呼叫createHQLQuery */
	@SuppressWarnings("rawtypes")
	public List createHQLQuery2_1(int index, int pageSize, String hql) {
		return this.createHQLQuery(index, pageSize, hql, null);
	}
	@SuppressWarnings("rawtypes")
	public List createHQLQuery2_2(int index, int pageSize, String hql,Object paramsValue) {
		return this.createHQLQuery(index, pageSize, hql, paramsValue);
	}
	@SuppressWarnings("rawtypes")
	public List createHQLQuery2_3(int index, int pageSize, String hql,Object[] paramsValue) {
		return this.createHQLQuery(index, pageSize, hql, paramsValue);
	}
	@SuppressWarnings("rawtypes")
	public List createHQLQuery2_2_2(int index, int pageSize, String hql,Map<String, Object> paramsValue) {
		return this.createHQLQuery(index, pageSize, hql, paramsValue);
	}
	@SuppressWarnings("rawtypes")
	public List createHQLQuery2_2_1(int index, int pageSize, String hql,List<Object> paramsValue) {
		return this.createHQLQuery(index, pageSize, hql, paramsValue);
	}
	
	/**
	 * 抓資料 index和pageSize都要大於0才會去做特定範圍的抓取,如果是要抓全部資料,而不是用於分頁,可以直接傳入0
	 * paramsValue,			如果沒有查詢參數,可以直接傳入null
	 * @param index 		設定第幾筆開始抓資料
	 * @param pageSize 		設定一次要抓幾筆資料
	 * @param hql 			hql語法
	 * @param paramsValue 	查詢參數
	 * @return 				回傳結果集為List,裡面元素是該Entity
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private List createHQLQuery(final int index, final int pageSize,final String hql, final Object paramsValue) {
		return (List) this.getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(Session session) {
						Query query = session.createQuery(hql);
						BaseUtil.println(hql);
						if (index > 0 && pageSize > 0) {
							query.setFirstResult((index - 1) * pageSize);
							query.setMaxResults(pageSize);
						}
						if (paramsValue != null) {
							processParamsValue(paramsValue, query);
						}
						return query.list();
					}
				});
	}

	/* 第3組-抓資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createHQLQueryCount */
	public Long createHQLQueryCount3_1(String hql) {
		return this.createHQLQueryCount(hql, null);
	}
	public Long createHQLQueryCount3_2(String hql, Object paramsValue) {
		return this.createHQLQueryCount(hql, paramsValue);
	}
	public Long createHQLQueryCount3_3(String hql, Object[] paramsValue) {
		return this.createHQLQueryCount(hql, paramsValue);
	}
	public Long createHQLQueryCount3_2_2(String hql,Map<String, Object> paramsValue) {
		return this.createHQLQueryCount(hql, paramsValue);
	}
	public Long createHQLQueryCount3_2_1(String hql, List<Object> paramsValue) {
		return this.createHQLQueryCount(hql, paramsValue);
	}
	
	/**
	 * 抓資料筆數
	 * @param hql           hql語法
	 * @param paramsValue	查詢參數
	 * @return 				回傳結果集的筆數
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Long createHQLQueryCount(final String hql, final Object paramsValue) {
		return (Long) this.getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(Session session) {
						String hqlCount="select count(*) "+ hql;
						Query query = session.createQuery(hqlCount);
						BaseUtil.println("hqlCount>>"+hqlCount);
						if (paramsValue != null) {
							processParamsValue(paramsValue, query);
						}
						return query.uniqueResult();
					}
				});
	}
	
	/* 第4組-抓資料和資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createHQLQueryPage */
	public QueryResultBean createHQLQueryPage4_1(int index, int pageSize,boolean isCount, String hql) throws Exception {
		return this.createHQLQueryPage(index, pageSize, isCount, hql, null);
	}
	public QueryResultBean createHQLQueryPage4_2(int index, int pageSize,boolean isCount, String hql, Object paramsValue) throws Exception {
		return this.createHQLQueryPage(index, pageSize, isCount, hql, paramsValue);
	}
	public QueryResultBean createHQLQueryPage4_2_1(int index, int pageSize,boolean isCount, String hql, List<Object> paramsValue)throws Exception {
		return this.createHQLQueryPage(index, pageSize, isCount, hql, paramsValue);
	}
	public QueryResultBean createHQLQueryPage4_2_2(int index, int pageSize,boolean isCount, String hql, Map<String, Object> paramsValue)throws Exception {
		return this.createHQLQueryPage(index, pageSize, isCount, hql, paramsValue);
	}
	public QueryResultBean createHQLQueryPage4_3(int index, int pageSize,boolean isCount, String hql, Object[] paramsValue) throws Exception {
		return this.createHQLQueryPage(index, pageSize, isCount, hql, paramsValue);
	}
	
	/**
	 * 抓資料和抓資料筆數,並封裝成QueryResultBean,用於前端的分頁元件
	 * @param index			設定第幾筆開始抓資料
	 * @param pageSize		設定一次要抓幾筆資料
	 * @param isCount		是否要執行"抓資料筆數"的語法
	 * @param hql			hql語法
	 * @param paramsValue	查詢參數
	 * @return
	 * @throws Exception
	 */
	private QueryResultBean createHQLQueryPage(final int index,
			final int pageSize, final boolean isCount, final String hql,
			final Object paramsValue) throws Exception {
		if (index <= 0) {
			throw new Exception("index不能小於等於0");
		}
		if (pageSize <= 0) {
			throw new Exception("pageSize不能小於等於0");
		}
		if (StringUtils.isBlank(hql)) {
			throw new Exception("hql要有值");
		}
		QueryResultBean result = new QueryResultBean();
		result.setResult(this.createHQLQuery(index, pageSize, hql, paramsValue));
		if (isCount) {
			result.setCount(this.createHQLQueryCount(hql, paramsValue));
		}
		return result;
	}
	
	/* 第5組-執行基本操作的HQL語法,以下method到最後都是呼叫createHQLExecuteUpdate */
	public Integer createHQLExecuteUpdate5_1(String hql) {
		return this.createHQLExecuteUpdate(hql, null);
	}
	public Integer createHQLExecuteUpdate5_2(String hql, Object paramsValue) {
		return this.createHQLExecuteUpdate(hql, paramsValue);
	}
	public Integer createHQLExecuteUpdate5_3(String hql, Object[] paramsValue) {
		return this.createHQLExecuteUpdate(hql, paramsValue);
	}
	public Integer createHQLExecuteUpdate5_2_2(String hql,Map<String, Object> paramsValue) {
		return this.createHQLExecuteUpdate(hql, paramsValue);
	}
	public Integer createHQLExecuteUpdate5_2_1(String hql,List<Object> paramsValue) {
		return this.createHQLExecuteUpdate(hql, paramsValue);
	}
	
	/**
	 * 執行基本操作的語法
	 * @param hql			hql語法
	 * @param paramsValue	查詢參數
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Integer createHQLExecuteUpdate(final String hql,final Object paramsValue) {
		return (Integer) this.getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(Session session) {
						Query query = session.createQuery(hql);
						BaseUtil.println(hql);
						if (paramsValue != null) {
							processParamsValue(paramsValue, query);
						}
						return query.executeUpdate();
					}
				});
	}

	/* SQL */
	/* 第1組-抓Map資料,以下method到最後都是呼叫createSQLQueryMap */
	@SuppressWarnings("rawtypes")
	public List createSQLQueryMap1_1(String sql) {
		return this.createSQLQueryMap(0, 0, sql, null);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryMap1_2(String sql, Object paramsValue) {
		return this.createSQLQueryMap(0, 0, sql, paramsValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryMap1_3(String sql, Object[] paramsValue) {
		return this.createSQLQueryMap(0, 0, sql, paramsValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryMap1_2_2(String sql, Map<String, Object> paramsValue) {
		return this.createSQLQueryMap(0, 0, sql, paramsValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryMap1_2_1(String sql, List<Object> paramsValue) {
		return this.createSQLQueryMap(0, 0, sql, paramsValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryMap1_3_1(Map map) {
		return this.createSQLQueryMap1_3((String) map.get("sql"),(Object[]) map.get("params"));
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryMap1_3_2(Map map, String sqlKey, String paramsKey) {
		return this.createSQLQueryMap1_3((String) map.get(sqlKey),(Object[]) map.get(paramsKey));
	}
	/* 第2組-抓Map資料,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryMap */
	@SuppressWarnings("rawtypes")
	public List createSQLQueryMap2_1(int index, int pageSize, String sql) {
		return this.createSQLQueryMap(index, pageSize, sql, null);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryMap2_2(int index, int pageSize, String sql,Object paramsValue) {
		return this.createSQLQueryMap(index, pageSize, sql, paramsValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryMap2_2_1(int index, int pageSize, String sql,List<Object> paramsValue) {
		return this.createSQLQueryMap(index, pageSize, sql, paramsValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryMap2_2_2(int index, int pageSize, String sql,Map<String, Object> paramsValue) {
		return this.createSQLQueryMap(index, pageSize, sql, paramsValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryMap2_3(int index, int pageSize, String sql,Object[] paramsValue) {
		return this.createSQLQueryMap(index, pageSize, sql, paramsValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryMap2_3_1(int index, int pageSize, Map map) {
		return this.createSQLQueryMap2_3(index, pageSize, (String) map.get("sql"),	(Object[]) map.get("params"));
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryMap2_3_2(int index, int pageSize, Map map,String sqlKey, String paramsKey) {
		return this.createSQLQueryMap2_3(index, pageSize,(String) map.get(sqlKey), (Object[]) map.get(paramsKey));
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryMap2_4(String sql) {
		return this.createSQLQueryMap(-1, -1,sql, null);
	}
	
	/**
	 * 抓資料 index和pageSize都要大於0才會去做特定範圍的抓取,如果是要抓全部資料,而不是用於分頁,可以直接傳入0
	 * @param index			設定第幾筆開始抓資料
	 * @param pageSize		設定一次要抓幾筆資料
	 * @param sql			sql語法
	 * @param paramsValue	查詢參數,如果沒有查詢參數,可以直接傳入null
	 * @return 				回傳結果集為List裡面元素是Map,key是table的欄位名稱
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private List createSQLQueryMap(final int index, final int pageSize,final String sql, final Object paramsValue) {
		return (List) this.getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(Session session) {
						SQLQuery query = session.createSQLQuery(sql);
						BaseUtil.println(sql);
						if (index > 0 && pageSize > 0) {
							query.setFirstResult((index - 1) * pageSize);
							query.setMaxResults(pageSize);
						}
						if (paramsValue != null) {
							processParamsValue(paramsValue, query);
						}
						return query.setResultTransformer(
								Criteria.ALIAS_TO_ENTITY_MAP).list();
					}
				});
	}
	
	/* 第1組-抓Entity資料,以下method到最後都是呼叫createSQLQueryEntity */
	@SuppressWarnings("rawtypes")
	public List createSQLQueryEntity1_1(String sql,Class entityClass) {
		return this.createSQLQueryEntity(0, 0, sql, null,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryEntity1_2(String sql, Object paramsValue,Class entityClass) {
		return this.createSQLQueryEntity(0, 0, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryEntity1_2_1(String sql, List<Object> paramsValue,Class entityClass) {
		return this.createSQLQueryEntity(0, 0, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryEntity1_2_2(String sql, Map<String, Object> paramsValue,Class entityClass) {
		return this.createSQLQueryEntity(0, 0, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryEntity1_3(String sql, Object[] paramsValue,Class entityClass) {
		return this.createSQLQueryEntity(0, 0, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryEntity1_3_1(Map map,Class entityClass) {
		return this.createSQLQueryEntity1_3((String) map.get("sql"),(Object[]) map.get("params"),entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryEntity1_3_2(Map map, String sqlKey, String paramsKey,Class entityClass) {
		return this.createSQLQueryEntity1_3((String) map.get(sqlKey),(Object[]) map.get(paramsKey),entityClass);
	}
	
	/* 第2組-抓Entity資料,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryEntity */
	@SuppressWarnings("rawtypes")
	public List createSQLQueryEntity2_1(int index, int pageSize, String sql,Class entityClass) {
		return this.createSQLQueryEntity(index, pageSize, sql, null,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryEntity2_2(int index, int pageSize, String sql,Object paramsValue,Class entityClass) {
		return this.createSQLQueryEntity(index, pageSize, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryEntity2_2_1(int index, int pageSize, String sql,List<Object> paramsValue,Class entityClass) {
		return this.createSQLQueryEntity(index, pageSize, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryEntity2_2_2(int index, int pageSize, String sql,Map<String, Object> paramsValue,Class entityClass) {
		return this.createSQLQueryEntity(index, pageSize, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryEntity2_3(int index, int pageSize, String sql,Object[] paramsValue,Class entityClass) {
		return this.createSQLQueryEntity(index, pageSize, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryEntity2_3_1(int index, int pageSize, Map map,Class entityClass) {
		return this.createSQLQueryEntity2_3(index, pageSize, (String) map.get("sql"),	(Object[]) map.get("params"),entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryEntity2_3_2(int index, int pageSize, Map map,String sqlKey, String paramsKey,Class entityClass) {
		return this.createSQLQueryEntity2_3(index, pageSize,(String) map.get(sqlKey), (Object[]) map.get(paramsKey),entityClass);
	}
	
	/**
	 * 抓資料 index和pageSize都要大於0才會去做特定範圍的抓取,如果是要抓全部資料,而不是用於分頁,可以直接傳入0
	 * @param index			設定第幾筆開始抓資料
	 * @param pageSize		設定一次要抓幾筆資料
	 * @param sql			sql語法
	 * @param paramsValue	查詢參數,如果沒有查詢參數,可以直接傳入null
	 * @param entityClass	POJO實體物件的class
	 * @return 				回傳結果集是List裡面元素是該entityClass
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private List createSQLQueryEntity(final int index, final int pageSize,final String sql, final Object paramsValue,final Class entityClass) {
		return (List) this.getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(Session session) {
						SQLQuery query = session.createSQLQuery(sql);
						BaseUtil.println(sql);
						query.addEntity(entityClass);
						if (index > 0 && pageSize > 0) {
							query.setFirstResult((index - 1) * pageSize);
							query.setMaxResults(pageSize);
						}
						if (paramsValue != null) {
							processParamsValue(paramsValue, query);
						}
						return query.list();
					}
				});
	}
	
	/* 第2組-抓NoManagerEntity資料,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryNoManagerEntity */
	@SuppressWarnings("rawtypes")
	public List createSQLQueryNoManagerEntity2_0(String sql,Class entityClass) {
		return this.createSQLQueryNoManagerEntity(0, 0, sql, null,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryNoManagerEntity2_1(int index, int pageSize, String sql,Class entityClass) {
		return this.createSQLQueryNoManagerEntity(index, pageSize, sql, null,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryNoManagerEntity2_2(int index, int pageSize, String sql,Object paramsValue,Class entityClass) {
		return this.createSQLQueryNoManagerEntity(index, pageSize, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryNoManagerEntity2_2_1(int index, int pageSize, String sql,List<Object> paramsValue,Class entityClass) {
		return this.createSQLQueryNoManagerEntity(index, pageSize, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryNoManagerEntity2_2_2(int index, int pageSize, String sql,Map<String, Object> paramsValue,Class entityClass) {
		return this.createSQLQueryNoManagerEntity(index, pageSize, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryNoManagerEntity2_3(int index, int pageSize, String sql,Object[] paramsValue,Class entityClass) {
		return this.createSQLQueryNoManagerEntity(index, pageSize, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryNoManagerEntity2_3_1(int index, int pageSize, Map map,Class entityClass) {
		return this.createSQLQueryNoManagerEntity2_3(index, pageSize, (String) map.get("sql"),	(Object[]) map.get("params"),entityClass);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryNoManagerEntity2_3_2(int index, int pageSize, Map map,String sqlKey, String paramsKey,Class entityClass) {
		return this.createSQLQueryNoManagerEntity2_3(index, pageSize,(String) map.get(sqlKey), (Object[]) map.get(paramsKey),entityClass);
	}
	
	/**
	 * 抓資料 index和pageSize都要大於0才會去做特定範圍的抓取,如果是要抓全部資料,而不是用於分頁,可以直接傳入0
	 * @param index			設定第幾筆開始抓資料
	 * @param pageSize		設定一次要抓幾筆資料
	 * @param sql			sql語法
	 * @param paramsValue	查詢參數,如果沒有查詢參數,可以直接傳入null
	 * @param entityClass	POJO實體物件的class
	 * @return 				回傳結果集是List裡面元素是該entityClass
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private List createSQLQueryNoManagerEntity(final int index, final int pageSize,final String sql, final Object paramsValue,final Class entityClass) {
		return (List) this.getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(Session session) {
						SQLQuery query = session.createSQLQuery(sql);
						BaseUtil.println(sql);
						if (index > 0 && pageSize > 0) {
							query.setFirstResult((index - 1) * pageSize);
							query.setMaxResults(pageSize);
						}
						if (paramsValue != null) {
							processParamsValue(paramsValue, query);
						}
						// 返回非受管實體（Returning non-managed entities）
						query.setResultTransformer(Transformers.aliasToBean(entityClass));
						return query.list();
					}
				});
	}
	
	/* 第1組-抓Scalar資料,以下method到最後都是呼叫createSQLQueryScalar */
	@SuppressWarnings("rawtypes")
	public List createSQLQueryScalar1_1(String sql,Object scalarValue) {
		return this.createSQLQueryScalar(0, 0, sql, null,scalarValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryScalar1_2(String sql, Object paramsValue,Object scalarValue) {
		return this.createSQLQueryScalar(0, 0, sql, paramsValue,scalarValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryScalar1_2_1(String sql, List<Object> paramsValue,Object scalarValue) {
		return this.createSQLQueryScalar(0, 0, sql, paramsValue,scalarValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryScalar1_2_2(String sql, Map<String, Object> paramsValue,Object scalarValue) {
		return this.createSQLQueryScalar(0, 0, sql, paramsValue,scalarValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryScalar1_3(String sql, Object[] paramsValue,Object scalarValue) {
		return this.createSQLQueryScalar(0, 0, sql, paramsValue,scalarValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryScalar1_3_1(Map map,Object scalarValue) {
		return this.createSQLQueryScalar1_3((String) map.get("sql"),(Object[]) map.get("params"),scalarValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryScalar1_3_2(Map map, String sqlKey, String paramsKey,Object scalarValue) {
		return this.createSQLQueryScalar1_3((String) map.get(sqlKey),(Object[]) map.get(paramsKey),scalarValue);
	}
	
	/* 第2組-抓Scalar資料,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryScalar */
	@SuppressWarnings("rawtypes")
	public List createSQLQueryScalar2_1(int index, int pageSize, String sql,Object scalarValue) {
		return this.createSQLQueryScalar(index, pageSize, sql, null,scalarValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryScalar2_2(int index, int pageSize, String sql,Object paramsValue,Object scalarValue) {
		return this.createSQLQueryScalar(index, pageSize, sql, paramsValue,scalarValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryScalar2_3(int index, int pageSize, String sql,Object[] paramsValue,Object scalarValue) {
		return this.createSQLQueryScalar(index, pageSize, sql, paramsValue,scalarValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryScalar2_2_2(int index, int pageSize, String sql,Map<String, Object> paramsValue,Object scalarValue) {
		return this.createSQLQueryScalar(index, pageSize, sql, paramsValue,scalarValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryScalar2_2_1(int index, int pageSize, String sql,List<Object> paramsValue,Object scalarValue) {
		return this.createSQLQueryScalar(index, pageSize, sql, paramsValue,scalarValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryScalar2_3_1(int index, int pageSize, Map map,Object scalarValue) {
		return this.createSQLQueryScalar2_3(index, pageSize, (String) map.get("sql"),	(Object[]) map.get("params"),scalarValue);
	}
	@SuppressWarnings("rawtypes")
	public List createSQLQueryScalar2_3_2(int index, int pageSize, Map map,String sqlKey, String paramsKey,Object scalarValue) {
		return this.createSQLQueryScalar2_3(index, pageSize,(String) map.get(sqlKey), (Object[]) map.get(paramsKey),scalarValue);
	}
	
	/**
     * 抓資料 index和pageSize都要大於0才會去做特定範圍的抓取,如果是要抓全部資料,而不是用於分頁,可以直接傳入0
	 * @param index			設定第幾筆開始抓資料
	 * @param pageSize		設定一次要抓幾筆資料
	 * @param sql			sql語法
	 * @param paramsValue	查詢參數,如果沒有查詢參數,可以直接傳入null
	 * @param scalarValue	純量值
	 * @return 				回傳結果集是List裡面元素是Map,key是scalarValue
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private List createSQLQueryScalar(final int index, final int pageSize,final String sql, final Object paramsValue,final Object scalarValue) {
		return (List) this.getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(Session session) {
						SQLQuery query = session.createSQLQuery(sql);
						BaseUtil.println(sql);
						if (index > 0 && pageSize > 0) {
							query.setFirstResult((index - 1) * pageSize);
							query.setMaxResults(pageSize);
						}
						if (paramsValue != null) {
							processParamsValue(paramsValue, query);
						}
						if (scalarValue != null) {
							processScalar(scalarValue, query);	
						}
						return query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).list();
					}
				});
	}
	
	/* 第3組-抓資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryCount */
	public Long createSQLQueryCount3_1(String sql) {
		return this.createSQLQueryCount(sql, null);
	}
	public Long createSQLQueryCount3_2(String sql, Object paramsValue) {
		return this.createSQLQueryCount(sql, paramsValue);
	}
	public Long createSQLQueryCount3_3(String sql, Object[] paramsValue) {
		return this.createSQLQueryCount(sql, paramsValue);
	}
	public Long createSQLQueryCount3_2_2(String sql,Map<String, Object> paramsValue) {
		return this.createSQLQueryCount(sql, paramsValue);
	}
	public Long createSQLQueryCount3_2_1(String sql, List<Object> paramsValue) {
		return this.createSQLQueryCount(sql, paramsValue);
	}
	@SuppressWarnings("rawtypes")
	public Long createSQLQueryCount3_3_1(Map map) {
		return this.createSQLQueryCount3_3((String) map.get("sql"),(Object[]) map.get("params"));
	}
	@SuppressWarnings("rawtypes")
	public Long createSQLQueryCount3_3_2(Map map, String sqlKey,String paramsKey) {
		return this.createSQLQueryCount3_3((String) map.get(sqlKey),(Object[]) map.get(paramsKey));
	}
	
	/**
	 * 抓資料筆數
	 * @param sql			sql語法
	 * @param paramsValue	查詢參數
	 * @return 				回傳結果集的筆數
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Long createSQLQueryCount(final String sql, final Object paramsValue) {
		return (Long) this.getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(Session session) {
						String sqlCount="select count(0) from("+ sql +"\n)";
						Query query = session.createSQLQuery(sqlCount);
						BaseUtil.println("sqlCount>>"+sqlCount);
						if (paramsValue != null) {
							processParamsValue(paramsValue, query);
						}
						return ((BigDecimal) query.uniqueResult()).longValue();
					}
				});
	}

	/* 第4組-抓Map資料和資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryPageMap */
	public QueryResultBean createSQLQueryPageMap4_1(int index, int pageSize,boolean isCount, String sql) throws Exception {
		return this.createSQLQueryPageMap(index, pageSize, isCount, sql, null);
	}
	public QueryResultBean createSQLQueryPageMap4_2(int index, int pageSize,boolean isCount, String sql, Object paramsValue) throws Exception {
		return this.createSQLQueryPageMap(index, pageSize, isCount, sql, paramsValue);
	}
	public QueryResultBean createSQLQueryPageMap4_2_1(int index, int pageSize,boolean isCount, String sql, List<Object> paramsValue)throws Exception {
		return this.createSQLQueryPageMap(index, pageSize, isCount, sql, paramsValue);
	}
	public QueryResultBean createSQLQueryPageMap4_2_2(int index, int pageSize,boolean isCount, String sql, Map<String, Object> paramsValue)throws Exception {
		return this.createSQLQueryPageMap(index, pageSize, isCount, sql, paramsValue);
	}
	public QueryResultBean createSQLQueryPageMap4_3(int index, int pageSize,boolean isCount, String sql, Object[] paramsValue) throws Exception {
		return this.createSQLQueryPageMap(index, pageSize, isCount, sql, paramsValue);
	}
	@SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageMap4_3_1(int index, int pageSize,boolean isCount, Map map) throws Exception {
		return this.createSQLQueryPageMap4_3(index, pageSize, isCount,(String) map.get("sql"), (Object[]) map.get("params"));
	}
	@SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageMap4_3_2(int index, int pageSize,boolean isCount, Map map, String sqlKey, String paramsKey)throws Exception {
		return this.createSQLQueryPageMap4_3(index, pageSize, isCount,(String) map.get(sqlKey), (Object[]) map.get(paramsKey));
	}

	/**
	 * 抓資料和抓資料筆數,並封裝成QueryResultBean,用於前端的分頁元件
	 * @param index			設定第幾筆開始抓資料
	 * @param pageSize		設定一次要抓幾筆資料
	 * @param isCount		是否要執行"抓資料筆數"的語法
	 * @param sql			sql語法
	 * @param paramsValue	查詢參數
	 * @return
	 * @throws Exception
	 */
	private QueryResultBean createSQLQueryPageMap(final int index,
			final int pageSize, final boolean isCount, final String sql,
			final Object paramsValue) throws Exception {
		if (index <= 0) {
			throw new Exception("index不能小於等於0");
		}
		if (pageSize <= 0) {
			throw new Exception("pageSize不能小於等於0");
		}
		if (StringUtils.isBlank(sql)) {
			throw new Exception("sql要有值");
		}
		QueryResultBean result = new QueryResultBean();
		result.setResult(this.createSQLQueryMap(index, pageSize, sql, paramsValue));
		if (isCount) {
			result.setCount(this.createSQLQueryCount(sql, paramsValue));
		}
		return result;
	}
	
	/* 第4組-抓Entity資料和資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryPageEntity */
	@SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageEntity4_1(int index, int pageSize,boolean isCount, String sql,Class entityClass) throws Exception {
		return this.createSQLQueryPageEntity(index, pageSize, isCount, sql, null,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageEntity4_2(int index, int pageSize,boolean isCount, String sql, Object paramsValue,Class entityClass) throws Exception {
		return this.createSQLQueryPageEntity(index, pageSize, isCount, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageEntity4_2_1(int index, int pageSize,boolean isCount, String sql, List<Object> paramsValue,Class entityClass)throws Exception {
		return this.createSQLQueryPageEntity(index, pageSize, isCount, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageEntity4_2_2(int index, int pageSize,boolean isCount, String sql, Map<String, Object> paramsValue,Class entityClass)throws Exception {
		return this.createSQLQueryPageEntity(index, pageSize, isCount, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageEntity4_3(int index, int pageSize,boolean isCount, String sql, Object[] paramsValue,Class entityClass) throws Exception {
		return this.createSQLQueryPageEntity(index, pageSize, isCount, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageEntity4_3_1(int index, int pageSize,boolean isCount, Map map,Class entityClass) throws Exception {
		return this.createSQLQueryPageEntity4_3(index, pageSize, isCount,(String) map.get("sql"), (Object[]) map.get("params"),entityClass);
	}
	@SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageEntity4_3_2(int index, int pageSize,boolean isCount, Map map, String sqlKey, String paramsKey,Class entityClass)throws Exception {
		return this.createSQLQueryPageEntity4_3(index, pageSize, isCount,(String) map.get(sqlKey), (Object[]) map.get(paramsKey),entityClass);
	}
	/**
	 * 抓資料和抓資料筆數,並封裝成QueryResultBean,用於前端的分頁元件
	 * @param index			設定第幾筆開始抓資料
	 * @param pageSize		設定一次要抓幾筆資料
	 * @param isCount		是否要執行"抓資料筆數"的語法
	 * @param sql			sql語法
	 * @param paramsValue	查詢參數
	 * @param entityClass	POJO實體物件的class
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	private QueryResultBean createSQLQueryPageEntity(final int index,
			final int pageSize, final boolean isCount, final String sql,
			final Object paramsValue,final Class entityClass) throws Exception {
		if (index <= 0) {
			throw new Exception("index不能小於等於0");
		}
		if (pageSize <= 0) {
			throw new Exception("pageSize不能小於等於0");
		}
		if (StringUtils.isBlank(sql)) {
			throw new Exception("sql要有值");
		}
		QueryResultBean result = new QueryResultBean();
		result.setResult(this.createSQLQueryEntity(index, pageSize, sql, paramsValue,entityClass));
		if (isCount) {
			result.setCount(this.createSQLQueryCount(sql, paramsValue));
		}
		return result;
	}
	
	/* 第4組-抓Scalar資料和資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryPageScalar */
	public QueryResultBean createSQLQueryPageScalar4_1(int index, int pageSize,boolean isCount, String sql,Object scalarValue) throws Exception {
		return this.createSQLQueryPageScalar(index, pageSize, isCount, sql, null,scalarValue);
	}
	public QueryResultBean createSQLQueryPageScalar4_2(int index, int pageSize,boolean isCount, String sql, Object paramsValue,Object scalarValue) throws Exception {
		return this.createSQLQueryPageScalar(index, pageSize, isCount, sql, paramsValue,scalarValue);
	}
	public QueryResultBean createSQLQueryPageScalar4_2_1(int index, int pageSize,boolean isCount, String sql, List<Object> paramsValue,Object scalarValue)throws Exception {
		return this.createSQLQueryPageScalar(index, pageSize, isCount, sql, paramsValue,scalarValue);
	}
	public QueryResultBean createSQLQueryPageScalar4_2_2(int index, int pageSize,boolean isCount, String sql, Map<String, Object> paramsValue,Object scalarValue)throws Exception {
		return this.createSQLQueryPageScalar(index, pageSize, isCount, sql, paramsValue,scalarValue);
	}
	public QueryResultBean createSQLQueryPageScalar4_3(int index, int pageSize,boolean isCount, String sql, Object[] paramsValue,Object scalarValue) throws Exception {
		return this.createSQLQueryPageScalar(index, pageSize, isCount, sql, paramsValue,scalarValue);
	}
	@SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageScalar4_3_1(int index, int pageSize,boolean isCount, Map map,Object scalarValue) throws Exception {
		return this.createSQLQueryPageScalar4_3(index, pageSize, isCount,(String) map.get("sql"), (Object[]) map.get("params"),scalarValue);
	}
	@SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageScalar4_3_2(int index, int pageSize,boolean isCount, Map map, String sqlKey, String paramsKey,Object scalarValue)throws Exception {
		return this.createSQLQueryPageScalar4_3(index, pageSize, isCount,(String) map.get(sqlKey), (Object[]) map.get(paramsKey),scalarValue);
	}	
	/**
	 * 抓資料和抓資料筆數,並封裝成QueryResultBean,用於前端的分頁元件
	 * @param index			設定第幾筆開始抓資料
	 * @param pageSize		設定一次要抓幾筆資料
	 * @param isCount		是否要執行"抓資料筆數"的語法
	 * @param sql			sql語法
	 * @param paramsValue	查詢參數
	 * @param scalarValue	純量值
	 * @return
	 * @throws Exception
	 */
	private QueryResultBean createSQLQueryPageScalar(final int index,
			final int pageSize, final boolean isCount, final String sql,
			final Object paramsValue,final Object scalarValue) throws Exception {
		if (index <= 0) {
			throw new Exception("index不能小於等於0");
		}
		if (pageSize <= 0) {
			throw new Exception("pageSize不能小於等於0");
		}
		if (StringUtils.isBlank(sql)) {
			throw new Exception("sql要有值");
		}
		QueryResultBean result = new QueryResultBean();
		result.setResult(this.createSQLQueryScalar(index, pageSize, sql, paramsValue,scalarValue));
		if (isCount) {
			result.setCount(this.createSQLQueryCount(sql, paramsValue));
		}
		return result;
	}
	
	/* 第4組-抓NoManagerEntity資料和資料筆數,並指定起始值和抓的數量,以下method到最後都是呼叫createSQLQueryPageNoManagerEntity */
	@SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageNoManagerEntity4_1(int index, int pageSize,boolean isCount, String sql,Class entityClass) throws Exception {
		return this.createSQLQueryPageNoManagerEntity(index, pageSize, isCount, sql, null,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageNoManagerEntity4_2(int index, int pageSize,boolean isCount, String sql, Object paramsValue,Class entityClass) throws Exception {
		return this.createSQLQueryPageNoManagerEntity(index, pageSize, isCount, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageNoManagerEntity4_2_1(int index, int pageSize,boolean isCount, String sql, List<Object> paramsValue,Class entityClass)throws Exception {
		return this.createSQLQueryPageNoManagerEntity(index, pageSize, isCount, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageNoManagerEntity4_2_2(int index, int pageSize,boolean isCount, String sql, Map<String, Object> paramsValue,Class entityClass)throws Exception {
		return this.createSQLQueryPageNoManagerEntity(index, pageSize, isCount, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageNoManagerEntity4_3(int index, int pageSize,boolean isCount, String sql, Object[] paramsValue,Class entityClass) throws Exception {
		return this.createSQLQueryPageNoManagerEntity(index, pageSize, isCount, sql, paramsValue,entityClass);
	}
	@SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageNoManagerEntity4_3_1(int index, int pageSize,boolean isCount, Map map,Class entityClass) throws Exception {
		return this.createSQLQueryPageNoManagerEntity4_3(index, pageSize, isCount,(String) map.get("sql"), (Object[]) map.get("params"),entityClass);
	}
	@SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageNoManagerEntity4_3_2(int index, int pageSize,boolean isCount, Map map, String sqlKey, String paramsKey,Class entityClass)throws Exception {
		return this.createSQLQueryPageNoManagerEntity4_3(index, pageSize, isCount,(String) map.get(sqlKey), (Object[]) map.get(paramsKey),entityClass);
	}
	/**
	 * 抓資料和抓資料筆數,並封裝成QueryResultBean,用於前端的分頁元件
	 * @param index			設定第幾筆開始抓資料
	 * @param pageSize		設定一次要抓幾筆資料
	 * @param isCount		是否要執行"抓資料筆數"的語法
	 * @param sql			sql語法
	 * @param paramsValue	查詢參數
	 * @param entityClass	POJO實體物件的class
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	private QueryResultBean createSQLQueryPageNoManagerEntity(final int index,
			final int pageSize, final boolean isCount, final String sql,
			final Object paramsValue,final Class entityClass) throws Exception {
		if (index <= 0) {
			throw new Exception("index不能小於等於0");
		}
		if (pageSize <= 0) {
			throw new Exception("pageSize不能小於等於0");
		}
		if (StringUtils.isBlank(sql)) {
			throw new Exception("sql要有值");
		}
		QueryResultBean result = new QueryResultBean();
		result.setResult(this.createSQLQueryNoManagerEntity(index, pageSize, sql, paramsValue,entityClass));
		if (isCount) {
			result.setCount(this.createSQLQueryCount(sql, paramsValue));
		}
		return result;
	}
	
	/* 第5組-執行基本操作的SQL語法,以下method到最後都是呼叫createSQLExecuteUpdate */
	public Integer createSQLExecuteUpdate5_1(String sql) {
		return this.createSQLExecuteUpdate(sql, null);
	}
	public Integer createSQLExecuteUpdate5_2(String sql, Object paramsValue) {
		return this.createHQLExecuteUpdate(sql, paramsValue);
	}
	public Integer createSQLExecuteUpdate5_3(String sql, Object[] paramsValue) {
		return this.createSQLExecuteUpdate(sql, paramsValue);
	}
	public Integer createSQLExecuteUpdate5_2_2(String sql,Map<String, Object> paramsValue) {
		return this.createSQLExecuteUpdate(sql, paramsValue);
	}
	public Integer createSQLExecuteUpdate5_2_1(String sql,List<Object> paramsValue) {
		return this.createSQLExecuteUpdate(sql, paramsValue);
	}
	/**
	 * 執行基本操作的語法
	 * @param sql			sql語法
	 * @param paramsValue	查詢參數
	 * @return
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Integer createSQLExecuteUpdate(final String sql,
			final Object paramsValue) {
		return (Integer) this.getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(Session session) {
						Query query = session.createSQLQuery(sql);
						BaseUtil.println(sql);
						if (paramsValue != null) {
							processParamsValue(paramsValue, query);
						}
						return query.executeUpdate();
					}
				});
	}

	/**
	 * 處理Object查詢參數值
	 * @param paramsValue
	 * @param query
	 */
	private void processParamsValue(Object paramsValue, Query query) {
			if (paramsValue instanceof Object[]) {
				Object[] objArray = (Object[]) paramsValue;
				for (int i = 0; i < objArray.length; i++) {
					query.setParameter(i, objArray[i]);
				}
			} else if (paramsValue instanceof Map) {
				// 通常用於,參數名稱綁定：定義查詢參數要用":"開頭
				// Map裡面的值元素,當有多選值時,可以放陣列型態的Object,且遇到in(:key),它會自動去解析,很有用
				mapParamsValue(paramsValue, query);
			} else if (paramsValue instanceof List) {
				// 通常用於,按參數位置綁定：定義查詢參數要用"?"
				// List裡面的元素,不要放陣列型態的Object,如果HQL遇到in(?,?,?),建議一筆一筆去放
				listParamsValue(paramsValue, query);
			} else if (paramsValue instanceof Object) {
				Object obj = (Object) paramsValue;
				query.setParameter(0, obj);
			}
	}
	
	/**
	 * 處理Map查詢參數值
	 * @param paramsValue
	 * @param query
	 */
	@SuppressWarnings("unchecked")
	private void mapParamsValue(Object paramsValue, Query query) {
		Map<String, Object> map = (Map<String, Object>) paramsValue;
		Iterator<String> keyIter = map.keySet().iterator();
		while (keyIter.hasNext()) {
			String key = keyIter.next();
			//map元素可能有兩種型態
			if (map.get(key) instanceof Object[]) {
				Object[] val = (Object[]) map.get(key);
				if (val != null && val.length > 0) {
					if (val.length == 1) {
						query.setParameter(key, val[0]);
					} else {
						query.setParameterList(key, val);
					}
				}
			} else if (map.get(key) instanceof Object) {
				Object val = (Object) map.get(key);
				if (val != null) {
					query.setParameter(key, val);
				}
			}
		}
	}

	/**
	 * 處理List查詢參數值
	 * @param paramsValue
	 * @param query
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void listParamsValue(Object paramsValue, Query query) {
		List<Object> list = (List) paramsValue;
		for (int i = 0; i < list.size(); i++) {
			//list元素可能有兩種型態
			if (list.get(i) instanceof Object[]) {
				Object[] val = (Object[]) list.get(i);
				if (val != null && val.length > 0) {
					if (val.length == 1) {
						query.setParameter(i, val[0]);
					}
				}
			} else if (list.get(i) instanceof Object) {
				query.setParameter(i, list.get(i));
			}
		}
	}
	
	/**
	 * 處理Object純量值
	 * @param scalarValue
	 * @param query
	 */
	@SuppressWarnings("unchecked")
	private void processScalar(Object scalarValue, SQLQuery query) {
			if (scalarValue instanceof String[]) {
				String[] objArray = (String[]) scalarValue;
				for (int i = 0; i < objArray.length; i++) {
					query.addScalar(objArray[i]);
				}
			} else if (scalarValue instanceof Map) {
				mapScalar((Map<String, Type>)scalarValue, query);
			} else if (scalarValue instanceof List) {
				listScalar((List<String>)scalarValue, query);
			} else if (scalarValue instanceof String) {
				String obj = (String) scalarValue;
				query.addScalar(obj);
			}
	}
	
	/**
	 * 處理Map<String, Type>純量值
	 * @param scalar
	 * @param query
	 */
	private void mapScalar(Map<String, Type> scalar, SQLQuery query) {
		Map<String, Type> map =  scalar;
		Iterator<String> keyIter = map.keySet().iterator();
		while (keyIter.hasNext()) {
			String key = keyIter.next();
			Type val = (Type) map.get(key);
			if (val != null) {
				query.addScalar(key, val);
			}
		}
	}
	
	/**
	 * 處理List<String> scalar純量值
	 * @param scalar
	 * @param query
	 */
	private void listScalar(List<String> scalar, SQLQuery query) {
		List<String> list = scalar;
		for (int i = 0; i < list.size(); i++) {
			query.addScalar(list.get(i));
		}
	}
   
    /* Criteria查詢 */
    /**
     * 建立與hibernate session無關的查詢
     * @param entityClass	POJO實體物件的class
     * @return
     */
    public DetachedCriteria createDetachedCriteria(Class<T> entityClass){
        return DetachedCriteria.forClass(entityClass);
    }
    
    /**
     * 建立與hibernate session綁定的查詢
     * @param entityClass	POJO實體物件的class
     * @return
     */
    public Criteria createCriteria(Class<T> entityClass){
        return this.createDetachedCriteria(entityClass).getExecutableCriteria(this.getSession());
    }

    /**
     * Criteria查詢
     * @param criteria
     * @return
     */
    @SuppressWarnings("rawtypes")
    public List findByCriteria(DetachedCriteria criteria){
        return getHibernateTemplate().findByCriteria(criteria);
    }
    
    /**
     * Criteria查詢,
     * @param criteria
	 * @param index 		設定第幾筆開始抓資料
	 * @param pageSize 		設定一次要抓幾筆資料
     * @return
     */
    @SuppressWarnings("rawtypes")
    public List findByCriteria(DetachedCriteria criteria, int index, int pageSize){
        return getHibernateTemplate().findByCriteria(criteria, index, pageSize);
    }
    
    /* 其它 */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public Map getClassPropertyNames(Class<T> entityClass){
    	Map map = new HashMap();
    	Field[] fieldA=entityClass.getDeclaredFields();
    	for(Field defProperty : fieldA){
    		map.put(defProperty.getName(),null);
    		BaseUtil.println(">>"+defProperty.getName());
        }
    	return map;
    }
    
    @SuppressWarnings("rawtypes")
	public QueryResultBean createSQLQueryPageNoManagerEntity2( final String sql,
			final Object paramsValue,final Class entityClass) throws Exception {
		if (StringUtils.isBlank(sql)) {
			throw new Exception("sql要有值");
		}
		QueryResultBean result = new QueryResultBean();
		result.setResult(this.createSQLQueryNoManagerEntity(-1, -1, sql, paramsValue,entityClass));
		result.setCount(this.createSQLQueryCount(sql, paramsValue));
		return result;
	}
}