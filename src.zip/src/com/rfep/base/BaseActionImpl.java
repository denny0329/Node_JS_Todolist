package com.rfep.base;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.bnq.sc.model.ScSysuser;
import com.opensymphony.xwork2.ActionContext;

/**
 * 系統展示層Struts Action的基礎類別，提供對Struts Action類別之共用方法
 * @author Johnson
 * @Date: 2010/10/01 上午 13:00:00
 */
public class BaseActionImpl extends BaseUtil {
	private static final long serialVersionUID = 6605997158298953443L;

	private static final Logger log = LogManager.getLogger(BaseActionImpl.class) ;
	
	//web資源
	protected String getContextPath() {
		return getRequest().getContextPath();
	}
	
	protected Map<String, Object> getSessionMap() {
		return ActionContext.getContext().getSession();
	}

	protected HttpServletRequest getRequest() {
		return ServletActionContext.getRequest();
	}
	
	protected HttpServletResponse getResponse() {
		return ServletActionContext.getResponse();
	}
	
	protected ServletContext getServletContext() {
		return ServletActionContext.getServletContext();
	}
	
	//顯示客製錯誤訊息
	private String dspMessage;
	
	public String getDspMessage() {
		return dspMessage;
	}

	public void setDspMessage(String dspMessage) {
		this.dspMessage = dspMessage;
	}

	// 前台畫面傳進來的查詢條件
	private Map<String,String> queryCondition = new HashMap<String,String>();

	public Map<String, String> getQueryCondition() {
		return queryCondition;
	}

	public void setQueryCondition(Map<String, String> queryCondition) {
		this.queryCondition = queryCondition;
	}

	// 分頁元件
	private PageBean pageBean = new PageBean();

	public PageBean getPageBean() {
		return pageBean;
	}

	public void setPageBean(PageBean pageBean) {
		this.pageBean = pageBean;
	}
	
	/**
	 * 設定分頁元件的相關資料
	 * @author Johnson
 	 * @Date: 2010/10/01 上午 13:00:00
	 * @param tableName 
	 * @throws Exception
	 */
	protected void setPageBeanByQueryResult(String tableName) throws Exception {
		QueryResultBean queryResultBean = null;
		// 跳頁值是0,才會去做計算"總筆數"的動作
		if (this.getPageBean().getJumpPage() == 0) {
			log.info("查詢");
			this.getPageBean().setJumpPage(1);
			queryResultBean=this.getQueryResultBean(this.getPageBean(),this.getQueryCondition(),true);
			this.getPageBean().setQueryList(queryResultBean.getResult());
			this.getPageBean().setRowCount(queryResultBean.getCount());
		} else {
			log.info("跳查");
			this.setQueryCondition((Map<String, String>)getSessionMap().get(tableName+"QueryCondition"));//當跳頁或select跳頁時,程式要去session抓之前畫面的查尋條件
			queryResultBean=this.getQueryResultBean(this.getPageBean(),this.getQueryCondition(),false);
			this.getPageBean().setQueryList(queryResultBean.getResult());
			this.getPageBean().setRowCount(this.getPageBean().getRowCount());
		}
		this.getPageBean().setPageCurrent(this.getPageBean().getJumpPage());// 將跳頁設給當前頁
		log.info(this.getPageBean());
		//session儲存畫面查尋條件和查詢結果,
		this.getSessionMap().put(tableName+"QueryCondition" , getQueryCondition());
		this.getSessionMap().put(tableName+"PageBean" , this.getPageBean());
	}
	
	/**
	 * 此method,將由子類別去重新override,所以在此不做任何事,回傳null
	 * @author Johnson
	 * @Date: 2010/10/01 上午 13:00:00
	 * @param pageBean 分頁元件的model
	 * @param queryCondition 前台畫面傳進來的查詢條件
	 * @param isCount 如果要計算"總筆數",請設定為true
	 * @return null
	 * @throws Exception
	 * 
	 */
	protected  QueryResultBean getQueryResultBean(PageBean pageBean,Map<String,String> queryCondition,Boolean isCount) throws Exception{
		return null;
	}
	
	/**
	 * 取得登入者物件
	 * 
	 * @return
	 */
	public ScSysuser getUser() {
		return (ScSysuser)this.getSessionMap().get("user");
		//Johnson,上測試環境要拿掉,以下1行
		//return(ScSysuser)((BsManagerDao) AppContext.getBean("bsManagerDao")).getScSysuerById("H00246");
	}
}
