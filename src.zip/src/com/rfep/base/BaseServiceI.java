package com.rfep.base;

/**
 * 將Dao注入到Service
 * 
 * @author Johnson
 * @Date: 2010/10/01 上午 13:00:00
 */
public interface BaseServiceI<T> extends BaseDaoI<T> {
}
