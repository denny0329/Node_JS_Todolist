package com.rfep.base;

import java.io.Serializable;
import java.util.List;

/**
 * 用於分頁
 * @author Johnson
 * @Date: 2010/10/01 上午 13:00:00
 */
public class QueryResultBean implements Serializable {
	private static final long serialVersionUID = 3908163788697910548L;

	private Long count ;
	private List result ;
	
	public QueryResultBean() {
		
	}
	
	public Long getCount() {
		return count;
	}
	
	public void setCount(Long count) {
		this.count = count;
	}
	
	public List getResult() {
		return result;
	}
	
	public void setResult(List result) {
		this.result = result;
	}	
	
}
