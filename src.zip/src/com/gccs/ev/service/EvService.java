/**
 * @(#)EvService.java 2015/03/18
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.gccs.ev.service;

import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import com.bnq.util.QueryResult;
import com.gccs.ev.dao.hibernate.EvDao;
import com.gccs.ev.model.ActStore;
import com.gccs.ev.model.Activity;
import com.gccs.ev.model.ConCard;
import com.gccs.ev.model.CostCenter;
import com.gccs.ev.model.DiscSku;
import com.gccs.ev.model.EvSkuP;
import com.gccs.ev.model.Groupsku;
import com.gccs.ev.model.GroupskuMap;
import com.gccs.ev.model.GuiCondition;
import com.gccs.ev.model.GuiSku;
import com.gccs.ev.model.Guiamt;
import com.gccs.ev.model.GuiamtQty;
import com.gccs.ev.model.MemberCondition;
import com.gccs.ev.model.PromotionSku;
import com.gccs.ev.model.condition.EvCondition;
import com.gccs.ev.model.condition.PageGuiSku;
import com.gccs.ev.model.condition.PagePromotionSku;
import com.gccs.ev.util.ActivityGlossary;
import com.rfep.product.bs.service.PdSkuService;

public class EvService {
	public TransactionTemplate transactionTemplate;
	public EvDao dao;
	private PdSkuService pdService;
	private String actHoursFrom;
	private String actHoursTo;
	
	public String getActHoursFrom() {
		return actHoursFrom;
	}
	public void setActHoursFrom(String actHoursFrom) {
		this.actHoursFrom = actHoursFrom;
	}
	public String getActHoursTo() {
		return actHoursTo;
	}
	public void setActHoursTo(String actHoursTo) {
		this.actHoursTo = actHoursTo;
	}
	public PdSkuService getPdService() {
		return pdService;
	}
	public void setPdService(PdSkuService pdService) {
		this.pdService = pdService;
	}
	public TransactionTemplate getTransactionTemplate() {
		return transactionTemplate;
	}
	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}
	public EvDao getDao() {
		return dao;
	}
	public void setDao(EvDao dao) {
		this.dao = dao;
	}	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<Activity> findActivityByDate(final Date date) {
		return (List)this.transactionTemplate.execute(new TransactionCallback() {
		    public Object doInTransaction(TransactionStatus status){
		    	List<Activity> activityList = dao.findActivityByDate(date);	
		    	
		    	for(Activity activity : activityList) {
		    		String activityOid = activity.getOid();
		    		Integer sellType = activity.getSellType();
		    			    		
		    		activity.setGuiSkuList(addGroupskuForGuiSku(dao.findGuiSkuListByActivityOid(activityOid)));
		    		
		    		if(sellType == 1) {
		    			activity.setPromotionSkuList(addGroupskuForPromotionSku(dao.findPromotionSkuListByRefOid(activityOid)));		    			
		    		} 
		    		else if(sellType == 5) {
		    			activity.setPromotionSkuList(dao.findPromotionSkuListByActivityOid(activityOid));		    			
		    		} 
		    		else if(sellType==2 || sellType==3 || sellType==4) {
		    			List<Guiamt> guiamtList = dao.findGuiamtListByActivityOid(activityOid);	
		    			
		    			for(Guiamt guiamt : guiamtList) {
		    				String guiamtOid = guiamt.getOid();
		    				
		    				if(sellType==2 || sellType==4) {
		    				    guiamt.setPromotionSkuList(addGroupskuForPromotionSku(dao.findPromotionSkuListByRefOid(guiamtOid)));
		    				}
		    				else if(sellType == 3) {
		    					PromotionSku promotionSku = addGroupskuForPromotionSku(dao.findPromotionSkuByRefOid(guiamtOid));
		    					promotionSku.setGuiamtQtyList(dao.findGuiamtQtyListByRefOid(promotionSku.getOid()));		    					
		    					guiamt.setPromotionSku(promotionSku);
		    				}
		    			}
		    			
		    			activity.setGuiamtList(guiamtList);  		    						
		    		} 		    				    		
		    	}
		    	
				return activityList;
			}
		});		
	}
	
	private List<GuiSku> addGroupskuForGuiSku(List<GuiSku> list) {
		if(list != null) {
			for(GuiSku vo : list) {
				if(vo.getSkuType().intValue() == ActivityGlossary._sku_type_group) {		    						    				
					vo.setGroupsku(dao.findGroupskuByOid(vo.getGroupskuOid()));		    			
				}
			}
		}		
		return list;
	}
	private List<PromotionSku> addGroupskuForPromotionSku(List<PromotionSku> list) {
		if(list != null) {
			for(PromotionSku vo : list) {
				addGroupskuForPromotionSku(vo);
			}
		}		
		return list;
	}	
	private PromotionSku addGroupskuForPromotionSku(PromotionSku vo) {
		if(vo != null) {
			if(vo.getSkuType().intValue() == ActivityGlossary._sku_type_group) {		    						    				
				vo.setGroupsku(dao.findGroupskuByOid(vo.getGroupskuOid()));		    			
			}
		}
		return vo;	
	}
	
	public void saveForActivityAction(final Activity activity, final PageGuiSku pgs, final PagePromotionSku pps) {
		this.transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			public void doInTransactionWithoutResult(TransactionStatus status)
			{									
				//EV_ACTIVITY
				dao.saveOrUpdateActivity(activity);
				
				String activityOid = activity.getOid(); //after save
										
				//EV_COST_CENTER
		    	dao.deleteCostCenterByActivityOid(activityOid);
		    	if(activity.getCostCenterList() != null) {
					for(CostCenter costCenter : activity.getCostCenterList()) {
						costCenter.setActivityOid(activityOid);
						dao.saveOrUpdateCostCenter(costCenter);
					}
				}
		    	
		    	//EV_ACT_STORE
		    	dao.deleteActStoreByActivityOid(activityOid);
		    	if(activity.getActStoreList() != null) {
					for(ActStore actStore : activity.getActStoreList()) {
						actStore.setActivityOid(activityOid);
						dao.saveOrUpdateActStore(actStore);
					}
				}
		    	
		    	//EV_DISC_SKU
		    	dao.deleteDiscSkuByActivityOid(activityOid);
		    	if(activity.getDiscSkuList() != null) {
					for(DiscSku discSku : activity.getDiscSkuList()) {
						discSku.setActivityOid(activityOid);
						dao.saveOrUpdateDiscSku(discSku);
					}
				}
		    	
		    	//EV_MEMBER_CONDITION & EV_CON_CARD
		    	dao.deleteMemberConditionByActivityOid(activityOid);
		    	dao.deleteConCardByActivityOid(activityOid);
		    	if(activity.getMemberConditionList() != null) {
					for(MemberCondition memberCondition : activity.getMemberConditionList()) {
						memberCondition.setActivityOid(activityOid);
						dao.saveOrUpdateMemberCondition(memberCondition);
						
						if(memberCondition.getActCondition() == 2) {
						    if(memberCondition.getConCardList() != null) {						    	
						    	for(ConCard conCard : memberCondition.getConCardList()) {
						    		conCard.setConditionOid(memberCondition.getOid());
						    		conCard.setActivityOid(activityOid);						    		
						    		dao.saveOrUpdateConCard(conCard);						    		
						    	}						    	
						    }
						}
					}
				}		    			    	
		    					
				//EV_GUI_CONDITION
		    	dao.deleteGuiConditionByActivityOid(activityOid);
		    	if(activity.getGuiConditionList() != null) {
					for(GuiCondition guiCondition : activity.getGuiConditionList()) {
						guiCondition.setActivityOid(activityOid);
						dao.saveOrUpdateGuiCondition(guiCondition);
					}
				}
		    	
		    	//EV_GUI_SKU
		    	if(pgs != null) {				
		    	    if(pgs.getDelList() != null) {
		    	    	for(String oid : pgs.getDelList()) {		    	    		
		    	    		dao.deleteGuiSkuByOid(oid);
		    	    	}		    	    	
		    	    }
		    	    if(pgs.getVoList() != null) {
		    	    	for(GuiSku vo : pgs.getVoList()) {		    	    				    	    		
		    	    		vo.setActivityOid(activityOid);
		    	    		dao.saveOrUpdateGuiSku(vo);	    	    		
		    	    	}
		    	    }
		    	}	
		    	
		    	//EV_PROMOTION_SKU
		    	if(activity.getSellType()!=null && activity.getSellType()==1) {
		    		handlePromotionSku(activityOid, activityOid, pps);
		    	}
		    	
			}
		});	
	}
	
	public void saveActivity(final Activity activity) {
		this.transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			public void doInTransactionWithoutResult(TransactionStatus status)
			{									
				//EV_ACTIVITY
				dao.saveOrUpdateActivity(activity);
				
				String activityOid = activity.getOid(); //after save

		    	//EV_ACT_STORE
		    	if(activity.getActStoreList() != null && activity.getActStoreList().size()>0) {
					for(ActStore actStore : activity.getActStoreList()) {
						actStore.setActivityOid(activityOid);
						dao.saveOrUpdateActStore(actStore);
					}
				}
		    					
				//EV_GUI_CONDITION
		    	if(activity.getGuiConditionList() != null && activity.getGuiConditionList().size()>0) {
					for(GuiCondition guiCondition : activity.getGuiConditionList()) {
						guiCondition.setActivityOid(activityOid);
						dao.saveOrUpdateGuiCondition(guiCondition);
//						guiConditionOid = guiCondition.getOid();
						if(activity.getGuiSkuList()!= null && activity.getGuiSkuList().size()>0) {
							for(GuiSku guiSku : activity.getGuiSkuList()) {
								if (guiSku.getGroupsku()!=null){
									Groupsku groupsku= guiSku.getGroupsku();
									dao.saveOrUpdateGroupsku(groupsku);
									String groupskuOid = groupsku.getOid();
									guiSku.setActivityOid(activityOid);
									guiSku.setGroupskuOid(groupskuOid);
									
									dao.saveOrUpdateGuiSku(guiSku);
									if(groupsku.getGroupskuMapList()!= null && groupsku.getGroupskuMapList().size()>0) {
										for(GroupskuMap groupskuMap : groupsku.getGroupskuMapList()){
											groupskuMap.setGroupskuOid(groupskuOid);
											dao.saveOrUpdateGroupskuMap(groupskuMap);
										}
									}
								}
							}
						}
					}
				}
		    	
		    	//EV_GUI_AMT
		    	if(activity.getGuiamtList()!= null && activity.getGuiamtList().size()>0) {
		    		int count=1;
					for(Guiamt guiamt : activity.getGuiamtList() ) {
						guiamt.setActivityOid(activityOid);
						guiamt.setActSeq(count);
						dao.saveOrUpdateGuiamt(guiamt);
						String refOid = guiamt.getOid();
						if(guiamt.getPromotionSku()!= null) {
							PromotionSku promotionSku = guiamt.getPromotionSku();
							promotionSku.setActivityOid(activityOid);
							if(activity.getSellType()==ActivityGlossary.SELL_TYPE_ADDITION || 
								activity.getSellType()==ActivityGlossary.SELL_TYPE_PRICE_DISCOUNT||
								activity.getSellType()==ActivityGlossary.SELL_TYPE_GROUP_PURCHASING){
								promotionSku.setRefOid(refOid);
							}
							promotionSku.setActSeq(1);
							dao.saveOrUpdatePromotionSku(promotionSku);
							if(promotionSku.getGuiamtQtyList()!= null && promotionSku.getGuiamtQtyList().size()>0 ) {
								int countGuiamtQty=1;
								for(GuiamtQty guiamtQty : promotionSku.getGuiamtQtyList()) {
									guiamtQty.setActivityOid(activityOid);
									guiamtQty.setRefOid(promotionSku.getOid());
									guiamtQty.setActSeq(countGuiamtQty);
									dao.saveOrUpdateGuiamtQty(guiamtQty);
									countGuiamtQty=countGuiamtQty+1;
								}
							}
							
							if(promotionSku.getGroupsku()!= null) {
								Groupsku groupsku = promotionSku.getGroupsku();
								dao.saveOrUpdateGroupsku(groupsku);
								promotionSku.setGroupskuOid(groupsku.getOid());
								dao.saveOrUpdatePromotionSku(promotionSku);
								if(groupsku.getGroupskuMapList()!=null && groupsku.getGroupskuMapList().size()>0){
									for(GroupskuMap groupskuMap : groupsku.getGroupskuMapList()){
										groupskuMap.setGroupskuOid(groupsku.getOid());
										dao.saveOrUpdateGroupskuMap(groupskuMap);
									}
								}
							}
						}
						if(guiamt.getPromotionSkuList()!=null && guiamt.getPromotionSkuList().size()!=0) {
							int promotionSkuActSeq=1;
							for(PromotionSku promotionSku : guiamt.getPromotionSkuList()){
								
								promotionSku.setActivityOid(activityOid);
								if(activity.getSellType()==ActivityGlossary.SELL_TYPE_ADDITION || 
									activity.getSellType()==ActivityGlossary.SELL_TYPE_PRICE_DISCOUNT||
									activity.getSellType()==ActivityGlossary.SELL_TYPE_GROUP_PURCHASING){
									promotionSku.setRefOid(refOid);
								}
								promotionSku.setActSeq(promotionSkuActSeq);
								promotionSkuActSeq=promotionSkuActSeq+1;
								dao.saveOrUpdatePromotionSku(promotionSku);
								if(promotionSku.getGuiamtQtyList()!= null && promotionSku.getGuiamtQtyList().size()>0 ) {
									int countGuiamtQty=1;
									for(GuiamtQty guiamtQty : promotionSku.getGuiamtQtyList()) {
										guiamtQty.setActivityOid(activityOid);
										guiamtQty.setRefOid(promotionSku.getOid());
										guiamtQty.setActSeq(countGuiamtQty);
										dao.saveOrUpdateGuiamtQty(guiamtQty);
										countGuiamtQty=countGuiamtQty+1;
									}
								}
							}
						}
						count=count+1;
					}
				}
		    	
		    	//EV_PROMOTION_SKU
		    	if(activity.getPromotionSkuList() != null &&activity.getPromotionSkuList().size()>0) {
		    		int count=1;
					for(PromotionSku promotionSku : activity.getPromotionSkuList()) {
						promotionSku.setActivityOid(activityOid);
						if(activity.getSellType()==ActivityGlossary.SELL_TYPE_STAMP){
							promotionSku.setRefOid(activityOid);
						}
						if(promotionSku.getGroupsku()!= null) {
							Groupsku groupsku = promotionSku.getGroupsku();
							dao.saveOrUpdateGroupsku(groupsku);
							promotionSku.setGroupskuOid(groupsku.getOid());
							dao.saveOrUpdatePromotionSku(promotionSku);
							if(groupsku.getGroupskuMapList()!=null && groupsku.getGroupskuMapList().size()>0){
								for(GroupskuMap groupskuMap : groupsku.getGroupskuMapList()){
									groupskuMap.setGroupskuOid(groupsku.getOid());
									dao.saveOrUpdateGroupskuMap(groupskuMap);
								}
							}
						}
						promotionSku.setActSeq(count);
						dao.saveOrUpdatePromotionSku(promotionSku);
						count=count+1;
					}
				}
			}
		});	
	}
	
	public void savePagePromotionSku(final PagePromotionSku pps) {
		this.transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			public void doInTransactionWithoutResult(TransactionStatus status) {				
				int sellType = pps.getSellType();
				String activityOid = pps.getActivityOid();
				
				if(sellType == 1) {
					//EV_PROMOTION_SKU
					handlePromotionSku(activityOid, activityOid, pps);
				} 
				else if(sellType == 3) {
					//EV_GUIAMT
					Guiamt guiamt = pps.getGuiamt();					
					handleGuiamt(activityOid, guiamt);
					
					//EV_PROMOTION_SKU
					PromotionSku promotionSku = pps.getPromotionSku();
					promotionSku.setActivityOid(activityOid);
					promotionSku.setRefOid(guiamt.getOid());
					if(StringUtils.isEmpty(promotionSku.getOid())) {
						promotionSku.setActSeq(dao.getActSeqFromPromotionSku(guiamt.getOid()));
					}
					dao.saveOrUpdatePromotionSku(promotionSku);
					
					//EV_GUIAMT_QTY					
					dao.deleteGuiamtQtyByRefOid(promotionSku.getOid());
			    	if(pps.getGuiamtQtyList() != null) {
			    		int actSeq = 1;
						for(GuiamtQty guiamtQty : pps.getGuiamtQtyList()) {
							guiamtQty.setActivityOid(activityOid);
							guiamtQty.setRefOid(promotionSku.getOid());
							guiamtQty.setActSeq(actSeq++);
							dao.saveOrUpdateGuiamtQty(guiamtQty);							
						}
					}
				} 
				else if(sellType==2 || sellType==4) {
					//EV_GUIAMT
					Guiamt guiamt = pps.getGuiamt();	
					handleGuiamt(activityOid, guiamt);					
					
					//EV_PROMOTION_SKU
					handlePromotionSku(activityOid, guiamt.getOid(), pps);
				} 																			
			}
		});									
	}
	
	private void handleGuiamt(String activityOid, Guiamt guiamt) {
		guiamt.setActivityOid(activityOid);
		if(StringUtils.isEmpty(guiamt.getOid())) {
			guiamt.setActSeq(this.dao.getActSeqFromGuiamt(activityOid));
		}
		dao.saveOrUpdateGuiamt(guiamt);
	}
	
	private void handlePromotionSku(String activityOid, String refOid, PagePromotionSku pps) {
		if(pps != null) {				
    	    if(pps.getDelList() != null) {
    	    	for(String oid : pps.getDelList()) {		    	    				    	    		
    	    		dao.deletePromotionSkuByOid(oid);
    	    	}		    	    	
    	    }
    	    if(pps.getVoList() != null) {
    	    	int actSeq = this.dao.getActSeqFromPromotionSku(refOid);
    	    	for(PromotionSku vo : pps.getVoList()) {
    	    		vo.setActivityOid(activityOid);
    	    		vo.setRefOid(refOid);
    	    		if(StringUtils.isEmpty(vo.getOid())) {
    	    			vo.setActSeq(actSeq++);
    	    		}
    	    		dao.saveOrUpdatePromotionSku(vo);		    	    		    	    		
    	    	}
    	    }
    	}	
	}
		
	public Guiamt queryGuiamt(final int sellType, final String guiamtOid) {	
		return (Guiamt)this.transactionTemplate.execute(new TransactionCallback() {
		    public Object doInTransaction(TransactionStatus status) {		    	
		    	
		    	
		    	Guiamt guiamt = dao.findGuiamtByOid(guiamtOid);
				guiamt.setPromotionSkuList(dao.findPromotionSkuListByRefOid(guiamtOid));
				
				return guiamt;
		    }		
	    });					
	}	
	
	public String[] deleteGuiamt(final int sellType, final String[] oidList) {
		this.transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			public void doInTransactionWithoutResult(TransactionStatus status) {
				for(String oid : oidList) {					
					if(sellType == 3) {
						String psOid = dao.findPromotionSkuByRefOid(oid).getOid();
						dao.deleteGuiamtByOid(oid);
						dao.deletePromotionSkuByRefOid(oid);
						dao.deleteGuiamtQtyByRefOid(psOid);
					} else {
						dao.deleteGuiamtByOid(oid);
						dao.deletePromotionSkuByRefOid(oid);
					}					
				}
			}
		});
        return oidList;
	}	
	
	public Activity loadForActivityAction(final String oid) {
		return (Activity)this.transactionTemplate.execute(new TransactionCallback() {
		    public Object doInTransaction(TransactionStatus status){
		    	Activity activity = dao.findActivityByOid(oid);
		    	
		    	if(activity.getMemberConditionList() != null) {
					for(MemberCondition memberCondition : activity.getMemberConditionList()) {												
						if(memberCondition.getActCondition() == 2) {
							memberCondition.setConCardList(dao.findConCardListByConditionOid(memberCondition.getOid())); 
						}
					}
				}
		    	
				return activity;
			}
		});				
	}
	
	public QueryResult findActivityByCondition(EvCondition condition, int index, int pageSize, boolean isCount) {		
		return this.dao.findActivityByCondition(condition, index, pageSize, isCount);
	}
	
	public void updateActivityStatusByOid(String oid, Integer status)  {
	    this.dao.updateActivityStatusByOid(oid, status);
	}
	
	public int queryGuiSkuTotal(final String activityOid) {
		return this.dao.queryGuiSkuTotal(activityOid);
	}
	public List<GuiSku> queryGuiSkuList(final String activityOid, final int index, final int pageSize) {
		return this.dao.queryGuiSkuList(activityOid, index, pageSize);
	}
	
	public int queryPromotionSkuTotal(final String refOid) {
		return this.dao.queryPromotionSkuTotal(refOid);
	}
	public List<PromotionSku> queryPromotionSkuList(final String refOid, final int index, final int pageSize) {
		return this.dao.queryPromotionSkuList(refOid, index, pageSize);
	}
	
	public int queryGuiamtTotal(final String activityOid) {
		return this.dao.queryGuiamtTotal(activityOid);
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<Guiamt> queryGuiamtList(final String activityOid, final int index, final int pageSize, final int sellType) {
		return (List)this.transactionTemplate.execute(new TransactionCallback() {
		    public Object doInTransaction(TransactionStatus status){
		    	List<Guiamt> list = dao.queryGuiamtList(activityOid, index, pageSize);
		    	
		    	for(Guiamt guiamt : list) {
		    		guiamt.setPromotionSkuList(dao.findPromotionSkuListByRefOid(guiamt.getOid()));
		    	}
		    	
				return list;
			}
		});				
	}
	
	public Guiamt findGuiamtByOid(String oid) {		
		return this.dao.findGuiamtByOid(oid);
	}
	
	public PromotionSku findPromotionSkuByRefOid(String refOid) {
		return this.dao.findPromotionSkuByRefOid(refOid);
	}
	
	public List<GuiamtQty> findGuiamtQtyListByRefOid(String refOid) {
	    return this.dao.findGuiamtQtyListByRefOid(refOid);
	}
	
	public Integer querySellType(String activityOid) {
		return this.dao.querySellType(activityOid);
	}
	
	public void updateSellType(final String activityOid, final Integer sellType) {		
		this.transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			public void doInTransactionWithoutResult(TransactionStatus status) {							  
				dao.deleteGuiamtByActivityOid(activityOid);				
				dao.deletePromotionSkuByActivityOid(activityOid);								
				dao.deleteGuiamtQtyByActivityOid(activityOid);
				dao.updateSellType(activityOid, sellType);
			}
		});
	}
	
	public void cleanEv() {		
		this.transactionTemplate.execute(new TransactionCallbackWithoutResult() {
			public void doInTransactionWithoutResult(TransactionStatus status) {							  
				dao.deleteAllEv();			
			}
		});
	}
	
	public void setPosPrice(String channelId, String storeId,String sku) {	
		List<Activity> activityList = dao.findSellType5Activity();
		for(Activity activity : activityList){
			List<ActStore> actStoreList= dao.findActStoreListByActivityOid(activity.getOid());
			for(ActStore actStore : actStoreList){
				if(actStore.getChannelId().equals(channelId) && actStore.getStoreId().equals(storeId)){
					List<PromotionSku> promotionSkuList = dao.findPromotionSkuListByActivityOid(activity.getOid());
					for(PromotionSku promotionSku : promotionSkuList){
						if(sku!=null){
							if(promotionSku.getSku().equals(sku)){
								pdService.setEvent(storeId,sku,activity.getEventId(),new Double(promotionSku.getSellPrice()));
							}
						}
						else{
							pdService.setEvent(storeId,promotionSku.getSku(),activity.getEventId(),new Double(promotionSku.getSellPrice()));
						}
					}
				}
			}
		}
	}
	
	public Activity findActivity(String channelId , String storeId , String eventNo){
		List<Activity> activityList  = dao.findActivityListByEventId(eventNo);
		if(activityList==null ||  activityList.size()==0){
			return null;
		}
		for(Activity activity :activityList){
			List<ActStore> actStoreList =  dao.findActStoreList(activity.getOid(), channelId, storeId);
			if(actStoreList!=null && actStoreList.size()!=0){
				return activity;
			}
		}
		return null;
	}
	
	public List<EvSkuP> findEvSkuPById(String storeId, String sku){
		return this.findEvSkuPById(storeId, sku, null, null);
	}
	
	public List<EvSkuP> findEvSkuPById(
			String storeId, String sku, Integer status, Integer sellType){
		return dao.findEvSkuPById(storeId, sku, status,sellType, null, null, null);
	}
	
	public List<EvSkuP> findEvSkuPById(
			String storeId, String sku, Integer status, Integer sellType, 
			String eventNo, Date leActDtFrom , Date leActDtTo ){
		return dao.findEvSkuPById(storeId, sku, status, sellType, eventNo, leActDtFrom, leActDtTo);
	}
	
	@SuppressWarnings("rawtypes")
	public QueryResult findEventByCondition(Map queryCondition, int index, int pageSize, boolean isCount) throws ParseException {
		return dao.findEventByCondition(queryCondition, index,pageSize,isCount);
	}
	
	public List<EvSkuP> getEvSkuPByDate(Date date){
		return dao.findEvSkuPByDate(date);
	}
}