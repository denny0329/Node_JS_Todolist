package com.gccs.ev.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Guiamt extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = 4300896914749480534L;

	private String oid;
	private String activityOid; //促銷活動代號 OID
	private Integer actSeq; //序號
	private Integer guiAmtFrom; //發票交易金額_起
	private Integer guiAmtTo; //發票交易金額_迄
	private Integer selectQty; //優惠條件(選擇個數)
	private Integer sellPrice; //合購價
	private Boolean group = Boolean.FALSE;	//商品分類(false.單品,true.群組)
	private Date createTime; 
	private String creator;
	private String creatorName;
	private Date modifyTime;
	private String modifier;
	private String modifierName;
		
	private List<PromotionSku> promotionSkuList = new ArrayList<PromotionSku>(); //sellType=2,4
	private PromotionSku promotionSku; //sellType=3	

	
	public String getOid() {
		return this.oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}	
	public String getActivityOid() {
		return activityOid;
	}
	public void setActivityOid(String activityOid) {
		this.activityOid = activityOid;
	}	
	public Integer getActSeq() {
		return actSeq;
	}
	public void setActSeq(Integer actSeq) {
		this.actSeq = actSeq;
	}
	public Integer getGuiAmtFrom() {
		return this.guiAmtFrom;
	}
	public void setGuiAmtFrom(Integer guiAmtFrom) {
		this.guiAmtFrom = guiAmtFrom;
	}
	public Integer getGuiAmtTo() {
		return this.guiAmtTo;
	}
	public void setGuiAmtTo(Integer guiAmtTo) {
		this.guiAmtTo = guiAmtTo;
	}
	public Integer getSelectQty() {
		return this.selectQty;
	}
	public void setSelectQty(Integer selectQty) {
		this.selectQty = selectQty;
	}
	public Integer getSellPrice() {
		return this.sellPrice;
	}
	public void setSellPrice(Integer sellPrice) {
		this.sellPrice = sellPrice;
	}
	public Date getCreateTime() {
		return this.createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreator() {
		return this.creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getCreatorName() {
		return this.creatorName;
	}
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}
	public Date getModifyTime() {
		return this.modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public String getModifier() {
		return this.modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public String getModifierName() {
		return this.modifierName;
	}
	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}
	
	
	public PromotionSku getPromotionSku() {
		return promotionSku;
	}
	public void setPromotionSku(PromotionSku promotionSku) {
		this.promotionSku = promotionSku;
	}
	public List<PromotionSku> getPromotionSkuList() {
		return promotionSkuList;
	}
	public void setPromotionSkuList(List<PromotionSku> promotionSkuList) {
		this.promotionSkuList = promotionSkuList;
	}
	public Boolean getGroup() {
		return group;
	}
	public void setGroup(Boolean group) {
		this.group = group;
	}
	

}