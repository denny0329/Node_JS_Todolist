package com.gccs.ev.model;

import java.util.Date;

public class CostCenter extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = -7742612662668402281L;

	private String oid;
	private String activityOid; //促銷活動代號 OID
	private String deptId; //部門 ID
	private String deptName; //部門名稱
	private Double sharingRate; //分攤比例
	private Integer sharingAmt; //分攤金額
	private Date createTime; 
	private String creator;
	private String creatorName;
	private Date modifyTime;
	private String modifier;
	private String modifierName;


	public String getOid() {
		return this.oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getActivityOid() {
		return this.activityOid;
	}
	public void setActivityOid(String activityOid) {
		this.activityOid = activityOid;
	}
	public String getDeptId() {
		return this.deptId;
	}
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}	
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public Double getSharingRate() {
		return this.sharingRate;
	}
	public void setSharingRate(Double sharingRate) {
		this.sharingRate = sharingRate;
	}
	public Integer getSharingAmt() {
		return this.sharingAmt;
	}
	public void setSharingAmt(Integer sharingAmt) {
		this.sharingAmt = sharingAmt;
	}
	public Date getCreateTime() {
		return this.createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreator() {
		return this.creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getCreatorName() {
		return this.creatorName;
	}
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}
	public Date getModifyTime() {
		return this.modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public String getModifier() {
		return this.modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public String getModifierName() {
		return this.modifierName;
	}
	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}
	

}