package com.gccs.ev.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.bnq.sc.model.ScSysuser;
import com.gccs.ev.util.ActivityGlossary;

@SuppressWarnings("unchecked")
public class Activity extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = 3493473282754796965L;

	private String oid;
	private String activityId; //促銷活動代碼
	private String activityName; //促銷活動名稱
	private Integer status; //狀態
	private String eventId; //EVENT ID
	private Date actDtFrom; //促銷活動日期_起
	private Date actDtTo; //促銷活動日期_迄
	private String actHoursFrom; //促銷活動時間_起
	private String actHoursTo; //促銷活動時間_迄
	private Integer actTimes; //活動期間限制次數
	private Integer actTrsTimes; //每筆交易限制次數
	private Integer guiType; //發票折扣方式
	private String note; //備註
	private Date downloadDate; //下載日期
	private Integer profitType; //商品毛利攤提方式
	private Integer sellType; //促銷方式
	private Date createTime;
	private String creator;
	private String creatorName;
	private Date modifyTime;
	private String modifier;
	private String modifierName;
	
	private List<CostCenter> costCenterList;
	private List<ActStore> actStoreList = new ArrayList<ActStore>();	
	private List<DiscSku> discSkuList = new ArrayList<DiscSku>();
	private List<GuiCondition> guiConditionList =  new ArrayList<GuiCondition>();	
	private List<MemberCondition> memberConditionList = new ArrayList<MemberCondition>();
	
	private List<GuiSku> guiSkuList = new ArrayList<GuiSku>();
	private List<PromotionSku> promotionSkuList = new ArrayList<PromotionSku>(); //sellType=1
	private List<Guiamt> guiamtList = new ArrayList<Guiamt>(); //sellType=2,3,4
	
	
    /****************************************************************************/
	
	public Activity() {}		
	public Activity(ScSysuser user) {
		this.setStatus(0); 	
		this.setGuiType(1);
		this.setSellType(1);
		this.setProfitType(2);
		this.setActDtFrom(new Date());
		this.setActDtTo(new Date());
		this.setActHoursFrom("00:00");
		this.setActHoursTo("23:59");
		this.setCreateTime(new Date());
		this.setCreator(user.getUserId());
		this.setCreatorName(user.getUserName());
		this.setModifyTime(new Date());
		this.setModifier(user.getUserId());
		this.setModifierName(user.getUserName());
	}
	 
	public static final Map statusMap;
	public static final Map guiTypeMap;
	public static final Map profitTypeMap;
	public static final Map sellTypeMap;
	static {
		statusMap = new LinkedHashMap<String,String>();
		statusMap.put("0", "0-建立");		
		statusMap.put("1", "1-生效");
		statusMap.put("2", "2-審核中");
		statusMap.put("9", "9-失效");		
		
		guiTypeMap = new LinkedHashMap<String,String>();
		guiTypeMap.put(ActivityGlossary.GUI_TYPE_DOWN_MARGIN,
				ActivityGlossary.getGuiTypeDesc(ActivityGlossary.GUI_TYPE_DOWN_MARGIN));
		guiTypeMap.put(ActivityGlossary.GUI_TYPE_DISCOUNTING_LINE,
				ActivityGlossary.getGuiTypeDesc(ActivityGlossary.GUI_TYPE_DISCOUNTING_LINE));
						
		profitTypeMap = new LinkedHashMap<String,String>();
		profitTypeMap.put(ActivityGlossary.PROFIT_TYPE_SKU,
				ActivityGlossary.getProfitTypeDesc(ActivityGlossary.PROFIT_TYPE_SKU));
		profitTypeMap.put(ActivityGlossary.PROFIT_TYPE_AVERAGE,
				ActivityGlossary.getProfitTypeDesc(ActivityGlossary.PROFIT_TYPE_AVERAGE));
		
		sellTypeMap = new LinkedHashMap<String,String>();
		sellTypeMap.put(ActivityGlossary.SELL_TYPE_STAMP,
				ActivityGlossary.getSellTypeDesc(ActivityGlossary.SELL_TYPE_STAMP));		
		sellTypeMap.put(ActivityGlossary.SELL_TYPE_ADDITION,
				ActivityGlossary.getSellTypeDesc(ActivityGlossary.SELL_TYPE_ADDITION));	
		sellTypeMap.put(ActivityGlossary.SELL_TYPE_PRICE_DISCOUNT,
				ActivityGlossary.getSellTypeDesc(ActivityGlossary.SELL_TYPE_PRICE_DISCOUNT));
		sellTypeMap.put(ActivityGlossary.SELL_TYPE_GROUP_PURCHASING,
				ActivityGlossary.getSellTypeDesc(ActivityGlossary.SELL_TYPE_GROUP_PURCHASING));
	}
	
	public String getStatusTxt() {		
		return (this.status==null ? "" : (String)statusMap.get(status.toString()));
	}	
	
	/****************************************************************************/

	public String getOid() {
		return this.oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getActivityId() {
		return this.activityId;
	}
	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}
	public String getActivityName() {
		return this.activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public Integer getStatus() {
		return this.status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getEventId() {
		return this.eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public Date getActDtFrom() {
		return this.actDtFrom;
	}
	public void setActDtFrom(Date actDtFrom) {
		this.actDtFrom = actDtFrom;
	}
	public Date getActDtTo() {
		return this.actDtTo;
	}
	public void setActDtTo(Date actDtTo) {
		this.actDtTo = actDtTo;
	}
	public String getActHoursFrom() {
		return this.actHoursFrom;
	}
	public void setActHoursFrom(String actHoursFrom) {
		this.actHoursFrom = actHoursFrom;
	}
	public String getActHoursTo() {
		return this.actHoursTo;
	}
	public void setActHoursTo(String actHoursTo) {
		this.actHoursTo = actHoursTo;
	}
	public Integer getActTimes() {
		return this.actTimes;
	}
	public void setActTimes(Integer actTimes) {
		this.actTimes = actTimes;
	}
	public Integer getActTrsTimes() {
		return this.actTrsTimes;
	}
	public void setActTrsTimes(Integer actTrsTimes) {
		this.actTrsTimes = actTrsTimes;
	}
	public Integer getGuiType() {
		return this.guiType;
	}
	public void setGuiType(Integer guiType) {
		this.guiType = guiType;
	}
	public String getNote() {
		return this.note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public Date getDownloadDate() {
		return this.downloadDate;
	}
	public void setDownloadDate(Date downloadDate) {
		this.downloadDate = downloadDate;
	}
	public Integer getProfitType() {
		return this.profitType;
	}
	public void setProfitType(Integer profitType) {
		this.profitType = profitType;
	}	
	public Integer getSellType() {
		return sellType;
	}
	public void setSellType(Integer sellType) {
		this.sellType = sellType;
	}
	public Date getCreateTime() {
		return this.createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreator() {
		return this.creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getCreatorName() {
		return this.creatorName;
	}
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}
	public Date getModifyTime() {
		return this.modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public String getModifier() {
		return this.modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public String getModifierName() {
		return this.modifierName;
	}
	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}
	
	
	public List<CostCenter> getCostCenterList() {
		return costCenterList;
	}
	public void setCostCenterList(List<CostCenter> costCenterList) {
		this.costCenterList = costCenterList;
	}
	public List<ActStore> getActStoreList() {
		return actStoreList;
	}
	public void setActStoreList(List<ActStore> actStoreList) {
		this.actStoreList = actStoreList;
	}
	public List<DiscSku> getDiscSkuList() {
		return discSkuList;
	}
	public void setDiscSkuList(List<DiscSku> discSkuList) {
		this.discSkuList = discSkuList;
	}
	public List<GuiCondition> getGuiConditionList() {
		return guiConditionList;
	}
	public void setGuiConditionList(List<GuiCondition> guiConditionList) {
		this.guiConditionList = guiConditionList;
	}	
	public List<MemberCondition> getMemberConditionList() {
		return memberConditionList;
	}
	public void setMemberConditionList(List<MemberCondition> memberConditionList) {
		this.memberConditionList = memberConditionList;
	}
	public List<GuiSku> getGuiSkuList() {
		return guiSkuList;
	}
	public void setGuiSkuList(List<GuiSku> guiSkuList) {
		this.guiSkuList = guiSkuList;
	}
	public List<PromotionSku> getPromotionSkuList() {
		return promotionSkuList;
	}
	public void setPromotionSkuList(List<PromotionSku> promotionSkuList) {
		this.promotionSkuList = promotionSkuList;
	}
	public List<Guiamt> getGuiamtList() {
		return guiamtList;
	}
	public void setGuiamtList(List<Guiamt> guiamtList) {
		this.guiamtList = guiamtList;
	}
}