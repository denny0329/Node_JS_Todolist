package com.gccs.ev.model;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import com.gccs.ev.util.ActivityGlossary;

@SuppressWarnings("unchecked")
public class GuiCondition extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = 290796711201983649L;

	private String oid;
	private String activityOid; //促銷活動代號 OID
	private Integer guiType; //交易類型
	private Integer selectType; //類型
	private Integer guiAmtFrom; //單筆發票交易金額_起
	private Integer guiAmtTo; //單筆發票交易金額_迄
	private Integer skuamtFrom; //商品交易金額_起
	private Integer skuamtTo; //商品交易金額_迄
	private Integer skuQty; //商品個數
	private Date createTime; 
	private String creator;
	private String creatorName;
	private Date modifyTime;
	private String modifier;
	private String modifierName;
	 	
	public static final Map guiTypeMap;
	public static final Map selectTypeMap;	
	static {
		guiTypeMap = new LinkedHashMap<String,String>();
		guiTypeMap.put(String.valueOf(ActivityGlossary._gui_condition_salse_type),
				ActivityGlossary.getGuiConditionDesc(ActivityGlossary._gui_condition_salse_type));		
		guiTypeMap.put(String.valueOf(ActivityGlossary._gui_condition_trans_amt),
				ActivityGlossary.getGuiConditionDesc(ActivityGlossary._gui_condition_trans_amt));	
		guiTypeMap.put(String.valueOf(ActivityGlossary._gui_condition_sku_amt),
				ActivityGlossary.getGuiConditionDesc(ActivityGlossary._gui_condition_sku_amt));
		guiTypeMap.put(String.valueOf(ActivityGlossary._gui_condition_sku_qty),
				ActivityGlossary.getGuiConditionDesc(ActivityGlossary._gui_condition_sku_qty));
//		guiTypeMap.put("0", "交易類型");		
//		guiTypeMap.put("1", "單筆發票交易金額");	
//		guiTypeMap.put("2", "商品交易金額");
//		guiTypeMap.put("3", "商品個數");
		
		selectTypeMap = new LinkedHashMap<String,String>();
		selectTypeMap.put(String.valueOf(ActivityGlossary._sale_type_free),
				ActivityGlossary.getSaleTypeDesc(ActivityGlossary._sale_type_free));
		selectTypeMap.put(String.valueOf(ActivityGlossary._sale_type_normal),
				ActivityGlossary.getSaleTypeDesc(ActivityGlossary._sale_type_normal));
		selectTypeMap.put(String.valueOf(ActivityGlossary._sale_type_so),
				ActivityGlossary.getSaleTypeDesc(ActivityGlossary._sale_type_so));
//		selectTypeMap.put("0", "不拘");
//		selectTypeMap.put("1", "一般交易");
//		selectTypeMap.put("2", "SO/TTS");
	}		
	
	/****************************************************************************/
	
	
	public String getOid() {
		return this.oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getActivityOid() {
		return this.activityOid;
	}
	public void setActivityOid(String activityOid) {
		this.activityOid = activityOid;
	}
	public Integer getGuiType() {
		return this.guiType;
	}
	public void setGuiType(Integer guiType) {
		this.guiType = guiType;
	}
	public Integer getSelectType() {
		return this.selectType;
	}
	public void setSelectType(Integer selectType) {
		this.selectType = selectType;
	}
	public Integer getGuiAmtFrom() {
		return this.guiAmtFrom;
	}
	public void setGuiAmtFrom(Integer guiAmtFrom) {
		this.guiAmtFrom = guiAmtFrom;
	}
	public Integer getGuiAmtTo() {
		return this.guiAmtTo;
	}
	public void setGuiAmtTo(Integer guiAmtTo) {
		this.guiAmtTo = guiAmtTo;
	}
	public Integer getSkuamtFrom() {
		return this.skuamtFrom;
	}
	public void setSkuamtFrom(Integer skuamtFrom) {
		this.skuamtFrom = skuamtFrom;
	}
	public Integer getSkuamtTo() {
		return this.skuamtTo;
	}
	public void setSkuamtTo(Integer skuamtTo) {
		this.skuamtTo = skuamtTo;
	}
	public Integer getSkuQty() {
		return this.skuQty;
	}
	public void setSkuQty(Integer skuQty) {
		this.skuQty = skuQty;
	}
	public Date getCreateTime() {
		return this.createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreator() {
		return this.creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getCreatorName() {
		return this.creatorName;
	}
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}
	public Date getModifyTime() {
		return this.modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public String getModifier() {
		return this.modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public String getModifierName() {
		return this.modifierName;
	}
	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

}