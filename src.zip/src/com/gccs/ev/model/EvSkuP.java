/**
 * @(#)EvSkuP.java 2015/03/18
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.gccs.ev.model;

import java.util.Date;

import com.bnq.util.AppContext;
import com.gccs.ev.util.ActivityGlossary;
import com.rfep.product.bs.dao.hibernate.BsSkuStoreDao;
import com.rfep.product.bs.model.BsSku;
import com.rfep.product.bs.model.BsSkuStore;

/**
 * @author san
 */
public class EvSkuP extends com.gccs.ws.model.BaseVo{
	private static final long serialVersionUID = -314518183736646105L;

	private	String storeId;
	private String sku;
	private	String eventId;
	private	Date actDtFrom;
	private	Date actDtTo;
	private String actHoursFrom;
	private String actHoursTo;
	private	Integer status;
	private	Integer sellType;
	private	String activityName;
	private Integer sellPrice;		//優惠價
	private Integer printingPrice;	//印花價
	private Integer discountRate;	//percentOff
	
	private BsSku bsSku;			//商品主檔物件
	
	public String getStoreId() {
		return storeId;
	}
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
	public String getSku() {
		return sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getEventId() {
		return eventId;
	}
	public void setEventId(String eventId) {
		this.eventId = eventId;
	}
	public Date getActDtFrom() {
		return actDtFrom;
	}
	public void setActDtFrom(Date actDtFrom) {
		this.actDtFrom = actDtFrom;
	}
	public Date getActDtTo() {
		return actDtTo;
	}
	public void setActDtTo(Date actDtTo) {
		this.actDtTo = actDtTo;
	}
	public String getActHoursFrom() {
		return actHoursFrom;
	}
	public void setActHoursFrom(String actHoursFrom) {
		this.actHoursFrom = actHoursFrom;
	}
	public String getActHoursTo() {
		return actHoursTo;
	}
	public void setActHoursTo(String actHoursTo) {
		this.actHoursTo = actHoursTo;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getSellType() {
		return sellType;
	}
	public void setSellType(Integer sellType) {
		this.sellType = sellType;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}
	public Integer getSellPrice() {
		return sellPrice;
	}
	public void setSellPrice(Integer sellPrice) {
		this.sellPrice = sellPrice;
	}
	public Integer getPrintingPrice() {
		return printingPrice;
	}
	public void setPrintingPrice(Integer printingPrice) {
		this.printingPrice = printingPrice;
	}
	public Integer getDiscountRate() {
		return discountRate;
	}
	public void setDiscountRate(Integer discountRate) {
		this.discountRate = discountRate;
	}
	
	public BsSku getBsSku() {
		return bsSku;
	}
	public void setBsSku(BsSku bsSku) {
		this.bsSku = bsSku;
	}
	public Double getRegularPrice() {
		BsSkuStoreDao bsSkuStoreDao = (BsSkuStoreDao)AppContext.getBean("bsSkuStoreDao");
		BsSkuStore bsSkuStore = bsSkuStoreDao.find(storeId, sku);
		if(bsSkuStore != null)
			return bsSkuStore.getRegularPrice();
		else
			return null;
	}
	public String getSellTypeDesc() {
		return ActivityGlossary.getSellTypeDesc(sellType);
	}
}