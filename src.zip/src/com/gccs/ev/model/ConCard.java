package com.gccs.ev.model;

import java.util.Date;

public class ConCard extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = 3601912721943977297L;

	private String oid;
	private String conditionOid; //會員資格設定 OID
	private String activityOid; //促銷活動代號 OID
	private String discCardOid; //折扣卡OID
	private Date createTime;
	private String creator;
	private String creatorName;
	private Date modifyTime;
	private String modifier;
	private String modifierName;

	
	public String getOid() {
		return this.oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getConditionOid() {
		return this.conditionOid;
	}
	public void setConditionOid(String conditionOid) {
		this.conditionOid = conditionOid;
	}
	public String getActivityOid() {
		return this.activityOid;
	}
	public void setActivityOid(String activityOid) {
		this.activityOid = activityOid;
	}
	public String getDiscCardOid() {
		return this.discCardOid;
	}
	public void setDiscCardOid(String discCardOid) {
		this.discCardOid = discCardOid;
	}
	public Date getCreateTime() {
		return this.createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreator() {
		return this.creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getCreatorName() {
		return this.creatorName;
	}
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}
	public Date getModifyTime() {
		return this.modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public String getModifier() {
		return this.modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public String getModifierName() {
		return this.modifierName;
	}
	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

}