package com.gccs.ev.model;

import java.util.Date;

public class GuiamtQty extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = -4765325050651970505L;

	private String oid;
	private String activityOid; //促銷活動代號 OID
	private String refOid; //RFE_OID
	private Integer actSeq; //序號
	private Integer multiple; //倍數 
	private Integer qtyFrom; //個數_起
	private Integer qtyTo; //個數_迄
	private Integer sellRate; //促銷(%off)
	private Integer sellPrice; //促銷售價 / @單位
	private Integer discountType;	//促銷型態
	private Integer discPrice; //未來促銷價
	private Date createTime;
	private String creator;
	private String creatorName;
	private Date modifyTime;
	private String modifier;
	private String modifierName;

	
	public String getOid() {
		return this.oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getActivityOid() {
		return this.activityOid;
	}
	public void setActivityOid(String activityOid) {
		this.activityOid = activityOid;
	}	
	public String getRefOid() {
		return refOid;
	}
	public void setRefOid(String refOid) {
		this.refOid = refOid;
	}	
	public Integer getActSeq() {
		return actSeq;
	}
	public void setActSeq(Integer actSeq) {
		this.actSeq = actSeq;
	}
	public Integer getMultiple() {
		return multiple;
	}
	public void setMultiple(Integer multiple) {
		this.multiple = multiple;
	}
	public Integer getQtyFrom() {
		return this.qtyFrom;
	}
	public void setQtyFrom(Integer qtyFrom) {
		this.qtyFrom = qtyFrom;
	}
	public Integer getQtyTo() {
		return this.qtyTo;
	}
	public void setQtyTo(Integer qtyTo) {
		this.qtyTo = qtyTo;
	}
	public Integer getSellRate() {
		return this.sellRate;
	}
	public void setSellRate(Integer sellRate) {
		this.sellRate = sellRate;
	}
	public Integer getSellPrice() {
		return this.sellPrice;
	}
	public void setSellPrice(Integer sellPrice) {
		this.sellPrice = sellPrice;
	}
	public Integer getDiscPrice() {
		return this.discPrice;
	}
	public void setDiscPrice(Integer discPrice) {
		this.discPrice = discPrice;
	}
	public Date getCreateTime() {
		return this.createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreator() {
		return this.creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getCreatorName() {
		return this.creatorName;
	}
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}
	public Date getModifyTime() {
		return this.modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public String getModifier() {
		return this.modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public String getModifierName() {
		return this.modifierName;
	}
	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}
	public Integer getDiscountType() {
		return discountType;
	}
	public void setDiscountType(Integer discountType) {
		this.discountType = discountType;
	}

}