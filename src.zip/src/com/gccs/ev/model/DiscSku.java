package com.gccs.ev.model;

import java.util.Date;

public class DiscSku extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = 191270117285706213L;

	private String oid;
	private String activityOid; //促銷活動代號 OID
	private String channelId; //通路代號
	private String sku1; //負項商品(含稅)
	private String sku2; //負項商品(未稅)
	private String sku1Name; //負項商品(含稅)名稱
	private String sku2Name; //負項商品(未稅)名稱
	private Date createTime;
	private String creator;
	private String creatorName;
	private Date modifyTime;
	private String modifier;
	private String modifierName;
	

	public String getOid() {
		return this.oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getActivityOid() {
		return this.activityOid;
	}
	public void setActivityOid(String activityOid) {
		this.activityOid = activityOid;
	}
	public String getChannelId() {
		return this.channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getSku1() {
		return this.sku1;
	}
	public void setSku1(String sku1) {
		this.sku1 = sku1;
	}
	public String getSku2() {
		return this.sku2;
	}
	public void setSku2(String sku2) {
		this.sku2 = sku2;
	}
	public String getSku1Name() {
		return this.sku1Name;
	}
	public void setSku1Name(String sku1Name) {
		this.sku1Name = sku1Name;
	}
	public String getSku2Name() {
		return this.sku2Name;
	}
	public void setSku2Name(String sku2Name) {
		this.sku2Name = sku2Name;
	}
	public Date getCreateTime() {
		return this.createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreator() {
		return this.creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getCreatorName() {
		return this.creatorName;
	}
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}
	public Date getModifyTime() {
		return this.modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public String getModifier() {
		return this.modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public String getModifierName() {
		return this.modifierName;
	}
	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}
	

}