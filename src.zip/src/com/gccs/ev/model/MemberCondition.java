package com.gccs.ev.model;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.gccs.ev.util.ActivityGlossary;
import com.gccs.util.web.SelectItem;

@SuppressWarnings("unchecked")
public class MemberCondition extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = -8466282713385657771L;

	private String oid;
	private String activityOid; //促銷活動代號 OID
	private Integer actSeq; //序號
	private Integer actCondition; //活動資格條件
	private Integer birthdayFrom; //會員生日月份_起
	private Integer birthdayTo; //會員生日月份_迄
	private String cardType; //會員卡別
	private Integer bonusFrom; //會員紅利點數_起
	private Integer bonusTo; //會員紅利點數_迄
	private String filterOid; //會員篩選代號 OID
	private String opertor; //運算子
	private Date createTime;
	private String creator;
	private String creatorName;
	private Date modifyTime;
	private String modifier;
	private String modifierName;
		
	private List<ConCard> conCardList; //For 2:折扣卡別
	
	public static final Map actConditionMap;
	public static final Map cardTypeMap = SelectItem.BsCardTypeMap;	
	static {
		actConditionMap = new LinkedHashMap<String,String>();
		actConditionMap.put(String.valueOf(ActivityGlossary._member_condition_birth_month), 
				ActivityGlossary.getMemberConditionDesc(ActivityGlossary._member_condition_birth_month));
		actConditionMap.put(String.valueOf(ActivityGlossary._member_condition_card_type), 
				ActivityGlossary.getMemberConditionDesc(ActivityGlossary._member_condition_card_type));
		actConditionMap.put(String.valueOf(ActivityGlossary._member_condition_discount_card_type), 
				ActivityGlossary.getMemberConditionDesc(ActivityGlossary._member_condition_discount_card_type));
		actConditionMap.put(String.valueOf(ActivityGlossary._member_condition_bonus), 
				ActivityGlossary.getMemberConditionDesc(ActivityGlossary._member_condition_bonus));
//		actConditionMap.put("0", "出生月份");
//		actConditionMap.put("1", "卡別");
//		actConditionMap.put("2", "折扣卡別");
//		actConditionMap.put("3", "紅利點數");
		//actConditionMap.put("4", "商務帳號");
		//actConditionMap.put("5", "商務總部");
		//actConditionMap.put("6", "會員群組篩選代號");
	}	
	
	public String getConCardString() {
		if(this.conCardList == null) return "";
		
		StringBuilder sb = new StringBuilder();
		for(int i=0,len=this.conCardList.size(); i<len; i++) {			
			sb.append(this.conCardList.get(i).getDiscCardOid());
			if(i != len-1) sb.append(",");
		}
		
		return sb.toString();
	}
	
	/****************************************************************************/
	

	public String getOid() {
		return this.oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getActivityOid() {
		return this.activityOid;
	}
	public void setActivityOid(String activityOid) {
		this.activityOid = activityOid;
	}
	public Integer getActSeq() {
		return this.actSeq;
	}
	public void setActSeq(Integer actSeq) {
		this.actSeq = actSeq;
	}
	public Integer getActCondition() {
		return this.actCondition;
	}
	public void setActCondition(Integer actCondition) {
		this.actCondition = actCondition;
	}
	public Integer getBirthdayFrom() {
		return this.birthdayFrom;
	}
	public void setBirthdayFrom(Integer birthdayFrom) {
		this.birthdayFrom = birthdayFrom;
	}
	public Integer getBirthdayTo() {
		return this.birthdayTo;
	}
	public void setBirthdayTo(Integer birthdayTo) {
		this.birthdayTo = birthdayTo;
	}
	public String getCardType() {
		return this.cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public Integer getBonusFrom() {
		return this.bonusFrom;
	}
	public void setBonusFrom(Integer bonusFrom) {
		this.bonusFrom = bonusFrom;
	}
	public Integer getBonusTo() {
		return this.bonusTo;
	}
	public void setBonusTo(Integer bonusTo) {
		this.bonusTo = bonusTo;
	}
	public String getFilterOid() {
		return this.filterOid;
	}
	public void setFilterOid(String filterOid) {
		this.filterOid = filterOid;
	}
	public String getOpertor() {
		return this.opertor;
	}
	public void setOpertor(String opertor) {
		this.opertor = opertor;
	}
	public Date getCreateTime() {
		return this.createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreator() {
		return this.creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getCreatorName() {
		return this.creatorName;
	}
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}
	public Date getModifyTime() {
		return this.modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public String getModifier() {
		return this.modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public String getModifierName() {
		return this.modifierName;
	}
	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}
	
	
	public List<ConCard> getConCardList() {
		return conCardList;
	}
	public void setConCardList(List<ConCard> conCardList) {
		this.conCardList = conCardList;
	}		
	

}