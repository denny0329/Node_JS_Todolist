package com.gccs.ev.model;

import java.util.Date;

public class GroupskuMap extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = -3087696420455133963L;

	private String oid;
	private String groupskuOid; //組合商品OID
	private Integer skuType;
	private String channelId; //通路別 ID	
	private String dept; //DEPT
	private String subDept; //SUB_DEPT
	private String class_; //CLASS
	private String subClass; //SUB_CLASS
	private String className; //分類名稱
	private String sku; //SKU
	private String skuName; //SKU名稱
	private String vendorId; //廠商
	private String vendorName; //廠商名稱
	private Integer qty; //數量
	private Integer diffPrice; //需補差價/個
	private Integer sellPrice; //售價
	private Integer OrgPrice; //原訂價
	private Integer discPrice; //促銷價
	private Integer orgCost; //原成本
	private Date createTime;
	private String creator;
	private String creatorName;
	private Date modifyTime;
	private String modifier;
	private String modifierName;
	
	public String getOid() {
		return this.oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getGroupskuOid() {
		return this.groupskuOid;
	}
	public void setGroupskuOid(String groupskuOid) {
		this.groupskuOid = groupskuOid;
	}
	public Integer getSkuType() {
		return skuType;
	}
	public void setSkuType(Integer skuType) {
		this.skuType = skuType;
	}
	public String getChannelId() {
		return this.channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getDept() {
		return this.dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getSubDept() {
		return this.subDept;
	}
	public void setSubDept(String subDept) {
		this.subDept = subDept;
	}
	public String getClass_() {
		return this.class_;
	}
	public void setClass_(String class_) {
		this.class_ = class_;
	}
	public String getSubClass() {
		return this.subClass;
	}
	public void setSubClass(String subClass) {
		this.subClass = subClass;
	}
	public String getClassName() {
		return this.className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getSku() {
		return this.sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getSkuName() {
		return this.skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	public String getVendorId() {
		return this.vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getVendorName() {
		return this.vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public Integer getQty() {
		return this.qty;
	}
	public void setQty(Integer qty) {
		this.qty = qty;
	}
	public Integer getDiffPrice() {
		return this.diffPrice;
	}
	public void setDiffPrice(Integer diffPrice) {
		this.diffPrice = diffPrice;
	}
	public Integer getSellPrice() {
		return this.sellPrice;
	}
	public void setSellPrice(Integer sellPrice) {
		this.sellPrice = sellPrice;
	}
	public Integer getOrgPrice() {
		return this.OrgPrice;
	}
	public void setOrgPrice(Integer OrgPrice) {
		this.OrgPrice = OrgPrice;
	}
	public Integer getDiscPrice() {
		return this.discPrice;
	}
	public void setDiscPrice(Integer discPrice) {
		this.discPrice = discPrice;
	}
	public Integer getOrgCost() {
		return this.orgCost;
	}
	public void setOrgCost(Integer orgCost) {
		this.orgCost = orgCost;
	}
	public Date getCreateTime() {
		return this.createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreator() {
		return this.creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getCreatorName() {
		return this.creatorName;
	}
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}
	public Date getModifyTime() {
		return this.modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public String getModifier() {
		return this.modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public String getModifierName() {
		return this.modifierName;
	}
	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}
}
