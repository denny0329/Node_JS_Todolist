package com.gccs.ev.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Groupsku extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = 6427259792326639292L;

	private String oid;
	private String groupskuId;
	private String groupskuName;
	private Date effdateFrom;
	private Date effdateTo;
	private String note;
	private Integer status;
	private Date createTime;
	private String creator;
	private String creatorName;
	private Date modifyTime;
	private String modifier;
	private String modifierName;
	
	private List<GroupskuMap> groupskuMapList = new ArrayList<GroupskuMap>();

	/*********************************************************************/
	
	public static final Map statusMap;
	static {
		statusMap = new LinkedHashMap<String,String>();
		statusMap.put("0", "0-建立");
		statusMap.put("1", "1-生效");
		statusMap.put("9", "9-失效");
	}
	
	/*********************************************************************/

	public String getOid() {
		return this.oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getGroupskuId() {
		return this.groupskuId;
	}
	public void setGroupskuId(String groupskuId) {
		this.groupskuId = groupskuId;
	}
	public String getGroupskuName() {
		return this.groupskuName;
	}
	public void setGroupskuName(String groupskuName) {
		this.groupskuName = groupskuName;
	}
	public Date getEffdateFrom() {
		return this.effdateFrom;
	}
	public void setEffdateFrom(Date effdateFrom) {
		this.effdateFrom = effdateFrom;
	}
	public Date getEffdateTo() {
		return this.effdateTo;
	}
	public void setEffdateTo(Date effdateTo) {
		this.effdateTo = effdateTo;
	}
	public String getNote() {
		return this.note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public Integer getStatus() {
		return this.status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Date getCreateTime() {
		return this.createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreator() {
		return this.creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getCreatorName() {
		return this.creatorName;
	}
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}
	public Date getModifyTime() {
		return this.modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public String getModifier() {
		return this.modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public String getModifierName() {
		return this.modifierName;
	}
	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}
	
	public List<GroupskuMap> getGroupskuMapList() {
		return groupskuMapList;
	}
	public void setGroupskuMapList(List<GroupskuMap> groupskuMapList) {
		this.groupskuMapList = groupskuMapList;
	}
}
