package com.gccs.ev.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.gccs.ev.util.ActivityGlossary;

@SuppressWarnings("unchecked")
public class PromotionSku extends com.gccs.ws.model.BaseVo {
	private String oid;
	private String activityOid; //促銷活動代號 OID
	private String refOid; //RFE_OID
	private Integer actSeq; //序號
	private String channelId; //通路別
	private String dept; //DEPT
	private String subDept; //SUB_DEPT
	private String class_; //CLASS
	private String subClass; //SUB_CLASS
	private String className; //分類名稱
	private String sku; //SKU
	private String skuName; //SKU名稱
	private String vendorId; //廠商代號
	private String vendorName; //廠商名稱
	private String groupskuOid; //群組商品
	private Integer printingPrice; //印花價
	private Double discountRate; //折扣%
	private Integer sellPrice; //售價/加購價�
	private Integer qty; //個數�
	private Integer orgPrice; //原訂價
	private Integer discPrice; //促銷價
	private Integer qtyType; //原促銷個數計算方式
	private Integer cumlType; //計算方式
	private Integer skuType; //商品分類型別
	private Integer stampType;	//印花價折扣類型(1:percent,2:固定價格)
	private Integer discountType;	//折扣類型(1:percent,2:固定價格)
	private Date createTime;
	private String creator;
	private String creatorName;
	private Date modifyTime;
	private String modifier;
	private String modifierName;
		
	private List<GuiamtQty> guiamtQtyList = new ArrayList<GuiamtQty>(); //sellType=3
	private Groupsku groupsku; //skuType=4
	
	private Integer buyQty;	//sellType=6 買滿M個
	private Integer overQty; //sellType=6 N個折扣數量
	
	/****************************************************************************/
	
	public static final Map cumlTypeMap;	
	public static final Map qtyTypeMap;
	static {
		cumlTypeMap = new LinkedHashMap<String,String>();
		cumlTypeMap.put(String.valueOf(ActivityGlossary._promotion_sku_cuml_type_pos),
				ActivityGlossary.getPromotionSkuCumlTypeDesc(ActivityGlossary._promotion_sku_cuml_type_pos));		
		cumlTypeMap.put(String.valueOf(ActivityGlossary._promotion_sku_cuml_type_fixed),
				ActivityGlossary.getPromotionSkuCumlTypeDesc(ActivityGlossary._promotion_sku_cuml_type_fixed));	
		
		qtyTypeMap = new LinkedHashMap<String,String>();
		qtyTypeMap.put(String.valueOf(ActivityGlossary._promotion_sku_condition_qty),
				ActivityGlossary.getPromotionSkuConditionDesc(ActivityGlossary._promotion_sku_condition_qty));
		qtyTypeMap.put(String.valueOf(ActivityGlossary._promotion_sku_condition_multiple_include),
				ActivityGlossary.getPromotionSkuConditionDesc(ActivityGlossary._promotion_sku_condition_multiple_include));
		qtyTypeMap.put(String.valueOf(ActivityGlossary._promotion_sku_condition_multiple),
				ActivityGlossary.getPromotionSkuConditionDesc(ActivityGlossary._promotion_sku_condition_multiple));	
	}
	
	/****************************************************************************/
	

	public String getOid() {
		return this.oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}	
	public String getActivityOid() {
		return activityOid;
	}
	public void setActivityOid(String activityOid) {
		this.activityOid = activityOid;
	}
	public String getRefOid() {
		return this.refOid;
	}
	public void setRefOid(String refOid) {
		this.refOid = refOid;
	}	
	public Integer getActSeq() {
		return actSeq;
	}
	public void setActSeq(Integer actSeq) {
		this.actSeq = actSeq;
	}
	public String getChannelId() {
		return this.channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getDept() {
		return this.dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getSubDept() {
		return this.subDept;
	}
	public void setSubDept(String subDept) {
		this.subDept = subDept;
	}
	public String getClass_() {
		return this.class_;
	}
	public void setClass_(String class_) {
		this.class_ = class_;
	}
	public String getSubClass() {
		return this.subClass;
	}
	public void setSubClass(String subClass) {
		this.subClass = subClass;
	}
	public String getClassName() {
		return this.className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getSku() {
		return this.sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getSkuName() {
		return this.skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	public String getVendorId() {
		return this.vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getVendorName() {
		return this.vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getGroupskuOid() {
		return this.groupskuOid;
	}
	public void setGroupskuOid(String groupskuOid) {
		this.groupskuOid = groupskuOid;
	}
	public Integer getPrintingPrice() {
		return this.printingPrice;
	}
	public void setPrintingPrice(Integer printingPrice) {
		this.printingPrice = printingPrice;
	}
	public Double getDiscountRate() {
		return this.discountRate;
	}
	public void setDiscountRate(Double discountRate) {
		this.discountRate = discountRate;
	}
	public Integer getSellPrice() {
		return this.sellPrice;
	}
	public void setSellPrice(Integer sellPrice) {
		this.sellPrice = sellPrice;
	}
	public Integer getQty() {
		return this.qty;
	}
	public void setQty(Integer qty) {
		this.qty = qty;
	}
	public Integer getOrgPrice() {
		return this.orgPrice;
	}
	public void setOrgPrice(Integer orgPrice) {
		this.orgPrice = orgPrice;
	}
	public Integer getDiscPrice() {
		return this.discPrice;
	}
	public void setDiscPrice(Integer discPrice) {
		this.discPrice = discPrice;
	}
	public Integer getQtyType() {
		return this.qtyType;
	}
	public void setQtyType(Integer qtyType) {
		this.qtyType = qtyType;
	}	
	public Integer getCumlType() {
		return cumlType;
	}
	public void setCumlType(Integer cumlType) {
		this.cumlType = cumlType;
	}
	public Date getCreateTime() {
		return this.createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreator() {
		return this.creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getCreatorName() {
		return this.creatorName;
	}
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}
	public Date getModifyTime() {
		return this.modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public String getModifier() {
		return this.modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public String getModifierName() {
		return this.modifierName;
	}
	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}
	public Integer getSkuType() {
		return skuType;
	}
	public void setSkuType(Integer skuType) {
		this.skuType = skuType;
	}
	public List<GuiamtQty> getGuiamtQtyList() {
		return guiamtQtyList;
	}
	public void setGuiamtQtyList(List<GuiamtQty> guiamtQtyList) {
		this.guiamtQtyList = guiamtQtyList;
	}
	public Integer getStampType() {
		return stampType;
	}
	public void setStampType(Integer stampType) {
		this.stampType = stampType;
	}
	public Integer getDiscountType() {
		return discountType;
	}
	public void setDiscountType(Integer discountType) {
		this.discountType = discountType;
	}
	public Groupsku getGroupsku() {
		return groupsku;
	}
	public void setGroupsku(Groupsku groupsku) {
		this.groupsku = groupsku;
	}
	public Integer getBuyQty() {
		return buyQty;
	}
	public void setBuyQty(Integer buyQty) {
		this.buyQty = buyQty;
	}
	public Integer getOverQty() {
		return overQty;
	}
	public void setOverQty(Integer overQty) {
		this.overQty = overQty;
	}
}