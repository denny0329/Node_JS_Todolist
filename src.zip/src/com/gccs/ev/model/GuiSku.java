package com.gccs.ev.model;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import com.gccs.ev.util.ActivityGlossary;

@SuppressWarnings("unchecked")
public class GuiSku extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = -7450452406861223889L;

	private String oid;
	private String activityOid; //促銷活動代號 OID
	private String channelId; //通路別 ID	
	private String dept; //DEPT
	private String subDept; //SUB_DEPT
	private String class_; //CLASS
	private String subClass; //SUB_CLASS
	private String className; //分類名稱
	private String vendorId; //廠商
	private String vendorName; //廠商名稱
	private String sku; //SKU
	private String skuName; //SKU名稱
	private String sellUnit; //銷售單位
	private String groupskuOid; //群組商品 OID
	private Date createTime;
	private String creator;
	private String creatorName;
	private Date modifyTime;
	private String modifier;
	private String modifierName;
	private Integer skuType; //商品分類型別
	
	private Groupsku groupsku;
	
	/****************************************************************************/
	public static final Map skuTypeMap;
	static {
		skuTypeMap = new LinkedHashMap<String,String>();
		skuTypeMap.put(String.valueOf(ActivityGlossary._sku_type_nos), "SKU");		
		skuTypeMap.put(String.valueOf(ActivityGlossary._sku_type_class), "商品");
		skuTypeMap.put(String.valueOf(ActivityGlossary._sku_type_vendor), "廠商");
		skuTypeMap.put(String.valueOf(ActivityGlossary._sku_type_group), "商品群組");
	}
	/*****************************************************************************/

	public String getOid() {
		return this.oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}	
	public String getActivityOid() {
		return activityOid;
	}
	public void setActivityOid(String activityOid) {
		this.activityOid = activityOid;
	}
	public String getChannelId() {
		return this.channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getDept() {
		return this.dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public String getSubDept() {
		return this.subDept;
	}
	public void setSubDept(String subDept) {
		this.subDept = subDept;
	}
	public String getClass_() {
		return this.class_;
	}
	public void setClass_(String class_) {
		this.class_ = class_;
	}
	public String getSubClass() {
		return this.subClass;
	}
	public void setSubClass(String subClass) {
		this.subClass = subClass;
	}
	public String getClassName() {
		return this.className;
	}
	public void setClassName(String className) {
		this.className = className;
	}	
	public String getVendorId() {
		return vendorId;
	}
	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getSku() {
		return this.sku;
	}
	public void setSku(String sku) {
		this.sku = sku;
	}
	public String getSkuName() {
		return this.skuName;
	}
	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}
	public String getSellUnit() {
		return this.sellUnit;
	}
	public void setSellUnit(String sellUnit) {
		this.sellUnit = sellUnit;
	}
	public String getGroupskuOid() {
		return this.groupskuOid;
	}
	public void setGroupskuOid(String groupskuOid) {
		this.groupskuOid = groupskuOid;
	}
	public Date getCreateTime() {
		return this.createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreator() {
		return this.creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getCreatorName() {
		return this.creatorName;
	}
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}
	public Date getModifyTime() {
		return this.modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public String getModifier() {
		return this.modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public String getModifierName() {
		return this.modifierName;
	}
	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}
	public Integer getSkuType() {
		return skuType;
	}
	public void setSkuType(Integer skuType) {
		this.skuType = skuType;
	}		
	public Groupsku getGroupsku() {
		return groupsku;
	}
	public void setGroupsku(Groupsku groupsku) {
		this.groupsku = groupsku;
	}
	public String getSkuClass() {
		StringBuffer sb = new StringBuffer();
		sb.append(this.getDept()==null?"":this.getDept())
			.append(this.getSubDept()==null?"":this.getSubDept())
			.append(this.getClass_()==null?"":this.getClass_())
			.append(this.getSubClass()==null?"":this.getSubClass());
		return sb.toString();
	}
	public boolean skuClassValidator(String deptId, String subdeptId, String classId, String subclassId) {
		boolean result = false;
		if(this.getSkuClass().equals(deptId))
			result = true;
		else if(this.getSkuClass().equals(deptId+subdeptId))
			result = true;
		else if(this.getSkuClass().equals(deptId+subdeptId+classId))
			result = true;
		else if(this.getSkuClass().equals(deptId+subdeptId+classId+subclassId))
			result = true;
		
		return result;
	}
}