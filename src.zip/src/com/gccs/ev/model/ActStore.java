package com.gccs.ev.model;

import java.util.Date;

public class ActStore extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = -6937127735916002072L;

	private String oid;
	private String activityOid; //促銷活動代號 OID
	private String channelId; //通路代號
	private String storeId; //通路店別
	private Date createTime;
	private String creator;
	private String creatorName;
	private Date modifyTime;
	private String modifier;
	private String modifierName;
	
	
	/*********************************************************************/
	
	public void setChannelStore(String str) {
		String[] list = str.split("#");
		this.setChannelId(list[0]);
		this.setStoreId(list[1]);    	
	}
	public String getChannelStore() {
		return this.getChannelId() +"#" + this.getStoreId();
	}
	
	/*********************************************************************/

	public String getOid() {
		return this.oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getActivityOid() {
		return this.activityOid;
	}
	public void setActivityOid(String activityOid) {
		this.activityOid = activityOid;
	}
	public String getChannelId() {
		return this.channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getStoreId() {
		return this.storeId;
	}
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
	public Date getCreateTime() {
		return this.createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreator() {
		return this.creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getCreatorName() {
		return this.creatorName;
	}
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}
	public Date getModifyTime() {
		return this.modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public String getModifier() {
		return this.modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public String getModifierName() {
		return this.modifierName;
	}
	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}
	
	

}