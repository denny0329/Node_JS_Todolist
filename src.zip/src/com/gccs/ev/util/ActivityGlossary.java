package com.gccs.ev.util;


public class ActivityGlossary {
	//Sell Type
	public static final int SELL_TYPE_STAMP = 1;			//印花價促銷
	public static final int SELL_TYPE_ADDITION = 2;			//加購商品/優惠商品
	public static final int SELL_TYPE_PRICE_DISCOUNT = 3;	//商品價格優惠
	public static final int SELL_TYPE_GROUP_PURCHASING = 4;	//合購商品
	public static final int SELL_TYPE_POS_PRICE = 5;		//降價促銷
	public static final int SELL_TYPE_GROUP_DISCOUNT = 6;	//M個商品內N個打折
	//GUI TYPE
	public static final int GUI_TYPE_DOWN_MARGIN = 1;		//Down Margin
	public static final int GUI_TYPE_DISCOUNTING_LINE = 2;	//Discounting Line
	//商品毛利攤提方式
	public static final int PROFIT_TYPE_SKU = 1;	//攤至贈品
	public static final int PROFIT_TYPE_AVERAGE = 2;	//售價加權平均分攤
	
	//會員條件分類
	public static final int _member_condition_birth_month = 0;	//出生月份		
	public static final int _member_condition_card_type = 1;		//卡別
	public static final int _member_condition_discount_card_type = 2;	//折扣卡別
	public static final int _member_condition_bonus = 3;			//紅利點數
	public static final int _member_condition_account = 4;		//商務帳號
	public static final int _member_condition_account_hq = 5;		//商務總部
	public static final int _member_condition_group_id = 6;		//會員群組篩選代號
	
	//交易條件分類
	public static final int _gui_condition_salse_type = 0;	//交易類型
	public static final int _gui_condition_trans_amt = 1;	//單筆發票交易金額
	public static final int _gui_condition_sku_amt = 2;		//商品交易金額
	public static final int _gui_condition_sku_qty = 3;		//商品個數
	
	//交易類型
	public static final int _sale_type_free = 0;	//不拘
	public static final int _sale_type_normal = 1;	//一般交易
	public static final int _sale_type_so = 2;		//SO/TTS
	
	//Guiamt所屬sku 型態
	public static final int _amt_sku_type_single = 1;	//單品
	public static final int _amt_sku_type_group = 2;	//群組
	
	//商品分類型別
	public static final int _sku_type_nos = 1;	//sku nos
	public static final int _sku_type_class = 2;	//商品分類
	public static final int _sku_type_vendor = 3;	//廠商
	public static final int _sku_type_group = 4;	//群組商品
	
	//CUML TYPE
	public static final int _promotion_sku_cuml_type_pos = 0;	//POS售價
	public static final int _promotion_sku_cuml_type_fixed = 1;	//一般售價
	
	//QTY TYPE
	public static final int _promotion_sku_condition_qty = 0;		//第N個
	public static final int _promotion_sku_condition_multiple_include = 1;	//滿倍數之內
	public static final int _promotion_sku_condition_multiple = 2;	//倍數
	public static final int _promotion_sku_condition_qty_standard = 3;	//達到第N個
	
	//印花價折扣類型
	public static final int _stamp_discount_percent = 1;	//倍率
	public static final int _stamp_discount_amt = 2;	//固定金額
	
	//折扣類型
	public static final int _discount_type_percent = 1;	//倍率
	public static final int _discount_type_amt = 2;	//固定金額
	
	public static String getPromotionSkuConditionDesc(int condition) {
		switch(condition) {
			case _promotion_sku_condition_qty :
				return "第N個";
			case _promotion_sku_condition_multiple_include :
				return "滿倍數之內";
			case _promotion_sku_condition_multiple :
				return "倍數";
			case _promotion_sku_condition_qty_standard :
				return "買滿第N個";
		}
		return null;
	}
	
	public static String getPromotionSkuCumlTypeDesc(int type) {
		switch(type) {
			case _promotion_sku_cuml_type_pos :
				return "POS售價";
			case _promotion_sku_cuml_type_fixed :
				return "一般售價";
		}
		return null;
	}
	
	public static String getSellTypeDesc(int type) {
		switch(type) {
			case SELL_TYPE_STAMP :
				return "印花價促銷";
			case SELL_TYPE_ADDITION :
				return "加購商品/優惠商品";
			case SELL_TYPE_PRICE_DISCOUNT :
				return "商品價格優惠";
			case SELL_TYPE_GROUP_PURCHASING :
				return "合購商品";
			case SELL_TYPE_POS_PRICE :		
				return "降價促銷";
		}
		return null;
	}
	
	public static String getGuiTypeDesc(int type) {
		switch(type) {
			case GUI_TYPE_DOWN_MARGIN :
				return "Down Margin";
			case GUI_TYPE_DISCOUNTING_LINE :
				return "Discounting Line";
		}
		return null;
	}
	
	public static String getGuiConditionDesc(int condition) {
		switch(condition) {
			case _gui_condition_salse_type :
				return "交易類型";
			case _gui_condition_trans_amt :
				return "單筆發票交易金額";
			case _gui_condition_sku_amt :
				return "商品交易金額";
			case _gui_condition_sku_qty :
				return "商品個數";
		}
		return null;
	}
	
	public static String getSaleTypeDesc(int condition) {
		switch(condition) {
			case _sale_type_free :
				return "不拘";
			case _sale_type_normal :
				return "一般交易";
			case _sale_type_so :
				return "SO/TTS";
		}
		return null;
	}
	
	public static String getMemberConditionDesc(int condition) {
		switch(condition) {
			case _member_condition_birth_month :
				return "出生月份";
			case _member_condition_card_type :
				return "卡別";
			case _member_condition_discount_card_type :
				return "折扣卡別";
			case _member_condition_bonus :
				return "紅利點數";
			case _member_condition_account :
				return "商務帳號";
			case _member_condition_account_hq :
				return "商務總部";
			case _member_condition_group_id :
				return "會員群組篩選代號";
		}
		return null;
	}
	
	public static String getProfitTypeDesc(int type) {
		switch(type) {
			case PROFIT_TYPE_SKU :
				return "攤至贈品";
			case PROFIT_TYPE_AVERAGE :
				return "售價加權平均分攤";
		}
		return null;
	}
}
