package com.gccs.ev.action;

import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.PageBean;
import com.bnq.util.QueryResult;
import com.gccs.base.action.BaseAction;
import com.gccs.ev.model.condition.EvCondition;
import com.gccs.ev.service.EvService;
import com.opensymphony.xwork2.Action;

@SuppressWarnings("unchecked")
public abstract class EvBaseAction extends BaseAction {
	private static final long serialVersionUID = 8140624926832450893L;

	protected static final Logger log = LogManager.getLogger(EvBaseAction.class);	
	protected static final String _session_PageBean = "_session_PageBean";
	protected static final String _session_Query = "_session_Query";
		
	protected EvService service;
	protected EvCondition condition;
	protected Map result;
	protected String jsp;
	
	public EvService getService() {
		return service;
	}
	public void setService(EvService service) {
		this.service = service;
	}
	public EvCondition getCondition() {
		return condition;
	}
	public void setCondition(EvCondition condition) {
		this.condition = condition;
	}
	public Map getResult() {
		return result;
	}
	public void setResult(Map result) {
		this.result = result;
	}	
	public String getJsp() {
		return jsp;
	}
	public void setJsp(String jsp) {
		this.jsp = jsp;
	}
	
	/************************************************************************************/
	
	public String execute() {
		this.getSessionMap().remove(_session_PageBean);
		this.getSessionMap().remove(_session_Query);				
		
		return Action.SUCCESS;
	}
	
	public String exit() {
		this.setPageBean((PageBean)this.getSessionMap().get(_session_PageBean));
		this.setCondition((EvCondition)this.getSessionMap().get(_session_Query));
		
		return Action.SUCCESS;
	}	
	
	public String findByCondition() {
		try {						
			if(!this.hasToCountTotal()) {				
				this.condition = (EvCondition)this.getSessionMap().get(_session_Query);
			} else {
				this.getSessionMap().put(_session_Query, this.condition);
				this.getPageBean().setJumpPage("");
			}
						
			QueryResult result = findQueryResult();
			this.setPageBeanByQueryResult(result, this.getAction("findByCondition"));
			
			this.getSessionMap().put(_session_PageBean, this.getPageBean());
		} catch (Throwable t) {
			log.error(t);
			addActionError(ERROR_MSG);			
		}					
		
		return Action.SUCCESS;
	}		
	
	//Abstract for overwrite
	protected QueryResult findQueryResult() {
		return null;
	}
}
