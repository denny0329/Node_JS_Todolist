package com.gccs.ev.action;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.bnq.util.DateTimeUtils;
import com.bnq.util.QueryResult;
import com.bnq.util.StringId;
import com.gccs.ev.model.Activity;
import com.gccs.ev.model.Guiamt;
import com.gccs.ev.model.GuiamtQty;
import com.gccs.ev.model.PromotionSku;
import com.gccs.ev.model.condition.PageGuiSku;
import com.gccs.ev.model.condition.PagePromotionSku;
import com.gccs.marketing.util.DiscountSelectItem;
import com.opensymphony.xwork2.Action;

@SuppressWarnings("unchecked")
public class ActivityAction extends EvBaseAction {
	private static final long serialVersionUID = -3199624175542060977L;

	private int type = 1; //1:設定;2:審核		
	private Activity vo;		
	private String oid;		
	private PageGuiSku pgs;
	private PagePromotionSku pps;
	
	//分頁資料
	private String attrName;
	private String dataType;
	private List dataList;
	private int index = 0;
	private int pageSize = 10;
		
	/************************************************************************************/
				
	//查詢
	public QueryResult findQueryResult() {
		return this.service.findActivityByCondition(
		    this.condition, getQueryStartIndex(), getPageBean().getPageSize(), hasToCountTotal()
		);
	}
	
	//新增
	public String create() {				
		this.vo = new Activity(this.getUser());							
		return Action.INPUT;
	}
	
	//編輯
	public String load() {	
		try {
			this.vo = this.service.loadForActivityAction(this.vo.getOid());				
		} catch (Throwable t) {
			log.error(t);
			addActionError(ERROR_MSG);	
			return Action.SUCCESS;
		}							
		return Action.INPUT;
	}
	
	//存檔
	public String save() {				
		try {					
			this.service.saveForActivityAction(this.vo, this.pgs, this.pps);						
		} catch (Throwable t) {			
			log.error(t);
			addActionError(ERROR_MSG);				
		}									
		return Action.INPUT;
	}	
	
	//刪除
	public String delete() {
		return this.save();
	}
	
	//審核
	public String submit() {
		return this.save();
	}								
	
	//退回
	public String doReturn() {		
		return this.updateStatus(0);
	}
	
	//生效
	public String approve() {		
		return this.updateStatus(1);
	}				
		
	//失效	
	public String invalid() {
		return this.updateStatus(9);
	}
	
	//促銷活動資料開窗
	public String openWin() {	
		int sellType = this.pps.getSellType();
				
		if(StringUtils.isNotEmpty(this.oid)) {				
			Guiamt guiamt = this.service.findGuiamtByOid(this.oid);
			this.pps.setGuiamt(guiamt);	
			
	    	if(sellType == 3) {
	    		PromotionSku promotionSku = this.service.findPromotionSkuByRefOid(guiamt.getOid());
	    		this.pps.setPromotionSku(promotionSku);
	    		
	    		List<GuiamtQty> guiamtQtyList = this.service.findGuiamtQtyListByRefOid(promotionSku.getOid());
	    		this.pps.setGuiamtQtyList(guiamtQtyList);
	    	}
	    }		
		
		this.jsp = "TypeWin_" + sellType;
		return "jsp";
	}
	
	//促銷活動方式設定
	public String sellTypeSetting() {		
		this.jsp = "UtSellType";
		return "jsp";
	}
	
	//分頁資料
	public String queryData() {
		if("GuiSku".equals(this.dataType)) {
			this.dataList = this.service.queryGuiSkuList(this.oid, this.index, this.pageSize);			
		} 
		else if("PromotionSku".equals(this.dataType)) {
			this.dataList = this.service.queryPromotionSkuList(this.oid, this.index, this.pageSize);
		} 
		else if("Guiamt".equals(this.dataType)) {
			this.dataList = this.service.queryGuiamtList(this.oid, this.index, this.pageSize, this.vo.getSellType());		
		}
		
		this.jsp = "UtData";
		return "jsp";
	}
	
	public String savePPS() {
		try {			
			this.result = new HashMap();
			this.result.put(Action.SUCCESS, "Y");
			this.result.put("msg", "執行成功！");			
						
			this.service.savePagePromotionSku(this.pps);
			
			this.result.put("sellType", this.pps.getSellType());
			this.result.put("guiamtOid", this.pps.getGuiamt().getOid());				
		} catch (Throwable t) {
			t.printStackTrace();
			this.result.put(Action.SUCCESS, "N");
			this.result.put("msg", "執行失敗！");
		}			
		
		return "result";
	}		
		
	private String updateStatus(Integer status) {
		try {			
			this.result = new HashMap();
			this.result.put(Action.SUCCESS, "Y");
			this.result.put("msg", "執行成功！");
			this.result.put("status", status);
			this.result.put("statusTxt", Activity.statusMap.get(status.toString()));
			this.result.put("modifyTime", DateTimeUtils.getFormatSysDateTimeStr());
			this.result.put("modifierName", this.getUser().getUserName());
						
			this.service.updateActivityStatusByOid(this.oid, status);
		} catch (Throwable t) {
			t.printStackTrace();
			this.result.put(Action.SUCCESS, "N");
			this.result.put("msg", "執行失敗！");
		}			
		
		return "result";
	}
	
	public Map getStatusMap() {
		Map map = new LinkedHashMap<String,String>();		
		String firstKey = (this.type==2 ? "1,2,3" : "");
				
		map.put(firstKey, "請選擇");
		map.putAll(Activity.statusMap);
		
		if(this.type == 2) {
			map.remove("0");
		} 
				
		return map;
	}
	
	public boolean isDisabled() {			
		if(new Integer(0).equals(this.vo.getStatus())) return false;		
		return true;
	}	
	
	public Map getDiscountCardMap() {
		Map map = new LinkedHashMap<String,String>();
		List<StringId> list = DiscountSelectItem.getDiscountCardNameList(null, false);
		
		list.remove(0);
		for(StringId vo : list) {
			map.put(vo.getId(), vo.getName());
		}
		
		return map;
	}	
	
	/*****************************************************************************************/
	
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public Activity getVo() {
		return vo;
	}
	public void setVo(Activity vo) {
		this.vo = vo;
	}		
	public String getOid() {
		return oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}	
	public PageGuiSku getPgs() {
		return pgs;
	}
	public void setPgs(PageGuiSku pgs) {
		this.pgs = pgs;
	}	
	public PagePromotionSku getPps() {
		return pps;
	}
	public void setPps(PagePromotionSku pps) {
		this.pps = pps;
	}			
	public String getAttrName() {
		return attrName;
	}
	public void setAttrName(String attrName) {
		this.attrName = attrName;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public List getDataList() {
		return dataList;
	}
	public void setDataList(List dataList) {
		this.dataList = dataList;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public int getPageSize() {
		return pageSize;
	}
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
}
