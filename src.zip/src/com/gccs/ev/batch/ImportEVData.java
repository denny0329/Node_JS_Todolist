/**
 * @(#)ImportEVData.java 2015/03/18
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.gccs.ev.batch;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.quartz.JobExecutionContext;
import org.quartz.StatefulJob;

import com.bnq.util.AppContext;
import com.bnq.util.ftp.FtpConfig;
import com.bnq.util.ftp.FtpFacade;
import com.bnq.util.ftp.dao.hibernate.FtpConfigDao;
import com.gccs.ev.batch.hola.SellType5;
import com.gccs.ev.batch.vo.PrcmasRawVo;
import com.gccs.ev.batch.vo.PrmmasRawVo;
import com.gccs.ev.batch.vo.type.ConvertMas;
import com.gccs.ev.batch.vo.type.Type1;
import com.gccs.ev.batch.vo.type.Type2;
import com.gccs.ev.batch.vo.type.Type3;
import com.gccs.ev.batch.vo.type.Type4;
import com.gccs.ev.batch.vo.type.Type5;
import com.gccs.ev.batch.vo.type.Type6;
import com.gccs.ev.batch.vo.type.Type7;
import com.gccs.ev.batch.vo.type.Type8;
import com.gccs.ev.batch.vo.type.Type9;
import com.gccs.ev.batch.vo.type.TypeA;
import com.gccs.ev.batch.vo.type.TypeB;
import com.gccs.ev.batch.vo.type.TypeC;
import com.gccs.ev.batch.vo.type.TypeD;
import com.gccs.ev.service.EvService;
import com.rfep.product.bs.service.PdSkuService;
import com.rfep.product.bs.service.TransSkuVariationService;
import com.rfep.valuation.util.EvActivityDefinition;

public class ImportEVData implements StatefulJob {
	private final Logger log = LogManager.getLogger(ImportEVData.class);
	private EvService evService = (EvService)AppContext.getBean("evService");
	private PdSkuService pdSkuService= (PdSkuService)AppContext.getBean("pdService");
	private TransSkuVariationService transSkuVariationService = (TransSkuVariationService)AppContext.getBean("transSkuVariationService");
	private static FtpFacade ftpFacade = null;
	private static String sourceDir=null;
	private static String bakDir=null;
	private static String tempDir = System.getProperty("java.io.tmpdir");
	
	/**
	 * Batch執行
	 */
	public void execute(JobExecutionContext jobContext) {
		log.info("Import EV Data start : " + new Date());
		try {
			FtpConfigDao ftpConfigDao = (FtpConfigDao)AppContext.getBean("ftpDao");
			List<FtpConfig> ftpConfigs = ftpConfigDao.loadConfig("EV");
			if(ftpConfigs == null || ftpConfigs.size()==0) {
				return;
			}
			FtpConfig ftpConfig = ftpConfigs.get(0);
			tlwRun(ftpConfig);
			holaRun();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		log.info("Import EV Data end : " + new Date());
	}
	
	@SuppressWarnings("rawtypes")
	private void tlwRun(FtpConfig ftpConfig){
		try{
			ftpFacade = new FtpFacade(ftpConfig);
			//測試
			ftpFacade.getFtp().enterLocalPassiveMode();
			sourceDir = ftpConfig.getRcv_awaiting_path();
			bakDir = ftpConfig.getSnd_awaiting_path()+File.separator+"BAK";
			
			List list = ftpFacade.getFileNameList(sourceDir+File.separator+"prcmas*",null);
			if(list.size()==0){
				return;
			}
			
			for(int i = 0 ; i < list.size() ; i++){
				String prcmas = (String)list.get(i);
				String prmmas = new String(prcmas).replace("prcmas", "prmmas");
				ftpFacade.receiveFile(sourceDir,  prcmas , tempDir, prcmas);
				ftpFacade.receiveFile(sourceDir,  prmmas , tempDir, prmmas);
				backup(prcmas);
				backup(prmmas);
			}		
			ftpFacade.disConnect();
			for(int i = 0 ; i < list.size() ; i++){
				String prcmas = (String)list.get(i);
				String prmmas = new String(prcmas).replace("prcmas", "prmmas");
				String[] split = StringUtils.split(prcmas, ".");
				if(split.length!=2)
					continue;
				String storeId =split[1];
				
				File prcmasFile = new File(tempDir + File.separator + prcmas);
				File prmmasFile = new File(tempDir + File.separator + prmmas);
				
				if (!prcmasFile.exists() || !prmmasFile.exists()){
					break;
				}
				doImport(prcmasFile , prmmasFile , storeId);
				FileUtils.deleteQuietly(prcmasFile);
				FileUtils.deleteQuietly(prmmasFile);
			}
		
		}
		catch(Exception ex){
			log.error(ex.getMessage(),ex);
		}
		
	}
	
	private void holaRun(){
		try{
			SellType5 sellType5 = new SellType5();
			sellType5.run();
		}
		catch(Exception ex){
			log.error(ex.getMessage(),ex);
		}
	}
	
	private void doImport(File prcmas , File prmmas , String storeId){
		ConvertMas convertMas = new ConvertMas();
		HashMap<String,ArrayList<PrcmasRawVo>> prcMap = convertMas.parsePrcMasFile(prcmas);
		HashMap<String,ArrayList<PrmmasRawVo>> prmMap = convertMas.parsePrmMasFile(prmmas);
		// resetPosPrice
		resetPosPrice();
		//刪除EVData
		evService.cleanEv();
		
		try{
			ArrayList<PrcmasRawVo> list1= prcMap.get("1");
			Type1 type1 = new Type1(storeId);
			type1.run(list1);
		}
		catch (Exception ex){
			log.error("Type1 Import Error",ex);
		}
		
		try{
			ArrayList<PrcmasRawVo> list2= prcMap.get("2");
			Type2 type2 = new Type2(storeId);
			type2.run(list2);
		}
		catch (Exception ex){
			log.error("Type2 Import Error",ex);
		}
		
		try{
			ArrayList<PrcmasRawVo> list3= prcMap.get("3");
			Type3 type3 = new Type3(storeId);
			type3.run(list3);
		}
		catch (Exception ex){
			log.error("Type3 Import Error",ex);
		}
		
		try{
			ArrayList<PrcmasRawVo> list4= prcMap.get("4");
			Type4 type4 = new Type4(storeId);
			type4.run(list4);
		}
		catch (Exception ex){
			log.error("Type4 Import Error",ex);
		}
		
		try{
			ArrayList<PrcmasRawVo> list5= prcMap.get("5");
			Type5 type5 = new Type5(storeId);
			type5.run(list5);
		}
		catch (Exception ex){
			log.error("Type5 Import Error",ex);
		}
		
		try{
			ArrayList<PrcmasRawVo> list6= prcMap.get("6");
			Type6 type6 = new Type6(storeId);
			type6.run(list6);
		}
		catch (Exception ex){
			log.error("Type6 Import Error",ex);
		}
		
		try{
			ArrayList<PrcmasRawVo> list7= prcMap.get("7");
			Type7 type7 = new Type7(storeId);
			type7.run(list7,prmMap);
		}
		catch (Exception ex){
			log.error("Type7 Import Error",ex);
		}
		
		try{
			ArrayList<PrcmasRawVo> list8= prcMap.get("8");
			Type8 type8 = new Type8(storeId);
			type8.run(list8);
		}
		catch (Exception ex){
			log.error("Type8 Import Error",ex);
		}
		
		try{
			ArrayList<PrcmasRawVo> list9= prcMap.get("9");
			Type9 type9 = new Type9(storeId);
			type9.run(list9,prmMap);
		}
		catch (Exception ex){
			log.error("Type9 Import Error",ex);
		}
		
		try{
			ArrayList<PrcmasRawVo> listA= prcMap.get("A");
			TypeA typeA = new TypeA(storeId);
			typeA.run(listA,prmMap);
		}
		catch (Exception ex){
			log.error("TypeA Import Error",ex);
		}
		
		try{
			ArrayList<PrcmasRawVo> listB= prcMap.get("B");
			TypeB typeB = new TypeB(storeId);
			typeB.run(listB,prmMap);
		}
		catch (Exception ex){
			log.error("TypeB Import Error",ex);
		}
		
		try{
			ArrayList<PrcmasRawVo> listC= prcMap.get("C");
			TypeC typeC = new TypeC(storeId);
			typeC.run(listC,prmMap);
		}
		catch (Exception ex){
			log.error("TypeC Import Error",ex);
		}
		
		try{
			ArrayList<PrcmasRawVo> listD= prcMap.get("D");
			TypeD typeD = new TypeD(storeId);
			typeD.run(listD,prmMap);
		}
		catch (Exception ex){
			log.error("TypeD Import Error",ex);
		}
		
		//Reload EvActivityDefinition
		EvActivityDefinition.reload();
		
		transSkuVariationService.createTransSkuVariationByNR();
	}
	
	private void resetPosPrice(){
		pdSkuService.resetPosPrice();
	}
	
	private String getBackupFileName(String fileName){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		String timeStamp = sdf.format(new Date());
		return fileName+"."+timeStamp;
	}
	

	private void backup(String fileName) throws IOException {
		String backupFileName = this.getBackupFileName(fileName);
		try{
			ftpFacade.rename(sourceDir + File.separator + fileName, bakDir + File.separator + backupFileName);
		}catch(Exception e){}
	}
}
