/**
 * @(#)ReportUtils.java 2013/07/18
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 * Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
*/
package com.gccs.util.report;

import com.bnq.util.AppContext;
import com.bnq.util.mail.MailService;
import com.gccs.mp.report.action.MpReportBaseAction;
import com.rfep.rm.web.OpenRmFile;
import com.rfep.util.sys.job.SkuTransReportJob;
import jxl.format.Alignment;
import jxl.format.Border;
import jxl.format.Colour;
import jxl.format.VerticalAlignment;
import jxl.write.NumberFormat;
import jxl.write.NumberFormats;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.export.*;
import net.sf.jasperreports.engine.util.JRProperties;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.springframework.util.ResourceUtils;
import org.springframework.web.context.ContextLoader;

import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.io.*;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.util.*;

public class ReportUtils {
	private static final Logger log = LogManager.getLogger(ReportUtils.class);

	public final static String reportPath = "/jrxml/";// 相對於WebContent/jrxml/內

	public static String extFile = ".jrxml";

	/**輸出格式：PDF(1)*/
	public final static String EXPORT_TYPE_PDF = "1";
	/**輸出格式：EXCEL(2)*/
	public final static String EXPORT_TYPE_EXCEL = "2";
	/**輸出格式：HTML(3)*/
	public final static String EXPORT_TYPE_HTML = "3";
	/**輸出格式：PRINTER(4)*/
	public final static String EXPORT_TYPE_PRINTER = "4";
	/**輸出格式：OCTET_STREAM(5)*/
	public final static String EXPORT_TYPE_OCTET_STREAM = "5";

	/**產生報表的類型：檔案(1)*/
	public final static String REPORT_TYPE_FILE = "1";

	/**產生報表的類型：串流(2)*/
	public final static String REPORT_TYPE_STREAM = "2";
	/**報表要輸出的方式(內崁頁面上)*/
	public final static String CONTENT_DISPOSITION_IN_LINE = "1";
	/**報表要輸出的方式(附加檔案)*/
	public final static String CONTENT_DISPOSITION_ATTACHMENT = "2";

	public static final String SPLIT_SEQU = "▲";
	public static final String SPLIT_SEQU1 = ",";
	
	public static final String REPORT_TYPE = "reportType";

	public static final String EXPORT_TYPE = "exportType";
	/**顯示列印視窗參數名稱*/
	public static final String SHOW_PRINT_DIALOG = "showPrintDialog";
	/**列印方向參數名稱*/
	public static final String PRINT_ORIENTATION = "PrintOrientation";
	/**列印方向:直印*/
	public static final String PRINT_ORIENTATION_PORTRAIT = "PORTRAIT";
	/**列印方向:橫印*/
	public static final String PRINT_ORIENTATION_LANDSCAPE = "LANDSCAPE";
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void processReportForSend(String reportName, String reportFileName, List result, Map parameterMap, HttpServletResponse response) throws Exception {
		PrintWriter out = null;
		// 載入JRXML檔案
		String CompilePath = JRProperties.getProperty(JRProperties.COMPILER_TEMP_DIR);
		JRProperties.setProperty(JRProperties.COMPILER_CLASSPATH, CompilePath + "/jasperreports-3.0.0.jar");
		
		FileInputStream inputStream = null;
		InputStream reportStream = null;
		try {
			String exportType = (String) parameterMap.get("exportType") != null ? (String) parameterMap.get("exportType") : EXPORT_TYPE_PDF;
			String contentDisposition = (String) parameterMap.get("contentDisposition") != null ? (String) parameterMap.get("contentDisposition") : CONTENT_DISPOSITION_IN_LINE;
			String printOrientation = (String) parameterMap.get(PRINT_ORIENTATION);

			
			// 商品變價報表特別處理Night Run, 因 night run 無法藉由 ServletContext 取 path, 改用 Hot Code 強制規定路徑。
			if("SkuTransReport".equals(reportFileName)){
				inputStream = new FileInputStream(ResourceUtils.getFile(SkuTransReportJob.CLASS_PATH + reportFileName + extFile));
			}else{
				reportStream  = ServletActionContext.getServletContext().getResourceAsStream(reportPath + reportFileName + extFile);
			}
			JasperDesign jasperDesign = null;
			if(reportStream != null){
				jasperDesign = JRXmlLoader.load(reportStream);
			}else{
				jasperDesign = JRXmlLoader.load(inputStream);
			}
			JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);

			// 將資料載入
			JRBeanCollectionDataSource ds = new JRBeanCollectionDataSource(result);
			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameterMap, ds);

			if (StringUtils.isNotBlank(printOrientation)) {
				if (printOrientation.equals(PRINT_ORIENTATION_PORTRAIT))
					jasperPrint.setOrientation(JRReport.ORIENTATION_PORTRAIT);
				else
					jasperPrint.setOrientation(JRReport.ORIENTATION_LANDSCAPE);
			}

			if (exportType.equals(EXPORT_TYPE_EXCEL)) {
				// Excel每頁不要有表頭
				parameterMap.put(JRParameter.IS_IGNORE_PAGINATION, Boolean.TRUE);
			}

			if (exportType.equals(EXPORT_TYPE_EXCEL)) {
				sendExcel(jasperPrint, response, reportName, contentDisposition, parameterMap);
			}
		} catch (JRException jre) {
			log.error("無法產生報表:" + reportName, jre);
			response.setContentType("text/html");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			out.println("<html>");
			out.println("\t<body>");
			out.println("\t\t<br /><br />");
			out.println("\t\t無法產生報表");
			out.println("\t\t<br /><br />");
			out.println("\t\t錯誤訊息 ==> " + jre.getLocalizedMessage());
			out.println("\t\t<br />");
			out.println("\t\t錯誤原因 ==> " + jre.getCause());
			out.println("\t</body>");
			out.println("</html>");
			throw jre;
		} catch (Exception e) {
			log.error("無法產生報表:" + reportName, e);
			response.setContentType("text/html");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			out.println("<html>");
			out.println("\t<body>");
			out.println("\t\t<br /><br />");
			out.println("\t\t無法產生報表");
			out.println("\t\t<br /><br />");
			out.println("\t\t錯誤訊息 ==> " + e.getLocalizedMessage());
			out.println("\t\t<br />");
			out.println("\t\t錯誤原因 ==> " + e.getCause());
			out.println("\t</body>");
			out.println("</html>");
			throw e;
		} finally{
			 if(inputStream != null){
				 inputStream.close();
			 }
			 if(reportStream != null){
				 reportStream.close();
			 }
		}
	}
	
	/**
	 * 多重促銷報表功能<br>
	 * 寄送報表至使用者Mail
	 * 
	 * @param reportName 報表名稱
	 * @param reportFileName 報表檔案名稱
	 * @param result 查詢結果
	 * @param parameterMap 報表頁面參數
	 * @param response
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void processReportForMpSend(String reportName, String reportFileName, List result, Map parameterMap, HttpServletResponse response) throws Exception {
		PrintWriter out = null;
		// 載入JRXML檔案
		String CompilePath = JRProperties.getProperty(JRProperties.COMPILER_TEMP_DIR);
		JRProperties.setProperty(JRProperties.COMPILER_CLASSPATH, CompilePath + "/jasperreports-3.0.0.jar");
		InputStream reportStream = null;
		try {
			String exportType = (String) parameterMap.get("exportType") != null ? (String) parameterMap.get("exportType") : EXPORT_TYPE_PDF;
			String contentDisposition = (String) parameterMap.get("contentDisposition") != null ? (String) parameterMap.get("contentDisposition") : CONTENT_DISPOSITION_IN_LINE;
			String printOrientation = (String) parameterMap.get(PRINT_ORIENTATION);

			reportStream = this.getClass().getClassLoader().getResourceAsStream(MpReportBaseAction.REPORT_PATH + reportFileName + extFile);
			
			JasperDesign jasperDesign = null;
			
			jasperDesign = JRXmlLoader.load(reportStream);
			
			JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);

			// 將資料載入
			JRBeanCollectionDataSource ds = new JRBeanCollectionDataSource(result);
			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameterMap, ds);

			if (StringUtils.isNotBlank(printOrientation)) {
				if (printOrientation.equals(PRINT_ORIENTATION_PORTRAIT))
					jasperPrint.setOrientation(JRReport.ORIENTATION_PORTRAIT);
				else
					jasperPrint.setOrientation(JRReport.ORIENTATION_LANDSCAPE);
			}

			if (exportType.equals(EXPORT_TYPE_EXCEL)) {
				// Excel每頁不要有表頭
				parameterMap.put(JRParameter.IS_IGNORE_PAGINATION, Boolean.TRUE);
			}
			
			if (exportType.equals(EXPORT_TYPE_PDF)) {
				sendPdf(jasperPrint, response, reportName, contentDisposition, parameterMap);
			} else if (exportType.equals(EXPORT_TYPE_EXCEL)) {
				sendExcel(jasperPrint, response, reportName, contentDisposition, parameterMap);
			}
			
		} catch (JRException jre) {
			log.error("無法產生報表:" + reportName, jre);
			response.setContentType("text/html");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			out.println("<html>");
			out.println("\t<body>");
			out.println("\t\t<br /><br />");
			out.println("\t\t無法產生報表");
			out.println("\t\t<br /><br />");
			out.println("\t\t錯誤訊息 ==> " + jre.getLocalizedMessage());
			out.println("\t\t<br />");
			out.println("\t\t錯誤原因 ==> " + jre.getCause());
			out.println("\t</body>");
			out.println("</html>");
			throw jre;
		} catch (Exception e) {
			log.error("無法產生報表:" + reportName, e);
			response.setContentType("text/html");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			out.println("<html>");
			out.println("\t<body>");
			out.println("\t\t<br /><br />");
			out.println("\t\t無法產生報表");
			out.println("\t\t<br /><br />");
			out.println("\t\t錯誤訊息 ==> " + e.getLocalizedMessage());
			out.println("\t\t<br />");
			out.println("\t\t錯誤原因 ==> " + e.getCause());
			out.println("\t</body>");
			out.println("</html>");
			throw e;
		}finally{
			if(reportStream != null){
				reportStream.close();
			}
		}
	}

	/**
	 * processReport : 依報表型態產生報表
	 * @param reportName : 報表中文名稱
	 * @param reportFileName : 檔案名稱
	 * @param result : 報表資料
	 * @param parameterMap  :　報表參數
	 * @param response ： HttpServletResponse
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void processReport(String reportName, String reportFileName, List result, Map parameterMap, HttpServletResponse response) throws Exception {
		PrintWriter out = null;
		// 載入JRXML檔案
		String CompilePath = JRProperties.getProperty(JRProperties.COMPILER_TEMP_DIR);
		JRProperties.setProperty(JRProperties.COMPILER_CLASSPATH, CompilePath + "/jasperreports-3.0.0.jar");
		FileInputStream inputStream = null;
		InputStream reportStream = null;
		try {
			String reportType = (String) parameterMap.get("reportType") != null ? (String) parameterMap.get("reportType") : REPORT_TYPE_STREAM;
			String exportType = (String) parameterMap.get("exportType") != null ? (String) parameterMap.get("exportType") : EXPORT_TYPE_PDF;
			String contentDisposition = (String) parameterMap.get("contentDisposition") != null ? (String) parameterMap.get("contentDisposition") : CONTENT_DISPOSITION_IN_LINE;
			boolean showPrintDialog = (Boolean) parameterMap.get(SHOW_PRINT_DIALOG) != null ? ((Boolean) parameterMap.get(SHOW_PRINT_DIALOG)).booleanValue() : false;
			String printOrientation = (String) parameterMap.get(PRINT_ORIENTATION);

			// 中文時有亂數
			//reportName = new String((reportName.getBytes("big5")), "ISO8859-1");

//			ServletContext servletContext =  ServletActionContext.getServletContext();
//			String ireportPath = "/jrxml/";
//			JasperCompileManager.compileReportToFile(servletContext.getRealPath(ireportPath+reportFileName+".jrxml"), servletContext.getRealPath(ireportPath+reportFileName + ".jasper"));
			
			// 商品變價報表特別處理Night Run, 因 night run 無法藉由 ServletContext 取 path, 改用 Hot Code 強制規定路徑。
			if("SkuTransReport".equals(reportFileName)){
				inputStream = new FileInputStream(ResourceUtils.getFile(SkuTransReportJob.CLASS_PATH + reportFileName + extFile));
			}else{
				reportStream  = ServletActionContext.getServletContext().getResourceAsStream(reportPath + reportFileName + extFile);
			}
			JasperDesign jasperDesign = null;
			if(reportStream != null){
				jasperDesign = JRXmlLoader.load(reportStream);
			}else{
				jasperDesign = JRXmlLoader.load(inputStream);
			}
			JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);

			// 將資料載入
			JRBeanCollectionDataSource ds = new JRBeanCollectionDataSource(result);
			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameterMap, ds);

			if (StringUtils.isNotBlank(printOrientation)) {
				if (printOrientation.equals(PRINT_ORIENTATION_PORTRAIT))
					jasperPrint.setOrientation(JRReport.ORIENTATION_PORTRAIT);
				else
					jasperPrint.setOrientation(JRReport.ORIENTATION_LANDSCAPE);
			}

			if (exportType.equals(EXPORT_TYPE_EXCEL)) {
				// Excel每頁不要有表頭
				parameterMap.put(JRParameter.IS_IGNORE_PAGINATION, Boolean.TRUE);
			}

			if (reportType.equals(REPORT_TYPE_STREAM)) {
				if (exportType.equals(EXPORT_TYPE_PDF)) {
					genPDF(jasperPrint, response, reportName, contentDisposition);
				} else if (exportType.equals(EXPORT_TYPE_HTML)) {
					genHTML(jasperPrint, response, reportName, contentDisposition);
				} else if (exportType.equals(EXPORT_TYPE_EXCEL)) {
					genEXCEL(jasperPrint, response, reportName, contentDisposition);
				} else if (exportType.equals(EXPORT_TYPE_PRINTER)) {
					autoPrint(jasperPrint, showPrintDialog);
				} else if (exportType.equals(EXPORT_TYPE_OCTET_STREAM)) {
					printForApplet(jasperPrint, response);
				}
			} else if (reportType.equals(REPORT_TYPE_FILE)) {
				if (exportType.equals(EXPORT_TYPE_PDF)) {
					genPDFtoFile(jasperPrint, response, reportName);
				} else if (exportType.equals(EXPORT_TYPE_HTML)) {
					genHTMLtoFile(jasperPrint, response, reportName);
				} else if (exportType.equals(EXPORT_TYPE_EXCEL)) {
					genEXCELtoFile(jasperPrint, response, reportName);
				}
			}
		} catch (JRException jre) {
			log.error("無法產生報表:" + new String((reportName.getBytes("ISO8859-1")), "big5") , jre);
			response.setContentType("text/html");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			out.println("<html>");
			out.println("\t<body>");
			out.println("\t\t<br /><br />");
			out.println("\t\t無法產生報表");
			out.println("\t\t<br /><br />");
			out.println("\t\t錯誤訊息 ==> " + jre.getLocalizedMessage());
			out.println("\t\t<br />");
			out.println("\t\t錯誤原因 ==> " + jre.getCause());
			out.println("\t</body>");
			out.println("\t</html>");
		} catch (Exception e) {
			log.error("無法產生報表:" + new String((reportName.getBytes("ISO8859-1")), "big5") , e);
			response.setContentType("text/html");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			out.println("<html>");
			out.println("\t<body>");
			out.println("\t\t<br /><br />");
			out.println("\t\t無法產生報表");
			out.println("\t\t<br /><br />");
			out.println("\t\t錯誤訊息 ==> " + e.getLocalizedMessage());
			out.println("\t\t<br />");
			out.println("\t\t錯誤原因 ==> " + e.getCause());
			out.println("\t</body>");
			out.println("</html>");
		}finally{
			 if(inputStream != null){
				 inputStream.close();
			 }
			 if(reportStream != null){
				 reportStream.close();
			 }
		}
	}
	
	/**
	 * processReport : 依報表型態產生報表
	 * @param reportName : 報表中文名稱
	 * @param reportFileName : 檔案名稱
	 * @param result : 報表資料
	 * @param parameterMap :　報表參數
	 * @param response ： HttpServletResponse
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public JasperPrint genJasperPrint(String reportFileName,List result, Map parameterMap) throws Exception {
		// 載入JRXML檔案
		String CompilePath = JRProperties.getProperty(JRProperties.COMPILER_TEMP_DIR);
		JRProperties.setProperty(JRProperties.COMPILER_CLASSPATH, CompilePath + "/jasperreports-3.0.0.jar");
		InputStream reportStream = null;
		try {
			String printOrientation = (String) parameterMap.get(PRINT_ORIENTATION);
			// 載入JRXML檔案
			ServletContext servletActionContext = ServletActionContext.getServletContext();
			if (servletActionContext == null) {
				servletActionContext = ContextLoader.getCurrentWebApplicationContext().getServletContext();
			}
			reportStream = servletActionContext.getResourceAsStream(reportPath + reportFileName + extFile);
			JasperDesign jasperDesign = JRXmlLoader.load(reportStream);
			JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);
			// 將資料載入
			JRBeanCollectionDataSource ds = new JRBeanCollectionDataSource(result);
			JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameterMap, ds);
			if (StringUtils.isNotBlank(printOrientation)) {
				if (printOrientation.equals(PRINT_ORIENTATION_PORTRAIT))
					jasperPrint.setOrientation(JRReport.ORIENTATION_PORTRAIT);
				else
					jasperPrint.setOrientation(JRReport.ORIENTATION_LANDSCAPE);
			}
			return jasperPrint;
		} catch (JRException jre) {
			log.error("無法產生報表:" + reportFileName, jre);
			return null;
		} catch (Exception e) {
			log.error("無法產生報表:" + reportFileName, e);
			return null;
		} finally{
			if(reportStream != null){
				reportStream.close();
			}
		}
	}

	/**
	 * processReport : 依報表型態產生報表(不吃JAVALIST RESULT)
	 * @param reportName : 報表中文名稱
	 * @param reportFileName : 檔案名稱
	 * @param parameterMap :　報表參數
	 * @param response ： HttpServletResponse
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void processReport(String reportName, String reportFileName, Map parameterMap, HttpServletResponse response) throws Exception {
		PrintWriter out = null;
		// 載入JRXML檔案
		String CompilePath = JRProperties.getProperty(JRProperties.COMPILER_TEMP_DIR);
		JRProperties.setProperty(JRProperties.COMPILER_CLASSPATH, CompilePath + "/jasperreports-3.0.0.jar");
		InputStream reportStream = null;
		try {
			String reportType = (String) parameterMap.get("reportType") != null ? (String) parameterMap.get("reportType") : REPORT_TYPE_STREAM;
			String exportType = (String) parameterMap.get("exportType") != null ? (String) parameterMap.get("exportType") : EXPORT_TYPE_PDF;
			String contentDisposition = (String) parameterMap.get("contentDisposition") != null ? (String) parameterMap.get("contentDisposition") : CONTENT_DISPOSITION_IN_LINE;
			// 中文時有亂數
			//reportName = new String((reportName.getBytes("big5")), "ISO8859-1");
			
			// 載入JRXML檔案
			reportStream = ServletActionContext.getServletContext().getResourceAsStream(reportPath + reportFileName + extFile);
			JasperDesign jasperDesign = JRXmlLoader.load(reportStream);
			JasperReport jasperReport = JasperCompileManager.compileReport(jasperDesign);

			// 將資料載入
			DataSource ds = null;
			Connection conn = null;
			JasperPrint jasperPrint = null;
			try {
				ds = (DataSource) AppContext.getBean("dataSource");
				conn = ds.getConnection();
				jasperPrint = JasperFillManager.fillReport(jasperReport, parameterMap, conn);

			} catch(Exception e) {
				throw new Exception("無法取得 JasperPrint 物件。" + e.getMessage(), e);
			} finally {
				if(conn != null) {
					conn.close();
				}
				ds = null;
			}

			if (exportType.equals(EXPORT_TYPE_EXCEL)) {
				// Excel每頁不要有表頭
				parameterMap.put(JRParameter.IS_IGNORE_PAGINATION, Boolean.TRUE);
			}

			if (reportType.equals(REPORT_TYPE_STREAM)) {
				if (exportType.equals(EXPORT_TYPE_PDF)) {
					genPDF(jasperPrint, response, reportName, contentDisposition);
				} else if (exportType.equals(EXPORT_TYPE_HTML)) {
					genHTML(jasperPrint, response, reportName, contentDisposition);
				} else if (exportType.equals(EXPORT_TYPE_EXCEL)) {
					genEXCEL(jasperPrint, response, reportName, contentDisposition);
				}
			} else if (reportType.equals(REPORT_TYPE_FILE)) {
				if (exportType.equals(EXPORT_TYPE_PDF)) {
					genPDFtoFile(jasperPrint, response, reportName);
				} else if (exportType.equals(EXPORT_TYPE_HTML)) {
					genHTMLtoFile(jasperPrint, response, reportName);
				} else if (exportType.equals(EXPORT_TYPE_EXCEL)) {
					genEXCELtoFile(jasperPrint, response, reportName);
				}
			}
		} catch (JRException jre) {
			log.error("無法產生報表:" + new String((reportName.getBytes("ISO8859-1")), "big5") , jre);
			response.setContentType("text/html");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			out.println("<html>");
			out.println("\t<body>");
			out.println("\t\t<br /><br />");
			out.println("\t\t無法產生報表");
			out.println("\t\t<br /><br />");
			out.println("\t\t錯誤訊息 ==> " + jre.getLocalizedMessage());
			out.println("\t\t<br />");
			out.println("\t\t錯誤原因 ==> " + jre.getCause());
			out.println("\t</body>");
			out.println("</html>");
		} catch (Exception e) {
			log.error("無法產生報表:" + new String((reportName.getBytes("ISO8859-1")), "big5") , e);
			response.setContentType("text/html");
			response.setCharacterEncoding("UTF-8");
			out = response.getWriter();
			out.println("<html>");
			out.println("\t<body>");
			out.println("\t\t<br /><br />");
			out.println("\t\t無法產生報表");
			out.println("\t\t<br /><br />");
			out.println("\t\t錯誤訊息 ==> " + e.getLocalizedMessage());
			out.println("\t\t<br />");
			out.println("\t\t錯誤原因 ==> " + e.getCause());
			out.println("\t</body>");
			out.println("</html>");
		}finally{
			if(reportStream != null){
				reportStream.close();
			}
		}
	}

	private void autoPrint(JasperPrint jasperPrint, boolean showPrintDialog) {
		try {
			JasperPrintManager.printReport(jasperPrint, showPrintDialog);
		} catch (JRException e) {
			log.error(e.getMessage(), e);
		}
	}

	private void printForApplet(JasperPrint jasperPrint, HttpServletResponse response) {
		List<JasperPrint> prints = new ArrayList<JasperPrint>();
		prints.add(jasperPrint);

		response.setContentType("application/octet-stream");
		ServletOutputStream ouputStream = null;
		ObjectOutputStream oos = null;
		try {
			ouputStream = response.getOutputStream();
			oos = new ObjectOutputStream(ouputStream);
			oos.writeObject(prints);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			if (oos != null) {
				try {
					oos.flush();
					oos.close();
				} catch (IOException e) {
					log.error(e.getMessage(), e);
				}
			}
			if (ouputStream != null) {
				try {
					ouputStream.flush();
					ouputStream.close();
				} catch (IOException e) {
					log.error(e.getMessage(), e);
				}
			}
		}
	}
	
	public void printForApplet(List<JasperPrint> jasperPrints, HttpServletResponse response) {
		response.setContentType("application/octet-stream");
		ServletOutputStream ouputStream = null;
		ObjectOutputStream oos = null;
		try {
			ouputStream = response.getOutputStream();
			oos = new ObjectOutputStream(ouputStream);
			oos.writeObject(jasperPrints);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			if (oos != null) {
				try {
					oos.flush();
					oos.close();
				} catch (IOException e) {
					log.error(e.getMessage(), e);
				}
			}
			if (ouputStream != null) {
				try {
					ouputStream.flush();
					ouputStream.close();
				} catch (IOException e) {
					log.error(e.getMessage(), e);
				}
			}
		}
	}

	/**
	 * genPDF : 產生Pdf報表
	 * @param jasperPrint : JasperPrint
	 * @param response : HttpServletResponse
	 * @param fileName : 檔案名稱
	 * @param contentDisposition : response header格式
	 */
	private void genPDF(JasperPrint jasperPrint, HttpServletResponse response,
			String fileName, String contentDisposition) {
		ServletOutputStream outstream = null;
		try {
			byte bytes[] = JasperExportManager.exportReportToPdf(jasperPrint);
			outstream = response.getOutputStream();

			response.setContentType("application/pdf");
			response.setContentLength(bytes.length);

			String fileNameUTF8 = java.net.URLEncoder.encode(fileName, "UTF-8");

			if (contentDisposition.equals(CONTENT_DISPOSITION_IN_LINE)) {
				response.setHeader("Content-disposition", "inline ; filename*=utf-8''" + fileNameUTF8 + ".pdf");// 附加檔案
				//response.setHeader("Content-disposition", "inline ; filename=" + fileName + ".pdf");// 內崁檔案
			} else if (contentDisposition.equals(CONTENT_DISPOSITION_ATTACHMENT)) {
				response.setHeader("Content-disposition", "attachment ; filename*=utf-8''" + fileNameUTF8 + ".pdf");// 附加檔案
				//response.setHeader("Content-disposition", "attachment ; filename=" + fileName + ".pdf");// 附加檔案
			}
			outstream.write(bytes);
			
		} catch (Exception ex) {
			log.error("產生PDF檔發生錯誤:" + ex.getMessage(), ex);
			return;
		} finally{
			try {
				if(outstream != null){
					outstream.flush();
					outstream.close();
				}
			} catch (IOException e) {
				log.error(e.getMessage(), e);
			}
		}
	}
	
	/**
	 * 產生PDF報表至儲存裝置。
	 * @param jasperPrints 待產生報表
	 * @param storeId 通路店別
	 * @param fileName 報表名稱
	 * @throws JRException 
	 * @throws IOException 
	 */
	public void genPDF(List<JasperPrint> jasperPrints, String storeId, String fileName) throws JRException, IOException {
		File f = new File(OpenRmFile.getCtxPath() + storeId);
		if(!f.exists()) { 
			f.mkdirs();
		}
		f = new File(OpenRmFile.getCtxPath() + storeId + "/" + fileName + ".pdf");
		
		FileOutputStream outstream = new FileOutputStream(f);
		try {
			JRPdfExporter exporter = new JRPdfExporter();
			exporter.setParameter(JRExporterParameter.JASPER_PRINT_LIST, jasperPrints);
			exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outstream);
			exporter.exportReport();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}finally{
			try {
				if(outstream != null){
					outstream.flush();
					outstream.close();
				}
			} catch (IOException e) {
				log.error(e.getMessage(), e);
			}
		}
	}

	/**
	 * genPDF : 產生Pdf報表
	 * @param jasperPrint : JasperPrint
	 * @param response : HttpServletResponse
	 * @param fileName : 檔案名稱
	 * @param contentDisposition : response header格式
	 */
	public void genPDF(List<JasperPrint> jasperPrints, HttpServletResponse response, String fileName, String contentDisposition) {
		ServletOutputStream outstream = null;
		try {
			outstream = response.getOutputStream();
			JRPdfExporter rtfExporter = new JRPdfExporter();
			rtfExporter.setParameter(JRExporterParameter.JASPER_PRINT_LIST, jasperPrints);
			rtfExporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outstream);
			response.setContentType("application/pdf");
			String fileNameUTF8 = java.net.URLEncoder.encode(fileName, "UTF-8");

			if (contentDisposition.equals(CONTENT_DISPOSITION_IN_LINE)) {
				response.setHeader("Content-disposition", "inline ; filename*=utf-8''" + fileNameUTF8 + ".pdf");// 附加檔案
				//response.setHeader("Content-disposition", "inline ; filename=" + fileName + ".pdf");// 內崁檔案
			} else if (contentDisposition.equals(CONTENT_DISPOSITION_ATTACHMENT)) {
				response.setHeader("Content-disposition", "attachment ; filename*=utf-8''" + fileNameUTF8 + ".pdf");// 附加檔案
				//response.setHeader("Content-disposition", "attachment ; filename=" + fileName + ".pdf");// 附加檔案
			}
			rtfExporter.exportReport();
			
		} catch (Exception ex) {
			log.error("產生PDF檔發生錯誤:" + ex.getMessage(), ex);
			return;
		} finally{
			try {
				if(outstream != null){
					outstream.flush();
					outstream.close();
				}
			} catch (IOException e) {
				log.error(e.getMessage(), e);
			}
		}
	}
	
	public void genPDF(List<JasperPrint> jasperPrints,HttpServletResponse response,String reportName){
		// 中文時有亂數
		try{
			//reportName = new String((reportName.getBytes("big5")), "ISO8859-1");
			this.genPDF(jasperPrints, response , reportName,CONTENT_DISPOSITION_IN_LINE);
		}
		catch(Exception ex){
			log.error("產生PDF檔發生錯誤:" + ex.getMessage(), ex);
			return;
		}
	}

	/**
	 * genPDFtoFile : 產生Pdf報表檔案
	 * @param jasperPrint : JasperPrint
	 * @param response : HttpServletResponse
	 * @param fileName : 檔案名稱
	 */
	private void genPDFtoFile(JasperPrint jasperPrint, HttpServletResponse response, String fileName) {
		FileOutputStream fileOutputStream = null;
		try {
			byte bytes[] = JasperExportManager.exportReportToPdf(jasperPrint);
			fileOutputStream = new FileOutputStream(new File("C:\\" + fileName + ".pdf"));
			fileOutputStream.write(bytes, 0, bytes.length);
			fileOutputStream.close();
		} catch (Exception ex) {
			log.error("產生PDF檔發生錯誤:" + ex.getMessage(), ex);
			return;
		} finally{
			try {
				if(fileOutputStream!=null){
					fileOutputStream.flush();
					fileOutputStream.close();
				}
			} catch (IOException e) {
				log.error(e.getMessage(), e);
			}
		}
	}

	/**
	 * genHTML : 產生Html報表
	 * @param jasperPrint : JasperPrint
	 * @param response : HttpServletResponse
	 * @param fileName : 檔案名稱
	 * @param contentDisposition : response header格式
	 */
	private void genHTML(JasperPrint jasperPrint, HttpServletResponse response, String fileName, String contentDisposition) {
		ByteArrayOutputStream htmlOutStream = new ByteArrayOutputStream();
		OutputStream ouputStream = null;
		try {
			JRHtmlExporter exporter = new JRHtmlExporter();
			
			exporter.setParameter(JRHtmlExporterParameter.JASPER_PRINT, jasperPrint);
			exporter.setParameter(JRHtmlExporterParameter.OUTPUT_STREAM, htmlOutStream);
			exporter.setParameter(JRHtmlExporterParameter.CHARACTER_ENCODING, "Big5");
			exporter.setParameter(JRHtmlExporterParameter.IS_USING_IMAGES_TO_ALIGN, Boolean.FALSE);
			exporter.setParameter(JRHtmlExporterParameter.IMAGES_MAP, null);
			exporter.setParameter(JRHtmlExporterParameter.IMAGES_URI, "image?image=");
			exporter.setParameter(JRHtmlExporterParameter.BETWEEN_PAGES_HTML, "<div style='page-break-before:always;'></div>");
			exporter.setParameter(JRHtmlExporterParameter.IS_USING_IMAGES_TO_ALIGN, Boolean.FALSE);
			exporter.setParameter(JRHtmlExporterParameter.HTML_HEADER, "<table width=\"100%\" cellpadding=\"1\" cellspacing=\"0\" border=\"1\"><tr><td>");
			exporter.setParameter(JRHtmlExporterParameter.HTML_FOOTER, "</td></tr></table>");
			exporter.exportReport();

			byte bytes[] = htmlOutStream.toByteArray();
			
			response.reset();
			response.setContentType("text/html");
			response.setHeader("Title", fileName);
			String fileNameUTF8 = java.net.URLEncoder.encode(fileName, "UTF-8");

			if (contentDisposition.equals(CONTENT_DISPOSITION_IN_LINE)) {
				response.setHeader("Content-disposition", "inline ; filename*=utf-8''" + fileNameUTF8 + ".html");// 附加檔案
				//response.setHeader("Content-disposition", "inline ; filename=" + fileName + ".html");// 內崁檔案
			} else if (contentDisposition.equals(CONTENT_DISPOSITION_ATTACHMENT)) {
				response.setHeader("Content-disposition", "attachment ; filename*=utf-8''" + fileNameUTF8 + ".html");// 附加檔案
				//response.setHeader("Content-disposition", "attachment ; filename=" + fileName + ".html");// 附加檔案
			}
			ouputStream = response.getOutputStream();
			ouputStream.write(bytes, 0, bytes.length);
			
		} catch (Exception ex) {
			log.error("產生Html檔發生錯誤:" + ex.getMessage(), ex);
		} finally{
			try {
				if(htmlOutStream != null){
					htmlOutStream.close();
				}
				if(ouputStream != null){
					ouputStream.flush();
					ouputStream.close();
				}
				
			} catch (IOException e) {
				log.error(e.getMessage(), e);
			}
		}
	}

	/**
	 * genHTMLtoFile : 產生Html報表檔案
	 * @param jasperPrint : JasperPrint
	 * @param response : HttpServletResponse
	 * @param fileName : 檔案名稱
	 */
	private void genHTMLtoFile(JasperPrint jasperPrint, HttpServletResponse response, String fileName) {
		FileOutputStream fileOutputStream = null;
		try {
			JRHtmlExporter exporter = new JRHtmlExporter();
			ByteArrayOutputStream htmlOutStream = new ByteArrayOutputStream();
			exporter.setParameter(JRHtmlExporterParameter.JASPER_PRINT, jasperPrint);
			exporter.setParameter(JRHtmlExporterParameter.OUTPUT_STREAM, htmlOutStream);
			exporter.setParameter(JRHtmlExporterParameter.CHARACTER_ENCODING, "Big5");
			exporter.setParameter(JRHtmlExporterParameter.IS_USING_IMAGES_TO_ALIGN, Boolean.FALSE);
			exporter.setParameter(JRHtmlExporterParameter.IMAGES_MAP, null);
			exporter.setParameter(JRHtmlExporterParameter.IMAGES_URI, "image?image=");
			exporter.setParameter(JRHtmlExporterParameter.BETWEEN_PAGES_HTML, "<div style='page-break-before:always;'></div>");
			exporter.setParameter(JRHtmlExporterParameter.IS_USING_IMAGES_TO_ALIGN, Boolean.FALSE);
			exporter.setParameter(JRHtmlExporterParameter.HTML_HEADER, "<table width=\"100%\" cellpadding=\"1\" cellspacing=\"0\" border=\"1\"><tr><td>");
			exporter.setParameter(JRHtmlExporterParameter.HTML_FOOTER, "</td></tr></table>");
			exporter.exportReport();

			byte bytes[] = htmlOutStream.toByteArray();
			fileOutputStream = new FileOutputStream(new File("C:\\" + fileName + ".html"));
			fileOutputStream.write(bytes, 0, bytes.length);
			
		} catch (Exception ex) {
			log.error("產生Html檔發生錯誤:" + ex.getMessage(), ex);
		} finally{
			if(fileOutputStream != null){
				try {
					fileOutputStream.flush();
					fileOutputStream.close();
				} catch (IOException e) {
					log.error(e.getMessage(), e);
				}
			}
		}
	}

	/**
	 * genEXCEL : 產生Excel報表
	 * @param jasperPrint : JasperPrint
	 * @param response : HttpServletResponse
	 * @param fileName : 檔案名稱
	 * @param contentDisposition : response header格式
	 */
	private void genEXCEL(JasperPrint jasperPrint, HttpServletResponse response, String fileName, String contentDisposition) {
		ByteArrayOutputStream xlsOutStream = new ByteArrayOutputStream();
		OutputStream ouputStream = null;
		try {
			JExcelApiExporter exporter = new JExcelApiExporter();
			
			exporter.setParameter(JExcelApiExporterParameter.JASPER_PRINT, jasperPrint);
			exporter.setParameter(JExcelApiExporterParameter.OUTPUT_STREAM, xlsOutStream);
			exporter.exportReport();
			byte bytes[] = xlsOutStream.toByteArray();
			
			response.reset();
			response.setContentType("application/vnd.ms-excel");

			String fileNameUTF8 = java.net.URLEncoder.encode(fileName, "UTF-8");
			if (contentDisposition.equals(CONTENT_DISPOSITION_IN_LINE)) {
				response.setHeader("Content-disposition", "inline ; filename*=utf-8''" + fileNameUTF8 + ".xls");// 附加檔案
				//response.setHeader("Content-disposition", "inline ; filename=" + fileName + ".xls");// 內崁檔案
			} else if (contentDisposition.equals(CONTENT_DISPOSITION_ATTACHMENT)) {
				response.setHeader("Content-disposition", "attachment ; filename*=utf-8''" + fileNameUTF8 + ".xls");// 附加檔案
				//response.setHeader("Content-disposition", "attachment ; filename=" + fileName + ".xls");// 附加檔案
			}
			ouputStream = response.getOutputStream();
			ouputStream.write(bytes, 0, bytes.length);
			
		} catch (Exception ex) {
			log.error("產生Excel檔發生錯誤:" + ex.getMessage(), ex);
			return;
		} finally{
			try {
				if(xlsOutStream != null){
					xlsOutStream.flush();
					xlsOutStream.close();
				}
				if(ouputStream != null){
					ouputStream.flush();
					ouputStream.close();
				}
			} catch (IOException e) {
				log.error(e.getMessage(), e);
			}
		}
	}
	
	/**
	 * 產生Excel報表至儲存裝置。
	 * @param jasperPrints 待產生報表
	 * @param storeId 通路店別
	 * @param fileName 報表名稱
	 * @param sheetNames 頁簽名稱
	 * @throws JRException 
	 * @throws IOException 
	 */
	public void genEXCEL(List<JasperPrint> jasperPrints, String storeId, String fileName, Set<String> sheetNames) throws JRException, IOException {
		File f = new File(OpenRmFile.getCtxPath() + storeId);
		if(!f.exists()) { 
			f.mkdirs();
		}
		f = new File(OpenRmFile.getCtxPath() + storeId + "/" + fileName + ".xls");
		
		FileOutputStream outstream = new FileOutputStream(f);
		try {
			JExcelApiExporter exporter = new JExcelApiExporter();
			exporter.setParameter(JRExporterParameter.JASPER_PRINT_LIST, jasperPrints);
			exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, outstream);
			if (CollectionUtils.isNotEmpty(sheetNames)) {
				exporter.setParameter(JExcelApiExporterParameter.IS_WHITE_PAGE_BACKGROUND, java.lang.Boolean.FALSE);
			    exporter.setParameter(JExcelApiExporterParameter.IS_DETECT_CELL_TYPE,Boolean.TRUE);
			    exporter.setParameter(JExcelApiExporterParameter.IGNORE_PAGE_MARGINS, Boolean.FALSE);
			    exporter.setParameter(JExcelApiExporterParameter.SHEET_NAMES, sheetNames.toArray(new String[sheetNames.size()]));
			}
			exporter.exportReport();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return;
		} finally{
			try {
				if(outstream != null){
					outstream.flush();
					outstream.close();
				}
			} catch (IOException e) {
				log.error(e.getMessage(), e);
			}
		}
		
	}
	
	public void genEXCEL(List<JasperPrint> jasperPrints, HttpServletResponse response, String fileName, String contentDisposition) {
		ByteArrayOutputStream xlsOutStream = new ByteArrayOutputStream();
		OutputStream ouputStream = null;
		try {
			JExcelApiExporter exporter = new JExcelApiExporter();
			exporter.setParameter(JExcelApiExporterParameter.JASPER_PRINT_LIST, jasperPrints);
			exporter.setParameter(JExcelApiExporterParameter.OUTPUT_STREAM, xlsOutStream);
			
			exporter.exportReport();
			byte bytes[] = xlsOutStream.toByteArray();
			
			response.reset();
			response.setContentType("application/vnd.ms-excel");
			String fileNameUTF8 = java.net.URLEncoder.encode(fileName, "UTF-8");

			if (contentDisposition.equals(CONTENT_DISPOSITION_IN_LINE)) {
				response.setHeader("Content-disposition", "inline ; filename*=utf-8''" + fileNameUTF8 + ".xls");// 附加檔案
				//response.setHeader("Content-disposition", "inline ; filename=" + fileName + ".xls");// 內崁檔案
			} else if (contentDisposition.equals(CONTENT_DISPOSITION_ATTACHMENT)) {
				response.setHeader("Content-disposition", "attachment ; filename*=utf-8''" + fileNameUTF8 + ".xls");// 附加檔案
				//response.setHeader("Content-disposition", "attachment ; filename=" + fileName + ".xls");// 附加檔案
			}
			ouputStream = response.getOutputStream();
			ouputStream.write(bytes, 0, bytes.length);
			
		} catch (Exception ex) {
			log.error("產生Excel檔發生錯誤:" + ex.getMessage(), ex);
			return;
		} finally{
			try {
				if(xlsOutStream != null){
					xlsOutStream.flush();
					xlsOutStream.close();
				}
				if(ouputStream != null){
					ouputStream.flush();
					ouputStream.close();
				}
			} catch (IOException e) {
				log.error(e.getMessage(), e);
			}
		}
	}
	
	/**
	 * For generate multiple sheets of excel file
	 * 
	 * @param jasperPrints
	 * @param response
	 * @param fileName
	 * @param contentDisposition
	 * @param keySet
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void genEXCEL(List<JasperPrint> jasperPrints, HttpServletResponse response, String fileName, String contentDisposition, Set keySet) {
		ByteArrayOutputStream xlsOutStream = new ByteArrayOutputStream();
		OutputStream ouputStream = null;
		try {
            JExcelApiExporter exporter = new JExcelApiExporter();
            
            exporter.setParameter(JExcelApiExporterParameter.JASPER_PRINT_LIST, jasperPrints);
            exporter.setParameter(JExcelApiExporterParameter.OUTPUT_STREAM, xlsOutStream);
            
            exporter.setParameter(JExcelApiExporterParameter.IS_WHITE_PAGE_BACKGROUND, java.lang.Boolean.FALSE);
            exporter.setParameter(JExcelApiExporterParameter.IS_DETECT_CELL_TYPE,Boolean.TRUE);
            exporter.setParameter(JExcelApiExporterParameter.IGNORE_PAGE_MARGINS, Boolean.FALSE);
            
            exporter.setParameter(JExcelApiExporterParameter.SHEET_NAMES, keySet.toArray(new String[keySet.size()]));
            exporter.exportReport();
            byte bytes[] = xlsOutStream.toByteArray();

            response.reset();
            response.setContentType("application/vnd.ms-excel");
			String fileNameUTF8 = java.net.URLEncoder.encode(fileName, "UTF-8");

			if (contentDisposition.equals(CONTENT_DISPOSITION_IN_LINE)) {
				response.setHeader("Content-disposition", "inline ; filename*=utf-8''" + fileNameUTF8 + ".xls");// 附加檔案
				//response.setHeader("Content-disposition", "inline ; filename=" + fileName + ".xls");// 內崁檔案
			} else if (contentDisposition.equals(CONTENT_DISPOSITION_ATTACHMENT)) {
				response.setHeader("Content-disposition", "attachment ; filename*=utf-8''" + fileNameUTF8 + ".xls");// 附加檔案
				//response.setHeader("Content-disposition", "attachment ; filename=" + fileName + ".xls");// 附加檔案
			}
            ouputStream = response.getOutputStream();
            ouputStream.write(bytes, 0, bytes.length);
           
        } catch (Exception ex) {
        	log.error("產生Excel檔發生錯誤:" + ex.getMessage(), ex);
            return;
        } finally{
			try {
				if(xlsOutStream != null){
					xlsOutStream.flush();
					xlsOutStream.close();
				}
				if(ouputStream != null){
					ouputStream.flush();
					ouputStream.close();
				}
			} catch (IOException e) {
				log.error(e.getMessage(), e);
			}
		}
    }

	/**
	 * genEXCELtoFile : 產生Excel報表檔案
	 * @param jasperPrint : JasperPrint
	 * @param response : HttpServletResponse
	 * @param fileName : 檔案名稱
	 */
	private void genEXCELtoFile(JasperPrint jasperPrint, HttpServletResponse response, String fileName) {
		ByteArrayOutputStream xlsOutStream = new ByteArrayOutputStream();
		FileOutputStream fileOutputStream = null;
		try {
			JExcelApiExporter exporter = new JExcelApiExporter();
			
			exporter.setParameter(JExcelApiExporterParameter.JASPER_PRINT, jasperPrint);
			exporter.setParameter(JExcelApiExporterParameter.OUTPUT_STREAM, xlsOutStream);
			exporter.exportReport();

			byte bytes[] = xlsOutStream.toByteArray();
			fileOutputStream = new FileOutputStream(new File("C:\\" + fileName + ".xls"));
			fileOutputStream.write(bytes, 0, bytes.length);

		} catch (Exception ex) {
			log.error("產生Excel檔發生錯誤:" + ex.getMessage(), ex);
			return;
		} finally{
			try {
				if(xlsOutStream != null){
					xlsOutStream.flush();
					xlsOutStream.close();
				}
				if(fileOutputStream != null){
					fileOutputStream.flush();
					fileOutputStream.close();
				}
			} catch (IOException e) {
				log.error(e.getMessage(), e);
			}
		}
	}

	/**
	 * processRequestParameterToMap : 將request的parameter值塞入Map內
	 * @param response : HttpServletResponse
	 * @param request : HttpServletRequest
	 * @return Map<String, String>
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> processRequestParameterToMap(HttpServletResponse response, HttpServletRequest request) throws Exception {
		Map<String, String[]> mapTemp = request.getParameterMap();
		Map<String, String> mapParameter = new HashMap<String, String>();

		if (mapTemp != null) {
			for (String key : mapTemp.keySet()) {
				mapParameter.put(key, mapTemp.get(key)[0]);
			}
		}
		return mapParameter;
	}

	/**
	 * get jxl color name
	 * @param r
	 * @param g
	 * @param b
	 * @throws Exception
	 */
	public static String getRGB(String r, String g, String b) throws Exception {
		for (Field field : jxl.format.Colour.class.getFields()) {
			if (jxl.format.Colour.class.equals(field.getType()) == true) {
				Colour col = (Colour) field.get(jxl.format.Colour.getInternalColour(0));
				if (new Integer(Integer.parseInt(r, 16)).equals(col.getDefaultRGB().getRed())
						&& new Integer(Integer.parseInt(g, 16)).equals(col.getDefaultRGB().getGreen())
						&& new Integer(Integer.parseInt(b, 16)).equals(col.getDefaultRGB().getBlue()))
					return field.getName();
			}
		}
		return "";
	}

	/**
	 * instance jxl style format
	 * @param classType
	 * @param fontColor
	 * @param backgroundColor
	 * @param vStyle
	 * @param cStyle
	 * @param addBorderFlag
	 * @param fontSize
	 * @param numberFormat
	 * @return WritableCellFormat
	 * @throws Throwable
	 */
	@SuppressWarnings("rawtypes")
	public static WritableCellFormat processStyle(
			Class classType, Colour fontColor, Integer backgroundColor,
			VerticalAlignment vStyle, Alignment cStyle, boolean addBorderFlag,
			Border borderStyle, Integer fontSize, String numberFormat) throws Throwable {
		return processStyle(classType, fontColor, backgroundColor, vStyle,
				cStyle, addBorderFlag, borderStyle, fontSize, numberFormat, null);
	}

	/**
	 * instance jxl style format
	 * @param classType
	 * @param fontColor
	 * @param backgroundColor
	 * @param vStyle
	 * @param cStyle
	 * @param addBorderFlag
	 * @param fontSize
	 * @param numberFormat
	 * @param underLine
	 * @return WritableCellFormat
	 * @throws Throwable
	 */
	@SuppressWarnings("rawtypes")
	public static WritableCellFormat processStyle(Class classType,
			Colour fontColor, Integer backgroundColor,
			VerticalAlignment vStyle, Alignment cStyle, boolean addBorderFlag,
			Border borderStyle, Integer fontSize, String numberFormat,
			jxl.format.UnderlineStyle underLine) throws Throwable {
		WritableCellFormat returnVal = null;
		
		if (WritableFont.class.equals(classType)) {
			returnVal = new WritableCellFormat(new WritableFont(
				WritableFont.createFont("細明體"), 
				(fontSize != null ? fontSize : 12),
				jxl.write.WritableFont.NO_BOLD, 
				false,
				(underLine != null ? underLine : jxl.format.UnderlineStyle.NO_UNDERLINE),
				(fontColor != null ? fontColor : Colour.BLACK))
			);
		} else if (NumberFormat.class.equals(classType)) {
			returnVal = new WritableCellFormat(new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "#,##0_"));
		} else if (NumberFormats.class.equals(classType)) {
			returnVal = new WritableCellFormat(new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00"));
		} else if (Number.class.equals(classType)) {
			returnVal = new WritableCellFormat(new NumberFormat(StringUtils.isNotBlank(numberFormat) ? numberFormat : "##0.00%"));
		}

		if (returnVal != null) {
			if (backgroundColor != null) {
				returnVal.setBackground(Colour.getInternalColour(backgroundColor));
			}
			returnVal.setVerticalAlignment(vStyle != null ? vStyle : VerticalAlignment.CENTRE);
			returnVal.setAlignment(cStyle != null ? cStyle : Alignment.CENTRE);
			returnVal.setFont(
				new WritableFont(WritableFont.createFont("細明體"),
				(fontSize != null ? fontSize : 12),
				jxl.write.WritableFont.NO_BOLD, 
				false,
				(underLine != null ? underLine : jxl.format.UnderlineStyle.NO_UNDERLINE),
				(fontColor != null ? fontColor : Colour.BLACK))
			);
			if (addBorderFlag) {
				returnVal.setBorder((borderStyle != null ? borderStyle : Border.ALL), jxl.format.BorderLineStyle.THIN);
			}
		}
		return returnVal;
	}

	/**
	 * formatNullString : 傳入之字串若為空值時,則回傳空字串
	 * @param value : String
	 * @return String
	 * @throws Throwable
	 */
	public static String formatNullString(String value) throws Throwable {
		if (StringUtils.isBlank(value)) {
			return "";
		}
		return value;
	}

	/**
	 * formatNullString : 傳入之數值若為空值時,則回傳空字串
	 * @param value : Integer
	 * @return String
	 * @throws Throwable
	 */
	public static String formatNullString(Integer value) throws Throwable {
		if (value == null) {
			return "";
		}
		return value + "";
	}

	/**
	 * formatBreakNullString : 傳入之數值若為空值或0時,則回傳空字串
	 * @param value : Integer
	 * @return String
	 * @throws Throwable
	 */
	public static String formatBreakNullString(Integer value) throws Throwable {
		if (value == null) {
			return "";
		}
		if (value.equals(0)) {
			return "";
		}
		return value + "";
	}

	/**
	 * formatNullDouble : 傳入之數值(Integer)若為0時,則回傳0.0d,反之,則回傳double型態之數值
	 * @param value : Integer
	 * @return double
	 * @throws Throwable
	 */
	public static double formatNullDouble(Integer value) throws Throwable {
		if (value == null) {
			return 0.0d;
		}
		return value.doubleValue();
	}

	/**
	 * formatNullDouble : 傳入之數值(Long)若為0時,則回傳0.0d,反之,則回傳double型態之數值
	 * @param value : Long
	 * @return double
	 * @throws Throwable
	 */
	public static double formatNullDouble(Long value) throws Throwable {
		if (value == null) {
			return 0.0d;
		}
		return value.doubleValue();
	}

	/**
	 * formatNullDouble : 傳入之數值(Integer)若為空值時,則回傳0.0d,反之,則回傳Math.round(value.doubleValue()*demic)/demic之數值
	 * @param value : Integer
	 * @param demic : demic
	 * @return double
	 * @throws Throwable
	 */
	public static double formatNullDouble(Integer value, Integer demic)
			throws Throwable {
		if (value == null) {
			return 0.0d;
		}
		return Math.round(value.doubleValue() * demic) / demic;
	}

	public static double formatNullDouble(Double value, Double demic)
			throws Throwable {
		if (value == null) {
			return 0.0d;
		}
		return Math.round(value.doubleValue() * demic) / demic;
	}

	/**
	 * formatNullDouble : 傳入之數值(Float)若為空值時,則回傳0.0d,反之,則回傳Math.round(value.doubleValue())之數值
	 * @param value : Float
	 * @return double
	 * @throws Throwable
	 */
	public static double formatNullDouble(Float value) throws Throwable {
		if (value == null) {
			return 0.0d;
		}
		return Math.round(value.doubleValue());
	}

	public static double formatNullDouble(Double value) throws Throwable {
		if (value == null) {
			return 0.0d;
		}
		return Math.round(value.doubleValue());
	}

	/**
	 * formatNullDouble : 傳入之數值(Float)若為空值時,則回傳0.0d,反之,則回傳Math.round(value.doubleValue())之數值
	 * @param value : Float
	 * @return double
	 * @throws Throwable
	 */
	public static double caseNullDouble(Double value) throws Throwable {
		if (value == null) {
			return 0.0d;
		}
		return Math.round(value);
	}

	/**
	 * formatNullDouble : : 傳入之數值(Float)若為空值時,則回傳0.0d,反之,則回傳Math.round(value.doubleValue()*demic)/demic之數值
	 * @param value : Float
	 * @param demic : double
	 * @return double
	 * @throws Throwable
	 */
	public static double formatNullDouble(Float value, double demic)
			throws Throwable {
		if (value == null) {
			return 0.0d;
		}
		return Math.round(value.doubleValue() * demic) / demic;
	}

	/**
	 * encode ISO8859-1 TO UTF-8
	 * @param value
	 * @return string
	 * @throws Throwable
	 */
	public static String changeEncode(String value) throws Throwable {
		boolean returnFlag = Boolean.FALSE;
		if (value == null) {
			return "";
		}
		if (returnFlag) {
			return new String(value.getBytes("ISO8859-1"), "UTF-8");
		} else {
			return value;
		}
	}

	/**
	 * storeMap轉字串
	 * @param channelId
	 * @return
	 * @throws Exception
	 */
	public static String getChannelIdString(Map<String, ArrayList<String>> channelId, String channelIdString, String storeIdString) throws Exception {
		StringBuffer sqlString = new StringBuffer();
		if (channelId != null && channelId.size() > 0) {
			sqlString.append(" AND ( ");
			boolean firstRow = Boolean.FALSE;
			boolean firstRow1 = Boolean.FALSE;
			for (String key : channelId.keySet()) {
				sqlString
					.append(firstRow ? " OR " : "")
					.append("( " + channelIdString + " ='" + key + "' AND ( ");
				firstRow1 = Boolean.FALSE;
				for (String storeKey : channelId.get(key)) {
					sqlString
						.append(firstRow1 ? " OR " : "")
						.append(" " + storeIdString + " = '" + storeKey + "' ");
					firstRow1 = Boolean.TRUE;
				}
				sqlString.append(" ) ) ");
				firstRow = Boolean.TRUE;
			}
			sqlString.append(" ) ");
		}
		return sqlString.toString();
	}

	/**
	 * process channelMap
	 * @param storeIdArray
	 * @return
	 * @throws Throwable
	 */
	public static Map<String, ArrayList<String>> getChannelMap(String[] storeIdArray) throws Throwable {
		String channelId = "";
		String storeId = "";
		String[] storeTemp = null;
		Map<String, ArrayList<String>> channelMap = new TreeMap<String, ArrayList<String>>();
		ArrayList<String> storeList = null;
		if (storeIdArray != null && storeIdArray.length > 0) {
			try{
				for (String storeString : storeIdArray) {
					storeTemp = storeString.split(SPLIT_SEQU1);
					channelId = StringUtils.isNotBlank(storeTemp[1]) ? storeTemp[1].trim() : ""; // channelId
					storeId = StringUtils.isNotBlank(storeTemp[3]) ? storeTemp[3].trim() : ""; // storeId
					if (channelMap.containsKey(channelId) == false) {
						storeList = new ArrayList<String>();
						channelMap.put(channelId, storeList);
					} else {
						storeList = channelMap.get(channelId);
					}
					storeList.add(storeId);
				}
			}catch(java.lang.ArrayIndexOutOfBoundsException e){
				if( storeIdArray != null )
					 log.error(com.rfep.base.UtilString.uS001(storeIdArray), e);
				if( storeTemp != null ){
					log.error(com.rfep.base.UtilString.uS001(storeTemp), e);
					throw new Exception("參數陣列不正確。"+com.rfep.base.UtilString.uS001(storeTemp));
				}else{
				    throw new Exception("參數陣列不正確。");
				}
			}
		}
		return channelMap;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void sendExcel(JasperPrint jasperPrint, HttpServletResponse response, String fileName, String contentDisposition, Map parameterMap) throws Exception{
		ByteArrayOutputStream xlsOutStream = new ByteArrayOutputStream();
		FileOutputStream out = null;
		try {
			JExcelApiExporter exporter = new JExcelApiExporter();
			
			exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
			exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, xlsOutStream);
			exporter.exportReport();
			byte bytes[] = xlsOutStream.toByteArray();
			
			String reportName = fileName;
			if (fileName.length() > 9)
				reportName = fileName.substring(0, 9);
			reportName = reportName + ".xls";
			String fileNameUTF8 = "=?UTF-8?B?" + java.util.Base64.getEncoder().encodeToString(reportName.getBytes()) + "?=";
			File file = new File(fileNameUTF8);
			out = new FileOutputStream(file);
			out.write(bytes, 0, bytes.length);
			
			
			List attachFileList = new ArrayList() ;
			attachFileList.add(file) ;
			String subject = fileName; //parameterMap.get("subject").toString();
			String email = parameterMap.get("email").toString();
			String userName = parameterMap.get("userName").toString();
			
			MailService.sendMessage("", subject, email, userName, attachFileList) ;
		} catch (Exception ex) {
			log.error("寄送Excel檔發生錯誤:" + ex.getMessage(), ex);
			throw ex;
		} finally{
			try {
				if(xlsOutStream != null){
					xlsOutStream.flush();
					xlsOutStream.close();
				}
				if(out != null){
					out.flush();
					out.close();
				}
			} catch (IOException e) {
				log.error(e.getMessage(), e);
			}
		}
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void sendPdf(JasperPrint jasperPrint, HttpServletResponse response, String fileName, String contentDisposition, Map parameterMap) throws Exception{
		ByteArrayOutputStream pdfOutStream = new ByteArrayOutputStream();
		FileOutputStream out = null;
		try {
			JRPdfExporter exporter = new JRPdfExporter();
			
			exporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
			exporter.setParameter(JRExporterParameter.OUTPUT_STREAM, pdfOutStream);
			exporter.exportReport();
			byte bytes[] = pdfOutStream.toByteArray();
			
			String reportName = fileName;
			if (fileName.length() > 9)
				reportName = fileName.substring(0, 9);
			reportName = reportName + ".pdf";
			String fileNameUTF8 = "=?UTF-8?B?" + java.util.Base64.getEncoder().encodeToString(reportName.getBytes()) + "?=";		
			File file = new File(fileNameUTF8);
			out = new FileOutputStream(file);
			out.write(bytes, 0, bytes.length);
			
			List attachFileList = new ArrayList() ;
			attachFileList.add(file) ;
			String subject = fileName; //parameterMap.get("subject").toString();
			String email = parameterMap.get("email").toString();
			String userName = parameterMap.get("userName").toString();
			
			MailService.sendMessage("", subject, email, userName, attachFileList) ;
			
		} catch (Exception ex) {
			log.error("寄送Excel檔發生錯誤:" + ex.getMessage(), ex);
			throw ex;
		} finally{
			try {
				if(pdfOutStream != null){
					pdfOutStream.flush();
					pdfOutStream.close();
				}
				if(out != null){
					out.flush();
					out.close();
				}
				
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
		}
	}
}