package com.gccs.util.report;

import jxl.format.Alignment;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.format.Colour;
import jxl.write.NumberFormat;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;


public class JxlCellStyle {
	
	private WritableCellFormat styleHead;
	private WritableCellFormat styleNormal;
	private WritableCellFormat styleNormalLeft;
	private WritableCellFormat styleColHead;
	private WritableCellFormat normalCenter;
	private WritableCellFormat normal;
	private WritableCellFormat normalNumber;
	private WritableCellFormat normalNumberRed;
	private WritableCellFormat normal42;
	private WritableCellFormat normalPercentNumber;
	
	private WritableCellFormat normalCenter_L;
	private WritableCellFormat normalCenter_R;
	private WritableCellFormat normalCenter_B;
	private WritableCellFormat normalCenter_T;
	private WritableCellFormat normalCenter_B_D;

	public JxlCellStyle(){
		try{
			this.styleHead = ReportUtils.processStyle(WritableFont.class, null, null, null, null, false,null,16, null);
			this.styleNormal = ReportUtils.processStyle(WritableFont.class, null, null, null, null, false,null,null, null);
			this.styleNormalLeft = ReportUtils.processStyle(WritableFont.class, null, null, null, Alignment.LEFT, false,null,null, null);	
			this.styleColHead = ReportUtils.processStyle(WritableFont.class, null, 31, null, null, true,null,null, null);
			styleColHead.setWrap(true);		
			this.normalCenter = ReportUtils.processStyle(WritableFont.class, null, null, null,null, true,null,12,null);
			this.normal = ReportUtils.processStyle(WritableFont.class, null, null, null, Alignment.LEFT, true,null,12,null);
			normal.setWrap(true);	
			this.normalNumber = ReportUtils.processStyle(NumberFormat.class, null, null, null, Alignment.RIGHT, true,null,12, null);
			this.normalNumberRed = ReportUtils.processStyle(NumberFormat.class, Colour.RED, null, null, Alignment.RIGHT, true,null,12, null);
			this.normal42 = ReportUtils.processStyle(WritableFont.class, null, 42, null, null, true,null,12,null);
			this.normalPercentNumber = ReportUtils.processStyle(Number.class, null, null, null, Alignment.RIGHT, true,null,12, null);
			normal42.setWrap(true);	
			this.normalCenter_L = ReportUtils.processStyle(WritableFont.class, null, null, null,null, false,null,12,null);
			this.normalCenter_L.setBorder(Border.LEFT,BorderLineStyle.THIN);
			this.normalCenter_R = ReportUtils.processStyle(WritableFont.class, null, null, null,null, false,null,12,null);
			this.normalCenter_R.setBorder(Border.RIGHT,BorderLineStyle.THIN);
			this.normalCenter_B = ReportUtils.processStyle(WritableFont.class, null, null, null,null, false,null,12,null);
			this.normalCenter_B.setBorder(Border.BOTTOM,BorderLineStyle.THIN);
			this.normalCenter_T = ReportUtils.processStyle(WritableFont.class, null, null, null,null, false,null,12,null);
			this.normalCenter_T.setBorder(Border.TOP,BorderLineStyle.THIN);
			this.normalCenter_B_D = ReportUtils.processStyle(WritableFont.class, null, null, null,null, false,null,12,null);
			this.normalCenter_B_D.setBorder(Border.BOTTOM,BorderLineStyle.DASH_DOT_DOT);		
		}catch(Throwable t){
			t.printStackTrace();
		}
	}
	
	public WritableCellFormat getNormalNumberRed() {
		return normalNumberRed;
	}

	public void setNormalNumberRed(WritableCellFormat normalNumberRed) {
		this.normalNumberRed = normalNumberRed;
	}

	public WritableCellFormat getNormalPercentNumber() {
		return normalPercentNumber;
	}

	public void setNormalPercentNumber(WritableCellFormat normalPercentNumber) {
		this.normalPercentNumber = normalPercentNumber;
	}

	public WritableCellFormat getStyleHead() {
		return styleHead;
	}

	public void setStyleHead(WritableCellFormat styleHead) {
		this.styleHead = styleHead;
	}

	public WritableCellFormat getStyleNormal() {
		return styleNormal;
	}

	public void setStyleNormal(WritableCellFormat styleNormal) {
		this.styleNormal = styleNormal;
	}

	public WritableCellFormat getStyleNormalLeft() {
		return styleNormalLeft;
	}

	public void setStyleNormalLeft(WritableCellFormat styleNormalLeft) {
		this.styleNormalLeft = styleNormalLeft;
	}

	public WritableCellFormat getStyleColHead() {
		return styleColHead;
	}

	public void setStyleColHead(WritableCellFormat styleColHead) {
		this.styleColHead = styleColHead;
	}

	public WritableCellFormat getNormalCenter() {
		return normalCenter;
	}

	public void setNormalCenter(WritableCellFormat normalCenter) {
		this.normalCenter = normalCenter;
	}

	public WritableCellFormat getNormal() {
		return normal;
	}

	public void setNormal(WritableCellFormat normal) {
		this.normal = normal;
	}

	public WritableCellFormat getNormalNumber() {
		return normalNumber;
	}

	public void setNormalNumber(WritableCellFormat normalNumber) {
		this.normalNumber = normalNumber;
	}

	public WritableCellFormat getNormal42() {
		return normal42;
	}

	public void setNormal42(WritableCellFormat normal42) {
		this.normal42 = normal42;
	}
	
	public static String formatMoney(double value) {
		return java.text.NumberFormat.getInstance().format(value);
	}

	public WritableCellFormat getNormalCenter_L() {
		return normalCenter_L;
	}

	public void setNormalCenter_L(WritableCellFormat normalCenterL) {
		normalCenter_L = normalCenterL;
	}

	public WritableCellFormat getNormalCenter_R() {
		return normalCenter_R;
	}

	public void setNormalCenter_R(WritableCellFormat normalCenterR) {
		normalCenter_R = normalCenterR;
	}

	public WritableCellFormat getNormalCenter_B() {
		return normalCenter_B;
	}

	public void setNormalCenter_B(WritableCellFormat normalCenterB) {
		normalCenter_B = normalCenterB;
	}

	public WritableCellFormat getNormalCenter_T() {
		return normalCenter_T;
	}

	public void setNormalCenter_T(WritableCellFormat normalCenterT) {
		normalCenter_T = normalCenterT;
	}

	public WritableCellFormat getNormalCenter_B_D() {
		return normalCenter_B_D;
	}

	public void setNormalCenter_B_D(WritableCellFormat normalCenterBD) {
		normalCenter_B_D = normalCenterBD;
	}
	
	
}
