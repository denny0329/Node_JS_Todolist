package com.gccs.util.report;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.write.WritableWorkbook;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

/**
 * PrintVo
 * @author JL
 */
public  class PrintVo{
	
	private static final Logger logger = LogManager.getLogger(PrintVo.class);
	
	private OutputStream outputStream;
	
	private ByteArrayOutputStream baos;
	
	private WritableWorkbook workbook;
	
	private HttpServletResponse response;
	
	private String fileName;
	
	
	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public WritableWorkbook getWorkbook() {
		return workbook;
	}

	public void setWorkbook(WritableWorkbook workbook) {
		this.workbook = workbook;
	}

	public PrintVo(HttpServletResponse response,HttpServletRequest request,String fileName,WorkbookSettings setting)throws Exception{
		response.reset();
		response.setContentType("application/vnd.ms-excel");
		String fileNameUTF8 = "";
		if (fileName==null)
			fileNameUTF8 = "Report"+Calendar.getInstance().getTimeInMillis() + ".xls";
		else 
			fileNameUTF8 = java.net.URLEncoder.encode(fileName, "UTF-8") + ".xls";
		
		if(request.getHeader("User-Agent").indexOf("MSIE") != -1){
			response.setHeader("Content-disposition", "attachment; filename*=utf-8''" + fileNameUTF8);
			//response.setHeader("Content-disposition", "attachment; filename=\"" + (fileName!=null? new String(fileName.getBytes("big5"),"ISO8859-1")+".xls":"Report"+Calendar.getInstance().getTimeInMillis()+"") + "\"");			
			logger.info("IE");
		}else{
			response.setHeader("Content-disposition", "attachment; filename*=utf-8''" + fileNameUTF8);
			//response.setHeader("Content-disposition", "attachment; filename=\"" + (fileName!=null? new String(fileName.getBytes(),"ISO8859-1")+".xls":"Report"+(Calendar.getInstance().getTimeInMillis()+"")) + "\"");
			logger.info("Mozilla");
		}
		this.response = response;
		this.fileName = fileName;
		workbook = Workbook.createWorkbook(outputStream,setting);
	}
	public PrintVo(HttpServletResponse response,HttpServletRequest request,String fileName)throws Exception{
		response.reset();
		response.setContentType("application/vnd.ms-excel");
		String fileNameUTF8 = "";
		if (fileName==null)
			fileNameUTF8 = "Report"+Calendar.getInstance().getTimeInMillis() + ".xls";
		else 
			fileNameUTF8 = java.net.URLEncoder.encode(fileName, "UTF-8") + ".xls";
		if(request.getHeader("User-Agent").indexOf("MSIE") != -1){
			response.setHeader("Content-disposition", "attachment; filename*=utf-8''" + fileNameUTF8);
			//response.setHeader("Content-disposition", "attachment; filename=\"" + (fileName!=null? new String(fileName.getBytes("big5"),"ISO8859-1"):"Report"+Calendar.getInstance().getTimeInMillis()+"")+".xls" + "\"");
			logger.info("IE");
		}else{
			response.setHeader("Content-disposition", "attachment; filename*=utf-8''" + fileNameUTF8);
			//response.setHeader("Content-disposition", "attachment; filename=\"" + (fileName!=null? new String(fileName.getBytes(),"ISO8859-1"):"Report"+Calendar.getInstance().getTimeInMillis()+"")+".xls" + "\"");
			logger.info("Mozilla");
		}
		this.response = response;
		this.fileName = fileName;
		this.outputStream = response.getOutputStream();
		workbook = Workbook.createWorkbook(outputStream);
	}
	
	public PrintVo(String fileName)throws Exception{
		this.fileName = fileName;
		this.baos = new ByteArrayOutputStream(); 
		this.workbook = Workbook.createWorkbook(baos);
		this.outputStream = new FileOutputStream(new File(fileName));
	}
	
	
	public void executeExcel()throws Exception{
		PrintWriter out = null;
		try {
			logger.info("報表名稱:" + fileName);
			 if (getWorkbook()!=null){
				 workbook.write();
				 workbook.close(); 
			 }
		} catch (Exception e) {
			e.printStackTrace();
			out = response.getWriter();
			out.println("<html>");
			out.println("\t<body>");
			out.println("\t\t<br /><br />");
			out.println("\t\t無法產生報表");
			out.println("\t\t<br /><br />");
			out.println("\t\t錯誤訊息 ==> " + e.getLocalizedMessage());
			out.println("\t\t<br />");
			out.println("\t\t錯誤原因 ==> " + e.getCause());
			out.println("\t</body>");
			out.println("</html>");
		} finally {
			outputStream.flush();
			outputStream.close();
		}			
	}
	
	public void executeExcelFile()throws Exception{
		PrintWriter out = null;
		try {
			logger.info("報表名稱:" + fileName);
			 if (getWorkbook()!=null){
				 workbook.write();
				 workbook.close(); 
			 }
			baos.writeTo(outputStream);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e);
		} finally {
			outputStream.flush();
			outputStream.close();
			baos.close();
		}			
	}	
	
}

