/**
 * @(#)SelectItem.java 2014/09/12
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.gccs.util.web;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.bs.model.BsCode;
import com.bnq.bs.model.BsTitle;
import com.bnq.cs.pm.service.IMmWebMasterConfigService;
import com.bnq.sc.model.ScSysuser;
import com.bnq.util.AppContext;
import com.bnq.util.StringId;
import com.bnq.util.cache.BsCodeDefinition;
import com.bnq.util.cache.BsTitleDefinition;
import com.gccs.bs.dao.hibernate.BsBizDeptDao;
import com.gccs.bs.dao.hibernate.BsManagerDao;
import com.gccs.bs.model.BsBizDept;
import com.gccs.bs.model.BsCard;
import com.gccs.bs.model.BsChannel;
import com.gccs.bs.model.BsCompany;
import com.gccs.bs.model.BsSalesSource;
import com.gccs.bs.model.BsStaff;
import com.gccs.bs.model.BsStore;
import com.gccs.bs.model.BsWorkType;
import com.gccs.marketing.IMarketingService;
import com.gccs.marketing.model.condition.DiscountCondition;
import com.gccs.marketing.model.vo.DiscountVo;
import com.gccs.marketing.util.DiscountSelectItem;
import com.gccs.marketing.util.MarketingGlossary;
import com.gccs.member.service.IMemberService;
import com.gccs.util.cache.BsCardDefinition;
import com.gccs.util.cache.BsChannelDefinition;
import com.gccs.util.cache.BsCompanyDefinition;
import com.gccs.util.cache.BsSalesSourceDefinition;
import com.gccs.util.cache.BsStoreDefinition;
import com.gccs.util.cache.BsWorktypeDefinition;
import com.rfep.bs.model.StoreSystemInfo;
import com.rfep.util.StoreInfoUtil;
import com.rfep.util.cache.StoreSystemInfoDefinition;

/**
 * <b></b>
 * @author neo
 * @Date: 2009/12/22 下午 12:17:45
 * @Project Name: epos_Source
 */
@SuppressWarnings("unchecked")
public class SelectItem {

	private static final Logger log = LogManager.getLogger(SelectItem.class);

	public static StringId _defaultSelect = new StringId("", "請選擇");
	public static StringId _none = new StringId("", "無資料");
	public static final String CLASS_CODE_BANK = "BANK";
	/** 紅利計算表識 */
	public static final String BONUS = "bonus";
	/** HISU 工資計算標識 */
	public static final String WAGE_BONUS = "wage_bonus";
	/** 酷卡計算標識 */
	public static final String COOL_CARD = "cool_card";
	/** 點數清算 */
	public static final String INACTIVE_BONUS = "inactive_bonus";
	/** 年度紅利點數結算 */
	public static final String BONUS_SUMMARY = "bonus_summary";
	/** 年度紅利點數清算 */
	public static final String BONUS_CLEAN = "bonus_clean";
	/** 年度紅利點數結算(先復原資料) */
	public static final String BONUS_SUMMARY_BACKUP = "bonus_summary";
	/** 年度紅利點數清算(先復原資料) */
	public static final String BONUS_CLEAN_BACKUP = "bonus_clean";
	/** 新增LINE會員綁定文字檔 */
	public static final String LINE_DAILY = "line";
	/** 所有程序 */
	public static final int allProcess = 0;
	/** 正常交易 */
	public static final int NormalProcess = 1;
	/** 正常作廢 */
	public static final int NormalCancelProcess = 2;
	/** 退貨交易 */
	public static final int RejectionProcess = 3;
	/** 退貨作廢 */
	public static final int RejectionCancelProcess = 4;
	/** 更新商務會員折扣 */
	public static final int ChangDiscountJob = 5;
	/** DecorSyncJob */
	public static final int ModifyDecorSyncJob = 6;
	/** 變動折扣處理 */
	public static final int ChangDiscountJobTriggerBean = 7;
	/** 異常卡處理 */
	public static final int ErrorCardJobTriggerBean = 8;
	/** 更新商務會員之應收帳款 */
	public static final int ArAmountJobTrigger = 9;
	/** 批次產生紅利點數總表 */
	public static final int BcBonusTemporalSum = 10; 
	/** VIP計算表識 */
	public static final String VIP = "vip";
	/** VIP正常交易 */
	public static final int VipNormalProcess = 24;
	/** VIP正常作廢 */
	public static final int VipNormalCancelProcess = 25;
	/** VIP退貨交易 */
	public static final int VipRejectionProcess = 26;
	/** VIP退貨作廢 */
	public static final int VipRejectionCancelProcess = 27;
	/** TR Plus VIP計算表識 */
	public static final String VIP_TRPLUS = "vip_tr_plus";
	/** VIP正常交易 */
	public static final int VipNormalProcess_TRPLUS = 39;
	/** VIP正常作廢 */
	public static final int VipNormalCancelProcess_TRPLUS = 40;
	/** VIP退貨交易 */
	public static final int VipRejectionProcess_TRPLUS = 41;
	/** VIP退貨作廢 */
	public static final int VipRejectionCancelProcess_TRPLUS = 42;
	/** 紅利批次手動執行作業 */
	public static final int BillingProcess = 28;
	/** 合營專櫃商品手動執行作業 */
	public static final int MtSkuDiscountProcess = 29;
	/** 首次消費日手動執行作業 */
	public static final int FirstPurchase = 38;
	/** 產出手機認證的異動檔文字檔 */
	public static final int PhoneRegLog = 82;
	/** 會員月紅利現金積點批次計算 */	
	public static final int BcBonusSummary = 43;
	/** 消費異常月報資料*/
	public static final int AbnormalConsumptionProcess = 35;
	/** 寄送email*/
	public static final int ProductServiceMailProcess = 36;
	/** 產生萬里通文字檔*/
	public static final int AmTxtProcess = 37;
	/** 企業卡及專業卡停卡作業*/
	public static final int CancelCard = 101;
	/** 計算累積消費金額 JOB*/
	public static final int CulmSaleAmt = 102;
	/**
	 * 月結天數<br>
	 * 記錄從SAP轉進來的「月結天數」資料
	 * @return
	 */
	public static List<StringId> getMonthlySettlementDayList() {
		return getCodeExplainByCoNo("PD", true);
	}

	/**
	 * OVERDUE CONTROL<br>
	 * 記錄從SAP轉進的「OVERDUE CONTROL」資料
	 * @return
	 */
	public static List<StringId> getOverdueControlList() {
		return getCodeExplainByCoNo("OD", true);
	}

	/**
	 * 幣別<br>
	 * 記錄從SAP轉進的「幣別」(currency)資料（例：001-新台幣）
	 * @return
	 */
	public static List<StringId> getCurrencyList() {
		return getCodeExplainByCoNo("CUR", true);
	}

	/**
	 * TAXCLASS：記錄「0＝零稅、1＝應稅、2＝外銷」等…資料
	 * @return
	 */
	public static List<StringId> getTaxclassList() {
		return getCodeExplainByCoNo("TAXCLASS", true);
	}

	public static List<StringId> getCodeExplainByCoNo(String codeNo, boolean _defaultFlag) {
		List<StringId> resultList = new ArrayList<StringId>();

		if (_defaultFlag)
			resultList.add(0, _defaultSelect);

		if (codeNo != null) {
			List<BsCode> reasonList = BsCodeDefinition.findAllByCodeClass(codeNo);
			if (reasonList != null) {
				for (Iterator<BsCode> iterator = reasonList.iterator(); iterator.hasNext();) {
					BsCode bsCode = iterator.next();
					StringId id = new StringId(bsCode.getId().getCodeNo(), bsCode.getCodeExplain());
					resultList.add(id);
				}
			}
		}
		return resultList;
	}

	public static List<StringId> getBigAreaList() {
		List<StringId> resultList = new ArrayList<StringId>();

		resultList.add(0, _defaultSelect);

		List<BsCode> reasonList = BsCodeDefinition.findAllByCodeClass("CY");
		if (reasonList != null) {
			for (Iterator<BsCode> iterator = reasonList.iterator(); iterator.hasNext();) {
				BsCode bsCode = iterator.next();
				StringId id = new StringId(bsCode.getId().getCodeNo(), bsCode.getCodeExplain());
				resultList.add(id);
			}
		}
		return resultList;
	}

	public static List<StringId> getSexList() {
		List<StringId> typeList = new ArrayList<StringId>();
		typeList.add(new StringId("0", "小姐"));
		typeList.add(new StringId("1", "先生 "));
		return typeList;
	}

	public static List<StringId> getMarriageTypeList() {
		List<StringId> typeList = new ArrayList<StringId>();
		typeList.add(new StringId("1", "已婚"));
		typeList.add(new StringId("2", "未婚"));
		typeList.add(new StringId("3", "未填"));
		return typeList;
	}

	public static List<StringId> getDiscTypeList() {
		List<StringId> typeList = new ArrayList<StringId>();
		typeList.add(new StringId("0", "0-DownMarfin"));
		typeList.add(new StringId("1", "1-CostMarkup"));
		typeList.add(new StringId("2", "2-Discounting"));
		return typeList;
	}

	@SuppressWarnings("rawtypes")
	public static List getPayTypeList(String accType) {
		List<StringId> typeList = new ArrayList<StringId>();
		if ("0".equals(accType)) {
			typeList.add(new StringId("0", "現結"));
		} else if ("1".equals(accType)) {
			typeList.add(new StringId("1", "月結"));
			typeList.add(new StringId("2", "現結+月結"));
		} else if ("3".equals(accType)) {
			typeList.add(new StringId("1", "月結"));
			typeList.add(new StringId("2", "現結+月結"));
		} else if ("X".equals(accType)) {
			typeList.add(new StringId("0", "現結"));
			typeList.add(new StringId("1", "月結"));
			typeList.add(new StringId("2", "現結+月結"));
		} else {
			typeList.add(new StringId("0", "現結"));
		}

		return typeList;
	}

	public static List<StringId> getNormalOrCancle() {
		List<StringId> typeList = new ArrayList<StringId>();
		typeList.add(new StringId("Y", "正常"));
		typeList.add(new StringId("N", "取消"));
		return typeList;
	}

	public static List<StringId> getConfirmList() {
		List<StringId> typeList = new ArrayList<StringId>();
		typeList.add(new StringId("1", "願意"));
		typeList.add(new StringId("0", "不願意"));
		typeList.add(new StringId("2", "每檔必寄"));
		return typeList;
	}

	public static List<StringId> getSellMessageList() {
		List<StringId> typeList = new ArrayList<StringId>();
		typeList.add(new StringId("0", "型錄/DM "));
		typeList.add(new StringId("1", "電子郵件(EDM)"));
		typeList.add(new StringId("2", "電話"));
		typeList.add(new StringId("3", "簡訊"));
		return typeList;
	}

	public static List<StringId> getCardTypeList() {
		List<StringId> typeList = new ArrayList<StringId>();
		IMarketingService marketingService = (IMarketingService) AppContext.getBean("mtService");
		DiscountCondition condition = new DiscountCondition();
		List<Integer> statusList = new ArrayList<Integer>();
		statusList.add(MarketingGlossary._status_activate);
		statusList.add(MarketingGlossary._status_passivate);
		condition.setStatusList(statusList);
		List<DiscountVo> list = new ArrayList<DiscountVo>();
		try {
			list = (List<DiscountVo>) marketingService.getDiscountList(condition, 0, 0, false).getResult();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}

		typeList.add(_defaultSelect);
		for (DiscountVo discount : list) {
			StringId id = new StringId(discount.getOid(), discount.getDiscountCardName());
			if (discount.getStatus() == MarketingGlossary._status_passivate) {
				id.setName("*" + discount.getDiscountCardName());
			}
			typeList.add(id);
		}
		return typeList;
	}
	
	public static List<StringId> getBusinessCardTypeList() {
		List<StringId> typeList = new ArrayList<>();
		IMarketingService marketingService = (IMarketingService) AppContext.getBean("mtService");
		DiscountCondition condition = new DiscountCondition();
		condition.setStatus(1);
		condition.setCardType("1");
		List<DiscountVo> list = new ArrayList<>();
		try {
			list = (List<DiscountVo>) marketingService.getDiscountList(condition, 0, 0, false).getResult();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		
		typeList.add(_defaultSelect);
		for (DiscountVo discount : list) {
			StringId id = new StringId(discount.getOid(), discount.getDiscountCardName());
			typeList.add(id);
		}
		return typeList;
	}

	public static List<StringId> getBsCardNameList() {
		List<StringId> typeList = new ArrayList<StringId>();

		List<BsCard> reasonList = BsCardDefinition.findAllCard();
		if (reasonList != null) {
			typeList.add(_defaultSelect);
			for (Iterator<BsCard> iterator = reasonList.iterator(); iterator.hasNext();) {
				BsCard bsCard = iterator.next();
				StringId id = new StringId(bsCard.getCardId(), bsCard.getCardName());
				typeList.add(id);
			}
		} else {
			typeList.add(0, _none);
			return typeList;
		}

		return typeList;
	}

	public static List<StringId> getYesOrNoCondition() {
		List<StringId> typeList = new ArrayList<StringId>();

		typeList.add(new StringId("", "全部"));
		typeList.add(new StringId("0", "否"));
		typeList.add(new StringId("1", "是"));

		return typeList;
	}

	public static List<StringId> getYesOrNo() {
		List<StringId> typeList = new ArrayList<StringId>();
		typeList.add(new StringId("0", "否"));
		typeList.add(new StringId("1", "是"));

		return typeList;
	}

	public static List<StringId> getActiveEnable() {
		List<StringId> typeList = new ArrayList<StringId>();
		typeList.add(new StringId("0", "是"));
		typeList.add(new StringId("1", "否"));

		return typeList;
	}

	public static List<StringId> getMemberStatus() {
		List<StringId> typeList = new ArrayList<StringId>();
		typeList.add(new StringId("0", "停用"));
		typeList.add(new StringId("1", "正常"));
		typeList.add(new StringId("2", "異常"));
		typeList.add(new StringId("9", "刪除"));

		return typeList;
	}

	public static List<StringId> geteEducationType() {
		List<StringId> typeList = new ArrayList<StringId>();
		typeList.add(new StringId("1", "博士"));
		typeList.add(new StringId("2", "碩士"));
		typeList.add(new StringId("3", "學士"));
		typeList.add(new StringId("4", "大專"));
		typeList.add(new StringId("5", "高中"));
		typeList.add(new StringId("6", "國中"));
		typeList.add(new StringId("7", "小學"));
		typeList.add(new StringId("8", "無"));

		return typeList;
	}

	public static List<StringId> getAccType() {
		List<StringId> typeList = new ArrayList<StringId>();
		typeList.add(new StringId("0", "一般商務會員"));
		typeList.add(new StringId("1", "月結商務會員"));
		typeList.add(new StringId("2", "專業商務會員"));
		typeList.add(new StringId("3", "加盟商"));

		return typeList;
	}
	
	public static List<StringId> getAccTypeInCondition() {
		List<StringId> typeList = new ArrayList<>();
		typeList.add(new StringId("0", "一般商務會員"));
		typeList.add(new StringId("1", "月結商務會員"));
		
		return typeList;
	}

	public static List<StringId> getAccType(String selectType) {
		List<StringId> typeList = getAccType();
		if (StringUtils.isNotBlank(selectType)) {
			for (int i = 0; i < typeList.size(); i++) {
				if ("0".equals(selectType)) {
					if (typeList.get(i).getId().equals("0") == false) {
						typeList.remove(i);
						i--;
					}
				} else {
					if (typeList.get(i).getId().equals("0")) {
						typeList.remove(i);
						i--;
					}
				}
			}
		}
		return typeList;
	}

	public static List<StringId> getAccStatuw() {
		List<StringId> typeList = new ArrayList<StringId>();

		typeList.add(new StringId("1", "正常"));
		typeList.add(new StringId("2", "跳票"));
		typeList.add(new StringId("3", "應收帳款逾期"));
		typeList.add(new StringId("4", "結束營業或倒閉"));
		typeList.add(new StringId("9", "停用"));
		return typeList;
	}

	public static List<StringId> getAccStatus() {
		List<StringId> typeList = new ArrayList<StringId>();
		typeList.add(new StringId("1", "申請中"));
		typeList.add(new StringId("2", "審核中"));
		typeList.add(new StringId("3", "核發"));
		typeList.add(new StringId("9", "刪除"));
		typeList.add(new StringId("4", "限制採購"));
		typeList.add(new StringId("0", "停用"));
		return typeList;
	}

	public static List<StringId> getComType(boolean flag) {
		List<StringId> resultList = new ArrayList<StringId>();
		if (flag) {
			resultList.add(0, _defaultSelect);

		}
		List<BsCode> reasonList = BsCodeDefinition.findAllByCodeClass("COMTYPE");
		if (reasonList != null) {
			for (Iterator<BsCode> iterator = reasonList.iterator(); iterator.hasNext();) {
				BsCode bsCode = iterator.next();
				StringId id = new StringId(bsCode.getId().getCodeNo(), bsCode.getCodeExplain());
				resultList.add(id);
			}
		} else {
			resultList.add(0, _none);
			return resultList;
		}

		return resultList;
	}

	public static List<StringId> getAreaByparentCodeNo(String parentCodeNo, boolean flag, boolean flag2) {
		List<StringId> resultList = new ArrayList<StringId>();
		if (flag) {
			resultList.add(0, _defaultSelect);
			return resultList;
		}
		List<BsCode> reasonList = BsCodeDefinition.findAllByParentCodeClassAndParentCodeNo("AD", parentCodeNo);
		if (reasonList != null) {
			for (Iterator<BsCode> iterator = reasonList.iterator(); iterator.hasNext();) {
				BsCode bsCode = iterator.next();
				StringId id = null;
				//edit by van 判斷CodeStatus為1 時,則不加入List
				if (bsCode.getCodeStatus() == 1) {
					id = new StringId(bsCode.getId().getCodeNo(), bsCode.getCodeExplain());
					resultList.add(id);
				}

			}
		} else {
			resultList.add(0, _none);
			return resultList;
		}

		if (flag2)
			resultList.add(0, _defaultSelect);
		return resultList;
	}

	public static List<StringId> getBsChannelAll(boolean flag) {
		return getBsChannelAll(flag,"");
	}
	
	public static List<StringId> getBsChannelAll(boolean flag,String companyId) {
		List<StringId> resultList = new ArrayList<StringId>();

		List<BsChannel> channelList = BsChannelDefinition.findAllChannel();
		if (channelList != null) {
			for (Iterator<BsChannel> iterator = channelList.iterator(); iterator.hasNext();) {
				BsChannel bsChannel = iterator.next();
				//StringId id = new StringId(bsChannel.getChannelId(), bsChannel.getChannelId() + "-" + bsChannel.getChannelName1());
				//resultList.add(id);
				StringId id = null;
				if(StringUtils.isNotEmpty(companyId)){
					if(companyId.trim().equals(bsChannel.getCompanyId())){
						id = new StringId(bsChannel.getChannelId(), bsChannel.getChannelId() + "-" + bsChannel.getChannelName1());
						resultList.add(id);
					}
				}else{
					id = new StringId(bsChannel.getChannelId(), bsChannel.getChannelId() + "-" + bsChannel.getChannelName1());
					resultList.add(id);
				}
			}
		} else {
			resultList.add(0, _none);
			return resultList;
		}

		if (flag)
			resultList.add(0, _defaultSelect);
		return resultList;
	}
	
	

	public static List<StringId> getBsChannelByAuth(boolean flag, String byAuth, String submitCancelFlag, ScSysuser user) {
		List<StringId> resultList = new ArrayList<StringId>();
		try {
			List<BsChannel> channelList = user.getAuthChannel();

			if (!StringUtils.isEmpty(submitCancelFlag) && "true".equalsIgnoreCase(submitCancelFlag))
				byAuth = "";

			if (!StringUtils.isEmpty(byAuth) && "1".equalsIgnoreCase(byAuth)) {
				if (channelList != null) {
					for (Iterator<BsChannel> iterator = channelList.iterator(); iterator.hasNext();) {
						BsChannel bsChannel = iterator.next();
						StringId id = new StringId(bsChannel.getChannelId(), bsChannel.getChannelId() + "-"
								+ bsChannel.getChannelName1());
						resultList.add(id);
					}
				} else {
					resultList.add(0, _none);
					return resultList;
				}
			} else {
				return getBsChannelAll(flag);
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		if (flag)
			resultList.add(0, _defaultSelect);
		return resultList;
	}

	/**
	 * 取得Channel包含總公司和非實體通路
	 * @param flag
	 * @return
	 */
	public static List<StringId> getBsChannelAllIncludeHQ(boolean flag) {
		List<StringId> resultList = new ArrayList<StringId>();

		List<BsChannel> channelList = BsChannelDefinition.findAllChannelIncludeHQ();
		if (channelList != null) {
			for (Iterator<BsChannel> iterator = channelList.iterator(); iterator.hasNext();) {
				BsChannel bsChannel = iterator.next();
				StringId id = new StringId(bsChannel.getChannelId(), bsChannel.getChannelId() + "-" + bsChannel.getChannelName1());
				resultList.add(id);
			}
		} else {
			resultList.add(0, _none);
			return resultList;
		}

		if (flag)
			resultList.add(0, _defaultSelect);
		return resultList;
	}

	/**
	 * 取得Channel包含總公司但不包含非實體通路
	 * @param flag
	 * @return
	 */
	public static List<StringId> getBsChannelAllIncludeHQ2(boolean flag) {
		return getBsChannelAllIncludeHQ2(flag,"");
	}
	
	public static List<StringId> getBsChannelAllIncludeHQ2(boolean flag,String companyId) {
		List<StringId> resultList = new ArrayList<StringId>();

		List<BsChannel> channelList = BsChannelDefinition.findAllChannelIncludeHQ2();
		if (channelList != null) {
			for (Iterator<BsChannel> iterator = channelList.iterator(); iterator.hasNext();) {
				BsChannel bsChannel = iterator.next();
				StringId id = null;
				if(StringUtils.isNotEmpty(companyId)){
					if(companyId.trim().equals(bsChannel.getCompanyId())){
						id = new StringId(bsChannel.getChannelId(), bsChannel.getChannelId() + "-" + bsChannel.getChannelName1());
						resultList.add(id);
					}
				}else{
					id = new StringId(bsChannel.getChannelId(), bsChannel.getChannelId() + "-" + bsChannel.getChannelName1());
					resultList.add(id);
				}
			}
		} else {
			resultList.add(0, _none);
			return resultList;
		}

		if (flag)
			resultList.add(0, _defaultSelect);

		return resultList;
	}
	
	// 沒有請選擇的選項
	public static String getBsChannelAllIncludeHQ2NoDefault(boolean flag, String companyId) {
		String channelStr = "";
		List<BsChannel> channelList = BsChannelDefinition.findAllChannelIncludeHQ2();
		if (channelList != null) {
			for (Iterator<BsChannel> iterator = channelList.iterator(); iterator.hasNext();) {
				BsChannel bsChannel = iterator.next();
				if (StringUtils.isNotEmpty(companyId)) {
					if (companyId.trim().equals(bsChannel.getCompanyId())) {
						channelStr += bsChannel.getChannelId() + "," + bsChannel.getChannelId() + "-" + bsChannel.getChannelName1() + ".";
					}
				} else {
					channelStr += bsChannel.getChannelId() + "," + bsChannel.getChannelId() + "-" + bsChannel.getChannelName1() + ".";
				}
			}
		} else {
			return channelStr;
		}

		return channelStr;
	}

	public static List<StringId> getBsStoreByChannelId(String channelId, boolean flag) {
		List<StringId> result = new ArrayList<StringId>();

		List<BsStore> list = BsStoreDefinition.findBsStoreByChannelIdStoreType(channelId, new Integer(1)); //僅實體店

		if (list != null && list.size() > 0) {
			for (Iterator<BsStore> it = list.iterator(); it.hasNext();) {
				BsStore vo = it.next();
				StringId id = new StringId(vo.getId().getStoreId(), vo.getId().getStoreId() + "-" + vo.getStoreName1());
				result.add(id);
			}
		} else {
			if (!channelId.equals("HQ"))
				result.add(0, _none);
			return result;
		}

		if (flag) {
			result.add(0, _defaultSelect);
		}

		return result;
	}

	public static List<StringId> getBsStoreByChannelIdIdInclude99(String channelId, boolean flag) {
		List<StringId> result = new ArrayList<StringId>();
		if (StringUtils.isBlank(channelId)) {
			result.add(_none);
			return result;
		}
		List<BsStore> list = BsStoreDefinition.findBsStoreByChannelIdStoreTypeInclude99(channelId, new Integer(1)); //僅實體店

		if (list != null && list.size() > 0) {
			for (Iterator<BsStore> it = list.iterator(); it.hasNext();) {
				BsStore vo = it.next();
				StringId id = new StringId(vo.getId().getStoreId(), vo.getId().getStoreId() + "-" + vo.getStoreName1());
				result.add(id);
			}
			if (list.size() == 1) {
				flag = false;
			}
		} else {
			result.add(0, _none);
			return result;
		}

		if (flag) {
			result.add(0, _defaultSelect);
		}

		return result;
	}

	public static Map<String, String> BsStatusMap;
	public static Map<String, String> BsPhChannelMap;
	public static Map<String, String> BsCardTypeMap;
	public static Map<String, String> MmCommisionStatisMap;
	public static Map<String, String> EmailSendStatusMap;
	public static List<StringId> DefaultSelectList;
	static {
		BsStatusMap = new LinkedHashMap<String, String>();
		BsStatusMap.put("1", "正常");
		BsStatusMap.put("0", "停用");

		BsPhChannelMap = new LinkedHashMap<String, String>();
		BsPhChannelMap.put("1", "是");
		BsPhChannelMap.put("0", "否");

		BsCardTypeMap = new LinkedHashMap<String, String>();
		BsCardTypeMap.put("0", "0-一般卡");
		BsCardTypeMap.put("1", "1-商務卡");
		BsCardTypeMap.put("2", "2-員工卡");
		BsCardTypeMap.put("3", "3-親友卡");
		BsCardTypeMap.put("4", "4-集團卡");
		BsCardTypeMap.put("5", "5-臨時卡");
		BsCardTypeMap.put("6", "6-其它卡");
		BsCardTypeMap.put("7", "7-貴賓卡");

		MmCommisionStatisMap = new LinkedHashMap<String, String>();
		MmCommisionStatisMap.put("0", "0-建立");
		MmCommisionStatisMap.put("1", "1-生效");
		MmCommisionStatisMap.put("2", "2-失效");
		
		EmailSendStatusMap = new LinkedHashMap<String, String>();
		EmailSendStatusMap.put("", "請選擇");
		EmailSendStatusMap.put("Y", "Y - 發送");
		EmailSendStatusMap.put("N", "N - 不發");
		
		DefaultSelectList = new ArrayList<>();
		DefaultSelectList.add(new StringId("", "請選擇"));
	}

	public static String getCardTypeDesc(String cardType) {
		return (String) BsCardTypeMap.get(cardType);
	}
	
	public static List<StringId> getReceiveDM() {
		List<StringId> typeList = new ArrayList<StringId>();

		typeList.add(new StringId("1", "是"));
		typeList.add(new StringId("0", "否"));
		return typeList;
	}
	
	

	public static List<StringId> getDisTypeList() {
		List<StringId> typeList = new ArrayList<StringId>();
		typeList.add(new StringId("0", "Discounting Line"));
		typeList.add(new StringId("1", "Down Margin"));
		typeList.add(new StringId("2", "Cost Markup"));
		return typeList;
	}

	public static List<StringId> getTitleSelectList(String companyId) {
		List<BsTitle> dataList = BsTitleDefinition.getSelectTitleNameArrayString(companyId);
		List<StringId> resultList = new ArrayList<StringId>();
		resultList.add(0, _defaultSelect);
		if (dataList != null) {
			for (BsTitle vo : dataList) {
				resultList.add(new StringId(vo.getTitleId(), vo.getTitleId() + "-" + vo.getTitleName()));
			}
		}
		return resultList;
	}

	public static String getChannelOptionDefForUser(String userId) {
		String rtn = "";
		List<StringId> storeStaffList = getChannelOptinsForUser(userId, false);
		for (StringId staff : storeStaffList) {
			rtn = staff.getId();
		}
		return rtn;
	}

	public static String getStoreOptionDefForUser(String channelId, String userId, String companyId) {
		String rtn = "";
		List<StringId> storeStaffList = getStoreOptinsForStaff(companyId, userId, channelId, false);
		for (StringId staff : storeStaffList) {
			rtn = staff.getId();
		}
		return rtn;
	}

	/**
	 * 依使用者帳號取得[通路]下拉選項
	 * @param userId : 使用者帳號
	 * @param flag : Default [請選擇]
	 * @return
	 */
	public static List<StringId> getChannelOptinsForUser(String userId, boolean flag) {
		ScSysuser user = ((BsManagerDao) AppContext.getBean("bsManagerDao")).getScSysuerById(userId);
		if (user.getUserRead() == 2) { // all
			return getBsChannelAllIncludeHQ2(flag,user.getCompanyId());
		} else {
			return getChannelOptinsForStaff(user, flag);
		}
	}

	/**
	 * 依使用者登入機器 IP 與網址識別碼取得[所支援通路]下拉選項
	 * @param urlIdCode : 網址識別碼
	 * @return
	 */
	public static List<StringId> getChannelOpetionsForAp(String urlIdCode) {
		List<StringId> storeList = new ArrayList<StringId>();
		List<StoreSystemInfo> storeSysInfo;
		try {
			storeSysInfo = StoreInfoUtil.getCurrentStoreInfo();
			
			if (storeSysInfo == null) {
				Map<String, List<StoreSystemInfo>> storeSysInfoIpMap = StoreInfoUtil.getCurrentStoreInfoIpMap();			
				List<String> IpMapKey = new ArrayList<String>(storeSysInfoIpMap.keySet());
				if (IpMapKey.size() > 0)
					storeSysInfo = storeSysInfoIpMap.get(IpMapKey.get(0));			
			}
			
			if (storeSysInfo != null) {
				BsCompany bsCompany = BsCompanyDefinition.getBsCompanyByCode(urlIdCode);
				for (StoreSystemInfo storeInfo : storeSysInfo) {
					BsChannel bsChannel = BsChannelDefinition.getChannelByChannelId(storeInfo.getChannelId(), bsCompany.getCompanyId());
					if(bsChannel != null) {
						StringId _SId = new StringId();
						_SId.setId(bsChannel.getChannelId());
						_SId.setName(bsChannel.getChannelId() + "-" + bsChannel.getChannelName1());
						if (!storeList.contains(_SId)) {
							storeList.add(_SId);
						}
					}
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return storeList;
	}

	/**
	 * 依使用者登入機器IP取得[所支援所有店別]下拉選項(總店展開為個店別)
	 * @param userId : 使用者帳號
	 * @param channelId : 通路代碼
	 * @param flag : Default [請選擇]
	 * @return
	 */
	public static List<StringId> getStoreOptinsForApExpand() {
		List<StringId> storeList = new ArrayList<StringId>();
		List<StoreSystemInfo> storeSysInfo;
		try {
			storeSysInfo = StoreInfoUtil.getCurrentStoreInfo();
			if (storeSysInfo != null) {
				for (StoreSystemInfo storeInfo : storeSysInfo) {
					for (StringId _SId : getBsStoreByChannelId(storeInfo.getChannelId(), false)) {
						if (!storeList.contains(_SId)) {
							storeList.add(_SId);
						}
					}
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		if (storeList.size() > 0) {
			Collections.sort(storeList, new Comparator<StringId>() {
				public int compare(StringId emp1, StringId emp2) {
					return emp1.getId().compareTo(emp2.getId());

				}
			});
		} else {
			storeList.add(new StringId("", "以AP查無授權登入店別"));
		}
		return storeList;
	}

	/**
	 * 依使用者登入機器IP取得[所支援店別]下拉選項
	 * @param channelId 選擇的通路代碼
	 * @param urlIdCode 登入公司
	 * @return 所選通路的店別下拉選單；id: storeId, name: storeId + "-" + storeName1
	 */
	public static List<StringId> getStoreOptinsForAp(String channelId, String urlIdCode) {
		List<StringId> storeList = new ArrayList<StringId>();
		List<StoreSystemInfo> storeSysInfo;
		try {
			storeSysInfo = StoreInfoUtil.getCurrentStoreInfo();
			
			if (storeSysInfo == null) {
				Map<String, List<StoreSystemInfo>> storeSysInfoIpMap = StoreInfoUtil.getCurrentStoreInfoIpMap();			
				List<String> IpMapKey = new ArrayList<String>(storeSysInfoIpMap.keySet());

				if (IpMapKey.size() > 0)
					storeSysInfo = storeSysInfoIpMap.get(IpMapKey.get(0));

			}
			
			if (storeSysInfo != null) {
				String companyId = BsCompanyDefinition.getBsCompanyByCode(urlIdCode).getCompanyId();
				for (StoreSystemInfo storeInfo : storeSysInfo) {
					BsStore bsStore = BsStoreDefinition.getBsStoreByStoreNo(storeInfo.getStoreId(), companyId);
					if (bsStore != null) {
						if (channelId == null) {
							StringId _SId = new StringId(bsStore.getId().getStoreId(), bsStore.getId().getStoreId() + "-"
									+ bsStore.getStoreName1());
							if (!storeList.contains(_SId)) {
								storeList.add(_SId);
							}
						} else {
							if (bsStore.getId().getChannelId().equals(channelId)) {
								StringId _SId = new StringId(bsStore.getId().getStoreId(), bsStore.getId().getStoreId() + "-"
										+ bsStore.getStoreName1());
								if (!storeList.contains(_SId)) {
									storeList.add(_SId);
								}
							}
						}
					}
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		if (storeList.size() > 0) {
			Collections.sort(storeList, new Comparator<StringId>() {
				public int compare(StringId emp1, StringId emp2) {
					return emp1.getId().compareTo(emp2.getId());

				}
			});
		} else {
			storeList.add(new StringId("", "以AP查無授權登入店別"));
		}
		return storeList;
	}

	/**
	 * 依使用者帳號取得[店別]下拉選項
	 * @param userId : 使用者帳號
	 * @param channelId : 通路代碼
	 * @param flag : Default [請選擇]
	 * @return
	 */
	public static List<StringId> getStoreOptinsForUser(String userId, String channelId, boolean flag) {
		if (StringUtils.isBlank(channelId)) {
			List<StringId> result = new ArrayList<StringId>();
			result.add(0, _defaultSelect);
			return result;
		}
		ScSysuser user = ((BsManagerDao) AppContext.getBean("bsManagerDao")).getScSysuerById(userId);
		if (user.getUserRead() == 2) { // all
			return getBsStoreByChannelIdIdInclude99(channelId, flag);
		} else {
			BsChannel bsChannel = BsChannelDefinition.getChannelByChannelId(channelId);
			return getStoreOptinsForStaff(bsChannel.getCompanyId(), userId, channelId, flag);
		}
	}

	/**
	 * 依通路代碼與通路店別，取得營業課OID
	 * @param channelId
	 * @param storeId
	 * @return
	 */
	public static List<StringId> getDeptOptins(String channelId, String storeId) {
		if (StringUtils.isBlank(channelId) || StringUtils.isBlank(storeId)) {
			List<StringId> result = new ArrayList<StringId>();
			result.add(0, _defaultSelect);
			return result;
		}

		List<StringId> result = new ArrayList<StringId>();

		Map<String, Object> queryCondition = new HashMap<String, Object>();
		String[] deptTypes = new String[1];
		deptTypes[0] = "1";
		queryCondition.put("channelId", channelId);
		queryCondition.put("storeId", storeId);
		queryCondition.put("deptType", deptTypes);
		List<BsBizDept> list = ((BsBizDeptDao) AppContext.getBean("bsBizDeptDao")).findAllBsBizDeptByCannelIdAndStoreId(queryCondition);
		if (list != null && list.size() > 0) {
			Iterator<BsBizDept> itr = list.iterator();
			result.add(_defaultSelect);
			while (itr.hasNext()) {
				BsBizDept bsBizDept = (BsBizDept) itr.next();
				StringId id = new StringId(bsBizDept.getOid(), bsBizDept.getName());
				result.add(id);
			}
		} else {
			result.add(0, _none);
			return result;
		}
		return result;
	}

	/**
	 * 依通路代碼與通路店別，取得營業區OID
	 * @param channelId
	 * @param storeId
	 * @param deptOid
	 * @return
	 */
	public static List<StringId> getAreaOptins(String channelId, String storeId, String parentOid) {
		if (StringUtils.isBlank(channelId) || StringUtils.isBlank(storeId) || StringUtils.isBlank(parentOid)) {
			List<StringId> result = new ArrayList<StringId>();
			result.add(0, _defaultSelect);
			return result;
		}

		List<StringId> result = new ArrayList<StringId>();
		Map<String, Object> queryCondition = new HashMap<String, Object>();
		String[] deptTypes = new String[1];
		deptTypes[0] = "2";
		queryCondition.put("channelId", channelId);
		queryCondition.put("storeId", storeId);
		queryCondition.put("deptType", deptTypes);
		queryCondition.put("parentOid", parentOid);
		List<BsBizDept> list = ((BsBizDeptDao) AppContext.getBean("bsBizDeptDao")).findAllBsBizDeptByCannelIdAndStoreId(queryCondition);
		if (list != null && list.size() > 0) {
			Iterator<BsBizDept> itr = list.iterator();
			result.add(_defaultSelect);
			while (itr.hasNext()) {
				BsBizDept bsBizDept = (BsBizDept) itr.next();
				StringId id = new StringId(bsBizDept.getOid(), bsBizDept.getName());
				result.add(id);
			}
		} else {
			result.add(0, _none);
			return result;
		}

		return result;
	}

	/**
	 * 依使用者帳號權限取得[通路]下拉選項
	 * @param userId : 使用者帳號
	 * @param flag : Default [請選擇]
	 * @return
	 */
	private static List<StringId> getChannelOptinsForStaff(ScSysuser user, boolean flag) {
		List<StringId> result = new ArrayList<StringId>();
		List<Map<String, Object>> list = ((BsManagerDao) AppContext.getBean("bsManagerDao")).findBsStaffForUser(user.getUserId(),user.getCompanyId());

		if (list != null) {
			for (Map<String, Object> map : list) {
				StringId id = new StringId((String) map.get("ID"), (String) map.get("NAME"));
				result.add(id);
			}
		} else {
			result.add(0, _none);
			return result;
		}

		if (flag)
			result.add(0, _defaultSelect);

		return result;
	}

	/**
	 * 依使用者帳號權限取得通路下的[店別]下拉選項
	 * @param companyId : 公司別代碼
	 * @param userId : 使用者帳號
	 * @param channelId : 通路代碼
	 * @param flag : Default [請選擇]
	 * @return
	 */
	private static List<StringId> getStoreOptinsForStaff(String companyId, String userId, String channelId, boolean flag) {
		List<StringId> result = new ArrayList<StringId>();
		List<BsStaff> list = ((BsManagerDao) AppContext.getBean("bsManagerDao")).findBsStaffForUser(companyId, userId, channelId,
				null);
		if (list != null && list.size() > 0) {
			List<StringId> storeList = SelectItem.getBsStoreByChannelIdIdInclude99(channelId, false);

			for (Iterator<BsStaff> iterator = list.iterator(); iterator.hasNext();) {
				String storeId = iterator.next().getStoreId();
				for (StringId id : storeList) {
					if (storeId.equals(id.getId()))
						result.add(id);
				}
			}
			if (list.size() == 1) {
				flag = false;
			}
		} else {
			result.add(0, _none);
			return result;
		}
		if (flag)
			result.add(0, _defaultSelect);

		return result;
	}

	public static List<StringId> getDMReturnList() {
		List<StringId> typeList = new ArrayList<StringId>();
		typeList.add(new StringId("1", "是"));
		typeList.add(new StringId("0", "否"));
		return typeList;
	}

	public static List<StringId> getDiscountCardNameList(String cardTypes, boolean storeIssuable, boolean flag) {
		List<StringId> list = DiscountSelectItem.getDiscountCardNameList(cardTypes, storeIssuable);
		if (!flag && list.size() > 0)
			list.remove(0);
		return list;
	}

	public static List<StringId> getTrueFalseList() {
		List<StringId> typeList = new ArrayList<StringId>();
		typeList.add(new StringId("true", "是"));
		typeList.add(new StringId("false", "否"));
		return typeList;
	}

	public static List<StringId> getAllCardType() {
		List<StringId> cardTypeList = new ArrayList<StringId>();
		Set<String> keySet = BsCardTypeMap.keySet();
		for (Iterator<String> iter = keySet.iterator(); iter.hasNext();) {
			String key = (String) iter.next();
			String cardName = (String) BsCardTypeMap.get(key);
			StringId id = new StringId(key, cardName);
			cardTypeList.add(id);
		}
		return cardTypeList;
	}

	public static List<StringId> getBsSalesSourceAll(boolean flag) {
		List<StringId> result = new ArrayList<StringId>();
		List<BsSalesSource> list = BsSalesSourceDefinition.findAll();

		if (list != null) {
			for (Iterator<BsSalesSource> it = list.iterator(); it.hasNext();) {
				BsSalesSource vo = it.next();
				result.add(new StringId(vo.getTypeId(), vo.getTypeName()));
			}
		} else {
			result.add(0, _none);
			return result;
		}

		if (flag) {
			result.add(0, _defaultSelect);
		}

		return result;
	}

	public static List<StringId> getBsWorkType01All(boolean flag) {
		List<StringId> result = new ArrayList<StringId>();
		List<BsWorkType> list = BsWorktypeDefinition.findAllType01();
		BsWorkType vo = null;

		if (list != null) {
			for (Iterator<BsWorkType> it = list.iterator(); it.hasNext();) {
				vo = it.next();
				result.add(new StringId(vo.getWorkTypeId(), vo.getWorkTypeName()));
			}
		} else {
			result.add(0, _none);
			return result;
		}

		if (flag) {
			result.add(0, _defaultSelect);
		}

		return result;
	}

	public static List<StringId> getBsWorkType02All(String codeId, boolean flag) {
		List<StringId> result = new ArrayList<StringId>();
		List<BsWorkType> list = BsWorktypeDefinition.findAllType02(codeId);
		BsWorkType vo = null;

		if (list != null) {
			for (Iterator<BsWorkType> it = list.iterator(); it.hasNext();) {
				vo = it.next();
				result.add(new StringId(vo.getWorkTypeId(), vo.getWorkTypeName()));
			}
		} else {
			result.add(0, _none);
			return result;
		}

		if (flag) {
			result.add(0, _defaultSelect);
		}

		return result;
	}

	/**
	 * 取得銀行代號
	 * @return List
	 */
	public static List<StringId> getBankList() {
		List<BsCode> list = BsCodeDefinition.findAllByCodeClass(CLASS_CODE_BANK);
		List<StringId> temp = new ArrayList<StringId>();
		temp.add(_defaultSelect);
		Iterator<BsCode> iterator = list.iterator();
		while (iterator.hasNext()) {
			BsCode local = iterator.next();
			temp.add(new StringId(local.getId().getCodeNo(), local.getCodeExplain()));
		}
		return temp;
	}

	private static String getSelectItem(Object obj, String properties[], String delim) {
		try {
			StringBuffer result = new StringBuffer();
			for (String property : properties) {
				if (result.length() > 0) {
					result.append(delim);
				}
				result.append((String) PropertyUtils.getProperty(obj, property));
			}
			return result.toString();
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static <T> List<StringId> getSelectItems(List<T> list, String listKeys[], String listValues[], String delim) {
		List<StringId> result = new ArrayList<StringId>();
		for (T obj : list) {
			result.add(new StringId(getSelectItem(obj, listKeys, delim), getSelectItem(obj, listValues, delim)));
		}
		return result;
	}

	public static <T> List<StringId> getSelectItems(List<T> list, String listKeys[], String listValues[]) {
		return getSelectItems(list, listKeys, listValues, "#");
	}

	public static List<StringId> getPaymentTypes() {
		List<StringId> resultList = new ArrayList<StringId>();

		resultList.add(0, _defaultSelect);

		List<BsCode> reasonList = BsCodeDefinition.findAllByCodeClass("PY");
		if (reasonList != null) {
			for (Iterator<BsCode> iterator = reasonList.iterator(); iterator.hasNext();) {
				BsCode bsCode = iterator.next();
				StringId id = new StringId(bsCode.getId().getCodeNo(), bsCode.getCodeExplain());
				resultList.add(id);
			}
		}
		return resultList;
	}

	public static List<StringId> getTimePeriod() {
		List<StringId> result = new ArrayList<StringId>();
		result.add(new StringId("00", "00:00-00:59"));
		result.add(new StringId("01", "01:00-01:59"));
		result.add(new StringId("02", "02:00-02:59"));
		result.add(new StringId("03", "03:00-03:59"));
		result.add(new StringId("04", "04:00-04:59"));
		result.add(new StringId("05", "05:00-05:59"));
		result.add(new StringId("06", "06:00-06:59"));
		result.add(new StringId("07", "07:00-07:59"));
		result.add(new StringId("08", "08:00-08:59"));
		result.add(new StringId("09", "09:00-09:59"));
		result.add(new StringId("10", "10:00-10:59"));
		result.add(new StringId("11", "11:00-11:59"));
		result.add(new StringId("12", "12:00-12:59"));
		result.add(new StringId("13", "13:00-13:59"));
		result.add(new StringId("14", "14:00-14:59"));
		result.add(new StringId("15", "15:00-15:59"));
		result.add(new StringId("16", "16:00-16:59"));
		result.add(new StringId("17", "17:00-17:59"));
		result.add(new StringId("18", "18:00-18:59"));
		result.add(new StringId("19", "19:00-19:59"));
		result.add(new StringId("20", "20:00-20:59"));
		result.add(new StringId("21", "21:00-21:59"));
		result.add(new StringId("22", "22:00-22:59"));
		result.add(new StringId("23", "23:00-23:59"));
		return result;
	}

	/**
	 * 排班時用到的時間
	 * @return
	 */
	public static List<StringId> getScheduleTime() {
		List<StringId> result = new ArrayList<StringId>();
		result.add(_defaultSelect);
		result.add(new StringId("00:00", "00:00"));
		result.add(new StringId("00:30", "00:30"));
		result.add(new StringId("01:00", "01:00"));
		result.add(new StringId("01:30", "01:30"));
		result.add(new StringId("02:00", "02:00"));
		result.add(new StringId("02:30", "02:30"));
		result.add(new StringId("03:00", "03:00"));
		result.add(new StringId("03:30", "03:30"));
		result.add(new StringId("04:00", "04:00"));
		result.add(new StringId("04:30", "04:30"));
		result.add(new StringId("05:00", "05:00"));
		result.add(new StringId("05:30", "05:30"));
		result.add(new StringId("06:00", "06:00"));
		result.add(new StringId("06:30", "06:30"));
		result.add(new StringId("07:00", "07:00"));
		result.add(new StringId("07:30", "07:30"));
		result.add(new StringId("08:00", "08:00"));
		result.add(new StringId("08:30", "08:30"));
		result.add(new StringId("09:00", "09:00"));
		result.add(new StringId("09:30", "09:30"));
		result.add(new StringId("10:00", "10:00"));
		result.add(new StringId("10:30", "10:30"));
		result.add(new StringId("11:00", "11:00"));
		result.add(new StringId("11:30", "11:30"));
		result.add(new StringId("12:00", "12:00"));
		result.add(new StringId("12:30", "12:30"));
		result.add(new StringId("13:00", "13:00"));
		result.add(new StringId("13:30", "13:30"));
		result.add(new StringId("14:00", "14:00"));
		result.add(new StringId("14:30", "14:30"));
		result.add(new StringId("15:00", "15:00"));
		result.add(new StringId("15:30", "15:30"));
		result.add(new StringId("16:00", "16:00"));
		result.add(new StringId("16:30", "16:30"));
		result.add(new StringId("17:00", "17:00"));
		result.add(new StringId("17:30", "17:30"));
		result.add(new StringId("18:00", "18:00"));
		result.add(new StringId("18:30", "18:30"));
		result.add(new StringId("19:00", "19:00"));
		result.add(new StringId("19:30", "19:30"));
		result.add(new StringId("20:00", "20:00"));
		result.add(new StringId("20:30", "20:30"));
		result.add(new StringId("21:00", "21:00"));
		result.add(new StringId("21:30", "21:30"));
		result.add(new StringId("22:00", "22:00"));
		result.add(new StringId("22:30", "22:30"));
		result.add(new StringId("23:00", "23:00"));
		result.add(new StringId("23:30", "23:30"));
		return result;
	}

	/**
	 * 取得紅利的交易類型下拉選單
	 * @return
	 */
	public static List<StringId> getBonusType() {
		List<StringId> result = new ArrayList<StringId>();
		result.add(_defaultSelect);
		List<BsCode> codeList = BsCodeDefinition.findAllByCodeClass("BC");
		for (BsCode code : codeList) {
			result.add(new StringId(code.getId().getCodeNo(), code.getCodeExplain()));
		}
		return result;
	}

	/**
	 * 取得兌換商品設定的交易類別下拉選單
	 * @return List<StringId>
	 */
	public static List<StringId> getExBonusType() {
		List<StringId> result = new ArrayList<StringId>();
		result.add(_defaultSelect);
		result.add(new StringId("7", "紅利折抵現金"));
		result.add(new StringId("6", "紅利兌換商品"));
		return result;
	}

	/**
	 * 取得服務台活動給點設定的交易類別下拉選單
	 * @return List<StringId>
	 */
	public static List<StringId> getExBonusType1() {
		List<StringId> result = new ArrayList<StringId>();
		result.add(_defaultSelect);
		result.add(new StringId("103", "活動給點"));
		return result;
	}

	/**
	 * 手動執行作業用到的排程
	 * @return
	 */
	public static List<StringId> getScheduleName() {
		List<StringId> result = new ArrayList<StringId>();
		result.add(_defaultSelect);
		result.add(new StringId(BONUS, "紅利計算"));
		result.add(new StringId(COOL_CARD, "酷卡計算"));
		result.add(new StringId(INACTIVE_BONUS, "點數清算"));
		result.add(new StringId(WAGE_BONUS, "HISU 工資計算"));
		result.add(new StringId(BONUS_SUMMARY, "年度紅利點數結算"));
		result.add(new StringId(BONUS_CLEAN, "年度紅利點數清算"));
		result.add(new StringId(BONUS_SUMMARY_BACKUP, "年度紅利點數結算(先復原資料)"));
		result.add(new StringId(BONUS_CLEAN_BACKUP, "年度紅利點數清算(先復原資料)"));

		result.add(new StringId(String.valueOf(NormalProcess), "正常交易"));
		result.add(new StringId(String.valueOf(NormalCancelProcess), "正常作廢"));
		result.add(new StringId(String.valueOf(RejectionProcess), "退貨交易"));
		result.add(new StringId(String.valueOf(RejectionCancelProcess), "退貨作廢"));
		result.add(new StringId("99", "第一次到店計算"));
		result.add(new StringId(String.valueOf(BillingProcess), "專業卡帳單billingjob"));
		result.add(new StringId(String.valueOf(ProductServiceMailProcess), "商品維修寄送Email"));
		result.add(new StringId(String.valueOf(AmTxtProcess), "產生萬里通文字檔"));
		result.add(new StringId(String.valueOf(AbnormalConsumptionProcess), "消費異常月報資料"));
		result.add(new StringId(String.valueOf(MtSkuDiscountProcess), "ZHNT 合營商品 ZTNT 專櫃商品"));
		result.add(new StringId(String.valueOf(FirstPurchase), "首次消費日文字檔"));
		result.add(new StringId(String.valueOf(PhoneRegLog), "產出手機認證的異動檔文字檔"));
		result.add(new StringId(String.valueOf(BcBonusSummary), "會員月紅利現金積點批次計算"));
		result.add(new StringId(String.valueOf(LINE_DAILY), "新增LINE會員綁定文字檔"));
		return result;
	}

	/**
	 * 手動執行作業用到的排程 For Vip
	 * @return
	 */
	public static List<StringId> getVipScheduleName() {
		List<StringId> result = new ArrayList<StringId>();
		result.add(_defaultSelect);
		result.add(new StringId(VIP, "VIP計算"));
		result.add(new StringId(String.valueOf(VipNormalProcess), "正常交易"));
		result.add(new StringId(String.valueOf(VipNormalCancelProcess), "正常作廢"));
		result.add(new StringId(String.valueOf(VipRejectionProcess), "退貨交易"));
		result.add(new StringId(String.valueOf(VipRejectionCancelProcess), "退貨作廢"));
		return result;
	}
	
	/**
	 * 手動執行作業用到的排程 For TR Plus Vip
	 * @return
	 */
	public static List<StringId> getTRPlusVipScheduleName() {
		List<StringId> result = new ArrayList<StringId>();
		result.add(_defaultSelect);
		result.add(new StringId(VIP_TRPLUS, "TR Plus VIP計算"));
		result.add(new StringId(String.valueOf(VipNormalProcess_TRPLUS), "正常交易"));
		result.add(new StringId(String.valueOf(VipNormalCancelProcess_TRPLUS), "正常作廢"));
		result.add(new StringId(String.valueOf(VipRejectionProcess_TRPLUS), "退貨交易"));
		result.add(new StringId(String.valueOf(VipRejectionCancelProcess_TRPLUS), "退貨作廢"));
		return result;
	}

	public static List<StringId> getImType() {
		List<StringId> typeList = new ArrayList<StringId>();
		typeList.add(new StringId("0", "愛心碼"));
		typeList.add(new StringId("1", "特力配合的社福團體"));
		return typeList;
	}

	public static List<StringId> getBsCodeExplain() {
		List<StringId> typeList = new ArrayList<StringId>();

		List<BsCode> reasonList = BsCodeDefinition.findAllByCodeClass("CM_TYPE");
		if (reasonList != null) {
			for (Iterator<BsCode> iterator = reasonList.iterator(); iterator.hasNext();) {
				BsCode bsCode = iterator.next();
				StringId id = new StringId(bsCode.getId().getCodeNo(), bsCode.getCodeExplain());
				typeList.add(id);
			}
		}

		return typeList;
	}

	@SuppressWarnings("rawtypes")
	public static List<StringId> getMembersMarket(String memberOid) {
		List<BsCode> reasonList = BsCodeDefinition.findAllByCodeClass("CM_TYPE");
		List<StringId> typeList = new ArrayList<StringId>();

		IMemberService memberService = (IMemberService) AppContext.getBean("memberService");
		List list = memberService.findMmMembersMarket(memberOid);

		Object returnType;
		for (Object resultList : list) {
			Map map = (HashMap) resultList;
			returnType = map.get("RETURN_TYPE");

			if (reasonList != null) {
				for (Iterator<BsCode> iterator = reasonList.iterator(); iterator.hasNext();) {
					BsCode bsCode = iterator.next();
					if (bsCode.getId().getCodeNo().equals(returnType)) {
						StringId id = new StringId(bsCode.getId().getCodeNo(), bsCode.getCodeExplain());
						typeList.add(id);
					}
				}
			}
		}

		return typeList;
	}

	public static List<StringId> getResultList() {
		List<StringId> typeList = new ArrayList<StringId>();
		typeList.add(_defaultSelect);
		typeList.add(new StringId("0", "未處理"));
		typeList.add(new StringId("1", "處理中"));
		typeList.add(new StringId("2", "已完成"));
		return typeList;
	}

	public static List<StringId> getProgramList() {
		List<StringId> typeList = new ArrayList<StringId>();
		typeList.add(_defaultSelect);
		typeList.add(new StringId("3041", "3041-退件作業"));
		typeList.add(new StringId("3042", "3042-寄送名單作業"));
		typeList.add(new StringId("3023", "3023-活動會員匯入群組作業"));
		typeList.add(new StringId("6603", "6603-紅利點數整批補扣點作業"));
		return typeList;
	}
	
	public static List<StringId> getBsCodeByERParentCode(String parentCodeNo) {
		List<StringId> resultList = new ArrayList<StringId>();
		List<BsCode> reasonList = BsCodeDefinition.findAllByParentCodeClassAndParentCodeNo("ER", parentCodeNo);
		if (reasonList != null) {
			for (Iterator<BsCode> iterator = reasonList.iterator(); iterator.hasNext();) {
				BsCode bsCode = iterator.next();
				StringId id = new StringId(bsCode.getClassExplain(), bsCode.getClassExplain());
				resultList.add(id);
			}
		}

		return resultList;
	}

	public static List<StringId> getWebMasterId() {
		IMmWebMasterConfigService mmWebMasterConfigService = (IMmWebMasterConfigService) AppContext.getBean("mmWebMasterConfigService");//new MmWebMasterConfigSnDao();
		List<String> dataList = mmWebMasterConfigService.findWebMasterIdList();
		List<StringId> resultList = new ArrayList<StringId>();
		resultList.add(0, _defaultSelect);
		if (dataList != null) {
			for (String item : dataList) {
				resultList.add(new StringId(item, item));
			}
		}
		return resultList;
	}

	public static List<StringId> getWebType() {
		IMmWebMasterConfigService mmWebMasterConfigService = (IMmWebMasterConfigService) AppContext.getBean("mmWebMasterConfigService");//new MmWebMasterConfigSnDao();
		List<String> dataList = mmWebMasterConfigService.findWebTypeList();
		List<StringId> resultList = new ArrayList<StringId>();
		resultList.add(0, _defaultSelect);
		if (dataList != null) {
			for (String item : dataList) {
				resultList.add(new StringId(item, item));
			}
		}
		return resultList;
	}
	
}
