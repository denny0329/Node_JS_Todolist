package com.gccs.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.apache.struts2.ServletActionContext;
import org.keycloak.adapters.RefreshableKeycloakSecurityContext;

import com.bnq.util.PropertyConfigUtils;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class KeyCloakTokenUtil {
	
	private static final String PROPERTY_FILE = "keycloakClients.properties";
	
	public String getToken() {
		HttpServletRequest request = (HttpServletRequest) ServletActionContext.getRequest();
		HttpSession session = request.getSession();	
		RefreshableKeycloakSecurityContext rksc = (RefreshableKeycloakSecurityContext) session.getAttribute("KCToken");
		return rksc.getTokenString();
	}
	
	public static String getProperty(String key) {
		return PropertyConfigUtils.getProperty(PROPERTY_FILE, key);
	}
	
	public String getCrmSystemToken() throws Exception {
		return getSysToken(getProperty("clientId.crmSystem"), getProperty("secret.crmSystem"));
	}
	
	private static RequestConfig keycloakReqConfig = 
			RequestConfig.custom().setSocketTimeout(1000)
			.setConnectTimeout(1000)
			.setConnectionRequestTimeout(1000)
			.build();
	
	/**
	 * @param clientId
	 * @param clientSecret
	 * @return access_token String
	 */
	private static String getSysToken(String clientId, String clientSecret) throws Exception {
		HttpPost httpPost = new HttpPost(getProperty("endpoint.realms.trEmployee"));

		httpPost.addHeader(HTTP.CONTENT_TYPE, "application/x-www-form-urlencoded");

		List<NameValuePair> postParameters = new ArrayList<>();
		postParameters.add(new BasicNameValuePair("grant_type", "client_credentials"));
		postParameters.add(new BasicNameValuePair("client_id", clientId));
		postParameters.add(new BasicNameValuePair("client_secret", clientSecret));

		httpPost.setEntity(new UrlEncodedFormEntity(postParameters, "UTF-8"));

		CloseableHttpClient httpsClient = HttpClients.custom().build();
		HttpClients.custom().setDefaultRequestConfig(keycloakReqConfig);
		CloseableHttpResponse response = httpsClient.execute(httpPost);

		int statusCode = response.getStatusLine().getStatusCode();
		HttpEntity httpEntity = response.getEntity();

		String responseString = new String(EntityUtils.toString(httpEntity).getBytes());

		String accessToken = "";
		if (200 == statusCode) {
			ObjectMapper objectMapper = new ObjectMapper();
			Map<String, String> resultMap = objectMapper.readValue(responseString,
					new TypeReference<Map<String, String>>() {
					});
			accessToken = resultMap.get("access_token");
		} else {
			throw new Exception();
		}

		return accessToken;
	}
	
}
