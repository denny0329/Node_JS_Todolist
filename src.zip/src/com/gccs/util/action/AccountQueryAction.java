package com.gccs.util.action;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.QueryResult;
import com.gccs.base.action.BaseAction;
import com.gccs.member.model.condition.AccountCondition;
import com.gccs.member.service.AccountService;
import com.opensymphony.xwork2.Action;

/* 程式的處理
 * @author neo
 */
public class AccountQueryAction extends BaseAction {
	private static final long serialVersionUID = 1415245766873027085L;

	private static final Logger log = LogManager.getLogger(AccountQueryAction.class) ;
	private AccountCondition condition;

	private static String _session_key_accountQuery_query = "_session_accountQuery_query";
	private static String _session_key_accountQuery = "_session_accountQuery";

	private AccountService accountService;

	public AccountService getAccountService() {
		return accountService;
	}
	public void setAccountService(AccountService accountService) {
		this.accountService = accountService;
	}
	public AccountCondition getCondition() {
		return condition;
	}
	public void setCondition(AccountCondition condition) {
		this.condition = condition;
	}

	public String doQueryAcount(){

		try {
			if(!this.hasToCountTotal()) {
				AccountCondition p = (AccountCondition)this.getSessionMap().get(_session_key_accountQuery_query);
				this.setCondition(p);
			} else {
				this.getSessionMap().put(_session_key_accountQuery_query, this.getCondition());
				this.getPageBean().setJumpPage("");
			}

			QueryResult result = accountService.findAccountByCondition(this.getCondition(), this.getQueryStartIndex(),
					this.getPageBean().getPageSize(), this.hasToCountTotal());

			this.setPageBeanByQueryResult(result,"doQueryAcount");

		} catch(Exception e) {
			e.printStackTrace();
		}
		return Action.SUCCESS;
	}
}
