package com.gccs.util.action;

import java.util.ArrayList;
import java.util.List;

import com.bnq.util.QueryResult;
import com.gccs.base.action.BaseAction;
import com.gccs.member.model.Account;
import com.gccs.member.model.condition.AccountHqCondition;
import com.gccs.member.service.AccountService;
import com.opensymphony.xwork2.Action;


/* 程式的處理
 * @author neo
 */
public class AccountHqQueryAction extends BaseAction {
	private static final long serialVersionUID = 434195489453955496L;

	private AccountHqCondition condition;

	private static String _session_key_accountHqQuery_query = "_session_accountHqQuery_query";
	private static String _session_key_accountHqQuery = "_session_accountHqQuery";
	private AccountService accountService;

	private List<Account> accountList = new ArrayList();

	public AccountService getAccountService() {
		return accountService;
	}
	public void setAccountService(AccountService accountService) {
		this.accountService = accountService;
	}

	public List<Account> getAccountList() {
		return accountList;
	}
	public void setAccountList(List<Account> accountList) {
		this.accountList = accountList;
	}
	public AccountHqCondition getCondition() {
		return condition;
	}
	public void setCondition(AccountHqCondition condition) {
		this.condition = condition;
	}

	public String doAccountHqQuery(){
		try {
			if(!this.hasToCountTotal()) {
				AccountHqCondition p = (AccountHqCondition)this.getSessionMap().get(_session_key_accountHqQuery_query);
				this.setCondition(p);
			} else {
				this.getSessionMap().put(_session_key_accountHqQuery_query, this.getCondition());
				this.getPageBean().setJumpPage("");
			}

			QueryResult result = this.getAccountService().findAccountHqByCondition(this.getCondition(), this.getQueryStartIndex(),
					this.getPageBean().getPageSize(), this.hasToCountTotal());

			this.setPageBeanByQueryResult(result,"doAccountHqQuery");

		} catch(Exception e) {
			e.printStackTrace();
		}
		return Action.SUCCESS;
	}

}
