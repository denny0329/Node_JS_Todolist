package com.gccs.util.action;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.krysalis.barcode4j.ChecksumMode;
import org.krysalis.barcode4j.HumanReadablePlacement;
import org.krysalis.barcode4j.impl.AbstractBarcodeBean;
import org.krysalis.barcode4j.impl.code128.Code128Bean;
import org.krysalis.barcode4j.impl.code39.Code39Bean;
import org.krysalis.barcode4j.impl.code39.Code39LogicImpl;
import org.krysalis.barcode4j.impl.int2of5.Interleaved2Of5Bean;
import org.krysalis.barcode4j.impl.int2of5.Interleaved2Of5LogicImpl;
import org.krysalis.barcode4j.impl.upcean.EAN13Bean;
import org.krysalis.barcode4j.impl.upcean.EAN8Bean;
import org.krysalis.barcode4j.impl.upcean.UPCABean;
import org.krysalis.barcode4j.impl.upcean.UPCEBean;
import org.krysalis.barcode4j.output.bitmap.BitmapCanvasProvider;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;

// No longer supported in 1.8.  
//import com.sun.image.codec.jpeg.JPEGCodec;
//import com.sun.image.codec.jpeg.JPEGImageEncoder;
// Need to fix 2018-11-13

public class BarcodeAction extends ActionSupport {
	private static final long serialVersionUID = -6784739080331418880L;

	private final Logger log = LogManager.getLogger(BarcodeAction.class);
		
	private String type;
	private String msg;
	private String supp;
	private String fileName;
	private String position = "bottom";
	private int orientation = 0;
	private double fontSize = 10;
	private double moduleWidth = 20;
	private boolean showValue = true;
	private boolean checkSum = false;
	private byte[] barcode;
	private String imgType = "jpeg";
	private String contentType = "image/jpeg";
	private String contentDisposition = "";
	private InputStream inputStream;	
	
	//for location test
	public static void main(String[] args) {
		BarcodeAction a = new BarcodeAction();
		a.setType("ean-13");
		//a.setCheckSum(false);
		a.setMsg("111111111111111");
		//a.setSupp("222556");
		a.execute();
		a.writeToFile();
		System.out.println("OK");		
	}
	
	public String execute() { 			
		try {
			if(StringUtils.isNotEmpty(this.fileName)) {
				String file = this.fileName + "." + this.imgType;
				this.contentDisposition = "attachment;filename=\"" + file + "\"";
				this.contentType = "image/" + this.imgType;
			}						
		    this.barcode = this.getBarcode();			
		} catch (Throwable t) {
            log.error("Error while generating barcode", t);   
            this.barcode = this.getPicture("Error");
        }
		
		this.inputStream = new ByteArrayInputStream(this.barcode);		
			
		return Action.SUCCESS;
	}			
	
	private byte[] getBarcode() throws Exception {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		
		try {
			BitmapCanvasProvider canvas = getCanvas(out);			
			AbstractBarcodeBean bean = this.getBarcodeBean();
			bean.setFontSize(this.fontSize/3);
			bean.setModuleWidth(this.moduleWidth/100);			
			
			if(!this.showValue) {
				bean.setMsgPosition(HumanReadablePlacement.HRP_NONE);
			} else if("top".equals(this.position)){
				bean.setMsgPosition(HumanReadablePlacement.HRP_TOP);
			}
			
			bean.generateBarcode(canvas, this.msg);
			canvas.finish();
		} finally {
			out.close();
		}
										
		return out.toByteArray();
	}	
	
	private byte[] getPicture(String msg) {			
		try {
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			int w=200, h=100;
            BufferedImage image = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = image.createGraphics();
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, 200, 100);
            g.setColor(Color.BLUE);
            g.setFont(new Font("Lucida Sans", Font.PLAIN, 24));
            g.drawString(msg, 20, 50);
            g.dispose();
                       
            // No longer supported in 1.8
            //JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
            //encoder.encode(image); 
            // Need to fix 2018-11-13
            
            out.close();
            return out.toByteArray();
		}  catch (Throwable t) {
            log.error("Error while generating picture", t); 
            return null;
        } 												
	}
	
    private AbstractBarcodeBean getBarcodeBean() {
    	AbstractBarcodeBean bean = null;
    	
    	if("code39".equals(type)) {
    		bean = new Code39Bean();
    		if(this.checkSum) {
    			this.msg += Code39LogicImpl.calcChecksum(this.msg);
    		}
    	} else if("code128".equals(type)) {
    		bean = new Code128Bean();
    	} else if("intl2of5".equals(type)) {
    		bean = new Interleaved2Of5Bean();
    		if(this.checkSum) {
    			this.msg += Interleaved2Of5LogicImpl.calcChecksum(this.msg);
    		}
    	} else if("codabar".equals(type)) {
    		bean = new Code39Bean();
    		if(this.checkSum) {
    			this.msg += Interleaved2Of5LogicImpl.calcChecksum(this.msg);
    		}
    	} else if("ean-8".equals(type)) {
    		bean = new EAN8Bean();
    		if(this.checkSum) {
    			this.msg = this.getLimitedMsg(7);
    		} else {
    			((EAN8Bean)bean).setChecksumMode(ChecksumMode.CP_IGNORE);
    			this.msg = this.getLimitedMsg(8);
    		}    		    		    		
    	} else if("ean-13".equals(type)) {
    		bean = new EAN13Bean();
    		if(this.checkSum) {
    			this.msg = this.getLimitedMsg(12);
    		} else {
    			((EAN13Bean)bean).setChecksumMode(ChecksumMode.CP_IGNORE);
    			this.msg = this.getLimitedMsg(13);
    		}
    		this.msg += this.getSuppMsg();
    	} else if("upc-a".equals(type)) {
    		bean = new UPCABean();
    		if(this.checkSum) {
    			this.msg = this.getLimitedMsg(11);
    		} else {
    			((UPCABean)bean).setChecksumMode(ChecksumMode.CP_IGNORE);
    			this.msg = this.getLimitedMsg(12);
    		}
    		this.msg += this.getSuppMsg();   
    	} else if("upc-e".equals(type)) {
    		bean = new UPCEBean();
    		if(this.checkSum) {
    			this.msg = this.getLimitedMsg(7);
    		} else {
    			((UPCEBean)bean).setChecksumMode(ChecksumMode.CP_IGNORE);
    			this.msg = this.getLimitedMsg(8);
    		} 
    	}
    	    	    	
    	return bean;
    }
    
    private String getLimitedMsg(int size) {
    	if(this.msg.trim().length() > size) {
			return this.msg.substring(0, size);
		} else if(this.msg.trim().length() < size) {
			return StringUtils.rightPad(this.msg, size, '0');
		} else {
			return this.msg;
		}
    }
    
    private String getSuppMsg() {
    	if(StringUtils.isNotEmpty(this.supp)) {
    		if(this.supp.trim().length() >= 5) {
    			return "+" + this.supp.trim().substring(0, 5);
    		} else if(this.supp.trim().length() >= 2) {
    			return "+" + this.supp.trim().substring(0, 2);
    		} 
    	}
    	return "";
    }
	
	private BitmapCanvasProvider getCanvas(OutputStream out) {
		return new BitmapCanvasProvider(
	        out, this.contentType, 300, BufferedImage.TYPE_BYTE_BINARY, false, this.orientation);
	}		
	
	//for location test
	public void writeToFile() {
		File file = new File("C:\\Documents and Settings\\Administrator\\桌面\\barcode.bmp");
		FileOutputStream out = null;
		try {			
			out = new FileOutputStream(file);
			out.write(this.barcode);			
		} catch (Throwable t) {			
			t.printStackTrace();			
		} finally {
	        try {
				out.close();
			} catch (Exception e) {}
		}
	}
	
	/********************************************************************************/	

	public String getType() {
		return type;
	}	
	public void setType(String type) {
		this.type = type;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}	
	public int getOrientation() {
		return orientation;
	}
	public void setOrientation(int orientation) {
		this.orientation = orientation;
	}
	public boolean isShowValue() {
		return showValue;
	}
	public void setShowValue(boolean showValue) {
		this.showValue = showValue;
	}	
	public double getModuleWidth() {
		return moduleWidth;
	}
	public void setModuleWidth(double moduleWidth) {
		this.moduleWidth = moduleWidth;
	}
	public boolean isCheckSum() {
		return checkSum;
	}
	public void setCheckSum(boolean checkSum) {
		this.checkSum = checkSum;
	}
	public InputStream getInputStream() {
		return inputStream;
	}
	public void setInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
	}
	public void setBarcode(byte[] barcode) {
		this.barcode = barcode;
	}
	public String getContentDisposition() {
		return contentDisposition;
	}
	public void setContentDisposition(String contentDisposition) {
		this.contentDisposition = contentDisposition;
	}
	public double getFontSize() {
		return fontSize;
	}
	public void setFontSize(double fontSize) {
		this.fontSize = fontSize;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getSupp() {
		return supp;
	}
	public void setSupp(String supp) {
		this.supp = supp;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	public String getImgType() {
		return imgType;
	}
	public void setImgType(String imgType) {
		this.imgType = imgType;
	}
}
