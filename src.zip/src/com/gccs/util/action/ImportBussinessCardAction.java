package com.gccs.util.action;


import java.io.File;

import jxl.Sheet;
import jxl.Workbook;

import org.apache.commons.lang.StringUtils;

import com.gccs.base.action.BaseAction;
import com.gccs.member.model.Members;
import com.gccs.member.service.AccountService;
import com.gccs.member.service.CardService;
import com.gccs.member.service.MemberService;
import com.opensymphony.xwork2.Action;


/* 程式的處理
 * @author neo
 */
public class ImportBussinessCardAction extends BaseAction {
	private static final long serialVersionUID = -6211016010457910599L;

	private final static String IMPORT_MEMO = "商務會員匯入新增商務卡";

	private MemberService memberService;
	private AccountService accountService;
	private CardService cardService;
	private String myFileFileName;
	private File myFile;


	public AccountService getAccountService() {
		return accountService;
	}
	public void setAccountService(AccountService accountService) {
		this.accountService = accountService;
	}
	public CardService getCardService() {
		return cardService;
	}
	public void setCardService(CardService cardService) {
		this.cardService = cardService;
	}
	public String getMyFileFileName() {
		return myFileFileName;
	}
	public void setMyFileFileName(String myFileFileName) {
		this.myFileFileName = myFileFileName;
	}
	public File getMyFile() {
		return myFile;
	}
	public void setMyFile(File myFile) {
		this.myFile = myFile;
	}
	public MemberService getMemberService() {
		return memberService;
	}
	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}



	//商務會員EXCEL匯入
	public String importMemberCard(){
		System.out.println("========== BEGIN: 執行商務會員EXCEL匯入 ============");
		StringBuffer errMsg = new StringBuffer();
		try {

            Workbook wb = Workbook.getWorkbook(myFile);
            Sheet sheet = wb.getSheet(0);
            for (int row = 2; row < sheet.getRows(); row++) {
            	System.out.println(">>> 處理列"+(row+1));
            	try {
	            	
	            	Members	member = new Members();
	            	String accountId = StringUtils.trimToNull(sheet.getCell(0,row).getContents());
	            	String personId = sheet.getCell(1,row).getContents();
	            	String name = sheet.getCell(2,row).getContents().trim();
	            	String birthdayYy = sheet.getCell(3,row).getContents().trim();
	            	String birthdayMm = sheet.getCell(4,row).getContents().trim();
	            	String birthdayDd = sheet.getCell(5,row).getContents().trim();
	            	String sex = sheet.getCell(6,row).getContents().trim();
	            	String cantactTel = sheet.getCell(7,row).getContents().trim();
	            	String faxNo = sheet.getCell(8,row).getContents().trim();
	            	String cellPhone = sheet.getCell(9,row).getContents().trim();
	            	String addr5 = sheet.getCell(10,row).getContents().trim();
	            	String marager = sheet.getCell(11,row).getContents().trim();
	            	String email = sheet.getCell(12,row).getContents().trim();
	            	String email2 = sheet.getCell(13,row).getContents().trim();

	            	if (Integer.valueOf(this.doConvertNumber(birthdayMm, "0")).intValue() < 1
							|| Integer.valueOf(this.doConvertNumber(birthdayMm, "0")) > 12) {
						birthdayMm = "0";
					}
					if (Integer.valueOf(this.doConvertNumber(birthdayDd, "0")).intValue() < 1
							|| Integer.valueOf(this.doConvertNumber(birthdayDd, "0")).intValue() > 31) {
						birthdayDd = "0";
					}
					if (Integer.valueOf(this.doConvertNumber(sex, "4")).intValue() != 1
							&& Integer.valueOf(this.doConvertNumber(sex, "4")).intValue() != 0) {
						sex = "0";
					}
					if (Integer.valueOf(this.doConvertNumber(marager, "4")).intValue() != 1
							&& Integer.valueOf(this.doConvertNumber(marager, "4")).intValue() != 0
							&& Integer.valueOf(this.doConvertNumber(marager, "4")).intValue() != 2) {
						marager = "2";
					}
					member.setName(name.length() > 20 ? subStringToLeng(this.doConvertNumber(name, ""), 20) : name);
					member.setAccountId(accountId);
					member.setPersonId(personId.trim());
					Integer year = new Integer(this.doConvertNumber(birthdayYy, "0"));
					year = year.intValue() + 1911;
					member.setBirthdayYy(year);
					member.setBirthdayMm(new Integer(birthdayMm));
					member.setBirthdayDd(new Integer(birthdayDd));
					member.setSex(new Integer(sex));
					member.setCantactTel(cantactTel.length() > 20 ? subStringToLeng(this.doConvertNumber(cantactTel, ""), 20): this.doConvertNumber(cantactTel, ""));
					member.setFaxNo(faxNo.length() > 20 ? subStringToLeng(this.doConvertNumber(faxNo, ""), 20) : this.doConvertNumber(faxNo, ""));
					member.setCellPhone(cellPhone.length() > 20 ? subStringToLeng(this.doConvertNumber(cellPhone, ""), 20)
									: this.doConvertNumber(cellPhone, ""));
					member.setCantactAddr5(addr5.length() > 100 ? subStringToLeng(addr5, 100): addr5);
					member.setMarrage(new Integer(marager));

					String pattern = ".+@.+\\.[a-z]+";
					member.setEmail(email.length() > 50 ? subStringToLeng(email, 50) : this.doConvertNumber(email, ""));

					member.setEmailBackup(email2.length() > 50 ? subStringToLeng(email2, 50): this.doConvertNumber(email2, ""));
					if (!email.matches(pattern)) {
						member.setEmail(null);
					}
					if (!email2.matches(pattern)) {
						member.setEmailBackup(null);
					}
					member.setStatus(1);
					member.setEcYn(0);
					member.setBonusTotal(0);

					this.getCardService().importBusinessCard(member, this.getUser().getUserId(), this.getUser().getUserName());
					System.out.println("匯入成功");

            	} catch(Exception e) {
            		if(errMsg.length() > 0)
            			errMsg.append("\\n");
            		errMsg.append("列"+(row+1)+"資料匯入失敗: "+e.getMessage());
            	}
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            errMsg = new StringBuffer("匯入失敗");

        }

        this.getRequest().setAttribute("importCard", Boolean.TRUE);

        if(errMsg.length() > 0) {
        	errMsg.append("\\n\\n其餘資料匯入成功");
        	//System.out.println("errMsg: "+errMsg.toString());
        	this.getRequest().setAttribute("str", errMsg.toString());
        } else {
	        //this.getRequest().setAttribute("str", str);
	        this.getRequest().setAttribute("str", "匯入成功");
        }

        System.out.println("========== END: 執行商務會員EXCEL匯入 ============");

		return Action.SUCCESS;
	}

	/*
	public String importMemberCard(){
		System.out.println("========== BEGIN: 執行商務會員EXCEL匯入 ============");
		StringBuffer errMsg = new StringBuffer();
		try {

            Workbook wb = Workbook.getWorkbook(myFile);
            Sheet sheet = wb.getSheet(0);
            for (int row = 2; row < sheet.getRows(); row++) {
            	System.out.println(">>> 處理列"+(row+1));
            	try {
	            	String accountId = StringUtils.trimToNull(sheet.getCell(0,row).getContents());
	            	System.out.println("Excel accountId: "+accountId);
	            	if(accountId != null){
	            	    Account account=  accountService.findAccountByAccountIdStatus(accountId,3);
	            		if(account!=null){
						    System.out.println("商務帳號(accountId: "+account.getAccountId()+")存在");
	            			String personId = sheet.getCell(1,row).getContents();
	            			Members member = memberService.getMemberByPersonId(personId.trim()); 
	            			if(member != null){ //會員存在
	            			    System.out.println("會員(PERSON_ID:"+personId+")存在, 檢查是否已有商務卡");
	            				String memberAccountId = member.getAccountId();
	            				List<MmCard> businessCard  = this.getCardService().findMmCardByMemberOidStatusAndCardType(member.getOid(), 1, 1);
	            				if(businessCard != null && businessCard.size() > 0){
	            				    throw new Exception("已有商務卡存在,不製卡");
	            				} else {   //沒有商務卡, 要製卡
	            					//更新會員的商務帳號
	     							member.setAccountOid(account.getOid());
	     							member.setAccountId(account.getAccountId());
	     							getMemberService().updateMember(member, getUser().getUserId(), getUser().getUserName());
	     							System.out.println("更新會員的商務帳號(accountId:" + account.getAccountId() + ")");
	            					 
	            					 String newVipNo = this.getCardService().createBusinessCard(null,member.getOid(), 
	            							 this.getUser().getUserId(),this.getUser().getUserName() ,account.getDiscCardOid(),null,null,
	            							 account.getAccountId(), null, true);
	            					 System.out.println("建立新商務卡(VIP_NO:"+newVipNo+")");
	            				}
	            				 
	            				//  //2010/06/29, remarked by Crown, 每一會員只能有一張商務卡, 商務帳號位於會員中
								//String oldVipNo = null;
								//for(MmCard cardVo:businessCard){
	            				//	 if(cardVo.getAccountId() != null && cardVo.getAccountId().equals(accountId)) {
	            				//		//卡片已存在,不製卡
	            				//		oldVipNo = cardVo.getVipNo();
	            				//	 	//cardVo.setCardType(0);
	            				//	 	//cardVo.setDelReason(null);
	            				//		break;
	            				//	 }
	            				//}
	            				//if(oldVipNo == null) { //卡片不存在,製卡
	            				//	 //this.getMemberService().updateMmCards(businessCard);
	            				//	 String newVipNo = this.getCardService().createBusinessCard(null,member.getOid(), 
	            				//			 this.getUser().getUserId(),this.getUser().getUserName() ,account.getDiscCardOid(),null,null,
	            				//			 account.getAccountId(), null, true);
	            				//	 System.out.println("舊卡不存在, 建立新商務卡(VIP_NO:"+newVipNo+")");
	            				//} else {
	            				//	 throw new Exception("舊商務卡(卡號:"+oldVipNo+")已存在,不製卡");
	            				//}
	            				
	            			}else{  //會員不存在
	            				System.out.println("會員(PERSON_ID:"+personId+")不存在, 建立帳戶並新增商務卡");

	            				member = new Members();
	            				String name = sheet.getCell(2,row).getContents().trim();
	            				String birthdayYy = sheet.getCell(3,row).getContents().trim();
	            				String birthdayMm = sheet.getCell(4,row).getContents().trim();
	            				String birthdayDd = sheet.getCell(5,row).getContents().trim();
	            				String sex = sheet.getCell(6,row).getContents().trim();
	            				String cantactTel = sheet.getCell(7,row).getContents().trim();
	            				String faxNo = sheet.getCell(8,row).getContents().trim();
	            				String cellPhone = sheet.getCell(9,row).getContents().trim();
	            				String addr5 = sheet.getCell(10,row).getContents().trim();
	            				String marager = sheet.getCell(11,row).getContents().trim();
	            				String email = sheet.getCell(12,row).getContents().trim();
	            				String email2 = sheet.getCell(13,row).getContents().trim();

	            				if(Integer.valueOf(this.doConvertNumber(birthdayMm,"0")).intValue()<1 || Integer.valueOf(this.doConvertNumber(birthdayMm,"0"))>12){
	            				    birthdayMm = "0";
	            				}
	            				if(Integer.valueOf(this.doConvertNumber(birthdayDd,"0")).intValue()<1 || Integer.valueOf(this.doConvertNumber(birthdayDd,"0")).intValue()>31){
	            				    birthdayDd = "0";
	            				}
	            				if(Integer.valueOf(this.doConvertNumber(sex,"4")).intValue()!=1 && Integer.valueOf(this.doConvertNumber(sex,"4")).intValue()!=0){
	            					sex = "0";
	            				}
	            				if(Integer.valueOf(this.doConvertNumber(marager,"4")).intValue()!=1 && Integer.valueOf(this.doConvertNumber(marager,"4")).intValue()!=0 && Integer.valueOf(this.doConvertNumber(marager,"4")).intValue()!=2){
	            					marager = "2";
	            				}
	            				String serial = SerialService.getMemberSerial("MM") ;
	            				member.setName(name.length()>20?subStringToLeng(this.doConvertNumber(name,""),20):name);
	            				member.setMemberId(Long.valueOf(serial));
	            				member.setAccountId(account.getAccountId());
	            				member.setAccountOid(account.getOid());
	            				member.setPersonId(personId.trim());
	            				Integer year = new Integer(this.doConvertNumber(birthdayYy,"0"));
	            				year  =year.intValue()+1911;
	            				member.setBirthdayYy(year);
	            				member.setBirthdayMm(new Integer(birthdayMm));
	            				member.setBirthdayDd(new Integer(birthdayDd));
	            				member.setSex(new Integer(sex));
	            				member.setCantactTel(cantactTel.length()>20?subStringToLeng(this.doConvertNumber(cantactTel,""),20):this.doConvertNumber(cantactTel,""));
	            				member.setFaxNo(faxNo.length()>20?subStringToLeng(this.doConvertNumber(faxNo,""),20):this.doConvertNumber(faxNo,""));
	            				member.setCellPhone(cellPhone.length()>20?subStringToLeng(this.doConvertNumber(cellPhone,""),20):this.doConvertNumber(cellPhone,""));
	            				member.setCantactAddr5(addr5.length()>100?subStringToLeng(addr5,100):addr5);
	            				member.setMarrage(new Integer(marager));

	            				String pattern = ".+@.+\\.[a-z]+";
	            				member.setEmail(email.length()>50?subStringToLeng(email,50):this.doConvertNumber(email,""));

	            				member.setEmailBackup(email2.length()>50?subStringToLeng(email2,50):this.doConvertNumber(email2,""));
	            				if(!email.matches(pattern)){
	            				    member.setEmail(null);
	            				}
	            				if(!email2.matches(pattern)){
	            				    member.setEmailBackup(null);
	            				}
	            				member.setStatus(1);
	            				member.setEcYn(0);
	            				member.setBonusTotal(0);

	            				member.setCreator(this.getUser().getUserId());
	            				member.setCreatorName(this.getUser().getUserName());
	            				member.setCreateTime(new Date());
	            				member.setModifier(this.getUser().getUserId());
	            				member.setModifierName(this.getUser().getUserName());
	            				member.setModifyTime(new Date());
	            				this.getMemberService().createMember(member, this.getUser().getUserId(), this.getUser().getUserName());
	            				System.out.println("建立新會員(PERSON_ID:"+personId+"  OID:"+member.getOid()+")");
	            				String newVipNo = this.getCardService().createBusinessCard(null,member.getOid(), this.getUser().getUserId(),this.getUser().getUserName() ,account.getDiscCardOid(),null,null,account.getAccountId(), null, true);
	            				System.out.println("建立新商務卡(VIP_NO:"+newVipNo+")");
	            				//更新mm_account.ApproveCard
	            				this.getCardService().updateApproveCardByAccountId(member.getAccountId());
	            				//System.out.println( member.toString());
	            			}
	            			//List<MmCard> businessCard  = this.getMemberService().getMemberDao().findMmCardByAccountIdCardTypeDisCardOid(account.getAccountId(), 1,account.getDiscCardOid());

	            			// 找出此商務帳號舊商務卡改為一般卡 並新增商務卡
	            			//this.doUpdateCardToType0(businessCard);


	        			    System.out.println("匯入成功");

	            		}else{
	            			System.out.println("商務帳號(ACCOUNT_ID: "+accountId+")不存在或狀態非核發");
	            		    throw new Exception("商務帳號(ACCOUNT_ID: "+accountId+")不存在或狀態非核發");
	            	    }

	            	} else {
	            		System.out.println("沒有指定商務帳號");
	            	    throw new Exception("沒有指定商務帳號");
	            	}
            	} catch(Exception e) {
            		if(errMsg.length() > 0)
            			errMsg.append("\\n");
            		errMsg.append("列"+(row+1)+"資料匯入失敗: "+e.getMessage());
            	}
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            errMsg = new StringBuffer("匯入失敗");

        }

        this.getRequest().setAttribute("importCard", Boolean.TRUE);

        if(errMsg.length() > 0) {
        	errMsg.append("\\n\\n其餘資料匯入成功");
        	//System.out.println("errMsg: "+errMsg.toString());
        	this.getRequest().setAttribute("str", errMsg.toString());
        } else {
	        //this.getRequest().setAttribute("str", str);
	        this.getRequest().setAttribute("str", "匯入成功");
        }

        System.out.println("========== END: 執行商務會員EXCEL匯入 ============");

		return Action.SUCCESS;
	}
    */

	private String subStringToLeng(String str,int leng){
		str= str.substring(0, leng);
		return str;
	}

	private String doConvertNumber(String str,String defauleReturn){
		if(str==null || "".equals(str)){
			return defauleReturn;
		}
		StringBuffer sb = new StringBuffer("");
		for(int i=0;i<str.length();i++){
			for(int j=0;j<10;j++){
					if(String.valueOf(str.charAt(i)).equals(String.valueOf(j))){
						sb.append(str.charAt(i));
					}
			}
		}

		if(sb.toString().trim().equals("")){
			return defauleReturn;
		}
		return sb.toString().trim();
	}

	/*
	//改為一般卡
	private void doUpdateCardToType0(List<MmCard> list) throws Exception{
		if(list.size()!=0){
			 for(MmCard card :list){
				 card.setCardType(0);
				 card.setStatus(1);
				 card.setDisCardOid(null);
				 card.setModifier(this.getUser().getUserId());
				 card.setModifierName(this.getUser().getUserName());
				 card.setModifyTime(new Date());

			 }
			 this.getCardService().updateCard(list);
		 }
	}
    */
}
