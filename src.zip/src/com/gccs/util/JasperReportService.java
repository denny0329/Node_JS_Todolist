package com.gccs.util;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.ByteArrayHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

@SuppressWarnings("all")
public class JasperReportService {
	private static final Logger log = LogManager.getLogger(JasperReportService.class);
	
	private ResourceBundle bundle = ResourceBundle.getBundle("webService");
	
	public Map<String, String> getReportUri(String reportId, List<JSONObject> paramterList) throws IOException {
		
		RestTemplate restTemplate = new RestTemplate();
		
		// 組合post content
		JSONObject reqContent = new JSONObject();
		reqContent.put("\"reportUnitUri\"", "/testritegroup/reports/" + reportId);
		reqContent.put("\"async\"", "false");
		reqContent.put("\"freshData\"", "false");
		reqContent.put("\"saveDataSnapshot\"", "false");
		reqContent.put("\"outputFormat\"", "pdf");
		reqContent.put("\"interactive\"", "true");
		reqContent.put("\"ignorePagination\"", "false");
		
		JSONArray reportParameter = new JSONArray();
		for (JSONObject jsonObj : paramterList) {
			reportParameter.put(jsonObj);
		}
		JSONObject parameters = new JSONObject();
		parameters.put("\"reportParameter\"", reportParameter);
		reqContent.put("\"parameters\"", parameters);
		
		// 設定http header與認證
		HttpHeaders headers = new HttpHeaders();
		MediaType mediaType = new MediaType("application", "json", Charset.forName("UTF-8"));
		headers.setContentType(mediaType);
		headers.set("Authorization", "Basic " + bundle.getString("JasperBasic"));
		
		// 發送post
		HttpEntity<String> httpEntity = new HttpEntity<>(reqContent.toString(), headers);
		ResponseEntity<String> responseEntity = restTemplate.postForEntity(bundle.getString("JasperServerUri"), httpEntity, String.class);
		
		// 取得http post response 的 sessionId
		HttpHeaders responseHttpHeaders = responseEntity.getHeaders();
		String setCookieHeaderStr = responseHttpHeaders.getFirst("Set-Cookie");
		String sessionIdBeginStr = setCookieHeaderStr.substring(setCookieHeaderStr.indexOf("JSESSIONID"));
		String sessionId = sessionIdBeginStr;
		if (sessionIdBeginStr.indexOf(";") > 0) {
			sessionId = sessionIdBeginStr.substring(0, sessionIdBeginStr.indexOf(";"));
		}
		
		// 根據response組合報表url
		JSONObject jsonResponse = new JSONObject(responseEntity.getBody());
		String requestId = jsonResponse.getString("requestId");
		String id = ((JSONObject)((JSONArray) jsonResponse.get("exports")).get(0)).getString("id");
		String reportUri = bundle.getString("JasperServerUri") + "/" + requestId + "/exports/" + id + "/outputResource";
		
		Map<String, String> resultMap = new HashMap<>();
		resultMap.put("reportUri", reportUri);
		resultMap.put("sessionId", sessionId);
		
		return resultMap;
	}
	
	public void saveReportByReportUri(String reportUri, String pdfFilePath, String sessionId) throws IOException {
	   RestTemplate restTemplate = new RestTemplate();
	   
	   // 使其支援body是byte array
	   restTemplate.getMessageConverters().add(
	            new ByteArrayHttpMessageConverter());
	   
	   HttpHeaders headers = new HttpHeaders();
	   // 內容為二進制檔案類別
       headers.setAccept(Arrays.asList(MediaType.APPLICATION_OCTET_STREAM));
	   headers.set("Cookie", sessionId);
       HttpEntity<String> entity = new HttpEntity<>(headers);
       ResponseEntity<byte[]> response = restTemplate.exchange(reportUri, HttpMethod.GET, entity, byte[].class, "1");
       Files.write(Paths.get(pdfFilePath), response.getBody());
	}
}
