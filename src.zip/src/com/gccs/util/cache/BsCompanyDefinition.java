/**
 * @(#)BsCompanyDefinition.java 2014/09/12
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.gccs.util.cache;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.directwebremoting.WebContextFactory;

import com.bnq.util.AppContext;
import com.gccs.bs.model.BsChannel;
import com.gccs.bs.model.BsCompany;
import com.gccs.bs.model.BsStore;
import com.gccs.bs.service.BsCompanyService;
import com.rfep.util.cache.BaseDefinition;

public class BsCompanyDefinition extends BaseDefinition {

	private static final Logger log = LogManager.getLogger(BsCompanyDefinition.class);

	/** 儲存 BS_COMPANY.COMPANY_ID 的 Session Key */
	public static final String SESSION_BS_COMPANY_ID = "SESSION_BS_COMPANY_ID";

	/** BS_COMPANY model list */
	private static List<BsCompany> list = new ArrayList<BsCompany>();
	
	/** 負向條碼的代碼*/
	private static Map<String,String> NegBarcode = new HashMap<String, String>();

	/** 過期時間 */
	static long timeoutstamp = 0L;

	static {
		init();
	}

	/**
	 * 初始化 list 與 timeoutstamp。
	 */
	private static void init() {
		BsCompanyService bsCompanyService = (BsCompanyService) AppContext.getBean("bsCompanyService");
		try {
			list = bsCompanyService.findAllBsCompany();
			NegBarcode.put("1010", "027,031,007");
			NegBarcode.put("1050", "897,031,007");
			setTimeOutStamp();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	/**
	 * 重新查詢 BS_COMPANY。
	 */
	public static void reload() {
		list.clear();
		init();
	}

	/**
	 * 設定過期時間。
	 */
	public static void setTimeOutStamp() {
		timeoutstamp = getCacheTimeOut(defaultTimeOut);
	}

	/**
	 * 取得所有的 BS_COMPANY 資料。
	 * @return
	 */
	public static List<BsCompany> getList() {
		checkExpire();
		return list;
	}

	/**
	 * 檢核是否已超過設定的過期時間，若已超過就重新查詢。
	 */
	public static void checkExpire() {
		if (isExpire(timeoutstamp)) {
			log.debug(" Expire CacheTimeOut ");
			reload();
		}
	}

	/**
	 * 從 URL 或 IP 的附加參數取得網址識別碼。
	 * @return BS_COMPANY.URL_ID_CODE，取不到回傳 "tlw"。
	 */
	@SuppressWarnings("unchecked")
	public static String getUrlIdCode() {
		HttpServletRequest request = ServletActionContext.getRequest();
		Map<String, String[]> parameterMap = request.getParameterMap();// 取得 URL 附加參數
		
		// 判斷是否有附加參數 url_id_code 與其是否符合網址識別碼
		String url_id_code = "url_id_code";
		if (parameterMap.containsKey(url_id_code)) {
			String[] urlIdCode = (String[]) parameterMap.get(url_id_code);
			for (String code : urlIdCode) {
				if (StringUtils.isNotBlank(code)) {
					BsCompany bsCompany = getBsCompanyByCode(code);
					if (bsCompany != null) {
						return bsCompany.getUrlIdCode();
					}
				}
			}
		}
		throw new NullPointerException("invalid parameter 'url_id_code'");
	}

	/**
	 * 依網址識別碼取得 BS_COMPANY model。
	 * @param urlIdCode 網址識別碼。
	 * @return 取不到回傳 null。
	 */
	public static BsCompany getBsCompanyByCode(String urlIdCode) {
		for (BsCompany bsCompany : list) {
			if (bsCompany.getUrlIdCode().equalsIgnoreCase(urlIdCode)) {
				return bsCompany;
			}
		}
		return null;
	}

	/**
	 * 依公司別代碼取得 BS_COMPANY model。
	 * @param companyId 公司別代碼。
	 * @return 取不到回傳 null。
	 */
	public static BsCompany getBsCompanyById(String companyId) {
		for (BsCompany bsCompany : list) {
			if (bsCompany.getCompanyId().equals(companyId)) {
				return bsCompany;
			}
		}
		return null;
	}

	/**
	 * 從 Session 取得公司別代碼。
	 * @return 取不到拋出 RuntimeException。
	 */
	public static String getCompanyId() {
		HttpSession session = null;
		if (ServletActionContext.getRequest() != null) {
			session = ServletActionContext.getRequest().getSession();
		} else if (WebContextFactory.get() != null) {
			session = WebContextFactory.get().getSession();
		}
		if (session != null) {
			return (String) session.getAttribute(SESSION_BS_COMPANY_ID);
		} else{
			return "";
		}
	}
	
	/**
	 * 依採購組織取得公司別代碼.
	 * @param purchasingOrg 採購組織.
	 * @return 公司別代碼(取不到回傳 null).
	 */
	 public static String getCompanyIdByPurchasingOrg(final String purchasingOrg) {
		 for(BsCompany bsCompany:list){
			 if(StringUtils.equals(bsCompany.getPurchasingOrg(), purchasingOrg)){
				 return bsCompany.getCompanyId();
			 }
		 }
		 return null;
     }

	/**
	 * 依據商品據點取得公司別代碼。
	 * @param skuWerks 商品據點代碼。
	 * @return 公司別代碼，取不到回傳 null。
	 */
	public static String getCompanyIdBySkuWerks(String skuWerks) {
		for (BsCompany bsCompany : list) {
			if (bsCompany.getSkuWerks().equals(skuWerks)) {
				return bsCompany.getCompanyId();
			}
		}
		return null;
	}
	
	/**
	 * 依據通路代碼取得公司別資料.
	 * @param channelId 通路代碼
	 * @return BsCompany 公司別資料，查無資料時回傳 null
	 * @throws RuntimeException 取不到 BsStore 時拋出
	 */
	public static BsCompany getCompanyByChannelId(String channelId) throws RuntimeException {
		BsChannel bsChannel = BsChannelDefinition.getChannelByChannelId(channelId);
		if (bsChannel == null) {
			throw new RuntimeException("無法取得通路資料，ChannelId=" + channelId);
		}
		return getBsCompanyById(bsChannel.getCompanyId());
	}

	/**
	 * 依據店別代碼取得公司別資料.
	 * @param storeId 店別代碼
	 * @return BsCompany 公司別資料，查無資料時回傳 null
	 * @throws RuntimeException 傳入店號為99時拋出 總公司店號無法取得公司別資料
	 * @throws RuntimeException 取不到 BsStore 時拋出
	 */
	public static BsCompany getCompanyByStoreId(String storeId) throws RuntimeException {
//		if (BsStore.HQ_STOREID.equals(storeId)) {
//			throw new RuntimeException("總公司店號無法取得公司別資料");
//		}
		BsStore bsStore = BsStoreDefinition.getByStoreId(storeId);
		if (bsStore == null) {
			throw new RuntimeException("無法取得通路店別資料，StoreId="+storeId);
		}
		return getBsCompanyById(bsStore.getId().getCompanyId());
	}

	/**
	 * 依據據點代碼取得公司別資料.
	 * @param storeId 店別代碼
	 * @return BsCompany 公司別資料，查無資料時回傳 null
	 * @throws RuntimeException 取不到 BsStore 時拋出
	 */
	public static BsCompany getCompanyBySiteId(String siteId) throws RuntimeException {
		BsStore bsStore = BsStoreDefinition.getBySiteId(siteId);
		if (bsStore == null) {
			throw new RuntimeException("無法取得通路店別資料，SiteId="+siteId);
		}
		return getBsCompanyById(bsStore.getId().getCompanyId());
	}
	
	/**
	 * 依據 SAP 通路代碼取得公司別資料。
	 * @param sapChannelCode SAP通路代碼
	 * @return 公司別資料，查無資料時回傳 null
	 * @throws RuntimeException 傳入sapChannelCode為99時拋出 總公司店號無法取得公司別資料
	 * @throws RuntimeException 取不到 BsChannel 時拋出
	 */
	public static BsCompany getCompanyBySapChannelCode(String sapChannelCode) {
		if (BsChannel.HQ_SAP_CHANNEL.equals(sapChannelCode)) {
			throw new RuntimeException("總公司店號無法取得公司別資料");
		}
		BsChannel bsChannel = BsChannelDefinition.getChannelByChannelId(BsChannelDefinition.getChannelIdBySapCode(sapChannelCode));
		if(bsChannel == null) {
			throw new RuntimeException("無法取得通路資料，SapChannelCode = " + sapChannelCode);
		}
		return getBsCompanyById(bsChannel.getCompanyId());
	}
	
	public static String getSkuExistInNegBarcode() {
		checkExpire();
		return NegBarcode.get(getCompanyId());
	}
}