/**
 * @(#)BsCompanyDefinition.java 2014/09/12
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.gccs.util.cache;

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.bs.model.CcSettingMst;
import com.bnq.bs.service.IBsVariableService;
import com.bnq.util.AppContext;
import com.rfep.util.cache.BaseDefinition;

public class CcSettingMstDefinition extends BaseDefinition {
	private static final Logger log = LogManager.getLogger(CcSettingMstDefinition.class) ;
	static long timeoutstamp = 0L;
	private static CcSettingMst ccSettingMst ;
	private static List<CcSettingMst> list;
	
	public static List<CcSettingMst> getList() {
		return list;
	}

	public static void setList(List<CcSettingMst> list) {
		CcSettingMstDefinition.list = list;
	}
	static {
		init();
	}
	
	public static void reload(){
		init();
	}
	
	@SuppressWarnings("unchecked")
	private static void init() {
		log.debug(" Cache Init ");
		IBsVariableService service=(IBsVariableService)AppContext.getBean("bsVariableService");
		try {
			list = (List<CcSettingMst>)service.findAllCcSettingMst();
			setTimeOutStamp();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	private CcSettingMstDefinition() {
		
	}
	
	public static CcSettingMst getCcSettingMst(String channelId) {
		if(list==null){
			reload();
		}
		checkExpire();
		for (CcSettingMst cc : list) {
			if(cc.getChannelId().equals(channelId)){
				ccSettingMst = cc;
				return ccSettingMst;
			}
		}
		//default
		for (CcSettingMst cc : list) {
			if(cc.getChannelId().equals("OTHER")){
				ccSettingMst = cc;
				return ccSettingMst;
			}
		}
		return null;
	}
	
	public static Integer getTransDate() {
		return ccSettingMst.getTranDate();
	}
	
	public static Double getReturnMult() {
		return ccSettingMst.getReturnMult();
	}
	
	public static Double getFixCostMult() {
		return ccSettingMst.getCostMult();
	}
	
	public static int getReplyDays() {
		return ccSettingMst.getReplyDay().intValue() ;
	}
	
	public static int getCommonDays() {
		return ccSettingMst.getCommonDay().intValue() ;
	}
	
	public static int getCloseDays() {
		return ccSettingMst.getEffectDay().intValue() ;
	}
	
	public static int getCharge() {
		return ccSettingMst.getTranCharge().intValue() ;
	}
	
	public static int getqueryDays() {
		System.out.println(ccSettingMst.getQueryDay().intValue());
		return (0 - ccSettingMst.getQueryDay().intValue()) ;
	}
	
	public static String getBusinessDuty() {
		return new BigDecimal(String.valueOf(ccSettingMst.getBusinessDuty())).divide(new BigDecimal("100")).toString() ;
	}
	
	public static void setTimeOutStamp(){
		timeoutstamp = getCacheTimeOut(defaultTimeOut);
	}
	public static void checkExpire(){
		if( isExpire(timeoutstamp) ){
			log.debug(" Expire CacheTimeOut ");
			reload();
		}
	}
}