/*
 * Created on Feb 4, 2008
 */
package com.gccs.util.cache;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.AppContext;
import com.gccs.bs.model.BsCard;
import com.gccs.bs.service.BsCardService;
import com.rfep.util.cache.BaseDefinition;

/**
 * @author neo
 */
public class BsCardDefinition extends BaseDefinition{
	private static final Logger log = LogManager.getLogger(BsCardDefinition.class) ;
	static long timeoutstamp = 0L;
	public static List findAllCard = new ArrayList();//"CC01"
	
	static {
		init();
	}
	
	public static void reload(){
		findAllCard.clear();
		init();
	}
	
	private static void init() {
		log.debug(" Cache Init ");
		BsCardService bsCardService=(BsCardService)AppContext.getBean("bsCardService");
		try {
			findAllCard= bsCardService.findAllBsCard();
			setTimeOutStamp();
		} catch (Exception e) {
			log.error(e.getMessage(),e) ;
		}
	}
		
	public static List findAllCard(){
		List list = new ArrayList();
		Iterator iterator = getFindAllCard().iterator();
		while(iterator.hasNext()) {
			BsCard bsCard = (BsCard)iterator.next();
			
				list.add(bsCard);
		}
		return list;		
	}
	
	public static String getChannelDesc(String oid) {
		if(oid != null && !oid.equals("")) {
			Iterator iterator = getFindAllCard().iterator();
			while (iterator.hasNext()) {
				BsCard bsCard = (BsCard)iterator.next();
				if (bsCard.getOid().equals(oid)) {
					return bsCard.getCardName();
				}
			}
		}
		return "";
	}
	
	public static List getFindAllCard() {
		checkExpire();
		return findAllCard;
	}

	public static void setTimeOutStamp(){
		timeoutstamp = getCacheTimeOut(defaultTimeOut);
	}
	public static void checkExpire(){
		if( isExpire(timeoutstamp) ){
			log.debug(" Expire CacheTimeOut ");
			reload();
		}
	}
}