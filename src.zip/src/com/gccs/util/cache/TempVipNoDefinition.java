package com.gccs.util.cache;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.AppContext;
import com.rfep.util.cache.BaseDefinition;

public class TempVipNoDefinition extends BaseDefinition{
	private static List<String> tempVipNo = new ArrayList();
	private static final Logger log = LogManager.getLogger(TempVipNoDefinition.class);
	static long timeoutstamp = 0L;

	static {
		init() ;
	}

	public static void reload(){
		init();
	}	
	
	public static void clear() {
		tempVipNo.clear();
	}
	
	private static void init() {
		log.debug(" Cache Init ");
		com.bnq.util.sale.dao.hibernate.TempVipNoDAO service = 
			(com.bnq.util.sale.dao.hibernate.TempVipNoDAO)AppContext.getBean("tempVipNoDAO");
		try {
			tempVipNo = service.queryVipNo();
			setTimeOutStamp();
		} catch(Exception e) {
			log.error(e.getMessage(),e);
		}
	}
	
	
	/**
	 * 回傳是否優惠vipNo
	 * @param vipNo
	 * @return
	 * @throws Exception
	 */
	public static boolean getVipNo(String vipNo)throws Exception{
		if (StringUtils.isBlank(vipNo)){
			return Boolean.FALSE;
		}
		return Collections.binarySearch(getTempVipNo(), vipNo.trim())>=0;
	}
	
	public static List<String> getTempVipNo() {
		checkExpire();
		return tempVipNo;
	}

	public static void setTimeOutStamp(){
		timeoutstamp = getCacheTimeOut(defaultTimeOut);
	}
	public static void checkExpire(){
		if( isExpire(timeoutstamp) ){
			log.debug(" Expire CacheTimeOut ");
			reload();
		}
	}
}
