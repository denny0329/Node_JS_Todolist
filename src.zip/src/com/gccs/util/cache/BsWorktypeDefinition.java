package com.gccs.util.cache;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.AppContext;
import com.gccs.bs.dao.hibernate.BsWorkTypeDAO;
import com.gccs.bs.model.BsWorkType;
import com.rfep.util.cache.BaseDefinition;

public class BsWorktypeDefinition extends BaseDefinition{
	private static List<BsWorkType> list_1 = new ArrayList<BsWorkType>(); //行業別一
	private static List<BsWorkType> list_2 = new ArrayList<BsWorkType>(); //行業別二
	private static Map<String,List<BsWorkType>> map = new HashMap<String,List<BsWorkType>>();
	private static final Logger log = LogManager.getLogger(BsWorktypeDefinition.class) ;
	static long timeoutstamp = 0L;
	
	static {
		init();
	}
	
	public static void reload() {		
		list_1.clear();	
		list_2.clear();
		map.clear();
		init();
	}
	
	private static void init() {	
		log.debug(" Cache Init ");
		try {
			BsWorkTypeDAO dao = (BsWorkTypeDAO)AppContext.getBean("bsWorkTypeDAO");
			list_1 = dao.findAllForType01();
			list_2 = dao.findAllForType02();			
			
			List<BsWorkType> list = null;
			String key = null;
			for(BsWorkType vo : list_2) {
				key = vo.getParentWorkType().getWorkTypeId();
				list = map.get(key);
				if(list == null) {
					list = new ArrayList<BsWorkType>();	
					map.put(key, list);
				} 
				list.add(vo);
			}	
			setTimeOutStamp();
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	public static List<BsWorkType> findAllType01() {		
		return new ArrayList<BsWorkType>(getList_1());		
	}	
	
	public static List<BsWorkType> findAllType02(String codeId) {	
		List list = getMap().get(codeId);
		return (list==null) ? null : new ArrayList<BsWorkType>(getMap().get(codeId));	
	}
	
	public static void setTimeOutStamp(){
		timeoutstamp = getCacheTimeOut(defaultTimeOut);
	}
	public static void checkExpire(){
		if( isExpire(timeoutstamp) ){
			log.debug(" Expire CacheTimeOut ");
			reload();
		}
	}

	public static List<BsWorkType> getList_1() {
		checkExpire();
		return list_1;
	}

	public static List<BsWorkType> getList_2() {
		checkExpire();
		return list_2;
	}

	public static Map<String, List<BsWorkType>> getMap() {
		checkExpire();
		return map;
	}
}
