/**
 * @(#)BsStoreDefinition.java 2013/11/15
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.gccs.util.cache;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import com.bnq.util.AppContext;
import com.bnq.util.DateUtils;
import com.gccs.bs.dao.hibernate.BsManagerDao;
import com.gccs.bs.model.BsStore;
import com.gccs.bs.model.BsStoreId;
import com.opensymphony.xwork2.ActionContext;
import com.rfep.util.cache.BaseDefinition;

public class BsStoreDefinition extends BaseDefinition{
	private static List<BsStore> list = new ArrayList<BsStore>();
	private static final Logger log = LogManager.getLogger(BsStoreDefinition.class) ;
	static long timeoutstamp = 0L;
	static {
		init();
	}
	
	public static void reload() {
		list.clear();
		init();
	}
	
	private static void init() 
	{		
		log.debug(" Cache Init ");
		try {
			BsManagerDao dao = (BsManagerDao)AppContext.getBean("bsManagerDao");
			list = dao.findAllBsStore();
			setTimeOutStamp();
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	public static List<BsStore> getList() {
		checkExpire();
		return list;
	}
	
	

	public static List<BsStore> findAllBsStore() {
		List<BsStore> result = new ArrayList<BsStore>();
		for(Iterator<BsStore> it=getList().iterator(); it.hasNext();) {
			BsStore vo = it.next();
				
			if(vo.getStatus()==1) {
				result.add(vo);
			}			
		}		
		return result;				
	}		
	
	public static BsStore findBsStoreByStroeId(String storeId) {
		for(Iterator<BsStore> it=getList().iterator(); it.hasNext();) {
			BsStore vo = it.next();
			if(vo.getId().getStoreId().equals(storeId))
				return vo;
		}			
		return null;				
	}		
	
	/**
	 * 
	 * @param storeType 1:實體店;  2:倉庫;  3:非實體店;  4:其他
	 * @return
	 */
	public static List<BsStore> findAllBsStoreByStoreType(Integer storeType, String companyId) {
		List<BsStore> result = new ArrayList<BsStore>();
		for(Iterator<BsStore> it=getList().iterator(); it.hasNext();) {
			BsStore vo = it.next();
			if(vo.getStatus()==1) {
				//同公司才加入
				if(companyId.equals(vo.getId().getCompanyId())) {
					//storeType相同才加入
					if(storeType != null && vo.getStoreType() != null && storeType.compareTo(vo.getStoreType()) == 0) {
						result.add(vo);
					} else if(storeType == null && vo.getStoreType() == null)
						result.add(vo);
				}
			}			
		}		
		return result;		
	}			
	
	/**
	 * 依據 channelId 取得該通路符合以下規則的 bs_store 資料：<br>
	 * 1.store_id 不為 "99"<br>
	 * 2.status == 1(正常)
	 * @param channelId 通路代碼
	 * @return
	 */
	public static List<BsStore> findBsStoreByChannelId(String channelId) {				
		List<BsStore> result = new ArrayList<BsStore>();
		for(Iterator<BsStore> it=getList().iterator(); it.hasNext();) {
			BsStore vo = it.next();
			if(channelId != null && channelId.equals(vo.getId().getChannelId()) 
			   && vo.getStatus()==1) {
				result.add(vo);
			}			
		}		
		return result;	
	}
	
	/**
	 * 依據 channelId 取得該通路內所有符合以下規則的店別代碼：<br>
	 * 1.store_id 不為 "99"<br>
	 * 2.status == 1(正常)
	 * @param channelId 通路代碼
	 * @return
	 */
	public static List<String> getAllStoreByChannelId(String channelId) {
		ArrayList<String> result = new ArrayList<String>();
		
		if(StringUtils.isBlank(channelId)) return result;
		
		for(BsStore store : getList()) {
			if(channelId.equals(store.getId().getChannelId())&& store.getStatus() == 1) {
				result.add(store.getId().getStoreId());
			}
		}
		
		return result;
	}
	
	public static List<BsStore> findAllNotClosedBsStore(String channelId) {
		ActionContext actionContext = ActionContext.getContext();   
		Date today =DateUtils.getToday();
		List<BsStore> result = new ArrayList<BsStore>();
		for(Iterator<BsStore> it=getList().iterator(); it.hasNext();) {
			BsStore vo = it.next();
			
			if(channelId != null && channelId.equals(vo.getId().getChannelId()) &&vo.getId().getCompanyId().equals(actionContext.getSession().get("SESSION_BS_COMPANY_ID"))
			   && vo.getStatus()==1   &&  ( vo.getClosedDate()==null  ||  (vo.getClosedDate().compareTo(today)>=0 ) ||   
			   	(vo.getOpenDate().compareTo(vo.getClosedDate())==0)) && vo.getOpenDate()!=null ) {
				if("00672".equals(vo.getId().getStoreId())) continue;
				result.add(vo);
			}			
		}		
		return result;					
	}
	
	public static List<BsStore> findBsStoreByChannelIdStoreType(String channelId, Integer storeType) {				
		List<BsStore> result = new ArrayList<BsStore>();
		for(Iterator<BsStore> it=getList().iterator(); it.hasNext();) {
			BsStore vo = it.next();
			if(channelId != null && channelId.equals(vo.getId().getChannelId()) 
			   && vo.getStatus()==1) {
				//storeType相同才加入
				if(storeType != null && vo.getStoreType() != null && storeType.compareTo(vo.getStoreType()) == 0) {
					result.add(vo);
				}
					
				if(storeType == null && vo.getStoreType() == null)
					result.add(vo);
			}			
		}		
		return result;	
	}
	
	public static List<BsStore> findAllBsStoreInclude99() {
		List<BsStore> result = new ArrayList<BsStore>();
		for(Iterator<BsStore> it=getList().iterator(); it.hasNext();) {
			BsStore vo = it.next();
			if(vo.getStatus()==1) {
				result.add(vo);
			}			
		}		
		return result;			
	}	
	
	/**
	 * 
	 * @param storeType 1:實體店;  2:倉庫;  3:非實體店;  4:其他
	 * @return
	 */
	public static List<BsStore> findAllBsStoreByStoreTypeInclude99(Integer storeType) {
		List<BsStore> result = new ArrayList<BsStore>();
		for(Iterator<BsStore> it=getList().iterator(); it.hasNext();) {
			BsStore vo = it.next();
			if(vo.getStatus()==1) {
				//storeType相同才加入
				if(storeType != null && vo.getStoreType() != null && storeType.compareTo(vo.getStoreType()) == 0) {
					result.add(vo);
				}
					
				if(storeType == null && vo.getStoreType() == null)
					result.add(vo);
			}			
		}		
		return result;		
	}	
	
	public static List<BsStore> findBsStoreByChannelIdInclude99(String channelId) {				
		List<BsStore> result = new ArrayList<BsStore>();
		for(Iterator<BsStore> it=getList().iterator(); it.hasNext();) {
			BsStore vo = it.next();
			if(channelId.equals(vo.getId().getChannelId()) && vo.getStatus()==1){
				result.add(vo);
			}			
		}		
		return result;	
	}
	
	/**
	 * 
	 * @param channelId
	 * @param storeType 1:實體店;  2:倉庫;  3:非實體店;  4:其他
	 * @return
	 */
	public static List<BsStore> findBsStoreByChannelIdStoreTypeInclude99(String channelId, Integer storeType) {				
		List<BsStore> result = new ArrayList<BsStore>();
		for(Iterator<BsStore> it=getList().iterator(); it.hasNext();) {
			BsStore vo = it.next();
			if(channelId.equals(vo.getId().getChannelId()) && vo.getStatus()==1){
				//storeType相同才加入
				if(storeType != null && vo.getStoreType() != null && storeType.compareTo(vo.getStoreType()) == 0) {
					result.add(vo);
				}
					
				if(storeType == null && vo.getStoreType() == null)
					result.add(vo);
			}			
		}		
		return result;	
	}
	
	/**
	 * 依據通路店別取得門店資料。
	 * @param storeId 通路店別
	 * @return 找不到傳回 null。
	 * @deprecated 改用 getByStoreId(String storeId) 或 getIncludeHQ(String companyId, String storeId)
	 * @throws RuntimeException 傳入店號為99時拋出 總公司店號無法取得店別資料
	 */
	@Deprecated
	public static BsStore getBsStoreByStoreNo(String storeId) {
		// FIXME Need to delete
//		if (BsStore.HQ_STOREID.equals(storeId)) {
//			throw new RuntimeException("總公司店號無法取得店別資料");
//		}
		for(Iterator<BsStore> iterator = getList().iterator(); iterator.hasNext(); ) {
			BsStore store = iterator.next();
			if(store.getId().getStoreId().equals(storeId)) {
				return store;
			}
		}
		return null;
	}
	
	/**
	 * 依據 storeId 取得門店資料。
	 * @param storeId 通路店別
	 * @return
	 * @throws IllegalArgumentException 總公司店號不得使用本方法查詢
	 * @throws NullPointerException storeId 為空值、查無資料時拋出
	 */
	public static BsStore getByStoreId(String storeId) {
		if(StringUtils.isBlank(storeId)) throw new NullPointerException("通路店別為空值無法查詢門店資料！");
//		if(BsStore.HQ_STOREID.equals(storeId)) 
//			throw new IllegalArgumentException("總公司店號必須要指定公司別才能查詢！");
		
		for(Iterator<BsStore> iterator = getList().iterator(); iterator.hasNext(); ) {
			BsStore store = iterator.next();
			if(storeId.equalsIgnoreCase(store.getId().getStoreId())) {
				return store;
			}
		}
		
		throw new NullPointerException("依據通路店別[" + storeId + "]查無門店資料。");
	}
	
	/**
	 * 依據 siteId 取得門店資料。
	 * @param siteId SAP 門店代碼
	 * @return
	 * @throws NullPointerException siteId 為空值、查無資料時拋出
	 */
	public static BsStore getBySiteId(String siteId) {
		if(StringUtils.isBlank(siteId)) throw new NullPointerException("門店代碼為空值無法查詢門店資料！");
		
		for(Iterator<BsStore> iterator = getList().iterator(); iterator.hasNext(); ) {
			BsStore store = iterator.next();
			if(siteId.equalsIgnoreCase(store.getSiteId())) {
				return store;
			}
		}
		
		throw new NullPointerException("依據門店代碼[" + siteId + "]查無門店資料。");
	}
	
	/**
	 * 依據 companyId, storeId 取得門店資料。<br>
	 * 建議當 storeId 有可能包含總公司店號(99)時才用本方法。
	 * @param companyId 公司別
	 * @param storeId 通路店別
	 * @return
	 * @throws NullPointerException companyId 或 storeId 為空值、查無資料時拋出
	 */
	public static BsStore getIncludeHQ(String companyId, String storeId) {
		if(StringUtils.isBlank(companyId) || StringUtils.isBlank(storeId))
			throw new NullPointerException("公司別[" + companyId + "]或通路店別[" + storeId + "]為空值無法查詢門店資料！");
		
		for(Iterator<BsStore> iterator = getList().iterator(); iterator.hasNext(); ) {
			BsStore store = iterator.next();
			if(companyId.equalsIgnoreCase(companyId) && storeId.equalsIgnoreCase(store.getId().getStoreId())) {
				return store;
			}
		}
		
		throw new NullPointerException("依據公司別[" + companyId + "]、通路店別[" + storeId + "]查無門店資料。");
	}
	
	/**
	 * 依據通路店別、公司別代碼取得門店資料。
	 * @param storeId 通路店別
	 * @param companyId 公司別代碼
	 * @return 查無資料回傳 null
	 */
	public static BsStore getBsStoreByStoreNo(String storeId, String companyId) {
		for(Iterator<BsStore> iterator = getList().iterator(); iterator.hasNext(); ) {
			BsStore store = iterator.next();
			if(storeId.equalsIgnoreCase(store.getId().getStoreId()) && companyId.equalsIgnoreCase(store.getId().getCompanyId())) {
				return store;
			}
		}
		return null;
	}
	
	/**
	 * 依據 siteId 取得 BS_STORE 資料。
	 * @param siteId SAP店別代碼
	 * @return 傳回符合 siteId 的 BsStore，否則傳回 null。
	 * @deprecated 改用 getBySiteId(String siteId)
	 */
	@Deprecated
	public static BsStore getBsStoreBySiteId(String siteId) {
		// FIXME Need to delete
		if(StringUtils.isBlank(siteId)) return null;
		
		BsStore rtv = null;
		for(Iterator<BsStore> iterator = getList().iterator(); iterator.hasNext(); ) {
			BsStore store = iterator.next();
			if(siteId.equals(store.getSiteId())) {
				rtv = store;
				break;
			}
		}
		return rtv;
	}
	
	/**
	 * 依據 storeNo 取得 ChannelId。
	 * @param storeNo 通路店別
	 * @return 若查無資料回傳 ""。
	 */
	public static String getChannelIdByStoreNo(String storeNo) {
		try {
			return getByStoreId(storeNo).getId().getChannelId();
		} catch(Exception e) {
			return "";
		}
	}
	
	/**
	 * 傳入storeNO,回傳bsstore companyId
	 * @param storeNo
	 * @return 公司代碼
	 */
	public static String getCompanyIdByStoreNo(String storeNo) {
		BsStore store = getBsStoreByStoreNo(storeNo);
		if(store!=null)
			return store.getId().getCompanyId();
		return "";
	}
	
	public static String getStoreDesc(String storeId) {
		BsStore store = getBsStoreByStoreNo(storeId);
		if(store != null) {
			return store.getId().getStoreId() + "-" + store.getStoreName1(); 
		} else {
			return "";
		}
	}
	
	public static String getStoreName(String storeId){
		BsStore store = getBsStoreByStoreNo(storeId);
		if(store != null) {
			return store.getId().getStoreId() + "-" + store.getStoreName2(); 
		} else {
			return "";
		}
	}

	/**
	 * 取 CAL_ID
	 * @param channelId
	 * @param storeId
	 * @return
	 */
	public static String getCalId(String storeId){
		BsStore store = getBsStoreByStoreNo(storeId); 
		return store!=null?store.getCalId():null;
	}
	
	/**
	 * 將 4 碼 siteId 對應成 storeId
	 * @param siteId SAP店別代碼
	 * @return 若有對應的 BsStore 則傳回 storeId，否則回傳 siteId
	 */
	public static String siteIdToStoreId(String siteId){
		BsStore store = getBsStoreBySiteId(siteId);
		return store == null ? siteId : store.getId().getStoreId();
	}
	
	/**
	 * 將 storeId 對應成 4 碼 siteId
	 * @param storeId 店別代碼
	 * @return 若有對應的 BsStore 則傳回 siteId，否則回傳 storeId
	 */
	public static String storeIdToSiteId(String storeId){
		BsStore store = getBsStoreByStoreNo(storeId); 
		return store == null ? storeId : store.getSiteId();
	}

	/**
	 * 將 storeId 對應成 4 碼 siteId<br>
	 * 當 static parame 找不到時，重新由 DB 撈取符合 channelId、storeId 的最新資料。
	 * 
	 * @param channelId 通路代碼
	 * @param storeId 店別代碼
	 * @return 若有對應的 BsStore 則傳回 siteId，否則回傳 storeId
	 */
	public static String storeIdToSiteId(String channelId, String storeId){
		BsStore store = getBsStoreByStoreNo(storeId); 
		if( store == null && channelId!= null && storeId != null ){
			BsStoreId bsId = new BsStoreId(channelId.trim(),storeId.trim());
			BsManagerDao dao = (BsManagerDao)AppContext.getBean("bsManagerDao");
			store = dao.loadStoreById(bsId);
		}
		return store!=null?store.getSiteId():storeId;
	}
	
	/**
	 * 傳入 storeId 或 siteId
	 * @param storeOrSiteId
	 * @return
	 */
	public static boolean isStore(String storeOrSiteId){
		if(storeOrSiteId!=null){
			BsStore store = getBsStoreByStoreNo(storeOrSiteId); 
			if(store!=null){
				return true;
			}
			store = getBsStoreBySiteId(storeOrSiteId); 
			if(store!=null){
				return true;
			}
		}
		return false;
	}
	
	/**
	 * 傳入 storeId 回傳storeType 1:實體店;  2:倉庫;  3:非實體店;  4:其他
	 * @param storeNo
	 * @return storeType
	 */
	public static Integer getStoreTypeByStoreId(String storeNo) {
		BsStore store = getByStoreId(storeNo);
		if(store!=null) {
			return store.getStoreType();
		} else {
			return null;
		}
	}
	
	public static void setTimeOutStamp(){
		timeoutstamp = getCacheTimeOut(defaultTimeOut);
	}
	
	public static void checkExpire(){
		if( isExpire(timeoutstamp) ){
			log.debug(" Expire CacheTimeOut ");
			reload();
		}
	}

	/**
	 * 依據 companyId 找出對應的總公司 siteId。
	 * @param companyId 公司別代碼
	 * @return
	 * @throws NullPointerException 公司別代碼為空值無法找出對應的總公司SAP店別代碼
	 * @throws NullPointerException 沒有對應的總公司門店資料，請洽系統管理員新增
	 */
	public static String getHQSiteId(String companyId) throws NullPointerException, RuntimeException {
		if(StringUtils.isBlank(companyId))
			throw new NullPointerException("公司別代碼為空值無法找出對應的總公司SAP店別代碼。");
		
		for(BsStore bsStore : list) {
			if(bsStore.getId().getCompanyId().equals(companyId) && BsStore.HQ_STOREID.equals(bsStore.getId().getStoreId())) {
				return bsStore.getSiteId();
			}
		}
		
		throw new NullPointerException("公司別代碼:" + companyId + ", 沒有對應的總公司門店資料，請洽系統管理員新增。");
	}
}