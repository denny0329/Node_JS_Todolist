/*
 * Created on Feb 4, 2008
 */
package com.gccs.util.cache;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.AppContext;
import com.gccs.bs.model.BsChannel;
import com.gccs.bs.service.BsParaService;
import com.rfep.bs.model.BsPara;
import com.rfep.util.cache.BaseDefinition;

/**
 * @author neo
 */
public class BsParaDefinition extends BaseDefinition{
	private static final Logger log = LogManager.getLogger(BsParaDefinition.class) ;
	static long timeoutstamp = 0L;
	public static List<BsChannel> findAllChannel = new ArrayList<BsChannel>();//"CC01"
	private static final String _exceptionPrefix = "HQ" ;
	private static BsParaService bsParaService;
	
	static {
		init();
	}
	
	public static void reload(){
		findAllChannel.clear();
		init();
	}
	
	private static void init() {
		log.debug(" Cache Init ");
		bsParaService=(BsParaService)AppContext.getBean("bsParaService");
		try {
			setTimeOutStamp();
		} catch (Exception e) {
			log.error(e.getMessage(),e) ;
		}
	}
	
	public static String getExceptionPrefix() {
		return _exceptionPrefix;
	}

	public static List<BsPara> getFindAllParaForStoTransferOutApply() throws Exception{
		checkExpire();
		return bsParaService.findBsParaList("STO_STORE", "APPLY_CHANNEL");
	}
	
	public static List<BsPara> getFindAllParaForInventoryInit() throws Exception{
		checkExpire();
		return bsParaService.findBsParaList("YEAR", "BEGINNING_INV");
	}
	
	public static void setTimeOutStamp(){
		timeoutstamp = getCacheTimeOut(defaultTimeOut);
	}
	public static void checkExpire(){
		if( isExpire(timeoutstamp) ){
			log.debug(" Expire CacheTimeOut ");
			reload();
		}
	}
}
