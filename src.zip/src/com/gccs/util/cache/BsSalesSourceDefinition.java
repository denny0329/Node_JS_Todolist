package com.gccs.util.cache;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.AppContext;
import com.gccs.bs.model.BsSalesSource;
import com.gccs.bs.service.BsSalesSourceService;
import com.rfep.util.cache.BaseDefinition;

public class BsSalesSourceDefinition extends BaseDefinition{
	private static List<BsSalesSource> list = new ArrayList<BsSalesSource>();
	private static final Logger log = LogManager.getLogger(BsSalesSourceDefinition.class) ;
	static long timeoutstamp = 0L;
	static {
		init();
	}
	
	public static void reload() {
		list.clear();		
		init();
	}
	
	private static void init() {
		log.debug(" Cache Init ");
		try {
			BsSalesSourceService service = (BsSalesSourceService)AppContext.getBean("bsSalesSourceService");
			list = service.findAll();	
			setTimeOutStamp();
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	public static List<BsSalesSource> findAll() {
		List<BsSalesSource> result = new ArrayList<BsSalesSource>();
		for(Iterator<BsSalesSource> it = getList().iterator(); it.hasNext();) {
			result.add(it.next());					
		}		
		return result;		
	}		
	
	public static List<BsSalesSource> getList() {
		checkExpire();
		return list;
	}

	public static void setTimeOutStamp(){
		timeoutstamp = getCacheTimeOut(defaultTimeOut);
	}
	public static void checkExpire(){
		if( isExpire(timeoutstamp) ){
			log.debug(" Expire CacheTimeOut ");
			reload();
		}
	}
}