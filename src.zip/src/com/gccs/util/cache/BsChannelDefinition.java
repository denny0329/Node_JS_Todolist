/*
 * Created on Feb 4, 2008
 */
package com.gccs.util.cache;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.AppContext;
import com.gccs.bs.model.BsChannel;
import com.gccs.bs.service.BsChannelService;
import com.gccs.member.model.BrandVo;
import com.rfep.util.cache.BaseDefinition;

/**
 * @author neo
 */
public class BsChannelDefinition extends BaseDefinition{
	private static final Logger log = LogManager.getLogger(BsChannelDefinition.class) ;
	static long timeoutstamp = 0L;
	public static List<BsChannel> findAllChannel = new ArrayList<BsChannel>();//"CC01"
	private static final String _exceptionPrefix = "HQ" ;
	
	static {
		init();
	}
	
	public static void reload(){
		findAllChannel.clear();
		init();
	}
	
	private static void init() {
		log.debug(" Cache Init ");
		BsChannelService bsChannelService=(BsChannelService)AppContext.getBean("bsChannelService");
		try {
			findAllChannel= bsChannelService.findAll();
			setTimeOutStamp();
		} catch (Exception e) {
			log.error(e.getMessage(),e) ;
		}
	}
	
	public static List<BsChannel> getFindAllChannel() {
		checkExpire();
		return findAllChannel;
	}

	public static String getExceptionPrefix() {
		return _exceptionPrefix;
	}

	/**
	 * 不含非實體通路
	 * @return BsChannel List
	 */
	public static List<BsChannel> findAllChannel(){
		List<BsChannel> list = new ArrayList<BsChannel>();
		Iterator<BsChannel> iterator = getFindAllChannel().iterator(); 
		String companyId = BsCompanyDefinition.getCompanyId();
		while(iterator.hasNext()) {
			BsChannel bsChannel = iterator.next();
			if(bsChannel.getPhChannel() != 1) {
				continue ;
			}
			if(StringUtils.isNotEmpty(companyId)&&!companyId.equals(bsChannel.getCompanyId()))
				continue;
			if(bsChannel.getStatus())
				list.add(bsChannel);
		}
		return list;
	}
	
	public static List<BsChannel> findAllChannel(String companyId){
		List<BsChannel> list = new ArrayList<BsChannel>();
		Iterator<BsChannel> iterator = getFindAllChannel().iterator(); 
		while(iterator.hasNext()) {
			BsChannel bsChannel = iterator.next();
			if(bsChannel.getChannelId().startsWith(_exceptionPrefix)
			   || bsChannel.getPhChannel() != 1) {
				continue ;
			}
			if(StringUtils.isNotEmpty(companyId)&&!companyId.equals(bsChannel.getCompanyId()))
				continue;
			if(bsChannel.getStatus())
				list.add(bsChannel);
		}
		return list;
	}
	
	/**
	 * 取得Channel包含總公司和非實體通路
	 * @return BsChannel List
	 */
	public static List<BsChannel> findAllChannelIncludeHQ() {
		List<BsChannel> list = new ArrayList<BsChannel>();
		Iterator<BsChannel> iterator = getFindAllChannel().iterator();
		while(iterator.hasNext()) {
			BsChannel bsChannel = iterator.next();	
			if(bsChannel.getStatus()) 
				list.add(bsChannel);
		}
		return list;		
	}
	
	/**
	 * 取得Channel包含總公司但不包含非實體通路(ph_channel=>0:非實體通路/1:實體通路)
	 * @return BsChannel List
	 */
	public static List<BsChannel> findAllChannelIncludeHQ2() {
		List<BsChannel> list = new ArrayList<BsChannel>();
		Iterator<BsChannel> iterator = getFindAllChannel().iterator();
		while(iterator.hasNext()) {
			BsChannel bsChannel = iterator.next();	
			if(bsChannel.getStatus() && bsChannel.getPhChannel()==1) 
				list.add(bsChannel);
		}
		return list;		
	}
	
	/**
	 * 取得Channel不含總公司但包含非實體通路(ph_channel=>0:非實體通路/1:實體通路)
	 * @return BsChannel List
	 */
	public static List<BsChannel> findAllChannelIncludeHQ3() {
		List<BsChannel> list = new ArrayList<BsChannel>();
		Iterator<BsChannel> iterator = getFindAllChannel().iterator();
		while(iterator.hasNext()) {
			BsChannel bsChannel = iterator.next();	
			if(bsChannel.getChannelId().startsWith(_exceptionPrefix)) {
				continue ;
			}
			
			list.add(bsChannel);		
		}
		return list;		
	}
	
	/**
	 * 依據 companyId 找出其所有通路的通路代碼資料。
	 * @param companyId 公司別代碼
	 * @return 找不到資料回傳空 List
	 */
	public static List<String> findAllChannelInCompany(String companyId) {
		List<String> result = new ArrayList<String>();
		
		if(StringUtils.isBlank(companyId)) {
			return result;
		}
		
		for(BsChannel channel : getFindAllChannel()) {
			if(companyId.equals(channel.getCompanyId())) {
				result.add(channel.getChannelId());
			}
		}
		
		return result;
	}

	public static String getChannelDesc(String channelId) {
		if(channelId != null && !channelId.equals("")) {
			Iterator<BsChannel> iterator = getFindAllChannel().iterator();
			while (iterator.hasNext()) {
				BsChannel bsChannel = iterator.next();
				if (bsChannel.getChannelId().equals(channelId)) {
					return bsChannel.getChannelId() + "-"
							+ bsChannel.getChannelName1();
				}
			}
		}
		return "";
	}
	
	/**
	 * 依據通路別代碼取得通路資料。
	 * @param channelId 通路別
	 * @return 查無相符資料回傳 Null
	 * @throws RuntimeException 傳入channelId為HQ時拋出 總公司通路別無法取得通路資料
	 */
	public static BsChannel getChannelByChannelId(String channelId) {
//		if (BsChannel.HQ_CHANNEL.equals(channelId)) {
//			throw new RuntimeException("總公司通路別無法取得通路資料");
//		}
		BsChannel rtv = null;
		if(StringUtils.isNotBlank(channelId)) {
			for(BsChannel bsChannel: getFindAllChannel()) {
				if (bsChannel.getChannelId().equals(channelId)) {
					rtv = bsChannel;
					break;
				}
			}
		}
		return rtv;
	}
	
	/**
	 * 依據通路別及公司別取得通路資料。
	 * @param channelId 通路別代碼
	 * @param companyId 公司別代碼
	 * @return 查無相符資料回傳 null
	 */
	public static BsChannel getChannelByChannelId(String channelId, String companyId) {
		BsChannel rtv = null;
		if(StringUtils.isNotBlank(channelId) && StringUtils.isNotBlank(companyId)) {
			for(BsChannel bsChannel: getFindAllChannel()) {
				if (channelId.equalsIgnoreCase(bsChannel.getChannelId()) && companyId.equalsIgnoreCase(bsChannel.getCompanyId())) {
					return bsChannel;
				}
			}
		}
		return rtv;
	}
	
	public static String getChannelName1(String channelId) {
		String rtv = "";
		if(StringUtils.isNotBlank(channelId)) {
			for(BsChannel bsChannel: getFindAllChannel()) {
				if (bsChannel.getChannelId().equals(channelId)) {
					rtv = bsChannel.getChannelName1();
					break;
				}
			}
		}
		return rtv;
	}
	
	public static BsChannel getChannelByChannelPos(String channelPos) {
		BsChannel rtv = null;
		if(StringUtils.isNotBlank(channelPos)) {
			for(BsChannel bsChannel: getFindAllChannel()) {
				if (bsChannel.getChannelPos().equals(channelPos)) {
					rtv = bsChannel;
					break;
				}
			}
		}
		return rtv;
	}

	public static String getChannelName(String channelId){
		BsChannel channel = BsChannelDefinition.getChannelByChannelId(channelId);
		if( channel != null )
			return channel.getChannelId() + "-" + channel.getChannelName1();
		else
			return null;
	}
	
	/**
	 * 依據 SAP 的通路代碼，取得 OMS 的通路代碼。
	 * @param sapChannelCode SAP的通路代碼
	 * @return 通路代碼
	 * @throws RuntimeException 傳入sapChannelCode為99時拋出 總公司店號無法取得通路代碼
	 */
	public static String getChannelIdBySapCode(String sapChannelCode) {
		String channelId = "";
		if (BsChannel.HQ_SAP_CHANNEL.equals(sapChannelCode)) {
			throw new RuntimeException("總公司店號無法取得通路代碼");
		}
		if(StringUtils.isNotBlank(sapChannelCode)) {
			for(BsChannel bsChannel: getFindAllChannel()) {
				if (bsChannel.getSapChannelCode() != null && 
						bsChannel.getSapChannelCode().equals(sapChannelCode)) {
					channelId = bsChannel.getChannelId() ;
					break;
				}
			}
		}
		return channelId;
	}
	
	/**
	 * 依據 SAP 的通路代碼，取得 OMS 的通路代碼。
	 * @param companyId 公司別代碼
	 * @param sapChannelCode SAP的通路代碼
	 * @return 通路代碼
	 * @throws RuntimeException 傳入sapChannelCode為99時拋出 總公司店號無法取得通路代碼
	 */
	public static String getChannelIdBySapCode(String companyId, String sapChannelCode) {
		String channelId = "";
		if(StringUtils.isNotBlank(sapChannelCode)) {
			for(BsChannel bsChannel: getFindAllChannel()) {
				if (bsChannel.getSapChannelCode() != null && bsChannel.getSapChannelCode().equalsIgnoreCase(sapChannelCode) && 
					bsChannel.getCompanyId() != null && bsChannel.getCompanyId().equalsIgnoreCase(companyId)) {
					channelId = bsChannel.getChannelId() ;
					break;
				}
			}
		}
		return channelId;
	}
	
	/**
	 * 
	 * @param channelId
	 * @return
	 * @throws RuntimeException 傳入channelId為HQ時拋出 總公司通路別無法取得SAP通路代碼
	 */
	public static String getSapChannelCodeByChannelId(String channelId) {
//		if (BsChannel.HQ_CHANNEL.equals(channelId)) {
//			throw new RuntimeException("總公司通路別無法取得SAP通路代碼");
//		}
		String rtv = "";
		if(StringUtils.isNotBlank(channelId)) {
			for(BsChannel bsChannel: getFindAllChannel()) {
				if (bsChannel.getChannelId() != null && 
						bsChannel.getChannelId().equals(channelId)) {
					rtv = bsChannel.getSapChannelCode() ;
					break;
				}
			}
		}
		return rtv;
	}
	
	public static void setTimeOutStamp(){
		timeoutstamp = getCacheTimeOut(defaultTimeOut);
	}
	public static void checkExpire(){
		if( isExpire(timeoutstamp) ){
			log.debug(" Expire CacheTimeOut ");
			reload();
		}
	}
	
	public static List<BrandVo> findBrand(String gNo,String companyId){
		try {
			BsChannelService bsChannelService=(BsChannelService)AppContext.getBean("bsChannelService");
			return bsChannelService.findBrand(gNo,companyId);
		} catch (Exception e) {
			log.error(e.getMessage(),e) ;
		}
		return null;
	}
	
	public static List<BrandVo> findAllBrand(){
		try {
			BsChannelService bsChannelService=(BsChannelService)AppContext.getBean("bsChannelService");
			return bsChannelService.findAllBrand();
		} catch (Exception e) {
			log.error(e.getMessage(),e) ;
		}
		return null;
	}
	
}
