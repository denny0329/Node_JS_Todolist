package com.gccs.util.dwr;

import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.InetAddress;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.BigDecimalConverter;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.directwebremoting.WebContextFactory;
import org.keycloak.adapters.RefreshableKeycloakSecurityContext;

import com.bnq.bs.model.BsCode;
import com.bnq.cs.cc.service.ICommentService;
import com.bnq.cs.pm.service.IPrdSerService;
import com.bnq.sc.model.ScSysuser;
import com.bnq.util.ADAuth;
import com.bnq.util.AppContext;
import com.bnq.util.DateTimeUtils;
import com.bnq.util.QueryResult;
import com.bnq.util.WebServiceUtils;
import com.bnq.util.cache.BsCodeDefinition;
import com.gccs.base.action.BaseAction;
import com.gccs.bonus.service.BcBonusTemporalService;
import com.gccs.bs.model.BsCompany;
import com.gccs.bs.service.BsCompanyService;
import com.gccs.marketing.model.Discount;
import com.gccs.marketing.model.vo.DiscountVo;
import com.gccs.marketing.service.MarketingService;
import com.gccs.marketing.util.DiscountSelectItem;
import com.gccs.member.action.AdvanceCardAction;
import com.gccs.member.action.MemberBaseAction;
import com.gccs.member.card.model.MmCard;
import com.gccs.member.dao.hibernate.MtVipMasterDAO;
import com.gccs.member.model.Account;
import com.gccs.member.model.AccountHq;
import com.gccs.member.model.Members;
import com.gccs.member.model.MembersEcSycn;
import com.gccs.member.model.MembersRemark;
import com.gccs.member.model.MmLineMst;
import com.gccs.member.model.MmMbPhoneReg;
import com.gccs.member.model.MmMembersAgree;
import com.gccs.member.model.MmMembersAgreeBak;
import com.gccs.member.model.MmPosVipCulmMaster;
import com.gccs.member.model.MmPosVipCulmMasterVo;
import com.gccs.member.model.vo.AppMemberVo;
import com.gccs.member.model.vo.AppPayCardVo;
import com.gccs.member.model.vo.AppPaySumByChannelVo;
import com.gccs.member.model.vo.MemberLikeVo;
import com.gccs.member.model.vo.MemberVo;
import com.gccs.member.model.vo.MmCardQueryCondition;
import com.gccs.member.model.vo.QueryBonusRespVo;
import com.gccs.member.service.AccountService;
import com.gccs.member.service.CardService;
import com.gccs.member.service.IMembersEcSycnService;
import com.gccs.member.service.IMembersRemarkService;
import com.gccs.member.service.MemberService;
import com.gccs.member.service.MtGroupVipService;
import com.gccs.member.util.AppPayStaticString;
import com.gccs.member.util.MemberGlossary;
import com.gccs.member.vo.MemberGiftTicketSeqVO;
import com.gccs.mmbonus.model.MmMembersBonus;
import com.gccs.mmbonus.service.MmBonusService;
import com.gccs.util.cache.BsCompanyDefinition;
import com.gccs.util.log.model.CrmWebServiceLog;
import com.gccs.util.log.service.ModifyService;
import com.gccs.util.model.AppMemberQuery;
import com.gccs.util.model.AppQueryBonusData;
import com.gccs.util.model.AppQueryPayCardNoData;
import com.gccs.util.model.MemberLikeCount;
import com.gccs.util.model.MemberLikeQuery;
import com.gccs.util.web.SelectItem;
import com.gccs.ws.service.BaseWebService;
import com.opensymphony.xwork2.Action;
import com.trg.oms.externalWS.ExternalWSClient;
import com.trg.oms.externalWS.ec.mobileVerify.CheckMobileVerifyCodeResponse;
import com.trg.oms.externalWS.ec.mobileVerify.DoCheckMobileVerifyCode;
import com.trg.oms.externalWS.ec.mobileVerify.DoVerifyMobile;
import com.trg.oms.externalWS.ec.mobileVerify.MobileVerifyService;
import com.trg.oms.externalWS.ec.mobileVerify.ObjectFactory;
import com.trg.oms.externalWS.ec.mobileVerify.SendMobileVerifyResponse;
import com.trg.oms.externalWS.ec.mobileVerify.SynCustomerService;
import com.trg.oms.externalWS.ec.mobileVerify.SyncTestriteCustomerResponse;

@SuppressWarnings("all")
public class MembersDwrAction extends BaseAction{
	private static final long serialVersionUID = 4698852967688826900L;

	private static final Logger log = LogManager.getLogger(MembersDwrAction.class) ;
	private static final String staff_cardType = "2"; // 員工卡折扣
	private static final String visitant_cardType = "7"; // 貴賓卡折扣
	private static final String friends_cardType = "3"; // 親友卡折扣
	
	private MemberService memberService;
	private MmBonusService mmBonusService;
	private AccountService accountService;
	private CardService cardService;
	private MarketingService marketingService;
	private BcBonusTemporalService bcBonusTemporalService;
	private IPrdSerService prdSerService;
	private ICommentService ccService ;
	private IMembersRemarkService membersRemarkService; 
	private IMembersEcSycnService membersEcSycnService;
	private ExternalWSClient externalWSClient;
	
	private String[] createCardArray;
	private String accountId;
	private String doCreateUtilCardVipNoList = "doCreateUtilCardVipNoList";
	private String memberOid;
	private Integer bonusTotal;
	private String loginChannelId;
	private long DeductionTotal;
	private String memberId;
	private String channelId;
	private String companyId;
	
	private MembersRemark membersRemark;
	private String remark;
	private BsCompanyService bsCompanyService;
	private MtGroupVipService mtGroupVipService;
	private MtVipMasterDAO mtVipMasterDao;
	private String syncFlag;
	private MemberBaseAction memberBaseAction;
	private String userID;
	private String userName;
	private String regularCustomerUrl;
	
	public String getLoginChannelId() {
		return loginChannelId;
	}
	public void setLoginChannelId(String loginChannelId) {
		this.loginChannelId = loginChannelId;
	}
	public ExternalWSClient getExternalWSClient() {
		return externalWSClient;
	}
	public void setExternalWSClient(ExternalWSClient externalWSClient) {
		this.externalWSClient = externalWSClient;
	}
	public long getDeductionTotal() {
		return DeductionTotal;
	}
	public void setDeductionTotal(long deductionTotal) {
		DeductionTotal = deductionTotal;
	}
	public Integer getBonusTotal() {
		return bonusTotal;
	}
	public void setBonusTotal(Integer bonusTotal) {
		this.bonusTotal = bonusTotal;
	}
	public String getMemberOid() {
		return memberOid;
	}
	public void setMemberOid(String memberOid) {
		this.memberOid = memberOid;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String[] getCreateCardArray() {
		return createCardArray;
	}
	public void setCreateCardArray(String[] createCardArray) {
		this.createCardArray = createCardArray;
	}
	public CardService getCardService() {
		return cardService;
	}
	public void setCardService(CardService cardService) {
		this.cardService = cardService;
	}
	public AccountService getAccountService() {
		return accountService;
	}
	public void setAccountService(AccountService accountService) {
		this.accountService = accountService;
	}
	public MemberService getMemberService() {
		return memberService;
	}
	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}
	public MarketingService getMarketingService() {
		return marketingService;
	}
	public void setMarketingService(MarketingService marketingService) {
		this.marketingService = marketingService;
	}
	public BcBonusTemporalService getBcBonusTemporalService() {
		return bcBonusTemporalService;
	}
	public void setBcBonusTemporalService(BcBonusTemporalService bcBonusTemporalService) {
		this.bcBonusTemporalService = bcBonusTemporalService;
	}
	public IPrdSerService getPrdSerService() {
		return prdSerService;
	}
	public void setPrdSerService(IPrdSerService prdSerService) {
		this.prdSerService = prdSerService;
	}
	public ICommentService getCcService() {
		return ccService;
	}
	public void setCcService(ICommentService ccService) {
		this.ccService = ccService;
	}
	public IMembersEcSycnService getMembersEcSycnService() {
		return membersEcSycnService;
	}
	public void setMembersEcSycnService(IMembersEcSycnService membersEcSycnService) {
		this.membersEcSycnService = membersEcSycnService;
	}
	public MmBonusService getMmBonusService() {
		return mmBonusService;
	}
	public void setMmBonusService(MmBonusService mmBonusService) {
		this.mmBonusService = mmBonusService;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getRegularCustomerUrl() {
		return regularCustomerUrl;
	}
	public List doCheckHqId(String id,String oid) throws Exception{
		List list = this.memberService.checkHqId(id,oid);
		return list;
	}
	public List doCheckpersonId(String id,String oid) throws Exception{
		List list = this.memberService.getMemberByPersonIdWithDiffOid(id,oid);
		return list;
	}
	public List doCheckeEmpId(String empPersonId) throws Exception{
		List list = this.memberService.getMembersByEmployeePersonId(empPersonId);
		return list;
	}
	public List getCardByDiscCardOid(String memberId,String disOid)throws Exception{
		List<MmCard> list = this.getCardService().findMmCardByDiscCardOid(memberId,disOid);
		return list;
	}
	public List doCheckpersonIdFromAccount(String id,String oid) throws Exception{
		List list = this.accountService.checkpersonIdFromAccount(id,oid);
		return list;
	}
	public void doUpdateMemberStatusByOid(String status,String resulm,String oid) throws Exception{
		Members oldMember = memberService.findMemberByOid(oid);
		this.memberService.updateMemberStatus(Integer.parseInt(status),resulm, null, null,oid);
		Members member = memberService.findMemberByOid(oid);
		ModifyService modifyService = (ModifyService)AppContext.getBean("modifyService");
		modifyService.createModifyRecord(member.getOid(), oldMember, member, this.getUser().getUserId(), this.getUser().getUserName());
	}
	public void doUpdateMemberStatusByOid2(String status,String resulm,String oid) throws Exception{
		Members oldMember = memberService.findMemberByOid(oid);
		this.memberService.updateMemberStatus2(Integer.parseInt(status),resulm,null,null,oid,this.getUser().getUserId(), this.getUser().getUserName());
		Members member = memberService.findMemberByOid(oid);
		ModifyService modifyService = (ModifyService)AppContext.getBean("modifyService");
		modifyService.createModifyRecord(member.getOid(), oldMember, member, this.getUser().getUserId(), this.getUser().getUserName());
	}

	public Map loadBussinessAccountByAccountId(String accountId)throws Exception{
		Account  account=  this.getAccountService().findAccountByAccountId(accountId);
		if(account ==null){
			return null;
		}
		Map accountMap = new HashMap();
		accountMap.put("companyName1", account.getCompanyName1());
		accountMap.put("discCardOid", account.getDiscCardOid());
		accountMap.put("status", account.getStatus());

		accountMap.put("comAddr1", account.getComAddr1());
		accountMap.put("comAddr2", account.getComAddr2());
		accountMap.put("comAddr3", account.getComAddr3());
		accountMap.put("comAddr4", account.getComAddr4());
		accountMap.put("comAddr5", account.getComAddr5());

		return  accountMap;
	}

	public AccountHq loadBussinessByAccountId(String accountId)throws Exception{
		Account account = this.getAccountService().findAccountByAccountId(accountId);
		AccountHq accountHq =null;
		if(account!=null){
			if(account.getHqOid()!=null && !"".equals(account.getHqOid())){
				accountHq = this.loadBussinessByHqId(account.getHqId());
			}else{
				accountHq = new AccountHq();
				accountHq.setHqId("");
				accountHq.setHqName("");
			}
		}
		return accountHq;

	}
	
	public AccountHq loadBussinessByHqId(String hqId)throws Exception{

		return this.getAccountService().findAccountHqByHqId(hqId);
	}

	public String createCard() {
		try {
			if(createCardArray!=null && createCardArray.length!=0){
				StringBuffer sb = new StringBuffer("");
				//for(String oid:createCardArray ){
				for(String oid:createCardArray ){
					if(!"false".equals(oid)){
	
						MmCard oldCard =  this.getCardService().findMmCardByCardOid(oid);
						int oldCardType = oldCard.getCardType().intValue();
	
						//狀態為正常(Status: 1)且卡別為商務卡(1)且BatchYN為null,員工卡(2),親友(3),集團卡(4),貴賓卡(7)，停用原卡並製新卡
						if("1".equals(oldCard.getStatus().toString()) && (oldCardType==1 ||  oldCardType==2 ||  oldCardType==3 || oldCardType==4 || oldCardType==7)){
							boolean doStopOldCardAndCreateNew = true;
	
							if(oldCardType == 1) {
								if(oldCard.getBatchYN() != null && oldCard.getBatchYN().equalsIgnoreCase("Y")) {
									//BatchYN為Y, 表匯入後第一次製卡, 不執行停用原卡並製新卡的動作
									doStopOldCardAndCreateNew = false;
	
									//依原卡號製卡，並將舊卡BatchYN清空
									oldCard.setBatchYN(null);
									this.getCardService().updateCard(oldCard);
								}
							}
	
							if(doStopOldCardAndCreateNew) {
								oldCard.setMemo("");
								oldCard.setOid(null);
	
								try {
									this.getCardService().createCard(oldCard, oldCard.getVipNo(), this.getUser().getUserId(), this.getUser().getUserName());
								} catch(Exception e) {
									throw new Exception("卡號"+oldCard.getVipNo()+" 製卡失敗: "+e.getMessage());
								}
								//sb.append(oldCard.getVipNo());
							}
	
						}else{
	
	
						}
						if(!sb.toString().equals("")){
							sb.append(",");
						}
						sb.append(oldCard.getVipNo());
					}
				}
				if(!sb.toString().equals("")){
					this.getRequest().setAttribute(doCreateUtilCardVipNoList, sb.toString());
				}
			}
		} catch(Exception e) {
	    	this.addActionError(e.getMessage());
	    }	
	    
		if (StringUtils.trimToNull(memberOid) != null) {
			return queryCardInfo();
		} else {
			return queryCardInfoByAccountId();
		}
	    
	}
	
	public String createCardWithoutPrint() {
		try {
			if(createCardArray!=null && createCardArray.length!=0){
				StringBuffer sb = new StringBuffer("");
				//for(String oid:createCardArray ){
				for(String oid:createCardArray ){
					if(!"false".equals(oid)){
						
						MmCard oldCard =  this.getCardService().findMmCardByCardOid(oid);
						int oldCardType = oldCard.getCardType().intValue();
						
						//狀態為正常(Status: 1)且卡別為商務卡(1)且BatchYN為null,員工卡(2),親友(3),集團卡(4),貴賓卡(7)，停用原卡並製新卡
						if("1".equals(oldCard.getStatus().toString()) && (oldCardType==1 ||  oldCardType==2 ||  oldCardType==3 || oldCardType==4 || oldCardType==7)){
							boolean doStopOldCardAndCreateNew = true;
							
							if(oldCardType == 1) {
								if(oldCard.getBatchYN() != null && oldCard.getBatchYN().equalsIgnoreCase("Y")) {
									//BatchYN為Y, 表匯入後第一次製卡, 不執行停用原卡並製新卡的動作
									doStopOldCardAndCreateNew = false;
									
									//依原卡號製卡，並將舊卡BatchYN清空
									oldCard.setBatchYN(null);
									this.getCardService().updateCard(oldCard);
								}
							}
							
							if(doStopOldCardAndCreateNew) {
								oldCard.setMemo("");
								oldCard.setOid(null);
								
								try {
									this.getCardService().createCard(oldCard, oldCard.getVipNo(), this.getUser().getUserId(), this.getUser().getUserName());
								} catch(Exception e) {
									throw new Exception("卡號"+oldCard.getVipNo()+" 製卡失敗: "+e.getMessage());
								}
								//sb.append(oldCard.getVipNo());
							}
							
						}else{
							
							
						}
						if(!sb.toString().equals("")){
							sb.append(",");
						}
						sb.append(oldCard.getVipNo());
					}
				}
				// 不印卡
				if(!sb.toString().equals("")){
					this.getRequest().setAttribute(doCreateUtilCardVipNoList, "");
				}
			}
		} catch(Exception e) {
			this.addActionError(e.getMessage());
		}	
		
		if (StringUtils.trimToNull(memberOid) != null) {
			return queryCardInfo();
		} else {
			return queryCardInfoByAccountId();
		}
		
	}

	public String queryCardInfo() {
		try {
			accountId = null;
			System.out.println("[MembersDwrAction.queryCardInfo()] getMemberOid():"+getMemberOid());
			QueryResult result = this.getCardService().findMmCard(getMemberOid(), getQueryStartIndex(), getPageBean().getPageSize(), true,this.getUser().getCompanyId());

			this.setPageBeanForAjaxView(result,"doQueryCardInfo");
		} catch(Exception e) {
			e.printStackTrace();
		}

		return Action.SUCCESS;
	}

	public String queryCardInfoByAccountId() {
		try {
			memberOid = null;
			//QueryResult result = this.getCardService().findMmCardByAccountId(this.getAccountId(), getQueryStartIndex(), getPageBean().getPageSize(), hasToCountTotal());
			QueryResult result = this.getCardService().findMmCardByAccountId(this.getAccountId(), getQueryStartIndex(), getPageBean().getPageSize(), true);
			System.out.println("MembersDwrAction.queryCardInfoByAccountId(): "+result.getCount());
			this.setPageBeanForAjaxView(result,"doQueryCardInfo");
		} catch(Exception e) {
			e.printStackTrace();
		}

		return Action.SUCCESS;
	}

	public String cardChangeStatus() throws Exception{
		String status = this.getRequest().getParameter("status");
		String delCardReason = this.getRequest().getParameter("delCardReason");
		Long memId = 0l;
		
		if(createCardArray != null && createCardArray.length != 0){
			StringBuffer sb = new StringBuffer("");
			for(String oid : createCardArray ){
				MmCard oldCard =  this.getCardService().findMmCardByCardOid(oid);
				memId = oldCard.getMemberId();
				oldCard.setModifier(this.getUser().getUserId());
				oldCard.setModifierName(this.getUser().getUserName());
				// 不管卡片是啟用還是停用，都要把時間和原因埴入
				oldCard.setDelReason(delCardReason);
				oldCard.setDelDate(DateTimeUtils.getSysDate());
				
				if("1".equals(status)){
					// 檢查一
					if(oldCard.getCardType().intValue()==1){
						if(oldCard.getAccountId()!=null && !"".equals(oldCard.getAccountId())){
							Account accountVo = this.getAccountService().findAccountByAccountId(oldCard.getAccountId());
							if(accountVo.getStatus().intValue()==0 || accountVo.getStatus().intValue()==9){
								if(!sb.toString().equals("")){
									sb.append("</br>");
								}

								sb.append("卡號"+oldCard.getVipNo()+" 商務帳號"+accountVo.getAccountId()+"停用,無法啟用");

								break;
							}
						}
					}
					
					// 檢查二，必須檢查只能有一張親友卡或員工卡可以被啟用，不能用時啟用親友卡和員工卡
					if(staff_cardType.equalsIgnoreCase(oldCard.getCardType().toString()) || friends_cardType.equalsIgnoreCase(oldCard.getCardType().toString())){
						if(this.getMemberService().checkMembers(oldCard.getMemberOid())){
							sb.append("更新失敗，申請人己有員工或親友資料，不可啟用！");
							break;
						}
					}
					
					// 檢查三，如果是啟用員工卡要檢查員工編號是否有值
					if(staff_cardType.equalsIgnoreCase(oldCard.getCardType().toString())){
						Members member = this.getMemberService().findMemberByOid(oldCard.getMemberOid());
						if(StringUtils.isEmpty(member.getEmpId())){
							sb.append("更新失敗，啟用員工卡請先填寫員工工號並儲存後再行啟用！");
							break;
						}
					}
					
					// 檢查四，如果是啟用親友卡，要檢查recommand是否有值，要檢查推薦人是否有別的親友卡
					if(friends_cardType.equalsIgnoreCase(oldCard.getCardType().toString())){
						Members member = this.getMemberService().findMemberByOid(oldCard.getMemberOid());
						if(StringUtils.isEmpty(member.getRecommand())){
							sb.append("更新失敗，啟用親友卡請先填寫推薦人並儲存後再行啟用！");
							break;
						}
						
						List list = this.getMemberService().checkMembers(member.getRecommand(), false);
						if(list.size() > 0 ){
							sb.append("更新失敗，推薦人只能申請一張親友卡！");
							break;
						} 
					}
					/** 啟用更新Dis_card_oid or Trcb_dis_card_oid */
					Discount mt = null;
					Integer[] tmp = {2,3,4};
					if(ArrayUtils.contains(tmp, oldCard.getCardType())){
						mt = this.getMemberService().findDisCardOid(oldCard.getCardType(),"1010");
						oldCard.setDisCardOid(mt!=null?mt.getOid():null);
						mt = this.getMemberService().findDisCardOid(oldCard.getCardType(),"1050");
						oldCard.setTrcbdisCardOid(mt!=null?mt.getOid():null);
					}
				}
				
				oldCard.setModifyTime(new Date());
				oldCard.setStatus(new Integer(status));
				this.getCardService().updateCard(oldCard);
				
				/*
				 * 修改,當員工卡(2)變更狀態為停用(0)、刪除(9)，則附屬的親友卡也要更著變更為同等狀態
				 * */
				if(2 == oldCard.getCardType() && ("0".equals(status) || "9".equals(status))){
					Members members = this.getMemberService().findMemberByOid(oldCard.getMemberOid());
					List<MmCard> cardList = this.getMemberService().findMmCardByRecommand(members.getPersonId());
					for(MmCard card : cardList){
						card.setModifier(this.getUser().getUserId());
						card.setModifierName(this.getUser().getUserName());
						card.setModifyTime(new Date());
						card.setStatus(new Integer(status));
						card.setDelReason(delCardReason);
						card.setDelDate(DateTimeUtils.getSysDate());
						this.getCardService().updateCard(card);
					}
				}
			}// end of for
			this.getRequest().setAttribute("doCardChangeStatusVipNoList",sb.toString());
		}// end of if
		
		if (StringUtils.isNotBlank(syncFlag)) {
			log.info("syncFlag:" + syncFlag);
			log.info("syncEc開始");
			String result = memberService.businessAuth(memId);
			log.info("syncEc結果: " + result);
		}
		if(StringUtils.trimToNull(accountId) == null){
			return queryCardInfo();
		}
		
		return queryCardInfoByAccountId();
	}
	
	//商務會員卡(新增)
	public String doCreateMemberBusinessCard(String channelId,String storeId,String disCardOid,String memo, String memberOid,boolean freg,String accountId) throws Exception{
		Members members = this.getMemberService().findMemberByOid(memberOid);
		MmCard newCard = new MmCard();

		//建立MmCard
		newCard.setChannelId(channelId);
		newCard.setStoreId(storeId);
		newCard.setAccountId(accountId);
		newCard.setMemo(memo);
		newCard.setDisCardOid(disCardOid);
		newCard.setCardType(MemberGlossary._mm_card_type_business);
		if(freg){
			newCard.setRecommand(members.getRecommand());
		}
		newCard.setMemberOid(members.getOid());
		newCard.setMemberId(members.getMemberId());
		
		cardService.createCard(newCard, this.getUser().getUserId(), this.getUser().getUserName());
		//更新mm_account.ApproveCard
		this.getCardService().updateApproveCardByAccountId(members.getAccountId());
		return newCard.getVipNo();
	}
	
	public String doCheckMembers(String channelId, String storeId, String disCardOid, String memo, String oid, boolean setRecommand, String myCardType, String recommand) throws Exception {
		
		Members members = this.getMemberService().findMemberByOid(oid);
		
		// 檢查一：折扣卡選擇為親友卡折扣時，推薦人名下不可有別的親友卡
		if(friends_cardType.equalsIgnoreCase(myCardType)){
			List list = this.getMemberService().checkMembers(recommand, false);
			if(list.size() == 1){
				Map map = (Map)list.get(0);
				if(!oid.equalsIgnoreCase(map.get("OID").toString())){
					return "更新失敗，推薦人只能申請一張親友卡！";
				}
			}
			if(list.size() > 1){
				return "更新失敗，推薦人只能申請一張親友卡！";
			}
		}
		
		// 檢查二：折扣卡選擇為親友卡折扣或員工卡折扣時，如果申請人有正常親友卡及員工卡則無法存檔
		if(staff_cardType.equalsIgnoreCase(myCardType) || friends_cardType.equalsIgnoreCase(myCardType)){
			List list = this.getMemberService().checkMembers(members.getPersonId(), true);
			
			if(list.size() == 1){
				Map data = (Map)list.get(0);
				String message;
				if(data.get("CARD_TYPE") == null){
					return "更新失敗，申請人己有員工或親友資料，不可再次申請！";
				} else {
					message = ("2".equalsIgnoreCase(data.get("CARD_TYPE").toString()))? "員工卡" : "親友卡";
					if(!myCardType.equalsIgnoreCase(data.get("CARD_TYPE").toString())){
						return "更新失敗，申請人己有一張" + message + "，不可再次申請！";
					}
				}
				
				if(!oid.equalsIgnoreCase(data.get("OID").toString())){
					return "更新失敗，申請人己有一張" + message + "，不可再次申請！";
				}
			}
			
			if(list.size() > 1){
				Map data = (Map)list.get(0);
				if(data.get("CARD_TYPE") == null){
					return "更新失敗，申請人己有員工或親友資料，不可再次申請！";
				}
				
				String message = ("2".equalsIgnoreCase(data.get("CARD_TYPE").toString()))? "員工卡" : "親友卡";
				return "更新失敗，申請人己有一張" + message + "，不可再次申請！";
			}
		}
		
		if(recommand != null || recommand.trim().length() > 0) {
			members.setRecommand(recommand);
			memberService.saveOrUpdateMembers(members);
		}
		
		return doCreateMemberCard(channelId, storeId, disCardOid, memo, oid, setRecommand);
	}
	
	public String doCreateMemberCard(String channelId,String storeId,String disCardOid,String memo, String oid,boolean setRecommand) throws Exception{
		Members members = this.getMemberService().findMemberByOid(oid);
		MmCard newCard = new MmCard();

		//建立MmCard
		newCard.setChannelId(channelId);
		newCard.setStoreId(storeId);
		newCard.setMemo(memo);
		newCard.setDisCardOid(disCardOid);
		newCard.setMemberOid(members.getOid());
		newCard.setMemberId(members.getMemberId());
		newCard.setCompanyId(this.getUser().getCompanyId());
		if(setRecommand){
			newCard.setRecommand(members.getRecommand());
		}
		
	    this.cardService.createCard(newCard, this.getUser().getUserId(), this.getUser().getUserName());
	  //String message = "產生卡號："+newCard.getVipNo();
	    String message = newCard.getVipNo(); 
		return message;
	}

	//停用卡
	private void doDisableCard(List<MmCard> cardList) throws Exception{
		if(cardList != null && cardList.size() > 0){
			 getCardService().disableMmCard(cardList, null, this.getUser().getUserId(), this.getUser().getUserName());
		 }
	}

	public List<SelectItem> doChangeIsGroupCardDiscount(String type){
		return  DiscountSelectItem.getDiscountCardNameList(type, false);
	}

	public List<SelectItem> doChangeAccType(String accType){
		return  SelectItem.getPayTypeList(accType);
	}

	public String doCheckCardType0(String memberOid,String discountOid) throws Exception{
		if(StringUtils.isNotBlank(discountOid)) {
			DiscountVo discount = marketingService.getDiscountVoByOid(discountOid);
			if(!"0".equals(discount.getCardType())){
				return Boolean.TRUE.toString();
			}
		}
		List list = this.getCardService().findMmCardByMemberOidStatusAndCardType(memberOid,1,MemberGlossary._mm_card_type_normal);
		if(list.size()==0){
			return Boolean.TRUE.toString();
		}

		return Boolean.FALSE.toString();
	}
	public List findMmCardByMemberOidIsAverableByStatus(String oid,Integer status,Integer cardType) throws Exception{
		return this.getMemberService().getMemberDao().findMmCardByMemberOidStatusAndCardType(oid,status,cardType);
	}

	/**
	 * 取得hq底下的account
	 * @param hqId
	 * @author JL
	 * @return
	 */
	public List<Account> loadAccountOfHq(String hqId,String accountId){
		List<Account> list = new ArrayList<Account>();
		try{
			if (StringUtils.isBlank(hqId) && StringUtils.isBlank(accountId)){
				return new ArrayList<Account>();
			}
			list = accountService.findAccountByCondition(hqId,accountId);
		}catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}
	
	public boolean checkAuthorityForIdRepeat(String userId) {
		return this.memberService.getMemberDao().checkAuthorityForIdRepeat(userId);
	}

	public boolean checkPasswordForIdRepeat(String userId, String userPw) {
		if(!this.isADAuthEnabled()) {
			return true;
		}
		return ADAuth.checkAuth(userId, userPw);
	}

	public boolean isCardExistByCardType(String memberOid, Integer status, Integer cardType) throws Exception {
		List cards = null;
		if(StringUtils.trimToNull(memberOid) != null) {
			if(status != null) {
				if(cardType != null) {
					//MmCard card = memberService.loadPersonnelCardByOid(memberOid, 1);
					cards = cardService.findMmCardByMemberOidStatusAndCardType(memberOid, status, cardType);
				} else {
					cards = cardService.findMmCardByMemberOidAndStatus(memberOid, status);
				}
			} else {
				if(cardType != null) {
					//MmCard card = memberService.loadPersonnelCardByOid(memberOid, 1);
					cards = cardService.findMmCardByMemberOidStatusAndCardType(memberOid, null, cardType);
				} else {
					cards = cardService.findMmCardByMemberOid(memberOid);
				}
			}
		}
		if(cards != null && cards.size() > 0)
			return true;
		else
			return false;
	}

	public boolean isCardExist(String memberOid, Integer status, String cardDiscountOid) throws Exception {
		DiscountVo cardDiscount = null;
		if(StringUtils.isNotBlank(cardDiscountOid)) {
			cardDiscount = marketingService.getDiscountVoByOid(cardDiscountOid);
			
			//集團卡可允許重覆
			if(cardDiscount.getCardType().equals("4")) {
				return false;
			}
					 
			return isCardExistByCardType(memberOid, status, Integer.parseInt(cardDiscount.getCardType().trim()));
		} else {
			return isCardExistByCardType(memberOid, status, null);
		}
	}

	public int queryAdvanceCardAmount(String channelId, String storeId, String aproveDate) {
		List<String> list = this.cardService.findAdvanceCard(channelId, storeId, aproveDate);

		if(list.size() > 0) {
			StringBuilder sb = new StringBuilder();
			for(String vipNo : list) {
				sb.append(vipNo).append("\n");
			}
			WebContextFactory.get().getSession().setAttribute(AdvanceCardAction._session_dowloadStr, sb.toString());
		}

		return list.size();
	}

	public int makeAdvanceCard(String channelId, String storeId, Integer amount, String note, String vipDate) {
		ScSysuser user = this.getUser();
		this.cardService.makeAdvanceCard(
		    channelId, storeId, amount, note, user.getUserId(), user.getUserName(),vipDate);
		return 0;
	}
	
	/** 214預製黑卡，查詢TRCB VIP資料*/
	public Map queryMmCard(String cardNum) throws Exception {
		return this.memberService.getMemberDao().queryTRCB(cardNum);
	}
	
	/** 214預製黑卡，儲存TRCB VIP資料*/
	public void saveTrcb(String memberId,String startDate) throws Exception {
		this.memberService.getMemberDao().saveTRCB(memberId, startDate);
	}

	public int revertDMReturn(String oid) {
		ScSysuser user = this.getUser();
		this.memberService.revertDMReturn(oid, user.getUserId(), user.getUserName(), null);
		return 0;
	}
	
	// ID重覆處理
	public String doIdRepeat(Integer type, String oid) throws Exception {
		ScSysuser user = this.getUser();
		this.memberService.handleMemberForIdRepeat(oid, user);
		return null;
	}
	
	// 停用、異常、刪除，啟用處理
	public int updateMemberStatusByOid(final String oid, final String status,
			final String resId1, final String resId2, final String resulm) {
		ScSysuser user = this.getUser();

		final String tmpResId2 = procResId2(resId2);
		this.memberService.updateMemberStatusByOid(oid, status, resId1, tmpResId2, resulm, user.getUserId(), user.getUserName(),user.getCompanyId());
		return 0;
	}
	
	// 退件處理
	public int updateMemberStatusByOidForReturn(final String oid, final String status,
			final String resId1, final String resId2, final String resulm, final String nmName) throws Exception{
		log.info("選擇退件原因: " + resId2);
		if (!"4".equals(resId2)) {
			
			ScSysuser user = this.getUser();
			this.memberService.updateMemberStatusByOidForReturn(oid, status, resId1, resId2, resulm, user.getUserId(), user.getUserName(), nmName, user.getCompanyId());
			//Ec同步
			Members members = this.memberService.findMemberByOid(oid);
			if(members.getEcYn() != null && members.getEcYn() == 1 && this.memberService.isOpenEcSycn()) {
				String errmsg = "";
				SyncTestriteCustomerResponse response = null;
				try{
					com.trg.oms.externalWS.ec.mobileVerify.SynCustomer request = new com.trg.oms.externalWS.ec.mobileVerify.SynCustomer();
					com.trg.oms.externalWS.ec.mobileVerify.SynCustomer.SyncTestriteCustomerRequest req = new com.trg.oms.externalWS.ec.mobileVerify.SynCustomer.SyncTestriteCustomerRequest();
					req.setSourceSystem("CRM_SYSTEM");
					req.setCrmMemberID(members.getMemberId().toString());
					request.setSyncTestriteCustomerRequest(req);
					SynCustomerService synCustomerService = (SynCustomerService) externalWSClient.create(SynCustomerService.class,"EC-WS-Syn", "SynCustomer", null);
					response = synCustomerService.doSynCustomer(request);
				}catch(Exception e){
					errmsg = e.getMessage();
				}
				MembersEcSycn ec = new MembersEcSycn();
				ec.setMemberId(members.getMemberId());
				if(StringUtils.isNotEmpty(errmsg)){
					ec.setResult("N");
					ec.setErrorMsg("連線錯誤");
				}else{
					ec.setResult((response.getSyncTestriteCustomerResponse().getRtnCode()>0)?"Y":null);
					String errMsg = StringUtils
							.substring(response.getSyncTestriteCustomerResponse().getRtnMsg(), 0, 25);
					ec.setErrorMsg(errMsg);
				}
				ec.setModifyTime(new Date());
				ec.setCreateTime(new Date());
				ec.setWebServiceName("SynCustomer");
				this.getMemberService().getMemberDao().getHibernateTemplate().save(ec);
			}
		}
		return 0;
	}
	
	// 回復退件處理
	public int revertReturnStatus(String oid, String returnType) {
		ScSysuser user = this.getUser();
		this.memberService.revertDMReturn(oid, user.getUserId(), user.getUserName(), returnType, BsCompanyDefinition.getCompanyId());
		return 0;
	}
	
	// 異常回復處理
	public int revertStatus(final String oid, final String status,
			final String resId1, final String resId2, final String resulm) {
		ScSysuser user = this.getUser();
		
		//異常回復需判斷是否還有退件(mm_members_market)資料，若無資料，就執行異常回復，若有資料，需註記為退件
		List list = memberService.findMmMembersMarket(oid);
		if(list.size() == 0){
			final String tmpResId2 = procResId2(resId2);
			this.memberService.revertMemberStatusToNormal(oid, status, resId1, tmpResId2, resulm, user.getUserId(), user.getUserName(), true);
		}else{
			Map map = (Map)list.get(0);
			BsCode bsCode = BsCodeDefinition.findAllMemberByCodeClassAndCodeNo("CM_TYPE", map.get("RETURN_TYPE").toString());
			this.memberService.revertMemberStatusToNormal(oid, "2", "ER", "003", bsCode.getCodeExplain()+"退件", user.getUserId(), user.getUserName(), false);
		}
		
		return 0;
	}
	
	private String procResId2(String data) {
		String resId2 = data;
		if(resId2 == null || resId2 == "") {
			return resId2;
		}
		if(resId2.indexOf(";") == -1) {
			return resId2;
		}
		try {
			String[] tmpResId2 = resId2.split(";");
			String codeNo = tmpResId2[0];
			String choiceIdx = tmpResId2[1];

			List reasonList = BsCodeDefinition.findAllByParentCodeClassAndParentCodeNo("ER", codeNo);
			BsCode bsCode = (BsCode)reasonList.get(Integer.parseInt(choiceIdx));
			return bsCode.getId().getCodeNo();
		} catch(Exception e){
			log.error("proccess resId2 error" + e);
		}
		return resId2;
	}

	public boolean checkAuthorityFromBsErraut(String userId) {
		return this.memberService.getMemberDao().checkAuthorityFromBsErraut(userId);
	}

	/**
	 * 讀取AD認證設定
	 * @return true(AD認證開啟) / false(AD認證關閉)
	 */
	private static PropertiesConfiguration pCfg = null;
	private boolean isADAuthEnabled() {
		boolean adAuthEnabled = true;
		try {
			if(pCfg == null) {
				pCfg = new PropertiesConfiguration("application.properties");
			}
			adAuthEnabled = pCfg.getBoolean("ENABLE_AD_AUTH", true);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return adAuthEnabled;
	}

	public String checkTransferMemberStatus(String personId,String vipNo) {
		String rtnMsg = "";
		try {
			boolean canTransfer = getMemberService().checkTransferMemberStatus(personId, vipNo) ;
			if(!canTransfer) {
				rtnMsg = "無法移轉";
			}
		} catch (Exception e) {
			rtnMsg = e.getMessage();
		}
		return rtnMsg;
	}

	public MemberVo getMemberBonusInfo(String memberId, String vipNo) {
		MemberVo vo = new MemberVo() ;
		try {
			Members m = this.getMemberService().getMemberByMemberIdOrVipNo(vipNo, memberId) ;
			if(m != null) {
				MmMembersBonus mbonus = this.getMmBonusService().findMmMembersBonusByParms(m.getCompanyId(),m.getMemberId());
				m.setBonusTotal(mbonus.getBonusTotal());
				if(m.getBonusTotal() != null) {
					vo.setBonusTotal(String.valueOf(m.getBonusTotal())) ;
				}else{
					vo.setBonusTotal("0") ;
				}
				if(m.getBonusUpdateTime() != null) {
					vo.setBonusUpdateTime(DateTimeUtils.getFormatDateStr(m.getBonusUpdateTime())) ;
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage(),e) ;
		}
		return vo ;
	}
	
	public long queryAdvanceCardCount(String channelId, String storeId) {
		return this.cardService.findAdvanceCardCount(channelId, storeId);
	}

	/**
	 * 200-會員/卡片資料維護(門市)-維護作業 - 紅利點數
	 * @return
	 */
	public String queryBonusInfo()
	{
		try {
			Members member = (Members)this.getCardService().getMemberDao().getHibernateTemplate().get(Members.class, getMemberOid());
			Map map = mmBonusService.findBonusTotalByParms(BsCompanyDefinition.getCompanyId(),member.getMemberId()+"");
			if(map!=null&&map.get("bonusTotal")!=null){
				this.bonusTotal = ((Integer)map.get("bonusTotal")).intValue();
			}else{this.bonusTotal=0;}
			this.DeductionTotal = this.getBcBonusTemporalService().getRealTimeBonusMinsTotal(member.getPersonId());

			//QueryResult result = this.getCardService().findBounsLog(getMemberOid(), getQueryStartIndex(), getPageBean().getPageSize(), hasToCountTotal());
			QueryResult result = this.getCardService().findBounsLog(getMemberOid(), getQueryStartIndex(), getPageBean().getPageSize(), true,this.getUser().getCompanyId());
			this.setPageBeanForAjaxView(result,"doQueryBonusInfo");
		} catch(Exception e) {
			e.printStackTrace();
		}

		return Action.SUCCESS;
	}

	/**
	 * 紅利總表
	 * @return
	 */
	public String queryBonusSubtotalInfo()
	{
		try {
			Members member = (Members)this.getCardService().getMemberDao().getHibernateTemplate().get(Members.class, getMemberOid());
			if(member != null){
				this.bonusTotal = BaseWebService.isEmpty(member.getBonusTotal()) ? 0 : member.getBonusTotal();
				QueryResult result = this.getCardService().findBounsSubtotalInfo(member.getMemberId().toString(), getQueryStartIndex(), getPageBean().getPageSize(), true);
				this.setPageBeanForAjaxView(result,"doQueryBonusSubtotalInfo");
			}else{
				// 錯誤訊息
				this.addActionError("查無會員資料!");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}

		return Action.SUCCESS;
	}
	
	/**
	 * LINE綁定
	 * @return
	 */
	public String queryMmLineMstInfo() {
		try {
			HttpServletRequest request = this.getRequest();
			MmLineMst mst = new MmLineMst();
			mst.setMemberId(memberId);
			mst.setCompanyId(this.getUser().getCompanyId());
			List<MmLineMst> lineMstList = this.memberService.getMemberDao().selectMmLineMstWithCompanyId(mst);
			request.setAttribute("lineMstList", lineMstList);
			request.setAttribute("memberId", memberId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Action.SUCCESS;
	}
	
	/**
	 * LINE人工頁面解綁
	 * @return
	 */
	public String deleteAIM() {
		try {
			HttpServletRequest request = (HttpServletRequest) ServletActionContext.getRequest();
			HttpSession session = request.getSession();	
			RefreshableKeycloakSecurityContext rksc = (RefreshableKeycloakSecurityContext) session.getAttribute("KCToken");
			String token = rksc.getTokenString();
			String lineId = "";
			boolean deleteMst = false;
			
			String memberId = (String) request.getAttribute("memberId");
			String channelId = (String) request.getAttribute("channelId");
			MmLineMst mst = new MmLineMst();
			mst.setMemberId(memberId);
			mst.setChannelId(channelId);
			mst.setCompanyId(this.getUser().getCompanyId());
			List<MmLineMst> oldLineMstList = this.memberService.getMemberDao().selectMmLineMstWithCompanyId(mst);
			for (MmLineMst mmLineMst : oldLineMstList) {
				this.memberService.insertMmLineMstBak(mmLineMst);
				deleteMst = true;
				lineId = mmLineMst.getLineId();
			}
			if (deleteMst) {
				this.memberService.deleteMmLineMstByMemberAndChannelId(memberId, channelId);
				String sourceId = transferWebId(channelId);
				this.memberService.deleteMmMemLikesBySourceId(memberId, sourceId);
			}
			MemberBaseAction memAction = new MemberBaseAction();
			String result = memAction.deleteAIM(memberId, lineId, token);
			log.info(String.format("{人工頁面解綁會員},result:%s", memberId, result));
			
			mst.setChannelId("");
			List<MmLineMst> lineMstList = this.memberService.getMemberDao().selectMmLineMstWithCompanyId(mst);
			request.setAttribute("lineMstList", lineMstList);
			request.setAttribute("memberId", memberId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Action.SUCCESS;
	}
	
	private String transferWebId(String channelId) {
		Map<String, String> webIdMap = new HashMap<String, String>();
		webIdMap.put("HOLA", "LB00000001");
		webIdMap.put("TLW", "LA00000001");
		String sourceId = "";
		for (Map.Entry<String, String> entry : webIdMap.entrySet()) {
			if (channelId.equals(entry.getKey())) {
				sourceId = entry.getValue();
			}
		}
		return sourceId;
	}
	
	/**
	 * HISU個資授權註記
	 * @return
	 */
	public String queryMemberAgree() {
		try {
			HttpServletRequest request = this.getRequest();
			MmMembersAgree mmAgree = new MmMembersAgree();
			mmAgree.setMemberId(new BigDecimal(memberId));
			List<MmMembersAgree> mmAgreeList = this.memberService.selectMmMembersAgree(mmAgree);
			List<BsCompany> companyList = bsCompanyService.findAllBsCompany();
			for (MmMembersAgree mmMembersAgree : mmAgreeList) {
				for (BsCompany bsCompany : companyList) {
					if (mmMembersAgree.getCompanyId().equals(bsCompany.getCompanyId())) {
						mmMembersAgree.setCompanyId(mmMembersAgree.getCompanyId() + "(" + bsCompany.getCompanyName() + ")");
					}
				}
			}
			request.setAttribute("mmAgreeList", mmAgreeList);
			request.setAttribute("memberId", memberId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Action.SUCCESS;
	}
	
	/**
	 * HISU個資授權註記新增
	 * @return
	 */
	public String insertMemberAgree() {
		try {
			HttpServletRequest request = this.getRequest();
			MmMembersAgree mmAgree = new MmMembersAgree();
			mmAgree.setMemberId(new BigDecimal(memberId));
			mmAgree.setCompanyId("1060");
			mmAgree.setAgreeYn("N");
			mmAgree.setCreator(this.getUser().getUserId());
			mmAgree.setCreateTime(new Date());
			this.memberService.insertMmMembersAgree(mmAgree);
			
			mmAgree.setCompanyId("");
			List<MmMembersAgree> mmAgreeList = this.memberService.selectMmMembersAgree(mmAgree);
			List<BsCompany> companyList = bsCompanyService.findAllBsCompany();
			for (MmMembersAgree mmMembersAgree : mmAgreeList) {
				for (BsCompany bsCompany : companyList) {
					if (mmMembersAgree.getCompanyId().equals(bsCompany.getCompanyId())) {
						mmMembersAgree.setCompanyId(mmMembersAgree.getCompanyId() + "(" + bsCompany.getCompanyName() + ")");
					}
				}
			}
			request.setAttribute("mmAgreeList", mmAgreeList);
			request.setAttribute("memberId", memberId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Action.SUCCESS;
	}
	
	/**
	 * HISU個資授權註記刪除
	 * @return
	 */
	public String deleteMemberAgree() {
		try {
			HttpServletRequest request = this.getRequest();
			MmMembersAgree mmAgree = new MmMembersAgree();
			mmAgree.setMemberId(new BigDecimal(memberId));
			String comId = companyId.substring(0, 4);
			mmAgree.setCompanyId(comId);
			List<MmMembersAgree> mmAgreeList = this.memberService.selectMmMembersAgree(mmAgree);
			for (MmMembersAgree mmMembersAgree : mmAgreeList) {
				MmMembersAgreeBak bak = new MmMembersAgreeBak();
				BeanUtils.copyProperties(bak, mmMembersAgree);
				bak.setModifier(this.getUser().getCreator());
				bak.setModifyTime(new Date());
				this.memberService.deleteMmMembersAgree(bak, mmMembersAgree);
			}
			
			mmAgree.setCompanyId("");
			List<MmMembersAgree> mmAgreeResultList = this.memberService.selectMmMembersAgree(mmAgree);
			List<BsCompany> companyList = bsCompanyService.findAllBsCompany();
			for (MmMembersAgree mmMembersAgree : mmAgreeResultList) {
				for (BsCompany bsCompany : companyList) {
					if (mmMembersAgree.getCompanyId().equals(bsCompany.getCompanyId())) {
						mmMembersAgree.setCompanyId(mmMembersAgree.getCompanyId() + "(" + bsCompany.getCompanyName() + ")");
					}
				}
			}
			request.setAttribute("mmAgreeList", mmAgreeResultList);
			request.setAttribute("memberId", memberId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Action.SUCCESS;
	}
	
	/**
	 * 查詢VIP和SVIP
	 * @return
	 */
	public String queryVipOrSvip() {
		try {
			HttpServletRequest request = this.getRequest();
			String companyId = this.getUser().getCompanyId();
			List<MmPosVipCulmMasterVo> basicList = mtGroupVipService.selectVipSvipBasic(companyId);
			List<MmPosVipCulmMasterVo> resultList = new ArrayList<>();
			BigDecimalConverter bd = new BigDecimalConverter(BigDecimal.ZERO);    
			ConvertUtils.register(bd, java.math.BigDecimal.class);
			for (MmPosVipCulmMasterVo basicVo : basicList) {
				MmPosVipCulmMasterVo vo = new MmPosVipCulmMasterVo();
				MmPosVipCulmMaster vipMaster = getMtVipMasterDao().findVipSvipByChannelMember(Long.valueOf(memberId), basicVo.getChannelGroupId());
				if (null == vipMaster) {
					BeanUtils.copyProperties(vo, basicVo);
				} else {
					BeanUtils.copyProperties(vo, vipMaster);
				}
				vo.setGroupName(basicVo.getGroupName());
				resultList.add(vo);
			}
			request.setAttribute("vipMasterList", resultList);
			request.setAttribute("memberId", memberId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Action.SUCCESS;
	}
	
	/**
	 * 點數清算
	 * @return
	 */
	public String queryMembersBonusInfo()
	{
		try {
			Members member = (Members)this.getCardService().getMemberDao().getHibernateTemplate().get(Members.class, getMemberOid());
			Map map = mmBonusService.findBonusTotalByParms(BsCompanyDefinition.getCompanyId(),member.getMemberId()+"");
			Integer lastYearTot = (map==null || map.get("lastYearTot")==null)?0:((Integer)map.get("lastYearTot")).intValue();
			Integer thisYearTot = (map==null || map.get("thisYearTot")==null)?0:((Integer)map.get("thisYearTot")).intValue();
			Integer bonusTotal = (map==null || map.get("bonusTotal")==null)?0:((Integer)map.get("bonusTotal")).intValue();
			if(member != null){
				List<Members> list = new ArrayList<Members>();
				member.setLastYearTot(lastYearTot);
				member.setThisYearTot(thisYearTot);
				member.setBonusTotal(bonusTotal);
				list.add(member);
				coverExpDate(list);
				QueryResult result = new QueryResult(1, list);
				this.setPageBeanForAjaxView(result, "doQueryMembersBonusInfo");
			}else{
				// 錯誤訊息
				this.addActionError("查無會員資料!");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}

		return Action.SUCCESS;
	}
	
	// 查詢最後消費日期
	private void coverExpDate(List<Members> list) throws Exception {
		// 消費者最後消費時間
		for (Members m : list) {
			Date expDateStr = mmBonusService.latestShopDate(m.getMemberId(), this.getUser().getCompanyId());
			Date activeDate = formatStringToDate("2020/06/01", "yyyy/MM/dd");
			Date temp = null;
			if (null != expDateStr) {
				String afterMonth = subOrAddMonth(expDateStr, 12);
				Date afterDate = formatStringToDate(afterMonth, "yyyy-MM-dd");
				temp = (true == afterDate.before(activeDate)) ? activeDate : afterDate;
			} else {
				Date now = formatDateToDate(new Date(), "yyyy-MM-dd");
				Date defDate = formatStringToDate("2020/05/01", "yyyy/MM/dd");
				temp = (true == now.after(activeDate)) ? now : defDate;
			}
			Date expDate = getLastDayOfMonth(temp);
			m.setExpDate(formatDateToString(expDate, "yyyy/MM/dd"));
		}
	}
	
	// 字串轉日期
	private Date formatStringToDate(String date, String format) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.parse(date);
	}
	
	// 處理加減月份
	private String subOrAddMonth(Date date, int amount) throws Exception {
		Date dt = formatDateToDate(date, "yyyy-MM-dd");
		Calendar rightNow = Calendar.getInstance();
		rightNow.setTime(dt);
		rightNow.add(Calendar.MONTH, amount);
		Date dt1 = rightNow.getTime();
		String reStr = formatDateToString(dt1, "yyyy-MM-dd");
		return reStr;
	}
	
	// 日期轉字串
	public String formatDateToString(Date date, String format) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(date);
	}
	
	// 日期轉日期
	public Date formatDateToDate(Date date, String format) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		Date dateFormat = formatStringToDate(sdf.format(date), format);
		return dateFormat;
	}
	
	// 月份最後一天
	public Date getLastDayOfMonth(Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		int last = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
		cal.set(Calendar.DAY_OF_MONTH, last);
		return cal.getTime();
	}
	
	public String queryMtDmSendlog()
	{
		try {
			//QueryResult result = this.getCardService().findMtDmSendlog(getMemberOid(), getQueryStartIndex(), getPageBean().getPageSize(), hasToCountTotal());
			QueryResult result = this.getCardService().findMtDmSendlog(getMemberOid(), getQueryStartIndex(), getPageBean().getPageSize(), true,
					this.getUser().getCompanyId());
			this.setPageBeanForAjaxView(result,"queryform");
		} catch(Exception e) {
			e.printStackTrace();
		}

		return Action.SUCCESS;
	}
	
	/**
	 * 折價券/贈品活動(6個月內)
	 * @return
	 */
	public String queryCouponForMemberTag(){
		try {
//			21876 200-會員/卡片資料維護(門市)-查詢作業 201-會員/卡片資料維護(總公司)-維護作業 原頁簽,修改為 [折價券/贈品活動-6個月內] ,增加另一頁簽 [折價券/贈品活動-歷史區]
			QueryResult result = memberService.findMemberCoupon(getMemberOid(), getQueryStartIndex(), getPageBean().getPageSize(), true, BsCompanyDefinition.getCompanyId());
			this.setPageBeanForAjaxView(result,"queryform");
		} catch(Exception e) {
			log.error("queryCouponForMemberTag has error...", e);
		}
		return Action.SUCCESS;
	}
	
	/** 
	 * 折價券/贈品活動詳情
	 * @return
	 */
	public String queryCouponDtlForMemberTag(){
		HttpServletRequest request = this.getRequest();
		String recid = request.getParameter("recid");
		List<MemberGiftTicketSeqVO> ls = null;
		try {
			ls = memberService.findMemberGiftTicket(recid);
		} catch(Exception e) {
			log.error("queryCouponDtlForMemberTag has error...", e);
		}
		request.setAttribute("giftticketls", ls);
		return Action.SUCCESS;
	}
	
	/**
	 * 折價券/贈品活動(歷史區)
	 * @return
	 */
	public String queryCouponForMemberTagBak(){
		try {
//			21876 200-會員/卡片資料維護(門市)-查詢作業 201-會員/卡片資料維護(總公司)-維護作業 原頁簽,修改為 [折價券/贈品活動-6個月內] ,增加另一頁簽 [折價券/贈品活動-歷史區]
			QueryResult result = memberService.findMemberCouponBak(getMemberOid(), getQueryStartIndex(), getPageBean().getPageSize(), true , BsCompanyDefinition.getCompanyId());
			this.setPageBeanForAjaxView(result,"queryform");
		} catch(Exception e) {
			log.error("queryCouponForMemberTagBak has error...", e);
		}
		return Action.SUCCESS;
	}
	
	/**
	 * 首次消費日
	 * @return
	 */
	public String queryAbnormalForMemberTag()
	{
		try {
			QueryResult result = this.memberService.findMemberAbnormal(getMemberOid(), this.getUser().getCompanyId(),
					getQueryStartIndex(), getPageBean().getPageSize(), true);
			this.setPageBeanForAjaxView(result,"queryAbnormalForMemberTag");
		} catch(Exception e) {
			e.printStackTrace();
		}

		return Action.SUCCESS;
	}
	
	/**
	 * 折價券/購物金轉贈紀錄
	 * @return
	 */
	public String queryCreditTransHistory(){
		try {
			QueryResult result = memberService.findCreditTransHistory(getMemberOid(), getQueryStartIndex(), getPageBean().getPageSize(), true , BsCompanyDefinition.getCompanyId());
			this.setPageBeanForAjaxView(result,"queryform");
		} catch(Exception e) {
			log.error("queryCouponForMemberTagBak has error...", e);
		}
		return Action.SUCCESS;
	}	
	
	public ScSysuser getUser() {
		ScSysuser user = super.getUser();
		if(user == null) {
			//get user using DWR API 
			HttpServletRequest request = WebContextFactory.get().getHttpServletRequest();
			user = (ScSysuser)request.getSession().getAttribute("user");
		}
		return user;
	}
	
	public String queryCommentForMemberTag(){
		QueryResult result = null;
		
		try {
			result = getCcService().getCommentTypeList(this.getMemberOid(), this.getPageBean().getPageNo(), this.getPageBean().getPageSize(), true, false,this.getUser().getCompanyId());
//			 doQueryMembersCommentInfo(action name)
			this.setPageBeanForAjaxView(result, "doQueryMembersCommentInfo");
		} catch(Exception e){
			e.printStackTrace();
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	public String queryMemberOidByPersoId(String personId){
		String noid = this.getMemberService().queryMemberOidByPersoId(personId);
		return StringUtils.isNotEmpty(noid)?noid:"";
	}
	
	public Members queryMemberByPersoId(String personId){
		return this.getMemberService().queryMemberByPersoId(personId);
	}
	
	public Members queryMemberByOid(String oid){
		Members ms =  this.getMemberService().queryMemberByOid(oid);
		boolean ispass = false;
		for (MmCard cd : ms.getMmCard()) {
			if(cd.getCompanyId().equals(BsCompanyDefinition.getCompanyId())){
				ispass = true;
			}
		}
//		if(ispass){
//			return null;
//		}else{
			return this.getMemberService().queryMemberByOid(oid);
//		}
	}
	
	
	public String queryProductForMemberTag(){
		QueryResult result = null;
		
		try {
			result = getPrdSerService().getProductServiceListByMemberOid(this.getMemberOid(), this.getPageBean().getPageNo(), this.getPageBean().getPageSize(), true,this.getUser().getCompanyId());
			// doQueryMembersProductInfo(action name)
			this.setPageBeanForAjaxView(result, "doQueryMembersProductInfo");
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}
		
		return SUCCESS;
	}
	
	public Map<String, Object> queryReverseMemberName(String vipNo,String personId){
		return getMemberService().getMemberDao().queryReverseMemberName(vipNo, personId);
	}
	
	public String queryRemarkForMemberTag(){ 
		try {
			this.membersRemark = membersRemarkService.findByMemberOid(this.getMemberOid(),this.getUser().getCompanyId());
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}  
		return SUCCESS;
	} 
	
	public boolean getMmCardStatsByVipNo(String vipNo){
		boolean ispass = true;
		try{
			MmCard mmCard = cardService.findMmCardByVipNo(vipNo);
			if(mmCard!=null&&(mmCard.getStatus()==0||mmCard.getStatus()==9)) ispass = false;
		}catch(Exception e){
			e.printStackTrace();
		}
		return ispass;
	}
	
	public Map mobileVerify(String memberId,String cellPhone,String brithday,String name,String status,String isY,String channelId){
		Map returnmap = new HashMap();
		try{
			// call webservice
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			com.trg.oms.externalWS.ec.mobileVerify.DoVerifyMobile request = new com.trg.oms.externalWS.ec.mobileVerify.DoVerifyMobile();
			com.trg.oms.externalWS.ec.mobileVerify.DoVerifyMobile.SendMobileVerifyRequest req = new com.trg.oms.externalWS.ec.mobileVerify.DoVerifyMobile.SendMobileVerifyRequest();
			SendMobileVerifyResponse response = null;
			int year;
			if(brithday.length()>6){
				year = Integer.parseInt(brithday.substring(0,3)) + 1911;
				req.setBirthday(year + brithday.substring(3,7));
			}else{
				year = Integer.parseInt(brithday.substring(0,2)) + 1911;
				req.setBirthday(year + brithday.substring(2,6));
			}
			req.setSourceSystem("CRM_SYSTEM");
			req.setCompanyID(BsCompanyDefinition.getCompanyId());
			req.setCrmMemberID(memberId);
			req.setChannel(channelId);
			req.setCellPhone(cellPhone);
			req.setReceiverName(name);
			req.setChannel(loginChannelId);
			if("Y".equals(isY)){
				req.setDlvTime(sdf.format(DateUtils.addSeconds(new Date(), 15)));
			}else{
				SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd 10:00:00");
				req.setDlvTime(sdf1.format(DateUtils.addDays(new Date(), 1)));
			}
			request.setSendMobileVerifyRequest(req);
			MobileVerifyService verifyMobile = (MobileVerifyService) externalWSClient.create(MobileVerifyService.class,"EC-WS-MSG", "MobileVerify", null);
			ObjectFactory obj = new ObjectFactory();
			JAXBElement<DoVerifyMobile> in = obj.createVerifyMobile(request);
			String input = jaxbObjectToXML(request,in);
			response = verifyMobile.doVerifyMobile(request);
			JAXBElement<Object> out = obj.createVerifyMobileResponse(response);
			String output = jaxbObjectToXML(response,out);
			int rcode = response.getSendMobileVerifyResponse().getRtnCode();
			String rerr = response.getSendMobileVerifyResponse().getRtnMsg();
			// 記錄資料
			MembersEcSycn ec = new MembersEcSycn();
			ec.setMemberId(Long.parseLong(memberId));
			ec.setResult((rcode>0)?"Y":"N");
			ec.setErrorMsg(response.getSendMobileVerifyResponse().getRtnMsg());
			ec.setModifyTime(new Date());
			ec.setCreateTime(new Date());
			ec.setWebServiceName("mobileVerify");
			this.getMemberService().getMemberDao().getHibernateTemplate().saveOrUpdate(ec);
			// 更新
			Members om = this.getMemberService().getMemberDao().findMemberByMemberId(Long.parseLong(memberId));
			om.setMbRegYn(status);
			Members nm = (Members)SerializationUtils.clone(om);
			if(rcode>0){
				MmMbPhoneReg reg = this.getMemberService().getMemberDao().findMmMbPhoneReg(memberId,BsCompanyDefinition.getCompanyId());
				if(reg!=null){
					reg.setStatus("YR");
					reg.setModifyTime(new Date());
					reg.setSendTime(new Date());
					nm.setMbRegYn("YR");
					this.getMemberService().getMemberDao().getHibernateTemplate().update(reg);
				}else{
					MmMbPhoneReg newReg = new MmMbPhoneReg();
					newReg.setMemberId(Long.parseLong(memberId));
					newReg.setMbPhoneReg(cellPhone);
					newReg.setStatus("YR");
					newReg.setCreateTime(new Date());
					newReg.setModifyTime(new Date());
					newReg.setSendTime(new Date());
					newReg.setCompanyId(BsCompanyDefinition.getCompanyId());
					this.getMemberService().getMemberDao().getHibernateTemplate().save(newReg);
				}
				nm.setResId1("ER");
				nm.setResId2(StringUtils.isNotEmpty(nm.getPersonId())?"013":"014");
				nm.setStatus(2);
				nm.setCellPhone(cellPhone);
				nm.setResulm(((BsCode)this.getMemberService().getBsCodeDAO().findAllByCodeClass("ER", StringUtils.isNotEmpty(nm.getPersonId())?"013":"014").get(0)).getClassExplain());
				this.getMemberService().getMemberDao().getHibernateTemplate().update(nm);
			}
			returnmap.put("id", rcode);
			returnmap.put("err", rerr);
			
			ModifyService modifyService = (ModifyService)AppContext.getBean("modifyService");
			modifyService.createModifyRecord(om.getOid(), om, nm, this.getUser().getUserId(), this.getUser().getUserName());
			CrmWebServiceLog crmLog = new CrmWebServiceLog();
			InetAddress ip = InetAddress.getLocalHost();
			crmLog.setOid(ec.getOid());
			crmLog.setWebServiceName("mobileVerify");
			crmLog.setReqDate(new Date());
			crmLog.setContent(input+output);
			crmLog.setSourceIp(ip.getHostAddress());
			this.getMemberService().getMemberDao().getHibernateTemplate().save(crmLog);
			return returnmap;
		}catch(Exception e){
			e.printStackTrace();
		}	
		return returnmap;
	}
	
	private static  String  jaxbObjectToXML(Object customer,Object des) {
	    String xmlString = "";
	    try {
	        JAXBContext context = JAXBContext.newInstance(customer.getClass());
	        Marshaller m = context.createMarshaller();
	        StringWriter sw = new StringWriter();
	        m.marshal(des, sw);
	        xmlString = sw.toString();
	    } catch (JAXBException e) {
	        e.printStackTrace();
	    }
	    return xmlString;
	}
	
	public Map checkMobileVerifyCode(String memberId,String cellPhone,String brithday, String verifyCode, String status){
		try{
			// call webservice
			Map returnmap = new HashMap();
			com.trg.oms.externalWS.ec.mobileVerify.DoCheckMobileVerifyCode request = new com.trg.oms.externalWS.ec.mobileVerify.DoCheckMobileVerifyCode();
			com.trg.oms.externalWS.ec.mobileVerify.DoCheckMobileVerifyCode.CheckMobileVerifyCodeRequest req = new com.trg.oms.externalWS.ec.mobileVerify.DoCheckMobileVerifyCode.CheckMobileVerifyCodeRequest();
			CheckMobileVerifyCodeResponse response = null;
			int year;
			if(brithday.length()>6){
				year = Integer.parseInt(brithday.substring(0,3)) + 1911;
				req.setBirthday(year + brithday.substring(3,7));
			}else{
				year = Integer.parseInt(brithday.substring(0,2)) + 1911;
				req.setBirthday(year + brithday.substring(2,6));
			}
			req.setSourceSystem("CRM_SYSTEM");
			req.setCompanyID(BsCompanyDefinition.getCompanyId());
			req.setCrmMemberID(memberId);
			req.setCellPhone(cellPhone);
			req.setVerifyCode(verifyCode);
			
			request.setCheckMobileVerifyCodeRequest(req);
			MobileVerifyService verifyMobile = (MobileVerifyService) externalWSClient.create(MobileVerifyService.class,"EC-WS-MSG", "MobileVerify", null);
			ObjectFactory obj = new ObjectFactory();
			JAXBElement<DoCheckMobileVerifyCode> in = obj.createCheckMobileVerify(request);
			String input = jaxbObjectToXML(request,in);
			response = verifyMobile.doCheckMobileVerifyCode(request);
			JAXBElement<Object> out = obj.createCheckMobileVerifyCodeResponse(response);
			String output = jaxbObjectToXML(response,out);
			int rcode = response.getCheckMobileVerifyCodeResponse().getRtnCode();
			String rerror = response.getCheckMobileVerifyCodeResponse().getRtnMsg();
			// 記錄至EC
			MembersEcSycn ec = new MembersEcSycn();
			ec.setMemberId(Long.parseLong(memberId));
			ec.setResult((rcode>0)?"Y":"N");
			ec.setErrorMsg(response.getCheckMobileVerifyCodeResponse().getRtnMsg());
			ec.setModifyTime(new Date());
			ec.setCreateTime(new Date());
			ec.setWebServiceName("checkMobileVerifyCode");
			this.getMemberService().getMemberDao().getHibernateTemplate().saveOrUpdate(ec);
			
			// 更新
			ModifyService modifyService = (ModifyService)AppContext.getBean("modifyService");
			Members om = this.getMemberService().getMemberDao().findMemberByMemberId(Long.parseLong(memberId));
			om.setMbRegYn(status);
			Members nm = (Members)SerializationUtils.clone(om);
			if(rcode>0){
				MmMbPhoneReg reg = this.getMemberService().getMemberDao().findMmMbPhoneReg(memberId,BsCompanyDefinition.getCompanyId());
				if(reg!=null){
					reg.setStatus("YY");
					reg.setRegTime(new Date());
					nm.setMbPhoneReg("YY");
					this.getMemberService().getMemberDao().getHibernateTemplate().update(reg);
					nm.setResId1(null);
					nm.setResId2(null);
					nm.setStatus(1);
					nm.setResulm(null);
					this.getMemberService().getMemberDao().getHibernateTemplate().update(nm);
				}
			}
			returnmap.put("id", rcode);
			returnmap.put("err", rerror);
			
			modifyService.createModifyRecord(om.getOid(), om, nm, this.getUser().getUserId(), this.getUser().getUserName());
			CrmWebServiceLog crmLog = new CrmWebServiceLog();
			InetAddress ip = InetAddress.getLocalHost();
			crmLog.setOid(ec.getOid());
			crmLog.setWebServiceName("checkMobileVerifyCode");
			crmLog.setReqDate(new Date());
			crmLog.setContent(input+output);
			crmLog.setSourceIp(ip.getHostAddress());
			this.getMemberService().getMemberDao().getHibernateTemplate().save(crmLog);
			return returnmap;
		}catch(Exception e){
			e.printStackTrace();
		}	
		return null;
	}
	
	@SuppressWarnings({ "unchecked", "unused" })
	public int phoneCertification(String phone){
		int result = 0;
		try{
			result = memberService.findMemberByPhone(phone, BsCompanyDefinition.getCompanyId());
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
	
	@SuppressWarnings({ "unchecked", "unused" })
	public int phoneCertificationFilterMemberId(String memberId, String phone){
		int result = 0;
		try{
			result = memberService.findMemberByPhoneFilterMemberId(memberId, phone, BsCompanyDefinition.getCompanyId());
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
	
	public int countMemberByPhoneFilterMemberIdAndName(String memberId, String phone, String name){
		int result = 0;
		try{
			result = memberService.countMemberByPhoneFilterMemberIdAndName(memberId, phone, BsCompanyDefinition.getCompanyId(), name);
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
	
	@SuppressWarnings({ "unchecked", "unused" })
	public int phoneAndNameCertification(String memberId, String phone, String name){
		QueryResult result = new QueryResult();
		try{
			result = memberService.findMemberByPhoneAndName(phone, name, this.getQueryStartIndex(),this.getPageBean().getPageSize(), this.hasToCountTotal(),BsCompanyDefinition.getCompanyId());
		}catch(Exception e){
			e.printStackTrace();
		}
		return result.getCount();
	}
	
	@SuppressWarnings({ "unchecked", "unused" })
	public int phoneCertifica(String phone){
		int result = 0;
		try{
			result = memberService.phoneCertifica(phone, BsCompanyDefinition.getCompanyId());
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
	
	public boolean isValidTWBID(String twbid){
		Pattern TWBID_PATTERN = Pattern.compile("^[0-9]{8}$");
		boolean result = false;
        String weight = "12121241";
        boolean type2 = false; //第七個數是否為七
        if (TWBID_PATTERN.matcher(twbid).matches()) {
            int tmp = 0, sum = 0;
            for (int i = 0; i < 8; i++) {
                tmp = (twbid.charAt(i) - '0')*(weight.charAt(i) - '0');
                sum += (int) (tmp / 10) + (tmp % 10); //取出十位數和個位數相加
                if (i == 6 && twbid.charAt(i) == '7') {
                    type2 = true;
                }
            }
            if (type2) {
                if ((sum % 10) == 0 || ((sum + 1) % 10) == 0) { //如果第七位數為7
                    result = true;
                }
            } else {
                if ((sum % 10) == 0) {
                    result = true;
                }
            }
        }
        return result;
	}

	public String saveOrUpdateRemark(){ 
		try {
			this.membersRemark = membersRemarkService.saveOrUpdateRemarkForMember(this.getMemberOid(), this.remark, this.getCurrentUser()); 
		} catch (Exception e) {
			e.printStackTrace();
			return ERROR;
		}  
		return SUCCESS;
	}
	
	public String memHasBusinessCard(String memberId) throws Exception {
		String has = "Y";
		
		try {
			Members member = this.getMemberService().getMemberDao().findMemberByMemberId(Long.parseLong(memberId));
			for (MmCard card : member.getMmCard()) {
				if (1 == card.getCardType()) {
					log.info(String.format("會員有商務卡:%s,status:%d", card.getVipNo(), card.getStatus()));
					if (1 == card.getStatus() || 2 == card.getStatus()) {
						has = "Y";
						break;
					} else {
						has = "N";
					}
				} else {
					has = "N";
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new Exception("檢查會員商務卡失敗,請洽總公司商務會員窗口,謝謝");
		}
		return has;
	}
	
    public Members mergeMemberCheckName(String memberId){
        Members result = new Members();
        try{
            result = memberService.queryMemberByMemberId(memberId);
        }catch(Exception e){
            log.error(e.getMessage(), e);
        }
        return result;
    }
	
	public String queryAppPayTransDetail() {
		try {
			List<AppPaySumByChannelVo> appPaySumList = new ArrayList<>();
			BigDecimal appPayMoney = BigDecimal.ZERO;

			List<String> memberIdList = new ArrayList<>();
			memberIdList.add(memberId);
			
			AppQueryPayCardNoData<AppPayCardVo> appPayCardRes = memberService.callAppQueryPayCard(memberIdList, 5000);
			if (AppPayStaticString.ERROR.equals(appPayCardRes.getStatus())) {
				String msg = String.format(AppPayStaticString.ERR_FORMAT, appPayCardRes.getErrorCode(), appPayCardRes.getMessage());
				log.info("呼叫AppQueryPayCard失敗: " + msg);
				if (memberService.checkAppErrorCode(appPayCardRes.getErrorCode())) {
					addActionError(AppPayStaticString.APP_PAY_ERROR_FOR_DETAIL);
					return ERROR;
				}
			} else {
				AppQueryBonusData<QueryBonusRespVo> response = new AppQueryBonusData<>();
				// 呼叫電子錢包餘額
				int count = 0;
				boolean queryAppPayBonusResult = true;
				while (queryAppPayBonusResult) {
					try {
						response = memberService.callAppQueryBonus(memberIdList, 7000);
						queryAppPayBonusResult = false;
					} catch (Exception e) {
						log.error("callAppQueryBonus try " + String.valueOf(count) + " time");
						if (count >= 3) {
							addActionError(AppPayStaticString.APP_PAY_ERROR_FOR_DETAIL);
							throw e;
						} else {
							log.error(e.getMessage(), e);
							count++;
						}
					}
				}
				
				if (AppPayStaticString.ERROR.equals(response.getStatus())) {
					String msg = String.format(AppPayStaticString.ERR_FORMAT, response.getErrorCode(), response.getMessage());
					log.info("呼叫AppQueryBonus失敗: " + msg);
					if (memberService.checkAppErrorCode(response.getErrorCode())) {
						addActionError(AppPayStaticString.APP_PAY_ERROR_FOR_DETAIL);
						return ERROR;
					}
				} else {
					appPaySumList = memberService.convertAppPaySum(response);
					appPayMoney = memberService.calculateAppPayMoneySum(response);
				}
			}
			
			HttpServletRequest request = this.getRequest();
			request.setAttribute(AppPayStaticString.APP_PAY_SUM_LIST, appPaySumList);
			request.setAttribute(AppPayStaticString.APP_PAY_MONEY, appPayMoney);
			String appQueryTxnFileUrl = WebServiceUtils.getProperty("APP_QUERY_TXN_FILE");
			request.setAttribute(AppPayStaticString.APP_URL, appQueryTxnFileUrl);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			addActionError(AppPayStaticString.EXCEPTION);
		}
		return Action.SUCCESS;
	}
	
	public String queryAppMem() {
		
		try {
			AppMemberQuery appMemQry = memberService.callAppMemberQuery(memberId, 5000);
			 
			if ("ERROR".equals(appMemQry.getStatus())) {
				String msg = String.format("errCode:%s,errMsg:%s", appMemQry.getErrorCode(), appMemQry.getMessage());
				log.info("呼叫取得App註冊狀態失敗: " + msg);
				addActionError("[App註冊狀態查詢異常,請稍後再試]");
				return ERROR;
			} else {
				AppMemberVo appMemberVo = appMemQry.getData();
				SimpleDateFormat formt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				if(appMemberVo.getAppRegDate()!=null) {
					appMemberVo.setAppRegDateToDate(formt.parse(appMemberVo.getAppRegDate()));
				}
				if(appMemberVo.getFirstLogin()!=null) {
					appMemberVo.setFirstLoginToDate(formt.parse(appMemberVo.getFirstLogin()));
				}
				if(appMemberVo.getLastLogin()!=null) {
					appMemberVo.setLastLoginToDate(formt.parse(appMemberVo.getLastLogin()));
				}
				if(appMemberVo.getCreateDate()!=null) {
					appMemberVo.setCreateDateToDate(formt.parse(appMemberVo.getCreateDate()));
				}
				
				HttpServletRequest request = this.getRequest();
				request.setAttribute("appMemberVo", appMemberVo);
			}
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	
		return Action.SUCCESS;
	}
	
	public String queryMemLike() {
		
		try {
			MemberLikeQuery memLikeQry = memberService.callMemberLikeQuery(memberId, 5000);
			 
			if ("ERROR".equals(memLikeQry.getStatus())) {
				String msg = String.format("errCode:%s,errMsg:%s", memLikeQry.getErrorCode(), memLikeQry.getMessage());
				log.info("呼叫取得偏好設定失敗: " + msg);
				addActionError("[偏好設定查詢異常,請稍後再試]");
				return ERROR;
			} else {
				MemberLikeCount memLikeCount = memLikeQry.getData();
				List<MemberLikeVo> memberLikeVoList = memLikeCount.getList();
				
				SimpleDateFormat formt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");				
				for (MemberLikeVo vo : memberLikeVoList) {
					if(vo.getModifyDate()!=null) {
						vo.setModifyDateToDate(formt.parse(vo.getModifyDate()));
					}
					if(vo.getCreateDate()!=null) {
						vo.setCreateDateToDate(formt.parse(vo.getCreateDate()));
					}
				}
				
				HttpServletRequest request = this.getRequest();
				request.setAttribute("memberLikeVoList", memberLikeVoList);
			}
			
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	
		return Action.SUCCESS;
	}
	
	public String checkIsEmployee() {
		try {
			// 查員工卡
			MmCardQueryCondition cardCondition = new MmCardQueryCondition();
			cardCondition.setMemberId(Long.valueOf(memberId));
			cardCondition.setCompanyId(this.getUser().getCompanyId());
			cardCondition.setStatusArray(new Object[] {1, 2});
			cardCondition.setCardTypeArray(new Object[] {2});
			List<MmCard> cardList = memberService.selectMmCardByCondition(cardCondition);
			// 建重導網址
			buildCustomerUrl(cardList);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return Action.SUCCESS;
	}
	
	private void buildCustomerUrl(List<MmCard> cardList) throws UnsupportedEncodingException {
		StringBuilder builder = new StringBuilder(ResourceBundle.getBundle("crmCommon").getString("REGULAR_CUSTOMER_URL"));
		builder.append("&userID=").append(userID).
		append("&userName=").append(userName).
		append("&memberID=").append(memberId);
		String isEmpCard = cardList.isEmpty() ? "N" : "Y";
		builder.append("&isEmployee=").append(isEmpCard);

		regularCustomerUrl = builder.toString();
	}
	
	public MembersRemark getMembersRemark() {
		return membersRemark;
	}
	
	public void setMembersRemark(MembersRemark membersRemark) {
		this.membersRemark = membersRemark;
	}
	
	public IMembersRemarkService getMembersRemarkService() {
		return membersRemarkService;
	}
	
	public void setMembersRemarkService(IMembersRemarkService membersRemarkService) {
		this.membersRemarkService = membersRemarkService;
	}
	
	public String getRemark() {
		return remark;
	}
	
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public BsCompanyService getBsCompanyService() {
		return bsCompanyService;
	}
	public void setBsCompanyService(BsCompanyService bsCompanyService) {
		this.bsCompanyService = bsCompanyService;
	} 
	public MtGroupVipService getMtGroupVipService() {
		return mtGroupVipService;
	}
	public void setMtGroupVipService(MtGroupVipService mtGroupVipService) {
		this.mtGroupVipService = mtGroupVipService;
	}
	public MtVipMasterDAO getMtVipMasterDao() {
		return mtVipMasterDao;
	}
	public void setMtVipMasterDao(MtVipMasterDAO mtVipMasterDao) {
		this.mtVipMasterDao = mtVipMasterDao;
	}
	public String getSyncFlag() {
		return syncFlag;
	}
	public void setSyncFlag(String syncFlag) {
		this.syncFlag = syncFlag;
	}
	public MemberBaseAction getMemberBaseAction() {
		return memberBaseAction;
	}
	public void setMemberBaseAction(MemberBaseAction memberBaseAction) {
		this.memberBaseAction = memberBaseAction;
	}
}
