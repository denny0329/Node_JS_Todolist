/**
 * @(#)BsSkuDwrAction.java 2014/09/15
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.gccs.util.dwr;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.AppContext;
import com.bnq.util.QueryResult;
import com.bnq.util.StringId;
import com.gccs.bs.dao.hibernate.BsSkuDao;
import com.gccs.bs.model.BsClass;
import com.gccs.bs.model.condition.BsSkuCondition;
import com.gccs.bs.service.BsClassService;
import com.gccs.bs.service.BsSkuService;
import com.gccs.bs.service.IBsBizDeptService;
import com.gccs.util.cache.BsCompanyDefinition;
import com.rfep.iv.rtv.service.RtvService;
import com.rfep.nm.service.NmProduceService;
import com.rfep.product.bs.dao.hibernate.BsSkuUnitDao;
import com.rfep.product.bs.model.BsSku;
import com.rfep.product.bs.service.PdSkuService;
import com.rfep.so.bs.service.SoDeliverySkuService;
import com.trg.oms.utils.UserUtil;

/**
 * @author kaychen
 * @Date: 2010/1/11 下午 12:18:37
 * @Project Name: RFEP
 */
public class BsSkuDwrAction {
	private final Logger log = LogManager.getLogger(BsSkuDwrAction.class) ;
	private BsSkuService bsSkuService ;
	private BsClassService bsClassService ;
	private IBsBizDeptService bsBizDeptService;
	private	PdSkuService pdService;
	private NmProduceService nmProduceService;
	private SoDeliverySkuService soDeliverySkuService;
	private BsSkuUnitDao bsSkuUnitDao;
	
	public NmProduceService getNmProduceService() {
		return nmProduceService;
	}
	public void setNmProduceService(NmProduceService nmProduceService) {
		this.nmProduceService = nmProduceService;
	}
	public BsSkuService getBsSkuService() {
		return bsSkuService;
	}
	public void setBsSkuService(BsSkuService bsSkuService) {
		this.bsSkuService = bsSkuService;
	}
	public BsClassService getBsClassService() {
		return bsClassService;
	}
	public void setBsClassService(BsClassService bsClassService) {
		this.bsClassService = bsClassService;
	}
	public IBsBizDeptService getBsBizDeptService() {
		return bsBizDeptService;
	}
	public void setBsBizDeptService(IBsBizDeptService bsBizDeptService) {
		this.bsBizDeptService = bsBizDeptService;
	}
	public PdSkuService getPdService() {
		return pdService;
	}
	public void setPdService(PdSkuService pdService) {
		this.pdService = pdService;
	}
	public SoDeliverySkuService getSoDeliverySkuService() {
		return soDeliverySkuService;
	}
	public void setSoDeliverySkuService(SoDeliverySkuService soDeliverySkuService) {
		this.soDeliverySkuService = soDeliverySkuService;
	}

	public void setBsSkuUnitDao(BsSkuUnitDao bsSkuUnitDao) {
		this.bsSkuUnitDao = bsSkuUnitDao;
	}
	/**
	 * 取得商品基本資料。
	 * @param sku 商品代碼。
	 * @return 取不到回傳 null。
	 * @throws Exception
	 */
	public BsSku getBsSku(String sku) throws Exception {
		try {
			return bsSkuService.findBsSku(sku, BsCompanyDefinition.getCompanyId());
		} catch(Exception e) {
			log.error(e.getMessage(), e);
			return null;
		}
	}

	public BsSku getSkuBySubDeptAndSkuNo(String store, String subDept, String sku) throws Exception {
		log.debug("[getBsSku] StoreId : " + store + " SubDept : " + subDept + " , sku : "+sku) ;
		BsSku bsSku = this.getPdService().getSkuBySubDeptAndSkuNo(store, subDept, sku);
		return bsSku ;
	}
	
	public String chkSkuClass(String dept,String subDept,String clazz,String subClass) {
		log.debug("[chkSkuClass] "+dept+"-"+subDept+"-"+clazz+"-"+subClass) ;
		BsClass bo = new BsClass() ;
		bo.setDept(dept) ;
		bo.setSubDept(subDept) ;
		bo.setClass_(clazz) ;
		bo.setSubClass(subClass) ;
		if(!bo.isFormatValid()) {
			return "必須輸入前項分類" ;
		}
		

		List<BsSkuCondition> conditionList = new ArrayList<BsSkuCondition>() ;
		BsSkuCondition condition = new BsSkuCondition() ;
		condition.setDept(dept) ;
		condition.setSubDept(subDept) ;
		condition.setClazz(clazz) ;
		condition.setSubClass(subClass) ;
		conditionList.add(condition) ;
		try {
			if(this.getBsClassService().checkClassExists(conditionList) != null) {
				return "分類不正確" ;
			}
		} catch (Exception e) {
			log.error(e.getMessage(),e) ;
			return "讀取資料錯誤" ;
		}
		return "" ;
	}
	
	public String chkNmSkuClass(String dept,String subDept,String clazz,String subClass,String cid) {
		log.debug("[chkSkuClass] "+dept+"-"+subDept+"-"+clazz+"-"+subClass) ;
		BsClass bo = new BsClass() ;
		bo.setDept(dept) ;
		bo.setSubDept(subDept) ;
		bo.setClass_(clazz) ;
		bo.setSubClass(subClass) ;
		if(!bo.isFormatValid()) {
			return "必須輸入前項分類" ;
		}
		

		List<BsSkuCondition> conditionList = new ArrayList<BsSkuCondition>() ;
		BsSkuCondition condition = new BsSkuCondition() ;
		condition.setDept(dept) ;
		condition.setSubDept(subDept) ;
		condition.setClazz(clazz) ;
		condition.setSubClass(subClass) ;
		condition.setCompanyid(cid);
		conditionList.add(condition) ;
		try {
			if(this.getNmProduceService().checkClassExists(conditionList) != null) {
				return "使用者輸入分類不正確" ;
			}
		} catch (Exception e) {
			log.error(e.getMessage(),e) ;
			return "讀取資料錯誤" ;
		}
		return "" ;
	}

	/**
	 * 檢核「商品 SKU」或「商品分類」是否存在於 SO_DELIVERY_SKU。<br/>
	 * （Caller：/jsp/bs/SoDeliverySkuEdit.jsp）
	 * @param oid SO_DELIVERY_SKU.OID。
	 * @param value 商品 SKU 或 商品分類。
	 * @param companyId 公司別代碼。
	 * @param isSku 若為 true，則傳入的 value 為 商品 SKU。
	 * @return 若不存在於 SO_DELIVERY_SKU，則回傳空字串。
	 */
	public String checkkSkuOrMc(String oid, String value, String companyId, boolean isSku) {
		try {
			return soDeliverySkuService.checkSkuOrMc(oid, value, companyId, isSku);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return "讀取資料錯誤";
		}
	}

	/**
	 * 取得 營業課區 下拉清單
	 * @param channelId
	 * @param storeId
	 * @return
	 */
	public List<StringId> getDeptAreasByStore(String channelId, String storeId){
		Map<String, String[]> queryCondition = new HashMap<String, String[]>();
		queryCondition.put("channelId", new String[]{channelId});
		queryCondition.put("storeId", new String[]{storeId});
		return this.getBsBizDeptService().findAllDeptAreaByCannelIdAndStoreId(queryCondition);
	}
	
	/**
	 * 取得 營業課區 下拉清單
	 * @param channelId
	 * @param storeId
	 * @return
	 */
	public List<StringId> getDeptAreasByStoreWithout99(String channelId, String storeId){
		Map<String, String[]> queryCondition = new HashMap<String, String[]>();
		queryCondition.put("channelId", new String[]{channelId});
		queryCondition.put("storeId", new String[]{storeId});
		return this.getBsBizDeptService().findAllDeptAreaByCannelIdAndStoreId(queryCondition, false);
	}

	/**
	 * 取得只有父類別的營業課別下拉清單
	 * @param channelId 通路代碼
	 * @param storeId 店代碼
	 * @return 下拉選單物件
	 */
	public List<StringId> getParentDept(String channelId, String storeId) {
		return this.getBsBizDeptService().findParentDept(channelId, storeId);
	}

	/**
	 * 查詢此退廠單號是否屬於該店家
	 * @param channelId
	 * @param storeId
	 * @param formNo
	 * @return Map<String, Object>
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map<String, Object> checkStoreContainFormData(String channelId, String storeId, String formNo){
		RtvService rtvService = (RtvService) AppContext.getBean("rtvService");
		HashMap<String,String> condition = new HashMap<String,String>();
		condition.put("channelId", channelId);
		condition.put("storeId", storeId);
		condition.put("formNo", formNo);
		QueryResult result = rtvService.findPoRtvByCondition(condition,0,10,false);
		List list = result.getResult();
		Map<String, Object> mapResult = null;
		if(!list.isEmpty()){
			mapResult = new HashMap<String, Object>();
			mapResult = (Map<String, Object>)list.get(0);
			if(mapResult.get("STATUS").toString().equals("1") ) {
				mapResult.put("result", true);
			}
			else {
				mapResult.put("result", false);
			}
		}
		return mapResult;
	}
	
	/**
	 * 依sku找bsSku skuName
	 * @param sku
	 * @return String
	 */
	public String getBsSkuName(String sku) throws Exception {
		BsSku bsSku = getBsSku(sku);
		if(bsSku == null) {
			return "無此商品";
		}
		return bsSku.getSkuName();
	}

	/**
	 * 依分類找bsClass 分類Name
	 * @param subDept
	 * @param class_
	 * @param subClass
	 * @return String
	 */
	public String getBsClassName(String subDept, String class_, String subClass) throws Exception {
		BsClass bsClz = bsClassService.getBsClass(null, subDept, class_, subClass);
		if(bsClz == null) {
			return "無此類別";
		}
		return bsClz.getName2();
	}
	
	/**
	 * 依據UPC或SKU與公司別取得SKU
	 * @param code UPC/SKU
	 * @return 如果查無SKU則回傳"noSku"以做判斷,查詢有資料則直接回傳該SKU
	 */
	public String getSkuByUpcOrSku(String code) {
		String skuOrMsg = "";
		//取得公司別
		String companyId = UserUtil.getUserObject().getCompanyId();
		//依照公司別與UPC/SKU取得sku
		skuOrMsg = bsSkuUnitDao.findSkuByCode(code, companyId);
		
		return skuOrMsg;
	}
	
	/**
	 * 檢核 sku 的 sku_type(商品類型) 是否為'HAWA'、'FERT'、'ZHWA'。
	 * @param companyId 公司別代碼
	 * @param sku 商品代碼
	 * @return true: 是、false: 否
	 */
	public boolean isSkuTypeInHawaFertZhwa(String companyId, String sku){
		boolean result = false;

		try {
			BsSkuDao dao = (BsSkuDao)AppContext.getBean("bsSkuDao");
			result = dao.isSkuTypeInHawaFertZhwa(companyId, sku);
		} catch(Exception e) {
			log.error(e.getMessage(), e);
		}

		return result;
	}
	
//	public boolean isHisuSku(String productId){
//		boolean result = false;
//
//		try {
//			BsSkuDao dao = (BsSkuDao)AppContext.getBean("bsSkuDao");
//			result = dao.isHisuSku(productId);
//		} catch(Exception e) {
//			log.error(e.getMessage(), e);
//		}
//
//		return result;
//	}
}