/**
 * @(#) BsSkuDeptDwrAction.java 2016/07/19
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.gccs.util.dwr;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.rfep.product.bs.service.BsSkuDeptService;
import com.rfep.util.TokenUtil;

public class BsSkuDeptDwrAction {
	private static final Logger log = LogManager.getLogger(BsSkuDeptDwrAction.class) ;
	
	BsSkuDeptService bsSkuDeptService;

	public void setBsSkuDeptService(BsSkuDeptService bsSkuDeptService) {
		this.bsSkuDeptService = bsSkuDeptService;
	}
	
	/**
	 * 刪除品類與營業課區對應
	 * @param oids
	 * @param pageToken 頁面金鑰
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map deleteBsSkuDeptByOid(String[] oids, String pageToken) {		
		Map result = new HashMap();

		try {
			TokenUtil.checkTokenPreAction(pageToken);
			bsSkuDeptService.deleteBsSkuDept(oids);
			result.put("success", true);
			result.put("msg", "刪除成功！");
		} catch (Throwable e) {	
			log.error(e.getMessage(), e);
			result.put("success", false);
			if(StringUtils.isBlank(e.getMessage())) {
				result.put("msg", "程式發生錯誤，請洽系統人員！");
			} else {
				result.put("msg", e.getMessage());
			}
		}		
		
		return result;
	}
}