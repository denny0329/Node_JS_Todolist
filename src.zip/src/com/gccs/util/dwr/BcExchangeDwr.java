package com.gccs.util.dwr;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.gccs.bc.service.BcExchangeService;
import com.gccs.bs.model.condition.BsSkuCondition;
import com.gccs.bs.service.BsClassService;

/**
 * @author JL
 */
public class BcExchangeDwr {
	
	private BcExchangeService service;
	
	private BsClassService bsClassService;

	public BsClassService getBsClassService() {
		return bsClassService;
	}

	public void setBsClassService(BsClassService bsClassService) {
		this.bsClassService = bsClassService;
	}

	public BcExchangeService getService() {
		return service;
	}

	public void setService(BcExchangeService service) {
		this.service = service;
	}

	/**
	 * 檢核折現設定
	 * @param oid
	 * @param bsType
	 * @param activeDate
	 * @param inactiveDate
	 * @param channelId
	 * @param exBonus
	 * @return
	 */
	public Map<String,String> checkExchangeCash(String oid,String bsType,String activeDate,String inactiveDate
			,Map<String,Map<String,String>> channelId,String[] exBonus){
		return service.checkExchangeCash(oid, bsType, activeDate, inactiveDate, channelId, exBonus);
	}

	
	/**
	 * exists class
	 * @author JL
	 * @param params
	 * @return
	 * @throws Exception
	 */
	public BsSkuCondition checkClassExists(Map<String,String>[] params)throws Exception{
		BsSkuCondition condition;
		List<BsSkuCondition> bsSkuConditionList = new ArrayList<BsSkuCondition>();
		if (params!=null){
			for(Map<String,String> key:params){
				condition = new BsSkuCondition();
				condition.setDept(StringUtils.isNotBlank(key.get("dept"))? key.get("dept"):"");
				condition.setSubDept(StringUtils.isNotBlank(key.get("subDept"))? key.get("subDept"):"");
				condition.setClazz(StringUtils.isNotBlank(key.get("class_"))? key.get("class_"):"");
				condition.setSubClass(StringUtils.isNotBlank(key.get("subClass"))? key.get("subClass"):"");
				bsSkuConditionList.add(condition);
			}
		}
		return getBsClassService().checkClassExists(bsSkuConditionList);
	}
	
	/**
	 * 檢核channel store exists
	 * @param oid
	 * @param bsType
	 * @param activeDate
	 * @param inactiveDate
	 * @param channelId
	 * @return
	 */
	public Map<String,String> checkExchangeStore(String oid,String bsType,String activeDate,String inactiveDate
			,boolean isExchange,Map<String,Map<String,String>> channelId){
		return service.checkExchangeStore(oid, bsType, activeDate, inactiveDate, isExchange, channelId);
	}
	
	/**
	 * 檢核商品&&紅利&&店別&&通路在生效中的設定是否存在 
	 * @param oid
	 * @param bsType
	 * @param activeDate
	 * @param inactiveDate
	 * @param channelId
	 * @param sku
	 * @param exBonus
	 * @return
	 */
	public Map<String,String> checkExchangeSku(String oid,String bsType,String activeDate,String inactiveDate
			,Map<String,Map<String,String>> channelId,String[] channelSku,String[] sku,String[] exBonus){
		return service.checkExchangeSku(oid, bsType, activeDate, inactiveDate, channelId,channelSku,sku,exBonus);
	}

	/**
	 * 檢核商品及發票累積是否有重覆之設定
	 * @param oid
	 * @param bsType
	 * @param activeDate
	 * @param inactiveDate
	 * @param channelId
	 * @param roleString
	 * @return
	 */
	public Map<String,String> checkBonusSotreSku(String oid,String bsType,String activeDate,String inactiveDate,
			Map<String,Map<String,String>> channelId,String[] roleString){
		return service.checkBonusSotreSku(oid, bsType, activeDate, inactiveDate, channelId, roleString);
	}	
	
	public void processFile(File fileString){
		System.out.println(fileString);
	}
}
