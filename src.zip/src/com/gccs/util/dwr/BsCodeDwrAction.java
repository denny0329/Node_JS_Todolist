package com.gccs.util.dwr;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.directwebremoting.WebContext;
import org.directwebremoting.WebContextFactory;

import com.bnq.bs.model.BsCode;
import com.bnq.sc.model.ScSysuser;
import com.bnq.util.StringId;
import com.bnq.util.cache.BsCodeDefinition;
import com.gccs.util.web.SelectItem;

public class BsCodeDwrAction {
	public List<StringId> getArea2(String area,boolean freg) {
		List dataList = BsCodeDefinition.findAllByParentCodeClassAndParentCodeNo("AD", area);
		List<StringId> list = new ArrayList<StringId>();

		if(area!=null && !"".equals(area)){
			if(dataList!=null) {
				for(Iterator iterator = dataList.iterator(); iterator.hasNext(); ) {
					BsCode code = (BsCode)iterator.next();
					StringId id = new StringId(code.getId().getCodeNo(), code.getCodeExplain());
					list.add(id);
				}
			}
		}
		if(dataList==null){
			list.add(SelectItem._none);
		}else if(dataList.isEmpty())
			list.add(SelectItem._none);
		else
			if(freg)
				list.add(0,SelectItem._defaultSelect);
		return list;
	}


	public BsCode getAreaByCantactAddr2(String codeNo){
		return  BsCodeDefinition.findAllMemberByCodeClassAndCodeNo("AD", codeNo);
	}

	public static List<StringId> getBsChannelAll(){
		return SelectItem.getBsChannelAll(true);
	}

	public static List getBsChannelByAuth(String byAuth,String submitCancelFlag){
		WebContext ctx = WebContextFactory.get();
		HttpSession session = ctx.getSession() ;
		ScSysuser user = (ScSysuser)session.getAttribute("user");
		return SelectItem.getBsChannelByAuth(true, byAuth, submitCancelFlag, user);
	}

	public static BsCode getBankBsCodeByCodeNo(String cardNo){
		BsCode bscode = BsCodeDefinition.findBankBsCodeByparentcodeClassAndCodeNo(cardNo);
		return bscode;
	}
	
	public static List<StringId> getForeignCountryArea(boolean flag){
		List dataList = BsCodeDefinition.findAllByCodeClass("COUNTRY");
		List<StringId> list = new ArrayList<StringId>();

		
			if(dataList!=null) {
				for(Iterator iterator = dataList.iterator(); iterator.hasNext(); ) {
					BsCode code = (BsCode)iterator.next();
					StringId id = new StringId(code.getId().getCodeNo(), code.getCodeExplain());
					list.add(id);
				}
			}
		
		if(dataList==null){
			list.add(SelectItem._none);
		}else if(dataList.isEmpty())
			list.add(SelectItem._none);
		else
			if(flag)
				list.add(0,SelectItem._defaultSelect);
		return list;
	}
	
	
	
	public static List<StringId> getForeignRegion(String parentCodeNo ,boolean flag){
		List dataList = BsCodeDefinition.findAllByParentCodeClassAndParentCodeNo("COUNTRY",parentCodeNo);
		List<StringId> list = new ArrayList<StringId>();

		
			if(dataList!=null) {
				for(Iterator iterator = dataList.iterator(); iterator.hasNext(); ) {
					BsCode code = (BsCode)iterator.next();
					StringId id = new StringId(code.getId().getCodeNo(), code.getCodeExplain());
					list.add(id);
				}
			}
		
		if(dataList==null){
			list.add(SelectItem._none);
		}else if(dataList.isEmpty())
			list.add(SelectItem._none);
		else
			if(flag)
				list.add(0,SelectItem._defaultSelect);
		return list;
	}
	public static BsCode getForeignRegionPostCode(String postCode){
		BsCode bscode = BsCodeDefinition.findAllMemberByCodeClassAndCodeNo("FD",postCode);
		return bscode;
	}
}
