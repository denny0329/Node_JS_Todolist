package com.gccs.util.dwr;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gccs.bc.model.BcBonusSettingMst;
import com.gccs.bc.service.BcBonusService;

/**
 * @author Van
 *
 */
public class BcBonusDwrAction {

	private static final Logger log = LogManager.getLogger(BcBonusDwrAction.class) ;

	private BcBonusService  bbService;
	private MarketingDwrAction mtDwrAction;

	public MarketingDwrAction getMtDwrAction() {
		return mtDwrAction;
	}


	public void setMtDwrAction(MarketingDwrAction mtDwrAction) {
		this.mtDwrAction = mtDwrAction;
	}


	public BcBonusService getBbService() {
		return bbService;
	}


	public void setBbService(BcBonusService bbService) {
		this.bbService = bbService;
	}

	public BcBonusSettingMst getCumlByPromotId(String promotId) {
		BcBonusSettingMst cuml = null ;
		try {
			if (StringUtils.isNotBlank(promotId)){
				cuml = this.getBbService().getBcBonusCuml(null, promotId) ;
				if(cuml.getBsType().intValue() != Integer.parseInt(BcBonusService.TYPE_CODE_99) && 
						cuml.getBsType().intValue()  != Integer.parseInt(BcBonusService.TYPE_CODE_98) &&
						cuml.getBsType().intValue()  != Integer.parseInt(BcBonusService.TYPE_CODE_97) && 
						cuml.getBsType().intValue()  != Integer.parseInt(BcBonusService.TYPE_CODE_96)) {
					return null ;
				}
			}
		} catch (Throwable e) {
			log.error(e.getMessage(),e) ;
		}
		return cuml ;
	}
}
