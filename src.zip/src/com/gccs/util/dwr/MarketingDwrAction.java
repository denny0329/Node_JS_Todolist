package com.gccs.util.dwr;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.directwebremoting.WebContext;
import org.directwebremoting.WebContextFactory;

import com.bnq.sc.model.ScSysuser;
import com.bnq.util.DateTimeUtils;
import com.bnq.util.QueryResult;
import com.gccs.bs.model.BsChannel;
import com.gccs.bs.model.BsClass;
import com.gccs.marketing.model.DiscountSku;
import com.gccs.marketing.model.MtGroup;
import com.gccs.marketing.model.condition.DiscountCondition;
import com.gccs.marketing.model.condition.MtGroupCondition;
import com.gccs.marketing.model.vo.DiscountChannelVo;
import com.gccs.marketing.model.vo.DiscountSkuVo;
import com.gccs.marketing.model.vo.DiscountVo;
import com.gccs.marketing.model.vo.MtGroupVo;
import com.gccs.marketing.service.MarketingService;
import com.gccs.marketing.util.MarketingGlossary;
import com.gccs.util.cache.BsChannelDefinition;
import com.gccs.ws.service.BaseWebService;
import com.opensymphony.xwork2.Action;
import com.rfep.util.BsClassUtil;

/**
 * <b></b>
 * @author kaychen
 * @Date: 2010/1/18 上午 10:34:12
 * @Project Name: RFEP
 */
public class MarketingDwrAction {
	private static final Logger log = LogManager.getLogger(MarketingDwrAction.class) ;
	private MarketingService mtService ;

	public MarketingService getMtService() {
		return mtService;
	}

	public void setMtService(MarketingService mtService) {
		this.mtService = mtService;
	}

	public List<DiscountChannelVo> getDiscountChannel(String discountOid) throws Exception {
		if(discountOid == null || discountOid.equals("")) {
			return null ;
		}
		DiscountVo vo = this.getMtService().getDiscountVoByOid(discountOid,true,false) ;
		List<DiscountChannelVo> disCVoList = vo.getDiscountChannel();
		DiscountChannelVo _vo = null;
		//去除不上架的通路
		if( disCVoList != null ){
			for( int i = (disCVoList.size()-1); i >=0; i--){
				_vo = disCVoList.get(i);
				if( BsChannelDefinition.getChannelByChannelId(_vo.getChannelId()) != null ){
					if( !BsChannelDefinition.getChannelByChannelId(_vo.getChannelId()).getStatus() ){
						disCVoList.remove(i);
					}
				}else{
					disCVoList.remove(i);
				}
			}
			vo.setDiscountChannel(disCVoList);
		}
		if(vo != null) {
			return vo.getDiscountChannel() ;
		}
		return null ;
	}

	public boolean checkEmployeeDayConditionValid(String cardType,boolean isEmployeeDay,String expDateFrom,String oid) {
		log.info("cardType : "+cardType) ;
		log.info("employeeDay : "+isEmployeeDay) ;
		log.info("expDateFrom : "+expDateFrom) ;
		DiscountCondition condition = new DiscountCondition() ;
		condition.setCardType(cardType) ;
		condition.setEmployeeDay(isEmployeeDay) ;
		condition.setType(MarketingGlossary._discountType_group) ;
		condition.setTempStatus(2);
		if(StringUtils.isNotEmpty(oid))
			condition.setTempOid(oid);
		try{
			condition.setExpireDate(DateTimeUtils.getDateFormat(expDateFrom)) ;
			QueryResult result = mtService.getDiscountList(condition, 0, 0, false) ;
			if(result.getResult().size() == 0) {
				return true ;
			}else{
				return false ;
			}
		} catch(Throwable t) {
			return false ;
		}
	}

	public boolean checkChannelAndCardActivate(String channelId,String cardType) {
		log.info("channelId : "+channelId) ;
		log.info("cardType : "+cardType) ;
		return true ;
	}
	
	public String getBsClassByName1(String _subDept, String _class, String _subClass){
		return BsClassUtil.getSubClassName("000", _subDept, _class, _subClass);
	}
	
	public String getBsClassByName1(String _dept, String _subDept, String _class, String _subClass){
		return BsClassUtil.getSubClassName(_dept, _subDept, _class, _subClass);
	}
	
	/**
	 * 查詢BSClass對應Class Name
	 * @param classIdObj
	 * @return
	 */
	public String[] ajaxQueryClassMappedName(String classIdObj,String idx){
		log.info("classId : "+classIdObj + " idx : "+idx);
		try{
			String[] classIds = classIdObj.split(",");
			String deptId =passByIgnoreStr(classIds[0]);
			String subDeptId = passByIgnoreStr(classIds[1]);
			String classId = passByIgnoreStr(classIds[2]);
			String subClassId = passByIgnoreStr(classIds[3]);
			log.info("查詢條件 deptId => "+deptId+" subDeptId => "+subDeptId + " classId => "+ classId +" subClassId => "+subClassId);
			List<BsClass> list = this.getMtService().queryClassMappedName(deptId, subDeptId, classId, subClassId);
			String []rtResult = null;
			if(list !=null && list.size()>0){
				log.info("BsClass list size : "+list.size());
				log.info("BsClass Name2 : "+ ((BsClass)list.get(0)).getName2());
				rtResult = new String[2];
				rtResult[0] = idx;
				rtResult[1] =  ((BsClass)list.get(0)).getName2();
				return rtResult;
			}else log.info("BsClass list is null. ");
		}catch(Exception e){
			log.error(e.getMessage(),e) ;
		}
		return null;
	}

	/**
	 * queryClassMappedName
	 * @param classIdObj
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public String queryClassMappedName(String dept,String subDept,String class_,String subClass){

		try{
			log.info("查詢條件 deptId => "+dept+" subDeptId => "+subDept + " classId => "+ class_ +" subClassId => "+subClass);
			List<BsClass> list = this.getMtService().queryClassMappedName(dept, subDept, class_, subClass);
			if(list !=null && list.size()>0){
				log.info("BsClass list size : "+list.size());
				log.info("BsClass Name2 : "+ ((BsClass)list.get(0)).getName2());
				return ((BsClass)list.get(0)).getName2();
			}else return null;
		}catch(Exception e){
			log.error(e.getMessage(),e) ;
		}
		return null;
	}

	public String ajaxChangeDeptSubdeptClassSubclassAndItem(String refOid) throws Exception{
		log.info("refOid :"+refOid);
		try{
			if(!BaseWebService.isEmpty(refOid))
				this.getMtService().deleteDiscountByRefOid(refOid);
			else log.info("refOid is null or empty");
		}catch(Exception e){
			log.error(e.getMessage(),e) ;
			e.printStackTrace();
			return "更新失敗("+e.getMessage()+")，請洽系統管理人員!";
		}
		return Action.SUCCESS ;

	}
	public String[] ajaxModifyAccountRestrictionSku(Map<String,List> dataMap) {
		String []rtResult = null;
		try {
			Set set = dataMap.keySet();
			Iterator it = set.iterator();
			while ( it.hasNext()){
				log.info( (String) ((ArrayList)dataMap.get((String)it.next())).get(0));
			}

			//boolean expSkuType = Boolean.parseBoolean((String)((ArrayList)dataMap.get("expSkuType")).get(0));
			String userId = (String)((ArrayList)dataMap.get("userId")).get(0);
			String userName = (String)((ArrayList)dataMap.get("userName")).get(0);
			String refOid =(String)((ArrayList)dataMap.get("refOid")).get(0);
			log.info("refOid : "+refOid);

			List<String> oid = (ArrayList)dataMap.get("oid");
			List<String> channelId = (ArrayList)dataMap.get("channelId");
			List<String> deptSubdeptClassSubclass = (ArrayList)dataMap.get("deptSubdeptClassSubclass");
			List<String> expDeptSubdeptClassSubclass = (ArrayList)dataMap.get("expDeptSubdeptClassSubclass");
			List<String> skuIdAndName = (ArrayList)dataMap.get("skuIdAndName");
			List<String> expSkuIdAndName = (ArrayList)dataMap.get("expSkuIdAndName");

			List newDiscountSkuList = new ArrayList();
			List oldDiscountSkuList = new ArrayList();

			if(oid!=null){
				log.info("oid size: "+oid.size());
				for(int i=0;i<oid.size();i++){
					log.info("第"+i+"筆 deptSubdeptClassSubclass: "+(String)deptSubdeptClassSubclass.get(i));

					DiscountSku sku = new DiscountSku();
					String[] deptSubClass = deptSubdeptClassSubclass.get(i).split(",");
					String[] expDeptSubClass = expDeptSubdeptClassSubclass.get(i).split(",");
					String[] skuIdAndNames = skuIdAndName.get(i).split(",");
					String[] expSkuIdAndNames = expSkuIdAndName.get(i).split(",");


					log.info("oid["+i+"]"+oid.get(i));
					log.info("channelId["+i+"]"+channelId.get(i));
					log.info("deptSubdeptClassSubclass["+i+"]"+deptSubdeptClassSubclass.get(i));
					log.info("expDeptSubdeptClassSubclass["+i+"]"+expDeptSubdeptClassSubclass.get(i));
					log.info("skuIdAndName["+i+"]"+skuIdAndName.get(i));
					log.info("expSkuIdAndName["+i+"]"+expSkuIdAndName.get(i));

					sku.setOid(oid.get(i));
					sku.setRefOid(refOid);
					sku.setChannelId(channelId.get(i));
					sku.setStatus(true);
					sku.setModifyTime(new Date());
					sku.setModifier(userId);
					sku.setModifierName(userName);

					sku.setCreateTime(new Date());
					sku.setCreator(userId);


					sku.setExpDeptId(passByIgnoreStr(expDeptSubClass[0]));
					sku.setExpSubDeptId(passByIgnoreStr(expDeptSubClass[1]));
					sku.setExpClassId(passByIgnoreStr(expDeptSubClass[2]));
					sku.setExpSubClassId(passByIgnoreStr(expDeptSubClass[3]));

					sku.setExpSku(expSkuIdAndNames[0]);
					sku.setExpSkuName(passByIgnoreStr(expSkuIdAndNames[1]));

					sku.setDeptId(passByIgnoreStr(deptSubClass[0]));
					sku.setSubDeptId(passByIgnoreStr(deptSubClass[1]));
					sku.setClassId(passByIgnoreStr(deptSubClass[2]));
					sku.setSubClassId(passByIgnoreStr(deptSubClass[3]));

					sku.setSku(skuIdAndNames[0]);
					sku.setSkuName(passByIgnoreStr(skuIdAndNames[1]));

					if(sku.getOid()!=null&& !"".equalsIgnoreCase(sku.getOid()))
						oldDiscountSkuList.add(sku);
					else {
						log.info("new DiscountSku 準備新增 oid"+sku.getOid());
						newDiscountSkuList.add(sku);
					}
				}
			}
			log.info("oldDiscountSkuList : "+oldDiscountSkuList.size());
			log.info("newDiscountSkuList : "+newDiscountSkuList.size());
			for(int i=0;i<oldDiscountSkuList.size();i++){
				DiscountSku sku = (DiscountSku)oldDiscountSkuList.get(i);
				log.info("old 第 "+i+" 筆: oid => "+sku.getOid()+" refOid => "+sku.getRefOid()+
						" dept => "+sku.getDeptId()+" subDept => "+sku.getSubDeptId()+
						" classId => "+sku.getClassId()+" subClassId => "+sku.getSubClassId());
			}

			//Save DiscountSku
			this.mtService.saveDiscountSkus(oldDiscountSkuList, newDiscountSkuList);

			//將原頁面新增資料之oid由newDiscountSkuList轉入oldDiscountSkuList
			log.info("print newDiscountSkuList size : "+newDiscountSkuList.size());

			if(newDiscountSkuList.size()>0){
				rtResult =new String[newDiscountSkuList.size()+1];
				for(int i=0;i<newDiscountSkuList.size();i++){
					log.info("rtResult["+i+"] => "+((DiscountSku)newDiscountSkuList.get(i)).getOid()+
							" skuName : "+((DiscountSku)newDiscountSkuList.get(i)).getSkuName());
					rtResult[i+1] = ((DiscountSku)newDiscountSkuList.get((newDiscountSkuList.size()-1)-i)).getOid();
				}
				rtResult[0]=Action.SUCCESS;
			}else{
				rtResult = new String[1];
				rtResult[0]=Action.SUCCESS;
			}


			log.info("ajax modify...");
			//return Action.SUCCESS ;
			return rtResult;
		} catch (Exception e) {
			log.error(e.getMessage(),e) ;
			e.printStackTrace();
			rtResult = new String[1];
			rtResult[0]="更新失敗("+e.getMessage()+")，請洽系統管理人員!";
			return rtResult;
		}
	}

	public String  deleteDiscountSkuByOid(String oidStr){
		if(oidStr==null || "".equalsIgnoreCase(oidStr))
			return Action.SUCCESS;

		String[] oids = oidStr.split(",");
		for(int i=0;i<oids.length;i++){
			log.info("刪除 oid["+i+"]: "+oids[i]);
		}
		this.mtService.deleteDiscountSkuByOid(oids);
		return Action.SUCCESS;
		//this.getMtService().deleteDiscountSkuByOid(oid);
	}

	/**
	 * 忽略字串'|'
	 * @param str
	 * @return
	 */
	public String passByIgnoreStr(String str){
		String ignoreStr = "|";
		if(str!=null&&!"".equalsIgnoreCase(str)){
			if(str.equalsIgnoreCase(ignoreStr)){
				return null;
			}
		}
		return str;
	}

	public boolean isStoreIssuable(String mtCardDiscountOid) throws Exception {
		boolean storeIssuable = false;
		if(StringUtils.trimToNull(mtCardDiscountOid) != null) {
			DiscountVo discountVo = getMtService().getDiscountVoByOid(mtCardDiscountOid);
			if(discountVo != null && discountVo.getIssuable() != null
					&& discountVo.getIssuable().booleanValue() == true) {
				storeIssuable = true;
			}
		}
		return storeIssuable;
	}

	public QueryResult  getDiscountSkuByOid(String formId,String formIndex,String formPageSize,String byAuth,String cid)throws Exception{
		if(byAuth==null ||"".equalsIgnoreCase(byAuth) ||"0".equalsIgnoreCase(byAuth)||byAuth.length()>1){
			return getDiscountSkuList(formId,formIndex,formPageSize,cid);
		}else{
			return getDiscountSkuListByAuth(formId,formIndex,formPageSize,cid);
		}
	}
	
	public QueryResult  getDiscountSkuByOidFilterA(String formId,String formIndex,String formPageSize,String byAuth,String cid)throws Exception{
		if(byAuth==null ||"".equalsIgnoreCase(byAuth) ||"0".equalsIgnoreCase(byAuth)||byAuth.length()>1){
			return getDiscountSkuListFilterA(formId,formIndex,formPageSize,cid);
		}else{
			return getDiscountSkuListByAuthFilterA(formId,formIndex,formPageSize,cid);
		}
	}
	
	public QueryResult  getDiscountSkuByOidFilterNA(String formId,String formIndex,String formPageSize,String byAuth,String cid)throws Exception{
		if(byAuth==null ||"".equalsIgnoreCase(byAuth) ||"0".equalsIgnoreCase(byAuth)||byAuth.length()>1){
			return getDiscountSkuListFilterNA(formId,formIndex,formPageSize,cid);
		}else{
			return getDiscountSkuListByAuthFilterNA(formId,formIndex,formPageSize,cid);
		}
	}

	public QueryResult  getDiscountSkuList(String formId,String formIndex,String formPageSize,String cid)throws Exception{
		String oid = formId;
		int index = Integer.parseInt(BaseWebService.isEmpty(formIndex)?"0":formIndex);
		int pageSize = Integer.parseInt(BaseWebService.isEmpty(formPageSize)?"0":formPageSize) ;

		QueryResult queryResult = this.getMtService().findDiscountSkuByCondition(oid, index, pageSize,cid);
		List <DiscountSkuVo>collection = queryResult.getResult();
		 if(collection!=null && collection.size()>0){
			 for(int i=0;i<collection.size();i++){
				 DiscountSkuVo vo =  collection.get(i);
				 vo.setClassName(this.queryClassMappedName(
						 vo.getDeptId(),
						 vo.getSubDeptId(),
						 vo.getClassId(),
						 vo.getSubClassId())
						 );
				 collection.set(i, vo);
			 }
			 queryResult.setResult(collection);
		 }

		 return queryResult;
	}

	public QueryResult  getDiscountSkuListFilterA(String formId,String formIndex,String formPageSize,String cid)throws Exception{
		String oid = formId;
		int index = Integer.parseInt(BaseWebService.isEmpty(formIndex)?"0":formIndex);
		int pageSize = Integer.parseInt(BaseWebService.isEmpty(formPageSize)?"0":formPageSize) ;

		QueryResult queryResult = this.getMtService().findDiscountSkuByConditionWithSkuFilter(oid, index, pageSize, cid, "A");
		List <DiscountSkuVo>collection = queryResult.getResult();
		 if(collection!=null && collection.size()>0){
			 for(int i=0;i<collection.size();i++){
				 DiscountSkuVo vo =  collection.get(i);
				 vo.setClassName(this.queryClassMappedName(
						 vo.getDeptId(),
						 vo.getSubDeptId(),
						 vo.getClassId(),
						 vo.getSubClassId())
						 );
				 collection.set(i, vo);
			 }
			 queryResult.setResult(collection);
		 }

		 return queryResult;
	}
	
	public QueryResult  getDiscountSkuListFilterNA(String formId,String formIndex,String formPageSize,String cid)throws Exception{
		String oid = formId;
		int index = Integer.parseInt(BaseWebService.isEmpty(formIndex)?"0":formIndex);
		int pageSize = Integer.parseInt(BaseWebService.isEmpty(formPageSize)?"0":formPageSize) ;

		QueryResult queryResult = this.getMtService().findDiscountSkuByConditionWithSkuFilter(oid, index, pageSize,cid, "NA");
		List <DiscountSkuVo>collection = queryResult.getResult();
		 if(collection!=null && collection.size()>0){
			 for(int i=0;i<collection.size();i++){
				 DiscountSkuVo vo =  collection.get(i);
				 vo.setClassName(this.queryClassMappedName(
						 vo.getDeptId(),
						 vo.getSubDeptId(),
						 vo.getClassId(),
						 vo.getSubClassId())
						 );
				 collection.set(i, vo);
			 }
			 queryResult.setResult(collection);
		 }

		 return queryResult;
	}

	public QueryResult  getDiscountSkuListByAuth(String formId,String formIndex,String formPageSize,String cid)throws Exception{
		String oid = formId;
		int index = Integer.parseInt(BaseWebService.isEmpty(formIndex)?"0":formIndex);
		int pageSize = Integer.parseInt(BaseWebService.isEmpty(formPageSize)?"0":formPageSize) ;

		WebContext ctx = WebContextFactory.get();
		HttpSession session = ctx.getSession() ;
		ScSysuser user = (ScSysuser)session.getAttribute("user");
		List <BsChannel>channelList = user.getAuthChannel();
		List<String> onlyChannelValueList = new ArrayList<String>();
		if(channelList!=null && channelList.size()>0){
			for(int i=0;i<channelList.size();i++){
				onlyChannelValueList.add(channelList.get(i).getChannelId());
			}
		}

		QueryResult queryResult = this.getMtService().findDiscountSkuByCondition(oid, index, pageSize,onlyChannelValueList,cid);
		List <DiscountSkuVo>collection = queryResult.getResult();
		 if(collection!=null && collection.size()>0){
			 for(int i=0;i<collection.size();i++){
				 DiscountSkuVo vo =  collection.get(i);
				 vo.setClassName(this.queryClassMappedName(
						 vo.getDeptId(),
						 vo.getSubDeptId(),
						 vo.getClassId(),
						 vo.getSubClassId())
						 );
				 collection.set(i, vo);
			 }
			 queryResult.setResult(collection);
		 }
		 return queryResult;
	}
	
	public QueryResult  getDiscountSkuListByAuthFilterA(String formId,String formIndex,String formPageSize,String cid)throws Exception{
		String oid = formId;
		int index = Integer.parseInt(BaseWebService.isEmpty(formIndex)?"0":formIndex);
		int pageSize = Integer.parseInt(BaseWebService.isEmpty(formPageSize)?"0":formPageSize) ;

		WebContext ctx = WebContextFactory.get();
		HttpSession session = ctx.getSession() ;
		ScSysuser user = (ScSysuser)session.getAttribute("user");
		List <BsChannel>channelList = user.getAuthChannel();
		List<String> onlyChannelValueList = new ArrayList<String>();
		if(channelList!=null && channelList.size()>0){
			for(int i=0;i<channelList.size();i++){
				onlyChannelValueList.add(channelList.get(i).getChannelId());
			}
		}

		QueryResult queryResult = this.getMtService().findDiscountSkuByConditionWithSkuFilter(oid, index, pageSize,onlyChannelValueList,cid, "A");
		List <DiscountSkuVo>collection = queryResult.getResult();
		 if(collection!=null && collection.size()>0){
			 for(int i=0;i<collection.size();i++){
				 DiscountSkuVo vo =  collection.get(i);
				 vo.setClassName(this.queryClassMappedName(
						 vo.getDeptId(),
						 vo.getSubDeptId(),
						 vo.getClassId(),
						 vo.getSubClassId())
						 );
				 collection.set(i, vo);
			 }
			 queryResult.setResult(collection);
		 }
		 return queryResult;
	}
	
	public QueryResult  getDiscountSkuListByAuthFilterNA(String formId,String formIndex,String formPageSize,String cid)throws Exception{
		String oid = formId;
		int index = Integer.parseInt(BaseWebService.isEmpty(formIndex)?"0":formIndex);
		int pageSize = Integer.parseInt(BaseWebService.isEmpty(formPageSize)?"0":formPageSize) ;

		WebContext ctx = WebContextFactory.get();
		HttpSession session = ctx.getSession() ;
		ScSysuser user = (ScSysuser)session.getAttribute("user");
		List <BsChannel>channelList = user.getAuthChannel();
		List<String> onlyChannelValueList = new ArrayList<String>();
		if(channelList!=null && channelList.size()>0){
			for(int i=0;i<channelList.size();i++){
				onlyChannelValueList.add(channelList.get(i).getChannelId());
			}
		}

		QueryResult queryResult = this.getMtService().findDiscountSkuByConditionWithSkuFilter(oid, index, pageSize,onlyChannelValueList,cid,"NA");
		List <DiscountSkuVo>collection = queryResult.getResult();
		 if(collection!=null && collection.size()>0){
			 for(int i=0;i<collection.size();i++){
				 DiscountSkuVo vo =  collection.get(i);
				 vo.setClassName(this.queryClassMappedName(
						 vo.getDeptId(),
						 vo.getSubDeptId(),
						 vo.getClassId(),
						 vo.getSubClassId())
						 );
				 collection.set(i, vo);
			 }
			 queryResult.setResult(collection);
		 }
		 return queryResult;
	}

	public MtGroupVo getMtGroupVo(String groupId) {
		try{
			MtGroupCondition condition = new MtGroupCondition() ;
			condition.setExpireDate(new Date()) ;
			condition.setGroupId(groupId) ;
			condition.setSpeical(true) ;
			return mtService.getGroupVoByCondition(condition) ;
		}catch(Exception e){
			log.error(e.getMessage(),e) ;
			return new MtGroupVo() ;
		}
	}

	/**
	 * @author JL
	 * @param groupId
	 * @return
	 * @throws Exception
	 */
	public MtGroup queryMtGroup(String groupId)throws Exception{
		MtGroup returnVal = null;
		 try {
			 MtGroupVo vo = new MtGroupVo();
			 if (StringUtils.isBlank(groupId)){
				 return null;
			 }
			 vo.setGroupId(groupId);
			 vo.setStatus(1);
			 vo.setGroupType("1");
			 Date sysDate = DateTimeUtils.getDate(DateTimeUtils.getFormatDateStr(DateTimeUtils.getSysDate()));
			 vo.setExpDateFrom(sysDate);
			 vo.setExpDateTo(sysDate);
			 List<MtGroup> dataList = getMtService().queryMtGroup(vo);
			 if (dataList==null || dataList.size()!=1){
				 return null;
			 }
			 returnVal = dataList.get(0);
			 returnVal.setDiscountChannel(null);
			 returnVal.setDiscountSku(null);
		 } catch(Exception e) {
			 log.error(e);
			 e.printStackTrace();
			 return null;
		 }
		 return returnVal;
	}
	
	public Map querySessionKey(String key) {
		return (Map)WebContextFactory.get().getSession().getAttribute(key);
	}
	
}
