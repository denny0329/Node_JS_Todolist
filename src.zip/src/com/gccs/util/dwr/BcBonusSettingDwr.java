package com.gccs.util.dwr;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.directwebremoting.WebContext;
import org.directwebremoting.WebContextFactory;

import com.bnq.sc.model.ScSysuser;
import com.bnq.util.QueryResult;
import com.gccs.bc.model.BcBonusSku;
import com.gccs.bc.setting.service.BcBonusSettingService;
import com.gccs.bs.model.BsChannel;
import com.gccs.bs.service.BsClassService;
import com.gccs.ws.service.BaseWebService;

/**
 * @author Kenny
 */
public class BcBonusSettingDwr {
	
	private static final Logger log = LogManager.getLogger(BcBonusSettingDwr.class) ;
	
	private BcBonusSettingService service;
	
	private BsClassService bsClassService;
	
	private MarketingDwrAction mtDwrAction;

	public MarketingDwrAction getMtDwrAction() {
		return mtDwrAction;
	}

	public void setMtDwrAction(MarketingDwrAction mtDwrAction) {
		this.mtDwrAction = mtDwrAction;
	}

	public BsClassService getBsClassService() {
		return bsClassService;
	}

	public void setBsClassService(BsClassService bsClassService) {
		this.bsClassService = bsClassService;
	}

	public BcBonusSettingService getService() {
		return service;
	}

	public void setService(BcBonusSettingService service) {
		this.service = service;
	}
	
	/**
	 * 檢核商品&&紅利&&店別&&通路在生效中的設定是否存在 
	 * @param oid
	 * @param bsType
	 * @param activeDate
	 * @param inactiveDate
	 * @param channelId
	 * @param sku
	 * @param exBonus
	 * @return
	 */
	public Map<String,String> checkExchangeSku(String oid,String bsType,String activeDate,String inactiveDate
			,Map<String,Map<String,String>> channelId,String[] channelSku,String[] sku,String[] exBonus){
		return service.checkExchangeSku(oid, bsType, activeDate, inactiveDate, channelId,channelSku,sku,exBonus);
	}
	
	/**
	 * 檢核折現設定
	 * @param oid
	 * @param bsType
	 * @param activeDate
	 * @param inactiveDate
	 * @param channelId
	 * @param exBonus
	 * @return
	 */
	public Map<String,String> checkExchangeCash(String oid,String bsType,String activeDate,String inactiveDate
			,Map<String,Map<String,String>> channelId,String[] exBonus){
		return service.checkExchangeCash(oid, bsType, activeDate, inactiveDate, channelId, exBonus);
	}
	
	/**
	 * 檢核channel store exists
	 * @param oid
	 * @param bsType
	 * @param activeDate
	 * @param inactiveDate
	 * @param channelId
	 * @return
	 */
	public Map<String,String> checkExchangeStore(String oid,String bsType,String activeDate,String inactiveDate
			,boolean isExchange,Map<String,Map<String,String>> channelId){
		return service.checkExchangeStore(oid, bsType, activeDate, inactiveDate, isExchange, channelId);
	}
	
	public QueryResult  getBonusSkuByOid(String formId,String formIndex,String formPageSize,String byAuth)throws Exception{
		if(byAuth==null ||"".equalsIgnoreCase(byAuth) ||"0".equalsIgnoreCase(byAuth)||byAuth.length()>1){
			return this.getBonusSkuList(formId, formIndex, formPageSize);
		}else return this.getBonusSkuListByAuth(formId, formIndex, formPageSize);

	}

	public QueryResult  getBonusSkuList(String formId,String formIndex,String formPageSize)throws Exception{
		String oid = formId;
		int index = Integer.parseInt(BaseWebService.isEmpty(formIndex)?"0":formIndex);
		int pageSize = Integer.parseInt(BaseWebService.isEmpty(formPageSize)?"0":formPageSize) ;


		QueryResult queryResult = service.findBonusSkuByCondition(oid, index, pageSize);
		List <BcBonusSku>collection = queryResult.getResult();
		 if(collection!=null && collection.size()>0){
			 log.info("getQueryList total count : "+queryResult.getCount());
			 //StringBuilder sb = new StringBuilder();
			 log.info("collection size : "+collection.size());
			 for(int i=0;i<collection.size();i++){
				BcBonusSku vo =  collection.get(i);
				 vo.setClassName(mtDwrAction.queryClassMappedName(
						 vo.getDept(),
						 vo.getSubDept(),
						 vo.getClass_(),
						 vo.getSubClass())
						 );
				 collection.set(i, vo);
			 }
			 queryResult.setResult(collection);
		 }
		 return queryResult;
	}
	public QueryResult  getBonusSkuListByAuth(String formId,String formIndex,String formPageSize)throws Exception{
		String oid = formId;
		int index = Integer.parseInt(BaseWebService.isEmpty(formIndex)?"0":formIndex);
		int pageSize = Integer.parseInt(BaseWebService.isEmpty(formPageSize)?"0":formPageSize) ;

		WebContext ctx = WebContextFactory.get();
		HttpSession session = ctx.getSession() ;
		ScSysuser user = (ScSysuser)session.getAttribute("user");
		List <BsChannel>channelList = user.getAuthChannel();
		List<String> onlyChannelValueList = new ArrayList<String>();
		if(channelList!=null && channelList.size()>0){
			for(int i=0;i<channelList.size();i++){
				onlyChannelValueList.add(channelList.get(i).getChannelId());
			}
		}

		QueryResult queryResult = service.findBonusSkuByCondition(oid, index, pageSize,onlyChannelValueList);
		List <BcBonusSku>collection = queryResult.getResult();
		 if(collection!=null && collection.size()>0){

			 //StringBuilder sb = new StringBuilder();
			 for(int i=0;i<collection.size();i++){
				BcBonusSku vo =  collection.get(i);
				 vo.setClassName(mtDwrAction.queryClassMappedName(
						 vo.getDept(),
						 vo.getSubDept(),
						 vo.getClass_(),
						 vo.getSubClass())
						 );
				 collection.set(i, vo);
			 }
			 queryResult.setResult(collection);
		 }
		 return queryResult;
	}

}