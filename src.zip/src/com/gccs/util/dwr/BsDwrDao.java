/**
 * @(#)BsDwrDao.java 2014/12/10
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.gccs.util.dwr;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.math.BigDecimal;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.directwebremoting.WebContextFactory;
import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.json.JSONObject;
import org.springframework.orm.hibernate3.HibernateCallback;

import com.bnq.base.dao.hibernate.BaseDAO;
import com.bnq.bs.model.BsCode;
import com.bnq.sc.model.ScSysuser;
import com.bnq.util.AppContext;
import com.bnq.util.StringId;
import com.bnq.util.cache.BsCodeDefinition;
import com.bnq.util.serial.dao.BcBonusSerialNumDao;
import com.gccs.bc.model.BcBonusLog;
import com.gccs.bonus.dao.hibernate.BonusCountSaleDataDAO;
import com.gccs.bonus.model.BcBonusTemporalLog;
import com.gccs.bonus.model.BcBonusTemporalSum;
import com.gccs.bonus.util.BonusUtility;
import com.gccs.bs.dao.hibernate.BsManagerDao;
import com.gccs.bs.model.BsChannel;
import com.gccs.bs.model.BsStaff;
import com.gccs.bs.model.BsStore;
import com.gccs.bs.model.BsStoreId;
import com.gccs.bs.service.BsManagerService;
import com.gccs.marketing.model.GroupCardDiscount;
import com.gccs.member.action.CommissionSettingAction;
import com.gccs.member.card.model.MmCard;
import com.gccs.member.model.Account;
import com.gccs.member.model.Members;
import com.gccs.member.model.MmCommission;
import com.gccs.member.model.MtGroupVipChannel;
import com.gccs.mmbonus.model.MmMembersBonus;
import com.gccs.util.cache.BsCompanyDefinition;
import com.gccs.util.web.SelectItem;
import com.rfep.util.web.ChannelStoreOptionsUtil;

public class BsDwrDao extends BaseDAO {
	private static final long serialVersionUID = -3221287504814876525L;

	private static final Logger log = LogManager.getLogger(BsDwrDao.class);
	public BcBonusSerialNumDao bcBonusSerialNumDao;
	public BsManagerDao bsManagerDao;
	public BonusCountSaleDataDAO bonusCountSaleDataDAO;
	
	public BsManagerDao getBsManagerDao() {
		return bsManagerDao;
	}

	public void setBsManagerDao(BsManagerDao bsManagerDao) {
		this.bsManagerDao = bsManagerDao;
	}

	public BcBonusSerialNumDao getBcBonusSerialNumDao() {
		return bcBonusSerialNumDao;
	}

	public void setBcBonusSerialNumDao(BcBonusSerialNumDao bcBonusSerialNumDao) {
		this.bcBonusSerialNumDao = bcBonusSerialNumDao;
	}
	
    public BonusCountSaleDataDAO getBonusCountSaleDataDAO() {
		return bonusCountSaleDataDAO;
	}

	public void setBonusCountSaleDataDAO(BonusCountSaleDataDAO bonusCountSaleDataDAO) {
		this.bonusCountSaleDataDAO = bonusCountSaleDataDAO;
	}

	@SuppressWarnings("rawtypes")
	public String queryMarketName(String marketId) {
    	String hql = "select promotName from BcBonusSettingMst where promotId=?";
    	List list = this.getHibernateTemplate().find(hql, marketId);
    	return (list.size()>0) ? (String)list.get(0) : null;
    }
    
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public Map queryAccountByAccountId(final String accountId,final String companyId) {
    	final String sql = "select * from mm_account where account_id=? and company_id = ?";
    	return (Map)getHibernateTemplate().execute(
	        new HibernateCallback() {
	        	public Object doInHibernate(Session session) {		        			        			        			        			    		      	        		
	        		Query query = session.createSQLQuery(sql)
	        		.addScalar("OID", Hibernate.STRING)		        		
	        		.addScalar("ACCOUNT_ID", Hibernate.STRING)	
	        		.addScalar("STATUS", Hibernate.INTEGER)	
	        		.addScalar("COMAPANY_NAME1", Hibernate.STRING)	
	        		.setParameter(0, accountId).setParameter(1, companyId);
    			    
    			    List list = query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP).list();			        	    			   	        		
	        		if(list.size()>0) {
	        			Map map = (Map)list.get(0);
	        			map.put("STATUS_TXT", CommissionSettingAction.getStatusTxt((Integer)map.get("STATUS")));
	        			return map;
	        		}
    			    return null;
	        	}		        	
	        }
        );
    }
    
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public Map queryCardiscAndCommission(final String accountOid, final Integer actType) {
    	final String sql = 
    		" select a.oid as CARD_DISC_OID, b.oid as COMMISSION_OID, b.ACTIVITY_ID " +
    		" from mm_card_disc a " +
    		" inner join mm_commission b on a.activity_oid= b.oid  " +
    		" and b.status!=2 and act_type=? " +
    		" and trunc(sysdate) between b.actdate_from and b.actdate_to " +
    		" where account_oid=? " ;
    	return (Map)getHibernateTemplate().execute(
	        new HibernateCallback() {
	        	public Object doInHibernate(Session session) {		        			        			        			        			    		      	        		
	        		Query query = session.createSQLQuery(sql)
	        		.addScalar("CARD_DISC_OID", Hibernate.STRING)		        		
	        		.addScalar("COMMISSION_OID", Hibernate.STRING)	
	        		.addScalar("ACTIVITY_ID", Hibernate.STRING)	
	        		.setParameter(0, actType)
	        		.setParameter(1, accountOid);
	        		    			    
    			    List list = query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP).list();			        	    			   	        			        		
    			    return (list.size()>0) ? (Map)list.get(0) : null;
	        	}		        	
	        }
        );
    }
    
    @SuppressWarnings("rawtypes")
	public MmCommission queryCommissionByActivityOid(String accountOid, Integer actType) {
    	DetachedCriteria criteria = DetachedCriteria.forClass(MmCommission.class); 
		criteria.add(Restrictions.sqlRestriction(
				"oid in(select activity_oid from mm_card_disc where account_oid=?)", 
				accountOid, Hibernate.STRING));
		criteria.add(Restrictions.ne("status", 2));
		criteria.add(Restrictions.eq("actType", actType));		
		
    	List list = this.getHibernateTemplate().findByCriteria(criteria);
		
		return (list.size()>0) ? (MmCommission)list.get(0) : null;
    }       
    
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public Map checkAccountId(String commissionOid, String accountId, Integer actType) {    	
    	Map result = new HashMap();    	
    	Map account = queryAccountByAccountId(accountId,BsCompanyDefinition.getCompanyId());
    	
    	if(account == null) {
    		result.put("isAllow", false);
    		result.put("msg", "查無帳號("+accountId+")！");
    		return result;
    	}    	
    	
    	if(!"核發".equals(account.get("STATUS_TXT"))) {
    		result.put("isAllow", false);
    		result.put("msg", "帳號("+accountId+")狀態為"+account.get("STATUS_TXT")+"！");
    		return result;
    	}
    	
    	Map map = queryCardiscAndCommission((String)account.get("OID"), actType);    	
    	if(map != null) {  
    		String COMMISSION_OID = (String)map.get("COMMISSION_OID");
    		String CARD_DISC_OID = (String)map.get("CARD_DISC_OID");
    		String ACTIVITY_ID = (String)map.get("ACTIVITY_ID");
    		
    		if(COMMISSION_OID.equals(commissionOid)) {
    			result.put("cardDiscOid", CARD_DISC_OID);    			    			
    		} else {
    			result.put("isAllow", false);
        		result.put("msg", "帳號("+accountId+")，已設定於"+ACTIVITY_ID+"！");
        		return result;
    		}    		    		
    	}
    	
    	result.put("isAllow", true);      	
    	result.put("accountOid", account.get("OID"));
    	result.put("accountId", account.get("ACCOUNT_ID"));
    	result.put("status", account.get("STATUS"));
    	result.put("statusTxt", account.get("STATUS_TXT"));
    	result.put("comapanyName", account.get("COMAPANY_NAME1"));
    	
    	return result;
    }
    
    public int queryMtCardDiscountCount(int cardType)
    {    	
    	DetachedCriteria criteria = DetachedCriteria.forClass(GroupCardDiscount.class);
		criteria.add(Restrictions.eq("status",1)) ;	
		criteria.add(Restrictions.eq("cardType",cardType));			
		criteria.add(Restrictions.eq("employeeDay",Boolean.FALSE));		
		criteria.addOrder(Order.desc("expDateTo"));  
		
		return this.getHibernateTemplate().findByCriteria(criteria).size();		    	  	    	    	
    }

    /**
     * 取得登入使用者資料
     * @return
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public String getUserLoginInfo(){
    	Map userInfo = new HashMap();
    	userInfo.put("userId", this.getUser().getUserId());
    	userInfo.put("userName", this.getUser().getUserName());
    	userInfo.put("userRead", this.getUser().getUserRead());
    	userInfo.put("loginChannelId", this.getUser().getLoginChannelId());
    	userInfo.put("loginStoreId", this.getUser().getLoginStoreId());
    	userInfo.put("loginStoreChannelId", this.getUser().getLoginStoreChannel());
    	// 2013/01/21 - 取得所屬通路代碼.通路店別
		Map bsStoreId = new LinkedHashMap();
    	List <BsChannel>authChannel = this.getUser().getAuthChannel();
    	if(CollectionUtils.isNotEmpty(authChannel)){
    		for(BsChannel vo : authChannel) {
    			List<BsStore>stores = vo.getBsStores();
    			if(CollectionUtils.isNotEmpty(stores)){
    				for(BsStore vos : stores) {
    					BsStoreId  bsStoreIdObj = vos.getId();
    					bsStoreId.put(bsStoreIdObj.getChannelId(),bsStoreIdObj.getStoreId());
    				}
    			}
    		}
    	}
    	userInfo.put("bsStoreId",bsStoreId);
    	
    	return new JSONObject(userInfo).toString();
    }
    
    public static List<StringId> getStoreOption(
    		boolean isUser, boolean isHqStaff, String channelId, Integer storeType, boolean exculdeTxnType17){
    	log.debug(" isUser : " + isUser +" isHqStaff : "+isHqStaff+" channelId : "+ channelId +" storeType :" + storeType + " exculdeTxnType17 : " + exculdeTxnType17);
    	ScSysuser user = null;
    	if( isUser )
    		user = (ScSysuser)WebContextFactory.get().getSession().getAttribute("user");
    	if( storeType != null ){
    		if( storeType.intValue() > 4 || storeType.intValue() < 0 ) storeType = 1;
    		if( storeType.intValue() == 0 ) storeType = null;
    	}
    	return ChannelStoreOptionsUtil.getStore(user, isHqStaff, channelId, storeType, exculdeTxnType17);
    }
    
    /**
     * 依據所選通路連動產生店別選單內容，且比對登入主機IP是否與DB記錄相同，一致才顯示店別資料。
     * @param channelId 通路代碼
     * @param urlIdCode 登入公司
     * @return 所選通路的店別下拉選單；id: storeId, name: storeId + "-" + storeName1
     */
    public static List<StringId> getBsStoreByChannelIdForAp(String channelId, String urlIdCode){
    	return SelectItem.getStoreOptinsForAp(channelId, urlIdCode);
    }
    
    public static List<StringId> getBsStoreByChannelIdIncludeAll(String channelOid, boolean freg) {
    	StringId all = new StringId("ALL", "ALL-查詢所有店");
    	List<StringId> result = new ArrayList<StringId>();
    	result.addAll(SelectItem.getBsStoreByChannelId(channelOid, freg));
    	if( result.size() > 0 )
    		result.add(1, all);
    		
		return result;
	}
    
    public static List<StringId> getBsStoreByChannelId(String channelOid, boolean freg) {		
		return SelectItem.getBsStoreByChannelId(channelOid, freg);
	}
    
    public static List<StringId> getBsStoreByChannelIdInclude99(String channelOid, boolean freg) {		
		return SelectItem.getBsStoreByChannelIdIdInclude99(channelOid, freg);
	}

	/**
	 * 以登入使用者權限取得預設店別代碼
	 * @param channelId
	 * @return
	 */
	public String getStoreOptionsDefForUser(String channelId) {
		return SelectItem.getStoreOptionDefForUser(channelId, this.getUser().getUserId(), this.getUser().getCompanyId());
	}
    
    /**
     * 以登入使用者權限取得通路店別清單
     * @param channelId
	 * @param flag		: Default [請選擇]
     * @return
     */
    public List<StringId> getStoreOptinsForUser(String channelId, boolean freg) {		
		String userId = this.getUser().getUserId();
    	return SelectItem.getStoreOptinsForUser(userId, channelId, freg);
	}
    
    /**
     * 依通路代碼與通路店別，取得營業課OID
     * @param channelId
     * @param storeId
     * @return
     */
    public List<StringId> getDeptOptins(String channelId, String storeId) {
    	return SelectItem.getDeptOptins(channelId, storeId);
	}
    
    /**
     * 依通路代碼與通路店別，取得營業區OID
     * @param channelId
     * @param storeId
     * @return
     */
    public List<StringId> getAreaOptins(String channelId, String storeId, String parentOid) {
    	return SelectItem.getAreaOptins(channelId, storeId, parentOid);
	}
    
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public Map queryAccountForOptions(String hqId, boolean freg) {		
		DetachedCriteria criteria = DetachedCriteria.forClass(Account.class);        	
		criteria.add(Restrictions.eq("hqId", hqId));
		criteria.add(Restrictions.not(Restrictions.in("status", new Integer[]{0,1,2})));
		criteria.addOrder(Order.asc("accountId"));  	
		List<Account> list = this.getHibernateTemplate().findByCriteria(criteria);  		
    	
		Map map = new LinkedHashMap();
		if(list.size() <= 0) {
			map.put("", "無資料");
		} else {
			if(freg) map.put("", "請選擇");
			for(Account vo : list) {
				map.put(vo.getAccountId(), vo.getAccountId()+"-"+vo.getCompanyName1());
			}
		}
		
		return map;
	}
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
	public boolean isExistBsStaffById(final String channelId, final String companyId, 
			final String storeId, final String staffId) {
		int count =  (Integer) getHibernateTemplate().execute(
				new HibernateCallback() {
					public Object doInHibernate(Session session) {
		        		StringBuffer sb = new StringBuffer("select count(*) from Bs_Staff BsStaff");
		        		sb.append(" inner join Bs_Channel BsChannel on BsChannel.channel_Id = BsStaff.channel_Id");
		        		sb.append(" Where BsStaff.channel_Id = :channelId");
		        		sb.append(" AND BsStaff.staff_Id = :staffId");
		        		sb.append(" AND BsStaff.store_Id = :storeId");
		        		sb.append(" AND trunc(sysdate) between BsStaff.exp_from and BsStaff.exp_to");
		        		sb.append(" AND BsChannel.company_Id = :companyId");

		        		Query query = session.createSQLQuery(sb.toString());
		        		query.setParameter("channelId", channelId);
		        		query.setParameter("staffId", staffId);
		        		query.setParameter("storeId", storeId);
		        		query.setParameter("companyId", companyId);
		        		return ((BigDecimal) query.uniqueResult()).intValue();
		        	}		        	
		        }
		    );
		
		return (count>0) ? true : false;

	}
        
    @SuppressWarnings({ "unchecked", "rawtypes" })
	public boolean isExistBsCardByCardType(final String oid, final String cardType) {
		long count = (Long)getHibernateTemplate().execute(
		        new HibernateCallback() {
		        	public Object doInHibernate(Session session) {		        				        		
		        		Query query = session.createQuery(
		        				"select count(*) from BsCard where cardType=:cardType " + 
		        				(isEmpty(oid) ? "" : "and oid!=:oid and status='1'"));
		        		if(!isEmpty(oid)) query.setParameter("oid", oid);
		        		query.setParameter("cardType", cardType);
		        		return query.uniqueResult();
		        	}		        	
		        }
		    );
		
		return (count>0) ? true : false;
	}
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
	public boolean isExistBsCardByCardId(final String oid, final String cardId) {
		long count = (Long)getHibernateTemplate().execute(
		        new HibernateCallback() {
		        	public Object doInHibernate(Session session) {		        				        		
		        		Query query = session.createQuery(
		        				"select count(*) from BsCard where cardId = :cardId " + 
		        				(isEmpty(oid) ? "" : "and oid != :oid"));
		        		if(!isEmpty(oid)) query.setParameter("oid", oid);
		        		query.setParameter("cardId", cardId);
		        		return query.uniqueResult();
		        	}		        	
		        }
		    );
		
		return (count>0) ? true : false;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public boolean isExistStoreByCardNum(final String cardNum) throws Exception {						
		long count = 0;
		try {
			count = (Long)getHibernateTemplate().execute(
			        new HibernateCallback() {
			        	public Object doInHibernate(Session session) {		        				        		
			        		Query query = session.createQuery(
			        				"select count(*) from BsStore where cardNum=? ");			        							        		
			        		query.setParameter(0, cardNum);			        					        				        					        	
			        		return query.uniqueResult();
			        	}		        	
			        }
			    );
		}
		catch(Exception e) 
		{
			 log.error(e.getMessage(), e);
			 throw e;
		}
		
		return (count>0) ? true : false;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public boolean isExistStoreByStoreId(final String oid, final String storeId) {
		long count = (Long)getHibernateTemplate().execute(
		        new HibernateCallback() {
		        	public Object doInHibernate(Session session) {		        				        		
		        		Query query = session.createQuery(
		        				"select count(*) from BsStore where storeId = :storeId " + 
		        				(isEmpty(oid) ? "" : "and oid != :oid"));
		        		if(!isEmpty(oid)) query.setParameter("oid", oid);
		        		query.setParameter("storeId", storeId);
		        		return query.uniqueResult();
		        	}		        	
		        }
		    );
		
		return (count>0) ? true : false;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public boolean isExistChannelByChannelPos(final String oid, final String channelPos) {
		long count = (Long)getHibernateTemplate().execute(
		        new HibernateCallback() {
		        	public Object doInHibernate(Session session) {		        				        		
		        		Query query = session.createQuery(
		        				"select count(*) from BsChannel where channelPos = :channelPos " + 
		        				(isEmpty(oid) ? "" : "and oid != :oid"));
		        		if(!isEmpty(oid)) query.setParameter("oid", oid);
		        		query.setParameter("channelPos", channelPos);
		        		return query.uniqueResult();
		        	}		        	
		        }
		    );
		
		return (count>0) ? true : false;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public boolean isExistChannelByChannelId(final String oid, final String channelId) throws Exception {						
		long count = (Long)getHibernateTemplate().execute(
		        new HibernateCallback() {
		        	public Object doInHibernate(Session session) {		        				        		
		        		Query query = session.createQuery(
		        				"select count(*) from BsChannel where channelId = :channelId " + 
		        				(isEmpty(oid) ? "" : "and oid != :oid"));
		        		if(!isEmpty(oid)) query.setParameter("oid", oid);
		        		query.setParameter("channelId", channelId);
		        		return query.uniqueResult();
		        	}		        	
		        }
		    );	
		
		return (count>0) ? true : false;
	}	
	
    @SuppressWarnings({ "unchecked", "rawtypes" })
	public String addBons(final Map map) throws Exception {						
    	try {			
			final ScSysuser user = this.getUser();			
			
			this.getHibernateTemplate().execute( new HibernateCallback() {
	        	public Object doInHibernate(Session session) 
	        	{	        			  
	        		String companyId = "";
	    			try{
	    				companyId = BsCompanyDefinition.getCompanyId();
	    			}catch(Exception e){
	    				companyId = "1010";
	    			}
	        		String memberOid = (String)map.get("memberOid");
	        		String channelId = (String)map.get("channelId");
	        		String storeId = (String)map.get("storeId");	        		
	    			int bonus = Integer.valueOf((String)map.get("bonus"));
	    			String reason = (String)map.get("reason");
	    			String guiNos = (String)map.get("guiNos");
	    			String bonusType = (String)map.get("bonusType");
	    			String marketId = (String)map.get("marketId");
	    			String confirmExtendDate = (String)map.get("choose");
	    			
	    			// user沒有填活動代號，就使用預設值
	    			if(!StringUtils.isNotBlank(marketId)){
	    				marketId = BcBonusLog.MARKET_ID;
	    			}
	    			
	    			List<BsCode> codeList = BsCodeDefinition.findAllByParentCodeClassAndParentCodeNo("BC", bonusType);
	    				    			
	    			Transaction tx = session.beginTransaction();
	    			
	    			//update member.bonusTotal
	    			Members member = (Members)session.load(Members.class, memberOid);	
	    			MmMembersBonus mmMembersBonus = find(member);
	    			
	    			int bonusTotal = (mmMembersBonus.getBonusTotal()==null) ? 0 : mmMembersBonus.getBonusTotal();
	    			// bonusTotal照公式應該等於thisYearTot+LastYeartot，但是有可能會有不相等情況，所以先分開算，bonusTotal=bonusTotal+紅利加點-紅利扣點
	    			mmMembersBonus.setBonusTotalYday(mmMembersBonus.getBonusTotal());
	    			mmMembersBonus.setThisYearTotYday(mmMembersBonus.getThisYearTot());
	    			mmMembersBonus.setLastYearTotYday(mmMembersBonus.getLastYearTot());
	    			mmMembersBonus.setBonusTotal(bonusTotal+bonus);	 
	    			mmMembersBonus.setModifyTime(new Date());
	    			if ("Y".equals(confirmExtendDate)) {
	    				log.info("勾選延長到期日");
	    				Date yearAfterLastDateOfMonth = getYearLaterAndEndOfMonth();
						mmMembersBonus.setBonusExpiryDate(yearAfterLastDateOfMonth);
	    			}
	    			
	    			String vipNo = (String)map.get("vipNo");
	    			if(StringUtils.isEmpty(vipNo)) {
	    				Set<MmCard> set1 = member.getMmCard();
	    				Set<MmCard> set = new HashSet<MmCard>();
	    				for (MmCard mmCard : set1) {
	    					if(companyId.equals(mmCard.getCompanyId()))
	    						set.add(mmCard);
	    				}
	    				if(set!=null && set.size()>0) {
	    					vipNo = set.iterator().next().getVipNo();	
	    				}
	    			}
	    			
	    			BcBonusLog bonusLog = new BcBonusLog();
	    			bonusLog.setChannelId(channelId);
	    			bonusLog.setStoreId(storeId);
	    			bonusLog.setMemberOid(memberOid);	
	    			bonusLog.setMemberId(member.getMemberId());
	    			bonusLog.setTransDate(new Date());
	    			bonusLog.setReason(reason);	    			
	    			bonusLog.setCreator(user.getUserId());
	    			bonusLog.setCreatorName(user.getUserName());
	    			bonusLog.setCreateTime(new Date());	
	    			bonusLog.setModifier(user.getUserId());
	    			bonusLog.setModifierName(user.getUserName());
	    			bonusLog.setModifyTime(new Date());	
	    			bonusLog.setVipNo(vipNo);	    				    		
	    			bonusLog.setBonusTotal(bonusTotal+bonus);
	    			bonusLog.setCompanyId(BsCompanyDefinition.getCompanyId());
	    			
	    			Integer bonusTypeInt = null;
	    			if(bonus >= 0) {
	    				bonusLog.setBonusAdd(bonus);
	    				bonusLog.setBonusMins(0);
	    				for(BsCode code:codeList){
	    					if("+".equals(code.getId().getCodeNo())){
	    						try{
	    							bonusTypeInt = Integer.parseInt(code.getCodeExplain());
	    						}catch (Exception e) {
	    							log.error("紅利種類代碼["+code.getCodeExplain()+"]無法轉換成數字!", e);
								}
	    					}
	    				}
	    			} else {
	    				bonusLog.setBonusAdd(0);
	    				bonusLog.setBonusMins(bonus*-1);
	    				for(BsCode code:codeList){
	    					if("-".equals(code.getId().getCodeNo())){
	    						try{
	    							bonusTypeInt = Integer.parseInt(code.getCodeExplain());
	    						}catch (Exception e) {
	    							log.error("紅利種類代碼["+code.getCodeExplain()+"]無法轉換成數字!", e);
								}
	    					}
	    				}
	    			}
	    			if(reason.length() > 180) {
	    				reason = reason.substring(0, 180);
	    			}
	    			bonusLog.setGuiNo(guiNos);
	    			bonusLog.setBonusType(bonusTypeInt);
	    			bonusLog.setSerialNum(bcBonusSerialNumDao.getSerialNum());
	    			bonusLog.setMarketId(marketId);
	    			bonusLog.setReason(reason);	
	    			
	    			session.save(bonusLog);
	    			
	        		Map<String, Integer> map = BonusUtility.CalculateBonus(bonusLog.getBonusAdd(), bonusLog.getBonusMins(), mmMembersBonus.getThisYearTot(), mmMembersBonus.getLastYearTot());
	        		mmMembersBonus.setThisYearTot(map.get("thisYearTot"));
	        		mmMembersBonus.setLastYearTot(map.get("lastYearTot"));
	        		// bonusTotal照公式應該等於thisYearTot+LastYeartot，但是有可能會有不相等情況，所以先分開算，bonusTotal=bonusTotal+紅利加點-紅利扣點
	        		
	    			session.saveOrUpdate(mmMembersBonus);
	    			
	    			if("C".equals(bonusType) || "D".equals(bonusType)){
	    				BcBonusTemporalSum bonusSum = getBsManagerDao().loadBonusSumByMemberId(bonusLog.getMemberId());
	    				if(bonusSum != null){
							bonusSum.setBonusTotal(bonusSum.getBonusTotal() + bonusLog.getBonusAdd() - bonusLog.getBonusMins());
							bonusSum.setModifiedTime(new Date());
							session.update(bonusSum);
						}
	    				
	    				BcBonusTemporalLog log = new BcBonusTemporalLog(bonusLog);
		        		log.setPersonId(member.getPersonId());
		        		log.setModifiedTime(new Date());
		        		session.save(log);
	    			}
	    			
	        		tx.commit();		        		
	        		
	        		return null;
	        	}
		    });
									
		} 
		catch(Exception e) 
		{
			log.error(e.getMessage(), e);
		    throw e;
		}
				
		return "存檔成功！";
	}

	private Date getYearLaterAndEndOfMonth() {
		Date yearLater = DateUtils.addDays(new Date(), 365);
		
		Calendar c = Calendar.getInstance();
		c.setTime(yearLater);
		c.set(Calendar.DATE, c.getActualMaximum(Calendar.DAY_OF_MONTH));
		return com.bnq.util.DateUtils.trunc(c.getTime());
	}
    
    MmMembersBonus find(Members member){
		MmMembersBonus mmMembersBonus = null;
		if(member!=null)
			 mmMembersBonus = bonusCountSaleDataDAO.findMmMembersBonus(member.getMemberId(),BsCompanyDefinition.getCompanyId());
		
		if(mmMembersBonus==null)
			mmMembersBonus = new MmMembersBonus(BsCompanyDefinition.getCompanyId(), "", member.getMemberId());
		return mmMembersBonus;
	}
    
    @SuppressWarnings("rawtypes")
	private BcBonusLog loadBsBonusLogForTransDate(String memberOid)  throws Exception
	{
    	BcBonusLog vo = null;
    	
    	try 
    	{    		
        	DetachedCriteria criteria = DetachedCriteria.forClass(BcBonusLog.class);        	
    		criteria.add(Restrictions.eq("memberOid", memberOid));
    		criteria.addOrder(Order.desc("transDate"));  	
    		    		
        	List list = this.getHibernateTemplate().findByCriteria(criteria);        	
        	if(list.size() > 0) {
        		vo = (BcBonusLog)list.get(0);        		
        	}
    	}	
		catch(Exception e) 
		{
			log.error(e.getMessage(), e);
		    throw e;
		}  
    	
    	return vo;		    	   	    	
	}
    
    @SuppressWarnings("rawtypes")
	private MmMembersBonus loadMmMembersBonus(String companyId, Long memberId) throws Exception {
    		MmMembersBonus vo = null;
		DetachedCriteria criteria = DetachedCriteria.forClass(MmMembersBonus.class);
		criteria.add(Restrictions.eq("memberId", memberId))
		.add(Restrictions.eq("companyId", companyId));
		
		List list = this.getHibernateTemplate().findByCriteria(criteria);
		if (list != null && list.size() > 0)
			vo = (MmMembersBonus) list.get(0);
		return vo;
	}
    
    private String formateDate(Date date) {
    	if(date == null) return "";
    	return new SimpleDateFormat("yyyy/MM/dd").format(date);
    }
    
    private String formateNum(Integer num) {
    	if(num == null) return "0";
    	return new DecimalFormat("#,##0").format(num);
    }
    
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public Map queryBonusInfo(String memberId, String personId) throws Exception
	{
    	Map result = null;
    	try {	    		
    		Members vo = loadMember(memberId, personId);
    		if(vo != null) 
    		{    	
    			Integer bonusTotal = 0;
    			MmMembersBonus mmMembersBonus = loadMmMembersBonus(BsCompanyDefinition.getCompanyId(), vo.getMemberId());
    			if (mmMembersBonus != null){
    				bonusTotal=(mmMembersBonus.getBonusTotal()==null?new Integer(0):
    					new Integer(mmMembersBonus.getBonusTotal().toString()));
    			}
    				
	    			BcBonusLog bonus = loadBsBonusLogForTransDate(vo.getOid()) ;
	    			result = new HashMap();
	    			
	    			result.put("error", "");
	    			if(vo.getStatus()==0) result.put("error", "此會員已停用！");
	    			if(vo.getStatus()==9) result.put("error", "此會員已刪除！");
	    			//如狀態異常，需判斷異常代號(NOTE_FIRST)，是否可在服務台兌換    			
	    			if(vo.getStatus()==2) {
	    				BsCode code = BsCodeDefinition.findAllMemberByCodeClassAndCodeNo(vo.getResId1(), vo.getResId1());
	    				if(code==null || "N".equals(code.getNoteFirst())) {
	    					result.put("error", "此會員狀態為異常，不可兌換商品！");	
	    				}
	    			}
	    				
	    			result.put("oid", vo.getOid());
	    			result.put("name", vo.getName());  
	    			result.put("birthday", "民國 "+vo.getBirthdayYear()+"年 "+(vo.getBirthdayMm()==null?"":vo.getBirthdayMm())+"月 ");  
	    			result.put("bonusTotal", formateNum(bonusTotal)+"點");
	    			result.put("transDate", (bonus==null) ? "" : formateDate(bonus.getTransDate())); 
	    			result.put("bonus", bonusTotal);
	    			//bonusTempSum=null;
    		}
    	} 
    	catch(Exception e) 
		{
    		log.error(e.getMessage(), e);
		    throw e;
		}
    			
		return result;
	}
    
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public Map queryMemberInfo(String memberId, String personId) throws Exception
	{
    	Map result = null;
    	try {	    		
    		Members vo = loadMember(memberId, personId);    		
    		if(vo != null) {
    			result = new HashMap();
    			
    			result.put("error", "");
    			if(vo.getStatus()==0) result.put("error", "此會員已停用！");
    			if(vo.getStatus()==9) result.put("error", "此會員已刪除！");
    			
    			result.put("oid", vo.getOid());
    			result.put("name", vo.getName());
    			result.put("sex", (new Integer(0).equals(vo.getSex()))? "小姐" : " 先生 ");
    			result.put("cantactTel", isEmpty(vo.getCantactExt()) ?  vo.getCantactTel() : vo.getCantactTel()+"#"+vo.getCantactExt());
    			result.put("faxNo", vo.getFaxNo());
    			result.put("cellPhone", vo.getCellPhone());			
    			result.put("cantactAddr", getCantactAddr(vo));
    		}
    	} 
    	catch(Exception e) 
		{
    		log.error(e.getMessage(), e);
		    throw e;
		}
    			
		return result;
	}       
    
    @SuppressWarnings("unchecked")
	private Members loadMember(String vipNo, String personId)  throws Exception
	{
    	Members vo = null;
    	
    	if (isEmpty(personId) && isEmpty(vipNo))
    		return vo;
    	
    	try 
    	{    		
        	DetachedCriteria criteria = DetachedCriteria.forClass(Members.class);
        	if(!isEmpty(personId)) {
    			criteria.add(Restrictions.eq("personId", personId.toUpperCase()));
    		}    	
    		if(!isEmpty(vipNo)) {
    			criteria.createCriteria("mmCard")
    			.add(Restrictions.eq("vipNo", vipNo.toUpperCase()));
    		}  
    		
        	List<Members> list = this.getHibernateTemplate().findByCriteria(criteria);        	
        	if(list.size() > 0) {
        		vo = (Members)list.get(0);        		
        	}
    	}	
		catch(Exception e) 
		{
			log.error(e.getMessage(), e);
		    throw e;
		}  
    	
    	return vo;		    	   	    	
	}
    
    private String getCantactAddr(Members vo) throws Exception
	{
		StringBuilder result = new StringBuilder();
		result.append(getBsCodeExplain("CY", vo.getCantactAddr1()))
		.append(" 郵遞區號  ").append(chcekNull(vo.getCantactAddr2())).append(" ")
		.append(getBsCodeExplain("AD", vo.getCantactAddr3()))
		.append(getBsCodeExplain("AD", vo.getCantactAddr4()))
		.append(chcekNull(vo.getCantactAddr5()));
		
		return result.toString();
	}    
    
    private String chcekNull(String str) {
    	if(str==null) return "";
    	return str;
    }
	    
	@SuppressWarnings("rawtypes")
	private String getBsCodeExplain(String codeClass, String codeNo) {
		String hql = "select codeExplain from BsCode where id.codeClass=? and id.codeNo=?";
		List list = getHibernateTemplate().find(hql, new Object[]{codeClass,codeNo});			
		return (list.size()>0) ? (String)list.get(0) : "";
	}
    
	private ScSysuser getUser() {
		return (ScSysuser)WebContextFactory.get().getSession().getAttribute("user");				
	}
	
	private boolean isEmpty(String str) {
		if(str==null || str.trim().length()<=0) {
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * 取  BS_STAFF USER, 但以設 POS ID 為優先, 同 channel/store 生效期間, 可能多筆(不同職務)
	 * @param channelId
	 * @param storeId
	 * @param userId
	 * @return
	 */
	public BsStaff findBsStaffForPosUser(String channelId, String storeId, String userId){
		BsManagerService bsManagerService = (BsManagerService) AppContext.getBean("bsManagerService");
		return bsManagerService.findBsStaffForPosUser(channelId, storeId, userId);
	}
	
	/**
	 * 檢查接單店別和安裝店別,使用者是否至少有其中一家的權限
	 * 
	 * @param channelId
	 *            通路別
	 * @param storeInId
	 *            接單店別
	 * @param storeOutId
	 *            安裝店別
	 * @return
	 */
	public boolean checkStoreInAndStoreOutForUser(final String channelId,
			final String storeInId, final String storeOutId) {
		boolean result = false;
		if (StringUtils.isBlank(channelId) && StringUtils.isBlank(storeInId)
				&& StringUtils.isBlank(storeOutId)) {
		} else {
			String userId = this.getUser().getUserId();
			List<StringId> storeList = SelectItem.getStoreOptinsForUser(userId,
					channelId, false);
			for (StringId stringId : storeList) {

				// 若接單店或安裝店其中一個符合權限
				if (storeInId.equals(stringId.getId())
						|| storeOutId.equals(stringId.getId())) {
					result = true;
					break;
				}
			}
		}

		return result;
	}
	
	/**
	 * 依商務代號取名稱
	 * @param accountId
	 * @return
	 */
	public String queryAccountName(String accountId) {
    	String sql = "SELECT COMAPANY_NAME2 from MM_ACCOUNT where ACCOUNT_ID =:accountId";
    	String result = "";
    	Session session = null;
    	
    	try {
    		session = super.getSession();
    		
    		Query query = session.createSQLQuery(sql)
	    		.addScalar("COMAPANY_NAME2", Hibernate.STRING)		        		
	    		.setParameter("accountId", accountId);
    		
    		result = (String)query.uniqueResult();
    	} catch(Exception e){
    		log.error(e.getMessage(), e);
    	} finally {
    		if (session != null) this.releaseSession(session);
    	}
    	
    	return result;
    }
	
	/**
	 * 依採購單位取名稱
	 * @param refUnit
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public String queryRefUnitName(String refUnit) {
    	String sql = new StringBuffer().append("SELECT mm.NAME NAME") 
    				.append(" from RFEP.TRAN_MST mst, RFEPDBA.MM_MEMBERS mm, RFEPDBA.MM_CARD card")
    				.append(" where mst.CUST_NOS = card.VIP_NO")
    				.append(" and card.MEMBER_ID = mm.MEMBER_ID")
    				.append(" and mst.CUST_NOS =:refUnit").toString();
    	Session session = null;
    	List<String> list = new ArrayList<String>();
    	
    	try {
    		session = this.getSession();
    		
    		Query query = super.getSession().createSQLQuery(sql)
    			.addScalar("NAME", Hibernate.STRING)		        		
    			.setParameter("refUnit", refUnit);
    		
    		list = query.list();
    	} catch(Exception e){
    		log.error(e.getMessage(), e);
    	} finally {
    		if (session != null) this.releaseSession(session);
    	}
    	
    	return (list.size()>0) ? (String)list.get(0) : null;
    }
	
	@SuppressWarnings("rawtypes")
	public List<StringId> findChannel(
    		final String channelGroupId){
    	log.debug(" channelGroupId : " + channelGroupId);
    	
    	List<StringId> result = new ArrayList<StringId>();
    	result.add(new StringId("", "請選擇"));
    	
		List list = getHibernateTemplate().executeFind(
                new HibernateCallback() {
                    public Object doInHibernate(org.hibernate.Session session) { 
                    	Criteria criteria = session.createCriteria(MtGroupVipChannel.class);
            			criteria.add(Restrictions.eq("channelGroupId", channelGroupId));
            			return criteria.list(); 
                    }
                }); 
		
		if(list != null && list.size() > 0) { 
			for(int i = 0; i < list.size(); i++) {
				MtGroupVipChannel mtGroupChannel = (MtGroupVipChannel)list.get(i);
				result.add(new StringId(mtGroupChannel.getChannelId(), mtGroupChannel.getChannelId()));
			} 
		}
			
		return result; 
    }
	
	@SuppressWarnings("rawtypes")
	public List<StringId> findChannelStore(
    		final String channelId){
    	log.debug(" channelId : " + channelId);
    	
    	List<StringId> result = new ArrayList<StringId>();
    	result.add(new StringId("", "請選擇"));
    	
		List list = getHibernateTemplate().executeFind(
                new HibernateCallback() {
                    public Object doInHibernate(org.hibernate.Session session) { 
                    	Criteria criteria = session.createCriteria(BsStore.class);
            			criteria.add(Restrictions.eq("id.channelId", channelId));
            			return criteria.list(); 
                    }
                }); 
		
		if(list != null && list.size() > 0) { 
			for(int i = 0; i < list.size(); i++) {
				BsStore bsStore = (BsStore)list.get(i);
				result.add(new StringId(bsStore.getId().getStoreId(), bsStore.getStoreName1()));
			} 
		}
			
		return result; 
    }
	
	@SuppressWarnings("rawtypes")
	public List<StringId> findChannelTRPlus(final String channelGroupId){
	    	log.debug(" channelGroupId : " + channelGroupId);
	    	
	    	String sql = 
					" select distinct channel.*  " +
					"   from MT_GROUP_VIP_CHANNEL channel, MT_GROUP_VIP_EC_STORE store  " +
					"  where channel.OID=store.mst_oid  " +
					" and channel.channel_group_id=:channelGroupId";
	    	Session session = null;
	    	
	    	List<StringId> result = new ArrayList<StringId>();
	    	result.add(new StringId("", "請選擇"));
	    	List<Map<String,Object>> list = null;
	    	try {
		    	session = this.getSession();
			Query query = session.createSQLQuery(sql);  
			list = query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP).setString("channelGroupId", channelGroupId).list();
	    	} catch(Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			this.releaseSession(session);
		} 
		
		if(list != null && list.size() > 0) { 
			for(int i = 0; i < list.size(); i++) {
				String channelId = (String) list.get(i).get("CHANNEL_ID");
				result.add(new StringId(channelId, channelId));
			} 
		}
			
		return result; 
    }
	
	@SuppressWarnings("rawtypes")
	public List<StringId> findChannelStoreTRPlus(final String channelId){
		log.debug(" channelId : " + channelId);
    	
	    	String sql = 
					" select bsStore.*  " +
					"   from MT_GROUP_VIP_CHANNEL channel, MT_GROUP_VIP_EC_STORE store,BS_STORE bsStore  " +
					"  where channel.OID=store.mst_oid  "+
	    				"  and channel.CHANNEL_ID=:channelId  "+
	    				"  and bsStore.SITE_ID=store.store_id  ";
	    	Session session = null;
	    	
	    	List<StringId> result = new ArrayList<StringId>();
	    	result.add(new StringId("", "請選擇"));
	    	List<Map<String,Object>> list = null;
	    	try {
		    	session = this.getSession();
			Query query = session.createSQLQuery(sql);  
			list = query.setResultTransformer(Criteria.ALIAS_TO_ENTITY_MAP)
					.setString("channelId", channelId)
					.list();
	    	} catch(Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			this.releaseSession(session);
		} 
		
		if(list != null && list.size() > 0) { 
			for(int i = 0; i < list.size(); i++) {
				String siteId = (String) list.get(i).get("SITE_ID");
				String storeName1 = (String) list.get(i).get("STORE_NAME1");
				result.add(new StringId(siteId, storeName1));
			} 
		}
		
		return result; 
    }
}