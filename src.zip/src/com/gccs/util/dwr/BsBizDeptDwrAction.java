/**
 * @(#)BsBizDeptDwrAction.java 2013/11/26
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.gccs.util.dwr;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.rfep.util.SqlUtil;

/**
 * <b></b>
 * @author kaychen
 * @Date: 2012/10/10 上午 10:48:37
 * @Project Name: RFEP
 */
public class BsBizDeptDwrAction {
	// 營業課區中文說明SQL
	private static String SQL_queryBsBizDeptName_ForDept = " select b.name from BS_BIZ_DEPT b" +
			" where b.channel_id=:channelId and b.store_id=:storeId " +
			" and b.biz_id=:deptBizId and b.enabled='1' ";
	
	private static String SQL_queryBsBizDeptName_ForArea = " select a.name " +
			" from BS_BIZ_DEPT d inner join BS_BIZ_DEPT a on " +
			" d.oid = a.parent_oid " +
			" where a.channel_id=:channelId and a.store_id=:storeId " +
			" and d.biz_id=:deptBizId and a.biz_id=:areaBizId " +
			" and a.enabled='1' ";
	
	/**
	 * 取得營業課區中文說明
	 * @param params
	 * 	必填：
	 * 		channelId
	 * 		storeId
	 * 		deptBizId
	 * 	可選：
	 * 		areaBizId
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String queryBsBizDeptName(Map params) {
		String sql = StringUtils.isNotBlank((String)params.get("areaBizId")) ?  SQL_queryBsBizDeptName_ForArea : SQL_queryBsBizDeptName_ForDept;
		List<Map<String,Object>> list = SqlUtil.jdbc.queryForList(sql, params);

		if(list.isEmpty())
			return null;
		else
			return list.get(0).get("name").toString();
	}
	
	
	// 營業課區中文說明SQL
	private static String SQL_queryBsBizDeptNameAndOid_ForDept = " select b.oid, b.name from BS_BIZ_DEPT b" +
			" where b.channel_id=:channelId and b.store_id=:storeId " +
			" and b.biz_id=:deptBizId and b.enabled='1' ";
	
	private static String SQL_queryBsBizDeptNameAndOid_ForArea = " select a.oid, a.name " +
			" from BS_BIZ_DEPT d inner join BS_BIZ_DEPT a on " +
			" d.oid = a.parent_oid " +
			" where a.channel_id=:channelId and a.store_id=:storeId " +
			" and d.biz_id=:deptBizId and a.biz_id=:areaBizId " +
			" and a.enabled='1' ";
	/**
	 * 取得營業課區中文說明與Oid
	 * @param params
	 * 	必填：
	 * 		channelId
	 * 		storeId
	 * 		deptBizId
	 * 	可選：
	 * 		areaBizId
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map queryBsBizDeptNameAndOid(Map params) {
		String sql = StringUtils.isNotBlank((String)params.get("areaBizId")) ?  SQL_queryBsBizDeptNameAndOid_ForArea : SQL_queryBsBizDeptNameAndOid_ForDept;
		List<Map<String,Object>> list = SqlUtil.jdbc.queryForList(sql, params);

		if(list.isEmpty())
			return null;
		else
			return list.get(0);
	}
}
