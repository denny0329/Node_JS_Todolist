package com.gccs.util.dwr;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpSession;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.directwebremoting.WebContext;
import org.directwebremoting.WebContextFactory;

import com.bnq.sc.model.ScSysuser;
import com.gccs.bs.model.BsChannel;
import com.gccs.util.cache.BsChannelDefinition;

/**
 * <b></b>
 * @author kaychen
 * @Date: 2010/1/8 下午 6:31:00
 * @Project Name: RFEP
 */
public class BsChannelDwrAction {
	private static final Logger log = LogManager.getLogger(BsChannelDwrAction.class);

	public static List<Map> getChannel(String byAuth) {
		if(byAuth==null ||"".equalsIgnoreCase(byAuth) ||"0".equalsIgnoreCase(byAuth)||byAuth.length()>1){
			//byAuth.length() >1 因為如果是dwr沒傳入參數，該物件byAuth會是一串字串(如:c0-e1)
			//byAuth只有 0 或 1 所以長度不會有超過1的時候
			return getChannelList();
		}else	return getChannelListByAuth();
	}

	@SuppressWarnings("unchecked")
	private static List<Map> getChannelList() {
		List list = new ArrayList() ;
		Map<String,String> map = new TreeMap<String,String>() ;
		List channelList = BsChannelDefinition.findAllChannel() ;
		if(channelList != null) {
			log.info("getChannelList() / size : "+channelList.size());
			map.put("", "請選擇") ;
			for(Iterator iterator = channelList.iterator(); iterator.hasNext(); ) {
				BsChannel bsChannel = (BsChannel)iterator.next();
				map.put(bsChannel.getChannelId(), bsChannel.getChannelId()+"-"+bsChannel.getChannelName1()) ;
			}
		}else log.info("getChannelList() / channelList is Null");
		list.add(map) ;
		return list ;
	}

	@SuppressWarnings("unchecked")
	public static List<Map>getChannelListByAuth(){
		List list = new ArrayList() ;
		WebContext ctx = WebContextFactory.get();
		HttpSession session = ctx.getSession() ;
		ScSysuser user = (ScSysuser)session.getAttribute("user");

		Map<String,String> map = new TreeMap<String,String>();
		List <BsChannel>channelList = user.getAuthChannel();
		if(channelList != null) {
			log.info("getChannelListByAuth() / size : "+channelList.size());
			map.put("", "請選擇") ;
			for(Iterator iterator = channelList.iterator(); iterator.hasNext(); ) {
				BsChannel bsChannel = (BsChannel)iterator.next();
				map.put(bsChannel.getChannelId(), bsChannel.getChannelId()+"-"+bsChannel.getChannelName1()) ;
			}
		}else log.info("getChannelListByAuth() / channelList is Null");
		list.add(map) ;
		return list;

	}
}
