package com.gccs.util.dwr;

import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.bs.service.BsCodeService;
import com.bnq.util.QueryResult;
import com.gccs.gf.model.GfGift;
import com.gccs.gf.model.GfGiftActivitySku;
import com.gccs.gf.sevice.GiftService;
import com.gccs.ws.service.BaseWebService;

/**
 * @author Van
 */
public class GiftDwrAction {
	private static final Logger log = LogManager.getLogger(GiftDwrAction.class) ;

	private GiftService gfService ;
	private BsCodeService bsCodeService;
	private MarketingDwrAction mtDwrAction;

	private static final String CODE_CLASS_BANK = "BANK";

	public MarketingDwrAction getMtDwrAction() {
		return mtDwrAction;
	}
	public void setMtDwrAction(MarketingDwrAction mtDwrAction) {
		this.mtDwrAction = mtDwrAction;
	}
	public BsCodeService getBsCodeService() {
		return bsCodeService;
	}
	public void setBsCodeService(BsCodeService bsCodeService) {
		this.bsCodeService = bsCodeService;
	}
	public GiftService getGfService() {
		return gfService;
	}
	public void setGfService(GiftService gfService) {
		this.gfService = gfService;
	}


	public GfGift findGiftIdById(String giftId)throws Exception {
		log.info("giftId: "+giftId);
		return this.gfService.findGiftByGiftId(giftId);
	}

	public QueryResult findActivitySkuByActivityOid(String formId,String formIndex,String formPageSize)throws Exception{
		String oid = formId;
		int index = Integer.parseInt(BaseWebService.isEmpty(formIndex)?"0":formIndex);
		int pageSize = Integer.parseInt(BaseWebService.isEmpty(formPageSize)?"0":formPageSize) ;
		QueryResult queryResult = this.gfService.findActivitySkuByActivityOid(oid, index, pageSize);
		List <GfGiftActivitySku>collection = queryResult.getResult();
		if(collection!=null && collection.size()>0){
			log.info("getQueryList total count : "+queryResult.getCount());
			 StringBuilder sb = new StringBuilder();
			 log.info("collection size : "+collection.size());
			 for(int i=0;i<collection.size();i++){
				 GfGiftActivitySku vo =  collection.get(i);
				 //vo.setClassName(className)
				 vo.setClassName(mtDwrAction.queryClassMappedName(
						 vo.getDept(),
						 vo.getSubDept(),
						 vo.getClass_(),
						 vo.getSubClass())
						 );
				 collection.set(i, vo);
			 }
			 queryResult.setResult(collection);
		}
		return queryResult;
	}

	public boolean checkGiftIdDuplicate(String giftId){
		GfGift gift = this.getGfService().findGiftByGiftId(giftId);
		return (gift!=null?true:false);

	}

	public Map queryStoreMap(String giftId, String channelId, String storeId) {
		return this.getGfService().queryStoreMap( giftId,  channelId,  storeId);
	}
	public long queryCanTransferAmount(String giftOid, String channelId, String storeId){
		return this.getGfService().queryCanTransferAmount( giftOid,  channelId,  storeId);
	}
	public String findActivityNameByActivityId(String activityId){
		return this.getGfService().findActivityNameByActivityId(activityId);
	}
}
