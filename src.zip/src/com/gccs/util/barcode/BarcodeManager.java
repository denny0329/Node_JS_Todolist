/**
 * @(#)BarcodeManager.java 2015/03/06
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package com.gccs.util.barcode;

import org.krysalis.barcode4j.impl.upcean.EAN13LogicImpl;
import org.krysalis.barcode4j.impl.upcean.EAN8LogicImpl;

import com.bnq.util.StringUtils;

public class BarcodeManager {
	public final static String EAN8 = "EAN8";
	public final static String EAN13 = "EAN13";
	public final static String CODE39 = "CODE39";
	
	/**
	 * 依據條碼類型、輸入值取回驗證碼
	 * @param barcodeType 條碼類型
	 * @param inputValue 要進行編碼的輸入字串值
	 * @return 驗證碼
	 * @throws Exception
	 */
	public static String getChecksum(String barcodeType, String inputValue) throws RuntimeException {
		String checksum = null;
		try {
			String bcType = StringUtils.blankToNull(barcodeType);
			if(bcType != null) {
				String _value = StringUtils.blankToNull(inputValue);
				if(_value != null) {
					if (bcType.equalsIgnoreCase(EAN13)) {
						char checksumChar = EAN13LogicImpl
								.calcChecksum(_value);
						checksum = String.valueOf(checksumChar);
					} else if (bcType.equalsIgnoreCase(EAN8)) {
						char checksumChar = EAN8LogicImpl
								.calcChecksum(_value);
						checksum = String.valueOf(checksumChar);
					} else if (bcType.equalsIgnoreCase(CODE39)) {
						//BNQ CODE39沒有使用Checksum
					}
				} else {
					throw new Exception("欲執行編碼的原始輸入值不可為空");
				}
			} else {
				throw new Exception("必須指定條碼類型");
			}
		} catch(Exception e) {
			throw new RuntimeException(e.getMessage());
		}
		
		return checksum;
	}
	
	/**
	 * 依據條碼類型、輸入值取回BarcodeMsg
	 * @param barcodeType 條碼類型
	 * @param inputValue 要進行編碼的輸入字串值
	 * @return BarcodeMsg
	 * @throws Exception
	 */
	public static String getBarcodeMsg(String barcodeType, String inputValue) throws Exception {
		String barcode = null;
		if(barcodeType != null) {
			if(barcodeType.equalsIgnoreCase(EAN13)) {
				barcode = inputValue + getChecksum(barcodeType, inputValue);
			} else if(barcodeType.equalsIgnoreCase(CODE39)) {
				barcode = inputValue;
			} else if(barcodeType.equalsIgnoreCase(EAN8)) {
				barcode = inputValue + getChecksum(barcodeType, inputValue);
			}
		}
		return barcode;
	}
	
	/**
	 * 依據條碼類型、輸入值取回BarcodeMsg
	 * @param barcodeType 	:	條碼類型
	 * @param skuValue 		:	要進行編碼的輸入Sku
	 * @return 國際條碼(開頭為20)或展示品條碼(開頭為25)；序號為1。
	 * @throws Exception
	 */
	private static String getSkuBarcodeMsg(String barcodeType, String skuValue) throws Exception{
		return getSkuBarcodeMsg(barcodeType,skuValue,null);
	}
	
	/**
	 * 依據條碼類型、輸入值取回BarcodeMsg
	 * @param barcodeType 	:	條碼類型(EAN13、CODE39、EAN8)
	 * @param skuNo 		:	要進行編碼的輸入Sku
	 * @param seqNo			:	default=1(序號1碼)
	 * @return BarcodeMsg barcodeType、skuNo 為空值時回傳 null<br>
	 * 					  barcodeType = EAN13 時回傳：展示品條碼 : 25(2碼) + SKU_NO(9碼) + 1(序號1碼) + 檢查碼(1碼)<br>
	 * 					  barcodeType = CODE39 時回傳：一般條碼 : SKU_NO(9碼)<br>
	 * 					  barcodeType = EAN8 時回傳：國際條碼 : 20(2碼) + SKU_NO(9碼) + 1(序號1碼) + 檢查碼(1碼)
	 * @throws Exception
	 */
	private static String getSkuBarcodeMsg(String barcodeType, String skuNo, String seqNo) throws Exception {
		String barcode = null;
		if(barcodeType != null) {
			if( skuNo != null ){
				if( skuNo.length() != 9 )
					throw new Exception("欲執行編碼的原始輸入值[SKU_NO]長度應為9碼");
				if( seqNo == null || seqNo.trim().equals("") )
					seqNo = "1";
				String inputValue = "";
				if(barcodeType.equalsIgnoreCase(EAN13)) {
					//展示品條碼 : 25(2碼) + SKU_NO(9碼) + 1(序號1碼) + 檢查碼(1碼)
					inputValue = "25"+skuNo+seqNo;
				} else if(barcodeType.equalsIgnoreCase(CODE39)) {
					barcode = skuNo;
				} else if(barcodeType.equalsIgnoreCase(EAN8)) {
					//國際條碼 : 20(2碼) + SKU_NO(9碼) + 1(序號1碼) + 檢查碼(1碼)
					inputValue = "20"+skuNo+seqNo;
				}
				if(barcodeType.equalsIgnoreCase(EAN13)) {
					barcode = inputValue + getChecksum(barcodeType, inputValue);
				} else if(barcodeType.equalsIgnoreCase(CODE39)) {
					barcode = inputValue;
				} else if(barcodeType.equalsIgnoreCase(EAN8)) {
					barcode = inputValue + getChecksum(barcodeType, inputValue);
				}
			}
		}
		return barcode;
	}
	
	/**
	 * 將 skuNo 轉換為國際條碼(序號固定為1)。
	 * @param skuNo 商品代碼
	 * @return 20(2碼) + SKU_NO(9碼) + 1(序號1碼) + 檢查碼(1碼)：若缺少必要資訊回傳 null
	 * @throws Exception
	 */
	public static String getUPC(String skuNo)throws Exception{
		return getSkuBarcodeMsg(EAN8,skuNo);
	}
	
	/**
	 * 將 skuNo 轉換為展示品條碼(序號固定為1)。
	 * @param skuNo 商品代碼
	 * @return 25(2碼) + SKU_NO(9碼) + 1(序號1碼) + 檢查碼(1碼)：若缺少必要資訊回傳 null
	 * @throws Exception
	 */
	public static String getDisplayUPC(String skuNo)throws Exception{
		return getSkuBarcodeMsg(EAN13,skuNo);
	}
}