package com.gccs.util;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.UnknownHostException;
import java.util.Collections;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLException;

import org.apache.commons.httpclient.ConnectTimeoutException;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpRequest;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.protocol.HttpContext;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;


public class CallTestriteApiClient {
	
	private static final Logger log = LogManager.getLogger("bonusBatch");
	private KeyCloakTokenUtil keyCloakTokenUtil;
	private int timeout = 5000;
	private int maxRetries = 3;
	private int retryInterval = 5000;
	
	public KeyCloakTokenUtil getKeyCloakTokenUtil() {
		return keyCloakTokenUtil;
	}
	
	public void setKeyCloakTokenUtil(KeyCloakTokenUtil keyCloakTokenUtil) {
		this.keyCloakTokenUtil = keyCloakTokenUtil;
	}

	private ClientHttpRequestFactory getClientHttpRequestFactory() {
	    RequestConfig config = RequestConfig.custom()
	      .setConnectTimeout(timeout)
	      .setConnectionRequestTimeout(timeout)
	      .setSocketTimeout(timeout)
	      .build();
	    CloseableHttpClient client = HttpClientBuilder
	      .create()
	      .setDefaultRequestConfig(config)
	      .build();
	    return new HttpComponentsClientHttpRequestFactory(client);
	}

	private ClientHttpRequestFactory getRetryClientHttpRequestFactory() {
		RequestConfig config = RequestConfig.custom()
				.setConnectTimeout(timeout)
				.setConnectionRequestTimeout(timeout)
				.setSocketTimeout(timeout)
				.build();
		CloseableHttpClient client = HttpClientBuilder
				.create()
				.setRetryHandler(getRetryHandler())
				.setDefaultRequestConfig(config)
				.build();
		return new HttpComponentsClientHttpRequestFactory(client);
	}
	
	private HttpRequestRetryHandler getRetryHandler() {
		return new HttpRequestRetryHandler() {
			int retryInterval = 0;
			public boolean retryRequest(IOException exception, int executionCount, HttpContext context) {
				retryInterval += getRetryInterval();
				log.info("executionCount:" + executionCount + " retryInterval:" + retryInterval);
				try {
					TimeUnit.MILLISECONDS.sleep(retryInterval);
				} catch (InterruptedException e) {
					log.error(e.getMessage(), e);
					Thread.currentThread().interrupt();
				}
				if (executionCount >= getMaxRetries()) {
					// Do not retry if over max retry count
					return false;
				}
				if (exception instanceof InterruptedIOException) {
					// Timeout
					return true;
				}
				if (exception instanceof UnknownHostException) {
					// Unknown host
					return false;
				}
				if (exception instanceof ConnectTimeoutException) {
					// Connection refused
					return true;
				}
				if (exception instanceof SSLException) {
					// SSL handshake exception
					return false;

				}
				HttpClientContext clientContext = HttpClientContext.adapt(context);
				HttpRequest request = clientContext.getRequest();
				boolean idempotent = !(request instanceof HttpEntityEnclosingRequest);
				if (idempotent) {
					// Retry if the request is considered idempotent
					return idempotent;
				}
				return false;
			}
		};
	}
	
	/**
	 * POST method
	 * @param url 呼叫網址
	 * @param json 參數
	 * @return
	 */
	public ResponseEntity<String> callTestritePostTemplete(String url, JSONObject json) {
		String token = keyCloakTokenUtil.getToken();
		
		HttpHeaders headers = new HttpHeaders();
		// set content-type header
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("Authorization", "Bearer " + token);
		// set accept header 中文編碼
		MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
		headers.setAccept(Collections.singletonList(type));
		
		// build the request
		HttpEntity<String> entity = new HttpEntity<>(json.toString(), headers);
		
		// send POST request
		RestTemplate template = new RestTemplate(getClientHttpRequestFactory());
		return template.postForEntity(url, entity, String.class);
	}
	
	/**
	 * GET method
	 * @param url 呼叫網址
	 * @param json 參數
	 * @return
	 */
	public HttpEntity<String> callTestriteGetTemplete(String url, JSONObject json) {
		String token = keyCloakTokenUtil.getToken();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		headers.add("Authorization", "Bearer " + token);
		// set accept header 中文編碼
		MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
		headers.setAccept(Collections.singletonList(type));
		// build the request
		HttpEntity<?> entity = new HttpEntity<>(headers);
		
		UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);		
		Iterator<String> keys = json.keys();
		while(keys.hasNext()) {
		    String key = keys.next();
		    builder.queryParam(key, json.get(key));
		}
		
		RestTemplate template = new RestTemplate(getClientHttpRequestFactory());		
		HttpEntity<String> response = template.exchange(builder.build().toString(), HttpMethod.GET, entity, String.class);
		
		return response;
	}
	
	/**
	 * depend on spec's token and use HTTP method calling Testrite RESTful API
	 * @param token from which clients
	 * @param url service URL
	 * @param jsonBody request
	 * @param method HTTP method
	 * @return
	 */
	public ResponseEntity<String> callTestriteServiceByDiffToken(String token, String url, JSONObject jsonBody, HttpMethod method) {
		HttpHeaders headers = new HttpHeaders();
		// set content-type header
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.add("Authorization", "Bearer " + token);
		// set accept header
		MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
		headers.setAccept(Collections.singletonList(type));
		
		// build the request
		HttpEntity<String> entity = new HttpEntity<>(jsonBody.toString(), headers);
		
		// send request
		RestTemplate template = new RestTemplate(getRetryClientHttpRequestFactory());
		return template.exchange(url, method, entity, String.class);
	}

	public int getTimeout() {
		return timeout;
	}

	public void setTimeout(int timeout) {
		this.timeout = timeout;
	}

	public int getMaxRetries() {
		return maxRetries;
	}

	public void setMaxRetries(int maxRetries) {
		this.maxRetries = maxRetries;
	}

	public int getRetryInterval() {
		return retryInterval;
	}

	public void setRetryInterval(int retryInterval) {
		this.retryInterval = retryInterval;
	}
}
