package com.gccs.util.model;

import java.util.List;

import com.gccs.member.model.vo.MemberLikeVo;

public class MemberLikeCount {
	private Integer total;
	private List<MemberLikeVo> list;
	
	private Integer pageNum;
	private Integer pageSize;
	private Integer size;
	private Integer startRow;
	private Integer endRow;
	private Integer pages;
	private Integer prePage;
	private Integer nextPage;
	private String isFirstPage;
	private String isLastPage;
	private String hasPreviousPage;
	private String hasNextPage;
	
	private Integer navigatePages;
	private Integer[] navigatepageNums;
	private Integer navigateFirstPage;
	private Integer navigateLastPage;
	private Integer firstPage;
	private Integer lastPage;
	
	public Integer getTotal() {
		return total;
	}
	public void setTotal(Integer total) {
		this.total = total;
	}
	public List<MemberLikeVo> getList() {
		return list;
	}
	public void setList(List<MemberLikeVo> list) {
		this.list = list;
	}
	public Integer getPageNum() {
		return pageNum;
	}
	public void setPageNum(Integer pageNum) {
		this.pageNum = pageNum;
	}
	public Integer getPageSize() {
		return pageSize;
	}
	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}
	public Integer getSize() {
		return size;
	}
	public void setSize(Integer size) {
		this.size = size;
	}
	public Integer getStartRow() {
		return startRow;
	}
	public void setStartRow(Integer startRow) {
		this.startRow = startRow;
	}
	public Integer getEndRow() {
		return endRow;
	}
	public void setEndRow(Integer endRow) {
		this.endRow = endRow;
	}
	public Integer getPages() {
		return pages;
	}
	public void setPages(Integer pages) {
		this.pages = pages;
	}
	public Integer getPrePage() {
		return prePage;
	}
	public void setPrePage(Integer prePage) {
		this.prePage = prePage;
	}
	public Integer getNextPage() {
		return nextPage;
	}
	public void setNextPage(Integer nextPage) {
		this.nextPage = nextPage;
	}
	public String getIsFirstPage() {
		return isFirstPage;
	}
	public void setIsFirstPage(String isFirstPage) {
		this.isFirstPage = isFirstPage;
	}
	public String getIsLastPage() {
		return isLastPage;
	}
	public void setIsLastPage(String isLastPage) {
		this.isLastPage = isLastPage;
	}
	public String getHasPreviousPage() {
		return hasPreviousPage;
	}
	public void setHasPreviousPage(String hasPreviousPage) {
		this.hasPreviousPage = hasPreviousPage;
	}
	public String getHasNextPage() {
		return hasNextPage;
	}
	public void setHasNextPage(String hasNextPage) {
		this.hasNextPage = hasNextPage;
	}
	public Integer getNavigatePages() {
		return navigatePages;
	}
	public void setNavigatePages(Integer navigatePages) {
		this.navigatePages = navigatePages;
	}
	public Integer[] getNavigatepageNums() {
		return navigatepageNums;
	}
	public void setNavigatepageNums(Integer[] navigatepageNums) {
		this.navigatepageNums = navigatepageNums;
	}
	public Integer getNavigateFirstPage() {
		return navigateFirstPage;
	}
	public void setNavigateFirstPage(Integer navigateFirstPage) {
		this.navigateFirstPage = navigateFirstPage;
	}
	public Integer getNavigateLastPage() {
		return navigateLastPage;
	}
	public void setNavigateLastPage(Integer navigateLastPage) {
		this.navigateLastPage = navigateLastPage;
	}
	public Integer getFirstPage() {
		return firstPage;
	}
	public void setFirstPage(Integer firstPage) {
		this.firstPage = firstPage;
	}
	public Integer getLastPage() {
		return lastPage;
	}
	public void setLastPage(Integer lastPage) {
		this.lastPage = lastPage;
	}
}
