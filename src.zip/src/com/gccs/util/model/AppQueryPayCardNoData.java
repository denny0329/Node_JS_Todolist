package com.gccs.util.model;

import com.gccs.member.model.vo.Transition;

public class AppQueryPayCardNoData<T> {
	private String errorCode;
	private String status;
	private String message;
	private Transition<T> data;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Transition<T> getData() {
		return data;
	}

	public void setData(Transition<T> data) {
		this.data = data;
	}
}
