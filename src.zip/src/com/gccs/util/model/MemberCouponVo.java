package com.gccs.util.model;

import java.util.Date;

public class MemberCouponVo {
	private Date transDate;
	private String channelId;
	private String storeId;
	private String recId;
	private String giftName;
	private String guiNo;
	private String grno;
	private Integer giftCount;
	private String giftId;
	private String recType;
	
	public Date getTransDate() {
		return transDate;
	}
	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getStoreId() {
		return storeId;
	}
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
	public String getRecId() {
		return recId;
	}
	public void setRecId(String recId) {
		this.recId = recId;
	}
	public String getGiftName() {
		return giftName;
	}
	public void setGiftName(String giftName) {
		this.giftName = giftName;
	}
	public String getGuiNo() {
		return guiNo;
	}
	public void setGuiNo(String guiNo) {
		this.guiNo = guiNo;
	}
	public String getGrno() {
		return grno;
	}
	public void setGrno(String grno) {
		this.grno = grno;
	}
	public Integer getGiftCount() {
		return giftCount;
	}
	public void setGiftCount(Integer giftCount) {
		this.giftCount = giftCount;
	}
	public String getGiftId() {
		return giftId;
	}
	public void setGiftId(String giftId) {
		this.giftId = giftId;
	}
	
	public String getRecType() {
		return recType;
	}
	public void setRecType(String recType) {
		this.recType = recType;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((channelId == null) ? 0 : channelId.hashCode());
		result = prime * result + ((giftCount == null) ? 0 : giftCount.hashCode());
		result = prime * result + ((giftId == null) ? 0 : giftId.hashCode());
		result = prime * result + ((giftName == null) ? 0 : giftName.hashCode());
		result = prime * result + ((grno == null) ? 0 : grno.hashCode());
		result = prime * result + ((guiNo == null) ? 0 : guiNo.hashCode());
		result = prime * result + ((recId == null) ? 0 : recId.hashCode());
		result = prime * result + ((recType == null) ? 0 : recType.hashCode());
		result = prime * result + ((storeId == null) ? 0 : storeId.hashCode());
		result = prime * result + ((transDate == null) ? 0 : transDate.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MemberCouponVo other = (MemberCouponVo) obj;
		if (channelId == null) {
			if (other.channelId != null)
				return false;
		} else if (!channelId.equals(other.channelId))
			return false;
		if (giftCount == null) {
			if (other.giftCount != null)
				return false;
		} else if (!giftCount.equals(other.giftCount))
			return false;
		if (giftId == null) {
			if (other.giftId != null)
				return false;
		} else if (!giftId.equals(other.giftId))
			return false;
		if (giftName == null) {
			if (other.giftName != null)
				return false;
		} else if (!giftName.equals(other.giftName))
			return false;
		if (grno == null) {
			if (other.grno != null)
				return false;
		} else if (!grno.equals(other.grno))
			return false;
		if (guiNo == null) {
			if (other.guiNo != null)
				return false;
		} else if (!guiNo.equals(other.guiNo))
			return false;
		if (recId == null) {
			if (other.recId != null)
				return false;
		} else if (!recId.equals(other.recId))
			return false;
		if (recType == null) {
			if (other.recType != null)
				return false;
		} else if (!recType.equals(other.recType))
			return false;
		if (storeId == null) {
			if (other.storeId != null)
				return false;
		} else if (!storeId.equals(other.storeId))
			return false;
		if (transDate == null) {
			if (other.transDate != null)
				return false;
		} else if (!transDate.equals(other.transDate))
			return false;
		return true;
	}
	
}
