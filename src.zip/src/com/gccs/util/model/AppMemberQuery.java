package com.gccs.util.model;

import com.gccs.member.model.vo.AppMemberVo;

public class AppMemberQuery {
	private String errorCode;
	private String status;
	private String message;
	private AppMemberVo data;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public AppMemberVo getData() {
		return data;
	}

	public void setData(AppMemberVo data) {
		this.data = data;
	}
}
