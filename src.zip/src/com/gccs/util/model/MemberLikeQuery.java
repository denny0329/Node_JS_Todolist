package com.gccs.util.model;

import com.gccs.member.model.vo.MemberLikeVo;

public class MemberLikeQuery {
	private String errorCode;
	private String status;
	private String message;
	private MemberLikeCount data;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public MemberLikeCount getData() {
		return data;
	}

	public void setData(MemberLikeCount data) {
		this.data = data;
	}
}
