package com.gccs.util.quartz;

import java.util.Date;

public interface IQuartzLogService {
	public void createQuartzLog(String batchId, String[] precedingOpt) throws Exception;
	
	public boolean batchProcessBegin(final String batchId, final Date date) throws Exception;
	
	public boolean checkPrecedingOperationCompleted(String batchId) throws Exception;
	
	public boolean batchProcessEnd(final String batchId, final Date beginDate, final Date endDate) throws Exception;
}
