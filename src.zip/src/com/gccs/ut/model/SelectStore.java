package com.gccs.ut.model;

public class SelectStore extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = 6142613100914154725L;

	private String oid;
	private String masterOid; //主檔Master 物件OID
	private String channelId; //通路代號
	private String storeId; //店別代號
	
	public SelectStore() {}
    public SelectStore(String masterOid, String channelId, String storeId) {
       this.masterOid = masterOid;
       this.channelId = channelId;
       this.storeId = storeId;
    }

	
	public String getOid() {
		return this.oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getMasterOid() {
		return this.masterOid;
	}
	public void setMasterOid(String masterOid) {
		this.masterOid = masterOid;
	}
	public String getChannelId() {
		return this.channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getStoreId() {
		return this.storeId;
	}
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
}
