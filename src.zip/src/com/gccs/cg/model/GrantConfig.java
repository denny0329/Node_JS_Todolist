package com.gccs.cg.model;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.bnq.sc.model.ScSysuser;
import com.gccs.util.web.SelectItem;

@SuppressWarnings("unchecked")
public class GrantConfig extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = -2644340237237712520L;

	private String oid;
	private String activityOid; //活動主檔OID
	private Date startDate; //發放日期From
	private Date endDate; //發放日期To
	private String startTime; //發放開始時間
	private String endTime; //發放結束時間
	private Integer grantSit; //發放位置
	private Integer unitsPerTxn; //單筆交易可發放單位
	private Integer maxUnit; //活動期間限制發放單位
	private Integer inadequent; //不足額處理方式
	private Integer birthMonth; //依會員生日
	private String cardTypes; //可發放卡別
	private String txnTypes; //可發放交易別
	private Integer crossStore; //可否跨店累計發送
	private Integer crossDate; //可否跨日累計發送
	private Integer crossTxn; //可否跨交易累計發送
	private String note; //說明
	private Integer skuAval; //指定品項是否可計算金額	
	private Date createTime;
	private String creator;
	private String creatorName;
	private String modifier;
	private String modifierName;
	private Date modifyTime;
	
	private List<GrantThreshold> gtList;	
	
	/**********************************************************************************/
	
	public GrantConfig() {}		
	public GrantConfig(ScSysuser user) {
		this.setStartDate(new Date());
		this.setEndDate(new Date());
		this.setGrantSit(0);
		this.setInadequent(1);
		this.setBirthMonth(0);
		this.setCardTypes("0");
		this.setTxnTypes("0");
		this.setUnitsPerTxn(0);
		this.setMaxUnit(0);
		this.setCrossStore(1);
		this.setCrossDate(1);
		this.setCrossTxn(1);
		this.setSkuAval(0);
		this.setCreateTime(new Date());
		this.setCreator(user.getUserId());
		this.setCreatorName(user.getUserName());
		this.setModifyTime(new Date());
		this.setModifier(user.getUserId());
		this.setModifierName(user.getUserName());
	}
		
	public static final Map grantSitMap;
	public static final Map txnTypesMap;
	public static final Map inadequentMap; 
	public static final Map cardTypesMap = SelectItem.BsCardTypeMap;
	static {
		grantSitMap = new LinkedHashMap<String,String>();
		grantSitMap.put("0", "POS");
		grantSitMap.put("1", "服務台");
		
		txnTypesMap = new LinkedHashMap<String,String>();
		txnTypesMap.put("0", "一般");
		txnTypesMap.put("1", "EC");
		txnTypesMap.put("2", "SO");
		txnTypesMap.put("3", "TTS");
		
		inadequentMap = new LinkedHashMap<String,String>();
		inadequentMap.put("1", "1- 無條件捨去");
		inadequentMap.put("2", "2- 無條件進入");
		inadequentMap.put("3", "3- 四捨五入");		
	}
	
	public String getGrantSitTxt() {		
		return (this.grantSit!=null ? (String)grantSitMap.get(this.grantSit.toString()) : "");
	}	
	
	/**********************************************************************************/
	

	public String getOid() {
		return this.oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getActivityOid() {
		return this.activityOid;
	}
	public void setActivityOid(String activityOid) {
		this.activityOid = activityOid;
	}	
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public Integer getGrantSit() {
		return this.grantSit;
	}
	public void setGrantSit(Integer grantSit) {
		this.grantSit = grantSit;
	}
	public Integer getUnitsPerTxn() {
		return this.unitsPerTxn;
	}
	public void setUnitsPerTxn(Integer unitsPerTxn) {
		this.unitsPerTxn = unitsPerTxn;
	}
	public Integer getMaxUnit() {
		return this.maxUnit;
	}
	public void setMaxUnit(Integer maxUnit) {
		this.maxUnit = maxUnit;
	}	
	public Integer getInadequent() {
		return inadequent;
	}	
	public void setInadequent(Integer inadequent) {
		this.inadequent = inadequent;
	}	
	public Integer getBirthMonth() {
		return this.birthMonth;
	}
	public void setBirthMonth(Integer birthMonth) {
		this.birthMonth = birthMonth;
	}
	public String getCardTypes() {
		return this.cardTypes;
	}
	public void setCardTypes(String cardTypes) {
		this.cardTypes = cardTypes;
	}
	public String getTxnTypes() {
		return this.txnTypes;
	}
	public void setTxnTypes(String txnTypes) {
		this.txnTypes = txnTypes;
	}
	public Integer getCrossStore() {
		return this.crossStore;
	}
	public void setCrossStore(Integer crossStore) {
		this.crossStore = crossStore;
	}
	public Integer getCrossDate() {
		return this.crossDate;
	}
	public void setCrossDate(Integer crossDate) {
		this.crossDate = crossDate;
	}
	public Integer getCrossTxn() {
		return this.crossTxn;
	}
	public void setCrossTxn(Integer crossTxn) {
		this.crossTxn = crossTxn;
	}
	public String getNote() {
		return this.note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public Date getCreateTime() {
		return this.createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreator() {
		return this.creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getCreatorName() {
		return this.creatorName;
	}
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}
	public String getModifier() {
		return this.modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public String getModifierName() {
		return this.modifierName;
	}
	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}
	public Date getModifyTime() {
		return this.modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}	
	public Integer getSkuAval() {
		return skuAval;
	}	
	public void setSkuAval(Integer skuAval) {
		this.skuAval = skuAval;
	}
	public List<GrantThreshold> getGtList() {
		return gtList;
	}
	public void setGtList(List<GrantThreshold> gtList) {
		this.gtList = gtList;
	}
}
