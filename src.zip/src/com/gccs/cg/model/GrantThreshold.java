package com.gccs.cg.model;

public class GrantThreshold extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = -2453285464184870977L;

	private String oid;
	private String configOid; //發放設定OID
	private Integer amountF; //消費金額FROM
	private Integer amountT; //消費金額TO
	private Integer units; //發放單位

	
	public String getOid() {
		return this.oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getConfigOid() {
		return this.configOid;
	}
	public void setConfigOid(String configOid) {
		this.configOid = configOid;
	}
	public Integer getAmountF() {
		return this.amountF;
	}
	public void setAmountF(Integer amountF) {
		this.amountF = amountF;
	}
	public Integer getAmountT() {
		return this.amountT;
	}
	public void setAmountT(Integer amountT) {
		this.amountT = amountT;
	}
	public Integer getUnits() {
		return this.units;
	}
	public void setUnits(Integer units) {
		this.units = units;
	}

}
