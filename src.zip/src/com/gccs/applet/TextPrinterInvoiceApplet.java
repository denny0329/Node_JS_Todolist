package com.gccs.applet;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.font.FontRenderContext;
import java.awt.font.TextAttribute;
import java.awt.font.TextLayout;
import java.awt.print.Book;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterJob;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.text.CharacterIterator;
import java.text.StringCharacterIterator;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

/**
 * 列印特力屋發票
 * @author san
 *
 */
public class TextPrinterInvoiceApplet extends javax.swing.JApplet{
	private static final long serialVersionUID = 2600482795127247184L;

	private URL url = null;
	List<String> content = null;
	/** Creates new form AppletViewer */
	public TextPrinterInvoiceApplet() {
	}

	public void init() {
		String strUrl = getParameter("REPORT_URL");
		if (strUrl != null) {
			try {
				url = new URL(getCodeBase(), strUrl);
				printContent();
			} catch (Exception e) {
				StringWriter swriter = new StringWriter();
				PrintWriter pwriter = new PrintWriter(swriter);
				e.printStackTrace(pwriter);
				JOptionPane.showMessageDialog(this, swriter.toString());
			}
		} else {
			JOptionPane.showMessageDialog(this, "來源URL必須指定");
		}
	}

	private void printContent() {

		if (url != null) {
			if (content == null) {
				try {
					content = PrintUtil.loadUrlObjectStream(url);
				} catch (Exception e) {
					StringWriter swriter = new StringWriter();
					PrintWriter pwriter = new PrintWriter(swriter);
					e.printStackTrace(pwriter);
					JOptionPane.showMessageDialog(this, swriter.toString());
				}
			}

			if (content != null && content.size() > 0) {
				Thread thread = new Thread(new Runnable() {
					public void run() {
						try {
							PrinterJob job = PrinterJob.getPrinterJob();
							Book book = new Book();
							PageFormat pageFormat = job.defaultPage();
							// 自訂紙張大小
							pageFormat.setPaper(PrintUtil.createPaper100inX55in());

							final List<String> reportPages = content;
							for (final String content : reportPages) {
								book.append(new Printable() {
									public int print(Graphics g, PageFormat format, int pageIndex) {

										Graphics2D g2d = (Graphics2D) g;
										g2d.setPaint(Color.black);
										g2d.translate(format.getImageableX(), format.getImageableY());
										Map map = new Hashtable();
										map.put(TextAttribute.FAMILY, "細明體");
										map.put(TextAttribute.SIZE, new Float(10.0));
										Font font = new Font(map);

										FontRenderContext frc = g2d.getFontRenderContext();
										CharacterIterator strCharIterator = new StringCharacterIterator(content);
										int _x = 0;
										int _y = 0;
										int _line = 1;
										int _adjustmentPix = 0;
										for (char c = strCharIterator.first(); c != CharacterIterator.DONE; c = strCharIterator.next()) {
											// System.out.println(" read c : " + c);
											if (c == '\n') {
												_y += (font.getSize2D());
												_x = 0;
												_line++;
												// 針對特力屋發票單據進行維調整
												if (_line == 8 || (_line >= 15 && _line <= 26)) {
													_adjustmentPix = 2;
												} else if (_line == 31) {
													_adjustmentPix = 1;
												} else if (_line == 27) {
													_adjustmentPix = 4;
												} else if (_line == 11) {
													_adjustmentPix = -1;
												} else if (_line == 12 || _line == 30 || _line == 29) {
													_adjustmentPix = -2;
												} else if (_line == 11) {
													_adjustmentPix = -4;
												} else if (_line == 10) {
													_adjustmentPix = -5;
												} else {
													_adjustmentPix = 0;
												}
											} else {
												TextLayout layout = new TextLayout(String.valueOf(c), font, frc);
												if ((_y + (int) format.getImageableY() + _adjustmentPix + font.getSize2D()) < format.getImageableHeight())
													layout.draw(g2d, _x, _y + (int) format.getImageableY() + _adjustmentPix);
												// System.out.printf(" c:%s x:%s y:%s fSize:%s f2dSize:%s c.bytes.lenth:%s \n",String.valueOf(c),_x,_y,font.getSize(),font.getSize2D(),String.valueOf(c).getBytes().length);
												if (String.valueOf(c).getBytes().length <= 2)
													_x += (font.getSize2D() / 2) * String.valueOf(c).getBytes().length;
												else
													_x += (font.getSize2D() / 2) * 2;
											}
										}
										return Printable.PAGE_EXISTS;
									}
								}, pageFormat);
							}
							job.setPageable(book);

							if (job.printDialog()) {
								job.print();
							}
						} catch (Exception e) {
							StringWriter swriter = new StringWriter();
							PrintWriter pwriter = new PrintWriter(swriter);
							e.printStackTrace(pwriter);
							JOptionPane.showMessageDialog(null, swriter.toString());
						}
					}
				});
				thread.start();
			} else {
				JOptionPane.showMessageDialog(this, "沒有資料");
			}
		} else {
			JOptionPane.showMessageDialog(this, "來源URL必須指定");
		}
	}
}