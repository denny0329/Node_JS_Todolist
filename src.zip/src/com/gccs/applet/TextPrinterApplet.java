package com.gccs.applet;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.font.FontRenderContext;
import java.awt.font.TextAttribute;
import java.awt.font.TextLayout;
import java.awt.font.TransformAttribute;
import java.awt.geom.AffineTransform;
import java.awt.print.Book;
import java.awt.print.PageFormat;
import java.awt.print.PrinterJob;
import java.awt.print.Printable;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.text.CharacterIterator;
import java.text.StringCharacterIterator;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import javax.swing.JOptionPane;

/**
 * 列印 特力及和樂 換貨,退貨,折讓單據
 * @author san
 */
public class TextPrinterApplet extends javax.swing.JApplet{
	private static final long serialVersionUID = -1126374377173792676L;

	private URL url = null;
	List<String> content = null;
	/** Creates new form AppletViewer */
	public TextPrinterApplet() {
	}

	public void init() {
		String strUrl = getParameter("REPORT_URL");
		if (strUrl != null) {
			try {
				url = new URL(getCodeBase(), strUrl);
				printContent();
			} catch (Exception e) {
				StringWriter swriter = new StringWriter();
				PrintWriter pwriter = new PrintWriter(swriter);
				e.printStackTrace(pwriter);
				JOptionPane.showMessageDialog(this, swriter.toString());
			}
		} else {
			JOptionPane.showMessageDialog(this, "來源URL必須指定");
		}
	}

	/** applet call printer **/
	private void printContent() {

		if (url != null) {
			if (content == null) {
				try {
					content = PrintUtil.loadUrlObjectStream(url);
				} catch (Exception e) {
					StringWriter swriter = new StringWriter();
					PrintWriter pwriter = new PrintWriter(swriter);
					e.printStackTrace(pwriter);
					JOptionPane.showMessageDialog(this, swriter.toString());
				}
			}

			if (content != null && content.size() > 0) {
				Thread thread = new Thread(new Runnable() {
					public void run() {
						try {
							PrinterJob job = PrinterJob.getPrinterJob();
							Book book = new Book();
							PageFormat pageFormat = job.defaultPage();
							// 自訂紙張大小
							pageFormat.setPaper(PrintUtil.createPaper100inX55in());

							final List<String> reportPages = content;
							for (final String content : reportPages) {
								book.append(new Printable() {
									public int print(Graphics g, PageFormat format, int pageIndex) {

										Graphics2D g2d = (Graphics2D) g;
										g2d.setPaint(Color.black);
										g2d.translate(format.getImageableX(), format.getImageableY());
										Map map = new Hashtable();
										map.put(TextAttribute.FAMILY, "細明體");
										map.put(TextAttribute.SIZE, new Float(12.0));
										AffineTransform affineTransform = new AffineTransform();
										affineTransform.setToIdentity();
										map.put(TextAttribute.TRANSFORM, new TransformAttribute(affineTransform));
										Font font = new Font(map);

										FontRenderContext frc = g2d.getFontRenderContext();
										CharacterIterator strCharIterator = new StringCharacterIterator(content);
										int _x = 0;
										int _y = 0;
										for (char c = strCharIterator.first(); c != CharacterIterator.DONE; c = strCharIterator.next()) {
											if (c == '\n') {
												_y += (font.getSize2D());
												_x = 0;
											} else {
												TextLayout layout = new TextLayout(String.valueOf(c), font, frc);
												if ((_y + (int) format.getImageableY() + font.getSize2D()) < format.getImageableHeight())
													layout.draw(g2d, _x, _y + (int) format.getImageableY());
												if (String.valueOf(c).getBytes().length <= 2)
													_x += (font.getSize2D() / 2) * String.valueOf(c).getBytes().length;
												else
													_x += (font.getSize2D() / 2) * 2;
											}
										}
										return Printable.PAGE_EXISTS;
									}
								}, pageFormat);
							}
							job.setPageable(book);

							if (job.printDialog()) {
								job.print();
							}
						} catch (Exception e) {
							StringWriter swriter = new StringWriter();
							PrintWriter pwriter = new PrintWriter(swriter);
							e.printStackTrace(pwriter);
							JOptionPane.showMessageDialog(null, swriter.toString());
						}
					}
				});
				thread.start();
			} else {
				JOptionPane.showMessageDialog(this, "沒有資料");
			}
		} else {
			JOptionPane.showMessageDialog(this, "來源URL必須指定");
		}
	}
}