package com.gccs.applet;

import java.applet.AppletContext;
import java.awt.print.Paper;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

public class PrintUtil {
	
	public static String loadUrlStream(URL url){
		StringBuffer content = new StringBuffer();
		try {
            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(),"UTF-8"));
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                System.out.println(inputLine);
                content.append(inputLine);
            }
            in.close();  
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content.toString();
	}
	
	public static List<String> loadUrlObjectStream(URL url){
		List<String> content = null;
		try {
			ObjectInputStream oin = new ObjectInputStream(url.openStream());
			try {
				boolean readObjects = false;
				Object obj = null;
				while( !readObjects && ( obj = oin.readObject()) != null  ){
					content = (List<String>)obj;
					readObjects = true;
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
            oin.close();  
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content;
	}
	
	//-----------------------------------------------------------------------//
	
	/**
	 * 建立中一刀尺寸<br>
	 * 長10英吋,高5.5英吋,上下邊距42mm <br>
	 * 
	 * EPSON LQ-680C官方設定:<br>
	 * 報表紙的騎縫線上下最小頂邊界和底邊界必須是4.2 mm (0.17 inch)。
	 * @see <a href="http://w3.epson.com.tw/Epson/download/download_b_page.asp?no=154&gType_2=&pnos_2=&sTxt=lq-680c">詳細見EPSON印表機官方文件</a>
	 */
	public static Paper createPaper100inX55in(){
		return createPaper(10.0,5.5,0.42,0.42,0,0);
	}
	
	/**
	 * 建立自定尺寸<br>
	 * 長10英吋,高6英吋,上下邊距42mm <br>
	 * 
	 * EPSON LQ-680C官方設定:<br>
	 * 報表紙的騎縫線上下最小頂邊界和底邊界必須是4.2 mm (0.17 inch)。
	 * @see <a href="http://w3.epson.com.tw/Epson/download/download_b_page.asp?no=154&gType_2=&pnos_2=&sTxt=lq-680c">詳細見EPSON印表機官方文件</a>
	 */
	public static Paper createPaper100inX60in(){
		return createPaper(10.0,6.0,0.42,0.42,0,0);
	}
	
	/**
	 * 
	 * @param widthMM 	: 寬(英吋)
	 * @param heightMM	: 高(英吋)
	 * <br>上下左右邊界變數 - 0[cm]
	 */
	public static Paper createPaper(double widthIn, double heightIn){
		return createPaperBase(widthIn * 72,heightIn * 72,0,0,0,0);
	}
	
	/**
	 * 
	 * @param widthMM 	: 寬(英吋)
	 * @param heightMM	: 高(英吋)
	 * <br>上下左右邊界變數 - t,b,l,r [cm]
	 */
	public static Paper createPaper(double widthIn, double heightIn, 
			double t, double b, double l, double r){
		return createPaperBase(widthIn * 72,heightIn * 72,t,b,l,r);
	}
	
	/**
	 * 
	 * @param widthMM 	: 寬(mm)
	 * @param heightMM	: 高(mm)
	 * <br>上下左右邊界變數 - 0[cm]
	 * @return
	 * @deprecated 不建議使用，會與印表機吃的設定有誤差
	 */
	public static Paper createPaper(int widthMM , int heightMM){		
		return createPaperBase(
				(((widthMM/100))/2.54)*72,
				(((heightMM/100))/2.54)*72,
				0,0,0,0);
	}
	
	public static Paper createPaperBase(
			double pw , double ph, double t, double b, double l, double r){
		//可列印範圍的資料變數
		System.out.printf(" t:%s b:%s l:%s r:%s pw:%s ph:%s ",t,b,l,r,pw,ph);
        double x,y,w,h;
        //求出可列印範圍參數值
        //以整數計算才不會出現精算值誤差
        x=(int)((l/2.54)*72);
        y=(int)((t/2.54)*72);
        w=(int)(pw-((r/2.54)*72));
        h=ph-(int)((b/2.54)*72);

        //建立Paper，並設定紙張大小及列印範圍
        Paper paper = new Paper();
        paper.setSize(pw,ph);
        paper.setImageableArea(x,y,w,h);
        System.out.printf(" x:%s y:%s w:%s h:%s pw:%s ph:%s ",x,y,w,h,pw,ph);
        return paper;
	}
	
	//-----------------------------------------------------------------------//
	
	/**
	 * 呼叫javascript 的 alert('message');
	 */
	public static void jsAlert(AppletContext applet , String message){
		try {
			applet.showDocument(new URL("javascript:alert('"+message+"');"));
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * 呼叫javascript 的 window.close();
	 * @param applet
	 */
	public static void jsClose(AppletContext applet){
		try {
			applet.showDocument(new URL("javascript:window.close();"));
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}