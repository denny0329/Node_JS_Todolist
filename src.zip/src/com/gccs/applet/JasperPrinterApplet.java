/*
 * ============================================================================
 * GNU Lesser General Public License
 * ============================================================================
 *
 * JasperReports - Free Java report-generating library.
 * Copyright (C) 2001-2006 JasperSoft Corporation http://www.jaspersoft.com
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 * 
 * JasperSoft Corporation
 * 303 Second Street, Suite 450 North
 * San Francisco, CA 94107
 * http://www.jaspersoft.com
 */
package com.gccs.applet;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.util.List;

import javax.swing.JOptionPane;

import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperPrintManager;
import net.sf.jasperreports.engine.util.JRLoader;

/**
 * @author Teodor Danciu (teodord@users.sourceforge.net)
 * @version $Id: JasperPrinterApplet.java,v 1.1 2010/06/17 10:38:23 greglee Exp $
 */
public class JasperPrinterApplet extends javax.swing.JApplet {
	private static final long serialVersionUID = -6243916988324371533L;

	private URL url = null;
	private List<JasperPrint> jasperPrints = null;

	/** Creates new form AppletViewer */
	public JasperPrinterApplet() {
	}

	public void init() {
		String strUrl = getParameter("REPORT_URL");
		if (strUrl != null) {
			try {
				url = new URL(getCodeBase(), strUrl);
				printCard();
			} catch (Exception e) {
				StringWriter swriter = new StringWriter();
				PrintWriter pwriter = new PrintWriter(swriter);
				e.printStackTrace(pwriter);
				JOptionPane.showMessageDialog(this, swriter.toString());
			}
		} else {
			JOptionPane.showMessageDialog(this, "來源URL必須指定");
		}
	}

	private void printCard() {
		if (url != null) {
			if (jasperPrints == null) {
				try {
					jasperPrints = (List<JasperPrint>) JRLoader.loadObject(url);
				} catch (Exception e) {
					StringWriter swriter = new StringWriter();
					PrintWriter pwriter = new PrintWriter(swriter);
					e.printStackTrace(pwriter);
					JOptionPane.showMessageDialog(this, swriter.toString());
				}
			}

			if (jasperPrints != null && jasperPrints.size() > 0) {
				for(JasperPrint jasperPrint: jasperPrints) {
					
					final JasperPrint print = jasperPrint;
					
					Thread thread = new Thread(new Runnable() {
						public void run() {
							try {
								JasperPrintManager.printReport(print, true);
							} catch (Exception e) {
								StringWriter swriter = new StringWriter();
								PrintWriter pwriter = new PrintWriter(swriter);
								e.printStackTrace(pwriter);
								JOptionPane.showMessageDialog(null, swriter.toString());
							}
						}
					});
					
					thread.start();
				}
			} else {
				JOptionPane.showMessageDialog(this, "沒有資料");
			}
		} else {
			JOptionPane.showMessageDialog(this, "來源URL必須指定");
		}
	}
	
}
