package com.gccs.member.model;

import java.io.Serializable; 
import java.util.Date; 

public class MmMbPhoneReg implements Serializable {
	private static final long serialVersionUID = -6068700858983150519L;

	public MmMbPhoneReg(){
	}
	private String oid;
	private Long memberId;  
	private String status;
	private String mbPhoneReg;
	private String companyId;
	private String checkYn;
	private Date createTime;
	private Date regTime;
	private Date sendTime;
	private Date ecRegTime;
	private Date modifyTime;
	private String storeId;
	private String channelId;

	public String getOid() {
		return oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public Long getMemberId() {
		return memberId;
	}
	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMbPhoneReg() {
		return mbPhoneReg;
	}
	public void setMbPhoneReg(String mbPhoneReg) {
		this.mbPhoneReg = mbPhoneReg;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getCheckYn() {
		return checkYn;
	}
	public void setCheckYn(String checkYn) {
		this.checkYn = checkYn;
	}
	public Date getRegTime() {
		return regTime;
	}
	public void setRegTime(Date regTime) {
		this.regTime = regTime;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getSendTime() {
		return sendTime;
	}
	public void setSendTime(Date sendTime) {
		this.sendTime = sendTime;
	}
	public Date getEcRegTime() {
		return ecRegTime;
	}
	public void setEcRegTime(Date ecRegTime) {
		this.ecRegTime = ecRegTime;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public String getStoreId() {
		return storeId;
	}
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	
	
}
