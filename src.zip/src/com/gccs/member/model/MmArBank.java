package com.gccs.member.model;

import java.io.Serializable;

public class MmArBank implements Serializable {
	private static final long serialVersionUID = -7833023513825528035L;
	private String bankId;

	private String bankName;

	private String branchId;

	private String branchName;

	private String bkAccount;

	private String note;

	public String getBankId() {
		return bankId;
	}

	public void setBankId(String bankId) {
		this.bankId = bankId;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getBkAccount() {
		return bkAccount;
	}

	public void setBkAccount(String bkAccount) {
		this.bkAccount = bkAccount;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}
}