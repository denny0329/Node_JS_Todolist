package com.gccs.member.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class MmPosVipCulmMasterCal implements Serializable {
	private static final long serialVersionUID = -6068700858983150519L;

	public MmPosVipCulmMasterCal(){
	}
	 
	private String oid;

	/**會員編號**/
	private Long memberId;

	/**通路代號**/
	private String channelGroupId;

	/**成為VIP/SVIP時一般消費的累計金額**/
	private BigDecimal thisYearAmount;
	
	/**成為VIP/SVIP時一般消費的累計次數**/
	private BigDecimal thisYearQty;
	
	/**成為VIP/SVIP時tts消費的累計金額**/
	private BigDecimal thisYearAmountTts;
	
	/**成為VIP/SVIP時tts消費的累計次數**/
	private BigDecimal thisYearQtyTts;
	
	/**累計中的一般消費**/
	private BigDecimal nextYearAmount;
	
	/**累計中的一般消費次數**/
	private BigDecimal nextYearQty;
	
	/**累計中的tts消費**/
	private BigDecimal nextYearAmountTts;
	
	/**累計中的tts消費次數**/
	private BigDecimal nextYearQtyTts;
	
	/**累計區間起月**/
	private Date culmRangeStartDate;

	/**累計區間迄月**/
	private Date culmRangeEndDate; 

	/**用於連續達標, 記錄Vip起日**/
	private Date fitVipStartDate; 
	
	/**Vip起日**/
	private Date vipStartDate;

	/**Vip迄日**/
	private Date vipEndDate;
	
	/**記錄上次發生的Vip起日**/
	private Date preVipStartDate;

	/**記錄上次發生的Vip迄日**/
	private Date preVipEndDate;

	/**是否為VIP**/
	private String vipYn;

	/**用於記錄VIP_UPDATE JOB異動使用**/
	private String sasYn;

	/**修改時間**/
	private Date modifyTime;
	
	/**VIP狀態 A:VIP升等通知,B:VIP續卡,D:VIP退貨, N:預設**/
	private String vipType;
	
	/**一般消費累計次數最後修改時間*/
    private Date nextYearQtyMTime;

    /**tts消費累計次數最後修改時間*/
    private Date nextYearQtyTtsMTime;

	public String getOid() {
		return oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public Long getMemberId() {
		return memberId;
	}

	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}

	public String getChannelGroupId() {
		return channelGroupId;
	}

	public void setChannelGroupId(String channelGroupId) {
		this.channelGroupId = channelGroupId;
	}

	public BigDecimal getThisYearAmount() {
		return thisYearAmount;
	}

	public void setThisYearAmount(BigDecimal thisYearAmount) {
		this.thisYearAmount = thisYearAmount;
	}

	public BigDecimal getNextYearAmount() {
		return nextYearAmount;
	}

	public void setNextYearAmount(BigDecimal nextYearAmount) {
		this.nextYearAmount = nextYearAmount;
	}

	public String getVipYn() {
		return vipYn;
	}

	public void setVipYn(String vipYn) {
		this.vipYn = vipYn;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	} 

	public Date getFitVipStartDate() {
		return fitVipStartDate;
	}

	public void setFitVipStartDate(Date fitVipStartDate) {
		this.fitVipStartDate = fitVipStartDate;
	}

	public Date getVipStartDate() {
		return vipStartDate;
	}

	public void setVipStartDate(Date vipStartDate) {
		this.vipStartDate = vipStartDate;
	}

	public Date getVipEndDate() {
		return vipEndDate;
	}

	public void setVipEndDate(Date vipEndDate) {
		this.vipEndDate = vipEndDate;
	}

	public Date getPreVipStartDate() {
		return preVipStartDate;
	}

	public void setPreVipStartDate(Date preVipStartDate) {
		this.preVipStartDate = preVipStartDate;
	}

	public Date getPreVipEndDate() {
		return preVipEndDate;
	}

	public void setPreVipEndDate(Date preVipEndDate) {
		this.preVipEndDate = preVipEndDate;
	} 

	public String getSasYn() {
		return sasYn;
	}

	public void setSasYn(String sasYn) {
		this.sasYn = sasYn;
	}

	public String getVipType() {
		return vipType;
	}

	public void setVipType(String vipType) {
		this.vipType = vipType;
	}

	public BigDecimal getThisYearQty() {
		return thisYearQty;
	}

	public void setThisYearQty(BigDecimal thisYearQty) {
		this.thisYearQty = thisYearQty;
	}

	public BigDecimal getThisYearAmountTts() {
		return thisYearAmountTts;
	}

	public void setThisYearAmountTts(BigDecimal thisYearAmountTts) {
		this.thisYearAmountTts = thisYearAmountTts;
	}

	public BigDecimal getThisYearQtyTts() {
		return thisYearQtyTts;
	}

	public void setThisYearQtyTts(BigDecimal thisYearQtyTts) {
		this.thisYearQtyTts = thisYearQtyTts;
	}

	public BigDecimal getNextYearQty() {
		return nextYearQty;
	}

	public void setNextYearQty(BigDecimal nextYearQty) {
		this.nextYearQty = nextYearQty;
	}

	public BigDecimal getNextYearAmountTts() {
		return nextYearAmountTts;
	}

	public void setNextYearAmountTts(BigDecimal nextYearAmountTts) {
		this.nextYearAmountTts = nextYearAmountTts;
	}

	public BigDecimal getNextYearQtyTts() {
		return nextYearQtyTts;
	}

	public void setNextYearQtyTts(BigDecimal nextYearQtyTts) {
		this.nextYearQtyTts = nextYearQtyTts;
	}

	public Date getCulmRangeStartDate() {
		return culmRangeStartDate;
	}

	public void setCulmRangeStartDate(Date culmRangeStartDate) {
		this.culmRangeStartDate = culmRangeStartDate;
	}

	public Date getCulmRangeEndDate() {
		return culmRangeEndDate;
	}

	public void setCulmRangeEndDate(Date culmRangeEndDate) {
		this.culmRangeEndDate = culmRangeEndDate;
	}

	public Date getNextYearQtyMTime() {
		return nextYearQtyMTime;
	}

	public void setNextYearQtyMTime(Date nextYearQtyMTime) {
		this.nextYearQtyMTime = nextYearQtyMTime;
	}

	public Date getNextYearQtyTtsMTime() {
		return nextYearQtyTtsMTime;
	}

	public void setNextYearQtyTtsMTime(Date nextYearQtyTtsMTime) {
		this.nextYearQtyTtsMTime = nextYearQtyTtsMTime;
	}
}
