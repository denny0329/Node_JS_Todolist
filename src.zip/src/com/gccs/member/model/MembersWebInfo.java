package com.gccs.member.model;

import java.io.Serializable;
import java.util.Date;

/** 
 *  會員網站記錄
 */
public class MembersWebInfo implements Serializable {
	private static final long serialVersionUID = -6068700858983150519L;

	public MembersWebInfo(){
	}
	
	/**記錄 OID**/
	private String oid;
	/**會員號碼**/
	private Long memberId;
	/**登入ip**/
	private String ip; 
	/**登入店別**/
	private String storeId; 
	/**登入來源**/
	private String source; 
	/**登入日期**/
	private Date loginDate;
	/**型態**/
	private String type; 
	/**建立者**/
	private String creator; 
	/**建立時間**/
	private Date createTime;
	/**Store Site ID**/
	private String siteId;

	public String getOid() {
		return oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public Long getMemberId() {
		return memberId;
	}

	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public Date getLoginDate() {
		return loginDate;
	}

	public void setLoginDate(Date loginDate) {
		this.loginDate = loginDate;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}
}
