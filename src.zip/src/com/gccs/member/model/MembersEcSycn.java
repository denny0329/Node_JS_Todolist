package com.gccs.member.model;

import java.io.Serializable; 
import java.util.Date; 

/** 
 *  EC & CRM會員個資同步記錄檔
 */
public class MembersEcSycn implements Serializable {
	private static final long serialVersionUID = -6068700858983150519L;

	public MembersEcSycn(){
	}
	private String oid;
	private Long memberId;  
	private String result;
	private String errorMsg;
	private String webServiceName;
	private Date modifyTime;
	private Date createTime;
	private Long oldMemberId;

	public String getOid() {
		return oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public Long getMemberId() {
		return memberId;
	}
	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	} 
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getWebServiceName() {
		return webServiceName;
	}
	public void setWebServiceName(String webServiceName) {
		this.webServiceName = webServiceName;
	}
	public Long getOldMemberId() {
		return oldMemberId;
	}
	public void setOldMemberId(Long oldMemberId) {
		this.oldMemberId = oldMemberId;
	} 
	
}
