package com.gccs.member.model;

import java.io.Serializable;
import java.util.Date;

/** 會員行銷基本資料
 * @author Administrator
 */
public class MarketNotice implements Serializable {
	private static final long serialVersionUID = 3007617704788494570L;

	public MarketNotice(){
	}
	private String oid;
	private String memberOid;
	private String channelOid;
	private Integer recFlag;
	private Boolean dmFlag;
	private Boolean edmFlag;
	private String channelId;
	private Long memberId;

	/**最近一次消費日期**/
	private Date lastConsumerDate;
	/**變更行銷意願日期**/
	private Date changeMarketNoticeDate;
	/**公司代碼**/
	private String companyId;
	
	
	public Long getMemberId() {
		return memberId;
	}

	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}

	
	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	private Boolean telFlag;
	private Boolean mmsFlag;
	
	private Date createTime;
	
	private String creator;
	private String creatorName;
	
	private String modifier;
	private String modifierName;
	
	private Date modifyTime;

	public String getOid() {
		return oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	

	public String getMemberOid() {
		return memberOid;
	}

	public void setMemberOid(String memberOid) {
		this.memberOid = memberOid;
	}

	public String getChannelOid() {
		return channelOid;
	}

	public void setChannelOid(String channelOid) {
		this.channelOid = channelOid;
	}

	public Integer getRecFlag() {
		return recFlag;
	}

	public void setRecFlag(Integer recFlag) {
		this.recFlag = recFlag;
	}

	public Boolean getDmFlag() {
		return dmFlag;
	}

	public void setDmFlag(Boolean dmFlag) {
		this.dmFlag = dmFlag;
	}

	public Boolean getEdmFlag() {
		return edmFlag;
	}

	public void setEdmFlag(Boolean edmFlag) {
		this.edmFlag = edmFlag;
	}

	public Boolean getTelFlag() {
		return telFlag;
	}

	public void setTelFlag(Boolean telFlag) {
		this.telFlag = telFlag;
	}

	public Boolean getMmsFlag() {
		return mmsFlag;
	}

	public void setMmsFlag(Boolean mmsFlag) {
		this.mmsFlag = mmsFlag;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getModifierName() {
		return modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	
	public void copy(MarketNotice notice) {
		if(notice.getRecFlag() != null) {
			this.setRecFlag(notice.getRecFlag()) ;
		}
		if(notice.getEdmFlag() != null) {
			this.setEdmFlag(notice.getEdmFlag()) ;
		}
		if(notice.getMmsFlag() != null) {
			this.setMmsFlag(notice.getMmsFlag()) ;
		}
	}
	
	public boolean isUseful() {
		if((this.getDmFlag() != null && this.getDmFlag()) ||
				(this.getEdmFlag() != null && this.getEdmFlag()) ||
				(this.getMmsFlag() != null && this.getMmsFlag()) ||
				(this.getTelFlag() != null && this.getTelFlag())) {
		
			return true ;
		}
		return false ;
	}

	public Date getLastConsumerDate() {
		return lastConsumerDate;
	}

	public void setLastConsumerDate(Date lastConsumerDate) {
		this.lastConsumerDate = lastConsumerDate;
	}

	public Date getChangeMarketNoticeDate() {
		return changeMarketNoticeDate;
	}

	public void setChangeMarketNoticeDate(Date changeMarketNoticeDate) {
		this.changeMarketNoticeDate = changeMarketNoticeDate;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	
}
