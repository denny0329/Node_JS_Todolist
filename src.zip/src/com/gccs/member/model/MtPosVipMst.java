package com.gccs.member.model;

import java.io.Serializable;
import java.math.BigDecimal; 

public class MtPosVipMst implements Serializable{ 
	private static final long serialVersionUID = 1200082306360829025L;
	
	private String channelId;
	private String vipStartDate;
	private String vipEndDate;
	private BigDecimal thisYearAmount;
	private BigDecimal nextYearAmount;
	private String vipYn;
    private String culmStartDate;
    private String culmEndDate;
	private BigDecimal amount;
    
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getVipStartDate() {
		return vipStartDate;
	}
	public void setVipStartDate(String vipStartDate) {
		this.vipStartDate = vipStartDate;
	}
	public String getVipEndDate() {
		return vipEndDate;
	}
	public void setVipEndDate(String vipEndDate) {
		this.vipEndDate = vipEndDate;
	}
	public BigDecimal getThisYearAmount() {
		return thisYearAmount;
	}
	public void setThisYearAmount(BigDecimal thisYearAmount) {
		this.thisYearAmount = thisYearAmount;
	}
	public BigDecimal getNextYearAmount() {
		return nextYearAmount;
	}
	public void setNextYearAmount(BigDecimal nextYearAmount) {
		this.nextYearAmount = nextYearAmount;
	}
	public String getVipYn() {
		return vipYn;
	}
	public void setVipYn(String vipYn) {
		this.vipYn = vipYn;
	}
	public String getCulmStartDate() {
		return culmStartDate;
	}
	public void setCulmStartDate(String culmStartDate) {
		this.culmStartDate = culmStartDate;
	}
	public String getCulmEndDate() {
		return culmEndDate;
	}
	public void setCulmEndDate(String culmEndDate) {
		this.culmEndDate = culmEndDate;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
}
