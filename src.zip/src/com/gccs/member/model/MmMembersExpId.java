package com.gccs.member.model;

public class MmMembersExpId extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = 6928915032854465950L;

	private String personId;
	private String vipNo;
	
	public void setBoth(String str) {
		String[] list = str.split("#");
		this.setPersonId(list[0]);
		this.setVipNo(list[1]);    	
	}
	
	public String getPersonId() {
		return this.personId;
	}
	public void setPersonId(String personId) {
		this.personId = personId;
	}
	public String getVipNo() {
		return this.vipNo;
	}
	public void setVipNo(String vipNo) {
		this.vipNo = vipNo;
	}

}
