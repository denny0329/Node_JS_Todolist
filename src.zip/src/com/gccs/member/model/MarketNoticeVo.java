package com.gccs.member.model;

import java.io.Serializable;

/** 會員行銷基本資料
 * @author Administrator
 */
public class MarketNoticeVo implements Serializable {
	private static final long serialVersionUID = 8554403197720732073L;

	public MarketNoticeVo(){
	}

	private String oid ;
	private MarketNotice marketNotice;
	private String[] channel;
	private String confirm;
	private String channelId;
	private String channelName1;
	private String channelOid;
	private Integer addCulm = 0;
	private boolean showId = true;
	
	public String getOid() {
		return oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getChannelOid() {
		return channelOid;
	}
	public void setChannelOid(String channelOid) {
		this.channelOid = channelOid;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getChannelName1() {
		return channelName1;
	}
	public void setChannelName1(String channelName1) {
		this.channelName1 = channelName1;
	}
	public MarketNotice getMarketNotice() {
		return marketNotice;
	}
	public void setMarketNotice(MarketNotice marketNotice) {
		this.marketNotice = marketNotice;
	}
	public String[] getChannel() {
		return channel;
	}
	public void setChannel(String[] channel) {
		this.channel = channel;
	}
	public String getConfirm() {
		return confirm;
	}
	public void setConfirm(String confirm) {
		this.confirm = confirm;
	}
	public MarketNotice convert(MarketNotice bo) {
		if(this.getOid() == null) {
			bo = new MarketNotice() ;
		}
		bo.setChannelOid(this.getChannelOid());
		bo.setChannelId(this.getChannelId());
		//bo.setMemberId(memberId);
		bo.setDmFlag(Boolean.FALSE);
		bo.setEdmFlag(Boolean.FALSE);
		bo.setMmsFlag(Boolean.FALSE);
		bo.setTelFlag(Boolean.FALSE);
		if("0".equals(this.getConfirm())){
			//bo.setRecFlag(Boolean.FALSE);
		}else{
			//bo.setRecFlag(Boolean.TRUE);
			String[] status = this.getChannel();
			//0:型錄/DM   "1:電子郵件(EDM)"  "2:電話"  "3:簡訊"
			if(status != null) {
				for(String str:status){
					if("0".equals(str)){
						bo.setDmFlag(Boolean.TRUE);
					}else if("1".equals(str)){
						bo.setEdmFlag(Boolean.TRUE);
					}else if("2".equals(str)){
						bo.setTelFlag(Boolean.TRUE);
					}else if("3".equals(str)){
						bo.setMmsFlag(Boolean.TRUE);
					}
				}
			}
		}
		return bo ;
	}
	public Integer getAddCulm() {
		return addCulm;
	}
	public void setAddCulm(Integer addCulm) {
		this.addCulm = addCulm;
	}
	public boolean isShowId() {
		return showId;
	}
	public void setShowId(boolean showId) {
		this.showId = showId;
	}
	
}
