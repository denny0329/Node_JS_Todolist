package com.gccs.member.model;

import java.io.Serializable;
import java.util.Date;

/** 
 *  各店ego站ip
 */
public class MmStoreEgoIp implements Serializable {
	private static final long serialVersionUID = -6068700858983150519L;

	public MmStoreEgoIp(){
	}
	
	/**記錄 OID**/
	private String oid;
	/**Channel**/
	private String channelId; 
	/**店代號**/
	private String storeId; 
	/**IP**/
	private String ip; 
	/**啟用 0-啟用 1-停用 **/
	private String active; 
	/**建立者**/
	private String creator; 
	/**建立時間**/
	private Date createTime;
	/**修改者**/
	private String modifier;
	/**修改時間**/
	private Date modifyTime;
	/**Store Site ID**/
	private String siteId;
	

	public String getOid() {
		return oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public String getSiteId() {
		return siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	} 
}
