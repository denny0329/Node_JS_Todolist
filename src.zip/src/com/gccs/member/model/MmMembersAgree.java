package com.gccs.member.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class MmMembersAgree implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 623340833427130850L;

	public MmMembersAgree () {
	}
	
	private String companyId;

    private BigDecimal memberId;

    private String agreeYn;

    private Date createTime;

    private String creator;

    private String modifier;

    private Date modifyTime;

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public BigDecimal getMemberId() {
		return memberId;
	}

	public void setMemberId(BigDecimal memberId) {
		this.memberId = memberId;
	}

	public String getAgreeYn() {
		return agreeYn;
	}

	public void setAgreeYn(String agreeYn) {
		this.agreeYn = agreeYn;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
}
