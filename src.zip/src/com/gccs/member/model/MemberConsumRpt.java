package com.gccs.member.model;

import java.math.BigDecimal;

/**
 * 會員消費記錄報表 (list for 年份,消費次數,總金額,會員群組)
 */
public class MemberConsumRpt {
	//年份
	private String guiDate; 
	//消費次數
	private Integer cntGui;
	//總金額
	private BigDecimal sumTol;
	//會員群組
	private String levelExplain;
	public String getGuiDate() {
		return guiDate;
	}
	public void setGuiDate(String guiDate) {
		this.guiDate = guiDate;
	}
	public Integer getCntGui() {
		return cntGui;
	}
	public void setCntGui(Integer cntGui) {
		this.cntGui = cntGui;
	}
	public BigDecimal getSumTol() {
		return sumTol;
	}
	public void setSumTol(BigDecimal sumTol) {
		this.sumTol = sumTol;
	}
	public String getLevelExplain() {
		return levelExplain;
	}
	public void setLevelExplain(String levelExplain) {
		this.levelExplain = levelExplain;
	}
}
