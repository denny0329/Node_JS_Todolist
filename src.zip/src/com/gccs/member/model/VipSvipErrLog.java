package com.gccs.member.model;

import java.util.Date;

public class VipSvipErrLog {
	
	private long memberId;
	private String reason;
	private Date transDate;
	private String channelGroupId;
	private String guiNos;
	private String saleSource;
	private String orderId;
	private String oriVipMstData;
	private String oriVipMonthlyAmtData;
	private String oriVipMonthlyQtyData;
	
	
	public String getChannelGroupId() {
		return channelGroupId;
	}
	public void setChannelGroupId(String channelGroupId) {
		this.channelGroupId = channelGroupId;
	}
	public Date getTransDate() {
		return transDate;
	}
	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getSaleSource() {
		return saleSource;
	}
	public void setSaleSource(String saleSource) {
		this.saleSource = saleSource;
	}
	public long getMemberId() {
		return memberId;
	}
	public void setMemberId(long memberId) {
		this.memberId = memberId;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getGuiNos() {
		return guiNos;
	}
	public void setGuiNos(String guiNos) {
		this.guiNos = guiNos;
	}
	public String getOriVipMstData() {
		return oriVipMstData;
	}
	public void setOriVipMstData(String oriVipMstData) {
		this.oriVipMstData = oriVipMstData;
	}
	public String getOriVipMonthlyAmtData() {
		return oriVipMonthlyAmtData;
	}
	public void setOriVipMonthlyAmtData(String oriVipMonthlyAmtData) {
		this.oriVipMonthlyAmtData = oriVipMonthlyAmtData;
	}
	public String getOriVipMonthlyQtyData() {
		return oriVipMonthlyQtyData;
	}
	public void setOriVipMonthlyQtyData(String oriVipMonthlyQtyData) {
		this.oriVipMonthlyQtyData = oriVipMonthlyQtyData;
	}


}
