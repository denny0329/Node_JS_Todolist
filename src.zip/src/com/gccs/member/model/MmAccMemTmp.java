package com.gccs.member.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class MmAccMemTmp implements Serializable {
	private static final long serialVersionUID = -7833023513825528035L;

	private String accTmpOid;

	private BigDecimal seq;

	private String name;

	private String cellPhone;

	private String email;

	private String creator;

	private String creatorName;

	private Date createTime;

	private String modifier;

	private String modifierName;

	private Date modifyTime;

	public String getAccTmpOid() {
		return accTmpOid;
	}

	public void setAccTmpOid(String accTmpOid) {
		this.accTmpOid = accTmpOid;
	}

	public BigDecimal getSeq() {
		return seq;
	}

	public void setSeq(BigDecimal seq) {
		this.seq = seq;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCellPhone() {
		return cellPhone;
	}

	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getModifierName() {
		return modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

}