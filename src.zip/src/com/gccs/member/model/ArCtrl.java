package com.gccs.member.model;

import java.math.BigDecimal;
import java.util.Date;

/**
 * mmArCtrl entity. @author MyEclipse Persistence Tools
 */

public class ArCtrl implements java.io.Serializable {
	private static final long serialVersionUID = -8298439646220486878L;

	private String oid;
	private String accountId;
	private String vipNo;
	private String guiNos;
	private Date transDate;
	private BigDecimal guiAmt;
	private BigDecimal writeOffAmt;
	private Integer arFlag;

	// Constructors

	/** default constructor */
	public ArCtrl() {
	}

	/** full constructor */
	public ArCtrl(String accountId, String vipNo, String guiNos,
			Date transDate, BigDecimal guiAmt, BigDecimal writeOffAmt, Integer arFlag) {
		this.accountId = accountId;
		this.vipNo = vipNo;
		this.guiNos = guiNos;
		this.transDate = transDate;
		this.guiAmt = guiAmt;
		this.writeOffAmt = writeOffAmt;
		this.arFlag = arFlag;
	}

	// Property accessors

	public String getOid() {
		return this.oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public String getAccountId() {
		return this.accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getVipNo() {
		return this.vipNo;
	}

	public void setVipNo(String vipNo) {
		this.vipNo = vipNo;
	}

	public String getGuiNos() {
		return this.guiNos;
	}

	public void setGuiNos(String guiNos) {
		this.guiNos = guiNos;
	}

	public Date getTransDate() {
		return this.transDate;
	}

	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}

	public BigDecimal getGuiAmt() {
		return this.guiAmt;
	}

	public void setGuiAmt(BigDecimal guiAmt) {
		this.guiAmt = guiAmt;
	}

	public BigDecimal getWriteOffAmt() {
		return this.writeOffAmt;
	}

	public void setWriteOffAmt(BigDecimal writeOffAmt) {
		this.writeOffAmt = writeOffAmt;
	}

	public Integer getArFlag() {
		return this.arFlag;
	}

	public void setArFlag(Integer arFlag) {
		this.arFlag = arFlag;
	}

}