package com.gccs.member.model;

import java.util.Date;
import java.util.List;

import com.gccs.util.web.SelectItem;

public class MmThresholdMst extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = 7487425037134175770L;

	private String thresholdId;

	private String oid;

	private Date startDate;

	private Date endDate;

	private String thresholdName;

	private String status;

	private String creator;

	private String creatorName;

	private Date createTime;

	private String modifier;

	private String modifierName;

	private Date modifyTime;

	private String companyId;

	private List<MmThresholdDtl> thresholdDtlList;
	
	private List<MmCardDisc> cardDiscList;

	public String getThresholdId() {
		return thresholdId;
	}

	public void setThresholdId(String thresholdId) {
		this.thresholdId = thresholdId;
	}

	public String getOid() {
		return oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getThresholdName() {
		return thresholdName;
	}

	public void setThresholdName(String thresholdName) {
		this.thresholdName = thresholdName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getModifierName() {
		return modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public List<MmThresholdDtl> getThresholdDtlList() {
		return thresholdDtlList;
	}

	public void setThresholdDtlList(List<MmThresholdDtl> thresholdDtlList) {
		this.thresholdDtlList = thresholdDtlList;
	}

	public List<MmCardDisc> getCardDiscList() {
		return cardDiscList;
	}

	public void setCardDiscList(List<MmCardDisc> cardDiscList) {
		this.cardDiscList = cardDiscList;
	}
	
	public String getStatusTxt() {		
		return (this.status == null) ? "" : SelectItem.MmCommisionStatisMap.get(this.status.toString());
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}	
}
