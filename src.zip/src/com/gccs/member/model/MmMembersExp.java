package com.gccs.member.model;

import java.util.Date;

public class MmMembersExp extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = -8537172934585236658L;

	private MmMembersExpId id;
	private String name;
	private Integer status;
	private Integer birthdayYy;
	private Integer birthdayMm;
	private Integer birthdayDd;
	private Integer sex;
	private String cantactTel;
	private String faxNo;
	private String cellPhone;
	private String cantactAddr2;
	private String cantactAddr5;
	private Integer bonusTotal;
	private Date bonusUpdatime;

	
	public MmMembersExpId getId() {
		return this.id;
	}
	public void setId(MmMembersExpId id) {
		this.id = id;
	}
	public String getName() {
		return this.name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getStatus() {
		return this.status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getBirthdayYy() {
		return this.birthdayYy;
	}
	public void setBirthdayYy(Integer birthdayYy) {
		this.birthdayYy = birthdayYy;
	}
	public Integer getBirthdayMm() {
		return this.birthdayMm;
	}
	public void setBirthdayMm(Integer birthdayMm) {
		this.birthdayMm = birthdayMm;
	}
	public Integer getBirthdayDd() {
		return this.birthdayDd;
	}
	public void setBirthdayDd(Integer birthdayDd) {
		this.birthdayDd = birthdayDd;
	}
	public Integer getSex() {
		return this.sex;
	}
	public void setSex(Integer sex) {
		this.sex = sex;
	}
	public String getCantactTel() {
		return this.cantactTel;
	}
	public void setCantactTel(String cantactTel) {
		this.cantactTel = cantactTel;
	}
	public String getFaxNo() {
		return this.faxNo;
	}
	public void setFaxNo(String faxNo) {
		this.faxNo = faxNo;
	}
	public String getCellPhone() {
		return this.cellPhone;
	}
	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}
	public String getCantactAddr2() {
		return this.cantactAddr2;
	}
	public void setCantactAddr2(String cantactAddr2) {
		this.cantactAddr2 = cantactAddr2;
	}
	public String getCantactAddr5() {
		return this.cantactAddr5;
	}
	public void setCantactAddr5(String cantactAddr5) {
		this.cantactAddr5 = cantactAddr5;
	}
	public Integer getBonusTotal() {
		return this.bonusTotal;
	}
	public void setBonusTotal(Integer bonusTotal) {
		this.bonusTotal = bonusTotal;
	}
	public Date getBonusUpdatime() {
		return this.bonusUpdatime;
	}
	public void setBonusUpdatime(Date bonusUpdatime) {
		this.bonusUpdatime = bonusUpdatime;
	}

}
