package com.gccs.member.model;

import java.io.Serializable;
import java.util.Date;

/** 
 *  虛擬平台維護作業-
 */
public class MmWebMasterConfig implements Serializable {
	
	private static final long serialVersionUID = 397051527606916272L;

	public MmWebMasterConfig(){
	}
	
	/**記錄 OID**/
	private String oid;
	/**通路**/
	private String webMasterId;
	/**型態**/
	private String webType; 
	/**服務ID**/
	private String webId; 
	/**服務名稱**/
	private String webName; 
	/**建立者**/
	private String creator; 
	/**建立日**/
	private Date createTime;
	/**最後修改人員ID**/
	private String modifier;
	/**最後修改日**/
	private Date modifyTime;

	public String getOid() {
		return oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getWebMasterId() {
		return webMasterId;
	}
	public void setWebMasterId(String webMasterId) {
		this.webMasterId = webMasterId;
	}
	public String getWebType() {
		return webType;
	}
	public void setWebType(String webType) {
		this.webType = webType;
	}
	public String getWebId() {
		return webId;
	}
	public void setWebId(String webId) {
		this.webId = webId;
	}
	public String getWebName() {
		return webName;
	}
	public void setWebName(String webName) {
		this.webName = webName;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getModifier() {
		return modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	} 
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	

	
}
