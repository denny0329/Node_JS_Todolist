package com.gccs.member.model;
import java.util.LinkedList;
import java.util.List;

public class WebInfoMainReq {
	public static final String STATUS_SUCC = "SUCCESS";
	public static final String STATUS_FAIL = "<span style='color:red'>Fail</span>";
	
	//當天日期
	private String date;
	//檔案筆數
	private Integer count;
	//起始時間
	private String startDate;
	//結束時間
	private String endDate;
	//CRM筆數
	private Integer crmCount;
	
	private List<WebInfoReq> reqList = new LinkedList<WebInfoReq>();
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public List<WebInfoReq> getReqList() {
		return reqList;
	}
	public void setReqList(List<WebInfoReq> reqList) {
		this.reqList = reqList;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getStatus() {
		if(count.equals(crmCount))
			return STATUS_SUCC;
		
		return STATUS_FAIL;
	}
	public Integer getCrmCount() {
		return crmCount;
	}
	public void setCrmCount(Integer crmCount) {
		this.crmCount = crmCount;
	}
}
