package com.gccs.member.model;

import java.io.Serializable;
import java.util.Date;

public class MtPosVipExcludeSku implements Serializable {
	private static final long serialVersionUID = -6068700858983150519L;

	public MtPosVipExcludeSku(){
	}
	 
	private String oid;
 
	/**商品編號**/
	private String sku;

	/**商品分類2**/
	private String subDeptId;

	/**商品分類3**/
	private String classId;

	/**商品分類4**/
	private String subClassId;

	/**建檔人員代碼**/
	private String creator;

	/**建檔人員姓名**/
	private String creatorName;

	/**建檔日期**/
	private Date createTime;

	/**最後修改人員代碼**/
	private String modifier;

	/**最後修改人員姓名**/
	private String modifierName;

	/**修改日期**/
	private Date modifierTime;

	public String getOid() {
		return oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getSubDeptId() {
		return subDeptId;
	}

	public void setSubDeptId(String subDeptId) {
		this.subDeptId = subDeptId;
	}

	public String getClassId() {
		return classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	public String getSubClassId() {
		return subClassId;
	}

	public void setSubClassId(String subClassId) {
		this.subClassId = subClassId;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getModifierName() {
		return modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public Date getModifierTime() {
		return modifierTime;
	}

	public void setModifierTime(Date modifierTime) {
		this.modifierTime = modifierTime;
	}
}
