package com.gccs.member.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Date;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import com.bnq.util.AppContext;
import com.gccs.marketing.model.DiscountSku;
import com.gccs.marketing.model.vo.DiscountVo;
import com.gccs.marketing.service.MarketingService;

/** 會員查詢條件
 * @author Administrator
 */
public class Account implements Serializable {
	private static final long serialVersionUID = -7833023513825528035L;

	public Account(){
	}
	private String oid;
	private String accountId;
	private String hqOid;
	private String hqId;
	private Integer status;
	private String statusDesc;
	private Integer accType;
	private String reason;
	private String guiNo;
	private String companyName1;
	private String companyName2;
	private String comAddr1;
	private String comAddr2;
	private String comAddr3;
	private String comAddr4;
	private String comAddr5;
	private String billAddr1;
	private String billAddr2;
	private String billAddr3;
	private String billAddr4;
	private String billAddr5;
	private String comTel;
	private String comExt;
	private String comFax;
	private String comContact;
	private String comType0;
	private String comType;
	private Integer guiPrint;
	private Integer namePrint;
	private String discCardOid;
	//private String discCardDesc;
	private Integer payType;

	private Integer applyCard = new Integer(0);
	private Integer approveCard = new Integer(0);
	private String payDay;
	private String overdue;
	private BigDecimal arAmount;
	private Integer purchaseForm;
	private Integer purchaseTo;
	private Integer restraint;

	private Date promiseForm;
	private Date promiseTo;
	private Integer payIn;
	private Integer qouteYn;
	private Integer returnYn;

	private Integer accStatus;

	private String approveId;
	private String approveName;
	private Date approveTime;
	private String othName;
	private String accStatuwDesc;
	private Integer othSex;
	private String othRelationship;
	private String othCantactTel;
	private String othCantactExt;
	private String othCellPhone;
	private String othEmail;
	private String creator;
	private String creatorName;
	private Date createTime;
	private String modifier;
	private String modifierName;

	private Date modifyTime;
	private BigDecimal creditAmt;
	private BigDecimal limtAmt;
	private String comConDept;
	private String othNameDept;
	private Integer bonusTotal;
	private Integer thisYearTot;
	private Integer lastYearTot;
	private String saletypeId;

	//頁面用arAmount
	private String creditAmtDesc;
	private String limtAmtDesc;
	private String arAmountDesc;
	private String oldDiscCardOid;
	private String personIdDesc;


	//折扣變動所使用欄位(20100419新增)
	private BigDecimal variableFlag;
	private BigDecimal purMonth;
	private BigDecimal purAmt;
	private Date variableDate;
	private BigDecimal discDate;
	private String varDiscOid;
	private String orgDiscOid;

	private Integer businessType;

	private Integer relationship;//是否為關系人
	private String sapCustNo;//SAP客戶帳號
	private Integer taxClass;//稅別
	private String currency;//幣別
	private String saleDistrict;//銷售地區
	private String custPricingProc;//客戶定價程序
	private Boolean uploadSap; //上傳SAP
	private Boolean uploadSapMsg; //上傳SAP狀態
	
	private String sapMessage;
	private String keyinSapCustNo;
	
	private BigDecimal openSalesValue;
	private String companyId;//公司代碼
	private String comInCharge;
    private String comEmail;

    private Date comEmailRegDate;

    private String comBillEmail;

    private String mgmUser;

    private String mgmAccount;

    private Date saleAmtStartDate;

    private Date saleAmtEndDate;

    private BigDecimal saleAmt;

    private Date lastConsumeDate;

    private String commAccId;

    private String commBkId;

    private String commBkName;

    private BigDecimal lastCreditAmt;

    private Date lastPromiseFrom;

    private Date lastPromiseTo;

    private String thresholdId;

    private String isArmy;

    private String commBkBranch;

    private String commBkBranchName;

    private String lastApproveId;

    private String arMail;

    private String inforMail;

    private String arBkId;

    private String arBranchId;

    private String arAccId;
    
    private String commAccName;
	/**
	 * 上傳SAP狀態<br>
	 * Null、0=上傳失敗、1=重傳成功。
	 * @return
	 */
	public Boolean getUploadSapMsg() {
		return uploadSapMsg;
	}
	/**
	 * 上傳SAP狀態<br>
	 * Null、0=上傳失敗、1=重傳成功。
	 * @param uploadSapMsg
	 */
	public void setUploadSapMsg(Boolean uploadSapMsg) {
		this.uploadSapMsg = uploadSapMsg;
	}
	/**
	 * 上傳SAP<br>
	 * 是否勾選上傳SAP 0=不勾選、1=勾選
	 * @return
	 */
	public Boolean getUploadSap() {
		return uploadSap;
	}
	/**
	 * 上傳SAP<br>
	 * 是否勾選上傳SAP 0=不勾選、1=勾選
	 * @param uploadSap
	 */
	public void setUploadSap(Boolean uploadSap) {
		this.uploadSap = uploadSap;
	}
	/**
	 * SAP客戶帳號
	 * @return
	 */
	public String getSapCustNo() {
		return sapCustNo;
	}
	/**
	 * SAP客戶帳號
	 * @param sapCustNo
	 */
	public void setSapCustNo(String sapCustNo) {
		this.sapCustNo = sapCustNo;
	}
	/**
	 * 稅分類<br>
	 * FROM BS_CODE.CODE_CLASS＝’TAXCLASS’0(零稅),1(應稅),2(外銷)
	 * @return
	 */
	public Integer getTaxClass() {
		return taxClass;
	}
	/**
	 * 稅分類<br>
	 * FROM BS_CODE.CODE_CLASS＝’TAXCLASS’0(零稅),1(應稅),2(外銷)
	 * @param taxClass
	 */
	public void setTaxClass(Integer taxClass) {
		this.taxClass = taxClass;
	}
	/**
	 * 幣別(currency)<br>
	 * FROM BS_CODE.CODE_CLASS=’CUR’
	 * @return
	 */
	public String getCurrency() {
		return currency;
	}
	/**
	 * 幣別(currency)<br>
	 * FROM BS_CODE.CODE_CLASS=’CUR’
	 * @param currency
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getSaleDistrict() {
		return saleDistrict;
	}

	public void setSaleDistrict(String saleDistrict) {
		this.saleDistrict = saleDistrict;
	}

	public String getCustPricingProc() {
		return custPricingProc;
	}

	public void setCustPricingProc(String custPricingProc) {
		this.custPricingProc = custPricingProc;
	}
	/**
	 * 是否為關係人<br>
	 * 0-否 1-是
	 * @return
	 */
	public Integer getRelationship() {
		if(relationship==null) {
			if(this.getSapCustNo()!=null&&!this.getSapCustNo().trim().equals(""))
				relationship = new Integer(1);
			else
				relationship = new Integer(0);
		}
		return relationship;
	}
	/**
	 * 是否為關係人<br>
	 * 0-否 1-是
	 * @param relationship
	 */
	public void setRelationship(Integer relationship) {
		this.relationship = relationship;
	}

	public BigDecimal getVariableFlag() {
		return variableFlag;
	}

	public void setVariableFlag(BigDecimal variableFlag) {
		this.variableFlag = variableFlag;
	}

	public BigDecimal getPurMonth() {
		return purMonth;
	}

	public void setPurMonth(BigDecimal purMonth) {
		this.purMonth = purMonth;
	}

	public BigDecimal getPurAmt() {
		return purAmt;
	}

	public void setPurAmt(BigDecimal purAmt) {
		this.purAmt = purAmt;
	}

	public Date getVariableDate() {
		return variableDate;
	}

	public void setVariableDate(Date variableDate) {
		this.variableDate = variableDate;
	}

	public BigDecimal getDiscDate() {
		return discDate;
	}

	public void setDiscDate(BigDecimal discDate) {
		this.discDate = discDate;
	}

	public String getVarDiscOid() {
		return varDiscOid;
	}

	public void setVarDiscOid(String varDiscOid) {
		this.varDiscOid = varDiscOid;
	}

	public String getOrgDiscOid() {
		return orgDiscOid;
	}

	public void setOrgDiscOid(String orgDiscOid) {
		this.orgDiscOid = orgDiscOid;
	}

	public Integer getBusinessType() {
		return businessType;
	}

	public void setBusinessType(Integer businessType) {
		this.businessType = businessType;
	}

	public String getPersonIdDesc() {
		personIdDesc = guiNo;

		if(guiNo!=null && !"".equals(guiNo) && guiNo.length()==10 ){
			personIdDesc = 	guiNo.substring(0, 2);
			personIdDesc = personIdDesc+"●●●●●";
			personIdDesc = personIdDesc+guiNo.substring(7, guiNo.length());

		}
		return personIdDesc;
	}

	public void setPersonIdDesc(String personIdDesc) {
		this.personIdDesc = personIdDesc;
	}

	public Integer getBonusTotal() {
		return bonusTotal;
	}

	public void setBonusTotal(Integer bonusTotal) {
		this.bonusTotal = bonusTotal;
	}
	
	public Integer getThisYearTot() {
		return thisYearTot;
	}
	public void setThisYearTot(Integer thisYearTot) {
		this.thisYearTot = thisYearTot;
	}
	public Integer getLastYearTot() {
		return lastYearTot;
	}
	public void setLastYearTot(Integer lastYearTot) {
		this.lastYearTot = lastYearTot;
	}

	public String getOldDiscCardOid() {
		return oldDiscCardOid;
	}

	public void setOldDiscCardOid(String oldDiscCardOid) {
		this.oldDiscCardOid = oldDiscCardOid;
	}

	public String getArAmountDesc() {
//		if(arAmount!=null && arAmount.intValue()!=0){
//			NumberFormat formatter = new DecimalFormat("0,000");
//			return formatter.format(arAmount);
//		}
		BigDecimal total = new BigDecimal("0");
		if(arAmount!=null)
			total = total.add(arAmount);
		if(openSalesValue!=null)
			total = total.add(openSalesValue);
		NumberFormat formatter = new DecimalFormat("#,###");
		return formatter.format(total);
	}

	public void setArAmountDesc(String arAmountDesc) {
		this.arAmountDesc = arAmountDesc;
	}

	public String getCreditAmtDesc() {
		if(creditAmt!=null && creditAmt.intValue()!=0){
			NumberFormat formatter = new DecimalFormat("#,###");


			return formatter.format(creditAmt);
		}
		return "0";
	}

	public void setCreditAmtDesc(String creditAmtDesc) {
		this.creditAmtDesc = creditAmtDesc;
	}

	public String getLimtAmtDesc() {
		if(limtAmt!=null && limtAmt.intValue()!=0){
			NumberFormat formatter = new DecimalFormat("#,###");
			return formatter.format(limtAmt);
		}
		return "0";
	}

	public void setLimtAmtDesc(String limtAmtDesc) {
		this.limtAmtDesc = limtAmtDesc;
	}
	private Set<DiscountSku> restrictionSku ;
	/**
	 * 信用額度
	 * @return
	 */
	public BigDecimal getCreditAmt() {
		return creditAmt;
	}
	/**
	 * 信用額度
	 * @param creditAmt
	 */
	public void setCreditAmt(BigDecimal creditAmt) {
		this.creditAmt = creditAmt;
	}

	public String getOthNameDept() {
		return othNameDept;
	}

	public void setOthNameDept(String othNameDept) {
		this.othNameDept = othNameDept;
	}

	public String getComConDept() {
		return comConDept;
	}

	public void setComConDept(String comConDept) {
		this.comConDept = comConDept;
	}

	public BigDecimal getLimtAmt() {
		return limtAmt;
	}

	public void setLimtAmt(BigDecimal limtAmt) {
		this.limtAmt = limtAmt;
	}

	public String getAccStatuwDesc() {
		if(this.accStatus==null || "".equals(this.accStatus)){
			accStatuwDesc = "正常";
		}else if(1==accStatus.intValue()){
			accStatuwDesc = "正常";
		}else if(2==accStatus.intValue()){
			accStatuwDesc = "跳票";
		}else if(3==accStatus.intValue()){
			accStatuwDesc = "應收帳款逾期";
		}else if(4==accStatus.intValue()){
			accStatuwDesc = "結速營業或倒閉";
		}else if(9==accStatus.intValue()){
			accStatuwDesc = "停用";
		}
		return accStatuwDesc;
	}

	public void setAccStatuwDesc(String accStatuwDesc) {
		this.accStatuwDesc = accStatuwDesc;
	}

	public String getStatusDesc() {
		if(this.status==null || "".equals(this.status)){
			statusDesc = "申請中";
		}else if(1==status.intValue()){
			statusDesc = "申請中";
		}else if(2==status.intValue()){
			statusDesc = "審核中";
		}else if(3==status.intValue()){
			statusDesc = "核發";
		}else if(9==status.intValue()){
			statusDesc = "刪除";
		}else if(4==status.intValue()){
			statusDesc = "限制採購";
		}else if(0==status.intValue()){
			statusDesc = "停用";
		}
		return statusDesc;
	}

	public String getDiscCardDesc() {
		String rtv = null;
		if(StringUtils.isNotBlank(discCardOid)) {
			try {
				MarketingService mtService = (MarketingService)AppContext.getBean("mtService");
				DiscountVo discount = mtService.getDiscountVoByOid(discCardOid);
				if(discount != null)
					rtv = discount.getDiscountCardName();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		return rtv;
	}

	/*
	public void setDiscCardDesc(String discCardDesc) {
		this.discCardDesc = discCardDesc;
	}
	*/

	/*
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}
	*/

	public String getOthName() {
		return othName;
	}

	public void setOthName(String othName) {
		this.othName = othName;
	}


	public String getOthRelationship() {
		return othRelationship;
	}

	public void setOthRelationship(String othRelationship) {
		this.othRelationship = othRelationship;
	}

	public String getOthCantactTel() {
		return othCantactTel;
	}

	public void setOthCantactTel(String othCantactTel) {
		this.othCantactTel = othCantactTel;
	}

	public String getOthCantactExt() {
		return othCantactExt;
	}

	public void setOthCantactExt(String othCantactExt) {
		this.othCantactExt = othCantactExt;
	}

	public String getOthCellPhone() {
		return othCellPhone;
	}

	public void setOthCellPhone(String othCellPhone) {
		this.othCellPhone = othCellPhone;
	}

	public String getOthEmail() {
		return othEmail;
	}

	public void setOthEmail(String othEmail) {
		this.othEmail = othEmail;
	}
	/**
	 * 商務總部 ID
	 * @return
	 */
	public String getHqId() {
		return hqId;
	}
	/**
	 * 商務總部 ID
	 * @param hqId
	 */
	public void setHqId(String hqId) {
		this.hqId = hqId;
	}

	public String getOid() {
		return oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}
	/**
	 * 商務帳號
	 * @return
	 */
	public String getAccountId() {
		return accountId;
	}
	/**
	 * 商務帳號
	 * @param accountId
	 */
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	/**
	 * 商務總部 OID
	 * @return
	 */
	public String getHqOid() {
		if(StringUtils.trimToNull(this.hqId) == null)
			hqOid = null;
		return hqOid;
	}
	/**
	 * 商務總部 OID
	 * @param hqOid
	 */
	public void setHqOid(String hqOid) {
		this.hqOid = hqOid;
	}
	/**
	 * 統一編號/身份證號
	 * @return
	 */
	public String getGuiNo() {
		return guiNo;
	}
	/**
	 * 統一編號/身份證號
	 * @param guiNo
	 */
	public void setGuiNo(String guiNo) {
		this.guiNo = guiNo;
	}
	/**
	 * 公司/付款單位名稱
	 * @return
	 */
	public String getCompanyName1() {
		return companyName1;
	}
	/**
	 * 公司/付款單位名稱
	 * @param companyName1
	 */
	public void setCompanyName1(String companyName1) {
		this.companyName1 = companyName1;
	}
	/**
	 * 公司/付款單位全名
	 * @return
	 */
	public String getCompanyName2() {
		return companyName2;
	}
	/**
	 * 公司/付款單位全名
	 * @param companyName2
	 */
	public void setCompanyName2(String companyName2) {
		this.companyName2 = companyName2;
	}

	public String getComAddr1() {
		return comAddr1;
	}

	public void setComAddr1(String comAddr1) {
		this.comAddr1 = comAddr1;
	}

	public String getComAddr2() {
		return comAddr2;
	}

	public void setComAddr2(String comAddr2) {
		this.comAddr2 = comAddr2;
	}

	public String getComAddr3() {
		return comAddr3;
	}

	public void setComAddr3(String comAddr3) {
		this.comAddr3 = comAddr3;
	}

	public String getComAddr4() {
		return comAddr4;
	}

	public void setComAddr4(String comAddr4) {
		this.comAddr4 = comAddr4;
	}

	public String getComAddr5() {
		return comAddr5;
	}

	public void setComAddr5(String comAddr5) {
		this.comAddr5 = comAddr5;
	}

	public String getBillAddr1() {
		return billAddr1;
	}

	public void setBillAddr1(String billAddr1) {
		this.billAddr1 = billAddr1;
	}

	public String getBillAddr2() {
		return billAddr2;
	}

	public void setBillAddr2(String billAddr2) {
		this.billAddr2 = billAddr2;
	}

	public String getBillAddr3() {
		return billAddr3;
	}

	public void setBillAddr3(String billAddr3) {
		this.billAddr3 = billAddr3;
	}

	public String getBillAddr4() {
		return billAddr4;
	}

	public void setBillAddr4(String billAddr4) {
		this.billAddr4 = billAddr4;
	}

	public String getBillAddr5() {
		return billAddr5;
	}

	public void setBillAddr5(String billAddr5) {
		this.billAddr5 = billAddr5;
	}

	public String getComTel() {
		return comTel;
	}

	public void setComTel(String comTel) {
		this.comTel = comTel;
	}

	public String getComExt() {
		return comExt;
	}

	public void setComExt(String comExt) {
		this.comExt = comExt;
	}

	public String getComFax() {
		return comFax;
	}

	public void setComFax(String comFax) {
		this.comFax = comFax;
	}

	public String getComContact() {
		return comContact;
	}

	public void setComContact(String comContact) {
		this.comContact = comContact;
	}

	public String getComType() {
		return comType;
	}

	public void setComType(String comType) {
		this.comType = comType;
	}
	
	public String getDiscCardOid() {
		return discCardOid;
	}

	public void setDiscCardOid(String discCardOid) {
		this.discCardOid = discCardOid;
	}

	public Integer getApplyCard() {
		return applyCard;
	}

	public void setApplyCard(Integer applyCard) {
		this.applyCard = applyCard;
	}

	public Integer getApproveCard() {
		return approveCard;
	}

	public void setApproveCard(Integer approveCard) {
		this.approveCard = approveCard;
	}
	/**
	 * 月結天數<br>
	 * FROM BS_CODE.CODE_CLASS＝’PD’
	 * @return
	 */
	public String getPayDay() {
		return payDay;
	}
	/**
	 * 月結天數<br>
	 * FROM BS_CODE.CODE_CLASS＝’PD’
	 * @param payDay
	 */
	public void setPayDay(String payDay) {
		this.payDay = payDay;
	}
	/**
	 * OVERDUE CONTROL[信用管理:風險種類]<br>
	 * FROM BS_CODE.CODE_CLASS＝’OD’
	 * @return
	 */
	public String getOverdue() {
		return overdue;
	}
	/**
	 * OVERDUE CONTROL[信用管理:風險種類]<br>
	 * FROM BS_CODE.CODE_CLASS＝’OD’
	 * @param overdue
	 */
	public void setOverdue(String overdue) {
		this.overdue = overdue;
	}

	public BigDecimal getArAmount() {
		return arAmount;
	}

	public void setArAmount(BigDecimal arAmount) {
		this.arAmount = arAmount;
	}
	/**
	 * 採購日FROM
	 * @return
	 */
	public Integer getPurchaseForm() {
		return purchaseForm;
	}
	/**
	 * 採購日FROM
	 * @param purchaseForm
	 */
	public void setPurchaseForm(Integer purchaseForm) {
		this.purchaseForm = purchaseForm;
	}
	/**
	 * 採購日TO
	 * @return
	 */
	public Integer getPurchaseTo() {
		return purchaseTo;
	}
	/**
	 * 採購日TO
	 * @param purchaseTo
	 */
	public void setPurchaseTo(Integer purchaseTo) {
		this.purchaseTo = purchaseTo;
	}
	/**
	 * 採購商品限制<br>
	 * 0-否  1-是若有,<br>則必須要建立採購的商品清單
	 * @return
	 */
	public Integer getRestraint() {
		return restraint;
	}
	/**
	 * 採購商品限制<br>
	 * 0-否  1-是若有,<br>則必須要建立採購的商品清單
	 * @param restraint
	 */
	public void setRestraint(Integer restraint) {
		this.restraint = restraint;
	}
	/**
	 * 保證函期間FROM 
	 * @return
	 */
	public Date getPromiseForm() {
		return promiseForm;
	}
	/**
	 * 保證函期間FROM 
	 * @param promiseForm
	 */
	public void setPromiseForm(Date promiseForm) {
		this.promiseForm = promiseForm;
	}
	/**
	 * 保證函期間 TO
	 * @return
	 */
	public Date getPromiseTo() {
		return promiseTo;
	}
	/**
	 * 保證函期間 TO
	 * @param promiseTo
	 */
	public void setPromiseTo(Date promiseTo) {
		this.promiseTo = promiseTo;
	}

	/**
	 * 狀態<br>
	 * 0-停用 1-申請中 2-審核中 3-核發 4-限制採購 9-刪除
	 * @return
	 */
	public Integer getStatus() {
		return status;
	}
	
	/**
	 * 狀態
	 * @param status
	 */
	public void setStatus(Integer status) {
		this.status = status;
	}
	/**
	 * 會員類別<br>
	 * 0-一般商務會員 1-月結商務會員 2-專業商務會員
	 * @return
	 */
	public Integer getAccType() {
		return accType;
	}
	/**
	 * 會員類別<br>
	 * 0-一般商務會員 1-月結商務會員 2-專業商務會員
	 * @param accType
	 */
	public void setAccType(Integer accType) {
		this.accType = accType;
	}
	/**
	 * 買受人及統編列印<br>
	 * 0-否  1-是
	 * @return
	 */
	public Integer getGuiPrint() {
		return guiPrint;
	}
	/**
	 * 買受人及統編列印<br>
	 * 0-否  1-是
	 * @param guiPrint
	 */
	public void setGuiPrint(Integer guiPrint) {
		this.guiPrint = guiPrint;
	}
	/**
	 * 持卡人姓名列印<br>
	 * 0-否  1-是
	 * @return
	 */
	public Integer getNamePrint() {
		return namePrint;
	}
	/**
	 * 持卡人姓名列印<br>
	 * 0-否  1-是
	 * @param namePrint
	 */
	public void setNamePrint(Integer namePrint) {
		this.namePrint = namePrint;
	}
	/**
	 * 付款方式<br>
	 * 0-現結 1-月結 2-現結+月結
	 * @return
	 */
	public Integer getPayType() {
		return payType;
	}
	/**
	 * 付款方式<br>
	 * 0-現結 1-月結 2-現結+月結
	 * @param payType
	 */
	public void setPayType(Integer payType) {
		this.payType = payType;
	}
	/**
	 * 付款限制<br>
	 * 0-否  1-是
	 * @return
	 */
	public Integer getPayIn() {
		return payIn;
	}
	/**
	 * 付款限制<br>
	 * 0-否  1-是
	 * @param payIn
	 */
	public void setPayIn(Integer payIn) {
		this.payIn = payIn;
	}
	/**
	 * 需報價單採購<br>
	 * 0-否  1-是
	 * @return
	 */
	public Integer getQouteYn() {
		return qouteYn;
	}
	/**
	 * 需報價單採購<br>
	 * 0-否  1-是
	 * @param qouteYn
	 */
	public void setQouteYn(Integer qouteYn) {
		this.qouteYn = qouteYn;
	}
	/**
	 * 允許退貨<br>
	 * 0-否  1-是
	 * @return
	 */
	public Integer getReturnYn() {
		return returnYn;
	}
	/**
	 * 允許退貨<br>
	 * 0-否  1-是
	 * @param returnYn
	 */
	public void setReturnYn(Integer returnYn) {
		this.returnYn = returnYn;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
	/**
	 * 帳戶狀態<br>
	 * 1-正常 2-跳票 3-應收帳款逾期 4-結束營業或倒閉 9-停用
	 * @return
	 */
	public Integer getAccStatus() {
		return accStatus;
	}
	/**
	 * 帳戶狀態<br>
	 * 1-正常 2-跳票 3-應收帳款逾期 4-結束營業或倒閉 9-停用
	 * @param accStatus
	 */
	public void setAccStatus(Integer accStatus) {
		this.accStatus = accStatus;
	}

	public Integer getOthSex() {
		return othSex;
	}

	public void setOthSex(Integer othSex) {
		this.othSex = othSex;
	}

	public String getApproveId() {
		return approveId;
	}

	public void setApproveId(String approveId) {
		this.approveId = approveId;
	}

	public String getApproveName() {
		return approveName;
	}

	public void setApproveName(String approveName) {
		this.approveName = approveName;
	}

	public Date getApproveTime() {
		return approveTime;
	}

	public void setApproveTime(Date approveTime) {
		this.approveTime = approveTime;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getModifierName() {
		return modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public Set<DiscountSku> getRestrictionSku() {
		return restrictionSku;
	}

	public void setRestrictionSku(Set<DiscountSku> restrictionSku) {
		this.restrictionSku = restrictionSku;
	}

	public String getSaletypeId() {
		return saletypeId;
	}

	public void setSaletypeId(String saletypeId) {
		this.saletypeId = saletypeId;
	}

	public String getComType0() {
		return comType0;
	}

	public void setComType0(String comType0) {
		this.comType0 = comType0;
	}
	/**
	 * 暫存SAP回傳訊息
	 * @return
	 */
	public String getSapMessage() {
		return sapMessage;
	}
	/**
	 * 暫存SAP回傳訊息
	 * @param sapMessage
	 */
	public void setSapMessage(String sapMessage) {
		this.sapMessage = sapMessage;
	}
	/**
	 * 授權頁面keyInSap碼
	 * @return
	 */
	public String getKeyinSapCustNo() {
		return keyinSapCustNo;
	}
	/**
	 * 授權頁面keyInSap碼
	 * @param keyinSapCustNo
	 */
	public void setKeyinSapCustNo(String keyinSapCustNo) {
		this.keyinSapCustNo = keyinSapCustNo;
	}
	public BigDecimal getOpenSalesValue() {
		return openSalesValue;
	}
	public void setOpenSalesValue(BigDecimal openSalesValue) {
		this.openSalesValue = openSalesValue;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getComInCharge() {
        return comInCharge;
    }
    public void setComInCharge(String comInCharge) {
        this.comInCharge = comInCharge;
    }
	public String getComEmail() {
		return comEmail;
	}
	public void setComEmail(String comEmail) {
		this.comEmail = comEmail;
	}
	public Date getComEmailRegDate() {
		return comEmailRegDate;
	}
	public void setComEmailRegDate(Date comEmailRegDate) {
		this.comEmailRegDate = comEmailRegDate;
	}
	public String getComBillEmail() {
		return comBillEmail;
	}
	public void setComBillEmail(String comBillEmail) {
		this.comBillEmail = comBillEmail;
	}
	public String getMgmUser() {
		return mgmUser;
	}
	public void setMgmUser(String mgmUser) {
		this.mgmUser = mgmUser;
	}
	public String getMgmAccount() {
		return mgmAccount;
	}
	public void setMgmAccount(String mgmAccount) {
		this.mgmAccount = mgmAccount;
	}
	public Date getSaleAmtStartDate() {
		return saleAmtStartDate;
	}
	public void setSaleAmtStartDate(Date saleAmtStartDate) {
		this.saleAmtStartDate = saleAmtStartDate;
	}
	public Date getSaleAmtEndDate() {
		return saleAmtEndDate;
	}
	public void setSaleAmtEndDate(Date saleAmtEndDate) {
		this.saleAmtEndDate = saleAmtEndDate;
	}
	public BigDecimal getSaleAmt() {
		return saleAmt;
	}
	public void setSaleAmt(BigDecimal saleAmt) {
		this.saleAmt = saleAmt;
	}
	public Date getLastConsumeDate() {
		return lastConsumeDate;
	}
	public void setLastConsumeDate(Date lastConsumeDate) {
		this.lastConsumeDate = lastConsumeDate;
	}
	public String getCommAccId() {
		return commAccId;
	}
	public void setCommAccId(String commAccId) {
		this.commAccId = commAccId;
	}
	public String getCommBkId() {
		return commBkId;
	}
	public void setCommBkId(String commBkId) {
		this.commBkId = commBkId;
	}
	public String getCommBkName() {
		return commBkName;
	}
	public void setCommBkName(String commBkName) {
		this.commBkName = commBkName;
	}
	public BigDecimal getLastCreditAmt() {
		return lastCreditAmt;
	}
	public void setLastCreditAmt(BigDecimal lastCreditAmt) {
		this.lastCreditAmt = lastCreditAmt;
	}
	public Date getLastPromiseFrom() {
		return lastPromiseFrom;
	}
	public void setLastPromiseFrom(Date lastPromiseFrom) {
		this.lastPromiseFrom = lastPromiseFrom;
	}
	public Date getLastPromiseTo() {
		return lastPromiseTo;
	}
	public void setLastPromiseTo(Date lastPromiseTo) {
		this.lastPromiseTo = lastPromiseTo;
	}
	public String getThresholdId() {
		return thresholdId;
	}
	public void setThresholdId(String thresholdId) {
		this.thresholdId = thresholdId;
	}
	public String getIsArmy() {
		return isArmy;
	}
	public void setIsArmy(String isArmy) {
		this.isArmy = isArmy;
	}
	public String getCommBkBranch() {
		return commBkBranch;
	}
	public void setCommBkBranch(String commBkBranch) {
		this.commBkBranch = commBkBranch;
	}
	public String getCommBkBranchName() {
		return commBkBranchName;
	}
	public void setCommBkBranchName(String commBkBranchName) {
		this.commBkBranchName = commBkBranchName;
	}
	public String getLastApproveId() {
		return lastApproveId;
	}
	public void setLastApproveId(String lastApproveId) {
		this.lastApproveId = lastApproveId;
	}
	public String getArMail() {
		return arMail;
	}
	public void setArMail(String arMail) {
		this.arMail = arMail;
	}
	public String getInforMail() {
		return inforMail;
	}
	public void setInforMail(String inforMail) {
		this.inforMail = inforMail;
	}
	public String getArBkId() {
		return arBkId;
	}
	public void setArBkId(String arBkId) {
		this.arBkId = arBkId;
	}
	public String getArBranchId() {
		return arBranchId;
	}
	public void setArBranchId(String arBranchId) {
		this.arBranchId = arBranchId;
	}
	public String getArAccId() {
		return arAccId;
	}
	public void setArAccId(String arAccId) {
		this.arAccId = arAccId;
	}
	public String getCommAccName() {
		return commAccName;
	}
	public void setCommAccName(String commAccName) {
		this.commAccName = commAccName;
	}
	
	
}