package com.gccs.member.model;

import java.util.Date;

public class MmCommAmt extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = -5959334399013900814L;

	private String oid;
	private String activityOid;
	private Integer amountF;
	private Integer amountT;
	private Double commRate;
	private Date createTime;
	private String creator;
	private String creatorName;
	private String modifier;
	private String modifierName;
	private Date modifyTime;
	

	public MmCommAmt() {
	}	
	
	public MmCommAmt(Integer amountF,Integer amountT,Double commRate) {
		this.amountF = amountF;
		this.amountT = amountT;
		this.commRate = commRate;
	}	

	public String getOid() {
		return this.oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public String getActivityOid() {
		return this.activityOid;
	}

	public void setActivityOid(String activityOid) {
		this.activityOid = activityOid;
	}

	public Integer getAmountF() {
		return this.amountF;
	}

	public void setAmountF(Integer amountF) {
		this.amountF = amountF;
	}

	public Integer getAmountT() {
		return this.amountT;
	}

	public void setAmountT(Integer amountT) {
		this.amountT = amountT;
	}

	public Double getCommRate() {
		return this.commRate;
	}

	public void setCommRate(Double commRate) {
		this.commRate = commRate;
	}

	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreator() {
		return this.creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreatorName() {
		return this.creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public String getModifier() {
		return this.modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getModifierName() {
		return this.modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public Date getModifyTime() {
		return this.modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

}
