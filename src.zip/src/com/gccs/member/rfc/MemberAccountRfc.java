package com.gccs.member.rfc;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.cache.BsCodeDefinition;
import com.gccs.member.model.Account;
import com.gccs.member.model.MmArBank;
import com.gccs.member.service.MemberService;
import com.gccs.member.util.SapAdapterUtil;
import com.gccs.util.cache.BsCompanyDefinition;
import com.rfep.nm.util.BaseSapRfc;

/**
 * 會員帳號傳SAP
 * @author san
 *
 */
public class MemberAccountRfc extends BaseSapRfc{
	
	private Logger log = LogManager.getLogger(MemberAccountRfc.class) ;
	
	private MemberService memberService;
	/**
	 * 建立
	 */
    public static int CREATE = 1;
    /**
     * 修改
     */
    public static int MODIFY = 2;
    
    //-------------------------------------------------------------//
    
    /**
     * 客戶群組一
     */
    private final static String CUSTOMER_KVGR1 = "KVGR1";
    /**
     * 客戶或供應商處的發貨人(我方)帳號
     */
    private final static String CUSTOMER_EIKTO = "EIKTO";
    /**
     * 客戶科目群組
     */
    private final static String CUSTOMER_KTOKD = "KTOKD";
    /**
     * 客戶編號1
     */
    private final static String CUSTOMER_KUNNR = "KUNNR";
    /**
     * 公司代碼
     */
    private final static String CUSTOMER_BUKRS = "BUKRS";
    /**
     * 銷售組織
     */
    private final static String CUSTOMER_VKORG = "VKORG";
    /**
     * 配銷通路
     */
    private final static String CUSTOMER_VTWEG = "VTWEG";
    /**
     * 部門
     */
    private final static String CUSTOMER_SPART = "SPART";
    /**
     * 標題
     */
    private final static String CUSTOMER_ANRED = "ANRED";
    /**
     * 名稱1
     */
    private final static String CUSTOMER_NAME1 = "NAME1";
    /**
     * 名稱2
     */
    private final static String CUSTOMER_NAME2 = "NAME2";
    /**
     * 名稱3
     */
    private final static String CUSTOMER_NAME3 = "NAME3";
    /**
     * 名稱4
     */
    private final static String CUSTOMER_NAME4 = "NAME4";
    /**
     * 搜尋條件1
     */
    private final static String CUSTOMER_SORT1 = "SORT1";
    /**
     * 街道
     */
    private final static String CUSTOMER_STREET = "STREET";
    /**
     * 街道2
     */
    private final static String CUSTOMER_STR_SUPPL1 = "STR_SUPPL1";
    /**
     * 街道3
     */
    private final static String CUSTOMER_STR_SUPPL2 = "STR_SUPPL2";
    /**
     * 街道4
     */
    private final static String CUSTOMER_STR_SUPPL3 = "STR_SUPPL3";
    /**
     * 街道5
     */
    private final static String CUSTOMER_LOCATION = "LOCATION";
    /**
     * 城市郵遞區號
     */
    private final static String CUSTOMER_POST_CODE1 = "POST_CODE1";
    /**
     * 城市
     */
    private final static String CUSTOMER_CITY1 = "CITY1";
    /**
     * 國家碼
     */
    private final static String CUSTOMER_COUNTRY = "COUNTRY";
    /**
     * 地區(州,省,縣)
     */
    private final static String CUSTOMER_REGION = "REGION";
    /**
     * 業務夥伴:語言(ISO)
     */
    private final static String CUSTOMER_LANGU = "LANGU";
    /**
     * 第一個電話號碼:號碼
     */
    private final static String CUSTOMER_TEL_NUMBER = "TEL_NUMBER";
    /**
     * 第一個電話號碼:分機
     */
    private final static String CUSTOMER_TEL_EXTENS = "TEL_EXTENS";
    /**
     * 第二個電話號碼
     */
    private final static String CUSTOMER_TELF2 = "TELF2";
    /**
     * 第一個傳真號碼:電話號碼
     */
    private final static String CUSTOMER_FAX_NUMBER = "FAX_NUMBER";
    /**
     * 第一個傳真號碼:分機
     */
    private final static String CUSTOMER_FAX_EXTENS = "FAX_EXTENS";
    /**
     * 電子翻件地址
     */
    private final static String CUSTOMER_SMTP_ADDR = "SMTP_ADDR";
    /**
     * 加值稅登記號碼
     */
    private final static String CUSTOMER_STCEG = "STCEG";
    /**
     * 付款條件碼
     */
    private final static String CUSTOMER_ZTERM = "ZTERM";
    /**
     * 銷售地區
     */
    private final static String CUSTOMER_BZIRK = "BZIRK";
    /**
     * 幣別碼
     */
    private final static String CUSTOMER_WAERS = "WAERS";
    /**
     * 定價程序指派到該客戶
     */
    private final static String CUSTOMER_KALKS = "KALKS";
    /**
     * 付款條件碼
     */
    private final static String CUSTOMER_ZTERM1 = "ZTERM1";
    /**
     * 這個客戶的科目指派指組<br>
     * 是關係人傳[01], 其它傳[02]
     */
    private final static String CUSTOMER_KTGRD = "KTGRD";
    /**
     * 客戶稅分類
     */
    private final static String CUSTOMER_TAXKD = "TAXKD";
    /**
     * 信用控制範圍
     */
    private final static String CUSTOMER_KKBER = "KKBER";
    /**
     * 客戶信用額度
     */
    private final static String CUSTOMER_KLIMKS = "KLIMK";
    /**
     * 信用管理:風險種類
     */
    private final static String CUSTOMER_CTLPC = "CTLPC";
    
    //-------------------------------------------------------------//
    
    /**
     * 客戶群組一
     */
    private final static String PNRIN_KVGR1 = "KVGR1";
    /**
     * 客戶或供應商處的發貨人(我方)帳號
     */
    private final static String PNRIN_EIKTO = "EIKTO";
    /**
     * 聯絡人職責<br>
     * Z1-業務連絡人, Z2-帳務連絡人 
     */
    private final static String PNRIN_PAFKT = "PAFKT";
    /**
     * 名稱1
     */
    private final static String PNRIN_NAME1 = "NAME1";
    /**
     * 合作夥伴語言
     */
    private final static String PNRIN_PARLA = "PARLA";
    /**
     * 第一個電話號碼:分機
     */
    private final static String PNRIN_TEL_NUMBER = "TEL_NUMBER";
    /**
     * 第一個電話號碼:分機
     */
    private final static String PNRIN_TEL_EXTENS = "TEL_EXTENS";
    /**
     * 第二個電話號碼
     */
    private final static String PNRIN_TELF2 = "TELF2";
    /**
     * 第一個傳真號碼:電話號碼
     */
    private final static String PNRIN_FAX_NUMBER = "FAX_NUMBER";
    /**
     * 第一個傳真號碼:分機
     */
    private final static String PNRIN_FAX_EXTENS = "FAX_EXTENS";
    /**
     * 電子翻件地址
     */
    private final static String PNRIN_SMTP_ADDR = "SMTP_ADDR";
    
    //-------------------------------------------------------------//
    /**
     * 修改-客戶主檔
     */
    private final static String IT_CUSINC = "IT_CUSINC";
    /**
     * 修改-客戶聯絡人
     */
    private final static String IT_PNRIN = "IT_PNRIN";
    /**
     * 修改-客戶主檔回傳訊息
     */
    private final static String IT_CUSRET = "IT_CUSRET";
    /**
     * 修改-客戶聯絡人回傳訊息
     */
    private final static String IT_PNRRET = "IT_PNRRET";
    /**
     * 新增-客戶主檔
     */
    private final static String IT_CUSINS = "IT_CUSINS";
    /**
     * 新增-客戶聯絡人
     */
    private final static String IT_PNRINS = "IT_PNRINS";
    /**
     * 新增-客戶主檔回傳訊息
     */
    private final static String IT_CUSRETS = "IT_CUSRETS";
    /**
     * 新增-客戶聯絡人回傳訊息
     */
    private final static String IT_PNRRETS = "IT_PNRRETS";
    
    // 客戶銀行匯款帳號
    private final static String IT_BNKINS = "IT_BNKINS";
    
    // 客戶銀行匯款帳號_修改
    private final static String IT_BNKIN = "IT_BNKIN";
    
    // 客戶銀行匯款帳號回傳訊息
    private final static String IT_BNKRETS = "IT_BNKRETS";
    
    // 客戶銀行匯款帳號回傳訊息_修改
    private final static String IT_BNKRET = "IT_BNKRET";
    
    //-------------------------------------------------------------//
    
    public boolean execute(Account account){
    	boolean uploadSap = false;
    	boolean sapExist = false;
    	if( account.getSapCustNo() != null && account.getSapCustNo().length() > 2 )
    		sapExist = true;
    	
    	String executefunction = null;
    	String executeTableCUS = null;
    	String executeTablePNR = null;
    	String executeTableBNKINS = null;
    	String returnTableCUS = null;
    	String returnTablePNR = null;
    	String returnTableBNKINS = null;
    	Set<String> getTables = new HashSet<String>();
    	if(sapExist) {
    		executefunction = "ZCHANGE_CUSTOMER";
    		executeTableCUS = IT_CUSINC;
    		executeTablePNR = IT_PNRIN;
    		executeTableBNKINS = IT_BNKIN;
    		returnTableCUS = IT_CUSRET;
    		returnTablePNR = IT_PNRRET;
    		returnTableBNKINS = IT_BNKRET;
    	}else{ 
    		executefunction = "ZCREATE_CUSTOMER";
    		executeTableCUS = IT_CUSINS;
    		executeTablePNR = IT_PNRINS;
    		executeTableBNKINS = IT_BNKINS;
    		returnTableCUS = IT_CUSRETS;
    		returnTablePNR = IT_PNRRETS;
    		returnTableBNKINS = IT_BNKRETS;
    	}
    	getTables.add(returnTableCUS);
    	getTables.add(returnTablePNR);
    	getTables.add(returnTableBNKINS);
    	try{
    		
    		log.info(" sapExist : " + sapExist + (sapExist?" 修改":" 新增")+" ["+executefunction+"]");
    		
    		log.info(" execute TableCUS : " + executeTableCUS);
    		log.info(" return TableCUS : " + returnTableCUS);
    		
    		log.info(" execute TablePNR : " + executeTablePNR);
    		log.info(" return TablePNR : " + returnTablePNR);
    		log.info(" return TableBNKINS : " + executeTableBNKINS);
    		log.info(" return TableBNKINS : " + returnTableBNKINS);
	    	// 帶入資料
			Map<String, List<Map<String, Object>>> tables = new HashMap<String, List<Map<String, Object>>>();
			List<Map<String, Object>> datelist = new ArrayList<Map<String, Object>>();
			
			//設定上傳資料-客戶主檔
			Map<String, Object> dataMapCus = new HashMap<String, Object>();
			dataMapCus.put(CUSTOMER_KVGR1, "001");
			dataMapCus.put(CUSTOMER_EIKTO,account.getAccountId());
	        if(!sapExist) {
	        	//C02:一般客戶, C07:關係人, C09:一次性客戶
	        	if( account.getRelationship() == 1 )
	        		dataMapCus.put(CUSTOMER_KTOKD, "C07");
	        	else
	        		dataMapCus.put(CUSTOMER_KTOKD, "C02");
	        }
			if( sapExist ){
				dataMapCus.put(CUSTOMER_KUNNR,account.getSapCustNo());
			}else{
				if( account.getRelationship() == 1 )
					dataMapCus.put(CUSTOMER_KUNNR,account.getKeyinSapCustNo());
				else
					dataMapCus.put(CUSTOMER_KUNNR,"");
			}
			String companyId = BsCompanyDefinition.getCompanyId();
	        dataMapCus.put(CUSTOMER_BUKRS,companyId);
	        dataMapCus.put(CUSTOMER_VKORG,companyId);
	        dataMapCus.put(CUSTOMER_VTWEG,"99") ;
	        dataMapCus.put(CUSTOMER_SPART,"99") ;
	        dataMapCus.put(CUSTOMER_ANRED,"公司") ;
	        
	        String [] companyNames = SapAdapterUtil.getCompanyName(account.getCompanyName2()); //2012.6.20 Brian Han : 改抓公司全名
	        dataMapCus.put(CUSTOMER_NAME1,companyNames[0]) ;
	        dataMapCus.put(CUSTOMER_NAME2,companyNames[1]) ;
	        dataMapCus.put(CUSTOMER_NAME3,companyNames[2]) ;
	        dataMapCus.put(CUSTOMER_NAME4,companyNames[3]) ;
	        if( account.getCompanyName1().length() <= 10 )
	        	dataMapCus.put(CUSTOMER_SORT1,account.getCompanyName1()); 
	        else
	        	dataMapCus.put(CUSTOMER_SORT1,account.getCompanyName1().substring(0, 10));
	        
	        String [] addr = SapAdapterUtil.getAddr(account.getComAddr5());
	        dataMapCus.put(CUSTOMER_STREET,addr[0]);
	        dataMapCus.put(CUSTOMER_STR_SUPPL1,addr[1]);
	        dataMapCus.put(CUSTOMER_STR_SUPPL2,addr[2]);
	        dataMapCus.put(CUSTOMER_STR_SUPPL3,addr[3]);
	        dataMapCus.put(CUSTOMER_LOCATION,addr[4]);
	        
	        if( account.getComAddr1().equals("002") ){//外國
		        dataMapCus.put(CUSTOMER_POST_CODE1,account.getComAddr2()) ;
		        dataMapCus.put(CUSTOMER_CITY1, "");
		        dataMapCus.put(CUSTOMER_COUNTRY, account.getComAddr3()); 
		        String[] addr4 = account.getComAddr4().split(" ");
		        if( addr4.length >=2 )
		        	dataMapCus.put(CUSTOMER_REGION, addr4[1]);
		        else
		        	dataMapCus.put(CUSTOMER_REGION, "");
	        }else{//本國
	        	dataMapCus.put(CUSTOMER_POST_CODE1,account.getComAddr2()) ;
		        dataMapCus.put(CUSTOMER_CITY1, 
		        		BsCodeDefinition.getBsCodeExplain("AD",account.getComAddr3()) + 
		        		BsCodeDefinition.getBsCodeExplain("AD",account.getComAddr4())
		        		); //轉成名稱 -城市+地區 ex:台北市中山區
 		        dataMapCus.put(CUSTOMER_COUNTRY, "TW"); 
		        dataMapCus.put(CUSTOMER_REGION, account.getSaleDistrict());
	        }
	        dataMapCus.put(CUSTOMER_LANGU, "ZF");
	        
	        dataMapCus.put(CUSTOMER_TEL_NUMBER, account.getComTel());
	        dataMapCus.put(CUSTOMER_TEL_EXTENS, account.getComExt());
	        dataMapCus.put(CUSTOMER_TELF2, "");
	        dataMapCus.put(CUSTOMER_FAX_NUMBER, account.getComFax());
	        dataMapCus.put(CUSTOMER_FAX_EXTENS, "");
	        
	        dataMapCus.put(CUSTOMER_SMTP_ADDR, "");
	        dataMapCus.put(CUSTOMER_STCEG, account.getGuiNo());
	        dataMapCus.put(CUSTOMER_ZTERM, account.getPayDay());
	        dataMapCus.put(CUSTOMER_BZIRK, account.getSaleDistrict());
	        dataMapCus.put(CUSTOMER_WAERS, account.getCurrency());
	        
	        dataMapCus.put(CUSTOMER_KALKS, account.getCustPricingProc());
	        dataMapCus.put(CUSTOMER_ZTERM1, account.getPayDay());
	        if( account.getRelationship() == 1 )
	        	dataMapCus.put(CUSTOMER_KTGRD, "01");
	        else
	        	dataMapCus.put(CUSTOMER_KTGRD, "02");
	        dataMapCus.put(CUSTOMER_TAXKD, account.getTaxClass());
	        dataMapCus.put(CUSTOMER_KKBER, companyId);
	        dataMapCus.put(CUSTOMER_KLIMKS, account.getCreditAmt());
	        dataMapCus.put(CUSTOMER_CTLPC, account.getOverdue());
	        
	        log.info(" dataMapCus : " + dataMapCus);
	        datelist.add(dataMapCus);
	        tables.put(executeTableCUS, datelist);
	        
			//設定上傳資料-客戶聯絡人
	        datelist = new ArrayList<Map<String, Object>>();
			Map<String, Object> dataMapPnrZ1 = new HashMap<String, Object>();
			//Z1-業務連絡人
			dataMapPnrZ1.put(PNRIN_KVGR1, "001");
			dataMapPnrZ1.put(PNRIN_EIKTO, account.getAccountId());
			dataMapPnrZ1.put(PNRIN_PAFKT, "Z1");
			dataMapPnrZ1.put(PNRIN_NAME1, account.getOthName());
			dataMapPnrZ1.put(PNRIN_PARLA, "ZF");
			dataMapPnrZ1.put(PNRIN_TEL_NUMBER, account.getOthCantactTel());
			dataMapPnrZ1.put(PNRIN_TEL_EXTENS, account.getOthCantactExt());
			dataMapPnrZ1.put(PNRIN_TELF2, account.getOthCellPhone());
			dataMapPnrZ1.put(PNRIN_FAX_NUMBER, "");
			dataMapPnrZ1.put(PNRIN_FAX_EXTENS, "");
			dataMapPnrZ1.put(PNRIN_SMTP_ADDR, account.getOthEmail());
			
			log.info(" dataMapPnrZ1 : " + dataMapPnrZ1);
			datelist.add(dataMapPnrZ1);
			
			//Z2-帳務連絡人
			Map<String, Object> dataMapPnrZ2 = new HashMap<String, Object>();
			dataMapPnrZ2.put(PNRIN_KVGR1, "001");
			dataMapPnrZ2.put(PNRIN_EIKTO, account.getAccountId());
			dataMapPnrZ2.put(PNRIN_PAFKT, "Z2");
			dataMapPnrZ2.put(PNRIN_NAME1, account.getComContact());
			dataMapPnrZ2.put(PNRIN_PARLA, "ZF");
			dataMapPnrZ2.put(PNRIN_TEL_NUMBER, account.getComTel());
			dataMapPnrZ2.put(PNRIN_TEL_EXTENS, account.getComExt());
			dataMapPnrZ2.put(PNRIN_TELF2, account.getComFax());
			dataMapPnrZ2.put(PNRIN_FAX_NUMBER, "");
			dataMapPnrZ2.put(PNRIN_FAX_EXTENS, "");
			dataMapPnrZ2.put(PNRIN_SMTP_ADDR, "");
			
			log.info(" dataMapPnrZ2 : " + dataMapPnrZ2);
			datelist.add(dataMapPnrZ2);
			tables.put(executeTablePNR, datelist);
			
			// 客戶銀行匯款帳號
			datelist = new ArrayList<>();
			MmArBank arBank = new MmArBank();
			String arBkId = account.getArBkId();
			String arBranchId = account.getArBranchId();
			String arAccId = account.getArAccId();
			arBank.setBankId(arBkId);
			arBank.setBranchId(arBranchId);
			arBank.setBkAccount(arAccId);
			List<MmArBank> bankIdList = memberService.qyeryMmArBank(arBank);
			
			Map<String, Object> dataMapBNKINS = new HashMap<>();
			MmArBank bank = bankIdList.get(0);
			dataMapBNKINS.put(StaticBankins.CRMNO, account.getAccountId());
			dataMapBNKINS.put(StaticBankins.EB_MAIL, account.getComBillEmail());
			dataMapBNKINS.put(StaticBankins.ACCNAME, bank.getBankName() + " " + bank.getBranchName());
			dataMapBNKINS.put(StaticBankins.ELCFLAG, account.getArMail());
			dataMapBNKINS.put(StaticBankins.BANK, arBkId);
			dataMapBNKINS.put(StaticBankins.BRANCH, arBranchId);
			dataMapBNKINS.put(StaticBankins.ACCNO, arAccId);

			log.info(" dataMapBNKINS : " + dataMapBNKINS);
			datelist.add(dataMapBNKINS);
			tables.put(executeTableBNKINS, datelist);

			// 送到SAP 處理 todo
			tables = sapRfc(executefunction,tables, getTables);
			
			List<Map<String, Object>> listmap = null;
			String tableName = null;
			String err = "0" ; 
			String rtmsg = "" ;
			
			// 回應處理
			for (Iterator iterator = tables.keySet().iterator(); iterator.hasNext();) {
				tableName = iterator.next().toString();
				log.info(" getTables.tableName : " + tableName);
				if (tableName.equals(returnTableCUS)) {
					log.info("列印「客戶主檔回傳訊息」");
					listmap = tables.get(tableName);
					for (Map<String, Object> Map : listmap) {
						log.info("客戶群組一 : "+Map.get("KVGR1"));
			        	log.info("客戶或供應商第的發貨人(我方)帳號 : "+Map.get("EIKTO"));
			        	log.info("處理結果 : "+Map.get("TRAN_RESULT"));
			        	log.info("客戶編號 : "+Map.get("KUNNR"));
			        	log.info("訊息 : "+Map.get("MESSAGE"));
			        	//2011.9.15:竹君指示不考慮SAP回傳結果,如有sap_id回覆,就要處理
			        	if( account.getSapCustNo() == null || account.getSapCustNo().trim().equals("") ){
			        		if( Map.get("KUNNR") != null )
			        			account.setSapCustNo((String)Map.get("KUNNR"));
			        	}
			        	//修正傳入帳號上傳結果欄位值
			        	if( "S".equals(Map.get("TRAN_RESULT")) ){
			        		uploadSap = true;
			        		if( !sapExist )
			        			account.setSapCustNo((String)Map.get("KUNNR"));
			        		account.setUploadSapMsg(true);
			        	}else{
			        		uploadSap = false;
			        		account.setSapMessage((String)Map.get("MESSAGE"));
			        		account.setUploadSapMsg(false);
			        	}
					}
				}
				if (tableName.equals(returnTablePNR)) {
					log.info("列印「客戶聯絡人回傳訊息」");
					listmap = tables.get(tableName);
					for (Map<String, Object> Map : listmap) {
						log.info("客戶群組一 : "+Map.get("KVGR1"));
			            log.info("客戶或供應商處的發貨人(我方)帳號 : "+Map.get("EIKTO"));
			            log.info("聯絡人責職 :"+Map.get("PAFKT"));
			            log.info("名稱1 : "+Map.get("NAME1"));
			            log.info("處理結果 : "+Map.get("TRAN_RESULT"));
			            log.info("聯絡人 : "+Map.get("PATNR"));
			            log.info("訊息 : "+Map.get("MESSAGE"));
					}
				}
				if (tableName.equals(returnTableBNKINS)) {
					log.info("列印「客戶銀行匯款帳號回傳訊息」");
					listmap = tables.get(tableName);
					for (Map<String, Object> Map : listmap) {
						log.info("客戶群組一 : "+Map.get("KVGR1"));
						log.info("客戶或供應商處的發貨人(我方)帳號 : "+Map.get("EIKTO"));
						log.info("聯絡人責職 :"+Map.get("PAFKT"));
						log.info("名稱1 : "+Map.get("NAME1"));
						log.info("處理結果 : "+Map.get("TRAN_RESULT"));
						log.info("聯絡人 : "+Map.get("PATNR"));
						log.info("訊息 : "+Map.get("MESSAGE"));
					}
				}
			}
			
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		account.setSapMessage(e.getLocalizedMessage());
    	}
    	return uploadSap;
    }
    
    public boolean execute1(Account account){
    	boolean uploadSap = false;
    	boolean sapExist = false;
    	if( account.getSapCustNo() != null && account.getSapCustNo().length() > 2 )
    		sapExist = true;
    	
    	String executefunction = null;
    	String executeTableCUS = null;
    	String executeTablePNR = null;
    	String returnTableCUS = null;
    	Set<String> getTables = new HashSet<String>();
    	if(sapExist) {
    		executefunction = "ZCHANGE_CUSTOMER";
    		executeTableCUS = IT_CUSINC;
    		executeTablePNR = IT_PNRIN;
    		returnTableCUS = IT_CUSRET;
    	}else{ 
    		executefunction = "ZCREATE_CUSTOMER";
    		executeTableCUS = IT_CUSINS;
    		executeTablePNR = IT_PNRINS;
    		returnTableCUS = IT_CUSRETS;
    	}
    	getTables.add(returnTableCUS);
    	try{
    		
    		log.info(" sapExist : " + sapExist + (sapExist?" 修改":" 新增")+" ["+executefunction+"]");
    		
    		log.info(" execute TableCUS : " + executeTableCUS);
    		log.info(" return TableCUS : " + returnTableCUS);
    		
    		log.info(" execute TablePNR : " + executeTablePNR);
	    	// 帶入資料
			Map<String, List<Map<String, Object>>> tables = new HashMap<String, List<Map<String, Object>>>();
			List<Map<String, Object>> datelist = new ArrayList<Map<String, Object>>();
			
			//設定上傳資料-客戶主檔
			Map<String, Object> dataMapCus = new HashMap<String, Object>();
			dataMapCus.put(CUSTOMER_KVGR1, "001");
			dataMapCus.put(CUSTOMER_EIKTO,account.getAccountId());
	        if(!sapExist) {
	        	//C02:一般客戶, C07:關係人, C09:一次性客戶
	        	if( account.getRelationship() == 1 )
	        		dataMapCus.put(CUSTOMER_KTOKD, "C07");
	        	else
	        		dataMapCus.put(CUSTOMER_KTOKD, "C02");
	        }
			if( sapExist ){
				dataMapCus.put(CUSTOMER_KUNNR,account.getSapCustNo());
			}else{
				if( account.getRelationship() == 1 )
					dataMapCus.put(CUSTOMER_KUNNR,account.getKeyinSapCustNo());
				else
					dataMapCus.put(CUSTOMER_KUNNR,"");
			}
	        dataMapCus.put(CUSTOMER_BUKRS,account.getCompanyId());
	        dataMapCus.put(CUSTOMER_VKORG,account.getCompanyId());
	        dataMapCus.put(CUSTOMER_VTWEG,"99") ;
	        dataMapCus.put(CUSTOMER_SPART,"99") ;
	        dataMapCus.put(CUSTOMER_ANRED,"公司") ;
	        
	        String [] companyNames = SapAdapterUtil.getCompanyName(account.getCompanyName2()); //2012.6.20 Brian Han : 改抓公司全名
	        dataMapCus.put(CUSTOMER_NAME1,companyNames[0]) ;
	        dataMapCus.put(CUSTOMER_NAME2,companyNames[1]) ;
	        dataMapCus.put(CUSTOMER_NAME3,companyNames[2]) ;
	        dataMapCus.put(CUSTOMER_NAME4,companyNames[3]) ;
	        if( account.getCompanyName1().length() <= 10 )
	        	dataMapCus.put(CUSTOMER_SORT1,account.getCompanyName1()); 
	        else
	        	dataMapCus.put(CUSTOMER_SORT1,account.getCompanyName1().substring(0, 10));
	        
	        String [] addr = SapAdapterUtil.getAddr(account.getComAddr5());
	        dataMapCus.put(CUSTOMER_STREET,addr[0]);
	        dataMapCus.put(CUSTOMER_STR_SUPPL1,addr[1]);
	        dataMapCus.put(CUSTOMER_STR_SUPPL2,addr[2]);
	        dataMapCus.put(CUSTOMER_STR_SUPPL3,addr[3]);
	        dataMapCus.put(CUSTOMER_LOCATION,addr[4]);
	        
	        if( account.getComAddr1().equals("002") ){//外國
		        dataMapCus.put(CUSTOMER_POST_CODE1,account.getComAddr2()) ;
		        dataMapCus.put(CUSTOMER_CITY1, "");
		        dataMapCus.put(CUSTOMER_COUNTRY, account.getComAddr3()); 
		        String[] addr4 = account.getComAddr4().split(" ");
		        if( addr4.length >=2 )
		        	dataMapCus.put(CUSTOMER_REGION, addr4[1]);
		        else
		        	dataMapCus.put(CUSTOMER_REGION, "");
	        }else{//本國
	        	dataMapCus.put(CUSTOMER_POST_CODE1,account.getComAddr2()) ;
		        dataMapCus.put(CUSTOMER_CITY1, 
		        		BsCodeDefinition.getBsCodeExplain("AD",account.getComAddr3()) + 
		        		BsCodeDefinition.getBsCodeExplain("AD",account.getComAddr4())
		        		); //轉成名稱 -城市+地區 ex:台北市中山區
 		        dataMapCus.put(CUSTOMER_COUNTRY, "TW"); 
		        dataMapCus.put(CUSTOMER_REGION, account.getSaleDistrict());
	        }
	        dataMapCus.put(CUSTOMER_LANGU, "ZF");
	        
	        dataMapCus.put(CUSTOMER_TEL_NUMBER, account.getComTel());
	        dataMapCus.put(CUSTOMER_TEL_EXTENS, account.getComExt());
	        dataMapCus.put(CUSTOMER_TELF2, "");
	        dataMapCus.put(CUSTOMER_FAX_NUMBER, account.getComFax());
	        dataMapCus.put(CUSTOMER_FAX_EXTENS, "");
	        
	        dataMapCus.put(CUSTOMER_SMTP_ADDR, "");
	        dataMapCus.put(CUSTOMER_STCEG, account.getGuiNo());
	        dataMapCus.put(CUSTOMER_ZTERM, account.getPayDay());
	        dataMapCus.put(CUSTOMER_BZIRK, account.getSaleDistrict());
	        dataMapCus.put(CUSTOMER_WAERS, account.getCurrency());
	        
	        dataMapCus.put(CUSTOMER_KALKS, account.getCustPricingProc());
	        dataMapCus.put(CUSTOMER_ZTERM1, account.getPayDay());
	        if( account.getRelationship() == 1 )
	        	dataMapCus.put(CUSTOMER_KTGRD, "01");
	        else
	        	dataMapCus.put(CUSTOMER_KTGRD, "02");
	        dataMapCus.put(CUSTOMER_TAXKD, account.getTaxClass());
	        dataMapCus.put(CUSTOMER_KKBER, account.getCompanyId());
	        dataMapCus.put(CUSTOMER_KLIMKS, new BigDecimal(1));
	        dataMapCus.put(CUSTOMER_CTLPC, account.getOverdue());
	        
	        log.info(" dataMapCus : " + dataMapCus);
	        datelist.add(dataMapCus);
	        tables.put(executeTableCUS, datelist);
	        
			// 送到SAP 處理 todo
			tables = sapRfc(executefunction,tables, getTables);
			
			List<Map<String, Object>> listmap = null;
			String tableName = null;
			String err = "0" ; 
			String rtmsg = "" ;
			
			// 回應處理
			for (Iterator iterator = tables.keySet().iterator(); iterator.hasNext();) {
				tableName = iterator.next().toString();
				System.out.println(" getTables.tableName : " + tableName);
				if (tableName.equals(returnTableCUS)) {
					System.out.println("列印「客戶主檔回傳訊息」");
					listmap = tables.get(tableName);
					for (Map<String, Object> Map : listmap) {
						System.out.println("客戶群組一 : "+Map.get("KVGR1"));
			        	System.out.println("客戶或供應商第的發貨人(我方)帳號 : "+Map.get("EIKTO"));
			        	System.out.println("處理結果 : "+Map.get("TRAN_RESULT"));
			        	System.out.println("客戶編號 : "+Map.get("KUNNR"));
			        	System.out.println("訊息 : "+Map.get("MESSAGE"));
			        	//2011.9.15:竹君指示不考慮SAP回傳結果,如有sap_id回覆,就要處理
			        	if( account.getSapCustNo() == null || account.getSapCustNo().trim().equals("") ){
			        		if( Map.get("KUNNR") != null )
			        			account.setSapCustNo((String)Map.get("KUNNR"));
			        	}
			        	//修正傳入帳號上傳結果欄位值
			        	if( "S".equals(Map.get("TRAN_RESULT")) ){
			        		uploadSap = true;
			        		if( !sapExist )
			        			account.setSapCustNo((String)Map.get("KUNNR"));
			        		account.setUploadSapMsg(true);
			        	}else{
			        		uploadSap = false;
			        		account.setSapMessage((String)Map.get("MESSAGE"));
			        		account.setUploadSapMsg(false);
			        	}
					}
				}
			}
			
    	}catch(Exception e){
    		log.error(e.getMessage(), e);
    		System.out.println("  eMessage : " + e);
    		account.setSapMessage(e.getLocalizedMessage());
    	}
    	return uploadSap;
    }

	public com.gccs.member.service.MemberService getMemberService() {
		return memberService;
	}

	public void setMemberService(com.gccs.member.service.MemberService memberService) {
		this.memberService = memberService;
	}

}