package com.gccs.member.rfc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.gccs.member.card.model.MmCard;
import com.rfep.nm.util.BaseSapRfc;
import common.Logger;

/**
 * 修改客戶卡號SAP
 * @author san
 *
 */
public class MemberCardRfc extends BaseSapRfc{
	
	private Logger log = Logger.getLogger(MemberCardRfc.class);
	
	/**
	 * 客戶群組一
	 */
	private static final String CARDIN_KVGR1 = "KVGR1";
	/**
	 * 客戶或供應商處的發貨人(我方)帳號
	 */
	private static final String CARDIN_EIKTO = "EIKTO";
	/**
	 * 客戶卡號
	 */
	private static final String CARDIN_CARD_NO = "CARD_NO";
	/**
	 * 卡號狀態<br>
	 * 0-停用 1–正常 2–異常 9–刪除
	 */
	private static final String CARDIN_STATUS = "STATUS";
	
    /**
	 * 客戶名稱
	 */
	private static final String CARD_NAME = "CARD_NAME"; 
	//-----------------------------------------------------------------------//
	
	/**
	 * 客戶卡號傳入資料
	 */
	private static final String IT_CARDIN = "IT_CARDIN";
	/**
	 * 客戶卡號傳入回傳訊息
	 */
	private static final String IT_CARDRET = "IT_CARDRET";
	
	//-----------------------------------------------------------------------//
	
	private static final String executefunction = "ZUPDATE_CUST_CARDS";
	
	private static final String executeTable = IT_CARDIN;
	
	//-----------------------------------------------------------------------//
	
	public boolean execute(String account_id, List<MmCard> cards){
		boolean uploadSap = true;
		
		Set<String> getTables = new HashSet<String>();
		getTables.add(IT_CARDRET);
		try{
			// 帶入資料
			Map<String, List<Map<String, Object>>> tables = new HashMap<String, List<Map<String, Object>>>();
			List<Map<String, Object>> datelist = new ArrayList<Map<String, Object>>();
			for( MmCard card : cards ){
				//設定上傳資料-卡
				Map<String, Object> dataMapCard = new HashMap<String, Object>();
				
				dataMapCard.put(CARDIN_KVGR1, "001");
				dataMapCard.put(CARDIN_EIKTO, account_id);
				dataMapCard.put(CARDIN_CARD_NO, card.getVipNo());
				dataMapCard.put(CARDIN_STATUS, card.getStatus());
				dataMapCard.put(CARD_NAME, card.getName());
				
				log.info("honda dataMapCard : " + dataMapCard);
				
				datelist.add(dataMapCard);
			}
			
			tables.put(executeTable, datelist);
			
			// 送到SAP 處理 todo
			tables = sapRfc(executefunction,tables, getTables);
			
			List<Map<String, Object>> listmap = null;
			String tableName = null;
			
			// 回應處理
			for (Iterator iterator = tables.keySet().iterator(); iterator.hasNext();) {
				tableName = iterator.next().toString();
				System.out.println(" getTables.tableName : " + tableName);
				if (tableName.equals(IT_CARDRET)) {
					log.info("列印「客戶卡號回傳訊息」");
					listmap = tables.get(tableName);
					for (Map<String, Object> Map : listmap) {
						
						log.info("客戶群組一 : "+Map.get("KVGR1"));
						log.info("客戶或供應商第的發貨人(我方)帳號 : "+Map.get("EIKTO"));
						log.info("客戶卡號 : "+Map.get("CARD_NO"));
						log.info("處理結果 : "+Map.get("TRAN_RESULT"));
						log.info("訊息 : "+Map.get("MESSAGE"));
			        	//修正傳入帳號上傳結果欄位值
			        	if( "E".equals(Map.get("TRAN_RESULT")) ){
			        		uploadSap = false;
			        		String cardNo = (String)Map.get("CARD_NO");
			        		for( MmCard card : cards ){
			        			if( card.getVipNo().equals(cardNo) ){
			        				card.setSapMessage((String)Map.get("MESSAGE"));
			        			}
			        		}
			        	}
					}
				}
			}
		}catch(Exception e){
    		log.error(e.getMessage(), e);
    		System.out.println("  eMessage : " + e);
    		new RuntimeException(e.getMessage());
    	}
		return uploadSap;
	}
}