package com.gccs.member.rfc;

public class StaticBankins {
	public final static String CRMNO = "CRMNO";
	public final static String ACCNAME = "ACCNAME";
	public final static String ACCNO = "ACCNO";
	public final static String BANK = "BANK";
	public final static String BRANCH = "BRANCH";
	public final static String ELCFLAG = "ELCFLAG";
	public final static String EB_MAIL = "EB_MAIL";

	public final static String TRAN_RESULT = "TRAN_RESULT";
}