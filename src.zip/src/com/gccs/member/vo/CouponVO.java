package com.gccs.member.vo;

import java.io.File;

public class CouponVO extends com.gccs.ws.model.BaseVo{

	private static final long serialVersionUID = 4715553875583860557L;

	private File file;
	
	private int count;
	
	private String startDate;
	
	private String endDate;

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getEndDate() {
		return endDate;
	}
	
}
