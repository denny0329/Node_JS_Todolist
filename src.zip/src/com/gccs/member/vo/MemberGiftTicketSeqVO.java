package com.gccs.member.vo;

import java.util.Date;
import java.util.Map;

public class MemberGiftTicketSeqVO implements java.io.Serializable {
	
	private static final long serialVersionUID = -7641246968017709012L;
	private String skuSeq;
	private String useStatus;
	private String issueMethod;
	private Date validityEndDate;
	private String guiNos;
	private Date transDate;
	
	public MemberGiftTicketSeqVO(){}

	public String getSkuSeq() {
		return skuSeq;
	}

	public void setSkuSeq(String skuSeq) {
		this.skuSeq = skuSeq;
	}

	public String getUseStatus() {
		return useStatus;
	}

	public void setUseStatus(String useStatus) {
		this.useStatus = useStatus;
	}

	public String getIssueMethod() {
		return issueMethod;
	}

	public void setIssueMethod(String issueMethod) {
		this.issueMethod = issueMethod;
	}

	public Date getValidityEndDate() {
		return validityEndDate;
	}

	public void setValidityEndDate(Date validityEndDate) {
		this.validityEndDate = validityEndDate;
	}

	public String getGuiNos() {
		return guiNos;
	}

	public void setGuiNos(String guiNos) {
		this.guiNos = guiNos;
	}

	public Date getTransDate() {
		return transDate;
	}

	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}
	
	public void parseToMap(Map<String, Object> map){
		this.skuSeq = (String)map.get("skuSeq");
		this.useStatus = (String)map.get("useStatus");
		this.issueMethod = (String)map.get("issueMethod");
		this.validityEndDate = (Date)map.get("validityEndDate");
		this.guiNos = (String)map.get("guiNos");
		this.transDate = (Date)map.get("transDate");
	}
	
	
}
