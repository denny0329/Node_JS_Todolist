package com.gccs.member.util;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.keyvalue.MultiKey;
import org.apache.commons.collections.map.MultiKeyMap;

public class CalendarUtil {  

	/**
	 * 取得指定日期的上個月最後一天
	 * @return Calendar 
	 */
	public static Calendar getAgnDateLastDayOfMonth(Date asignDate) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(asignDate);
		cal.add(Calendar.MONTH, -1);
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DAY_OF_MONTH)); 
		return cal;
	}
	/**
	 * 取得指定日期的年
	 * @return int 
	 */
	public static int getYear(Date date) { 
		Calendar cal = Calendar.getInstance();
		cal.setTime(date); 
		
		return cal.get(Calendar.YEAR);
	}
	
	/**
	 * 取得指定日期的月
	 * @return int 
	 */
	public static int getMonth(Date date) { 
		Calendar cal = Calendar.getInstance();
		cal.setTime(date); 
		
		return cal.get(Calendar.MONTH) + 1;
	}
	
	/**
	 * 目前時間是否大於指定日期
	 * @return boolean 
	 */
	public static boolean isAgnDateGtDate(Date transDate, Calendar asignDate) { 
		Calendar cal = Calendar.getInstance();
		cal.setTime(transDate); 
		
		return cal.getTimeInMillis() > asignDate.getTimeInMillis();
	}
	
	/**
	 * 指定日期是否大於指定年
	 * @return boolean 
	 */
	public static boolean isGtDate(Integer year, Date date) { 
		Calendar cal = Calendar.getInstance();
		cal.setTime(date); 
		
		return cal.get(Calendar.YEAR) > year;
	}
	
	/**
	 * 依calendar 取得年月
	 * @return String 
	 */
	public static String getFmtYm(Calendar cal) { 
		return String.format("%d%s", cal.get(Calendar.YEAR), formatZero(cal.get(Calendar.MONTH) + 1));
	}
	
	/**
	 * 取得目前年月yyyyMM
	 * @return String 
	 */
	/*
	public static String getFmtYm() { 
		return String.format("%d%s", getThisYear(), getFmtMonth());
	}*/
	public static String getFmtYm(Date agnDate) { 
		Calendar cal = Calendar.getInstance();
		cal.setTime(agnDate);
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1; 
		return String.format("%d%s", year, formatZero(month));
	}
	
	/**
	 * 兩個日期比
	 * @return String 
	 */
	public static Boolean isAgnDateGtBfMonth(Date agnDate, Date date) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(agnDate); 

		Calendar cal1 = Calendar.getInstance();
		cal1.setTime(date); 
		cal1.add(Calendar.MONTH, -1); 
		cal1.set(Calendar.DAY_OF_MONTH, cal1.getActualMaximum(Calendar.DATE)); 
		cal1.set(Calendar.HOUR_OF_DAY, 23); 
		cal1.set(Calendar.MINUTE, 59); 
		cal1.set(Calendar.SECOND, 59); 
		
		return cal.getTimeInMillis() > cal1.getTimeInMillis();
	}   

	
	/**
	 * 兩個日期比
	 * @return String 
	 */
	public static Boolean isGtAgnDate(Date agnDate, Date date) { 
		Calendar cal = Calendar.getInstance();
		cal.setTime(agnDate); 

		Calendar cal1 = Calendar.getInstance();
		cal1.setTime(date);  
		cal1.set(Calendar.DAY_OF_MONTH, cal1.getActualMaximum(Calendar.DATE)); 
		cal1.set(Calendar.HOUR_OF_DAY, 23); 
		cal1.set(Calendar.MINUTE, 59); 
		cal1.set(Calendar.SECOND, 59); 
		
		return cal.getTimeInMillis() > cal1.getTimeInMillis();
	}  
	
	/**
	 * 依指定日期取得當前年月
	 * @return String 
	 */
	public static String getFmtYmByAgnDate(Date agnDate) { 
		Calendar cal = Calendar.getInstance();
		cal.setTime(agnDate);
		
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1;
		
		return String.format("%d%s", year, formatZero(month));
	}   

	/**
	 * 計算日期大小
	 * @return boolean 
	 */
	public static boolean isGtAgnDateYm(Date agnDate, String date) {  
		Date assignDate = stringToDate(getAsignDate(agnDate), "yyyyMM");
		Date tmpDate = stringToDate(date, "yyyyMM"); 
		 
		return assignDate.getTime() > tmpDate.getTime(); 
	} 
	
	/**
	 * 計算日期大小
	 * @return boolean 
	 */
	public static boolean isLtAgnDateYm(Date agnDate, String date) {  
		Date assignDate = stringToDate(getAsignDate(agnDate), "yyyyMM");
		Date tmpDate = stringToDate(date, "yyyyMM"); 
		 
		return assignDate.getTime() < tmpDate.getTime(); 
	} 
	
	/**
	 * 計算目前日期是否在指定時間內
	 * @return boolean 
	 */
	public static boolean isBtwDate(Date agnDate, String date, String date1) {  
		Date start = stringToDate(date, "yyyyMM");
		Date end = stringToDate(date1, "yyyyMM"); 
		Date now = stringToDate(getAsignDate(agnDate), "yyyyMM");
		 
		return now.getTime() >= start.getTime() && now.getTime() <= end.getTime(); 
	} 
	
	/**
	 * 兩個日期的YM是否一致
	 * @return boolean 
	 */
	public static boolean isSameDateForYm(Date dt, Date dt1) {  
		Calendar cal = Calendar.getInstance();
		cal.setTime(dt);

		Calendar cal1 = Calendar.getInstance();
		cal1.setTime(dt1);

		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1;

		int year1 = cal1.get(Calendar.YEAR);
		int month1 = cal1.get(Calendar.MONTH) + 1;
		return year == year1 && month == month1; 
	} 
	
	/**
	 * 兩個日期的YM是否一致
	 * @return boolean 
	 */
	public static boolean isSameDateForYm(Date dt, String dt1) {  
		Calendar cal = Calendar.getInstance();
		cal.setTime(dt); 

		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1;
		 
		return dt1.equals(String.format("%d%s", year, formatZero(month))); 
	} 
	

	/** 
	 * 兩個日期的YM是否一致
	 * @return boolean 
	 */
	public static boolean isSameDateForYm(String dt, String dt1) {  
		Date start = stringToDate(dt, "yyyyMM");
		Date end = stringToDate(dt1, "yyyyMM");  
		 
		return  start.getTime() == end.getTime(); 
	} 
	
	/**
	 * 現有日期增加12個月，顯示yyyyMM
	 * @return
	 */
	 public static String getAsignDate(Date agnDate) { 
		 Calendar cal = Calendar.getInstance();
		 cal.setTime(agnDate);
		 cal.get(Calendar.YEAR);
		  
		 return String.format("%d%s", cal.get(Calendar.YEAR), formatZero(cal.get(Calendar.MONTH) + 1));
	 }
	
	/**
	 * 現有日期增加12個月，顯示yyyyMM
	 * @return
	 */
	 public static String getFmtYmAdd12(Date agnDate) {  
		 Calendar cal = Calendar.getInstance();
		 cal.setTime(agnDate);
		 
		 cal.add(Calendar.MONTH, 11);
		 
		 int year = cal.get(Calendar.YEAR);
		 int month = cal.get(Calendar.MONTH) + 1;

		 return String.format("%d%s", year, formatZero(month)); 
	 }
	 
	/**
	 * 依指定日期 增加12個月，顯示yyyyMM
	 * @return String 
	 */
	public static String getFmtYmAdd12ByAgnDate(Date agnDate) { 
		Calendar cal = Calendar.getInstance();
		cal.setTime(agnDate);

		cal.add(Calendar.MONTH, 11);
		
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1;
		
		return String.format("%d%s", year, formatZero(month));
	}   
	 
	 /**
	  * 現有日期減12個月，顯示yyyyMM
	  * @return
	  */
	 public static String getFmtYmSub12() {
		 Calendar cal = addMonth(-11);
		 int year = cal.get(Calendar.YEAR);
		 int month = cal.get(Calendar.MONTH) + 1;
		 return String.format("%d%s", year, formatZero(month));
	 }
	
	/**
	 * 當月最後一天
	 * @return
	 */
	 public static Calendar getLastMonthDay(Calendar calendar) {
        calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DATE));
        return calendar;
	 }
	
	/**
	 * 增加月份 
	 * @return
	 */
	public static Calendar addMonth(Integer month) { 
	    Calendar cal = Calendar.getInstance();
	    cal.add(Calendar.MONTH, month);
		return cal;
	}  
	
	/**
	 * 增加天數
	 * @return
	 */
	public static Date addDay(Date date, Integer day) { 
	    Calendar cal = Calendar.getInstance();
	    cal.setTime(date);
	    cal.add(Calendar.DAY_OF_MONTH, day);
	    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    System.out.println(sdf.format(cal.getTime()));
		return cal.getTime();
	} 

	/**
	 * 增加月份 
	 * @return
	 */
	public static Date addMonthByDate(Date date, Integer month) { 
	    Calendar cal = Calendar.getInstance();
	    cal.setTime(date);
	    cal.add(Calendar.MONTH, month);
		return new Date(cal.getTimeInMillis());
	} 
	
	/**
	 * 取得今年年份 
	 * @return int
	*/ 
	public static int getThisYear(Date agnDate) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(agnDate);
		return cal.get(Calendar.YEAR);
	} 
	
	/**
	 * 取得今年年份 
	 * @return int
	*/ 
	public static int getThisYear() {
		Calendar cal = Calendar.getInstance(); 
		return cal.get(Calendar.YEAR);
	}
	
	/**
	 * 取得當月月份(左補0)
	 * @return String
	*/
	public static String getFmtMonth(Date agnDate) {  
		return formatZero(getThisMonth(agnDate));
	} 
	
	/**
	 * 取得當月月份 
	 * @return
	 */
	public static int getThisMonth(Date agnDate) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(agnDate);
		return cal.get(Calendar.MONTH) + 1;
	} 
	
	/**
	 * 取得當月月份 
	 * @return
	 */
	public static int getThisMonth() {
		Calendar cal = Calendar.getInstance();
		return cal.get(Calendar.MONTH) + 1;
	} 
	 
	/**
	 * 取得今天日期(左補0)
	 * @return String
	 */
	public static String getFmtDay() {  
		return formatZero(getThisDay());
	}
	
	/**
	 * 取得今天日期 
	 * @return
	 */
	public static int getThisDay() {
		Calendar calendar = Calendar.getInstance();
		return calendar.get(Calendar.DAY_OF_MONTH);
	}

	/**
	 * 取得今年年份 
	 * @return int
	*/ 
	public static int getThisDay(Date agnDate) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(agnDate);
		return cal.get(Calendar.DAY_OF_MONTH);
	} 
	
	/**
	 * 左補0
	 * @param num
	 * @return String
	 */
	public static String formatZero(int num) {  
		if(num < 10) {
			return "0" + num;
 		}
		return String.valueOf(num);
	} 
	
	/**
	 * 字串轉換為日期
	 * @param dateString
	 * @param format
	 * @return String
	 */
	public static Date stringToDate(String dateString, String format) {
		try { 
			SimpleDateFormat sdf = new SimpleDateFormat(format); 
			return sdf.parse(dateString); 
		} catch (Exception e) { 
			e.printStackTrace();
		}
		return null;
	} 
	
	/**
	 * 日期轉換為字串
	 * @param date 
	 * @return String
	 */
	public static String dateToString(Date date, String tag) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);

		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DAY_OF_MONTH);
		return String.format("%d%s%s%s%d", year, tag, formatZero(month), tag, day); 
	} 
	
	/**
	 * 日期轉換為字串
	 * @param date 
	 * @return String
	 */
	public static String formatDate(Date date, String tag) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);

		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DAY_OF_MONTH);
		return String.format("%d%s%s%s%s", year, tag, formatZero(month), tag, formatZero(day)); 
	} 
	
	/**
	 * 依年及月 來取得該年月的最後一天是幾號
	 * @param year
	 * @param month
	 * @return Integer
	 */
	public static Integer getMaximumByYm(Integer year, Integer month) {
		Calendar cal = Calendar.getInstance(); 
		cal.set(Calendar.YEAR, year);
		cal.set(Calendar.MONTH, month); 
		return cal.getActualMaximum(Calendar.DAY_OF_MONTH);
	}

	/**
	 * 取得上個月，推算11個月區間時間，如有小於指定時間則以最小單位來計算
	 * ex limit year 2004, 2005-02-01 => 2005-01-01 ~ 2005-01-31
	 * agnDate : gui_date
	 * @return
	 */
	 public static Map<String, String> getRgeDateByAgnDate(Date agnDate, Integer year, Integer limitMonth) {  
		 Map<String, String> result = new HashMap<String, String>();

		 Calendar endCal = Calendar.getInstance();
		 endCal.setTime(agnDate);
		 //endCal.add(Calendar.DAY_OF_MONTH, -1);
		 Integer ey = endCal.get(Calendar.YEAR);
		 Integer emInt = endCal.get(Calendar.MONTH) + 1;
		 String em = formatZero(emInt);
		 Integer ed = endCal.get(Calendar.DAY_OF_MONTH);

		 Calendar cal = Calendar.getInstance();
		 cal.setTime(agnDate);
		 cal.add(Calendar.MONTH, -1);
		 Integer endYear = cal.get(Calendar.YEAR);
		 Integer endMonthInt = cal.get(Calendar.MONTH) + 1;
		 String endMonth = formatZero(endMonthInt);
		 Integer startYear = 0;
		 String startMonth = "";
		 //Integer limitMonth = 11;
		 
		 while(cal.get(Calendar.YEAR) > year && limitMonth-- >=0) {
			 startYear = cal.get(Calendar.YEAR);
			 startMonth = formatZero(cal.get(Calendar.MONTH) + 1);
			 cal.add(Calendar.MONTH, -1);	
		 }
		 
		 if(startYear == 0 && startMonth.equals("")) {
			 startYear = endYear;
			 startMonth = endMonth;
		 } 
		 
		 result.put("startDate", String.format("%d-%s-01 00:00:00", startYear, startMonth));
		 result.put("endDate", String.format("%d-%s-%d 23:59:59", ey, em, ed)); 
		 
		 return result; 
	}

	 /**
	 * 取得上個月，推算11個月區間時間，如有小於指定時間則以最小單位來計算
	 * ex limit year 2004, 2005-02-01 => 2005-01-01 ~ 2005-01-31
	 * agnDate : gui_date
	 * @return
	 */
	 public static Map<String, String> getRgeDateByAgnDate(Date agnDate, String yearMonth, Integer limitMonth) {  
		 Map<String, String> result = new HashMap<String, String>(); 
		 Date limitYm = stringToDate(yearMonth, "yyyyMM"); 
		 Date assignDate = stringToDate(getAsignDate(agnDate), "yyyyMM");
		 
		 Calendar cal = Calendar.getInstance();
		 cal.setTime(agnDate);
		 
		 Integer endYear = cal.get(Calendar.YEAR);
		 Integer endMonthInt = cal.get(Calendar.MONTH) + 1; 
		 String endMonth = formatZero(endMonthInt);
		 Integer startYear = 0;
		 String startMonth = "";
		 
		 if(limitYm.equals(assignDate)) { 
			 result.put("startDate", String.format("%d-%s-01 00:00:00", endYear , endMonth));
			 result.put("endDate", 
					 String.format("%d-%s-%d 23:59:59", endYear, endMonth, getMaximumByYm(endYear, endMonthInt))); 
			 return result;
		 } 
		 
		 Calendar tmpCal = Calendar.getInstance();
		 tmpCal.setTime(limitYm);
		 
		 Calendar ecal = Calendar.getInstance();
		 ecal.set(Calendar.YEAR, tmpCal.get(Calendar.YEAR));
		 ecal.set(Calendar.MONTH, tmpCal.get(Calendar.MONTH) + 1); 
		 
		 while(cal.getTimeInMillis() > ecal.getTimeInMillis() && limitMonth-- >=0) {
			 startYear = cal.get(Calendar.YEAR);
			 startMonth = formatZero(cal.get(Calendar.MONTH) + 1); 
			 cal.add(Calendar.MONTH, -1);	
		 }

		 result.put("startDate", String.format("%d-%s-01 00:00:00", startYear, startMonth));
		 result.put("endDate", String.format("%d-%s-%d 23:59:59", endYear, endMonth, getMaximumByYm(endYear, endMonthInt))); 
 
		 return result; 
	}
	
	 /**
	 * 從目前月往回推算11個月，回傳年月需大於限制時間 
	 * @param limitYear
	 * @return String
	 */
	public static String getRangeStartDate(Date agnDate, Integer limitYear) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(agnDate);
		Integer limitMonth = 11;
		while(cal.get(Calendar.YEAR) > limitYear && limitMonth-- > 0) {  
			cal.add(Calendar.MONTH, -1);	 
		}
		
		if(cal.get(Calendar.YEAR) <= limitYear) {
			cal.add(Calendar.MONTH, 1);	 
		}

		return String.format("%d%s", cal.get(Calendar.YEAR), formatZero(cal.get(Calendar.MONTH) + 1));
	} 
	

	 /**
	 * 從目前月往回推算11個月，回傳"年月"需大於限制時間 
	 * @param limitYear
	 * @return String
	 */
	public static String getRangeStartDate(Date date, String limitYm) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		
		Integer limitMonth = 11;
		
		Date limYm = stringToDate(limitYm, "yyyyMM");  
		Calendar agnDate = Calendar.getInstance();
		agnDate.setTime(limYm);
		
		while(cal.getTimeInMillis() > agnDate.getTimeInMillis() && limitMonth-- > 0) {  
			cal.add(Calendar.MONTH, -1);	 
		}
		 
		if(cal.getTimeInMillis() <= agnDate.getTimeInMillis()) {
			cal.add(Calendar.MONTH, 1);	 
		} 

		return String.format("%d%s", cal.get(Calendar.YEAR), formatZero(cal.get(Calendar.MONTH) + 1));
	} 
	 
	 /**
	 * 今日是否為指定日期的最後一天
	 * @param String ym
	 * @return boolean
	 */ 
	public static boolean isSameAgnDateMaxmum(String ym) { 
		Calendar cal = Calendar.getInstance();

		Date limYm = stringToDate(ym, "yyyyMM");  
		Calendar agnDate = Calendar.getInstance();
		agnDate.setTime(limYm); 
		
		return cal.get(Calendar.YEAR) == agnDate.get(Calendar.YEAR) &&
				(cal.get(Calendar.MONTH) + 1) == (agnDate.get(Calendar.MONTH) + 1) &&
				 cal.get(Calendar.DAY_OF_MONTH) == agnDate.getActualMaximum(Calendar.DAY_OF_MONTH)
				;
	} 
	
	 /**
	 * 依ym取得完整ymd
	 * @param String ym
	 * @return yyyy-mm-dd
	 */ 
	public static String getYmdByYm(String ym) {  
		Date limYm = stringToDate(ym, "yyyyMM");  
		Calendar cal = Calendar.getInstance();
		cal.setTime(limYm);   
		
		return String.format("%d-%s-%d", cal.get(Calendar.YEAR), formatZero(cal.get(Calendar.MONTH) + 1), cal.getActualMaximum(Calendar.DAY_OF_MONTH));
	}  
	
	/**
	 * 依ym取得完整ymd, format
	 * @param String ym
	 * @param String tag
	 * @return yyyy-mm-dd
	 */ 
	public static String getYmdByYmFmt(String ym, String tag) {  
		Date limYm = stringToDate(ym, "yyyyMM");  
		Calendar cal = Calendar.getInstance();
		cal.setTime(limYm);   
		
		return String.format("%d%s%s%s%d", cal.get(Calendar.YEAR), tag, formatZero(cal.get(Calendar.MONTH) + 1), tag, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
	} 

	 /**
	 * 依ym取得完整這個月的第一天
	 * @param String ym
	 * @return yyyy-mm-dd
	 */ 
	public static String getFirstDateYmdByYm(String ym) {  
		Date limYm = stringToDate(ym, "yyyyMM");  
		Calendar cal = Calendar.getInstance();
		cal.setTime(limYm);   
		
		return String.format("%d-%s-%s", cal.get(Calendar.YEAR), formatZero(cal.get(Calendar.MONTH) + 1), "01");
	} 
	
	/**
	 * 依ym取得完整這個月的第一天, format
	 * @param String ym
	 * @param String tag
	 * @return yyyy-mm-dd
	 */ 
	public static String getFirstDateYmdByYmFmt(String ym, String tag) {  
		Date limYm = stringToDate(ym, "yyyyMM");  
		Calendar cal = Calendar.getInstance();
		cal.setTime(limYm);   
		
		return String.format("%d%s%s%s%s", cal.get(Calendar.YEAR), tag, formatZero(cal.get(Calendar.MONTH) + 1), tag, "01");
	} 
	
	public static void showCalandarToString(Calendar cal) {  
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		System.out.println( sdf.format(cal.getTime()));
	}
	
	/**
	 * 依指定日 當月最後一天回算指定月的1月1號區間
	 * @param agnDate
	 * @param limitMonth
	 * @return Map<String, String>
	 */
	public static Map<String, Date> getRgeDateByAgnDate(Date agnDate, Integer limitMonth) {  
		 Map<String, Date> result = new HashMap<String, Date>();

		 Calendar endCal = Calendar.getInstance();
		 endCal.setTime(agnDate);
		 endCal.set(Calendar.DATE, endCal.getActualMaximum(Calendar.DAY_OF_MONTH)); 
		 Integer ey = endCal.get(Calendar.YEAR);
		 Integer emInt = endCal.get(Calendar.MONTH) + 1;
		 String em = formatZero(emInt);
		 Integer ed = endCal.get(Calendar.DAY_OF_MONTH);

		 Calendar cal = Calendar.getInstance();
		 cal.setTime(agnDate);
		 cal.add(Calendar.MONTH, -1);
		 Integer endYear = cal.get(Calendar.YEAR);
		 Integer endMonthInt = cal.get(Calendar.MONTH) + 1;
		 String endMonth = formatZero(endMonthInt);
		 Integer startYear = 0;
		 String startMonth = ""; 
 
		 while(limitMonth-- >0) {
			 startYear = cal.get(Calendar.YEAR);
			 startMonth = formatZero(cal.get(Calendar.MONTH) + 1);
			 cal.add(Calendar.MONTH, -1);	
		 } 
		 
		 if(startYear == 0 && startMonth.equals("")) {
			 startYear = endYear;
			 startMonth = endMonth;
		 } 

		 result.put("startDate", stringToDate(String.format("%d-%s-01 00:00:00", startYear, startMonth), "yyyy-MM-dd HH:mm:ss"));
		 result.put("endDate", stringToDate(String.format("%d-%s-%d 23:59:59", ey, em, ed), "yyyy-MM-dd HH:mm:ss")); 
		 
		 return result; 
	}
	
	/**
	 * 依date取得這個月的第一天
	 * @param Date
	 * @return yyyy-mm-dd hh:mm:ss
	 */ 
	public static String getFirstDateYmdhms(Date date) {   
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);   

		return String.format("%d-%s-%s", cal.get(Calendar.YEAR), formatZero(cal.get(Calendar.MONTH) + 1), "01 00:00:00");
	} 
	
	/**
	 * 依date取得今天最後一分一秒
	 * @param Date
	 * @return yyyy-mm-dd hh:mm:ss
	 */ 
	public static Date fmtToHms(Date date) {   
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);   
		
		cal.set(Calendar.HOUR_OF_DAY, 23); 
		cal.set(Calendar.MINUTE, 59); 
		cal.set(Calendar.SECOND, 59); 

		return new Date(cal.getTimeInMillis());
	} 
	
	/**
	 * 依date取得這個月的第一天 , format
	 * @param Date
	 * @return yyyy-mm-dd hh:mm:ss
	 */
	public static Date fmtFirstDateYmdhms(Date date) {   
		String tmp = getFirstDateYmdhms(date);
 
		return stringToDate(tmp, "yyyy-MM-dd hh:mm:ss");
	} 
	
	/**
	 * 兩個日期比大小
	 * @return String 
	 */
	public static Boolean isGtDate(Date agnDate, Date date) { 
		Calendar cal = Calendar.getInstance();
		cal.setTime(agnDate); 

		Calendar cal1 = Calendar.getInstance();
		cal1.setTime(date);  
		
		return cal.getTimeInMillis() > cal1.getTimeInMillis();
	}

	/** 
	 * 日期的YM 比較大小
	 * @return boolean 
	 */
	public static boolean isGtDateForYm(String dt, String dt1) {  
		Date start = stringToDate(dt, "yyyyMM");
		Date end = stringToDate(dt1, "yyyyMM");  
		 
		return  start.getTime() == end.getTime(); 
	} 
	
	/**
	 * 取得上個月最後一天推算11個月區間時間  
	 * agnDate 
	 * @return
	 */ 
	public static Map<String, String> getRgeDateByAgnLastDate(Date agnDate, Integer year, Integer limitMonth) {  
		 Map<String, String> result = new HashMap<String, String>();

		 Calendar endCal = Calendar.getInstance();
		 endCal.setTime(agnDate);
		 endCal.add(Calendar.MONTH, -1);
		 endCal.set(Calendar.DATE, endCal.getActualMaximum(Calendar.DAY_OF_MONTH)); 
		 Integer ey = endCal.get(Calendar.YEAR);
		 Integer emInt = endCal.get(Calendar.MONTH) + 1;
		 String em = formatZero(emInt);
		 Integer ed = endCal.get(Calendar.DAY_OF_MONTH);

		 Calendar cal = Calendar.getInstance();
		 cal.setTime(agnDate);
		 cal.add(Calendar.MONTH, -1);
		 Integer endYear = cal.get(Calendar.YEAR);
		 Integer endMonthInt = cal.get(Calendar.MONTH) + 1;
		 String endMonth = formatZero(endMonthInt);
		 Integer startYear = 0;
		 String startMonth = "";
		 //Integer limitMonth = 11;
		 
		 while(cal.get(Calendar.YEAR) > year && limitMonth-- >=0) {
			 startYear = cal.get(Calendar.YEAR);
			 startMonth = formatZero(cal.get(Calendar.MONTH) + 1);
			 cal.add(Calendar.MONTH, -1);	
		 }
		 
		 if(startYear == 0 && startMonth.equals("")) {
			 startYear = endYear;
			 startMonth = endMonth;
		 } 
		 
		 result.put("startDate", String.format("%d-%s-01 00:00:00", startYear, startMonth));
		 result.put("endDate", String.format("%d-%s-%d 23:59:59", ey, em, ed)); 
		 
		 return result; 
	}

	/**
	 * 取得昨天
	 * @return Calendar 
	 */
	public static String getYesterday() {
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.DAY_OF_MONTH, -1);
		
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DAY_OF_MONTH);
		return String.format("%d%s%s", year, formatZero(month), formatZero(day));
	}
	
	public static void main(String args[]) { 
		System.out.println("Year=" + getThisYear(new Date()));
		System.out.println("Month=" + getThisMonth(new Date()));
		System.out.println("Day=" + getThisDay());
		System.out.println("FmtYm=" + getFmtYm(new Date()));
		System.out.println("getFmtYmAdd12=" + getFmtYmAdd12(new Date())); 
		System.out.println("getFmtYmSub12=" + getFmtYmSub12());  

		System.out.println("isBtwDate:" + isBtwDate(new Date(), "201401", "201409"));
		System.out.println("isBtwDate:" + getAsignDate(new Date()));
		
		
		System.out.println("isGtDate:" + isGtDate(2014, stringToDate("20130101", "yyyyMMdd")));
		
		Calendar sdate = CalendarUtil.addMonth(13); 
		showCalandarToString(sdate);
		
		Calendar sDate = CalendarUtil.addMonth(1); 
		String fmtYm = CalendarUtil.getFmtYm(sDate);
		System.out.println(CalendarUtil.stringToDate(fmtYm + "10", "yyyyMMdd"));
		
		Calendar eDate = CalendarUtil.addMonth(13); 
		String fmtYms = CalendarUtil.getFmtYm(eDate);
		System.out.println(CalendarUtil.stringToDate(fmtYms + "09 23:59:59", "yyyyMMdd hh:mm:ss"));

		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.MONTH, -1);
		cal.set(Calendar.DATE, cal.getActualMaximum(Calendar.DAY_OF_MONTH)); 
		showCalandarToString(cal);
		
		Calendar now = Calendar.getInstance();
		now.setTime(new Date()); 
		showCalandarToString(now);
		
		//showCalandarToString(addMonthByDate(stringToDate("20160810", "yyyyMMdd"), 12));
		
		System.out.println(addMonthByDate(stringToDate("20170809", "yyyyMMdd"), 12));
		
		System.out.println(">>>>"+getRangeStartDate(new Date(), 2014));
		
		System.out.println(getRgeDateByAgnDate(stringToDate("20141218", "yyyyMMdd"), "201608", 11));

		System.out.println(getRangeStartDate(new Date(), "201608"));
		System.out.println(isSameAgnDateMaxmum("201409"));

		BigDecimal a = new BigDecimal(12300.00);
		BigDecimal b = new BigDecimal(12300.01);
		System.out.println(a.compareTo(b) == 0);
		System.out.println(dateToString(new Date(), "-"));
		
		Object obj = "a";
		MultiKeyMap excludeMap = new MultiKeyMap();
		MultiKey key = new MultiKey(obj, obj);
		excludeMap.put(key, "1");

		System.out.println(excludeMap.containsKey("a"));
		System.out.println(excludeMap.containsKey("a", "b"));
		
		BigDecimal skuSaleTotal = new BigDecimal(-100.01);
		System.out.println(skuSaleTotal.abs());
		
		System.out.println(MathUtil.addScale(skuSaleTotal.abs(), new BigDecimal(3)));
		
		System.out.println(getRgeDateByAgnDate(new Date(), 11));
		
		System.out.println(getYesterday());
		
		System.out.println(addDay(new Date(),365));
	} 
}
