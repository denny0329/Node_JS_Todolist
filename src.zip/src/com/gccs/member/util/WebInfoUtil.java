package com.gccs.member.util;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class WebInfoUtil {  
	public static String getFormatDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	    return sdf.format(new Date());
	}
	
	public static String getTodayHMS() {
		SimpleDateFormat formatDate = new SimpleDateFormat("yyyyMMddHHmmss");
		return formatDate.format(new Date());
	}
	
	public static String getToday() {
		SimpleDateFormat formatDate = new SimpleDateFormat("yyyyMMdd");
		return formatDate.format(new Date());
	}
	
	public static String getBefToday() {
		SimpleDateFormat formatDate = new SimpleDateFormat("yyyyMMdd"); 

		Calendar cal = Calendar.getInstance(); 
        cal.add(Calendar.DAY_OF_MONTH, -1);
		return formatDate.format(cal.getTime());
	}
	
	public static String getTransDay(String dateInfo) throws Exception{  
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd"); 
		Date date = sdf.parse(dateInfo);
		
		return formatDate(date);
	}
	
	public static String formatDate(Date date) {
		SimpleDateFormat formatDate = new SimpleDateFormat("yyyyMMdd");
		return formatDate.format(date);
	}
	
	public static Date formatStringToDate(String dateString) {  
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd"); 
			return sdf.parse(dateString);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new Date();
	}
	
	public static String leftZero(Integer num, Integer limit) {
		String converNum = String.valueOf(num);

		String result = "";
		for(int i = 0; i < limit - converNum.length(); i++) {
			result += "0";
		}
		
		return result + converNum;
	}
	
	//取得上上個月時間區間
	public static Integer[] getMonthRange() {
		Calendar cal = Calendar.getInstance(); 
        cal.add(Calendar.MONTH, -2);
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);  
        int day = cal.get(Calendar.DAY_OF_MONTH);  

        int max = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        int mix = cal.getActualMinimum(Calendar.DAY_OF_MONTH);
        return new Integer[]{year, month+1, day, mix, max};
	}
	
	public static List<String> getFileCsvList(String folderPath){
		List<String> fileList = new ArrayList<String>();
		try{
			File folder = new File(folderPath);
			String[] list = folder.list();           
			for(int i = 0; i < list.length; i++){
				if(list[i].indexOf(".csv") != -1){
					fileList.add(list[i]);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		} 
		return fileList;
	}
}
