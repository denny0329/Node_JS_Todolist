package com.gccs.member.util;

import java.io.Serializable;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.CallbackException;
import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

import com.bnq.cs.cc.model.Comment;
import com.bnq.cs.cc.model.CommentTransfer;
import com.gccs.member.model.Members;
import com.gccs.util.log.model.AuditRecord;
import com.gccs.util.log.model.AuditStore;


public class AuditInterceptor extends EmptyInterceptor
{
    private static final long serialVersionUID = -8597658125309889388L;

	private static final Logger log = LogManager.getLogger(AuditInterceptor.class) ;
	@Override
	public String onPrepareStatement(String sql) {
		if(sql != null) {
			AuditRecord auditRecord = (AuditRecord)new AuditStore().getInstance().get();
			if(auditRecord != null) {
				auditRecord.setSql(sql);  
			}
		}

		return super.onPrepareStatement(sql);
	}
	
	public boolean onFlushDirty(Object entity,  Serializable id, Object[] currentState, 
			Object[] previousState, String[] propertyNames, Type[] types) {

		if (isAuditEntity(entity)){
			AuditRecord auditRecord = (AuditRecord)new AuditStore().getInstance().get();
			if(auditRecord != null) {
				StringBuffer param = new StringBuffer();
				for(int i = 0; i< propertyNames.length; i++) {  
					param.append(String.format("%s=%s,", propertyNames[i], currentState[i]));
				}
				
				auditRecord.setParam(String.format("[%s]", param));
			}
		}
		return false;
	}
	
	public boolean onSave(Object entity,Serializable id,
		Object[] state,String[] propertyNames,Type[] types)
		throws CallbackException {
		
		if (isAuditEntity(entity)){
			AuditRecord auditRecord = (AuditRecord)new AuditStore().getInstance().get();
			if(auditRecord != null) {
				StringBuffer param = new StringBuffer();
				for(int i = 0; i< state.length; i++) {  
					param.append(String.format("%s=%s,", propertyNames[i], state[i]));
				}
				
				auditRecord.setParam(String.format("[%s]", param));
			}
		} 
		return false;
 
	}
	
	private boolean isAuditEntity(Object entity) {
		return entity instanceof Members ||
				entity instanceof CommentTransfer ||
				entity instanceof Comment;
	}
}