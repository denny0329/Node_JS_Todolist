package com.gccs.member.util;

public class JsonResultTemplateErrorCode<T> {
	private String status;
	private String errorCode;
	private String message;
	private T data;
	private String error;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	public String getError() {
		return error;
	}
	public void setError(String error) {
		this.error = error;
	}
	
	@Override
	public String toString() {
		return "JsonResultTemplateErrorCode [status=" + status + ", errorCode=" + errorCode + ", message=" + message
				+ ", data=" + data + ", error=" + error + "]";
	}
}
