package com.gccs.member.util;

import java.math.BigDecimal;

public class MathUtil { 
	/**   
      *相加並四捨五入至整數
      *@param v1 被加數   
      *@param v2 加數    
      */    
    public static BigDecimal addScale(BigDecimal v1, BigDecimal ... args){ 
    	if(v1 == null) {
    		v1 = new BigDecimal(0);
    	}
    	if(args != null) {
	    	for(BigDecimal arg : args) {
	    		if(arg != null) {
	    			v1 = v1.add(arg).setScale(0, BigDecimal.ROUND_HALF_UP);  
	    		}
	    	}
    	}
    	
    	return v1;   
    }    

	/**   
      *四捨五入至整數
      *@param v1    
      */    
    public static BigDecimal scale(BigDecimal v1){    
    	return v1.setScale(0, BigDecimal.ROUND_HALF_UP);   
    }   

	/**   
      * 乘
      * @param v1   
      * @param v2     
      */    
    public static BigDecimal multi(BigDecimal v1, BigDecimal v2){    
    	return v1.multiply(v2);   
    }   
 
    public static void main(String[] args) {
    	System.out.println(addScale(new BigDecimal(2000), new BigDecimal(100), new BigDecimal(100)));
    	System.out.println(multi(new BigDecimal(-1000), new BigDecimal(-1)));

    	System.out.println(addScale(null, new BigDecimal(100), new BigDecimal(100)));
    	System.out.println(addScale(new BigDecimal(2000), new BigDecimal(100), null));
    	System.out.println(addScale(new BigDecimal(2000), null));
    }
}
