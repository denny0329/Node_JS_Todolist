package com.gccs.member.util;

import java.lang.reflect.Field;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.engine.SessionFactoryImplementor;
import org.hibernate.impl.CriteriaImpl;
import org.hibernate.impl.SessionImpl;
import org.hibernate.loader.OuterJoinLoader;
import org.hibernate.loader.criteria.CriteriaLoader;
import org.hibernate.persister.entity.OuterJoinLoadable;


public class HibernateUtil {
	private static final Logger log = LogManager.getLogger(HibernateUtil.class);
	
	private static final String FORMAT_LEFT_TAG = "[";
	
	private static final String FORMAT_RIGHT_TAG = "]";
	
	public static String getCriteriaSql(Criteria criteria) {
		CriteriaImpl ctrImpl = (CriteriaImpl)criteria;  
	    SessionImpl s = (SessionImpl)ctrImpl.getSession();  
	    SessionFactoryImplementor factory = (SessionFactoryImplementor)s.getSessionFactory();  
	    String[] implementors = factory.getImplementors( ctrImpl.getEntityOrClassName() );  
	     
	    CriteriaLoader loader = new CriteriaLoader(
	    		(OuterJoinLoadable)factory.getEntityPersister(implementors[0]), factory, 
	    		ctrImpl, implementors[0],s.getEnabledFilters());  

	    Field field;
	    String sql = "";
	    try {
	    	field = OuterJoinLoader.class.getDeclaredField("sql");
	    	field.setAccessible(true);  
	        sql = (String)field.get(loader);
	    } catch (Exception e) {
	    	log.error("getCriteriaSql error " + e);
	        e.printStackTrace();
	    }
	    return sql;
	}
	
	public static String formatCriterialInfo(String word) {
		String result = "";
		try {
			result = word.substring(
					word.lastIndexOf(FORMAT_LEFT_TAG), word.lastIndexOf(FORMAT_RIGHT_TAG) + 1);
		} catch (Exception e) {
			log.error("formatCriterialInfo error..");
		}
		return result;
	}
}
