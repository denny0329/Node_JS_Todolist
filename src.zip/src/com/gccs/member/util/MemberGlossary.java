package com.gccs.member.util;


public class MemberGlossary {
	public static final int RELATION_SHOP_Y = 1;//關係人:是
	public static final int RELATION_SHOP_N = 0;//關系人:否
	
	public static final int _member_status_disabled = 0;	//停用
	public static final int _member_status_normal = 1;		//正常
	public static final int _member_status_abnormal = 2;	//異常
	public static final int _member_status_cancel = 9;		//刪除
	
	private static final String _member_status_disabled_desc = "停用" ;
	private static final String _member_status_normal_desc = "正常" ;
	private static final String _member_status_abnormal_desc = "異常" ;
	private static final String _member_status_cancel_desc = "刪除" ;
	
	public static final int _mm_account_hq_status_disabled = 0;	//停用
	public static final int _mm_account_hq_status_normal = 1;	//正常
	
	/*
	public static final int _account_status_disabled = 0;	//停用
	public static final int _account_status_petition = 1;	//申請中
	public static final int _account_status_examine = 2;	//審核中
	public static final int _account_status_normal = 3;		//核發
	public static final int _account_status_limit = 4;		//限制採購
	public static final int _account_status_cancel = 9;		//刪除
	*/
	
	public static final int _mm_card_status_disabled = 0;	//停用
	public static final int _mm_card_status_normal = 1;		//正常
	public static final int _mm_card_status_abnormal = 2;	//異常
	public static final int _mm_card_status_deleted = 9;		//刪除

	public static final int _mm_account_status_disabled = 0 ;	//停用
	public static final int _mm_account_status_applied = 1 ;	//申請中
	public static final int _mm_account_status_submited = 2 ;	//審核中(送審)
	public static final int _mm_account_status_approved = 3 ;	//核發
	public static final int _mm_account_status_restricted = 4 ;	//限制採購
	public static final int _mm_account_status_deleted = 9 ;	//刪除
	
	public static final String _mm_account_status_disabled_desc = "停用" ;	
	public static final String _mm_account_status_applied_desc = "申請中" ;	
	public static final String _mm_account_status_submited_desc = "審核中" ;	
	public static final String _mm_account_status_approved_desc = "核發" ;	
	public static final String _mm_account_status_restricted_desc = "限制採購" ;	
	public static final String _mm_account_status_deleted_desc = "刪除" ;	

	public static final int _mm_account_acc_status_normal = 1 ;	//正常
	public static final int _mm_account_acc_status_bounced = 2 ;	//跳票
	public static final int _mm_account_acc_status_overdue = 3 ;	//應收帳款逾期
	public static final int _mm_account_acc_status_bankruptcy = 4 ;	//結束營業或倒閉
	public static final int _mm_account_acc_status_disabled = 9 ;	//停用
	
	public static final String _mm_account_acc_status_normal_desc = "正常" ;	
	public static final String _mm_account_acc_status_bounced_desc = "跳票" ;	
	public static final String _mm_account_acc_status_overdue_desc = "應收帳款逾期" ;	
	public static final String _mm_account_acc_status_bankruptcy_desc = "結束營業或倒閉" ;
	public static final String _mm_account_acc_status_disabled_desc = "停用" ;	
	
	
	public static final int _mm_account_pay_type_cash = 0 ; //現結
	public static final int _mm_account_pay_type_credit = 1 ; //月結
	public static final int _mm_account_pay_type_cash_credit = 2 ; //現結+月結
	
	public static final int _mm_card_type_normal = 0;
	public static final int _mm_card_type_business = 1;
	public static final int _mm_card_type_employee = 2;
	public static final int _mm_card_type_friends = 3;
	public static final int _mm_card_type_hq = 4;
	public static final int _mm_card_type_temp = 5;
	public static final int _mm_card_type_other = 6;
	public static final int _mm_card_type_vip = 7;
	
	public static final int _mm_card_state_notExists = 1;	//不存在系統
	public static final int _mm_card_state_duplicateId = 2; //ID 重覆
	public static final int _mm_card_state_preProducedCard = 3;  //預製卡

	public static final int _mm_market_notice_rec_disagree = 0;   //不願意
	public static final int _mm_market_notice_rec_agree = 1;      //願意
	public static final int _mm_market_notice_rec_everytime = 2;  //每檔必寄

	public static final String _mm_market_notice_rec_disagree_desc = "不願意";
	public static final String _mm_market_notice_rec_agree_desc = "願意";
	public static final String _mm_market_notice_rec_everytime_desc = "每檔必寄";
	
	public static final String _mm_market_notice_dm_desc = "DM";          //型錄/DM
	public static final String _mm_market_notice_edm_desc = "EDM";   //電子郵件(EDM)
	public static final String _mm_market_notice_tel_desc = "電話";  
	public static final String _mm_market_notice_mms_desc = "簡訊";
	
	
	private static final String _mm_card_type_normal_desc = "一般卡";
	private static final String _mm_card_type_business_desc = "商務卡";
	private static final String _mm_card_type_employee_desc = "員工卡";
	private static final String _mm_card_type_friends_desc = "親友卡";
	private static final String _mm_card_type_hq_desc = "集團卡";
	private static final String _mm_card_type_temp_desc = "臨時卡";
	private static final String _mm_card_type_other_desc = "其他卡";
	
	public static final String _mm_card_excel_import_biz_card = "商務會員匯入新增商務卡";
	
	public static String getCardTypeDesc(int type) {
		switch(type) {
			case _mm_card_type_normal : {
				return _mm_card_type_normal_desc;
			}
			case _mm_card_type_business : {
				return _mm_card_type_business_desc;
			}
			case _mm_card_type_employee : {
				return _mm_card_type_employee_desc;
			}
			case _mm_card_type_friends : {
				return _mm_card_type_friends_desc;
			}
			case _mm_card_type_hq : {
				return _mm_card_type_hq_desc;
			}
			case _mm_card_type_temp : {
				return _mm_card_type_temp_desc;
			}
			case _mm_card_type_other : {
				return _mm_card_type_other_desc;
			}
		}
		return "";
	}
	
	public static String getMemberStatusDesc(int status) {
		switch(status) {
			case _member_status_disabled : {
				return _member_status_disabled_desc;
			}
			case _member_status_normal : {
				return _member_status_normal_desc;
			}
			case _member_status_abnormal : {
				return _member_status_abnormal_desc;
			}
			case _member_status_cancel : {
				return _member_status_cancel_desc;
			}
		}
		return "";
	}
	
	public static String getAccountStatusDesc(int status) {
		switch(status) {
			case _mm_account_status_disabled : {
				return _mm_account_status_disabled_desc;
			}
			case _mm_account_status_applied : {
				return _mm_account_status_applied_desc;
			}
			case _mm_account_status_submited : {
				return _mm_account_status_submited_desc;
			}
			case _mm_account_status_approved : {
				return _mm_account_status_approved_desc;
			}
			case _mm_account_status_restricted : {
				return _mm_account_status_restricted_desc;
			}
			case _mm_account_status_deleted : {
				return _mm_account_status_deleted_desc;
			}
		}
		return "";
	}
	
	public static String getAccountAccStatusDesc(int accStatus) {
		switch(accStatus) {
			case _mm_account_acc_status_normal : {
				return _mm_account_acc_status_normal_desc;
			}
			case _mm_account_acc_status_bounced : {
				return _mm_account_acc_status_bounced_desc;
			}
			case _mm_account_acc_status_overdue : {
				return _mm_account_acc_status_overdue_desc;
			}
			case _mm_account_acc_status_bankruptcy : {
				return _mm_account_acc_status_bankruptcy_desc;
			}
			case _mm_account_acc_status_disabled : {
				return _mm_account_acc_status_disabled_desc;
			}
		}
		return "";
	}
}
