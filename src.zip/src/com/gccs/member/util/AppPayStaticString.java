package com.gccs.member.util;

public class AppPayStaticString {

	private AppPayStaticString() {
	}

	public static final String ERROR = "ERROR";
	public static final String SUCCESS = "SUCCESS";
	public static final String ERR_FORMAT = "errCode:%s,errMsg:%s";

	public static final String APP_PAY_SUM_LIST = "appPaySumList"; // 電子錢包資料
	public static final String HAS_APPPAY_MONEY = "hasAppPayMoney"; // 有電子錢包儲值金額
	public static final String HAS_APP_PAY_CARD = "hasAppPayCard"; // 有電子錢包卡號
	public static final String ORIGIN_HAS_APP_PAY_CARD = "originHasAppPayCard"; // 原會員有電子錢包卡號
	public static final String APP_PAY_MONEY = "appPayMoney"; // 電子錢包總金額
	public static final String APP_PAY_BONUS = "appPayBonus"; // 電子錢包總點數
	public static final String APP_URL = "url"; // url
	public static final String TRPAY = "TRPAY"; // 代碼對應通路

	public static final String APP_PAY_ERROR_FOR_MERGE = "[錢包餘額查詢異常,無法進行合併卡號,請稍後再試]";
	public static final String APP_PAY_ERROR_FOR_DETAIL = "[錢包餘額查詢異常,請稍後再試]"; // 電子錢包頁籤
	public static final String APP_PAY_ERROR_FOR_CARD = "[錢包帳號查詢失敗,請重新查詢]"; // 電子錢包卡號
	public static final String EXCEPTION = "系統錯誤，請洽系統管理人！";

	public static final String QURERY_CARD_TIMEOUT = "0";
	public static final String HAS_QURERY_CARD = "1";
}
