package com.gccs.member.util;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Properties;

import com.gccs.member.model.Account;
import com.sap.conn.jco.AbapException;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoTable;
import com.sap.conn.jco.ext.DestinationDataProvider;

public class SapHandler {
	static String ABAP_AS = "ABAP_AS_WITHOUT_POOL";
    static String ABAP_AS_POOLED = "ABAP_AS_WITH_POOL";
    static String ABAP_MS = "ABAP_MS_WITHOUT_POOL";
    
    public static int CREATE = 1;
    public static int MODIFY = 2;
    
    static
    {
        Properties connectProperties = new Properties();
        connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, "trtwsapqas.testritegroup.com");
        connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR,  "00");
        connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, "700");
        connectProperties.setProperty(DestinationDataProvider.JCO_USER,   "IT_GRACE");
        connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, "12345678");
        connectProperties.setProperty(DestinationDataProvider.JCO_LANG,   "en");
        createDataFile(ABAP_AS, "jcoDestination", connectProperties);

        connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, "3");
        connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT,    "10");
        createDataFile(ABAP_AS_POOLED, "jcoDestination", connectProperties);

        connectProperties.clear();
        connectProperties.setProperty(DestinationDataProvider.JCO_MSHOST, "trtwsapqas.testritegroup.com");
        connectProperties.setProperty(DestinationDataProvider.JCO_R3NAME,  "trtwsapqsa");
        connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, "700");
        connectProperties.setProperty(DestinationDataProvider.JCO_USER,   "IT_GRACE");
        connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, "12345678");
        connectProperties.setProperty(DestinationDataProvider.JCO_GROUP, "GROUP");
        connectProperties.setProperty(DestinationDataProvider.JCO_LANG,   "en");
        createDataFile(ABAP_MS, "jcoDestination", connectProperties);
    }
    
    static void createDataFile(String name, String suffix, Properties properties)
    {
        File cfg = new File(name+"."+suffix);
        if(!cfg.exists())
        {
            try
            {
                FileOutputStream fos = new FileOutputStream(cfg, false);
                properties.store(fos, "for tests only !");
                fos.close();
            }
            catch (Exception e)
            {
                throw new RuntimeException("Unable to create the destination file " + cfg.getName(), e);
            }
        }
    }
    
    
    
	public boolean uploadSap(Account account,int mode)throws JCoException{
		boolean uploadSap = false;
		
		//uploadSap code
		// 建立連線
    	JCoDestination destination = JCoDestinationManager.getDestination(ABAP_AS_POOLED);

        //取得需執行的Function
    	JCoFunction function = null;
    	if(mode == MODIFY) function = destination.getRepository().getFunction("ZCHANGE_CUSTOMER");	
    	else function = destination.getRepository().getFunction("ZCREATE_CUSTOMER");	
	        
	        //檢查有無取得function
	    	if(function == null)
	            throw new RuntimeException("BAPI_COMPANYCODE_GETLIST not found in SAP.");

	        //Date a = new Date();
	        //帶入 需upload 的資料
	        //取得抄做 table
	        JCoTable codes1 = null;
	        JCoTable codes2 = null;
	        
	        if(mode == MODIFY){
	        	codes1 = function.getTableParameterList().getTable("IT_CUSINC");
	        	codes2 = function.getTableParameterList().getTable("IT_PNRIN");
	        }else{
	        	codes1 = function.getTableParameterList().getTable("IT_CUSINS");
	        	codes2 = function.getTableParameterList().getTable("IT_PNRINS");
	        }
	        //新增一筆上傳資料
	        codes1.appendRow() ;
	        codes2.appendRow() ;
	        
	        //設定上傳資料
	        codes1.setValue("KVGR1","001") ;//客戶群組
	        codes1.setValue("EIKTO","3") ;
	        if(mode != MODIFY){
	        	codes1.setValue("KTOKD",account.getAccountId()) ;
	        }
	        codes1.setValue("KUNNR",account.getAccountId()) ;//客戶編號
	        codes1.setValue("BUKRS","1010") ;//公司代碼
	        codes1.setValue("VKORG","") ;//銷售組織
	        codes1.setValue("VTWEG","") ;//配銷通路
	        codes1.setValue("SPART","") ;//部門
	        codes1.setValue("ANRED","") ;//標題
	        
	        
	        String [] companyNames = getCompanyName(account.getCompanyName1());
	        codes1.setValue("NAME1",companyNames[0]) ;
	        codes1.setValue("NAME2",companyNames[1]) ;
	        codes1.setValue("NAME3",companyNames[2]) ;
	        codes1.setValue("NAME4",companyNames[3]) ;
	      
	        
	        codes1.setValue("SORT1"," ") ;//搜尋條件1
	        
	        String [] addr = getAddr(account.getComAddr5());
	        codes1.setValue("STREET",addr[0]) ;//街道
	        codes1.setValue("STR_SUPP",addr[1]) ;//街道2
	        codes1.setValue("STR_SUPP",addr[2]) ;//街道2
	        codes1.setValue("STR_SUPP",addr[3]) ;//街道2
	        codes1.setValue("LOCATION",addr[4]) ;//街道2
	        codes1.setValue("POST_CODE1",account.getComAddr2()) ;
	        codes1.setValue("CITY1", account.getComAddr3()+account.getComAddr4());
	        codes1.setValue("COUNTRY", "");
	        codes1.setValue("REGION", "");
	        codes1.setValue("LANGU", "");
	        codes1.setValue("TEL_NUMBER", account.getComTel());
	        codes1.setValue("TEL_EXTENS", account.getComExt());
	        codes1.setValue("TELF2", "");
	        codes1.setValue("FAX_NUMBER", account.getComFax());
	        codes1.setValue("FAX_EXTENS", "");
	        codes1.setValue("SMTP_ADDR", "");
	        codes1.setValue("STCEG", "");
	        codes1.setValue("ZTERM", "");
	        codes1.setValue("BZIRK", account.getSaleDistrict());
	        codes1.setValue("WAERS", account.getCurrency());
	        codes1.setValue("KALKS", account.getCustPricingProc());
	        codes1.setValue("ZTERM1", account.getPayDay());
	        codes1.setValue("KTGRD", account.getRelationship());
	        codes1.setValue("TAXKD", account.getTaxClass());
	        codes1.setValue("KKBER", "");
	        codes1.setValue("KLIMK", account.getCreditAmt());
	        codes1.setValue("CTLPIC", "");
	        
	        
	        
	        codes2.setValue("KVGR1", "001");
	        codes2.setValue("EIKTO", "");
	        codes2.setValue("PAFKT", "");//聯絡人職責
	        codes2.setValue("NAME1", account.getOthName());
	        codes2.setValue("PARLA", "");
	        codes2.setValue("TEL_NUMBER", account.getOthCantactTel());
	        codes2.setValue("TEL_EXTENS", account.getOthCantactExt());
	        codes2.setValue("TELF2", "");
	        codes2.setValue("FAX_NUMBER", "");
	        codes2.setValue("FAX_EXTENS", "");
	        codes2.setValue("SMTP_ADDR", account.getOthEmail());
	        /*
	        codes1.setValue(0,"2") ;
	        codes1.setValue(1,"DM") ;
	        codes1.setValue(2,"2") ;
	        codes1.setValue(3,"2") ;
	        codes1.setValue(8,"2") ;
	        codes1.setValue(9,"2") ;
	        codes1.setValue(10,"2") ;
	        */
	        try
	        {
	        	//執行上傳
	            function.execute(destination);
	        }
	        catch(AbapException e)
	        {
	        	uploadSap = true;
	            System.out.println(e.toString());
	            
	        }
	        

	        // 取的回復資料
	        JCoTable rtCodes1 = null;
	        JCoTable rtCodes2 = null;
	        
	        if(mode == MODIFY){
	        	rtCodes1 = function.getTableParameterList().getTable("IT_CUSRET");
	        	rtCodes2 = function.getTableParameterList().getTable("IT_PNRRET");
	        }else{
	        	rtCodes1 = function.getTableParameterList().getTable("IT_CUSRETS");
	        	rtCodes2 = function.getTableParameterList().getTable("IT_PNRRETS");
	        }
	        
	        //印出回復資料
	        System.out.println("列印「客戶主檔回傳訊息」");
	        for (int i = 0; i < rtCodes1.getNumRows(); i++) 
	        {
	        	rtCodes1.setRow(i);
	            System.out.println(rtCodes1.getString(0) + ',' + rtCodes1.getString(1)+ ',' + rtCodes1.getString(2));
	        }
	        
	        System.out.println("列印「客戶聯絡人回傳訊息」");
	        for (int i = 0; i < rtCodes2.getNumRows(); i++) 
	        {
	        	rtCodes2.setRow(i);
	            System.out.println(rtCodes2.getString(0) + ',' + rtCodes2.getString(1)+ ',' + rtCodes2.getString(2));
	        }
	        
		return uploadSap;
	}
	
	private static String[] getCompanyName(String companyName){
		String [] tempCN = new String[4];
		
        if(companyName!=null && companyName.length()>0){
        	if(companyName.length()<=40){
        		tempCN[0] = companyName ;//名稱1
        	}
        	if(companyName.length()>40 && companyName.length()<=80){
        		tempCN[0] = companyName.substring(0,40);
    			tempCN[1] = companyName.substring(40,companyName.length());
    		}
        	
        	if(companyName.length()>80 && companyName.length()<=120){
        		tempCN[0] = companyName.substring(0,40);
        		tempCN[1] = companyName.substring(40,80);
    			tempCN[2] = companyName.substring(80,companyName.length());
    		}
        	
        	if(companyName.length()>160){
        		tempCN[0] = companyName.substring(0,40);
        		tempCN[1] = companyName.substring(40,80);
    			tempCN[2] = companyName.substring(80,120);
    			tempCN[3] = companyName.substring(120,160);
    		}
        	
        }
        
		return tempCN;
	}
	private static String[] getAddr(String companyAddr){
		String [] temp = new String[5];
		
        if(companyAddr!=null && companyAddr.length()>0){
        	if(companyAddr.length()<=60){
        		temp[0] = companyAddr ;//名稱1
        	}
        	
        	if(companyAddr.length()>60 && companyAddr.length()<=100){
        		temp[0] = companyAddr.substring(0,60);
    			temp[1] = companyAddr.substring(60,companyAddr.length());
    		}
        	
        	if(companyAddr.length()>100 && companyAddr.length()<=140){
        		temp[0] = companyAddr.substring(0,60);
        		temp[1] = companyAddr.substring(60,100);
    			temp[2] = companyAddr.substring(100,companyAddr.length());
    		}
        	
        	if(companyAddr.length()>140 && companyAddr.length()<=180){
        		temp[0] = companyAddr.substring(0,60);
        		temp[1] = companyAddr.substring(60,100);
        		temp[2] = companyAddr.substring(100,140);
    			temp[3] = companyAddr.substring(140,companyAddr.length());
    		}
        	
        	if(companyAddr.length()>180){
        		temp[0] = companyAddr.substring(0,60);
        		temp[1] = companyAddr.substring(60,100);
        		temp[2] = companyAddr.substring(100,140);
        		temp[3] = companyAddr.substring(140,180);
    			temp[4] = companyAddr.substring(180,companyAddr.length());
    		}
        	
        }
        
		return temp;
	}
	
	public static void main(String args[]){
		String [] tempCN = new String[4];
		String companyName= "台灣福雷電子股份";
        if(companyName!=null && companyName.length()>0){
        	if(companyName.length()<=4){
        		System.out.println("-->p1");
        		tempCN[0] = companyName ;//名稱1
        	}
        	if(companyName.length()>4 && companyName.length()<=8){
        		System.out.println("-->p2");
        		tempCN[0] = companyName.substring(0,4);
    			tempCN[1] = companyName.substring(4,companyName.length());
    		}
        	
        	if(companyName.length()>8 && companyName.length()<=12){
        		System.out.println("-->p3");
        		tempCN[0] = companyName.substring(0,4);
        		tempCN[1] = companyName.substring(4,8);
    			tempCN[2] = companyName.substring(8,companyName.length());
    		}
        	
        	if(companyName.length()>12){
        		System.out.println("-->p4");
        		tempCN[0] = companyName.substring(0,4);
        		tempCN[1] = companyName.substring(4,8);
    			tempCN[2] = companyName.substring(8,12);
    			tempCN[3] = companyName.substring(12,16);
    		}
        	
        }
        for(int i=0;i<tempCN.length;i++){
        	System.out.println("Name"+(i+1)+": "+tempCN[i]);
        }
	}
}
