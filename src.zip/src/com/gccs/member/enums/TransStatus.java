package com.gccs.member.enums;

public enum TransStatus {
	ALL,		
	//正常交易
	NORMAL,		
	//正常作廢
	NormalCancel,
	//退貨交易
	Reject,
	//退貨作廢
	RejectCancel
}
