package com.gccs.member.action;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.gccs.base.action.BaseAction;
import com.gccs.member.service.MemberCouponDetailReportService;
import com.gccs.report.jxlexcel.CouponJxlActionImpl;
import com.rfep.base.JxlExcelBean;
import com.rfep.base.JxlExcelUtils;

public class MemberCouponSummaryRptAction extends BaseAction {

	private static final long serialVersionUID = 5585883449527292087L;
	
	private Logger log = Logger.getLogger(MemberCouponSummaryRptAction.class);
	// 固定常用session key值
	private static final String QUERY_CONDITION = "queryCondition";

	private MemberCouponDetailReportService memberCouponDetailReportService;
	private String year;
	private String month;
	private String channelId;
	
	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	/**
	 * 程式初始化動作
	 * 
	 * @return Struts導頁Result設定
	 */
	public String doEntry() {
		getSessionMap().remove(QUERY_CONDITION);

		return SUCCESS;
	}
	
	public String doPageEntry() {
		getSessionMap().remove(QUERY_CONDITION);

		return SUCCESS;
	}

	/**
	 * 執行報表
	 * 
	 * @return
	 */	
	public String doReport() {
		
		// 1621 >>> /RFEP/jsp/member/mmCouponSummaryRptLoad.action?formId=RPT050
		String jxlExcelFileName = "折價券發放統計表";
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		//用於存放JxlExcel的物件
		Map mapJxlExcel=new HashMap();
		try {
			HttpServletResponse response = ServletActionContext.getResponse();
			//取得工作簿並存在map內
			mapJxlExcel.put("WritableWorkbook-wb", Workbook.createWorkbook(output));
			JxlExcelBean jxlExcelBean= new JxlExcelBean(jxlExcelFileName);
			jxlExcelBean.setResponse(response);
			
			Map queryCondition = getQueryCondition();
			
			List<Map<String,Object>> result = memberCouponDetailReportService.getCouponDetailSummaryReport(queryCondition);
			
			CouponJxlActionImpl couponJxlActionImpl = new CouponJxlActionImpl();
			couponJxlActionImpl.getData1621(result, mapJxlExcel);

			if((WritableSheet)mapJxlExcel.get("WritableSheet-sheet1")!=null){
				((WritableWorkbook)mapJxlExcel.get("WritableWorkbook-wb")).write();
				((WritableWorkbook)mapJxlExcel.get("WritableWorkbook-wb")).close();
				JxlExcelUtils jxl = new JxlExcelUtils();
				jxl.genEXCELtoWeb(jxlExcelBean,output.toByteArray());
			}else{
				addActionError(getText("execule.fail")+"：Excel產生其失敗原因：sheet為null<br>");
				return ERROR;
			}
			

		} catch (Throwable e) {
			e.printStackTrace();
			log.error(e);
			addActionError(getText("execule.fail")+"："+e.getMessage());
			return ERROR;

		}
		return NONE;
	}
	
	/**
	 * 執行消費異常月報報表
	 * 
	 * @return
	 */	
	public String doPageReport() {
		
		// 1622 >>> /RFEP/jsp/member/mmAbnormalConsumptionLoad.action?formId=RPT052
		OutputStream output = null;
		try {
			//查詢清單
			List<Map<String,Object>> result = memberCouponDetailReportService.getAbnormalConsumptionReport(year,month,channelId);
			HttpServletResponse response = ServletActionContext.getResponse();
			response.reset();
			response.setContentType("application/x-download");
			String fileNameUTF8 = java.net.URLEncoder.encode("消費異常月報", "UTF-8") + ".xls";
			//String fileName = new String("消費異常月報".getBytes("big5"),"ISO8859-1");
			response.setHeader("Content-disposition", "attachment ; filename*=utf-8''"+fileNameUTF8);
			//response.setHeader("Content-disposition","attachment;filename=\""+fileName +".xls");
			output = response.getOutputStream();
			//產生excel檔
			WritableWorkbook wb = Workbook.createWorkbook(output);			
			WritableSheet ws = wb.createSheet("Sheet1", 0);
			ws.addCell(new Label(0, 0, "通路"));
			ws.addCell(new Label(1, 0, "店別"));
			ws.addCell(new Label(2, 0, "交易日期"));
			ws.addCell(new Label(3, 0, "機號"));
			ws.addCell(new Label(4, 0, "交易序號"));
			ws.addCell(new Label(5, 0, "發票號碼"));
			ws.addCell(new Label(6, 0, "發票金額"));
			ws.addCell(new Label(7, 0, "卡號"));
			ws.addCell(new Label(8, 0, "卡別"));
			ws.addCell(new Label(9, 0, "消費次數"));
			int i = 0;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			for (Map<String, Object> map : result) {
				ws.addCell(new Label(0, i+1, (String)map.get("CHANNEL_ID")));
				ws.addCell(new Label(1, i+1, (String)map.get("STORE_ID")));
				ws.addCell(new Label(2, i+1, sdf.format(((Date)map.get("TRANS_DATE")))));
				ws.addCell(new Label(3, i+1, (String)map.get("POS_NOS")));
				ws.addCell(new Label(4, i+1, (String)map.get("SER_NOS")));
				ws.addCell(new Label(5, i+1, (String)map.get("GUI_NOS")));
				ws.addCell(new Label(6, i+1, (((BigDecimal)map.get("TRANS_TOT"))).toString()));
				ws.addCell(new Label(7, i+1, (String)map.get("CUST_NOS")));
				ws.addCell(new Label(8, i+1, (String)map.get("CARD_NAME")));
				ws.addCell(new Label(9, i+1, (((BigDecimal)map.get("CONSUMPTION_COUNT"))).toString()));
				i++;
			}
			//下載excel檔
			wb.write(); 
			wb.close();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			this.addActionError(e.getMessage());
		}finally {
			try {
				if(output != null) {
					output.flush();
					output.close();
				}
			}
			catch (IOException e) {
				e.printStackTrace();
				log.error(e.getMessage(), e);
				this.addActionError(e.getMessage());
			}
		}
		return NONE;
	}


	public void setMemberCouponDetailReportService(
			MemberCouponDetailReportService memberCouponDetailReportService) {
		this.memberCouponDetailReportService = memberCouponDetailReportService;
	}

	public MemberCouponDetailReportService getMemberCouponDetailReportService() {
		return memberCouponDetailReportService;
	}
}
