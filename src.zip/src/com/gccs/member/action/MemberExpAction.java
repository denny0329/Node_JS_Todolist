package com.gccs.member.action;

import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.bnq.util.QueryResult;
import com.gccs.member.model.MmMembersExp;
import com.gccs.member.model.MmMembersExpId;
import com.gccs.member.model.condition.MemberCondition;
import com.opensymphony.xwork2.Action;

@SuppressWarnings("unchecked")
public class MemberExpAction extends MemberHeadquartersAction {	
	private static final long serialVersionUID = 197791785412318937L;

	private static final String ERROR_MSG = "程式發生錯誤，請洽系統人員！";
	private List<MmMembersExp> expList;
	private List<MmMembersExpId> expIdList;
	private MmMembersExpId expId;
	
	public List<MmMembersExp> getExpList() {
		return expList;
	}
	public void setExpList(List<MmMembersExp> expList) {
		this.expList = expList;
	}	
	public List<MmMembersExpId> getExpIdList() {
		return expIdList;
	}
	public void setExpIdList(List<MmMembersExpId> expIdList) {
		this.expIdList = expIdList;
	}	
	public MmMembersExpId getExpId() {
		return expId;
	}
	public void setExpId(MmMembersExpId expId) {
		this.expId = expId;
	}
	
	/**************************************************************************/
	
	public String doQuery() {
		try {
			if(!this.hasToCountTotal()) {
				MemberCondition p = (MemberCondition)this.getSessionMap().get(MEMBER_CONDITION);
				this.setCondition(p);
			} else {
				this.getSessionMap().put(MEMBER_CONDITION, this.getCondition());
				this.getPageBean().setJumpPage("");
			}

			QueryResult result = memberService.findMemberExpByCondition(this.getCondition(), this.getQueryStartIndex(),
					this.getPageBean().getPageSize(), this.hasToCountTotal());

			this.setPageBeanByQueryResult(result,"doQuery");
			this.getSessionMap().put(MEMBER_PAGEBEAN, this.getPageBean());

		} catch(Throwable t) {
			t.printStackTrace();
			addActionError(ERROR_MSG);	
		}

		return Action.SUCCESS;
	}

	public String doEdit() throws Exception {
		try {											
			if(this.expId != null) {				
				super.doLoadMember(this.memberService.queryMemberOidByPersoId(this.expId.getPersonId()));					
				MmMembersExp exp = this.memberService.findMembersExpById(this.expId);				
				
				if(StringUtils.isNotEmpty(exp.getName())) {
					this.getMembers().setName(exp.getName());
				}
				if(exp.getSex() != null) {
					this.getMembers().setSex(exp.getSex());
				}
				if(exp.getBirthdayYy() != null) {
					this.getMembers().setBirthdayYy(exp.getBirthdayYy());
				}
				if(exp.getBirthdayMm() != null) {
					this.getMembers().setBirthdayMm(exp.getBirthdayMm());
				}
				if(exp.getBirthdayDd() != null) {
					this.getMembers().setBirthdayDd(exp.getBirthdayDd());
				}				
				if(StringUtils.isNotEmpty(exp.getCantactTel())) {
					this.getMembers().setCantactTel(exp.getCantactTel());
				}
				if(StringUtils.isNotEmpty(exp.getFaxNo())) {
					this.getMembers().setFaxNo(exp.getFaxNo());
				}
				if(StringUtils.isNotEmpty(exp.getCellPhone())) {
					this.getMembers().setCellPhone(exp.getCellPhone());
				}				
				if(StringUtils.isNotEmpty(exp.getCantactAddr2())) {
					this.getMembers().setCantactAddr2(exp.getCantactAddr2());
				}
				if(StringUtils.isNotEmpty(exp.getCantactAddr5())) {
					this.getMembers().setCantactAddr5(exp.getCantactAddr5());
				}
			}	
			
			this.setExpList(this.memberService.findMembersExp(this.getMembers().getPersonId()));
		} catch(Throwable t) {
			t.printStackTrace();
			addActionError(ERROR_MSG);	
		}
						
		return Action.SUCCESS;
	}
	
	public String doChange() {							
		try {					
			this.memberService.doExpChange(this.expIdList, this.getUser().getUserId(), this.getUser().getUserName());
			this.setExpList(this.memberService.findMembersExp(this.getMembers().getPersonId()));						
		} catch (Throwable t) {	
			t.printStackTrace();
			addActionError(ERROR_MSG);			
		}
		return Action.SUCCESS;
	}
	
	public boolean isDisabledChange() {
		return (this.expList==null || this.expList.size()<=0) ? true : false;
	}
}
