package com.gccs.member.action;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.bnq.util.QueryResult;
import com.gccs.base.action.BaseAction;
import com.gccs.member.card.model.MmCard;
import com.gccs.member.model.Account;
import com.gccs.member.model.MmAccAttach;
import com.gccs.member.model.MmArBank;
import com.gccs.member.model.condition.AccountCondition;
import com.gccs.member.rfc.MemberAccountRfc;
import com.gccs.member.rfc.MemberCardRfc;
import com.gccs.member.service.AccountService;
import com.gccs.member.service.ICardService;
import com.gccs.member.service.MemberService;
import com.opensymphony.xwork2.Action;

/* 程式的處理
 * @author neo
 */
public class MemberBusinessGrantAction extends BaseAction {
	private static final long serialVersionUID = -562038068383123864L;

	private AccountCondition condition;

	private static String _session_key_bissinessGrant_query = "_session_bissinessGrant_query";
	//private static String _session_key_bissinessGrant = "_session_bissinessGrant";
	private static String _session_key_bissinessGrant_account = "_session_bissinessGrant_account";
	private MemberService memberService;
	private AccountService accountService;
	private ICardService cardService;
	private List<MmArBank> bankIdList;
	private List<MmArBank> branchIdList;
	private List<MmArBank> bankDescList;
	private List<MmAccAttach> accAttachList;
	private MemberAccountRfc memberAccountRfc;

	//private Account account;
	public AccountService getAccountService() {
		return accountService;
	}
	public void setAccountService(AccountService accountService) {
		this.accountService = accountService;
	}
	public AccountCondition getCondition() {
		return condition;
	}
	public void setCondition(AccountCondition condition) {
		this.condition = condition;
	}

	public MemberService getMemberService() {
		return memberService;
	}
	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}

	public ICardService getCardService() {
		return cardService;
	}
	public void setCardService(ICardService cardService) {
		this.cardService = cardService;
	}
	public Account getAccount() {
		Account account = (Account)this.getSessionMap().get(_session_key_bissinessGrant_account);
		if(account == null) {
			account = new Account();
			setAccount(account);
		}
		return account;
	}
	public void setAccount(Account account) {
		this.getSessionMap().put(_session_key_bissinessGrant_account, account);
	}
	public String doBusinessGrantQuery(){

		this.getCondition().setNeStatus_1("1");
		this.getCondition().setNeStatus_2("2");
		try {
			if(!this.hasToCountTotal()) {
				AccountCondition p = (AccountCondition)this.getSessionMap().get(_session_key_bissinessGrant_query);
				this.setCondition(p);
			} else {
				this.getSessionMap().put(_session_key_bissinessGrant_query, this.getCondition());
				this.getPageBean().setJumpPage("");
			}

			QueryResult result = accountService.findAccountByCondition(this.getCondition(), this.getQueryStartIndex(),
					this.getPageBean().getPageSize(), this.hasToCountTotal());

			this.setPageBeanByQueryResult(result,"doBusinessGrantQuery");

		} catch(Exception e) {
			e.printStackTrace();
		}
		return Action.SUCCESS;
	}
	public String doIndexBusinessGrant(){
		this.getSessionMap().remove(_session_key_bissinessGrant_query);
		return Action.SUCCESS;
	}

	public String doBusinessGrantEdit() throws Exception{
		String oid  = this.getRequest().getParameter("oid");
		doLoadAccont(oid);

		setMmArBankVal();
		setAccAttachList(this.getAccountService().selectMmAccAttachOrTmpAndCovert(getAccount().getAccountId(), getAccount().getStatus()));
		return Action.SUCCESS;
	}
	
	private void setMmArBankVal() throws Exception {
		MmArBank arBank = new MmArBank();
		bankIdList = memberService.selectMmArBank(arBank);
		arBank.setBankId(getAccount().getArBkId());
		branchIdList = memberService.selectMmArBank(arBank);
		arBank.setBranchId(getAccount().getArBranchId());
		bankDescList = memberService.selectMmArBank(arBank);
	}

	public String doBusinessGrantView() throws Exception{
		String oid  = this.getRequest().getParameter("oid");
		doLoadAccont(oid);

		setMmArBankVal();
		setAccAttachList(this.getAccountService().selectMmAccAttachOrTmpAndCovert(getAccount().getAccountId(), getAccount().getStatus()));
		return Action.SUCCESS;

	}



	public String doBusinessGrantExit(){

		try {
			AccountCondition p = (AccountCondition)this.getSessionMap().get(_session_key_bissinessGrant_query);
			if(p==null){
				return Action.SUCCESS;
			}
			this.setCondition(p);

			QueryResult result = accountService.findAccountByCondition(this.getCondition(), this.getQueryStartIndex(),
					this.getPageBean().getPageSize(), this.hasToCountTotal());
			this.getPageBean().setJumpPage("");
			this.setPageBeanByQueryResult(result,"doBusinessGrantQuery");

		} catch(Exception e) {
			this.addActionError("載入失敗:"+e.getMessage()+"，請洽系統管理人員.") ;
			e.printStackTrace();
			return ERROR;
		}
		return Action.SUCCESS;
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public String doBusinessGrantSave() throws Exception{
		//Account oldAccount = this.getAccountService().loadBusinessAccountByOid(this.account.getOid());
        Account account = getAccount();

        Account updateObject = this.getAccountService().findAccountByOid(account.getOid());
		if (null != updateObject.getCreditAmt()) {
			updateObject.setLastCreditAmt(updateObject.getCreditAmt());
		}
		if (null != updateObject.getPromiseForm()) {
			updateObject.setLastPromiseFrom(updateObject.getPromiseForm());
		}
		if (null != updateObject.getPromiseTo()) {
			updateObject.setLastPromiseTo(updateObject.getPromiseTo());
		}
		if (StringUtils.isNotBlank(updateObject.getApproveId())) {
			updateObject.setLastApproveId(updateObject.getApproveId());
		}
		updateObject.setModifier(this.getUser().getUserId());
		updateObject.setModifierName(this.getUser().getUserName());
		updateObject.setModifyTime(new Date());
		updateObject.setApproveId(this.getUser().getUserId());
		updateObject.setApproveName(this.getUser().getUserName());
		updateObject.setApproveTime(new Date());
		updateObject.setPayDay(account.getPayDay());
		updateObject.setOverdue(account.getOverdue());
		updateObject.setPromiseForm(account.getPromiseForm());
		updateObject.setPromiseTo(account.getPromiseTo());
		updateObject.setPurchaseForm(account.getPurchaseForm());
		updateObject.setPurchaseTo(account.getPurchaseTo());
		updateObject.setRestraint(account.getRestraint());
		updateObject.setReturnYn(account.getReturnYn());
		updateObject.setPayIn(account.getPayIn());
		updateObject.setQouteYn(account.getQouteYn());
		updateObject.setStatus(account.getStatus());
		updateObject.setAccStatus(account.getAccStatus());
		
		updateObject.setCreditAmt(account.getCreditAmt());
		updateObject.setTaxClass(account.getTaxClass());
		updateObject.setCurrency(account.getCurrency());
		//判斷是否為關係人
		updateObject.setRelationship(account.getRelationship());
		updateObject.setSapCustNo(account.getSapCustNo());
		updateObject.setKeyinSapCustNo(account.getKeyinSapCustNo());
		updateObject.setArBkId(account.getArBkId());
		updateObject.setArBranchId(account.getArBranchId());
		updateObject.setArAccId(account.getArAccId());
		//上傳SAP
		System.out.println(" uploadSap : " + updateObject.getUploadSap());
		if(updateObject.getUploadSap()!=null && updateObject.getUploadSap()){
			try{
				System.out.println(" 執行上傳SAP ======================= ");
				if( !getMemberAccountRfc().execute(updateObject) ){
					this.addActionMessage("執行上傳SAP失敗 : " + updateObject.getSapMessage());
				}
				else{
					//上傳SAP-卡
					List<MmCard> cards = cardService.findMmCardByAccountIdCardType(updateObject.getAccountId(), null);
					if( cards != null && cards.size() > 0 ){
						MemberCardRfc cardRfc = new MemberCardRfc();
						cardRfc.execute(updateObject.getAccountId(), cards);
					}
				}
			}catch(Exception e){
				this.addActionMessage("執行上傳SAP失敗 : " + e.getMessage());
			}
		}

		this.accountService.updateAccount(updateObject);

		setAccount(updateObject);
		setMmArBankVal();
		setAccAttachList(this.getAccountService().selectMmAccAttachOrTmpAndCovert(getAccount().getAccountId(), getAccount().getStatus()));
		return Action.SUCCESS;
	}
	
	private void doLoadAccont(String oid) throws Exception{
		setAccount(this.getAccountService().findAccountByOid(oid));
	}
	public List<MmArBank> getBankIdList() {
		return bankIdList;
	}
	public void setBankIdList(List<MmArBank> bankIdList) {
		this.bankIdList = bankIdList;
	}
	public List<MmArBank> getBranchIdList() {
		return branchIdList;
	}
	public void setBranchIdList(List<MmArBank> branchIdList) {
		this.branchIdList = branchIdList;
	}
	public List<MmArBank> getBankDescList() {
		return bankDescList;
	}
	public void setBankDescList(List<MmArBank> bankDescList) {
		this.bankDescList = bankDescList;
	}
	public List<MmAccAttach> getAccAttachList() {
		return accAttachList;
	}
	public void setAccAttachList(List<MmAccAttach> accAttachList) {
		this.accAttachList = accAttachList;
	}
	public MemberAccountRfc getMemberAccountRfc() {
		return memberAccountRfc;
	}
	public void setMemberAccountRfc(MemberAccountRfc memberAccountRfc) {
		this.memberAccountRfc = memberAccountRfc;
	}

}