package com.gccs.member.action;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ExecuteAndWaitInterceptor;

import com.apeo.sender.model.MessageContent;
import com.bnq.sc.model.ScSysuser;
import com.bnq.util.DateUtils;
import com.bnq.util.QueryResult;
import com.bnq.util.mail.MailService;
import com.gccs.base.action.BaseAction;
import com.gccs.member.model.condition.AccountCondition;
import com.gccs.member.service.IAccountService;
import com.gccs.mp.report.service.MpReportService;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.rfep.util.sys.service.CassetteJobTimeAndMailNotifyService;

@SuppressWarnings("all")
public class MemberBusinessReportAction extends BaseAction {
	private static final long serialVersionUID = -5493530933759926238L;

	private static final Logger log = LogManager.getLogger(MemberBusinessReportAction.class);

	private AccountCondition condition;

	private IAccountService accountService;

	public AccountCondition getCondition() {
		return condition;
	}

	public void setCondition(AccountCondition condition) {
		this.condition = condition;
	}

	public IAccountService getAccountService() {
		return accountService;
	}

	public void setAccountService(IAccountService accountService) {
		this.accountService = accountService;
	}

	public String queryAccountRpt() {
		return Action.SUCCESS;
	}

	public List doExcelAndMail(){
		OutputStream output = null;
		List attachmentsList = new ArrayList();
		try {
			QueryResult result = accountService.findAccountRptByCondition(this.getCondition(),0, 0, false);

			File file = new File("bussinessRpt.xls");
			output = new FileOutputStream(file);
			WritableWorkbook wb = Workbook.createWorkbook(output);
			WritableSheet ws = wb.createSheet("商務會員報表", 0);

			ws.addCell(new Label(0, 0, "商務帳號"));
			ws.addCell(new Label(1, 0, "公司名稱"));
			ws.addCell(new Label(2, 0, "統一編號"));
			ws.addCell(new Label(3, 0, "業務人員"));
			ws.addCell(new Label(4, 0, "行業別1"));
			ws.addCell(new Label(5, 0, "行業別2"));
			ws.addCell(new Label(6, 0, "折扣卡代號"));
			ws.addCell(new Label(7, 0, "繳款別"));			
			ws.addCell(new Label(8, 0, "帳號狀態"));
			ws.addCell(new Label(9, 0, "應收帳款"));
			ws.addCell(new Label(10, 0, "信用額度"));
			ws.addCell(new Label(11, 0, "保證函起日"));
			ws.addCell(new Label(12, 0, "保證函迄日"));
			ws.addCell(new Label(13, 0, "SAP客戶代號"));
			ws.addCell(new Label(14, 0, "縣市"));
			ws.addCell(new Label(15, 0, "郵遞區號"));
			ws.addCell(new Label(16, 0, "區"));
			ws.addCell(new Label(17, 0, "地址"));
			ws.addCell(new Label(18, 0, "聯絡人"));
			ws.addCell(new Label(19, 0, "聯絡人性別"));
			ws.addCell(new Label(20, 0, "聯絡人電話"));
			ws.addCell(new Label(21, 0, "聯絡人電話分機"));
			ws.addCell(new Label(22, 0, "聯絡人電話手機"));
			ws.addCell(new Label(23, 0, "聯絡人Email"));
			ws.addCell(new Label(24, 0, "VIP_NO"));
			ws.addCell(new Label(25, 0,  "卡別"));
			ws.addCell(new Label(26, 0,  "卡片狀態"));
			ws.addCell(new Label(27, 0, "會員姓名"));
			ws.addCell(new Label(28, 0, "會員性別"));
			ws.addCell(new Label(29, 0, "縣市"));
			ws.addCell(new Label(30, 0, "郵遞區號"));
			ws.addCell(new Label(31, 0, "區"));
			ws.addCell(new Label(32, 0, "地址"));
			ws.addCell(new Label(33, 0, "會員電話"));
			ws.addCell(new Label(34, 0, "會員手機"));
			ws.addCell(new Label(35, 0, "是否退件"));
			ws.addCell(new Label(36, 0, "TLW行銷訊息"));
			ws.addCell(new Label(37, 0, "HOLA行銷訊息"));

			int row = 1;
			for (Object obj : result.getResult()) {
				Map<String, Object> map = (Map<String, Object>) obj;
				ws.addCell(new Label(0, row, (String) map.get("ACCOUNT_ID")));
				ws.addCell(new Label(1, row, (String) map.get("COMAPANY_NAME2")));
				ws.addCell(new Label(2, row, (String) map.get("GUINO")));
				ws.addCell(new Label(3, row, (String) map.get("TYPE_NAME")));
				ws.addCell(new Label(4, row, (String) map.get("CODE_NAME1")));
				ws.addCell(new Label(5, row, (String) map.get("CODE_NAME2")));
				ws.addCell(new Label(6, row, (String) map.get("DISCOUNT_CARD_NAME")));
				ws.addCell(new Label(7, row, (String) map.get("PAY_TYPE")));
				ws.addCell(new Label(8, row, (String) map.get("STATUS")));
				ws.addCell(new Label(9, row, String.valueOf(map.get("AR_AMOUNT")).replace("null", "")));
				ws.addCell(new Label(10, row, String.valueOf(map.get("CREDIT_AMT")).replace("null", "")));
				ws.addCell(new Label(11, row, DateUtils.cdateFormat((Date) map.get("PROMISE_FROM"))));
				ws.addCell(new Label(12, row, DateUtils.cdateFormat((Date) map.get("PROMISE_TO"))));
				ws.addCell(new Label(13, row, (String) map.get("SAP_CUST_NO")));
				ws.addCell(new Label(14, row, (String) map.get("CODE_EXPLAIN")));
				ws.addCell(new Label(15, row, (String) map.get("COM_ADDR2")));
				ws.addCell(new Label(16, row, (String) map.get("CODE_EXPLAIN1")));
				ws.addCell(new Label(17, row, (String) map.get("COM_ADDR5")));
				ws.addCell(new Label(18, row, (String) map.get("OTH_NAME")));
				ws.addCell(new Label(19, row, (String) map.get("OTH_SEX")));
				ws.addCell(new Label(20, row, (String) map.get("OTH_CANTACT_TEL")));
				ws.addCell(new Label(21, row, (String) map.get("OTH_CANTACT_EXT")));
				ws.addCell(new Label(22, row, (String) map.get("OTH_CELL_PHONE")));
				ws.addCell(new Label(23, row, (String) map.get("OTH_EMAIL")));
				ws.addCell(new Label(24, row, (String) map.get("VIP_NO")));
				ws.addCell(new Label(25, row, (String) map.get("CARD_TYPE")));
				ws.addCell(new Label(26, row, String.valueOf(map.get("CARD_STATUS")).replace("null", "")));
				ws.addCell(new Label(27, row, (String) map.get("NAME")));
				ws.addCell(new Label(28, row, (String) map.get("SEX")));
				ws.addCell(new Label(29, row, (String) map.get("M_CODE_EXPLAIN")));
				ws.addCell(new Label(30, row, (String) map.get("M_CANTACT_ADD4")));
				ws.addCell(new Label(31, row, (String) map.get("M_CODE_EXPLAIN1")));
				ws.addCell(new Label(32, row, (String) map.get("M_CANTACT_ADD5")));
				ws.addCell(new Label(33, row, (String) map.get("M_CANTACT_TEL")));
				ws.addCell(new Label(34, row, (String) map.get("M_CELL_PHONE")));
				ws.addCell(new Label(35, row, String.valueOf(map.get("DM_RETURN")).replace("null", "")));
				ws.addCell(new Label(36, row, (String) map.get("TLW_M")));
				ws.addCell(new Label(37, row, (String) map.get("HOLA_M")));
				
				row++;
			}

			wb.write();
			wb.close();
			attachmentsList.add(file);
		} catch (Exception e) {
			e.printStackTrace();
			this.addActionError("匯出發生失敗: " + e.getMessage());
		} finally {
			try {
				if (output != null) {
					output.flush();
					output.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
				log.error(e.getMessage(), e);
				this.addActionError(e.getMessage());
			}
		}
		return attachmentsList;
	}
	
	public String doExport() {
		
		new Thread(new Runnable() {
			ScSysuser user = (ScSysuser)ActionContext.getContext().getSession().get("user");
			public void run() {
				try {
					String subject = "商務會員報表";
					String receiverList = user.getEMail();
					List attachments = MemberBusinessReportAction.this.doExcelAndMail();
					MailService.sendMessage("", subject,receiverList, "", attachments);
							
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}).start();
		return Action.SUCCESS;
	}

	public String doquery() {
		try {
			QueryResult result = accountService.findAccountRptByCondition(this.getCondition(),this.getQueryStartIndex(),
					 this.getPageBean().getPageSize(), this.hasToCountTotal());
			 
			this.setPageBeanByQueryResult(result, "doquery");
		} catch (Exception e) {
			e.printStackTrace();
			this.addActionError("查詢發生失敗: " + e.getMessage());
		}
		return Action.SUCCESS;
	}

}