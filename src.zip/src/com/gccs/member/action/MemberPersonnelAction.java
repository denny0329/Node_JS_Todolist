package com.gccs.member.action;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.QueryResult;
import com.gccs.member.model.Members;
import com.gccs.member.model.condition.MemberCondition;
import com.opensymphony.xwork2.Action;

/* 程式的處理
 * @author neo
 */
public class MemberPersonnelAction extends MemberBaseAction {
	private static final long serialVersionUID = 7103507551890156092L;

	private static final Logger log = LogManager.getLogger(MemberPersonnelAction.class) ;

	private String[] personIdList;

	public String[] getPersonIdList() {
		return personIdList;
	}
	public void setPersonIdList(String[] personIdList) {
		this.personIdList = personIdList;
	}
	
	public String doQuery() {
		try {
			if(!this.hasToCountTotal()) {
				MemberCondition p = (MemberCondition)this.getSessionMap().get(MEMBER_CONDITION);
				this.setCondition(p);
			} else {
				this.getSessionMap().put(MEMBER_CONDITION, this.getCondition());
				this.getPageBean().setJumpPage("");
			}


			QueryResult result = null;
			
			if("new".equals(this.getCondition().getPersonnelType())) //新進員工轉入
			{
				result = memberService.findMemberPersonnelForNew(
						getQueryStartIndex(),getPageBean().getPageSize(),hasToCountTotal());
			}
			else //現有員工資料查詢
			{
				result = memberService.findMemberPersonnelByCondition(
						getCondition(),getQueryStartIndex(),getPageBean().getPageSize(),hasToCountTotal());
			}
			
			this.setPageBeanByQueryResult(result,"doQuery");
			this.getSessionMap().put(MEMBER_PAGEBEAN, this.getPageBean());
			auditSuccessLog();
		} catch(Exception e) {
			e.printStackTrace();
			auditFailLog();
		}

		return Action.SUCCESS;
	}

	public String doCreateCard() throws Exception {
		this.setCondition((MemberCondition) this.getSessionMap().get(MEMBER_CONDITION));

		if ("new".equals(this.getCondition().getPersonnelType())) // 新進員工製卡
		{
			List<Members> memberList = this.memberService.findMembersForNewPersonnel(this.personIdList);
			this.memberService.createMemberWithPersonnelCard(memberList, this.getUser().getUserId(), this.getUser().getUserName());
		} else // 現有員工 製卡
		{
			this.getCardService().createPersonnelCard(this.personIdList, this.getUser().getUserId(), this.getUser().getUserName());
		}

		return this.doQuery();
	}

}
