package com.gccs.member.action;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.StringReader;
import java.util.Date;
import java.util.List;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gccs.base.action.BaseAction;
import com.gccs.bs.model.BsStore;
import com.gccs.member.service.MemberService;
import com.gccs.util.cache.BsStoreDefinition;
import com.opensymphony.xwork2.Action;

public class AdvanceCardAction extends BaseAction {
	private static final long serialVersionUID = 498915543521341197L;

	private static final Logger log = LogManager.getLogger(AdvanceCardAction.class);

	public static final String _session_dowloadStr = "_session_dowloadStr";

	private static final String _actionName = "AdvanceCard";
	private static final String _action_view = _actionName + "!view";	
	private static final String _action_export = _actionName + "!export";
	private static final String _action_query = _actionName + "!query";
					
	private MemberService memberService;
	private String channelId;
	private String storeId;
	private Integer amount;
	private String createDate;
	private InputStream inputStream;
	private String exportFileName;
	private Date sysdate = new Date();
	private Date vipDate;
	private String logicGroupNo;
	
	/******************************************************************************************/
	
	public String query(){
		this.getSessionMap().remove(_session_dowloadStr);		
		return "TRCBQRY";
	}
	
	public String view() {				
		this.getSessionMap().remove(_session_dowloadStr);
		return Action.SUCCESS;
	}
	
	public String export() {        
		try {
			String downloadStr = (String)this.getSessionMap().get(_session_dowloadStr);	     
			BufferedReader in = new BufferedReader(new StringReader(downloadStr));
	        String line = null;
	        int row = 0;
	        
			ByteArrayOutputStream output = new ByteArrayOutputStream();
			WritableWorkbook wb = Workbook.createWorkbook(output);
			WritableSheet ws = wb.createSheet("卡號", 0);
						
			while((line = in.readLine()) != null) {   				
				ws.addCell(new Label(0, row++, line));
			}
			
			wb.write();
			wb.close();
			in.close();
			
			this.inputStream = new ByteArrayInputStream(output.toByteArray());
			this.exportFileName = this.queryFileName();
			this.getSessionMap().remove(_session_dowloadStr);
		} catch(Exception e) {		
			e.printStackTrace();			
		}
		
		return "download";
	}
	
	private String queryFileName() throws Exception {		
		String storeName = "";
		List<BsStore> list = BsStoreDefinition.findBsStoreByChannelId(this.channelId);
		for(BsStore vo : list) {
			if(this.storeId.equals(vo.getId().getStoreId())) {
				storeName = vo.getStoreName1();
			}
		}				
		String fileName = storeName+"_"+createDate.replaceAll("/", "")+"預制卡";
		return new String(fileName.getBytes("Big5"), "ISO8859_1");
	}
	
	//原匯出為txt檔
	public String export_txt() throws Exception {		
		String downloadStr = (String)this.getSessionMap().get(_session_dowloadStr);		
		this.inputStream = new ByteArrayInputStream(downloadStr.getBytes());
		this.getSessionMap().remove(_session_dowloadStr);
				
		return "download";
	}		
	
	/******************************************************************************************/

	public MemberService getMemberService() {
		return memberService;
	}

	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public static String get_actionName() {
		return _actionName;
	}

	public static String get_action_view() {
		return _action_view;
	}

	public static String get_action_export() {
		return _action_export;
	}

	public InputStream getInputStream() {
		return inputStream;
	}

	public void setInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
	}

	public String getExportFileName() {
		return exportFileName;
	}

	public void setExportFileName(String exportFileName) {
		this.exportFileName = exportFileName;
	}

	public Date getSysdate() {
		return sysdate;
	}

	public void setSysdate(Date sysdate) {
		this.sysdate = sysdate;
	}

	public static String getActionQuery() {
		return _action_query;
	}

	public Date getVipDate() {
		return vipDate;
	}

	public void setVipDate(Date vipDate) {
		this.vipDate = vipDate;
	}

	public String getLogicGroupNo() {
		return logicGroupNo;
	}

	public void setLogicGroupNo(String logicGroupNo) {
		this.logicGroupNo = logicGroupNo;
	}
	
}
