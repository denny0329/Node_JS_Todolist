package com.gccs.member.action;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.DateTimeUtils;
import com.bnq.util.PageBean;
import com.bnq.util.QueryResult;
import com.gccs.base.action.BaseAction;
import com.gccs.member.card.vo.CardTransferVo;
import com.gccs.member.service.CardService;
import com.gccs.member.service.MemberService;

/**
 * <b></b>
 * @author kaychen
 * @Date: 2010/4/12 下午 5:26:26
 * @Project Name: RFEP
 */
public class CardTransferAction extends BaseAction {
	private static final Logger log = LogManager.getLogger(CardTransferAction.class) ;
	private CardTransferVo transferVo ;
	private static final String _transferVoSessionId = "_cardTransferVoSessionId" ;
	private static final String _pageBeanSessionId = "_cardTransferDataListSessionId" ;
	private static final String _conditionSessionId = "_cardTransferConditionSessionId" ;
	private MemberService memberService ;
	private CardService cardService;
	public CardService getCardService() {
		return cardService;
	}
	public void setCardService(CardService cardService) {
		this.cardService = cardService;
	}

	//private Map queryCondition = new HashMap() ;
	private String oid ;

	public String getOid() {
		return oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}

	public CardTransferVo getTransferVo() {
		if(this.getSessionMap().get(_transferVoSessionId) != null) {
			transferVo = (CardTransferVo)this.getSessionMap().get(_transferVoSessionId) ;
		}
		return transferVo;
	}
	public void setTransferVo(CardTransferVo transferVo) {
		this.getSessionMap().put(_transferVoSessionId,transferVo) ;
		this.transferVo = transferVo;
	}

	public MemberService getMemberService() {
		return memberService;
	}
	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}

	public String onLoad() {
		this.setPageBean(null) ;
		this.getSessionMap().remove(_pageBeanSessionId) ;
		this.setTransferVo(null) ;
		this.getSessionMap().remove(_transferVoSessionId) ;

		return SUCCESS ;
	}

	public String createTransfer() {
		transferVo = new CardTransferVo() ;
		transferVo.setCreator(this.getUser().getUserId()) ;
		transferVo.setCreatorName(this.getUser().getUserName()) ;
		try {
			transferVo.setCreateTime(DateTimeUtils.getFormatSysDateTimeStr()) ;
		} catch (Throwable e) {
		}
		this.setTransferVo(transferVo) ;
		return SUCCESS ;
	}

	public String queryTransferLog() {
		try{
			this.getSessionMap().put(_conditionSessionId,this.getQueryCondition()) ;
			String originalPersonId = null ;
			Date dateFrom = null ;
			Date dateTo = null ;
			String vipNo = null ;

			if(this.getQueryCondition().get("originalPersonId") != null) {
				originalPersonId = ((String[])this.getQueryCondition().get("originalPersonId"))[0] ;
			}
			if(this.getQueryCondition().get("createTimeFrom") != null) {
				String temp = ((String[])this.getQueryCondition().get("createTimeFrom"))[0] ;
				if(!temp.trim().equals("")) {
					dateFrom = DateTimeUtils.getDate(temp) ;
				}
			}
			if(this.getQueryCondition().get("createTimeTo") != null) {
				String temp = ((String[])this.getQueryCondition().get("createTimeTo"))[0] ;
				if(!temp.trim().equals("")) {
					dateTo = DateTimeUtils.getDate(temp) ;
				}
			}
			if(this.getQueryCondition().get("vipNo") != null) {
				vipNo = ((String[])this.getQueryCondition().get("vipNo"))[0] ;
			}
			QueryResult result = this.getMemberService().getTransferLogList(originalPersonId, dateFrom, dateTo, vipNo, this.getQueryStartIndex(),this.getPageBean().getPageSize(), this.hasToCountTotal()) ;
			this.setPageBeanByQueryResult(result,this.getActionName()) ;
			this.getSessionMap().put(_pageBeanSessionId, this.getPageBean()) ;

			return SUCCESS ;
		}catch(Exception e){
			log.error(e.getMessage() ,e) ;
			this.addActionError(e.getMessage()) ;
			return INPUT ;
		}
	}

	public String selectTransferLog() {
		log.info("Select Transfer Log : "+this.getOid()) ;
		try{
			this.reloadPageData() ;
			List list = (List)this.getPageBean().getQueryList() ;
			for (Iterator iterator = list.iterator(); iterator.hasNext();) {
				CardTransferVo vo = (CardTransferVo) iterator.next();
				if(vo.getOid().equals(this.getOid())) {
					this.setTransferVo(vo) ;
					break ;
				}
			}
			return SUCCESS ;
		}catch(Exception e){
			log.error(e.getMessage() ,e) ;
			this.addActionError(e.getMessage()) ;
			return INPUT ;
		}
	}

	public String transfer() {
		try {
			this.getCardService().transferMmCard(this.getTransferVo()) ;
			this.addActionMessage(getText("SAVE_SUCCESS"));
			//頁面更新為不可輸入
			this.getTransferVo().setOid("temp") ;
			return SUCCESS ;
		} catch(Exception e) {
			log.error(e.getMessage(),e) ;
			this.addActionError(e.getMessage()) ;
			return INPUT ;
		}
	}

	public String exitToTransferQuery() {
		this.getSessionMap().remove(_transferVoSessionId) ;
		this.setTransferVo(null) ;
		this.reloadPageData() ;
		return SUCCESS ;
	}

	private void reloadPageData() {
		this.setPageBean((PageBean)this.getSessionMap().get(_pageBeanSessionId)) ;
		this.setQueryCondition((Map)this.getSessionMap().get(_conditionSessionId)) ;
	}

	public boolean isCanModify() {
		if(this.getTransferVo() != null && this.getTransferVo().getOid() != null) {
			return false ;
		}
		return true ;
	}
}
