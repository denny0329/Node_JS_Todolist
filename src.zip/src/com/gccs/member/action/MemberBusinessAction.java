package com.gccs.member.action;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.bnq.util.QueryResult;
import com.gccs.base.action.BaseAction;
import com.gccs.member.model.Account;
import com.gccs.member.model.AccountHq;
import com.gccs.member.model.condition.AccountHqCondition;
import com.gccs.member.service.AccountService;
import com.gccs.member.service.MemberService;
import com.gccs.member.util.MemberGlossary;
import com.opensymphony.xwork2.Action;


/* 程式的處理
 * @author neo
 */
public class MemberBusinessAction extends BaseAction {
	private static final long serialVersionUID = -4515879676616844978L;

	private AccountHqCondition condition;

	private static String _session_key_accountHq_query = "_session_accountHq_query";
	private static String _session_key_accountHq = "_session_accountHq";
	private MemberService memberService;
	//private AccountHq accountHq;
	//private List<Account> accountList = new ArrayList();
	private AccountService accountService;

	public AccountService getAccountService() {
		return accountService;
	}
	public void setAccountService(AccountService accountService) {
		this.accountService = accountService;
	}
	public List<Account> getAccountList() throws Exception {
		return getAccountHq().getAccountList();
	}
	/*
	public void setAccountList(List<Account> accountList) {
		this.accountList = accountList;
	}
	*/
	public AccountHqCondition getCondition() {
		return condition;
	}
	public void setCondition(AccountHqCondition condition) {
		this.condition = condition;
	}

	public MemberService getMemberService() {
		return memberService;
	}
	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}
	public AccountHq getAccountHq() {
		AccountHq accountHq = (AccountHq)this.getSessionMap().get(_session_key_accountHq);
		if(accountHq == null) {
			accountHq = new AccountHq();
			setAccountHq(accountHq);
		}
		return accountHq;
	}
	public void setAccountHq(AccountHq accountHq) {
		this.getSessionMap().put(_session_key_accountHq, accountHq);
	}
	public String doBusinessQuery(){


		try {
			if(!this.hasToCountTotal()) {
				AccountHqCondition p = (AccountHqCondition)this.getSessionMap().get(_session_key_accountHq_query);
				this.setCondition(p);
			} else {
				this.getSessionMap().put(_session_key_accountHq_query, this.getCondition());
				this.getPageBean().setJumpPage("");
			}

			QueryResult result = accountService.findAccountHqByCondition(this.getCondition(), this.getQueryStartIndex(),
					this.getPageBean().getPageSize(), this.hasToCountTotal());

			this.setPageBeanByQueryResult(result,"doBusinessQuery");

		} catch(Exception e) {
			e.printStackTrace();
		}
		return Action.SUCCESS;
	}
	public String doIndexBusiness(){
		this.getSessionMap().remove(_session_key_accountHq_query);
		return Action.SUCCESS;
	}

	public String doBusinessEdit() throws Exception{
		String oid  = this.getRequest().getParameter("oid");
		if(StringUtils.isNotBlank(oid))
			setAccountHq(this.getAccountService().findAccountHqByOid(oid));
		return Action.SUCCESS;
	}
	
	/*
	private void setAccountHqInfo(String oid)throws Exception{
		this.accountHq = this.getAccountService().loadBusinessByOid(oid);
		this.accountList = this.getAccountService().findAccountByHqId(accountHq.getHqId());
	}
	
	public void findAccountByHqId(String hqId) throws Exception{
		this.getAccountService().findAccountByHqId(hqId);
	}
	*/

	public String doBusinessCreate(){
		AccountHq accountHq = new AccountHq();
		accountHq.setStatus(MemberGlossary._mm_account_hq_status_normal);
		setModifyInfo(accountHq, true);
		setAccountHq(accountHq);
		return Action.SUCCESS;
	}

	public String doBusinessExit(){
		try {
			AccountHqCondition p = (AccountHqCondition)this.getSessionMap().get(_session_key_accountHq_query);
			if(p==null){
				return Action.SUCCESS;
			}
			this.setCondition(p);

			QueryResult result = accountService.findAccountHqByCondition(this.getCondition(), this.getQueryStartIndex(),
					this.getPageBean().getPageSize(), this.hasToCountTotal());
			this.getPageBean().setJumpPage("");
			this.setPageBeanByQueryResult(result,"doBusinessQuery");

		} catch(Exception e) {
			this.addActionError("載入失敗:"+e.getMessage()+"，請洽系統管理人員.") ;
			e.printStackTrace();
			return ERROR;
		}
		return Action.SUCCESS;
	}

	public String doBusinessSave() throws Exception{
		AccountHq accountHq = getAccountHq();
		if(accountHq.getMemo()!=null){
			if(accountHq.getMemo().length()>100){
				String memo = accountHq.getMemo();
				memo = memo.substring(0, 99);
				accountHq.setMemo(memo);
			}

		}

		
		if(StringUtils.isBlank(this.getAccountHq().getOid())){
			//accountHq.setStatus(1);
			setModifyInfo(accountHq, true);
			this.getAccountService().createAccountHq(accountHq);
		}else{
			setModifyInfo(accountHq, false);
			this.getAccountService().updateAccountHq(accountHq);
		}
		//setAccountHqInfo(accountHq.getOid());
		
		return Action.SUCCESS;
	}
	
	private void setModifyInfo(AccountHq accountHq, boolean alsoSetCreateInfo) {
		Date modifyTime = new Date();
		//Modify Info
		accountHq.setModifier(this.getUser().getUserId());
		accountHq.setModifierName(this.getUser().getUserName());
		accountHq.setModifyTime(modifyTime);
		if(alsoSetCreateInfo) {
			//Creator info
			accountHq.setCreator(this.getUser().getUserId());
			accountHq.setCreatorName(this.getUser().getUserName());
			accountHq.setCreateTime(modifyTime);
		}
	}
}
