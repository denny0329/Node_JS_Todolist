package com.gccs.member.action;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gccs.base.action.BaseAction;
import com.gccs.member.service.CardService;
import com.opensymphony.xwork2.Action;

public class AdvanceCardChangeAction extends BaseAction {
	private static final long serialVersionUID = -4326900119946558536L;

	private static final Logger log = LogManager.getLogger(AdvanceCardChangeAction.class);

	private String _actionName;
	private String channelId;
	private String storeId;
	private String channelIdChange;
	private String storeIdChange;
	private String msg;
	private CardService cardService;

	public CardService getCardService() {
		return cardService;
	}
	public void setCardService(CardService cardService) {
		this.cardService = cardService;
	}

	/******************************************************************************************/

	public String get_action(String methodName) {
		return this._actionName + "!" + methodName;
	}
	public String get_action_view() {
		return this.get_action("view");
	}
	public String get_action_execute() {
		return this.get_action("execute");
	}

	/******************************************************************************************/

	public String view() {
		return Action.SUCCESS;
	}

	public String execute() {
		this.cardService.changeAdvanceCard(
		    this.channelId, this.storeId, this.channelIdChange, this.storeIdChange,
			this.getUser().getUserId(), this.getUser().getUserName());

		this.setChannelId(null);
		this.setChannelIdChange(null);
		this.setMsg("成功轉換完畢！");

		return Action.SUCCESS;
	}

	/******************************************************************************************/

	public String get_actionName() {
		return _actionName;
	}
	public void set_actionName(String name) {
		_actionName = name;
	}

	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getStoreId() {
		return storeId;
	}
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
	public String getChannelIdChange() {
		return channelIdChange;
	}
	public void setChannelIdChange(String channelIdChange) {
		this.channelIdChange = channelIdChange;
	}
	public String getStoreIdChange() {
		return storeIdChange;
	}
	public void setStoreIdChange(String storeIdChange) {
		this.storeIdChange = storeIdChange;
	}
	public static Logger getLog() {
		return log;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
}
