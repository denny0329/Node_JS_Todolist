package com.gccs.member.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bnq.util.PageBean;
import com.bnq.util.QueryResult;
import com.bnq.util.StringId;
import com.gccs.base.action.BaseAction;
import com.gccs.member.service.MemberService;
import com.gccs.util.web.SelectItem;
import com.opensymphony.xwork2.Action;

public class MemberNoticeReverseAction extends BaseAction {
	private static final long serialVersionUID = -203659816669141143L;

	private Logger log = Logger.getLogger(MemberNoticeReverseAction.class);
	// 固定常用session key值
	private static final String QUERY_CONDITION = "queryCondition";
	private static final String PAGE_BEAN = "pageBean";
	private static final String OPERATE_ID = "operateId";
	private static final String OPERATE_OBJECT = "operateObject";
	private static final String ACTION_TYPE = "actionType"; 
	private ReverseMarketNotice operateObject;
	
	public ReverseMarketNotice getOperateObject() {
		return operateObject;
	}

	public void setOperateObject(ReverseMarketNotice operateObject) {
		this.operateObject = operateObject;
	}

	protected MemberService memberService;
	
	
	public static List<StringId> getChannelList() {
		List<StringId> list = new ArrayList<StringId>();
		list.add(SelectItem._defaultSelect);
		list.add(new StringId("TRCB","TRCB-特力恩瑞")) ;
		list.add(new StringId("TBA","TBA-特家")) ;
		return list;
	}

	public MemberService getMemberService() {
		return memberService;
	}

	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}

	public String load() {
		getSessionMap().remove(QUERY_CONDITION);
		getSessionMap().remove(PAGE_BEAN);
		getSessionMap().remove(OPERATE_OBJECT);
		getSessionMap().remove(ACTION_TYPE);
		getSessionMap().remove(OPERATE_ID);

		return SUCCESS;
	}
	
	/**
	 * 進入點
	 * @return
	 */
	public  String doEntry(){
		return Action.SUCCESS;
	}

	/**
	 * 執行查詢
	 * 
	 * @return
	 */	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String query() {
		try {
			if (!hasToCountTotal()) {
				setQueryCondition((Map) getSessionMap().get(QUERY_CONDITION));
			} else {
				getPageBean().setJumpPage("");
			}

			Map queryCondition = getQueryCondition();
			queryCondition.put("companyId", getCurrentUser().getCompanyId());
			QueryResult result = getMemberService()
					.findReverseMarketNotice(queryCondition,
							getQueryStartIndex(), getPageBean().getPageSize(),
							hasToCountTotal());
			// BsComskuQuery代表查詢所呼叫的Action，用於讓換頁時呼叫查詢動作 Tony
			setPageBeanByQueryResult(result, "reverseMarketNotice");

			// 儲存查詢條件、結果
			getSessionMap().put(QUERY_CONDITION, queryCondition);
			getSessionMap().put(PAGE_BEAN, getPageBean());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			addActionError(getText("QUERY_FAIL") + "：" + e.getMessage());

			return ERROR;
		}
		return SUCCESS;
	}
	
	/**
	 * 執行新增
	 * 
	 * @return
	 */
	public String add() {
		return SUCCESS;
	}
	
	/**
	 * 執行刪除
	 * 
	 * @return
	 */
	public String delete() {
		for (int i = 0; i < getItems().length; i++) {
			String id = getItems()[i];
			try{				
				getMemberService().deleteReverseMarketNotice(id);
			}catch (Exception e) {				
				e.printStackTrace();
				addActionError(getText("DELETE_FAIL") + e.getMessage());
			}
		}
		addActionMessage(getText("DELETE_SUCCESS"));
		return query();
	}
	
    public class ReverseMarketNotice{
    	private String memberId;
    	private String personId;
    	private List<String> channelIds;
    	private String companyId;
    	private String creator;
    	private String modifier;
    	private String vipNo;
    	private String memberName;
		public String getMemberId() {
			return memberId;
		}
		public void setMemberId(String memberId) {
			this.memberId = memberId;
		}
		public String getPersonId() {
			return personId;
		}
		public void setPersonId(String personId) {
			this.personId = personId;
		}
		public List<String> getChannelIds() {
			return channelIds;
		}
		public void setChannelIds(List<String> channelIds) {
			this.channelIds = channelIds;
		}
		public String getCompanyId() {
			return companyId;
		}
		public void setCompanyId(String companyId) {
			this.companyId = companyId;
		}
		public String getCreator() {
			return creator;
		}
		public void setCreator(String creator) {
			this.creator = creator;
		}
		public String getModifier() {
			return modifier;
		}
		public void setModifier(String modifier) {
			this.modifier = modifier;
		}
		public String getVipNo() {
			return vipNo;
		}
		public void setVipNo(String vipNo) {
			this.vipNo = vipNo;
		}
		public String getMemberName() {
			return memberName;
		}
		public void setMemberName(String memberName) {
			this.memberName = memberName;
		}
	}
    
    /**
	 * 儲存資料
	 * 
	 * @return
	 */
	public String save() {
		ReverseMarketNotice operateObject = getOperateObject();
		try {
			operateObject.setCreator(getCurrentUser().getUserId());
			operateObject.setModifier(getCurrentUser().getUserId());
			getMemberService().getMemberDao().saveReverseMemberName(operateObject);
			addActionMessage(getText("SAVE_SUCCESS"));
			return SUCCESS;
		} catch (Exception e) {
			e.printStackTrace();
			addActionError(getText("SAVE_FAIL") + e.getMessage());
			return ERROR;
		}
	}
    
    /**
	 * 執行離開
	 */
	@SuppressWarnings("rawtypes")
	public String exit() {
		setOperateObject(null);

		try{
			setQueryCondition((Map) getSessionMap().get(QUERY_CONDITION));
			setPageBean((PageBean) getSessionMap().get(PAGE_BEAN));
		}catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			addActionError(getText("Exit_FAIL") + "：" + e.getMessage());
		}
		return SUCCESS;
	}
	
}
