package com.gccs.member.action;

import java.util.Date;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.PageBean;
import com.bnq.util.QueryResult;
import com.gccs.base.action.BaseAction;
import com.gccs.member.model.Account;
import com.gccs.member.model.MmThresholdMst;
import com.gccs.member.model.condition.MemberCondition;
import com.gccs.member.service.CardService;
import com.gccs.member.service.IAccountService;
import com.gccs.member.service.MemberService;
import com.gccs.util.cache.BsCompanyDefinition;
import com.gccs.ws.service.BaseWebService;
import com.opensymphony.xwork2.Action;

public class ThresholdSettingAction extends BaseAction {
	private static final long serialVersionUID = -6717178994269628380L;

	private static final Logger log = LogManager.getLogger(ThresholdSettingAction.class);
	private static final String _session_PageBean = "_session_PageBean";
	private static final String _session_Query = "_session_Query";

	private Integer actType; //1:退佣;2:獎勵
	private MemberService memberService;
	private MemberCondition condition;
	private MmThresholdMst vo;
	private CardService cardService;
	private IAccountService accountService;
	private List<Account> accountList;
	private Integer totalCount;


	/****************************************************************************************/


	public CardService getCardService() {
		return cardService;
	}
	public void setCardService(CardService cardService) {
		this.cardService = cardService;
	}

	/****************************************************************************************/

	public String view() {
		this.getSessionMap().remove(_session_PageBean);
		this.getSessionMap().remove(_session_Query);

		return Action.SUCCESS;
	}

	public String query() {
		try {
			if(!this.hasToCountTotal()) {
				this.condition = (MemberCondition)this.getSessionMap().get(_session_Query);
			} else {
				this.getSessionMap().put(_session_Query, this.condition);
				this.getPageBean().setJumpPage("");
			}
			this.condition.setCompanyId(BsCompanyDefinition.getCompanyId());
			QueryResult result = memberService.findMmThresholdMst(this.condition, getQueryStartIndex(), getPageBean().getPageSize(), hasToCountTotal());
			this.setPageBeanByQueryResult(result, "selectMmThreshold");

			this.getSessionMap().put(_session_PageBean, this.getPageBean());
		} catch(Exception e) {
			e.printStackTrace();
		}

		return Action.SUCCESS;
	}

	public String exit() {
		try {
			if(this.getSessionMap().get(_session_Query) != null)
			{
				this.setCondition((MemberCondition)this.getSessionMap().get(_session_Query));
				this.setPageBean((PageBean)this.getSessionMap().get(_session_PageBean));

				QueryResult result = memberService.findMmThresholdMst(this.condition, getQueryStartIndex(), getPageBean().getPageSize(), true);
				this.setPageBeanByQueryResult(result, "selectMmThreshold");
			}
		} catch(Exception e) {
			e.printStackTrace();
		}

		return Action.SUCCESS;
	}

	public String edit() throws Exception {
		if(!isNew()) {
			this.vo = this.memberService.deployLoadMmThresholdMst(this.vo.getOid());
			vo.setThresholdDtlList(this.memberService.findMmThresholdDtlByThresholdId(this.vo.getThresholdId()));
			this.setTotalCount(accountService.findAccountByThresholdIdCount(this.vo.getThresholdId(), 0, 0, false));
		} else {
			this.vo = new MmThresholdMst();
			this.vo.setThresholdId("系統給號");
			this.vo.setStatus("0");
		}

		if("2".equals(this.vo.getStatus())) {
			return "view";
		} else {
			return Action.INPUT;
		}
	}

	public String save() throws Exception {
		if(isNew()) {
			this.vo.setCreator(this.getUser().getUserId());
			this.vo.setCreatorName(this.getUser().getUserName());
			this.vo.setCreateTime(new Date());
			this.vo.setCompanyId(this.getUser().getCompanyId());
		}

		this.vo.setModifier(this.getUser().getUserId());
		this.vo.setModifierName(this.getUser().getUserName());
		this.vo.setModifyTime(new Date());

		this.memberService.deeplySaveOrUpdateMmThresholdMst(this.vo);
		return this.edit();
	}

	public String cardDiscTable() throws Exception {
		String thresholdId = this.getRequest().getParameter("thresholdId");
		int index = Integer.valueOf((String)this.getRequest().getParameter("index"));
		int pageSize = Integer.valueOf((String)this.getRequest().getParameter("pageSize"));
		this.accountList = accountService.findAccountByThresholdId(thresholdId, index, pageSize, true);
		return "cardDiscTable";
	}

	public String openWin() throws Exception {
		this.getRequest().setAttribute("isWin", true);
		this.vo = this.memberService.deployLoadMmThresholdMst(this.vo.getOid());
		vo.setThresholdDtlList(this.memberService.findMmThresholdDtlByThresholdId(this.vo.getThresholdId()));
		this.setTotalCount(accountService.findAccountByThresholdIdCount(this.vo.getOid(), 0, 0, false));

		return "view";
	}

	public boolean isNew() {
		if(BaseWebService.isEmpty(this.vo) || BaseWebService.isEmpty(this.vo.getOid())) {
			return true;
		} else {
			return false;
		}
	}

	public static String getStatusTxt(Integer status) {
		if(status==null || status==1){
			return "申請中";
		}else if(status==2){
			return "審核中";
		}else if(status==3){
			return "核發";
		}else if(status==9){
			return "刪除";
		}else if(status==4){
			return "限制採購";
		}else if(status==0){
			return "停用";
		}
		return "";
	}

	public static String handleBreak(String str) {
		return str.replaceAll("\r\n", "<br>");
	}

	/****************************************************************************************/

	public Integer getActType() {
		return actType;
	}
	public void setActType(Integer actType) {
		this.actType = actType;
	}
	public MemberService getMemberService() {
		return memberService;
	}
	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}
	public MemberCondition getCondition() {
		return condition;
	}
	public void setCondition(MemberCondition condition) {
		this.condition = condition;
	}
	public MmThresholdMst getVo() {
		return vo;
	}
	public void setVo(MmThresholdMst vo) {
		this.vo = vo;
	}
	public IAccountService getAccountService() {
		return accountService;
	}
	public void setAccountService(IAccountService accountService) {
		this.accountService = accountService;
	}
	public List<Account> getAccountList() {
		return accountList;
	}
	public void setAccountList(List<Account> accountList) {
		this.accountList = accountList;
	}
	public Integer getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}
}
