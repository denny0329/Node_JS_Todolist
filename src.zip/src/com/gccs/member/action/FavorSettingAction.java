package com.gccs.member.action;

public class FavorSettingAction extends CommissionSettingAction {    		
	private static final long serialVersionUID = 966668584159876708L;

	private String _actionName = "FavorSetting";		
	private String _action_view = _actionName + "!view";	
	private String _action_query = _actionName + "!query";	
	private String _action_exit = _actionName + "!exit";
	private String _action_edit = _actionName + "!edit";
	private String _action_save = _actionName + "!save";
	private String _action_cardDiscTable = _actionName + "!cardDiscTable";
	private Integer actType = 2; //1:退佣;2:獎勵	
	
	public String get_actionName() {
		return _actionName;
	}
	public void set_actionName(String name) {
		_actionName = name;
	}
	public String get_action_view() {
		return _action_view;
	}
	public void set_action_view(String _action_view) {
		this._action_view = _action_view;
	}
	public String get_action_query() {
		return _action_query;
	}
	public void set_action_query(String _action_query) {
		this._action_query = _action_query;
	}
	public String get_action_exit() {
		return _action_exit;
	}
	public void set_action_exit(String _action_exit) {
		this._action_exit = _action_exit;
	}
	public String get_action_edit() {
		return _action_edit;
	}
	public void set_action_edit(String _action_edit) {
		this._action_edit = _action_edit;
	}
	public String get_action_save() {
		return _action_save;
	}
	public void set_action_save(String _action_save) {
		this._action_save = _action_save;
	}
	public String get_action_cardDiscTable() {
		return _action_cardDiscTable;
	}
	public void set_action_cardDiscTable(String discTable) {
		_action_cardDiscTable = discTable;
	}
	public Integer getActType() {
		return actType;
	}
	public void setActType(Integer actType) {
		this.actType = actType;
	}	
}
