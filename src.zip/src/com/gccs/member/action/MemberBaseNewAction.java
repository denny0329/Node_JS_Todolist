package com.gccs.member.action;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import jxl.Workbook;
import jxl.format.Alignment;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.format.Colour;
import jxl.format.UnderlineStyle;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.bs.service.IBsCodeService;
import com.bnq.util.FileTools;
import com.bnq.util.PageBean;
import com.bnq.util.QueryResult;
import com.gccs.base.action.BaseAction;
import com.gccs.bc.model.BcBonusLog;
import com.gccs.bonus.service.BonusCountSaleDataService;
import com.gccs.bs.model.BsChannel;
import com.gccs.bs.service.BsManagerService;
import com.gccs.member.card.model.MmCard;
import com.gccs.member.model.BrandVo;
import com.gccs.member.model.MarketNotice;
import com.gccs.member.model.MarketNoticeVo;
import com.gccs.member.model.MemberCntRpt;
import com.gccs.member.model.MemberConsumMainRpt;
import com.gccs.member.model.MemberConsumRpt;
import com.gccs.member.model.Members;
import com.gccs.member.model.MembersEcSycn;
import com.gccs.member.model.condition.MemberCondition;
import com.gccs.member.service.IAccountService;
import com.gccs.member.service.ICardService;
import com.gccs.member.service.IMembersEcSycnService;
import com.gccs.member.service.IMtVipService;
import com.gccs.member.service.MemberService;
import com.gccs.member.util.MemberGlossary;
import com.gccs.mmbonus.model.MmMembersBonus;
import com.gccs.util.cache.BsChannelDefinition;
import com.gccs.util.cache.BsCompanyDefinition;
import com.gccs.util.log.model.AuditInfo;
import com.gccs.util.log.model.AuditRecord;
import com.gccs.util.log.model.AuditStore;
import com.gccs.util.log.model.ModifyRecord;
import com.opensymphony.xwork2.Action;
import com.rfep.util.cache.StoreSystemInfoDefinition;
import com.trg.oms.externalWS.ExternalWSClient;
import com.trg.oms.externalWS.ec.mobileVerify.SynCustomerService;
import com.trg.oms.externalWS.ec.mobileVerify.SyncTestriteCustomerResponse;

public class MemberBaseNewAction extends BaseAction {
	private static final long serialVersionUID = -2008048334483917426L;

	private static final Logger log = LogManager.getLogger(MemberBaseNewAction.class) ;
	private MemberCondition condition;
	protected final static String MEMBER_CONDITION = "s_member_condition";
	protected final static String MEMBER_PAGEBEAN = "s_member_pagebean";
	protected final static String MEMBER_LOGICGROUPNO = "s_member_logicGroupNo";
	private final static String DM_TYPE = "1";
	private final static String PHONE_TYPE = "2";
	private final static String EMAIL_TYPE = "3";
	
	protected MemberService memberService;
	private ICardService cardService;
	private IAccountService accountService;
	private IBsCodeService bsCodeService; 
	private IMembersEcSycnService membersEcSycnService;
	private BonusCountSaleDataService bonusCountSaleDataService; 
	private BsManagerService bsManagerService;
	private IMtVipService mtVipService;
	private ExternalWSClient externalWSClient;
	private String ErCard = "N";
	private String Eroption;

	private Members members;
	private Members omembers;
	protected String doCreateCardVipNoList = "doCreateCardVipNoList";
	private List<BsChannel> channelList;
	private List<MmCard> mmCardList;
	private List<MarketNoticeVo> marketNoticeVoList = new ArrayList();
	private List<Map<String, String>> mtPosVipMstList = new ArrayList<Map<String, String>>();
	private MmCard card ;
	private static final int STATUS_READONLY = 0;
	public final static String READONLY = "readonly";
	public final static boolean LOAD_ACCOUNT = true;
	public final static boolean DO_NOT_LOAD_ACCOUNT = false;
	private String isShowPersonId = "N";
	private boolean remarkAuth = true;
	private MemberConsumMainRpt mainRpt;
	private String fileName;
	private String dialogValue;
	private InputStream inputStream;
	private String confirmPage;
	
	public ExternalWSClient getExternalWSClient() {
		return externalWSClient;
	}
	public void setExternalWSClient(ExternalWSClient externalWSClient) {
		this.externalWSClient = externalWSClient;
	}
	public String getConfirmPage() {
		return confirmPage;
	}
	public void setConfirmPage(String confirmPage) {
		this.confirmPage = confirmPage;
	}
	public String getErCard() {
		return ErCard;
	}
	public void setErCard(String erCard) {
		ErCard = erCard;
	}
	public String getEroption() {
		return Eroption;
	}
	public void setEroption(String eroption) {
		Eroption = eroption;
	}
	public IMtVipService getMtVipService() {
		return mtVipService;
	}
	public void setMtVipService(IMtVipService mtVipService) {
		this.mtVipService = mtVipService;
	}
	public BsManagerService getBsManagerService() {
		return bsManagerService;
	}
	public void setBsManagerService(BsManagerService bsManagerService) {
		this.bsManagerService = bsManagerService;
	}
	public BonusCountSaleDataService getBonusCountSaleDataService() {
		return bonusCountSaleDataService;
	}
	public void setBonusCountSaleDataService(
			BonusCountSaleDataService bonusCountSaleDataService) {
		this.bonusCountSaleDataService = bonusCountSaleDataService;
	}
	public String getIsShowPersonId() {
		return isShowPersonId;
	}
	public void setIsShowPersonId(String isShowPersonId) {
		this.isShowPersonId = isShowPersonId;
	}
	public IAccountService getAccountService() {
		return accountService;
	}
	public void setAccountService(IAccountService accountService) {
		this.accountService = accountService;
	}
	public ICardService getCardService() {
		return cardService;
	}
	public void setCardService(ICardService cardService) {
		this.cardService = cardService;
	}
	public MmCard getCard() {
		return card;
	}
	public void setCard(MmCard card) {
		this.card = card;
	}
	public List<MmCard> getMmCardList() {
		return mmCardList;
	}
	public void setMmCardList(List<MmCard> mmCardList) {
		this.mmCardList = mmCardList;
	}
	public List<MarketNoticeVo> getMarketNoticeVoList() {
		return marketNoticeVoList;
	}
	public void setMarketNoticeVoList(List<MarketNoticeVo> marketNoticeVoList) {
		this.marketNoticeVoList = marketNoticeVoList;
	}
	public List<BsChannel> getChannelList() {
		return channelList;
	}
	public void setChannelList(List<BsChannel> channelList) {
		this.channelList = channelList;
	}
	public Members getMembers() {
		return members;
	}
	public void setMembers(Members members) {
		this.members = members;
	}
	public MemberService getMemberService() {
		return memberService;
	}
	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}
	public MemberCondition getCondition() {
		return condition;
	}
	public void setCondition(MemberCondition condition) {
		this.condition = condition;
	}
	
	public String getDialogValue() {
		return dialogValue;
	}
	public void setDialogValue(String dialogValue) {
		this.dialogValue = dialogValue;
	}
	private boolean isReadOnly(int status){
		if(STATUS_READONLY == status)return true;
		else return false;
	}
	
	public IBsCodeService getBsCodeService() {
		return bsCodeService;
	}
	public void setBsCodeService(IBsCodeService bsCodeService) {
		this.bsCodeService = bsCodeService;
	}
	public Members getOmembers() {
		return omembers;
	}
	public void setOmembers(Members omembers) {
		this.omembers = omembers;
	}
	/**
	 * 重組/準備 markNotice 資料
	 * @param memberId
	 */
	protected void setMarketNotice(Long memberId,String memberOid){
		if(members.getMarketNotice()!=null){
			members.getMarketNotice().clear();
		}else{
			members.setMarketNotice(new HashSet());
		}
		for(MarketNoticeVo marketNoticeVo:marketNoticeVoList){
			MarketNotice markNotice = new MarketNotice();
			markNotice.setChannelOid(marketNoticeVo.getChannelOid());
			markNotice.setChannelId(marketNoticeVo.getChannelId());
			
			if(StringUtils.isBlank(getMembers().getOid())){
				markNotice.setCreateTime(new Date());
				markNotice.setCreator(this.getUser().getUserId());
				markNotice.setCreatorName(this.getUser().getUserName());
			} else if(markNotice.getCreateTime()==null){
				markNotice.setCreateTime(new Date());
				markNotice.setCreator(this.getUser().getUserId());
				markNotice.setCreatorName(this.getUser().getUserName());
			}
			markNotice.setMemberId(memberId);
			markNotice.setMemberOid(memberOid);
			//markNotice.setModifyTime(new Date());
			//markNotice.setModifier(this.getUser().getUserId());
			//markNotice.setModifierName(this.getUser().getUserName());
			markNotice.setDmFlag(Boolean.FALSE);
			markNotice.setEdmFlag(Boolean.FALSE);
			markNotice.setMmsFlag(Boolean.FALSE);
			markNotice.setTelFlag(Boolean.FALSE);
			markNotice.setRecFlag(Integer.parseInt(marketNoticeVo.getConfirm()));
			if(markNotice.getRecFlag() > 0) {  //1:願意, 2:每檔必寄
				String[] status = marketNoticeVo.getChannel();
				//0:型錄/DM   "1:電子郵件(EDM)"  "2:電話"  "3:簡訊"
				if(status != null){
					for(String str:status){
						if("0".equals(str)){
							markNotice.setDmFlag(Boolean.TRUE);
						}else if("1".equals(str)){
							markNotice.setEdmFlag(Boolean.TRUE);
						}else if("2".equals(str)){
							markNotice.setTelFlag(Boolean.TRUE);
						}else if("3".equals(str)){
							markNotice.setMmsFlag(Boolean.TRUE);
						}
					}
				}
			}
			markNotice.setCompanyId(this.getUser().getCompanyId());
			members.getMarketNotice().add(markNotice);
		}
	}

	protected void doLoadMember(String oid)throws Exception{
		//if(marketNoticeVoList!=null && marketNoticeVoList.size()>0)marketNoticeVoList.clear();
		//marketNoticeVoList = new ArrayList();
		//members = this.getMemberService().loadMemberGeneralByOid(oid);
		members = this.getMemberService().findMemberByOid(oid, true);
		marketNoticeVoList = new ArrayList();
		String companyId = this.getUser().getCompanyId();
		members.setCompanyId(companyId);
		this.channelList = BsChannelDefinition.findAllChannelIncludeHQ3();
		String groupNo = (String)this.getSessionMap().get(MEMBER_LOGICGROUPNO);
		List<BrandVo> brandVos = BsChannelDefinition.findBrand(groupNo,companyId);
		if(brandVos!=null){
			int i=0;
			for (BrandVo bVo : brandVos) { //先綁定
				MarketNoticeVo marketNoticeVo = new MarketNoticeVo();
				marketNoticeVo.setChannelId(bVo.getBrand());
				marketNoticeVo.setChannelName1(bVo.getBrandName());
				marketNoticeVo.setShowId(false);
				marketNoticeVo.setConfirm("1");   //願意
				marketNoticeVo.setChannel(new String[]{"0","1","2","3"}); 
				marketNoticeVo.setChannelOid(bVo.getOid());
				if(!bVo.getLogicGroupNo().toString().equals(groupNo.toString())){
					marketNoticeVo.setAddCulm(i+1);
					i = marketNoticeVo.getAddCulm();
				}
				marketNoticeVoList.add(marketNoticeVo);
			}
		}else{
			for(BsChannel channel:channelList){
				if(StringUtils.isNotEmpty(companyId)&&!(companyId.equals(channel.getCompanyId().trim())))
					continue;
				if(channel.getStatus()) {
					MarketNoticeVo marketNoticeVo = new MarketNoticeVo();
					marketNoticeVo.setChannelId(channel.getChannelId());
					marketNoticeVo.setChannelName1(channel.getChannelName1());
					marketNoticeVo.setConfirm("1");    
					marketNoticeVo.setChannel(new String[]{"0","1","2","3"}); 
					marketNoticeVo.setChannelOid(channel.getOid());
					marketNoticeVoList.add(marketNoticeVo);
				}
			}
		}

		//通路
		Set<MarketNotice> marketNoticeList = members.getMarketNotice();
		if(marketNoticeList == null)log.info("marketNoticeList is Null");
		else log.info("marketNoticeList is not Null");
		Iterator<MarketNotice> it = marketNoticeList.iterator();
		while(it.hasNext()){
			MarketNotice marketNotice = it.next();
			for(MarketNoticeVo marketNoticeVo:marketNoticeVoList){
				if(marketNotice.getChannelOid().equals(marketNoticeVo.getChannelOid())){
					marketNoticeVo.setConfirm(marketNotice.getRecFlag().toString());
					marketNoticeVo.setChannel(new String[]{"","","",""});
					if(marketNotice.getRecFlag() > 0){
						String[] checkboxList = marketNoticeVo.getChannel();
						if(marketNotice.getDmFlag()) checkboxList[0] = "0";
						if(marketNotice.getEdmFlag()) checkboxList[1] = "1";
						if(marketNotice.getTelFlag()) checkboxList[2] = "2";
						if(marketNotice.getMmsFlag()) checkboxList[3] = "3";
						marketNoticeVo.setChannel(checkboxList);
					}
					marketNoticeVo.setMarketNotice(marketNotice);
				}
			}
		}
		
		//get mm_members_market data
		members = getMemberService().getMembersMarketData(members);
		
		this.mtPosVipMstList = this.getMemberService().findMtPosVipCulmMstByMemberId(members.getMemberId(),companyId);
	}

	/**
	 * do Entry
	 * @return
	 */
	public  String doEntry(){
		this.getSessionMap().put(MEMBER_LOGICGROUPNO, this.getCondition().getArgs());
		return Action.SUCCESS;
	}


	/**
	 * do Query
	 * @return String
	 */
	public String doQuery(){
		try {
			if(!this.hasToCountTotal()) {
				MemberCondition p = (MemberCondition)this.getSessionMap().get(MEMBER_CONDITION);
				p.setIsNeedCardExist("Y");
				this.setCondition(p);
			} else {
				this.getCondition().setIsNeedCardExist("Y");
				this.getSessionMap().put(MEMBER_CONDITION, this.getCondition());
				this.getPageBean().setJumpPage("");   //Reset JumpPage, 啟動執行重新查詢
			}

			QueryResult result = memberService.findMemberGeneralByCondition(this.getCondition(), this.getQueryStartIndex(),
					this.getPageBean().getPageSize(), this.hasToCountTotal(),true);

			this.setPageBeanByQueryResult(result,"doQuery");
			this.getSessionMap().put(MEMBER_PAGEBEAN, this.getPageBean());

			auditSuccessLog(); 
		} catch(Exception e) {
			auditFailLog();
			e.printStackTrace();
		}

		return Action.SUCCESS;
	}
	
	private String getStoreSystemIp() {
		Iterator iter = StoreSystemInfoDefinition.getIp_map().keySet().iterator();
		 
		iter.hasNext();
		return (String)iter.next();
	}
	
	protected void auditSuccessLog() {
		try {
			AuditRecord record = (AuditRecord)new AuditStore().getInstance().get();
			new AuditInfo(this.getUser().getUserId(), 
					java.net.Inet4Address.getLocalHost().getHostAddress(), 
					getStoreSystemIp(), 
					this.getClass().getSimpleName(),  
					record.toString()
					 ).setQuerySuccess();
		} catch (Exception e) {
			log.error("auditSuccessLog fail ", e);
		}
	}
	
	protected void auditFailLog() {
		try {
			AuditRecord record = (AuditRecord)new AuditStore().getInstance().get();
			new AuditInfo(this.getUser().getUserId(), 
					java.net.Inet4Address.getLocalHost().getHostAddress(), 
					getStoreSystemIp(), 
					this.getClass().getSimpleName(),  
					record.toString()
					 ).setQueryFail();
		} catch (Exception e) {
			log.error("auditFailLog fail ", e);
		}
	}

	/**
	 * do Edit
	 * @return String
	 * @throws Exception
	 */
	public String doEdit() throws Exception{
		String oid  = this.getRequest().getParameter("oid");
		if(oid!=null) {
			doLoadMember(oid);
			auditSuccessLog();
			if("ER".equals(members.getResId1())&&"008".equals(members.getResId2())){
				setErCard("Y");
				setEroption("2");
			}
		}else{
			String noid = this.getMemberService().queryMemberOidByPersoId(members.getPersonId());
			String toid = members.getOid();
			ModifyRecord mr = new ModifyRecord();
			final String word = "<Members><LoadReason>%s</LoadReason></Members>";
			mr.setObjectName("Members");
			mr.setPreviousVersion(FileTools.createClob(String.format(word, "")));
			mr.setNewVersion(FileTools.createClob(String.format(word, (BsCompanyDefinition.getBsCompanyById(BsCompanyDefinition.getCompanyId()).getCompanyName()+"新增"))));
			mr.setCreateTime(new Date());
			mr.setCreator(getUser().getUserId());
			mr.setCreatorName(getUser().getUserName());
			
			if("ER".equals(members.getResId1())&&"008".equals(members.getResId2())){
				setErCard("Y");
				if(StringUtils.isNotEmpty(noid)){
					doLoadMember(noid);
					auditSuccessLog();
					setEroption("1");
				}
				omembers = this.getMemberService().findMemberByOid(toid);
				//預製卡會刪除原先預留的member
				List<MmCard> list = getCardService().findMmCardByMemberOidCardType(omembers.getOid(), null);
				String storeId = "";
				String channelId="";
				String vipno = "";
				//更新mmcard 為帶出的會員
				for (MmCard mmCard : list) {
					storeId = mmCard.getStoreId();
					channelId = mmCard.getChannelId();
					vipno = mmCard.getVipNo();
					mmCard.setMemberId(members.getMemberId());
					mmCard.setMemberOid(members.getOid());
					mmCard.setStatus(1);
					mmCard.setApproveDate(new Date());
					mmCard.setModifyTime(new Date());
					mmCard.setModifier(this.getUser().getUserId());
					mmCard.setModifierName(this.getUser().getUserName());
					resetModifierName(getDialogValue(),members,mmCard);
					getCardService().updateCard(mmCard);
					this.getMemberService().saveOrUpdateMembers(members);
				}
				if (omembers.getMemberId().compareTo(members.getMemberId()) != 0) {
					criditForMemerBonus(omembers, members,storeId,channelId,vipno);
				}
				if(!members.getOid().equals(omembers.getOid()))
					this.getMemberService().deleteMembers(omembers.getOid());
				doLoadMember(members.getOid());
				setMarketNotice(members.getMemberId(), members.getOid());
				getMemberService().getMemberDao().updateAndAudit(members, BsCompanyDefinition.getCompanyId());
				if(!omembers.getOid().equals(members.getOid())){
					mr.setRefKey(members.getOid());
					getMemberService().getModifyService().getDao().save(mr);
				}
			}else{
				if(StringUtils.isNotEmpty(noid)){
					doLoadMember(noid);
					auditSuccessLog();
				}
				if(StringUtils.isEmpty(toid)){
					mr.setRefKey(members.getOid());
					getMemberService().getModifyService().getDao().save(mr);
				}
			}
		}
		if(this.isReadOnly(members.getStatus()))return READONLY;
		List list =  this.getBsCodeService().isRemarkAuth(this.getCurrentUser().getUserId()); 
		this.setRemarkAuth(list.size() == 0 ? false : true);
		return Action.SUCCESS;
	}
	
	public void criditForMemerBonus(Members oMebmer,Members nMember,String storeId,String channelId,String Vipno) throws Exception{
		MmMembersBonus ommMembersBonus =  getBonusCountSaleDataService().findMmMembersBonus(oMebmer.getMemberId(), oMebmer.getCompanyId());
		MmMembersBonus nmmMembersBonus =  getBonusCountSaleDataService().findMmMembersBonus(nMember.getMemberId(), nMember.getCompanyId());
		if(ommMembersBonus!=null){//預製卡有點數
			if(nmmMembersBonus==null){
				nmmMembersBonus = new MmMembersBonus(nMember.getCompanyId(), channelId, nMember.getMemberId());
				nmmMembersBonus.setBonusTotal(ommMembersBonus.getBonusTotal());
				nmmMembersBonus.setThisYearTot(ommMembersBonus.getThisYearTot());
				nmmMembersBonus.setLastYearTot(ommMembersBonus.getLastYearTot());
				nmmMembersBonus.setModifyTime(new Date());
			}else{
				nmmMembersBonus.setBonusTotalYday(nmmMembersBonus.getBonusTotal());
				nmmMembersBonus.setThisYearTotYday(nmmMembersBonus.getThisYearTot());
				nmmMembersBonus.setLastYearTotYday(nmmMembersBonus.getLastYearTot());
				nmmMembersBonus.setBonusTotal(nmmMembersBonus.getBonusTotal()+ommMembersBonus.getBonusTotal());
				nmmMembersBonus.setThisYearTot(nmmMembersBonus.getThisYearTot()+ommMembersBonus.getThisYearTot());
				nmmMembersBonus.setLastYearTot(nmmMembersBonus.getLastYearTot()+ommMembersBonus.getLastYearTot());
				nmmMembersBonus.setModifyTime(new Date());
			}
			
			BcBonusLog log = new BcBonusLog();
			log.setChannelId(channelId);
			log.setMemberId(nMember.getMemberId());
			log.setStoreId(storeId);
			log.setMemberOid(nMember.getOid());
			List<String> normal = new ArrayList<String>();
			List<String> exnormal = new ArrayList<String>();
			for (MmCard mmCard : this.getMemberService().findMemberByOid(nMember.getOid()).getMmCard()) {
				if(BsCompanyDefinition.getCompanyId().equals(mmCard.getCompanyId())&&mmCard.getCardType()==0){
					if(mmCard.getStatus()==1){
						normal.add(mmCard.getVipNo());
					}else if(mmCard.getStatus()==2){
						exnormal.add(mmCard.getVipNo());
					}
				}
			}
			log.setVipNo(normal.size()==0?exnormal.size()==0?"":exnormal.get(0):normal.get(0));
			log.setMarketId("BSC201007060");
			log.setReason("原身份證號["+oMebmer.getPersonId()+"]轉入/原會員編號["+oMebmer.getMemberId()+"] 轉入");
			log.setBonusAdd(ommMembersBonus.getBonusTotal());
			log.setBonusMins(0);
			log.setBonusTotal(nmmMembersBonus.getBonusTotal());
			log.setCreateTime(new Date());
			log.setCreator("SYS_BATCH");
			log.setCreatorName("SYS_BATCH");
			log.setModifyTime(new Date());
			log.setModifier("SYS_BATCH");
			log.setModifierName("SYS_BATCH");
			log.setBonusType(1);
			log.setTransDate(new Date());
			log.setCompanyId(BsCompanyDefinition.getCompanyId());
			log.setSerialNum(getBsManagerService().getBcBonusSerialNumDao().getSerialNum());
			this.getMemberService().saveOrUpdateMmMembersBonus(nmmMembersBonus);
			getBonusCountSaleDataService().getBonusCountSaleDataDAO().deleteObject(ommMembersBonus);
			getBonusCountSaleDataService().getBonusCountSaleDataDAO().saveOrUpdateObject(log);
		}
		getMtVipService().transfer(oMebmer, nMember, BsCompanyDefinition.getCompanyId());
	}
	
	public void resetModifierName(String type,Members members,MmCard mmCard){
		String companyid = BsCompanyDefinition.getCompanyId();
		if("1".equals(type)){
			if("1010".equals(companyid)){
				members.setModifierName("愛家卡申請書"+"-"+this.getUser().getUserName());
			}else if("1040".equals(companyid)){
				members.setModifierName("特家申請書"+"-"+this.getUser().getUserName());
			}else if("1050".equals(companyid)){
				members.setModifierName("C&B申請書"+"-"+this.getUser().getUserName());
			}
		}else{
			if("1010".equals(companyid)){
				members.setModifierName("愛家卡權益行使書"+"-"+this.getUser().getUserName());
			}else if("1040".equals(companyid)){
				members.setModifierName("特家權益行使書"+"-"+this.getUser().getUserName());
			}else if("1050".equals(companyid)){
				members.setModifierName("C&B權益行使書"+"-"+this.getUser().getUserName());
			}
		}
		members.setModifyTime(new Date());
		members.setModifier(companyid+"_"+this.getUser().getUserId());
	}
	
	/**
	 * do Read Only
	 * @return String
	 * @throws Exception
	 */
	public String doReadOnly() throws Exception{
		String oid  = this.getRequest().getParameter("oid");
		if(oid!=null) {
			doLoadMember(oid);
			auditSuccessLog();
		}
		return READONLY;
	}
	
	/**
	 * do Create
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public String doCreate() throws Exception{
		this.members =new Members();
		members.setMarrage(new Integer(2));
		members.setCreator(this.getUser().getUserId());
		members.setCreatorName(this.getUser().getUserName());
		members.setCreateTime(new Date());
		members.setModifier(this.getUser().getUserId());
		members.setModifierName(this.getUser().getUserName());
		members.setModifyTime(new Date());
		this.channelList = BsChannelDefinition.findAllChannelIncludeHQ3();
		String companyId = this.getUser().getCompanyId();
		String groupNo = (String)this.getSessionMap().get(MEMBER_LOGICGROUPNO);
		List<BrandVo> brandVos = BsChannelDefinition.findBrand(groupNo,companyId);
		if(brandVos!=null){
			int i=0;
			for (BrandVo bVo : brandVos) { //先綁定
				MarketNoticeVo marketNoticeVo = new MarketNoticeVo();
				marketNoticeVo.setChannelId(bVo.getBrand());
				marketNoticeVo.setChannelName1(bVo.getBrandName());
				marketNoticeVo.setShowId(false);
				marketNoticeVo.setConfirm("1");   //願意
				marketNoticeVo.setChannel(new String[]{"0","1","2","3"}); 
				marketNoticeVo.setChannelOid(bVo.getOid());
				if(!bVo.getLogicGroupNo().toString().equals(groupNo.toString())){
					marketNoticeVo.setAddCulm(i+1);
					i = marketNoticeVo.getAddCulm();
				}
				marketNoticeVoList.add(marketNoticeVo);
			}
		}else{
			for(BsChannel channel:channelList){
				if(StringUtils.isNotEmpty(companyId)&&!(companyId.equals(channel.getCompanyId().trim())))
					continue;
				if(channel.getStatus()) {
					MarketNoticeVo marketNoticeVo = new MarketNoticeVo();
					marketNoticeVo.setChannelId(channel.getChannelId());
					marketNoticeVo.setChannelName1(channel.getChannelName1());
					marketNoticeVo.setConfirm("1");   
					marketNoticeVo.setChannel(new String[]{"0","1","2","3"}); 
					marketNoticeVo.setChannelOid(channel.getOid());
					marketNoticeVoList.add(marketNoticeVo);
				}
			}
		}
		return Action.SUCCESS;
	}
	/**
	 * do Exit
	 * @return String
	 */
	public String doExit(){
		try {
			MemberCondition p = (MemberCondition)this.getSessionMap().get(MEMBER_CONDITION);
			if(p==null)	return Action.SUCCESS;
			this.setCondition(p);
			PageBean pageBean = (PageBean)this.getSessionMap().get(MEMBER_PAGEBEAN);
			this.setPageBean(pageBean);
			this.members = null; this.card = null; this.mmCardList = null;
		} catch(Exception e) {
			this.addActionError("載入失敗:"+e.getMessage()+"，請洽系統管理人員.") ;
			e.printStackTrace();
			return ERROR;
		}
		//return Action.SUCCESS;
		return doQuery();
	}


	/**
	 * do Save
	 * @return String
	 * @throws Exception
	 */
	public String doSave() throws Exception{
		try{
			if(members.getBirthdayYy()==null){
				members.setBirthdayYy(Integer.valueOf(1911));
			}else{
				members.setBirthdayYy(Integer.valueOf(members.getBirthdayYy())+1911);
			}
			
			if(StringUtils.isBlank(this.getMembers().getOid())){//新增會員
				setMarketNotice(members.getMemberId(),members.getOid());
				if("Y".equals(getErCard())){
					String erchannel = this.getMemberService().findChannelByER(this.getUser().getUserId(), this.getUser().getCompanyId());
					if("2".equals(getEroption())){
						members.setCreator(this.getUser().getUserId());
						members.setCreatorName(erchannel+this.getUser().getUserName());
						members.setCreateTime(new Date());
					}
				}
				this.getMemberService().createMember(members, this.getUser().getUserId(), this.getUser().getUserName(),this.getUser().getCompanyId());
				
				if(card != null && StringUtils.isNotEmpty(card.getChannelId()) && StringUtils.isNotEmpty(card.getStoreId())){
					log.info(" card != null ");
					card.setMemberOid(members.getOid());
					card.setMemberId(members.getMemberId());
					card.setCompanyId(this.getUser().getCompanyId());
					log.info(" getCardService().createCard.Start["+members.getPersonId()+"] : " + java.util.Calendar.getInstance().getTime() );
					this.getCardService().createCard(card, this.getUser().getUserId(), this.getUser().getUserName());
					log.info(" getCardService().createCard.End["+members.getPersonId()+"] : " + java.util.Calendar.getInstance().getTime() );
					
					//列印
					if("Y".equals(card.getDoPrint())){
						this.getRequest().setAttribute(doCreateCardVipNoList, card.getVipNo());
					}
				}
				MmMembersBonus mmMembersBonus = new MmMembersBonus(getCurrentUser().getCompanyId(),members.getChannelId(),members.getMemberId());
				memberService.saveOrUpdateMmMembersBonus(mmMembersBonus);
			}else{  //修改MEMBER
				/* 檢查1
				 * 若此會員名下有任一張商務會員卡且為卡片狀態為[1.正常],或[2.異常],
				 * 即顯示[此會員為商務會員!門店人員無修改權限,請客人於上班時間洽商務會員聯絡窗口!0800-008-700]
				 * 並不允許存檔
				 * 
				 * 200(actionName = doGeneralSave)，201(actionName = doHeadquartersSave)的存檔都執行相同的程式，但需求只要求200要做檢查
				 * */
				if("doGeneralSave".equals(actionName)) {
					List<MmCard> list = this.getCardService().findMmCardByMemberOidCardType(members.getOid(), MemberGlossary._mm_card_type_business);
					for(MmCard card : list){
						if(card.getStatus() == MemberGlossary._mm_card_status_normal || card.getStatus() == MemberGlossary._mm_card_status_abnormal){
							addActionMessage("此會員為商務會員!門店人員無修改權限,請客人於上班時間洽商務會員聯絡窗口!0800-008-700");
							return Action.SUCCESS;
						}
					}
				}
				setMarketNotice(members.getMemberId(),members.getOid());
				if("Y".equals(getErCard())){
					String erchannel = this.getMemberService().findChannelByER(this.getUser().getUserId(), this.getUser().getCompanyId());
					if("2".equals(getEroption())){
						members.setCreator(this.getUser().getUserId());
						members.setCreatorName(erchannel+this.getUser().getUserName());
						members.setCreateTime(new Date());
					}
				}
				this.getMemberService().updateMember(members, this.getUser().getUserId(), this.getUser().getUserName(),this.getUser().getCompanyId());
				/*
				 * 
				 * 編輯時,sysjob啟用下並檢查ui member是否有被異動目前適用200 201 2063(override) 204(override) 
				 */
				if("doGeneralSave".equals(actionName) || "doHeadquartersSave".equals(actionName) || "doHeadquartersSaveNew".equals(actionName)) {
					Members po = this.memberService.findMemberByOid(members.getOid());
					
					if(po.getEcYn() != null && po.getEcYn() == 1 && this.memberService.isOpenEcSycn()) {
						String errmsg = "";
						SyncTestriteCustomerResponse response = null;
						try{
							com.trg.oms.externalWS.ec.mobileVerify.SynCustomer request = new com.trg.oms.externalWS.ec.mobileVerify.SynCustomer();
							com.trg.oms.externalWS.ec.mobileVerify.SynCustomer.SyncTestriteCustomerRequest req = new com.trg.oms.externalWS.ec.mobileVerify.SynCustomer.SyncTestriteCustomerRequest();
							req.setSourceSystem("CRM_SYSTEM");
							req.setCrmMemberID(po.getMemberId().toString());
							request.setSyncTestriteCustomerRequest(req);
							SynCustomerService synCustomerService = (SynCustomerService) externalWSClient.create(SynCustomerService.class,"EC-WS-Syn", "SynCustomer", null);
							response = synCustomerService.doSynCustomer(request);
						}catch(Exception e){
							errmsg = e.getMessage();
						}
						MembersEcSycn ec = new MembersEcSycn();
						ec.setMemberId(po.getMemberId());
						if(StringUtils.isNotEmpty(errmsg)){
							ec.setResult("N");
							ec.setErrorMsg("連線錯誤");
						}else{
							ec.setResult((response.getSyncTestriteCustomerResponse().getRtnCode()>0)?"Y":null);
							String errMsg = StringUtils
									.substring(response.getSyncTestriteCustomerResponse().getRtnMsg(), 0, 25);
							ec.setErrorMsg(errMsg);
						}
						ec.setModifyTime(new Date());
						ec.setCreateTime(new Date());
						ec.setWebServiceName("SynCustomer");
						this.getMemberService().getMemberDao().getHibernateTemplate().save(ec);
					}
				}
				  
				this.mtPosVipMstList = this.getMemberService().findMtPosVipCulmMstByMemberId(members.getMemberId(),this.getUser().getCompanyId());
				return doEdit();
			}
		} catch(Exception e) {
			log.error(e);
			this.addActionError("儲存發生失敗: "+e.getMessage());
		}
		
		return Action.SUCCESS;
	}

	/**
	 * 刪除會員
	 * @return String
	 * @throws Exception
	 */
	public String doUpdateStatusToDelete() throws Exception{
		this.getMemberService().deleteMember(members.getOid(), members.getResulm(), members.getResId1(), members.getResId2(), 
				getUser().getUserId(), getUser().getUserName(), getUser().getCompanyId());
		doLoadMember(members.getOid());
		//this.getCardService().changeCardStatus(members.getOid(),"9",members.getResulm(),this.getUser());
		//getCardService().deleteMmCardByMemberOid(members.getOid(), members.getResulm(), getUser().getUserId(), getUser().getUserName());
		return Action.SUCCESS;
	}
	/**
	 * 啟用已停用之會員與卡片
	 * @return String
	 * @throws Exception
	 */
	public String doChangeStstusToOpen()throws Exception{
		this.getMemberService().enableMember(members, getUser().getUserId(), getUser().getUserName());
		doLoadMember(members.getOid());
		//this.getCardService().checkCardStatusToOpen(members.getOid(),this.getUser());
		//getCardService().enableMmCardByMemberOid(members.getOid(), getUser().getUserId(), getUser().getUserName());
		return Action.SUCCESS;
	}

	/**
	 * 停用會員與卡片
	 * @return String
	 * @throws Exception
	 */
	public String doUpdateStatusToStop() throws Exception{
		this.getMemberService().disableMember(members.getOid(), members.getResulm(), getUser().getUserId(), getUser().getUserName());
		doLoadMember(members.getOid());
		//this.getCardService().changeCardStatus(members.getOid(),"0",members.getResulm(),this.getUser());
		return Action.SUCCESS;
	}

	/**
	 * do Report
	 * @return String
	 */
	public String doReport(){
		try {
			members = memberService.findMemberByOid(members.getOid());
			
			mainRpt = memberService.qryTransReport(getCurrentUser().getCompanyId(), members);
		} catch(Exception e) { 
			e.printStackTrace();
		}
		return Action.SUCCESS;
	}
	
	/**
	 * do Print
	 * @return String
	 */  
	public String doPrint(){ 
		try{ 
			members = memberService.findMemberByOid(members.getOid()); 
			
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			WritableWorkbook wb = Workbook.createWorkbook(bos);
			WritableSheet ws = wb.createSheet("會員消費記錄統計表", 0); 

			WritableCellFormat wchB = new WritableCellFormat();   
            wchB.setAlignment(Alignment.CENTRE);  
            wchB.setBorder(Border.ALL, BorderLineStyle.THIN);  
            
            WritableFont wfc = new  WritableFont(WritableFont.ARIAL, 10 ,WritableFont.NO_BOLD, false , UnderlineStyle.NO_UNDERLINE, Colour.RED);   
			WritableCellFormat wchB1 = new WritableCellFormat(wfc);   
            wchB1.setAlignment(Alignment.CENTRE);  
            wchB1.setBorder(Border.ALL, BorderLineStyle.THIN); 

			ws.addCell(new Label(0, 0, "會員消費記錄統計表"));  
			ws.addCell(new Label(0, 1, "會員身份證字號", wchB)); 
			ws.addCell(new Label(0, 2, "會員名稱/公司名稱", wchB)); 
			ws.addCell(new Label(1, 1, members.getPersonIdDesc(), wchB)); 
			ws.addCell(new Label(1, 2, members.getName(), wchB)); 
			ws.addCell(new Label(0, 3, "查詢名細")); 
			
			ws.mergeCells(0,4,0,5);
			ws.addCell(new Label(0, 4, "通路", wchB)); 
			ws.mergeCells(1,4,1,5);
			ws.addCell(new Label(1, 4, "年份", wchB));
			ws.mergeCells(2,4,2,5);
			ws.addCell(new Label(2, 4, "消費次數", wchB)); 
			
			ws.addCell(new Label(3, 4, "總金額", wchB));
			ws.addCell(new Label(3, 5, "(含所有卡別)", wchB1));
		 
			ws.addCell(new Label(4, 4, "會員群組", wchB)); 
			ws.addCell(new Label(4, 5, "(僅限一般卡)", wchB1));
			
			ws.mergeCells(5,4,6,4);
			ws.addCell(new Label(5, 4, "點數餘額", wchB));
 
			ws.addCell(new Label(5, 5, "前年度", wchB));
			 
			ws.addCell(new Label(6, 5, "當年度", wchB));

			ws.mergeCells(7,4,7,5);
			ws.addCell(new Label(7, 4, "意見次數", wchB));
			ws.mergeCells(8,4,8,5);
			ws.addCell(new Label(8, 4, "維修單件數", wchB));
			
			MemberConsumMainRpt mrp = memberService.qryTransReport(getCurrentUser().getCompanyId(), members);
			
			Map<String, List<MemberConsumRpt>> map = mrp.getMemberConSumRptMap();
			
			MemberCntRpt mcr = mrp.getMemberCntRpt();
			
			Iterator iter = map.keySet().iterator();
			
			DecimalFormat formatter = new DecimalFormat("###,###,###");
			int st = 5;
			while(iter.hasNext()) {
				String key = (String)iter.next();
				List<MemberConsumRpt> list = map.get(key);
				
				for(int i = 0; i < list.size(); i++){
					MemberConsumRpt mcrt = list.get(i);
					
					if(i == 0) {
						System.out.println(key + " - " + list.size());
						ws.mergeCells(0, st + 1, 0, st + list.size());
						ws.addCell(new Label(0, st + 1, key, wchB)); 
					} 
					System.out.println(mcrt.getGuiDate());

					ws.addCell(new Label(1, st + 1, mcrt.getGuiDate(), wchB)); 
					ws.addCell(new Label(2, st + 1, String.valueOf(mcrt.getCntGui()), wchB)); 
					ws.addCell(new Label(3, st + 1, formatter.format(mcrt.getSumTol()), wchB)); 
					ws.addCell(new Label(4, st + 1, mcrt.getLevelExplain(), wchB)); 
					
					st ++;
				}
			} 

			ws.mergeCells(5,6,5, st);
			ws.addCell(new Label(5, 6, mcr.getLastYearTot(), wchB));
			ws.mergeCells(6,6,6, st);
			ws.addCell(new Label(6, 6, mcr.getThisYearTot(), wchB));
			ws.mergeCells(7,6,7, st);
			ws.addCell(new Label(7, 6, mcr.getCommentCnt().toString(), wchB));
			ws.mergeCells(8,6,8, st);
			ws.addCell(new Label(8, 6, mcr.getPsCnt().toString(), wchB));

			WritableFont wfc1 = new  WritableFont(WritableFont.ARIAL, 10 ,WritableFont.NO_BOLD, false , UnderlineStyle.NO_UNDERLINE, Colour.RED);   
			WritableCellFormat wchB2 = new WritableCellFormat(wfc1);   
			wchB2.setAlignment(Alignment.CENTRE);  
            
			ws.addCell(new Label(0, st + 1, "說明:會員群組定義說明: 以一般會員(不含員工.親友.貴賓身份)使用一般卡消費計算, 年度累積消費金額分別達到$12,000/ $11,999~$4500/ $4,499~$1者，各為V1/V2/V3", wchB2));
			
			wb.write();
			wb.close();
			
			this.fileName = new String("會員消費記錄統計表.xls".getBytes("Big5"), "ISO8859_1");
			this.inputStream = new ByteArrayInputStream(bos.toByteArray());
		} catch(Exception e){
			e.printStackTrace(); 
		}
		return SUCCESS;
	}

	public boolean checkPersonId() {
        if(getMembers() != null && StringUtils.trimToNull(getMembers().getOid()) !=null) {
		    if(this.memberService.isPersonIdExists(this.members.getPersonId())) {
		    	this.addActionError("身份證號/護照號碼("+this.members.getPersonId()+")重覆！");
			    return true;
		    }
		}
        return false;
	}
	
	private boolean isSame(String rdata, String ndata) {
		if(StringUtils.isBlank(rdata) && StringUtils.isBlank(ndata)) {
			return true;
		}
		
		return rdata.equals(ndata);
	} 
	
	public boolean isRemarkAuth() {
		return remarkAuth;
	}
	public void setRemarkAuth(boolean remarkAuth) {
		this.remarkAuth = remarkAuth;
	}
	public IMembersEcSycnService getMembersEcSycnService() {
		return membersEcSycnService;
	}
	public void setMembersEcSycnService(IMembersEcSycnService membersEcSycnService) {
		this.membersEcSycnService = membersEcSycnService;
	}
	public List<Map<String, String>> getMtPosVipMstList() {
		return mtPosVipMstList;
	}
	public void setMtPosVipMstList(List<Map<String, String>> mtPosVipMstList) {
		this.mtPosVipMstList = mtPosVipMstList;
	}
	public MemberConsumMainRpt getMainRpt() {
		return mainRpt;
	}
	public void setMainRpt(MemberConsumMainRpt mainRpt) {
		this.mainRpt = mainRpt;
	} 
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public InputStream getInputStream() {
		return inputStream;
	}
	public void setInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
	}
}
