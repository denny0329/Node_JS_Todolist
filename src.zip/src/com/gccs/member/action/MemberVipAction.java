package com.gccs.member.action;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.QueryResult;
import com.gccs.member.model.Members;
import com.gccs.member.model.condition.MemberCondition;
import com.gccs.mmbonus.model.MmMembersBonus;
import com.gccs.util.cache.BsCompanyDefinition;
import com.opensymphony.xwork2.Action;

public class MemberVipAction extends MemberBaseAction {
	private static final long serialVersionUID = -235467482428587989L;

	private static final Logger log = LogManager.getLogger(MemberVipAction.class) ;
	private static final String staff_cardType = "2"; // 員工卡折扣
	private static final String visitant_cardType = "7"; // 貴賓卡折扣
	private static final String friends_cardType = "3"; // 親友卡折扣
	
	private String myCardType;
	private String membersEmpId;
	
	public String getMyCardType() {
		return myCardType;
	}

	public void setMyCardType(String myCardType) {
		this.myCardType = myCardType;
	}

	public String getMembersEmpId() {
		return membersEmpId;
	}

	public void setMembersEmpId(String membersEmpId) {
		this.membersEmpId = membersEmpId;
	}

	/**
	 * 判斷是否為唯讀
	 * @param status
	 * @return boolean
	 */
	private boolean isReadOnly(int status){
		log.info("is ReadOnly() => show status : "+status);
		if(status == 0 || status == 9)return true;
		else return false;
	}

	/**
	 * 員工/親友/貴賓卡片資料維護-修改
	 * @return String
	 */
	public String doEdit() throws Exception{
		String oid  = this.getRequest().getParameter("oid");
		if(oid!=null) {
			super.doLoadMember(oid);
			auditSuccessLog();
		}
		this.setMembersEmpId(super.getMembers().getEmpId());
		if(this.isReadOnly(super.getMembers().getStatus())){
			log.info("doEdit is Readonly");
			return READONLY;
		}
		return Action.SUCCESS;
	}
	/**
	 * 員工/親友/貴賓卡片資料維護-查詢
	 * @return String
	 */
	public String doQuery(){
		try {
			if(!this.hasToCountTotal()) {
				MemberCondition p = (MemberCondition)this.getSessionMap().get(MEMBER_CONDITION);
				this.setCondition(p);
			} else {
				this.getSessionMap().put(MEMBER_CONDITION, this.getCondition());
				this.getPageBean().setJumpPage("");
			}

			QueryResult result = memberService.findMemberGeneralByCondition(this.getCondition(), this.getQueryStartIndex(),
					this.getPageBean().getPageSize(), this.hasToCountTotal(),false);

			this.setPageBeanByQueryResult(result,"doQuery");
			this.getSessionMap().put(MEMBER_PAGEBEAN, this.getPageBean());
			auditSuccessLog();
		} catch(Exception e) {
			e.printStackTrace();
			auditFailLog();
		}

		return Action.SUCCESS;
	}

	public String doSave() {
		if (super.getMembers().getBirthdayYy() == null) {
			super.getMembers().setBirthdayYy(Integer.valueOf(1911));
		} else {
			super.getMembers().setBirthdayYy(Integer.valueOf(super.getMembers().getBirthdayYy()) + 1911);
		}
		
		try {
			String oid = getMembers().getOid();
			// 檢查一：折扣卡選擇為親友卡折扣時，推薦人名下不可有別的親友卡
			if(friends_cardType.equalsIgnoreCase(myCardType)){
				List list = this.getMemberService().checkMembers(super.getMembers().getRecommand(), false);
				if (StringUtils.isBlank(getMembers().getOid())){ // 新增(>=1)
					if(list.size() >= 1){
						this.addActionError("更新失敗，推薦人只能申請一張親友卡！");
						return Action.INPUT;
					}
				} else {
					if(list.size() == 1){
						Map map = (Map)list.get(0);
						if(!oid.equalsIgnoreCase(map.get("OID").toString())){
							this.addActionError("更新失敗，推薦人只能申請一張親友卡！");
							return Action.INPUT;
						}
					}
					if(list.size() > 1){
						this.addActionError("更新失敗，推薦人只能申請一張親友卡！");
						return Action.INPUT;
					}
				}
			}
			
			// 檢查二：折扣卡選擇為親友卡折扣或員工卡折扣時，如果申請人有正常親友卡及員工卡則無法存檔
			if(staff_cardType.equalsIgnoreCase(myCardType) || friends_cardType.equalsIgnoreCase(myCardType)){
				List list = this.getMemberService().checkMembers(super.getMembers().getPersonId(), true);
				if (StringUtils.isBlank(getMembers().getOid())){ // 新增(>=1)
					if(list.size() >= 1){
						Map data = (Map)list.get(0);
						if(data.get("CARD_TYPE") == null){
							this.addActionError("更新失敗，申請人己有員工或親友資料，不可再次申請！");
							return Action.INPUT;
						}
						String message = ("2".equalsIgnoreCase(data.get("CARD_TYPE").toString()))? "員工卡" : "親友卡";
						this.addActionError("更新失敗，申請人己有一張" + message + "，不可再次申請！");
						return Action.INPUT;
					}
				} else { // 修改(>1)
					if(list.size() == 1){
						Map data = (Map)list.get(0);
						String message;
						if(data.get("CARD_TYPE") == null){
							this.addActionError("更新失敗，申請人己有員工或親友資料，不可再次申請！");
							return Action.INPUT;
						} else {
							message = ("2".equalsIgnoreCase(data.get("CARD_TYPE").toString()))? "員工卡" : "親友卡";
							
							if(!myCardType.equalsIgnoreCase(data.get("CARD_TYPE").toString())){
								this.addActionError("更新失敗，申請人己有一張" + message + "，不可再次申請！");
								return Action.INPUT;
							}
						}
						
						if(!oid.equalsIgnoreCase(data.get("OID").toString())){
							this.addActionError("更新失敗，申請人己有一張" + message + "，不可再次申請！");
							return Action.INPUT;
						}
					}
					
					if(list.size() > 1){
						Map data = (Map)list.get(0);
						if(data.get("CARD_TYPE") == null){
							this.addActionError("更新失敗，申請人己有員工或親友資料，不可再次申請！");
							return Action.INPUT;
						}
						
						String message = ("2".equalsIgnoreCase(data.get("CARD_TYPE").toString()))? "員工卡" : "親友卡";
						this.addActionError("更新失敗，申請人己有一張" + message + "，不可再次申請！");
						return Action.INPUT;
					}
				}
			} 

			super.getMembers().setEmpId(getMembersEmpId());
			
			if (StringUtils.isBlank(getMembers().getOid())) { // 新增
				setMarketNotice(super.getMembers().getMemberId(),super.getMembers().getOid());

				this.getMemberService().createMember(
						super.getMembers(),
						this.getUser().getUserId(),
						this.getUser().getUserName());

				if (super.getCard() != null) {
					super.getCard().setMemberOid(super.getMembers().getOid());
					super.getCard().setMemberId(super.getMembers().getMemberId());
					super.getCard().setRecommand(super.getMembers().getRecommand());

					this.getCardService().createCard(
							super.getCard(),
							this.getUser().getUserId(),
							this.getUser().getUserName());
					// 列印
					if ("Y".equals(this.getCard().getDoPrint())) {
						this.getRequest().setAttribute(doCreateCardVipNoList, super.getCard().getVipNo());
					}
				}
				MmMembersBonus mmMembersBonus = new MmMembersBonus(BsCompanyDefinition.getCompanyId(),super.getMembers().getChannelId(),
						super.getMembers().getMemberId());
				this.getMemberService().saveOrUpdateMmMembersBonus(mmMembersBonus);
			} else { // 修改
				setMarketNotice(super.getMembers().getMemberId(),super.getMembers().getOid());
				this.getMemberService().updateMember(
						super.getMembers(),
						this.getUser().getUserId(),
						this.getUser().getUserName());

				Members po = this.memberService.findMemberByOid(super.getMembers().getOid());
				
				if(po.getEcYn() != null && po.getEcYn() == 1 && this.memberService.isOpenEcSycn()) {
					this.getMembersEcSycnService().insertObj(po.getMemberId()); 
				} 
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
//			if (checkPersonId())
//				return Action.INPUT;
			this.addActionError("更新失敗，請洽系統管理人！");
			return Action.INPUT;
		}
		
		this.addActionMessage(getText("SAVE_SUCCESS"));
		return Action.SUCCESS;
	}
}
