package com.gccs.member.action;

public class MemberGeneralAction extends MemberBaseAction {

}
