package com.gccs.member.action;

import java.io.StringWriter;
import java.math.BigDecimal;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.web.client.ResourceAccessException;

import com.bnq.util.FileTools;
import com.bnq.util.QueryResult;
import com.gccs.bc.model.BcBonusLog;
import com.gccs.member.card.model.MmCard;
import com.gccs.member.model.Members;
import com.gccs.member.model.MembersEcSycn;
import com.gccs.member.model.MmMbPhoneReg;
import com.gccs.member.model.condition.MemberCondition;
import com.gccs.member.model.vo.AppPayCardVo;
import com.gccs.member.model.vo.QueryBonusRespVo;
import com.gccs.member.util.AppPayStaticString;
import com.gccs.mmbonus.model.MmMembersBonus;
import com.gccs.util.cache.BsCompanyDefinition;
import com.gccs.util.log.model.CrmWebServiceLog;
import com.gccs.util.log.model.ModifyRecord;
import com.gccs.util.model.AppQueryPayCardNoData;
import com.gccs.util.model.AppQueryBonusData;
import com.opensymphony.xwork2.Action;
import com.trg.oms.externalWS.ec.mobileVerify.ObjectFactory;
import com.trg.oms.externalWS.ec.mobileVerify.SynCustomerService;
import com.trg.oms.externalWS.ec.mobileVerify.SyncTestriteCustomerResponse;

public class MemberHeadquartersAction extends MemberBaseAction {
	private static final long serialVersionUID = -4566619179059232929L;
	private static final Logger log = LogManager.getLogger(MemberHeadquartersAction.class) ;
	
	private boolean showExplain;
	private String memberId;
	private BigDecimal appPayBonus = BigDecimal.ZERO;
	/**
	 * 判斷是否為唯讀
	 * @param status
	 * @return boolean
	 */
	private boolean isReadOnly(int status){
		if(status == 0 || status == 9)return true;
		else return false;
	}
	
	public String showDialog(){
		return SUCCESS;
	}
	
	public String showConfirm(){
		return SUCCESS;
	}
	
	/**
	 * 會員/卡片資料維護(總公司)-修改
	 */
	public String doEdit() throws Exception{
		String oid  = this.getRequest().getParameter("oid");
		if(oid!=null) {
			super.doLoadMember(oid);
			auditSuccessLog();
			Members mm = super.getMembers();
//			if("ER".equals(mm.getResId1())&&"008".equals(mm.getResId2())){
			if(StringUtils.isNotEmpty(getDialogValue())){
				super.setErCard("Y");
				super.setEroption("2");
			}
//			}
		}else{
			boolean iscard = false;
			Members mm = super.getMembers();
			if(mm.getBirthdayYy()==null){
				mm.setBirthdayYy(Integer.valueOf(1911));
			}else{
				if(!(mm.getBirthdayYy() >1911))
					mm.setBirthdayYy(Integer.valueOf(mm.getBirthdayYy())+1911);
			}
			//String noid = this.getMemberService().queryMemberOidByPersoId(mm.getPersonId());
			String noid = mm.getCellPhoneOid();
			if(StringUtils.isBlank(mm.getOid())){
				iscard = true;
				mm.setOid(noid);
			}
			ModifyRecord mr = new ModifyRecord();
			final String word = "<Members><LoadReason>%s</LoadReason></Members>";
			mr.setObjectName("Members");
			mr.setPreviousVersion(FileTools.createClob(String.format(word, "")));
			mr.setNewVersion(FileTools.createClob(String.format(word, (BsCompanyDefinition.getBsCompanyById(BsCompanyDefinition.getCompanyId()).getCompanyName()+"新增"))));
			mr.setCreateTime(new Date());
			mr.setCreator(getUser().getUserId());
			mr.setCreatorName(getUser().getUserName());
//			if("ER".equals(mm.getResId1())&&"008".equals(mm.getResId2())){
			if(StringUtils.isNotEmpty(getDialogValue())){
				super.setErCard("Y");
				if(StringUtils.isNotEmpty(noid)){
					doLoadMember(noid);
					auditSuccessLog();
					super.setEroption("1");
				}
				Members omm = this.getMemberService().findMemberByOid(mm.getOid());
				List<MmCard> list = getCardService().findMmCardByMemberOidCardType(omm.getOid(), null);
				String storeId = "";
				String channelId="";
				for (MmCard mmCard : list) {//預製卡只會有一筆default
					//backup data
					Date now = new Date();
					backupData(mmCard, now);
					
					storeId = mmCard.getStoreId();
					channelId = mmCard.getChannelId();
					mmCard.setMemberId(super.getMembers().getMemberId());
					mmCard.setMemberOid(super.getMembers().getOid());
					if (mmCard.getStatus().compareTo(2) == 0) {
					mmCard.setStatus(1);
					}
					mmCard.setApproveDate(new Date());
					mmCard.setModifyTime(new Date());
					mmCard.setModifier(this.getUser().getUserId());
					mmCard.setModifierName(this.getUser().getUserName());
					resetModifierName(super.getDialogValue(),super.getMembers(),mmCard);
					getCardService().updateCard(mmCard);
					this.getMemberService().saveOrUpdateMembers(super.getMembers());
					//backup data
					backupData(super.getMembers(), now);
				}
				if(iscard) {
					resetModifierName(super.getDialogValue(),omm,null);
					this.getMemberService().saveOrUpdateMembers(omm);
				}
				if (omm.getMemberId().compareTo(super.getMembers().getMemberId()) != 0) {
					criditForMemerBonus(omm, super.getMembers(),storeId,channelId);
				}
				if(!super.getMembers().getOid().equals(omm.getOid())){
					//會員合併時,若其中一筆會員編號完成認證,將資料合併後請將已認證狀態保留
					//無須人工判斷是要A併到B或B併到A
					//合併時若A或B的status為1，則合併後status為1,RES_ID1 & RES_ID2 需清空
					mergePhoneReg(omm, super.getMembers());
					
					this.getMemberService().deleteMembers(omm.getOid());	
					//backup data
					Date now = new Date();
					backupData(omm, now);
					//會員合併後要通知EC
					String timeout = "5000";
					memberEcSync(omm, timeout);
					memberEcSync(super.getMembers(), timeout);
				}
				doLoadMember(super.getMembers().getOid());
				setMarketNotice(super.getMembers().getMemberId(), super.getMembers().getOid());
				getMemberService().getMemberDao().updateAndAudit(super.getMembers(), BsCompanyDefinition.getCompanyId());
				if(!omm.getOid().equals(super.getMembers().getOid())){
					mr.setRefKey(super.getMembers().getOid());
					getMemberService().getModifyService().getDao().save(mr);
				}
				
				// 合併卡號後更新MT_POS_VIP的memberId
				getMemberService().getMemberDao().updateMtPosVipMemId(super.getMembers().getMemberId());
				
				// 處理Line合併或是解綁
				super.saveOrUpdateLine(omm, super.getMembers());
				
				// 合併卡置換會員編號
				memberService.callReplaceMemberIdService(String.valueOf(omm.getMemberId()),
						String.valueOf(super.getMembers().getMemberId()), 1000);
			}else{
				if(StringUtils.isNotEmpty(noid)){
					doLoadMember(noid);
					auditSuccessLog();
				}
				if(StringUtils.isEmpty(mm.getOid())){
					mr.setRefKey(super.getMembers().getOid());
					getMemberService().getModifyService().getDao().save(mr);
				}
			}
		}
		if(this.isReadOnly(super.getMembers().getStatus()))return READONLY;
		return Action.SUCCESS;
	}
	
	private void memberEcSync(Members member, String timeout) throws UnknownHostException {
		if(this.memberService.isOpenEcSycn()) {
				String errmsg = "";
				SyncTestriteCustomerResponse response = null;
				com.trg.oms.externalWS.ec.mobileVerify.SynCustomer request = null;
				try{
					request = new com.trg.oms.externalWS.ec.mobileVerify.SynCustomer();
					com.trg.oms.externalWS.ec.mobileVerify.SynCustomer.SyncTestriteCustomerRequest req = new com.trg.oms.externalWS.ec.mobileVerify.SynCustomer.SyncTestriteCustomerRequest();
					req.setSourceSystem("CRM_SYSTEM");
					req.setCrmMemberID(member.getMemberId().toString());
					request.setSyncTestriteCustomerRequest(req);
					SynCustomerService synCustomerService = (SynCustomerService) super.externalWSClient.create(SynCustomerService.class,"EC-WS-Syn", "SynCustomer", timeout);
					response = synCustomerService.doSynCustomer(request);
				}catch(Exception e){
					errmsg = e.getMessage();
					e.printStackTrace();
				}
				MembersEcSycn ec = new MembersEcSycn();
				ec.setMemberId(member.getMemberId());
				if(StringUtils.isNotEmpty(errmsg)){
					ec.setResult("N");
					ec.setErrorMsg("連線錯誤");
				}else{
					ec.setResult((response.getSyncTestriteCustomerResponse().getRtnCode()>0)?"Y":null);
					String errMsg = StringUtils
							.substring(response.getSyncTestriteCustomerResponse().getRtnMsg(), 0, 25);
					ec.setErrorMsg(errMsg);
				}
				ec.setModifyTime(new Date());
				ec.setCreateTime(new Date());
				ec.setWebServiceName("SynCustomer");
				this.getMemberService().getMemberDao().getHibernateTemplate().save(ec);
				ObjectFactory obj = new ObjectFactory();
				JAXBElement<com.trg.oms.externalWS.ec.mobileVerify.SynCustomer> in = obj.createSynCustomer(request);
				String input = jaxbObjectToXML(request,in);
				JAXBElement<Object> out = obj.createSynCustomerResponse(response);
				String output = jaxbObjectToXML(response,out);
				CrmWebServiceLog crmLog = new CrmWebServiceLog();
				InetAddress ip = InetAddress.getLocalHost();
				crmLog.setOid(ec.getOid());
				crmLog.setWebServiceName("SynCustomer"); 
				crmLog.setReqDate(new Date());
				crmLog.setContent(input+output);
				crmLog.setSourceIp(ip.getHostAddress());
				this.getMemberService().getMemberDao().getHibernateTemplate().save(crmLog);
			}
	}
	
	private static  String  jaxbObjectToXML(Object customer,Object des) {
	    String xmlString = "";
	    try {
	        JAXBContext context = JAXBContext.newInstance(customer.getClass());
	        Marshaller m = context.createMarshaller();
	        StringWriter sw = new StringWriter();
	        m.marshal(des, sw);
	        xmlString = sw.toString();
	    } catch (Exception e) {
	    		xmlString = e.getMessage();
	        e.printStackTrace();
	    }
	    return xmlString;
	}
	
	/**
	 * 會員合併時,若其中一筆會員編號完成認證,將資料合併後請將已認證狀態保留
	 * 無須人工判斷是要A併到B或B併到A
	 * 合併時若A或B的status為1，則合併後status為1,RES_ID1 & RES_ID2 需清空
	 * @throws Exception
	 */
	private void mergePhoneReg(Members omembers,Members members) throws Exception {
		final Integer ONE = new Integer(1);
		Date now =  new Date();
		if ((members.getEcYn()==null || !ObjectUtils.equals(ONE, members.getEcYn())) 
				&& (omembers.getEcYn()!=null || ObjectUtils.equals(ONE, omembers.getEcYn()))) {
			members.setEcYn(1);
		}
		if (!"1".equals(members.getCbEc()) && "1".equals(omembers.getCbEc())) {
			members.setCbEc("1");
		}
		if (ObjectUtils.equals(ONE, members.getStatus()) || ObjectUtils.equals(ONE, omembers.getStatus())) {
			members.setStatus(ONE);
			members.setResId1(null);
			members.setResId2(null);
			members.setResulm(null);
		}
		this.getMemberService().saveOrUpdateMembers(members);
		try {
			MmMbPhoneReg oPhoneReg = this.getMemberService().getMemberDao()
					.findMmMbPhoneReg(omembers.getMemberId().toString(),BsCompanyDefinition.getCompanyId());
			MmMbPhoneReg phoneReg = this.getMemberService().getMemberDao()
					.findMmMbPhoneReg(members.getMemberId().toString(),BsCompanyDefinition.getCompanyId());
			//backup data
			backupData(phoneReg, now);
			backupData(oPhoneReg, now);
			
			if(oPhoneReg!=null && phoneReg!=null && "YY".equals(oPhoneReg.getStatus())
					&& !"YY".equals(phoneReg.getStatus())) {
				phoneReg.setStatus(oPhoneReg.getStatus());
				phoneReg.setRegTime(oPhoneReg.getRegTime());
				phoneReg.setSendTime(oPhoneReg.getSendTime());
				phoneReg.setEcRegTime(oPhoneReg.getEcRegTime());
				phoneReg.setCheckYn(oPhoneReg.getCheckYn());
				phoneReg.setModifyTime(now);
				this.getMemberService().getMemberDao().getHibernateTemplate().saveOrUpdate(phoneReg);
				this.getMemberService().getMemberDao().getHibernateTemplate().delete(oPhoneReg);
			} else if (oPhoneReg!=null && phoneReg==null) {//轉換到另一個member
				oPhoneReg.setMemberId(members.getMemberId());
				oPhoneReg.setModifyTime(now);
				this.getMemberService().getMemberDao().getHibernateTemplate().saveOrUpdate(oPhoneReg);
			} else if (oPhoneReg!=null){
				this.getMemberService().getMemberDao().getHibernateTemplate().delete(oPhoneReg);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}
	}
	
	public void criditForMemerBonus(Members oMebmer,Members nMember,String storeId,String channelId,String vipno) throws Exception{
		String companyId = this.getUser().getCompanyId();
		MmMembersBonus ommMembersBonus =  getBonusCountSaleDataService().findMmMembersBonus(oMebmer.getMemberId(), companyId);
		MmMembersBonus nmmMembersBonus =  getBonusCountSaleDataService().findMmMembersBonus(nMember.getMemberId(), companyId);
		//backup data
		Date now = new Date();
		backupData(nmmMembersBonus, now);
		backupData(ommMembersBonus, now);
		
		if(ommMembersBonus!=null){//預製卡有點數
			if(nmmMembersBonus==null){
				nmmMembersBonus = new MmMembersBonus(nMember.getCompanyId(), channelId, nMember.getMemberId());
				nmmMembersBonus.setBonusTotal(ommMembersBonus.getBonusTotal());
				nmmMembersBonus.setThisYearTot(ommMembersBonus.getThisYearTot());
				nmmMembersBonus.setLastYearTot(ommMembersBonus.getLastYearTot());
				nmmMembersBonus.setModifyTime(new Date());
			}else{
				nmmMembersBonus.setBonusTotalYday(nmmMembersBonus.getBonusTotal());
				nmmMembersBonus.setThisYearTotYday(nmmMembersBonus.getThisYearTot());
				nmmMembersBonus.setLastYearTotYday(nmmMembersBonus.getLastYearTot());
				nmmMembersBonus.setBonusTotal(nmmMembersBonus.getBonusTotal()+ommMembersBonus.getBonusTotal());
				nmmMembersBonus.setThisYearTot(nmmMembersBonus.getThisYearTot()+ommMembersBonus.getThisYearTot());
				nmmMembersBonus.setLastYearTot(nmmMembersBonus.getLastYearTot()+ommMembersBonus.getLastYearTot());
				nmmMembersBonus.setModifyTime(new Date());
			}
			
			BcBonusLog log = new BcBonusLog();
			log.setChannelId("HQ");
			log.setMemberId(nMember.getMemberId());
			log.setStoreId("99");
			log.setMemberOid(nMember.getOid());
			List<String> normal = new ArrayList<String>();
			List<String> exnormal = new ArrayList<String>();
			for (MmCard mmCard : this.getMemberService().findMemberByOid(nMember.getOid()).getMmCard()) {
				if(BsCompanyDefinition.getCompanyId().equals(mmCard.getCompanyId())&&mmCard.getCardType()==0){
					if(mmCard.getStatus()==1){
						normal.add(mmCard.getVipNo());
					}else if(mmCard.getStatus()==2){
						exnormal.add(mmCard.getVipNo());
					}
				}
			}
			log.setVipNo(normal.size()==0?exnormal.size()==0?"":exnormal.get(0):normal.get(0));
			log.setMarketId("BSC201007060");
			log.setReason("原身份證號["+oMebmer.getPersonId()+"]轉入/原會員編號["+oMebmer.getMemberId()+"] 轉入");
			log.setBonusAdd(ommMembersBonus.getBonusTotal());
			log.setBonusMins(0);
			log.setBonusTotal(nmmMembersBonus.getBonusTotal());
			log.setCreateTime(new Date());
			log.setCreator("SYS_BATCH");
			log.setCreatorName("SYS_BATCH");
			log.setModifyTime(new Date());
			log.setModifier("SYS_BATCH");
			log.setModifierName("SYS_BATCH");
			log.setBonusType(1);
			log.setTransDate(new Date());
			log.setCompanyId(BsCompanyDefinition.getCompanyId());
			log.setSerialNum(getBsManagerService().getBcBonusSerialNumDao().getSerialNum());
			
			//負項
			BcBonusLog negativeLog = new BcBonusLog();
			BeanUtils.copyProperties(negativeLog, log);
			negativeLog.setMemberId(oMebmer.getMemberId());
			negativeLog.setMemberOid(oMebmer.getOid());
			negativeLog.setSerialNum(getBsManagerService().getBcBonusSerialNumDao().getSerialNum());
			negativeLog.setBonusAdd(log.getBonusMins());
			negativeLog.setBonusMins(log.getBonusAdd());
			log.setReason("原身份證號["+oMebmer.getPersonId()+"]轉入/原會員編號["+nMember.getMemberId()+"] 轉出");
			log.setVipNo(vipno);
			
			
			this.getMemberService().saveOrUpdateMmMembersBonus(nmmMembersBonus);
			getBonusCountSaleDataService().getBonusCountSaleDataDAO().deleteObject(ommMembersBonus);			
			
			//BONUS_ADD/BONUS_MINS/BONUS_TOTAL等於0不記錄
			if(log.getBonusAdd()!=0 || log.getBonusMins()!=0) {
				getBonusCountSaleDataService().getBonusCountSaleDataDAO().saveOrUpdateObject(log);
			}
			if(negativeLog.getBonusAdd()!=0 || negativeLog.getBonusMins()!=0) {
				getBonusCountSaleDataService().getBonusCountSaleDataDAO().saveOrUpdateObject(negativeLog);
			}
		}
		getMtVipService().transfer(oMebmer, nMember, BsCompanyDefinition.getCompanyId());
	}
	
	public void resetModifierName(String type,Members members,MmCard mmCard){
		String companyid = BsCompanyDefinition.getCompanyId();
		if("1".equals(type)){
			if("1010".equals(companyid)){
				members.setModifierName("愛家卡申請書"+"-"+this.getUser().getUserName());
			}else if("1040".equals(companyid)){
				members.setModifierName("特家申請書"+"-"+this.getUser().getUserName());
			}else if("1050".equals(companyid)){
				members.setModifierName("C&B申請書"+"-"+this.getUser().getUserName());
			}
		}else{
			if("1010".equals(companyid)){
				members.setModifierName("愛家卡權益行使書"+"-"+this.getUser().getUserName());
			}else if("1040".equals(companyid)){
				members.setModifierName("特家權益行使書"+"-"+this.getUser().getUserName());
			}else if("1050".equals(companyid)){
				members.setModifierName("C&B權益行使書"+"-"+this.getUser().getUserName());
			}
		}
		members.setModifyTime(new Date());
		members.setModifier(companyid+"_"+this.getUser().getUserId());
	}

	/**
	 * 會員/卡片資料維護(總公司)-查詢
	 */
	@SuppressWarnings("unchecked")
	public String doQuery(){
		try {
			if(!this.hasToCountTotal()) {
				MemberCondition p = (MemberCondition)this.getSessionMap().get(MEMBER_CONDITION);
				p.setIsNeedCardExist("Y");
				this.setCondition(p);
			} else {
				this.getCondition().setIsNeedCardExist("Y");
				this.getSessionMap().put(MEMBER_CONDITION, this.getCondition());
				this.getPageBean().setJumpPage("");
			}
			
			QueryResult result = memberService.findMemberGeneralByCondition(this.getCondition(), this.getQueryStartIndex(),
					this.getPageBean().getPageSize(), this.hasToCountTotal(),false);

			if (!result.getResult().isEmpty()) {
				// 顯示電子錢包卡號
				try {
					result = memberService.showAppPayCard(result);
				} catch (ResourceAccessException e) {
					log.error(e.getMessage(), e);
					
					// timeout標記
					result = memberService.isAppPayCardTimeout(result);
				}
			}
			
			this.setPageBeanByQueryResult(result,"doQuery");
			this.getSessionMap().put(MEMBER_PAGEBEAN, this.getPageBean());
			
			auditSuccessLog();
		} catch(Exception e) {
			auditFailLog();
			log.error(e.getMessage(), e);
		}

		return Action.SUCCESS;
	}
	
	@SuppressWarnings({ "unchecked", "unused" })
	public String phoneCertification(){
		try{
			String phone  = this.getRequest().getParameter("id");
			String name  = this.getRequest().getParameter("name");
			String memberId  = this.getRequest().getParameter("memberId");
			HttpServletRequest reg = this.getRequest();
			reg.setAttribute("memberId", memberId);
			if(phone==null&&name==null){
				phone = super.getPhone1();
				name = super.getName1();
				this.getRequest().setAttribute("id",phone);
				this.getRequest().setAttribute("name",name);
			}else{
				super.setPhone1(phone);
				this.getRequest().setAttribute("id",phone);
				if(name!=null && !"null".equals(name)){
					this.getRequest().setAttribute("name",name);
				}else{
					super.setName1(name);
				}
			}
			QueryResult result = null;
			if (StringUtils.isNotEmpty(memberId)) {
				if(StringUtils.isNotEmpty(name) && !"null".equals(name)){ 
					name = java.net.URLDecoder.decode(name,"UTF-8");
					result = memberService.findMemberByPhoneAndNameFilterMemberId(memberId, phone, name, this.getQueryStartIndex(),this.getPageBean().getPageSize(), this.hasToCountTotal(),BsCompanyDefinition.getCompanyId());
				}else{
					result = memberService.findMemberByPhoneFilterMemberId(memberId, phone, this.getQueryStartIndex(),this.getPageBean().getPageSize(), this.hasToCountTotal(),BsCompanyDefinition.getCompanyId());
				}
			} else {
				if(StringUtils.isNotEmpty(name) && !"null".equals(name)){ 
					name = java.net.URLDecoder.decode(name,"UTF-8");
					result = memberService.findMemberByPhoneAndName(phone, name, this.getQueryStartIndex(),this.getPageBean().getPageSize(), this.hasToCountTotal(),BsCompanyDefinition.getCompanyId());
				}else{
					result = memberService.findMemberByPhone(phone, this.getQueryStartIndex(),this.getPageBean().getPageSize(), this.hasToCountTotal(),BsCompanyDefinition.getCompanyId());
				}
			}
			
			if (!result.getResult().isEmpty()) {
				
				// 呼叫電子錢包卡號
				// 查詢原會員有無錢包
				List<String> memberIdList = new ArrayList<>();
				memberIdList.add(memberId);
				AppQueryPayCardNoData<AppPayCardVo> originAppPayCardRes = memberService.callAppQueryPayCard(memberIdList, 5000);
				String msg = String.format(AppPayStaticString.ERR_FORMAT, originAppPayCardRes.getErrorCode(), originAppPayCardRes.getMessage());
				log.info("原會員呼叫AppQueryPayCard結果: " + msg);
				
				// 查詢可合併會員錢包
				memberIdList.clear();
				memberIdList = memberService.convertMemberIdList(result);
				
				AppQueryPayCardNoData<AppPayCardVo> appPayCardRes = new AppQueryPayCardNoData<>();
				try {
					appPayCardRes = memberService.callAppQueryPayCard(memberIdList, 5000);
				} catch (Exception e) {
					addActionError(AppPayStaticString.APP_PAY_ERROR_FOR_CARD);
					return ERROR;
				}

				if (AppPayStaticString.ERROR.equals(appPayCardRes.getStatus())) {
					msg = String.format(AppPayStaticString.ERR_FORMAT, appPayCardRes.getErrorCode(), appPayCardRes.getMessage());
					log.info("呼叫AppQueryPayCard失敗: " + msg);
					
					result = memberService.memberHasAppPayCard(result, appPayCardRes, originAppPayCardRes);
				} else {
					result = memberService.memberHasAppPayCard(result, appPayCardRes, originAppPayCardRes);
					
					// 呼叫電子錢包餘額
					AppQueryBonusData<QueryBonusRespVo> appPayBonusRes = memberService.callAppQueryBonus(memberIdList, 7000);
					if (AppPayStaticString.ERROR.equals(appPayBonusRes.getStatus())) {
						msg = String.format(AppPayStaticString.ERR_FORMAT, appPayBonusRes.getErrorCode(), appPayBonusRes.getMessage());
						log.info("呼叫AppQueryBonus失敗: " + msg);
						if (memberService.checkAppErrorCode(appPayBonusRes.getErrorCode())) {
							addActionError(AppPayStaticString.APP_PAY_ERROR_FOR_MERGE);
							return ERROR;
						}
					} else {
						result = memberService.memberSetAppPayBonus(result, appPayBonusRes);
					}
				}
			}
			
			// 顯示合併提醒
			String permission = this.getRequest().getParameter("permission");
			showExplain = ("normalStore".equals(permission) || "true".equals(permission)) ? true : false;
			
			this.setPageBeanByQueryResult(result,"doPhoneQuery");
			this.getSessionMap().put(MEMBER_PHONE_PAGEBEAN, this.getPageBean());			
		}catch(Exception e){
			log.error(e.toString(), e);
			addActionError(AppPayStaticString.EXCEPTION);
		}
		return SUCCESS;
	}

	public String mergeMemberAndCheckAppPayBonus(){
		try{
			List<String> memberIdList = new ArrayList<>();
			memberIdList.add(memberId);
			
			AppQueryPayCardNoData<AppPayCardVo> appPayCardRes = memberService.callAppQueryPayCard(memberIdList, 5000);
			if (AppPayStaticString.ERROR.equals(appPayCardRes.getStatus())) {
				String msg = String.format(AppPayStaticString.ERR_FORMAT, appPayCardRes.getErrorCode(), appPayCardRes.getMessage());
				log.info("呼叫AppQueryPayCard失敗: " + msg);
			} else {
				AppQueryBonusData<QueryBonusRespVo> response = memberService.callAppQueryBonus(memberIdList, 7000);
				if (AppPayStaticString.ERROR.equals(response.getStatus())) {
					String msg = String.format(AppPayStaticString.ERR_FORMAT, response.getErrorCode(), response.getMessage());
					log.info("呼叫AppQueryBonus失敗: " + msg);
					appPayBonus = BigDecimal.ONE.negate();
				} else {
					appPayBonus = memberService.calculateAppPayBonusSum(response);
				}
			}
			
		}catch(Exception e){
			log.error(e.getMessage(), e);
			appPayBonus = BigDecimal.ONE.negate();
		}
		return SUCCESS;
	}
	
	public boolean isShowExplain() {
		return showExplain;
	}

	public void setShowExplain(boolean showExplain) {
		this.showExplain = showExplain;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public BigDecimal getAppPayBonus() {
		return appPayBonus;
	}

	public void setAppPayBonus(BigDecimal appPayBonus) {
		this.appPayBonus = appPayBonus;
	}
}
