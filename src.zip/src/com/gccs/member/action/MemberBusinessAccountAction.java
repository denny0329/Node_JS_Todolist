package com.gccs.member.action;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.dao.DataIntegrityViolationException;

import com.bnq.util.AppContext;
import com.bnq.util.PageBean;
import com.bnq.util.QueryResult;
import com.bnq.util.StringId;
import com.bnq.util.ViewPage;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gccs.base.action.BaseAction;
import com.gccs.bc.model.MmAccCulmMst;
import com.gccs.marketing.IMarketingService;
import com.gccs.marketing.action.DiscountSkuParamUtil;
import com.gccs.marketing.model.Discount;
import com.gccs.marketing.model.vo.DiscountSkuVo;
import com.gccs.marketing.model.vo.VoUtil;
import com.gccs.marketing.util.DiscountSelectItem;
import com.gccs.member.card.model.MmCard;
import com.gccs.member.model.Account;
import com.gccs.member.model.AccountHq;
import com.gccs.member.model.MmAccAttach;
import com.gccs.member.model.MmArBank;
import com.gccs.member.model.MmThresholdMst;
import com.gccs.member.model.condition.AccountCondition;
import com.gccs.member.model.vo.AccountVo;
import com.gccs.member.rfc.MemberAccountRfc;
import com.gccs.member.rfc.MemberCardRfc;
import com.gccs.member.service.AccountService;
import com.gccs.member.service.IAccountService;
import com.gccs.member.service.ICardService;
import com.gccs.member.service.IMemberService;
import com.gccs.member.service.MemberService;
import com.gccs.member.util.MemberGlossary;
import com.gccs.util.cache.BsCompanyDefinition;
import com.opensymphony.xwork2.Action;

/* 程式的處理
 * @author neo
 */
public class MemberBusinessAccountAction extends BaseAction {
	private static final String RESULT = "result";

	private static final long serialVersionUID = -5493530933759926238L;

	private static final Logger log = LogManager.getLogger(MemberBusinessAccountAction.class) ;
	
	public static final String EDIT = "edit";
	public static final String VIEW = "view";
	
	private AccountCondition condition;

	private static String _session_key_account_query = "_session_account_query";
	private static String _session_key_account = "_session_account";
	private static String _session_key_accountvo = "_sessoin_account_vo" ;
	private static String _session_key_account_list = "_session_account_restriction" ;
	private static IMemberService memberService;
	private IMarketingService mtService;
	private IAccountService accountService;
	private ICardService cardService;
	private String flag;
	private Map<String, Object> jsonResult;
	private String thresholdId;
	private String bankId;
	private String branchId;
	private List<MmAccAttach> accAttachList;
	private MmAccCulmMst accCulmMst;
	private static DiscountSelectItem selectItem;
	private List<MmArBank> bankIdList;
	private List<MmArBank> branchIdList;
	private List<MmArBank> bankDescList;
	private MemberAccountRfc memberAccountRfc;
	
	public ICardService getCardService() {
		return cardService;
	}
	public void setCardService(ICardService cardService) {
		this.cardService = cardService;
	}

	//upload Field
	private File uploadFile;
	private String oid;

	public IAccountService getAccountService() {
		return accountService;
	}
	public void setAccountService(IAccountService accountService) {
		this.accountService = accountService;
	}
	public File getUploadFile() {
		return uploadFile;
	}
	public void setUploadFile(File uploadFile) {
		this.uploadFile = uploadFile;
	}
	public String getOid() {
		return oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}

	public IMarketingService getMtService() {
		return mtService;
	}
	public void setMtService(IMarketingService mtService) {
		this.mtService = mtService;
	}

	private AccountVo vo ;
	private String refOid;

	public String getRefOid() {
		return refOid;
	}
	public void setRefOid(String refOid) {
		this.refOid = refOid;
	}
	public AccountCondition getCondition() {
		return condition;
	}
	public void setCondition(AccountCondition condition) {
		this.condition = condition;
	}

	public IMemberService getMemberService() {
		return memberService;
	}
	public void setMemberService(IMemberService memberService) {
		this.memberService = memberService;
	}

	public Account getAccount() {
		Account account = (Account)this.getSessionMap().get(_session_key_account);
		if(account == null) {
			account = new Account();
			setAccount(account);
		}
		return account;
	}
	public void setAccount(Account account) {
		this.getSessionMap().put(_session_key_account,account);
	}
	public AccountVo getVo() {
		if(this.getSessionMap().get(_session_key_accountvo) != null) {
			vo = (AccountVo)this.getSessionMap().get(_session_key_accountvo) ;
		}
		return vo;
	}
	public void setVo(AccountVo vo) {
		this.getSessionMap().put(_session_key_accountvo, vo);
		this.vo = vo;
	}
	public String doBusinessAccountQuery(){

		try {
			if(!this.hasToCountTotal()) {
				AccountCondition p = (AccountCondition)this.getSessionMap().get(_session_key_account_query);
				this.setCondition(p);
			} else {
				this.getSessionMap().put(_session_key_account_query, this.getCondition());
				this.getPageBean().setJumpPage("");
			}

			QueryResult result = accountService.findAccountByCondition(this.getCondition(), this.getQueryStartIndex(),
					this.getPageBean().getPageSize(), this.hasToCountTotal());

			this.setPageBeanByQueryResult(result,"doBusinessAccountQuery");

		} catch(Exception e) {
			e.printStackTrace();
			this.addActionError("查詢發生失敗: "+e.getMessage());
		}
		return Action.SUCCESS;
	}
	
	public String doMmAccTmpQuery(){
		
		try {
			if(!this.hasToCountTotal()) {
				AccountCondition p = (AccountCondition)this.getSessionMap().get(_session_key_account_query);
				this.setCondition(p);
			} else {
				this.getSessionMap().put(_session_key_account_query, this.getCondition());
				this.getPageBean().setJumpPage("");
			}
			
			QueryResult result = accountService.findMmAccTmpAndStatusIsZero(this.getQueryStartIndex(),
					this.getPageBean().getPageSize(), this.hasToCountTotal());
			flag = "MmAccTmp";
			this.setPageBeanByQueryResult(result,"doMmAccTmpQuery");
			
		} catch(Exception e) {
			e.printStackTrace();
			this.addActionError("查詢發生失敗: "+e.getMessage());
		}
		return Action.SUCCESS;
	}
	public String doIndexBusinessAccount(){
		this.getSessionMap().remove(_session_key_account_query);
		this.getSessionMap().remove(_session_key_account);
		return Action.SUCCESS;
	}

	public String doBusinessAccountEdit(){
		String oid  = this.getRequest().getParameter("oid");
		try {
			setAccount(this.getAccountService().findAccountByOid(oid));
			setAccAttachList(this.getAccountService().selectMmAccAttachOrTmpAndCovert(getAccount().getAccountId(), getAccount().getStatus()));
			if (getAccount().getAccType() == 0 || getAccount().getAccType() == 1) {
				setAccCulmMst(this.getAccountService().findMmAccCulmMstByAccountId(getAccount().getAccountId()));
			}
			setMmArBankVal();
		} catch(Exception e) {
			log.error(e.getMessage(), e);
			this.addActionError("取得商務帳號資料時發生失敗: "+e.getMessage());
		}
		return Action.SUCCESS;
	}
	
	public String doMmAccTmpEdit(){
		String oid  = this.getRequest().getParameter("oid");
		try {
			
			setAccount(this.getAccountService().selectAccTmpAndCovert(oid));
			setAccAttachList(this.getAccountService().selectAccAttachTmpAndCovert(oid));
			if (getAccount().getAccType() == 0 || getAccount().getAccType() == 1) {
				setAccCulmMst(this.getAccountService().findMmAccCulmMstByAccountId(getAccount().getAccountId()));
			}
			setMmArBankVal();
		} catch(Exception e) {
			log.error(e.getMessage(), e);
			this.addActionError("取得MmAccTmp資料時發生失敗: "+e.getMessage());
		}
		return Action.SUCCESS;
	}
	
	public static List<StringId> selectThresholdId() throws Exception {
		List<StringId> typeList = new ArrayList<>();
		MmThresholdMst mst = new MmThresholdMst();
		mst.setStatus("1");
		mst.setCompanyId(BsCompanyDefinition.getCompanyId());
		List<MmThresholdMst> mstList = memberService.selectMmThresholdMst(mst);
		
		StringId defaultSelect = new StringId("", "請選擇");
		typeList.add(defaultSelect);
		for (MmThresholdMst mstVo : mstList) {
			StringId id = new StringId(mstVo.getThresholdId(), mstVo.getThresholdName());
			typeList.add(id);
		}
		return typeList;
	}
	
	public static List<StringId> showDiscCardOidByThresholdId(String oid) throws Exception {
		List<StringId> typeList = new ArrayList<>();

		StringId defaultSelect = new StringId("", "請選擇");
		typeList.add(defaultSelect);
		if (StringUtils.isNotBlank(oid)) {
			Discount discount = new Discount();
			discount.setOid(oid);
			MemberService memberService = (MemberService)AppContext.getBean("memberService");
			List<Discount> list = memberService.selectMtDardDiscount(discount);
			
			for (Discount vo : list) {
				StringId idVo = new StringId(vo.getOid(), vo.getDiscountCardName());
				typeList.add(idVo);
			}
		}

		return typeList;
	}
	
	@SuppressWarnings({ "unchecked", "static-access" })
	public String getDiscCardOidByThresholdId() throws Exception {
	    jsonResult = new HashMap<>();
		List<Discount> discountList = new ArrayList<>();
	    
	    if (AccountService.THR2999999.equals(thresholdId) ||
	    		AccountService.THR2999998.equals(thresholdId) ||
	    		AccountService.THR2999997.equals(thresholdId)) {
			selectItem = new DiscountSelectItem();
			List<StringId> list = selectItem.getDiscountCardNameList("1", false);
			
			for (int i = 0; i < list.size(); i++) {
				if (i > 0) {
					Discount discout = new Discount();
					discout.setOid(list.get(i).getId());
					discout.setDiscountCardName(list.get(i).getName());
					discountList.add(discout);
				}
			}
			jsonResult.put(RESULT, discountList);
		} else {
			discountList = memberService.findDiscCardOidByThresholdId(thresholdId);
			jsonResult.put(RESULT, discountList);
		}
	    return SUCCESS;
	}
	
	public String doBusinessAccountView(){
		String oid  = this.getRequest().getParameter("oid");
		try {
			setAccount(this.getAccountService().findAccountByOid(oid));
			setAccAttachList(this.getAccountService().selectMmAccAttachOrTmpAndCovert(getAccount().getAccountId(), getAccount().getStatus()));
			if (getAccount().getAccType() == 0 || getAccount().getAccType() == 1) {
				setAccCulmMst(this.getAccountService().findMmAccCulmMstByAccountId(getAccount().getAccountId()));
			}
			setMmArBankVal();
		} catch(Exception e) {
			log.error(e.getMessage(), e);
			this.addActionError("取得商務帳號資料時發生失敗: "+e.getMessage());
		}
		return Action.SUCCESS;
	}
	public String doBusinessAccountCreate(){
		Account _account = new Account();
		_account.setStatus(MemberGlossary._mm_account_status_applied);
		setModifyInfo(_account, true);
		setAccount(_account);
		try {
			setMmArBankVal();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			this.addActionError("取得MmArBank資料時發生失敗: "+e.getMessage());
		}
		return Action.SUCCESS;
	}

	public String doBusinessAccountExit(){
		try {
			AccountCondition p = (AccountCondition)this.getSessionMap().get(_session_key_account_query);
			if(p==null){
				return Action.SUCCESS;
			}
			this.setCondition(p);

			QueryResult result = accountService.findAccountByCondition(this.getCondition(), this.getQueryStartIndex(),
					this.getPageBean().getPageSize(), this.hasToCountTotal());
			this.getPageBean().setJumpPage("");
			this.setPageBeanByQueryResult(result,"doBusinessAccountQuery");
			this.getSessionMap().remove(_session_key_account);


		} catch(Exception e) {
			this.addActionError("載入失敗:"+e.getMessage()+"，請洽系統管理人員.") ;
			e.printStackTrace();
			return ERROR;
		}
		return Action.SUCCESS;
	}

	public String doBusinessAccountSave() {
		try {
			Date modifyTime = new Date();
			Account _account = getAccount();
			//新增
			if(StringUtils.trimToNull(getAccount().getOid()) == null) {
				setModifyInfo(_account, true);
				_account.setCompanyId(BsCompanyDefinition.getCompanyId());
				accountService.createAccount(_account, "");
			} else if (StringUtils.isNotBlank(getAccount().getOid()) && StringUtils.isBlank(getAccount().getAccountId())) {
				setModifyInfo(_account, true);
				_account.setCompanyId(BsCompanyDefinition.getCompanyId());
				accountService.createAccount(_account, "accTmp");
			} else
			//修改
			{
				setModifyInfo(_account, false);
				//上傳SAP-商務帳號
				if(_account.getUploadSap()!=null && _account.getUploadSap()){
					if( _account.getStatus() >= 3 ){
						try{
	//						_account.setUploadSapMsg(accountService.uploadSap(_account,SapAdapterUtil.MODIFY));
							if( !memberAccountRfc.execute(_account) ){
								this.addActionMessage("執行上傳SAP失敗 : " + _account.getSapMessage());
							}
							else{
								//上傳SAP-卡
								List<MmCard> cards = cardService.findMmCardByAccountIdCardType(_account.getAccountId(), null);
								if( cards != null && cards.size() > 0 ){
									MemberCardRfc cardRfc = new MemberCardRfc();
									cardRfc.execute(_account.getAccountId(), cards);
								}
							}
						}catch(Exception e){
							log.error(e.getMessage(), e);
							this.addActionMessage("執行上傳SAP失敗 : " + e.getMessage());
						}
					}
				}
				accountService.updateAccount2(_account, accAttachList);
				/*
				Account oldAccount = this.getAccountService().loadBusinessAccountByOid(getAccount().getOid());
				accountService.updateAccount(getAccount());
				doCheckChangeDisCardOid(getAccount());
				ModifyService modifyService = (ModifyService)AppContext.getBean("modifyService");
				modifyService.createModifyRecord(getAccount().getOid(), oldAccount, getAccount(), this.getUser().getUserId(), this.getUser().getUserName());
				*/
			}
			setAccAttachList(this.getAccountService().selectMmAccAttachOrTmpAndCovert(getAccount().getAccountId(), getAccount().getStatus()));
			if (getAccount().getAccType() == 0 || getAccount().getAccType() == 1) {
				setAccCulmMst(this.getAccountService().findMmAccCulmMstByAccountId(getAccount().getAccountId()));
			}
			setMmArBankVal();
			
			if(!(_account.getStatus() == MemberGlossary._mm_account_status_applied ||
					_account.getStatus() == MemberGlossary._mm_account_status_approved || 
					_account.getStatus() == MemberGlossary._mm_account_status_restricted)){  
				return VIEW;
			}

		} catch (DataIntegrityViolationException con) {
			log.error(con.getMessage(), con);
			this.addActionError("儲存發生失敗: " + con.getCause().getCause().getMessage());
			preparePageValue();
			return INPUT;
			
		} catch(Exception e) {
			log.error(e.getMessage(), e);
			this.addActionError("儲存發生失敗: "+e.getMessage());
			preparePageValue();
			return INPUT;
		}
		return Action.SUCCESS;
	}
	private void preparePageValue() {
		try {
			setAccount(this.getAccountService().findAccountByOid(getAccount().getOid()));
			setAccAttachList(this.getAccountService().selectMmAccAttachOrTmpAndCovert(getAccount().getAccountId(), getAccount().getStatus()));
			if (getAccount().getAccType() == 0 || getAccount().getAccType() == 1) {
				setAccCulmMst(this.getAccountService().findMmAccCulmMstByAccountId(getAccount().getAccountId()));
			}
			setMmArBankVal();
		} catch (Exception e1) {
			log.error(e1.getMessage(), e1);
		}
	}
	
	/*
	private void doCheckChangeDisCardOid(Account vo) throws Exception{
		if(vo != null && vo.getDiscCardOid() != null && vo.getOldDiscCardOid() != null
				&& vo.getDiscCardOid().equals(vo.getOldDiscCardOid())) {
			//沒有變更DisCardOid, 不需更新
		} else {
			//需求變更為直接更新DISC_CARD_OID
			List<MmCard> list= getCardService().findMmCardByAccountIdCardType(
					getAccount().getAccountId(), MemberGlossary._mm_card_type_bussiness);
			if(list != null && list.size() > 0) {
				for(MmCard card:list){
					card.setDisCardOid(vo.getDiscCardOid());
					card.setMemo("折扣卡更動");
					card.setModifier(vo.getModifier());
					card.setModifierName(vo.getModifierName());
					card.setModifyTime(vo.getModifyTime());
				}
				this.getCardService().updateCard(list);
			}
		}
	}
	*/
	
	public String doUpdateStatus() {
		Account _account = getAccount();
		Integer accountStatus = _account.getStatus();
		
		//Account oldAccount = this.getAccountService().loadBusinessAccountByOid(.getOid());
		//this.getAccountService().updateAccountStatus(getAccount().getStatus(),getAccount().getReason(),getAccount().getOid());
		//異動紀錄
		//Account newAccount = this.getMemberService().loadBusinessAccountByOid(getAccount().getOid());
		//ModifyService modifyService = (ModifyService)AppContext.getBean("modifyService");
		//modifyService.createModifyRecord(getAccount().getOid(), oldAccount, getAccount(), this.getUser().getUserId(), this.getUser().getUserName());
		//doLoadAccont(getAccount().getOid());
		
		//商務卡停用啟用
		try {
			setAccount(this.getAccountService().findAccountByOid(_account.getOid()));
			_account = getAccount();
			_account.setStatus(accountStatus);
			
			if(_account.getStatus() == MemberGlossary._mm_account_status_disabled){  //停用商務帳號
				//List<MmCard> list= this.getCardService().findMmCardByAccountIdCardType(getAccount().getAccountId(),new Integer(1));
				//for(MmCard card:list){
				//	card.setStatus(getAccount().getStatus());
				//	card.setDelDate(new Date());
				//	card.setDelReason(getAccount().getReason());
				//}
				//this.getCardService().updateCard(list);
				this.getAccountService().disableAccount(_account);
			} else if (_account.getStatus() == MemberGlossary._mm_account_status_deleted){  //刪除商務帳號
				//List<MmCard> list= this.getCardService().findMmCardByAccountIdCardType(getAccount().getAccountId(),new Integer(1));
				//for(MmCard card:list){
				//	card.setStatus(getAccount().getStatus());
				//	card.setDelDate(new Date());
				//	card.setDelReason(getAccount().getReason());
				//}
				//this.getCardService().updateCard(list);
				this.getAccountService().deleteAccount(_account);
			} else if(_account.getStatus() == MemberGlossary._mm_account_status_approved){   //核發商務帳號
				//this.getCardService().updateCardStatus(getAccount().getAccountId(),null,null);
				this.getAccountService().approveAccount(_account);
			}
			
		} catch(Exception e) {
			this.addActionError(e.getMessage());
		}
		preparePageValue();
		if(_account.getStatus() == MemberGlossary._mm_account_status_approved){
			return EDIT;
		}
		return Action.SUCCESS;
	}
	
	public String doBusinessAccountRestrictionInit(){
		this.getSessionMap().remove(_session_key_account_query);
		return Action.SUCCESS;
	}

	public String doBusinessAccountRestrictionQuery(){
		try {
			if(!this.hasToCountTotal()) {
				AccountCondition p = (AccountCondition)this.getSessionMap().get(_session_key_account_query);
				this.setCondition(p);
			} else {
				this.getSessionMap().put(_session_key_account_query, this.getCondition());
				this.getPageBean().setJumpPage("");
			}
			this.getCondition().setIsRestraint(true) ;
			QueryResult result = accountService.findAccountByCondition(this.getCondition(), this.getQueryStartIndex(),
					this.getPageBean().getPageSize(), this.hasToCountTotal());
			this.setPageBeanByQueryResult(result,"doBusinessAccountRestrictionQuery");
			this.getSessionMap().put(_session_key_account_list, this.getPageBean()) ;
		} catch(Exception e) {
			log.error(e.getMessage(),e) ;
			this.addActionError("查詢失敗("+e.getMessage()+")，請洽系統管理人員!") ;
			return Action.INPUT ;
		}
		return Action.SUCCESS;
	}

	public String editAccountRestriction() {
		try {
			String oid  = this.getRequest().getParameter("oid");
			if(oid!=null){
				this.getSessionMap().put("oid", oid);
			}
			oid = (String)this.getSessionMap().get("oid");

			String expSkuType =  this.getRequest().getParameter("expSkuType");
			if(expSkuType!=null)	log.info("expSkuType : "+expSkuType);


			this.setRefOid(oid);
			log.info("前端條件oid value :"+oid);
			Account temp = this.getAccountService().findAccountByOid(oid,true);
			if(temp != null) {
				//分頁查詢
				Map queryCondition = this.getQueryCondition();
				queryCondition.put("refOid",oid);
				this.setQueryCondition(queryCondition);
				this.setPageBean(this.getMarketingService().findDiscountSkuByCondition(this.getQueryCondition(), this.getPageBean()));
				this.getPageBean().setQueryList(VoUtil.convertSkuVo((List)this.getPageBean().getQueryList()));
				this.getPageBean().setFormAction("editAccountRestriction");//表單action
				this.getPageBean().setToolsMenu(ViewPage.getToolsMenuByDefault(this.getPageBean()));

				List listOfDiscountSku = (List)this.getPageBean().getQueryList();

				//this.setVo(new AccountVo(temp,list)) ;
				this.setVo(new AccountVo(temp,listOfDiscountSku)) ;//暫時
				//儲存查詢結果
				getSessionMap().put("discountSkuCondition" , queryCondition);
				getSessionMap().put("discountSkuPageBean" , this.getPageBean());

			}
			if(temp==null)log.info("=========> temp 是空值");
			else log.info("==============>temp 不是空值");
			if(temp.getHqId() != null && !temp.getHqId().equals("")) {
				AccountHq hq = this.getAccountService().findAccountHqByHqId(temp.getHqId()) ;
				if(hq != null) {
					this.getVo().setHqName(hq.getHqName()) ;
				}
			}
			return Action.SUCCESS ;
		} catch (Exception e) {
			this.addActionError("查詢失敗("+e.getMessage()+")，請洽系統管理人員!") ;
			e.printStackTrace();
			return Action.INPUT ;
		}
	}

	@SuppressWarnings("unchecked")
	public String modifyAccountRestrictionSku() {
		try {
			//重組前端DiscountSku data
			DiscountSkuParamUtil discountSkuParamUtil = new DiscountSkuParamUtil(this.getRequest(),this.getMtService());
			Map map = discountSkuParamUtil.recombinationSkuDetailData();

			Account account = this.getAccountService().findAccountByOid(this.getVo().getOid(),true);
			this.getVo().convert(account, this.getUser().getUserId(), this.getUser().getUserName()) ;

			this.getAccountService().updateAccountAndDiscountSku(
					account,
					 this.getUser().getUserId(),
					 this.getUser().getUserName(),
					refOid,
					(List <DiscountSkuVo>)map.get("addDiscountSkuVoList"),
					(List <DiscountSkuVo>)map.get("updDiscountSkuVoList"),
					(List <DiscountSkuVo>)map.get("delDiscountSkuVoList"));
			//this.getMemberService().doUpdate(account) ;
			//this.getVo().refresh(account) ;



			this.addActionMessage("更新成功") ;
			return Action.SUCCESS ;
		} catch (Exception e) {
			log.error(e.getMessage(),e) ;
			this.addActionError("更新失敗("+e.getMessage()+")，請洽系統管理人員!") ;
			return Action.INPUT ;
		}
	}

	public String exitAccountRestriction() {
		this.setCondition((AccountCondition)this.getSessionMap().get(_session_key_account_query)) ;
		this.setPageBean((PageBean)this.getSessionMap().get(_session_key_account_list)) ;
		this.setVo(null) ;

		return Action.SUCCESS ;
	}

	private void setMmArBankVal() throws Exception {
		MmArBank arBank = new MmArBank();
		setBankIdList(memberService.selectMmArBank(arBank));
		arBank.setBankId(getAccount().getArBkId());
		setBranchIdList(memberService.selectMmArBank(arBank));
		arBank.setBranchId(getAccount().getArBranchId());
		setBankDescList(memberService.selectMmArBank(arBank));
	}
	
	public boolean isShowRate() {
		return false ;
	}

	public boolean isCanModify() {
		return true ;
	}

	public IMarketingService getMarketingService() {
		return (IMarketingService)AppContext.getBean("mtService");
	}

	public boolean isMtGroup() {
		return false;
	}

	/**
	 * 匯入功能
	 * @author JL
	 * @return
	 */
	public String uploadProcess(){
		try {
			String message = mtService.saveMtDiscountSkuProcessUpload
				(getUploadFile(),getOid(),getCurrentUser().getUserId(), getCurrentUser().getUserName(), "insert");
			addActionMessage(getText("SAVE_SUCCESS")+","+message);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			this.addActionError(e.getMessage());
//			return ERROR;
		}
		return SUCCESS;
	}
	
	private void setModifyInfo(Account account, boolean alsoSetCreateInfo) {
		Date modifyTime = new Date();
		if(account.getAccType()!=null&&1==account.getAccType())
			account.setUploadSap(true);
		//Modify Info
		account.setModifier(this.getUser().getUserId());
		account.setModifierName(this.getUser().getUserName());
		account.setModifyTime(modifyTime);
		if(alsoSetCreateInfo) {
			//Creator info
			account.setCreator(this.getUser().getUserId());
			account.setCreatorName(this.getUser().getUserName());
			account.setCreateTime(modifyTime);
		}
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public Map<String, Object> getJsonResult() {
		return jsonResult;
	}
	public void setJsonResult(Map<String, Object> jsonResult) {
		this.jsonResult = jsonResult;
	}
	public String getThresholdId() {
		return thresholdId;
	}
	public void setThresholdId(String thresholdId) {
		this.thresholdId = thresholdId;
	}
	public String getBankId() {
		return bankId;
	}
	public void setBankId(String bankId) {
		this.bankId = bankId;
	}
	public String getBranchId() {
		return branchId;
	}
	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}
	public List<MmAccAttach> getAccAttachList() {
		return accAttachList;
	}
	public void setAccAttachList(List<MmAccAttach> accAttachList) {
		this.accAttachList = accAttachList;
	}
	public MmAccCulmMst getAccCulmMst() {
		return accCulmMst;
	}
	public void setAccCulmMst(MmAccCulmMst accCulmMst) {
		this.accCulmMst = accCulmMst;
	}
	public DiscountSelectItem getSelectItem() {
		return selectItem;
	}
	public void setSelectItem(DiscountSelectItem selectItem) {
		this.selectItem = selectItem;
	}
	public List<MmArBank> getBankIdList() {
		return bankIdList;
	}
	public void setBankIdList(List<MmArBank> bankIdList) {
		this.bankIdList = bankIdList;
	}
	public List<MmArBank> getBranchIdList() {
		return branchIdList;
	}
	public void setBranchIdList(List<MmArBank> branchIdList) {
		this.branchIdList = branchIdList;
	}
	public List<MmArBank> getBankDescList() {
		return bankDescList;
	}
	public void setBankDescList(List<MmArBank> bankDescList) {
		this.bankDescList = bankDescList;
	}
	public MemberAccountRfc getMemberAccountRfc() {
		return memberAccountRfc;
	}
	public void setMemberAccountRfc(MemberAccountRfc memberAccountRfc) {
		this.memberAccountRfc = memberAccountRfc;
	}
}
