package com.gccs.member.action;

import java.util.List;

import com.bnq.util.QueryResult;
import com.gccs.base.action.BaseAction;
import com.gccs.member.card.model.MmCard;
import com.gccs.member.model.*;
import com.gccs.member.service.AccountService;
import com.gccs.member.service.CardService;
import com.gccs.member.service.MemberService;
import com.opensymphony.xwork2.Action;

public class MemberGroupAction extends BaseAction {
	private static final long serialVersionUID = -5868621639761781263L;

	private static String QUERY_KEY = "_session_query_condition";
	private MemberService memberService;
	private List<AccountHq> hqList;
	private List<MmCard> cardList;
	private Account condition;
	private Account account;
	private String[] oidList;
	private Integer updateStatus;
	private CardService cardService;
	private AccountService accountService;


	public AccountService getAccountService() {
		return accountService;
	}
	public void setAccountService(AccountService accountService) {
		this.accountService = accountService;
	}
	public CardService getCardService() {
		return cardService;
	}
	public void setCardService(CardService cardService) {
		this.cardService = cardService;
	}
	public List<MmCard> getCardList() {
		return cardList;
	}
	public void setCardList(List<MmCard> cardList) {
		this.cardList = cardList;
	}
	public MemberService getMemberService() {
		return memberService;
	}
	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}
	public Account getCondition() {
		return condition;
	}
	public void setCondition(Account condition) {
		this.condition = condition;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}
	public List<AccountHq> getHqList() {
		return hqList;
	}
	public void setHqList(List<AccountHq> hqList) {
		this.hqList = hqList;
	}
	public String[] getOidList() {
		return oidList;
	}
	public void setOidList(String[] oidList) {
		this.oidList = oidList;
	}
	public Integer getUpdateStatus() {
		return updateStatus;
	}
	public void setUpdateStatus(Integer updateStatus) {
		this.updateStatus = updateStatus;
	}
	/**********************************************************************************/

	public String doIndex()
	{
		this.getSessionMap().remove(QUERY_KEY);
		try {
			this.hqList = this.getAccountService().findGroupAccountHq();
		} catch(Exception e) {
			this.addActionError("查詢發生失敗: "+e.getMessage());
		}
		return Action.SUCCESS;
	}

	public String doQuery()
	{
		try {
			if(!this.hasToCountTotal()) {
				Account p = (Account)this.getSessionMap().get(QUERY_KEY);
				this.setCondition(p);
			} else {
				this.getSessionMap().put(QUERY_KEY, this.getCondition());
				this.getPageBean().setJumpPage("");
			}

			QueryResult result = this.getAccountService().findMmAccountForGroup(this.getCondition(), this.getQueryStartIndex(),
					this.getPageBean().getPageSize(), this.hasToCountTotal());

			this.setPageBeanByQueryResult(result,"doGroupQuery");
			this.hqList = this.getAccountService().findGroupAccountHq();

		} catch(Exception e) {
			e.printStackTrace();
		}
		return Action.SUCCESS;
	}

	public String doExit()
	{
		try {
			Account p = (Account)this.getSessionMap().get(QUERY_KEY);
			if(p==null){
				return Action.SUCCESS;
			}
			this.setCondition(p);

			QueryResult result = this.getAccountService().findMmAccountForGroup(this.getCondition(), this.getQueryStartIndex(),
					this.getPageBean().getPageSize(), this.hasToCountTotal());
			this.getPageBean().setJumpPage("");
			this.setPageBeanByQueryResult(result,"doGroupQuery");
			this.hqList = this.getAccountService().findGroupAccountHq();

		} catch(Exception e) {
			this.addActionError("載入失敗:"+e.getMessage()+"，請洽系統管理人員.") ;
			e.printStackTrace();
			return ERROR;
		}
		return Action.SUCCESS;
	}

	public String doView() throws Exception
	{
		String oid  = this.getRequest().getParameter("oid");
		this.account = this.getAccountService().findAccountByOid(oid);
		this.cardList = this.getCardService().findGroupCardByAccountId(account.getAccountId());
		return Action.SUCCESS;
	}

	public String doAdd() throws Exception
	{
		String accountId = this.getRequest().getParameter("accountId");
		//this.getCardService().createGroupCard(this.getUser(), accountId);
		this.getCardService().createGroupCard(accountId, this.getUser().getUserId(), this.getUser().getUserName());
		return doView();
	}

	/**
	 * 依卡號清單啟用或停用卡片
	 * @return
	 * @throws Exception
	 */
	public String doUpdateStatus() throws Exception {
		//this.getCardService().updateCardStatus(this.oidList, this.updateStatus);
		if(oidList != null && oidList.length > 0) {
			for(String cardOid: oidList) {
				if(updateStatus==1)
					this.getCardService().enableMmCardByCardOid(cardOid, getUser().getUserId(), getUser().getUserName());
				else
					this.getCardService().disableMmCardByCardOid(cardOid, "停用卡片", getUser().getUserId(), getUser().getUserName());
			}
		}
		
		return doView();
	}
}
