package com.gccs.member.action;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.PageBean;
import com.bnq.util.QueryResult;
import com.gccs.base.action.BaseAction;
import com.gccs.member.model.vo.MemberQueryVo;
import com.gccs.member.service.MemberService;
import com.opensymphony.xwork2.Action;

@SuppressWarnings("unchecked")
public class MemberChangeAction extends BaseAction {
	private static final long serialVersionUID = -2596598282962494152L;
	private static final Logger log = LogManager.getLogger(MemberChangeAction.class) ;
	
	private static String _query_key = "_session_query_condition";
	private static String _sub_query_key = "_session_sub_query_condition";
	private static String _query_PageBean = "_session_query_PageBean";

	private MemberService memberService;
	private MemberQueryVo condition;
	private MemberQueryVo subCondition;
	private String fileName;
	private InputStream inputStream;
	
	public MemberService getMemberService() {
		return memberService;
	}

	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}

	public MemberQueryVo getCondition() {
		return condition;
	}

	public void setCondition(MemberQueryVo condition) {
		this.condition = condition;
	}

	public MemberQueryVo getSubCondition() {
		return subCondition;
	}

	public void setSubCondition(MemberQueryVo subCondition) {
		this.subCondition = subCondition;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public InputStream getInputStream() {
		return inputStream;
	}

	public void setInputStream(InputStream inputStream) {
		this.inputStream = inputStream;
	}

	/*************************************************************************************/

	public String viewQuery() {
		this.getSessionMap().remove(_query_key);
		this.getSessionMap().remove(_sub_query_key);
		this.getSessionMap().remove(_query_PageBean);
		return Action.SUCCESS;
	}

	public String doQuery() {
		try {
			if (!this.hasToCountTotal()) {
				this.condition = (MemberQueryVo) this.getSessionMap().get(
						_query_key);
			} else {
				this.getSessionMap().put(_query_key, this.condition);
				this.getPageBean().setJumpPage("");
			}

			QueryResult result = memberService.findMembersFromModifyRecord(
					condition, getQueryStartIndex(), getPageBean()
							.getPageSize(), hasToCountTotal());
			this.setPageBeanByQueryResult(result, "doQueryForm");

			this.getSessionMap().put(_query_PageBean, this.getPageBean());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return Action.SUCCESS;
	}

	public String doSubQuery() {
		try {
			if (!this.hasToCountTotal()) {
				this.subCondition = (MemberQueryVo) this.getSessionMap().get(_sub_query_key);
			} else {
				MemberQueryVo condition = (MemberQueryVo) this.getSessionMap().get(_query_key);
				this.subCondition.setModifierName(condition.getModifierName());
				this.subCondition.setDateFrom(condition.getDateFrom());
				this.subCondition.setDateTo(condition.getDateTo());

				this.getSessionMap().put(_sub_query_key, this.subCondition);
				
				this.getPageBean().setJumpPage("");
			}
			
			QueryResult result = memberService.findModifyRecord(
					subCondition,
					getQueryStartIndex(), 
					getPageBean().getPageSize(),
					hasToCountTotal());
			
			this.setPageBeanByQueryResult(result, "doQueryForm");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return Action.SUCCESS;
	}

	public String doExit() {
		try {
			this.getSessionMap().remove(_sub_query_key);

			if (this.getSessionMap().get(_query_key) != null) {
				this.setCondition((MemberQueryVo) this.getSessionMap().get(
						_query_key));
				this.setPageBean((PageBean) this.getSessionMap().get(
						_query_PageBean));

				QueryResult result = memberService.findMembersFromModifyRecord(
						condition, getQueryStartIndex(), getPageBean()
								.getPageSize(), hasToCountTotal());
				this.setPageBeanByQueryResult(result, "doQueryForm");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return Action.SUCCESS;
	}

	public static String getTdHtml(String s1, String s2, boolean isShowFirst) {
		String _s1 = notNull(s1);
		String _s2 = notNull(s2);

		if (_s1.equals(_s2)) {
			if (isShowFirst) {
				return "<td class='row3' rowspan='2'> </td>";
			} else {
				return "";
			}
		} else {
			if (isShowFirst) {
				return "<td class='row3' NOWRAP>" + _s1 + "</td>";
			} else {
				return "<td class='row3' NOWRAP>" + _s2 + "</td>";
			}
		}
	}

	private static String notNull(String str) {
		if (str == null || str.trim().length() <= 0 || str.equals("null")) {
			return "";
		} else {
			return str;
		}
	}
	
	public String downloadExcelReport(){
		try{
			MemberQueryVo map = (MemberQueryVo)this.getSessionMap().get(_sub_query_key);
			System.out.println("map = " + map.toString());
			ByteArrayOutputStream bos = memberService.queryModifyRecord(map, 0, 0, false);
			
			this.fileName = new String("會員異動清單.xls".getBytes("Big5"), "ISO8859_1");
			this.inputStream = new ByteArrayInputStream(bos.toByteArray());
		} catch(Exception e){
			e.printStackTrace();
			log.error(e.getMessage());
			addActionError("產出檔案失敗<br>" + e.getMessage());
			return ERROR;
		}

		return SUCCESS;
	}
}
