package com.gccs.member.action;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.PageBean;
import com.bnq.util.QueryResult;
import com.gccs.base.action.BaseAction;
import com.gccs.member.model.MmCommission;
import com.gccs.member.model.condition.MemberCondition;
import com.gccs.member.service.CardService;
import com.gccs.member.service.MemberService;
import com.gccs.util.cache.BsCompanyDefinition;
import com.gccs.ws.service.BaseWebService;
import com.opensymphony.xwork2.Action;

public class CommissionSettingAction extends BaseAction {
	private static final long serialVersionUID = -6717178994269628380L;

	private static final Logger log = LogManager.getLogger(CommissionSettingAction.class);
	private static final String _session_PageBean = "_session_PageBean";
	private static final String _session_Query = "_session_Query";

	private String _actionName;
	private Integer actType; //1:退佣;2:獎勵
	private MemberService memberService;
	private MemberCondition condition;
	private MmCommission vo;
	private String[] cardDiscTableRecord;
	private List cardDiscList;
	private Integer totalCount;
	private CardService cardService;
	private Map<String, Object> jsonResult;
	private String oldActivityId;

	/****************************************************************************************/


	public CardService getCardService() {
		return cardService;
	}
	public void setCardService(CardService cardService) {
		this.cardService = cardService;
	}
	public String get_action(String methodName) {
		return this._actionName + "!" + methodName;
	}
	public String get_action_query() {
		return this.get_action("query");
	}
	public String get_action_exit() {
		return this.get_action("exit");
	}
	public String get_action_edit() {
		return this.get_action("edit");
	}
	public String get_action_save() {
		return this.get_action("save");
	}
	public String get_action_cardDiscTable() {
		return this.get_action("cardDiscTable");
	}

	/****************************************************************************************/

	public String view() {
		this.getSessionMap().remove(_session_PageBean);
		this.getSessionMap().remove(_session_Query);

		return Action.SUCCESS;
	}

	public String query() {
		try {
			if(!this.hasToCountTotal()) {
				this.condition = (MemberCondition)this.getSessionMap().get(_session_Query);
			} else {
				this.getSessionMap().put(_session_Query, this.condition);
				this.getPageBean().setJumpPage("");
			}
			this.condition.setCompanyId(BsCompanyDefinition.getCompanyId());
			QueryResult result = memberService.findMmCommission(this.condition, getQueryStartIndex(), getPageBean().getPageSize(), hasToCountTotal());
			this.setPageBeanByQueryResult(result, this.get_action_query());

			this.getSessionMap().put(_session_PageBean, this.getPageBean());
		} catch(Exception e) {
			e.printStackTrace();
		}

		return Action.SUCCESS;
	}

	public String exit() {
		try {
			if(this.getSessionMap().get(_session_Query) != null)
			{
				this.setCondition((MemberCondition)this.getSessionMap().get(_session_Query));
				this.setPageBean((PageBean)this.getSessionMap().get(_session_PageBean));

				QueryResult result = memberService.findMmCommission(this.condition, getQueryStartIndex(), getPageBean().getPageSize(), true);
				this.setPageBeanByQueryResult(result, this.get_action_query());
			}
		} catch(Exception e) {
			e.printStackTrace();
		}

		return Action.SUCCESS;
	}

	public String edit() {
		if(!isNew()) {
			this.vo = this.memberService.deployLoadMmCommission(this.vo.getOid());
			this.totalCount = (Integer)this.getCardService().findMmCardDiscByActivityOid(this.vo.getOid(), 0, 0, true);
		} else {
			this.vo = new MmCommission();
			this.vo.setActivityId("系統給號");
			this.vo.setStatus(0);
		}

		if(new Integer(2).equals(this.vo.getStatus())) {
			return "view";
		} else {
			return Action.INPUT;
		}
	}

	public String save() {
		if(isNew()) {
			this.vo.setCreator(this.getUser().getUserId());
			this.vo.setCreatorName(this.getUser().getUserName());
			this.vo.setCreateTime(new Date());
		}

		this.vo.setModifier(this.getUser().getUserId());
		this.vo.setModifierName(this.getUser().getUserName());
		this.vo.setModifyTime(new Date());
		this.vo.setCompanyId(BsCompanyDefinition.getCompanyId());
		this.memberService.deeplySaveOrUpdateMmCommission(this.vo,this.cardDiscTableRecord, oldActivityId);

		return this.edit();
	}

	public String cardDiscTable() {
		String activityOid = this.getRequest().getParameter("activityOid");
		int index = Integer.valueOf((String)this.getRequest().getParameter("index"));
		int pageSize = Integer.valueOf((String)this.getRequest().getParameter("pageSize"));
		this.cardDiscList = (List)this.getCardService().findMmCardDiscByActivityOid(activityOid, index, pageSize, false);
		return "cardDiscTable";
	}

	public String openWin() {
		this.getRequest().setAttribute("isWin", true);
		this.vo = this.memberService.deployLoadMmCommission(this.vo.getOid());
		this.totalCount = (Integer)this.getCardService().findMmCardDiscByActivityOid(this.vo.getOid(), 0, 0, true);

		return "view";
	}

	public boolean isNew() {
		if(BaseWebService.isEmpty(this.vo) || BaseWebService.isEmpty(this.vo.getOid())) {
			return true;
		} else {
			return false;
		}
	}

	public String checkCommissionActive() {
		jsonResult = new HashMap<>();
		
		MmCommission mmCommission = new MmCommission();
		mmCommission.setCompanyId(BsCompanyDefinition.getCompanyId());
		mmCommission.setActType(1);
		mmCommission.setStatus(1);
		List<MmCommission> result = memberService.findMmCommission(mmCommission, false);
		
		jsonResult.put("result", result);
		return Action.SUCCESS;
	}

	public static String getStatusTxt(Integer status) {
		if(status==null || status==1){
			return "申請中";
		}else if(status==2){
			return "審核中";
		}else if(status==3){
			return "核發";
		}else if(status==9){
			return "刪除";
		}else if(status==4){
			return "限制採購";
		}else if(status==0){
			return "停用";
		}
		return "";
	}

	public static String handleBreak(String str) {
		return str.replaceAll("\r\n", "<br>");
	}

	/****************************************************************************************/

	public String get_actionName() {
		return _actionName;
	}
	public void set_actionName(String name) {
		_actionName = name;
	}
	public Integer getActType() {
		return actType;
	}
	public void setActType(Integer actType) {
		this.actType = actType;
	}
	public MemberService getMemberService() {
		return memberService;
	}
	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}
	public MemberCondition getCondition() {
		return condition;
	}
	public void setCondition(MemberCondition condition) {
		this.condition = condition;
	}
	public MmCommission getVo() {
		return vo;
	}
	public void setVo(MmCommission vo) {
		this.vo = vo;
	}
	public List getCardDiscList() {
		return cardDiscList;
	}
	public void setCardDiscList(List cardDiscList) {
		this.cardDiscList = cardDiscList;
	}
	public Integer getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}
	public String[] getCardDiscTableRecord() {
		return cardDiscTableRecord;
	}
	public void setCardDiscTableRecord(String[] cardDiscTableRecord) {
		this.cardDiscTableRecord = cardDiscTableRecord;
	}
	public Map<String, Object> getJsonResult() {
		return jsonResult;
	}
	public void setJsonResult(Map<String, Object> jsonResult) {
		this.jsonResult = jsonResult;
	}
	public String getOldActivityId() {
		return oldActivityId;
	}
	public void setOldActivityId(String oldActivityId) {
		this.oldActivityId = oldActivityId;
	}
}
