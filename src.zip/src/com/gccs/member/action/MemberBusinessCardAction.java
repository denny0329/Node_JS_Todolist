package com.gccs.member.action;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.PageBean;
import com.bnq.util.QueryResult;
import com.bnq.util.StringId;
import com.gccs.bs.model.BsChannel;
import com.gccs.member.card.model.MmCard;
import com.gccs.member.model.Account;
import com.gccs.member.model.AccountHq;
import com.gccs.member.model.MarketNotice;
import com.gccs.member.model.MarketNoticeVo;
import com.gccs.member.model.Members;
import com.gccs.member.model.MmAccPhoneRec;
import com.gccs.member.model.condition.MemberCondition;
import com.gccs.member.rfc.MemberCardRfc;
import com.gccs.util.cache.BsChannelDefinition;
import com.gccs.util.cache.BsCompanyDefinition;
import com.opensymphony.xwork2.Action;

public class MemberBusinessCardAction extends MemberBaseAction {
	private static final long serialVersionUID = -932224666330290936L;

	private static final Logger log = LogManager.getLogger(MemberBusinessCardAction.class) ;
	/**
	 * 判斷是否為唯讀
	 * @param status
	 * @return boolean
	 */
	
	private String accountId;
	private Map<String, Object> jsonResult;
	private MmAccPhoneRec mmAccPhoneRec;
	private MemberCardRfc memberCardRfc;
	
	private boolean isReadOnly(int status){
		if(status == 0 || status == 9)return true;
		else return false;
	}

	protected void doLoadMember(String oid)throws Exception{
		log.info("重新查詢Member => doLoadMember()");
		super.setMembers(this.getMemberService().findMemberByOid(oid));
			Account account = this.getAccountService().findAccountByAccountId(super.getMembers().getAccountId());
			if(account!=null){
				AccountHq accountHq = this.getAccountService().findAccountHqByHqId(account.getHqId());
				super.getMembers().setCompanyName1(account.getCompanyName1());
				if(accountHq!=null){
					super.getMembers().setHqId(accountHq.getHqId());
					super.getMembers().setHqName(accountHq.getHqName());
				}
			}

		super.setMarketNoticeVoList(new ArrayList());
		super.setChannelList(BsChannelDefinition.findAllChannelIncludeHQ3());
		for(BsChannel channel:super.getChannelList()){
			if(!channel.getCompanyId().equals(this.getUser().getCompanyId()))
				continue;
			if(channel.getStatus()){
				MarketNoticeVo marketNoticeVo = new MarketNoticeVo();
				marketNoticeVo.setChannelId(channel.getChannelId());
				marketNoticeVo.setChannelName1(channel.getChannelName1());
				marketNoticeVo.setConfirm("1");
				marketNoticeVo.setChannel(new String[]{"0","1","2","3"});
				marketNoticeVo.setChannelOid(channel.getOid());
				super.getMarketNoticeVoList().add(marketNoticeVo);
			}

		}


		//通路
		Set marketNoticeList = super.getMembers().getMarketNotice();
		if(marketNoticeList == null)log.info("marketNoticeList is Null");
		else log.info("marketNoticeList is not Null");
		Iterator it = marketNoticeList.iterator();
		while(it.hasNext()){
			MarketNotice marketNotice = (MarketNotice) it.next();
			for(MarketNoticeVo marketNoticeVo:super.getMarketNoticeVoList()){
				if(marketNotice.getChannelOid().equals(marketNoticeVo.getChannelOid())){
					marketNoticeVo.setChannel(new String[]{"","","",""});
					marketNoticeVo.setConfirm(marketNotice.getRecFlag().toString());
					if(marketNotice.getRecFlag() > 0){
						String[] temp=  marketNoticeVo.getChannel();
						if(marketNotice.getDmFlag()){
							temp[0]="0";

						}
						if(marketNotice.getEdmFlag()){
							temp[1]="1";

						}
						if(marketNotice.getTelFlag()){
							temp[2]="2";

						}
						if(marketNotice.getMmsFlag()){
							temp[3]="3";

						}

						marketNoticeVo.setChannel(temp);

					}
					marketNoticeVo.setMarketNotice(marketNotice);
				}
			}
		}
		
		super.setMembers(this.getMemberService().getMembersMarketData(super.getMembers()));
	}
	
	protected void doLoadMember2(String oid)throws Exception{
		log.info("重新查詢Member => doLoadMember2()");
		super.setMembers(this.getMemberService().findMemberByOid(oid));
		Account account = this.getAccountService().findAccountByAccountId(super.getMembers().getAccountId());
		if(account!=null){
			AccountHq accountHq = this.getAccountService().findAccountHqByHqId(account.getHqId());
			super.getMembers().setCompanyName1(account.getCompanyName1());
			if (StringUtils.isBlank(super.getMembers().getOthName())) {
				super.getMembers().setOthName(account.getComContact());
			}
			if (StringUtils.isBlank(super.getMembers().getOthCellPhone())) {
				super.getMembers().setOthCellPhone(account.getComFax());
			}
			if (StringUtils.isBlank(super.getMembers().getOthEmail())) {
				super.getMembers().setOthEmail(account.getComEmail());
			}
			if (StringUtils.isBlank(super.getMembers().getOthNameDept())) {
				super.getMembers().setOthNameDept(account.getComConDept());
			}
			if(accountHq!=null){
				super.getMembers().setHqId(accountHq.getHqId());
				super.getMembers().setHqName(accountHq.getHqName());
			}
		}
		
		super.setMarketNoticeVoList(new ArrayList());
		super.setChannelList(BsChannelDefinition.findAllChannelIncludeHQ3());
		for(BsChannel channel:super.getChannelList()){
			if(!channel.getCompanyId().equals(this.getUser().getCompanyId()))
				continue;
			if(channel.getStatus()){
				MarketNoticeVo marketNoticeVo = new MarketNoticeVo();
				marketNoticeVo.setChannelId(channel.getChannelId());
				marketNoticeVo.setChannelName1(channel.getChannelName1());
				marketNoticeVo.setConfirm("1");
				marketNoticeVo.setChannel(new String[]{"0","1","2","3"});
				marketNoticeVo.setChannelOid(channel.getOid());
				super.getMarketNoticeVoList().add(marketNoticeVo);
			}
			
		}
		
		
		//通路
		Set marketNoticeList = super.getMembers().getMarketNotice();
		if(marketNoticeList == null)log.info("marketNoticeList is Null");
		else log.info("marketNoticeList is not Null");
		Iterator it = marketNoticeList.iterator();
		while(it.hasNext()){
			MarketNotice marketNotice = (MarketNotice) it.next();
			for(MarketNoticeVo marketNoticeVo:super.getMarketNoticeVoList()){
				if(marketNotice.getChannelOid().equals(marketNoticeVo.getChannelOid())){
					marketNoticeVo.setChannel(new String[]{"","","",""});
					marketNoticeVo.setConfirm(marketNotice.getRecFlag().toString());
					if(marketNotice.getRecFlag() > 0){
						String[] temp=  marketNoticeVo.getChannel();
						if(marketNotice.getDmFlag()){
							temp[0]="0";
							
						}
						if(marketNotice.getEdmFlag()){
							temp[1]="1";
							
						}
						if(marketNotice.getTelFlag()){
							temp[2]="2";
							
						}
						if(marketNotice.getMmsFlag()){
							temp[3]="3";
							
						}
						
						marketNoticeVo.setChannel(temp);
						
					}
					marketNoticeVo.setMarketNotice(marketNotice);
				}
			}
		}
		
		super.setMembers(this.getMemberService().getMembersMarketData(super.getMembers()));
		
	}

	public String doQuery(){
		try {
			if(!this.hasToCountTotal()) {
				MemberCondition p = (MemberCondition)this.getSessionMap().get(MEMBER_CONDITION);
				this.setCondition(p);
			} else {
				this.getSessionMap().put(MEMBER_CONDITION, this.getCondition());
				this.getPageBean().setJumpPage("");
			}
			this.getCondition().setBusinessCard(true);
			this.getCondition().setCompanyId(BsCompanyDefinition.getCompanyId());
			QueryResult result = memberService.findMemberGeneralByCondition(this.getCondition(), this.getQueryStartIndex(),
					this.getPageBean().getPageSize(), this.hasToCountTotal(),false);

			this.setPageBeanByQueryResult(result,"doQuery");
			this.getSessionMap().put(MEMBER_PAGEBEAN, this.getPageBean());
			auditSuccessLog();
		} catch(Exception e) {
			e.printStackTrace();
			auditFailLog();
		}

		return Action.SUCCESS;
	}
	
	public String checkBusinessCardStatus() throws Exception {
		try {
			String str = "";

			int count = getCardService().checkBusinessCardStatus(accountId);
			if (count > 0) {
				str = "確認啟用會員卡?";
			} else {
				str = "沒有會員卡需啟用 !";
			}
			log.info("啟用商務會員卡: 查詢結果: " + count);
			
			jsonResult = new HashMap<>();
			jsonResult.put("result", new StringId(String.valueOf(count), str));
		} catch (Exception e) {
			this.addActionError("載入失敗:"+e.getMessage()+"，請洽系統管理人員.") ;
			log.error(e.getMessage(), e);
			return Action.ERROR;
		}
		return Action.SUCCESS;
	}

	public String dochangeStstusToOpen()throws Exception{
		log.info("MemberBusinessCardAction.dochangeStstusToOpen()");
		doLoadMember2(super.getMembers().getOid());
		getCardService().enableMmCardByMemberOid(super.getMembers(),this.getUser().getUserId(),this.getUser().getUserName());
		return Action.SUCCESS;
	}

	public String doEdit() throws Exception{
		log.info("MemberBusinessCardAction.dochangeStstusToOpen()");
		String oid  = this.getRequest().getParameter("oid");
		String isQueryFlag  = this.getRequest().getParameter("fromQuery");
		if (StringUtils.isBlank(oid) && StringUtils.isBlank(isQueryFlag)) {
			oid = this.getMembers().getOid();
		}
		if(oid!=null) {
			doLoadMember2(oid);
			auditSuccessLog();

			if (!"Y".equals(isQueryFlag)) {
				sendAuth();
			}
			setAccPhoneRecVal();
		}
		if(isReadOnly(super.getMembers().getStatus()))return READONLY;
		return Action.SUCCESS;
	}

	private void setAccPhoneRecVal() {
		setMmAccPhoneRec(getMemberService().selectMmAccPhoneRec(super.getMembers().getMemberId()));
	}

	public String doExit(){
		try {
			MemberCondition p = (MemberCondition)this.getSessionMap().get(MEMBER_CONDITION);
			if(p==null)return Action.SUCCESS;
			this.setCondition(p);
			this.getCondition().setBusinessCard(true);
			PageBean pageBean = (PageBean)this.getSessionMap().get(MEMBER_PAGEBEAN);
			this.setPageBean(pageBean);
		} catch(Exception e) {
			this.addActionError("載入失敗:"+e.getMessage()+"，請洽系統管理人員.") ;
			e.printStackTrace();
			return ERROR;
		}
		return Action.SUCCESS;
	}
    
	public String doSave() throws Exception {
		if (super.getMembers().getBirthdayYy() == null && super.getMembers().getBirthdayMm() == null &&
				super.getMembers().getBirthdayDd() == null) {
			super.getMembers().setBirthdayYy(Integer.valueOf(1921));
			super.getMembers().setBirthdayMm(Integer.valueOf(8));
			super.getMembers().setBirthdayDd(Integer.valueOf(8));
		}
		
		try{
			if(StringUtils.isBlank(getMembers().getOid())) { // 新增，商務會員不存在

				setMarketNotice(this.getMembers().getMemberId(),this.getMembers().getOid());

				this.getMemberService().createMember(getMembers(), getUser().getUserId(), getUser().getUserName());

				if(this.getCard()!=null){
					getCard().setMemberOid(this.getMembers().getOid());
					getCard().setMemberId(this.getMembers().getMemberId());
					getCard().setAccountId(this.getMembers().getAccountId());
					getCard().setName(this.getMembers().getName());
					getCard().setCompanyId(BsCompanyDefinition.getCompanyId());

					this.getCardService().createCard(getCard(), this.getUser().getUserId(), this.getUser().getUserName());
					// 新增好mmcard，將它塞回到members裡
					Set<MmCard> set = new HashSet<MmCard>();
					set.add(getCard());
					this.getMembers().setMmCard(set);
					if("Y".equals(getCard().getDoPrint())){
						this.getRequest().setAttribute(doCreateCardVipNoList, getCard().getVipNo());
					}
				}
			}else{ // 修改 
				setMarketNotice(this.getMembers().getMemberId(),this.getMembers().getOid());
				this.getMemberService().updateMember(this.getMembers(), this.getUser().getUserId(), this.getUser().getUserName());
			}
			
			// 根據商務帳號的是否上傳sap欄位(UploadSap)來決定是否要執行上傳sap
			Account account = getAccountService().findAccountByAccountId(this.getMembers().getAccountId());
			if(account.getUploadSap() != null && account.getUploadSap()){
				sendCardSap();
			}
			
			sendAuth();
			
			doLoadMember2(this.getMembers().getOid());
			setAccPhoneRecVal();
		} catch(Exception e) {
			log.error(e.getMessage(),e) ;
//			if(checkPersonId()) {
//				super.getMembers().setBirthdayYy(super.getMembers().getBirthdayYy()-Integer.valueOf(1911));
//				return Action.INPUT;
//			}
			this.addActionError("更新失敗，請洽系統管理人！");
			initVal();
			return Action.INPUT;
		}
		
		addActionMessage(getText("SAVE_SUCCESS"));
		return Action.SUCCESS;
	}

	private void initVal() {
		super.getMembers().setCreator(this.getUser().getUserId());
		super.getMembers().setCreatorName(this.getUser().getUserName());
		super.getMembers().setCreateTime(new Date());
		super.getMembers().setModifier(this.getUser().getUserId());
		super.getMembers().setModifierName(this.getUser().getUserName());
		super.getMembers().setModifyTime(new Date());
	}

	private void sendCardSap() {
		List<MmCard> cards = new ArrayList<>();
		Set<MmCard> set = this.getMembers().getMmCard();
		Iterator<MmCard> itor = set.iterator();
		while(itor.hasNext()){
			MmCard mmCard = itor.next();
			if(mmCard.getCardType() == 1){
				mmCard.setName(this.getMembers().getName());
				cards.add(mmCard);
			}
		}
		if(cards != null){
			memberCardRfc.execute(this.getMembers().getAccountId(),cards );
		}
	}

	private void sendAuth() throws Exception {
		Integer ecYn = super.getMembers().getEcYn();
		log.info("商務會員卡授權認證memId:" + super.getMembers().getMemberId() + ",ecYn:" + ecYn);
		if (null != ecYn) {
			if (1 == ecYn) {
				log.info("商務會員卡授權認證開始");
				String result = getMemberService().businessAuth(super.getMembers().getMemberId());
				log.info("商務會員卡授權認證結果: " + result);
				
			}
		}
	}

	public String doUpdateStatusToDelete() throws Exception{
		log.info("=============>MemberBusinessCardAction.doUpdateStatusToDelete()");
		//super.getCardService().changeCardStatus(getMembers().getOid(),"9",getMembers().getResulm(),this.getUser());
		getCardService().deleteMmCardByMemberOid(getMembers().getOid(), getMembers().getResulm(), this.getUser().getUserId(), this.getUser().getUserName());
		sendAuth();
		
		doLoadMember2(getMembers().getOid());
		setAccPhoneRecVal();
		return Action.SUCCESS;
	}
	public String doUpdateStatusToStop() throws Exception{
		log.info("=============>MemberBusinessCardAction.doUpdateStatusToStop()");
		//doLoadMember(getMembers().getOid());
		//super.getCardService().changeCardStatus(getMembers().getOid(),"0",getMembers().getResulm(),this.getUser());
		getCardService().disableMmCardByMemberOid(getMembers().getOid(), getMembers().getResulm(), this.getUser().getUserId(), this.getUser().getUserName());
		sendAuth();
		
		doLoadMember2(this.getMembers().getOid());
		setAccPhoneRecVal();
		return Action.SUCCESS;
	}

	public String sendBusinessAuth() {
		try {
			// 更新會員資料
			setMarketNotice(this.getMembers().getMemberId(),this.getMembers().getOid());
			this.getMemberService().updateMember(this.getMembers(), this.getUser().getUserId(), this.getUser().getUserName());

			// 認證手機號碼 
			sendAuth();
			
			// 新增mm_acc_phone_rec資料
			MmAccPhoneRec accPhone = accPhoneRecValue(getMembers());
			getMemberService().insertMmAccPhoneRec(accPhone);
			
			doLoadMember2(this.getMembers().getOid());
			setAccPhoneRecVal();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return Action.SUCCESS;
	}

	private MmAccPhoneRec accPhoneRecValue(Members members) {
		MmAccPhoneRec accPhone = new MmAccPhoneRec();
		Date date = new Date();
		accPhone.setCompanyId(this.getUser().getCompanyId());
		accPhone.setMemberId(new BigDecimal(members.getMemberId()));
		accPhone.setAccountId(members.getAccountId());
		accPhone.setAccPhoneRec(members.getCellPhone());
		accPhone.setCreateTime(date);
		accPhone.setCreator(this.getUser().getUserId());
		accPhone.setSendTime(date);
		accPhone.setEcStatus("YY");
		return accPhone;
	}
	
	public String makeBusinessMemStart() {
		try {
			Members member = super.getMembers();
			setModifyVal(member);
			// 更新會員和卡status
			getMemberService().updateMemAndCardStatus(member);
			
			doLoadMember2(member.getOid());
			setAccPhoneRecVal();
			
			sendCardSap();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return Action.SUCCESS;
	}

	private void setModifyVal(Members member) {
		String modifier = StringUtils.isBlank(member.getModifier()) == true ? this.getUser().getUserId() : member.getModifier();
		String modifierName = StringUtils.isBlank(member.getModifierName()) == true ? this.getUser().getUserName() : member.getModifierName();
		member.setModifier(modifier);
		member.setModifierName(modifierName);
	}
	
	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public Map<String, Object> getJsonResult() {
		return jsonResult;
	}

	public void setJsonResult(Map<String, Object> jsonResult) {
		this.jsonResult = jsonResult;
	}

	public MmAccPhoneRec getMmAccPhoneRec() {
		return mmAccPhoneRec;
	}

	public void setMmAccPhoneRec(MmAccPhoneRec mmAccPhoneRec) {
		this.mmAccPhoneRec = mmAccPhoneRec;
	}

	public MemberCardRfc getMemberCardRfc() {
		return memberCardRfc;
	}

	public void setMemberCardRfc(MemberCardRfc memberCardRfc) {
		this.memberCardRfc = memberCardRfc;
	}

}
