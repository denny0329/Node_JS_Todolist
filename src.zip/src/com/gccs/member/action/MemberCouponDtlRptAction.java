package com.gccs.member.action;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import jxl.Workbook;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.gccs.base.action.BaseAction;
import com.gccs.member.model.MembersCouponDetail;
import com.gccs.member.service.MemberCouponDetailReportService;
import com.gccs.report.jxlexcel.CouponJxlActionImpl;
import com.rfep.base.JxlExcelBean;
import com.rfep.base.JxlExcelUtils;

public class MemberCouponDtlRptAction extends BaseAction {

	private static final long serialVersionUID = -3095770176249298298L;
	private Logger log = Logger.getLogger(MemberCouponDtlRptAction.class);
	// 固定常用session key值
	private static final String QUERY_CONDITION = "queryCondition";
	
	private MemberCouponDetailReportService memberCouponDetailReportService;

	/**
	 * 程式初始化動作
	 * 
	 * @return Struts導頁Result設定
	 */
	public String doEntry() {
		getSessionMap().remove(QUERY_CONDITION);

		return SUCCESS;
	}

	/**
	 * 執行報表
	 * 
	 * @return
	 */	
	public String doReport() {
		
		// 1620 >>> File Encoding set in com/rfep/base -> JxlExcelUtils.java -> processContentDisposition
		String jxlExcelFileName = "折價券發放明細表";
		ByteArrayOutputStream output = new ByteArrayOutputStream();
		//用於存放JxlExcel的物件
		Map mapJxlExcel=new HashMap();
		try {
			HttpServletResponse response = ServletActionContext.getResponse();
			//取得工作簿並存在map內
			mapJxlExcel.put("WritableWorkbook-wb", Workbook.createWorkbook(output));
			JxlExcelBean jxlExcelBean= new JxlExcelBean(jxlExcelFileName);
			jxlExcelBean.setResponse(response);
			
			Map queryCondition = getQueryCondition();
			List<MembersCouponDetail> result = memberCouponDetailReportService.getCouponDetailReport(queryCondition);
			
			CouponJxlActionImpl couponJxlActionImpl = new CouponJxlActionImpl();
			couponJxlActionImpl.getData1620(result, mapJxlExcel);

			if((WritableSheet)mapJxlExcel.get("WritableSheet-sheet1")!=null){
				((WritableWorkbook)mapJxlExcel.get("WritableWorkbook-wb")).write();
				((WritableWorkbook)mapJxlExcel.get("WritableWorkbook-wb")).close();
				JxlExcelUtils jxl = new JxlExcelUtils();
				jxl.genEXCELtoWeb(jxlExcelBean,output.toByteArray());
			}else{
				addActionError(getText("execule.fail")+"：Excel產生其失敗原因：sheet為null<br>");
				return ERROR;
			}
			

		} catch (Throwable e) {
			e.printStackTrace();
			log.error(e);
			addActionError(getText("execule.fail")+"："+e.getMessage());
			return ERROR;

		}
		return NONE;
	}


	public void setMemberCouponDetailReportService(
			MemberCouponDetailReportService memberCouponDetailReportService) {
		this.memberCouponDetailReportService = memberCouponDetailReportService;
	}

	public MemberCouponDetailReportService getMemberCouponDetailReportService() {
		return memberCouponDetailReportService;
	}
}
