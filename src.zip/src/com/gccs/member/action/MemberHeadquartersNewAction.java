package com.gccs.member.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.bnq.util.FileTools;
import com.bnq.util.QueryResult;
import com.gccs.bc.model.BcBonusLog;
import com.gccs.member.card.model.MmCard;
import com.gccs.member.model.Members;
import com.gccs.member.model.condition.MemberCondition;
import com.gccs.mmbonus.model.MmMembersBonus;
import com.gccs.util.cache.BsCompanyDefinition;
import com.gccs.util.log.model.ModifyRecord;
import com.opensymphony.xwork2.Action;

public class MemberHeadquartersNewAction extends MemberBaseNewAction {
	private static final long serialVersionUID = -4566619179059232929L;

	/**
	 * 判斷是否為唯讀
	 * @param status
	 * @return boolean
	 */
	private boolean isReadOnly(int status){
		if(status == 0 || status == 9)return true;
		else return false;
	}
	
	public String showDialogNew(){
		return SUCCESS;
	}
	
	public String showConfirmNew(){
		return SUCCESS;
	}
	
	/**
	 * 會員/卡片資料維護(總公司)-修改
	 */
	public String doEdit() throws Exception{
		String oid  = this.getRequest().getParameter("oid");
		if(oid!=null) {
			super.doLoadMember(oid);
			auditSuccessLog();
			Members mm = super.getMembers();
			if("ER".equals(mm.getResId1())&&"008".equals(mm.getResId2())){
				super.setErCard("Y");
				super.setEroption("2");
			}
		}else{
			Members mm = super.getMembers();
			String noid = this.getMemberService().queryMemberOidByPersoId(mm.getPersonId());
			ModifyRecord mr = new ModifyRecord();
			final String word = "<Members><LoadReason>%s</LoadReason></Members>";
			mr.setObjectName("Members");
			mr.setPreviousVersion(FileTools.createClob(String.format(word, "")));
			mr.setNewVersion(FileTools.createClob(String.format(word, (BsCompanyDefinition.getBsCompanyById(BsCompanyDefinition.getCompanyId()).getCompanyName()+"新增"))));
			mr.setCreateTime(new Date());
			mr.setCreator(getUser().getUserId());
			mr.setCreatorName(getUser().getUserName());
			
			if("ER".equals(mm.getResId1())&&"008".equals(mm.getResId2())){
				super.setErCard("Y");
				if(StringUtils.isNotEmpty(noid)){
					doLoadMember(noid);
					auditSuccessLog();
					super.setEroption("1");
				}
				Members omm = this.getMemberService().findMemberByOid(mm.getOid());
				List<MmCard> list = getCardService().findMmCardByMemberOidCardType(omm.getOid(), null);
				String storeId = "";
				String channelId="";
				String vipno = "";
				for (MmCard mmCard : list) {//預製卡只會有一筆default
					storeId = mmCard.getStoreId();
					channelId = mmCard.getChannelId();
					vipno = mmCard.getVipNo();
					mmCard.setMemberId(super.getMembers().getMemberId());
					mmCard.setMemberOid(super.getMembers().getOid());
					mmCard.setStatus(1);
					mmCard.setApproveDate(new Date());
					mmCard.setModifyTime(new Date());
					mmCard.setModifier(this.getUser().getUserId());
					mmCard.setModifierName(this.getUser().getUserName());
					resetModifierName(super.getDialogValue(),super.getMembers(),mmCard);
					getCardService().updateCard(mmCard);
					this.getMemberService().saveOrUpdateMembers(super.getMembers());
				}
				if (omm.getMemberId().compareTo(super.getMembers().getMemberId()) != 0) {
				criditForMemerBonus(omm, super.getMembers(),storeId,channelId,vipno);
				}
				if(!omm.getOid().equals(super.getMembers().getOid()))
					this.getMemberService().deleteMembers(omm.getOid());
				doLoadMember(super.getMembers().getOid());
				setMarketNotice(super.getMembers().getMemberId(), super.getMembers().getOid());
				getMemberService().getMemberDao().updateAndAudit(super.getMembers(), BsCompanyDefinition.getCompanyId());
				if(!omm.getOid().equals(super.getMembers().getOid())){
					mr.setRefKey(super.getMembers().getOid());
					getMemberService().getModifyService().getDao().save(mr);
				}
			}else{
				if(StringUtils.isNotEmpty(noid)){
					doLoadMember(noid);
					auditSuccessLog();
				}
				if(StringUtils.isEmpty(mm.getOid())){
					mr.setRefKey(super.getMembers().getOid());
					getMemberService().getModifyService().getDao().save(mr);
				}
			}
		}
		if(this.isReadOnly(super.getMembers().getStatus()))return READONLY;
		return Action.SUCCESS;
	}
	
	public void criditForMemerBonus(Members oMebmer,Members nMember,String storeId,String channelId,String Vipno) throws Exception{
		MmMembersBonus ommMembersBonus =  getBonusCountSaleDataService().findMmMembersBonus(oMebmer.getMemberId(), oMebmer.getCompanyId());
		MmMembersBonus nmmMembersBonus =  getBonusCountSaleDataService().findMmMembersBonus(nMember.getMemberId(), nMember.getCompanyId());
		if(ommMembersBonus!=null){//預製卡有點數
			if(nmmMembersBonus==null){
				nmmMembersBonus = new MmMembersBonus(nMember.getCompanyId(), channelId, nMember.getMemberId());
				nmmMembersBonus.setBonusTotal(ommMembersBonus.getBonusTotal());
				nmmMembersBonus.setThisYearTot(ommMembersBonus.getThisYearTot());
				nmmMembersBonus.setLastYearTot(ommMembersBonus.getLastYearTot());
				nmmMembersBonus.setModifyTime(new Date());
			}else{
				nmmMembersBonus.setBonusTotalYday(nmmMembersBonus.getBonusTotal());
				nmmMembersBonus.setThisYearTotYday(nmmMembersBonus.getThisYearTot());
				nmmMembersBonus.setLastYearTotYday(nmmMembersBonus.getLastYearTot());
				nmmMembersBonus.setBonusTotal(nmmMembersBonus.getBonusTotal()+ommMembersBonus.getBonusTotal());
				nmmMembersBonus.setThisYearTot(nmmMembersBonus.getThisYearTot()+ommMembersBonus.getThisYearTot());
				nmmMembersBonus.setLastYearTot(nmmMembersBonus.getLastYearTot()+ommMembersBonus.getLastYearTot());
				nmmMembersBonus.setModifyTime(new Date());
			}
			
			BcBonusLog log = new BcBonusLog();
			log.setChannelId(channelId);
			log.setMemberId(nMember.getMemberId());
			log.setStoreId(storeId);
			log.setMemberOid(nMember.getOid());
			List<String> normal = new ArrayList<String>();
			List<String> exnormal = new ArrayList<String>();
			for (MmCard mmCard : this.getMemberService().findMemberByOid(nMember.getOid()).getMmCard()) {
				if(BsCompanyDefinition.getCompanyId().equals(mmCard.getCompanyId())&&mmCard.getCardType()==0){
					if(mmCard.getStatus()==1){
						normal.add(mmCard.getVipNo());
					}else if(mmCard.getStatus()==2){
						exnormal.add(mmCard.getVipNo());
					}
				}
			}
			log.setVipNo(normal.size()==0?exnormal.size()==0?"":exnormal.get(0):normal.get(0));
			log.setMarketId("BSC201007060");
			log.setReason("原身份證號["+oMebmer.getPersonId()+"]轉入/原會員編號["+oMebmer.getMemberId()+"] 轉入");
			log.setBonusAdd(ommMembersBonus.getBonusTotal());
			log.setBonusMins(0);
			log.setBonusTotal(nmmMembersBonus.getBonusTotal());
			log.setCreateTime(new Date());
			log.setCreator("SYS_BATCH");
			log.setCreatorName("SYS_BATCH");
			log.setModifyTime(new Date());
			log.setModifier("SYS_BATCH");
			log.setModifierName("SYS_BATCH");
			log.setBonusType(1);
			log.setTransDate(new Date());
			log.setCompanyId(BsCompanyDefinition.getCompanyId());
			log.setSerialNum(getBsManagerService().getBcBonusSerialNumDao().getSerialNum());
			this.getMemberService().saveOrUpdateMmMembersBonus(nmmMembersBonus);
			getBonusCountSaleDataService().getBonusCountSaleDataDAO().deleteObject(ommMembersBonus);
			getBonusCountSaleDataService().getBonusCountSaleDataDAO().saveOrUpdateObject(log);
		}
		getMtVipService().transfer(oMebmer, nMember, BsCompanyDefinition.getCompanyId());
	}
	
	public void resetModifierName(String type,Members members,MmCard mmCard){
		String companyid = BsCompanyDefinition.getCompanyId();
		if("1".equals(type)){
			if("1010".equals(companyid)){
				members.setModifierName("愛家卡申請書"+"-"+this.getUser().getUserName());
			}else if("1040".equals(companyid)){
				members.setModifierName("特家申請書"+"-"+this.getUser().getUserName());
			}else if("1050".equals(companyid)){
				members.setModifierName("C&B申請書"+"-"+this.getUser().getUserName());
			}
		}else{
			if("1010".equals(companyid)){
				members.setModifierName("愛家卡權益行使書"+"-"+this.getUser().getUserName());
			}else if("1040".equals(companyid)){
				members.setModifierName("特家權益行使書"+"-"+this.getUser().getUserName());
			}else if("1050".equals(companyid)){
				members.setModifierName("C&B權益行使書"+"-"+this.getUser().getUserName());
			}
		}
		members.setModifyTime(new Date());
		members.setModifier(companyid+"_"+this.getUser().getUserId());
	}

	/**
	 * 會員/卡片資料維護(總公司)-查詢
	 */
	@SuppressWarnings("unchecked")
	public String doQuery(){
		try {
			if(!this.hasToCountTotal()) {
				MemberCondition p = (MemberCondition)this.getSessionMap().get(MEMBER_CONDITION);
				this.setCondition(p);
			} else {
				this.getSessionMap().put(MEMBER_CONDITION, this.getCondition());
				this.getPageBean().setJumpPage("");
			}
			this.getCondition().setIsNeedCardExist("");
			QueryResult result = memberService.findMemberGeneralByCondition(this.getCondition(), this.getQueryStartIndex(),
					this.getPageBean().getPageSize(), this.hasToCountTotal(),false);

			this.setPageBeanByQueryResult(result,"doQuery");
			this.getSessionMap().put(MEMBER_PAGEBEAN, this.getPageBean());
			
			auditSuccessLog();
		} catch(Exception e) {
			e.printStackTrace();
			auditFailLog();
		}

		return Action.SUCCESS;
	}
}
