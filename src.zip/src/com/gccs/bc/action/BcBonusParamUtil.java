package com.gccs.bc.action;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.DateTimeUtils;
import com.gccs.bc.model.BcBonusSku;
import com.gccs.bc.service.BcBonusService;
import com.gccs.ws.service.BaseWebService;

public class BcBonusParamUtil {
	private static final Logger log = LogManager.getLogger(BcBonusParamUtil.class) ;
	private HttpServletRequest request;
	private BcBonusService bbService ;
	public static final int SKU = 0;
	public static final int AMT = 1;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

	private String userId;
	private String userName;


	public BcBonusService getBbService() {
		return bbService;
	}
	public void setBbService(BcBonusService bbService) {
		this.bbService = bbService;
	}
	public HttpServletRequest getRequest() {
		return request;
	}
	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}
	

	public BcBonusParamUtil(HttpServletRequest request,BcBonusService bbService,String userId,String userName){
		this.request = request;
		this.bbService = bbService;
		this.userId = userId;
		this.userName = userName;
	}
	
	/**
	 * 重組Sku data
	 * @return
	 * @throws Exception
	 */
	public Map recombinationSkuDetailDataByItem() throws Exception{
		Map skuMap = getSkuParam();
		String refOid = (String)skuMap.get("refOid");
		String [] delOids = (String[])skuMap.get("delOidObj");
		String [] oids = (String[])skuMap.get("oidObj");
		String [] channelIds = (String[])skuMap.get("channelIdsObj");
		String [] classMappeds = (String[])skuMap.get("classMappedObj");
		String [] skus = (String[])skuMap.get("skuObj");
		String [] skuNames = (String[])skuMap.get("skuNameObj");
		String [] vendors = (String[])skuMap.get("vendorObj");
		String [] vendorNames = (String[])skuMap.get("vendorNameObj");
		String [] exBonuss = (String[])skuMap.get("exBonusObj");
		String [] exPercents = (String[])skuMap.get("exPercentObj");
		
		
		BcBonusSku sku = null;
		List<BcBonusSku> addSkuVoList = new ArrayList<BcBonusSku>();
		List<BcBonusSku> updSkuVoList = new ArrayList<BcBonusSku>();
		List<BcBonusSku> delSkuVoList = new ArrayList<BcBonusSku>();
		
		log.info("oids length: "+oids.length);
		String tmpExBouns = null;
		String tmpExPercents = null;
		for(int i=0;i<oids.length;i++){
			sku = new BcBonusSku();
			if(!BaseWebService.isEmpty(passByIgnoreStr(oids[i]))){
				sku.setOid(oids[i]);
			}
			sku.setChannelId(passByIgnoreStr(channelIds[i]));
			if(classMappeds!=null && classMappeds.length>0){
				String [] classmappedDtl = classMappeds[i].split("-");
				sku.setDept(passByIgnoreStr(classmappedDtl[0]));
				sku.setSubDept(passByIgnoreStr(classmappedDtl[1]));
				sku.setClass_(passByIgnoreStr(classmappedDtl[2]));
				sku.setSubClass(passByIgnoreStr(classmappedDtl[3]));
			}

			sku.setSku(passByIgnoreStr(skus[i]));
			sku.setSkuName(passByIgnoreStr(skuNames[i]));
			sku.setVentorId(passByIgnoreStr(vendors[i]));
			sku.setVentorName(passByIgnoreStr(vendorNames[i]));
			
			tmpExBouns = passByIgnoreStr(exBonuss[i]);
			tmpExPercents = passByIgnoreStr(exPercents[i]);
			
			if(!BaseWebService.isEmpty(tmpExBouns)){
				sku.setExBonus(Integer.parseInt(tmpExBouns));
			}else{
				sku.setExPercent(Double.parseDouble(tmpExPercents));
			}
			
			Timestamp sysdate = DateTimeUtils.getSysDate();
			sku.setCreator(this.getUserId());
			sku.setCreatorName(this.getUserName());
			sku.setCreateTime(sysdate);
			sku.setModifier(this.getUserId());
			sku.setModifierName(this.getUserName());
			sku.setModifyTime(sysdate);
			sku.setClassType(this.getBbService().processClassType(sku));
			sku.setBonusType(this.getBbService().processBonusType(sku));
			sku.setPromotOid(refOid);
			
			if(!BaseWebService.isEmpty(sku.getOid())){
				if(isValid(sku))	updSkuVoList.add(sku);
			}else{
				if(isValid(sku))addSkuVoList.add(sku);
			}
			
			
		}
			
		if(delOids!=null&& delOids.length>0){
			for(int i=0;i<delOids.length;i++){
				sku = new BcBonusSku();
				if(!BaseWebService.isEmpty(delOids[i])){
					sku.setOid(delOids[i]);
					delSkuVoList.add(sku);
					log.info("del Oids ===>  ["+i+"]: "+delOids[i]);
				}
			}
		}
		
		Map map = new HashMap();
		//map.put("refOid",refOid);
		map.put("addSkuVoList",addSkuVoList); 
		map.put("updSkuVoList",updSkuVoList); 
		map.put("delSkuVoList",delSkuVoList); 
		return map;
	}	
	
	private boolean isValid(BcBonusSku sku) {
		if(  isNull(sku.getDept()) && isNull(sku.getSubDept()) && isNull(sku.getClass_()) && isNull(sku.getSubClass())
				    && isNull(sku.getSku()) ) {
			return false ;
		}else{
			return true ;
		}
	}
	private static boolean isNull(String value) {
		if(value == null || value.trim().equals("")) {
			return true ;
		}else{
			return false ;
		}
	}
	public Map recombinationSkuDetailDataByItemAmt() throws Exception{

		Map skuMap = getSkuParam();
		String refOid = (String)skuMap.get("refOid");
		String [] delOids = (String[])skuMap.get("delOidObj");
		String [] oids = (String[])skuMap.get("oidObj");
		String [] channelIds = (String[])skuMap.get("channelIdsObj");
		String [] classMappeds = (String[])skuMap.get("classMappedObj");
		String [] skus = (String[])skuMap.get("skuObj");
		String [] skuNames = (String[])skuMap.get("skuNameObj");
		String [] vendors = (String[])skuMap.get("vendorObj");
		String [] vendorNames = (String[])skuMap.get("vendorNameObj");
		
		
		BcBonusSku sku = null;
		List<BcBonusSku> addSkuVoList = new ArrayList<BcBonusSku>();
		List<BcBonusSku> updSkuVoList = new ArrayList<BcBonusSku>();
		List<BcBonusSku> delSkuVoList = new ArrayList<BcBonusSku>();
		
		log.info("oids length: "+oids.length);
		String tmpExBouns = null;
		String tmpExPercents = null;
		for(int i=0;i<oids.length;i++){
			sku = new BcBonusSku();
			if(!BaseWebService.isEmpty(passByIgnoreStr(oids[i]))){
				sku.setOid(oids[i]);
			}
			sku.setChannelId(passByIgnoreStr(channelIds[i]));
			if(classMappeds!=null && classMappeds.length>0){
				String [] classmappedDtl = classMappeds[i].split("-");
				sku.setDept(passByIgnoreStr(classmappedDtl[0]));
				sku.setSubDept(passByIgnoreStr(classmappedDtl[1]));
				sku.setClass_(passByIgnoreStr(classmappedDtl[2]));
				sku.setSubClass(passByIgnoreStr(classmappedDtl[3]));
			}

			sku.setSku(passByIgnoreStr(skus[i]));
			sku.setSkuName(passByIgnoreStr(skuNames[i]));
			sku.setVentorId(passByIgnoreStr(vendors[i]));
			sku.setVentorName(passByIgnoreStr(vendorNames[i]));
			
			
			Timestamp sysdate = DateTimeUtils.getSysDate();
			sku.setCreator(this.getUserId());
			sku.setCreatorName(this.getUserName());
			sku.setCreateTime(sysdate);
			sku.setModifier(this.getUserId());
			sku.setModifierName(this.getUserName());
			sku.setModifyTime(sysdate);
			sku.setClassType(this.getBbService().processClassType(sku));
			sku.setBonusType(this.getBbService().processBonusType(sku));
			sku.setPromotOid(refOid);
			
			if(!BaseWebService.isEmpty(sku.getOid())){
				if(isValid(sku))	updSkuVoList.add(sku);
				updSkuVoList.add(sku);
			}else{
				addSkuVoList.add(sku);
			}
			
			
		}
			
		if(delOids!=null&& delOids.length>0){
			for(int i=0;i<delOids.length;i++){
				sku = new BcBonusSku();
				if(!BaseWebService.isEmpty(delOids[i])){
					sku.setOid(delOids[i]);
					delSkuVoList.add(sku);
					log.info("del Oids ===>  ["+i+"]: "+delOids[i]);
				}
			}
		}
		
		Map map = new HashMap();
		//map.put("refOid",refOid);
		map.put("addSkuVoList",addSkuVoList); 
		map.put("updSkuVoList",updSkuVoList); 
		map.put("delSkuVoList",delSkuVoList); 
		return map;
	}		
	/**
	 * show log
	 * @param updDiscountSkuList
	 * @param addDiscountSkuList
	 */
	public static void showLog(List <BcBonusSku>updSkuList,List <BcBonusSku>addSkuList){
		log.info("更新 Sku size: "+updSkuList.size());
		StringBuilder sb = null;
		for(int i=0;i<updSkuList.size();i++){
			sb = new StringBuilder();
			BcBonusSku sku = updSkuList.get(i);
			sb.append("\n第"+i+"筆\n");
			sb.append("promotOid: "+sku.getPromotOid()+"\n");
			sb.append("oid : "+ sku.getOid()+"\n");
			sb.append("channelId : "+sku.getChannelId()+"\n");
			sb.append("dept: "+sku.getDept()+"\n");
			sb.append("subDept: "+sku.getSubDept()+"\n");
			sb.append("class: "+sku.getClass()+"\n");
			sb.append("subClass: "+sku.getSubClass()+"\n");
			sb.append("sku: "+sku.getSku()+"\n");
			sb.append("skuName : "+sku.getSkuName()+"\n");
			sb.append("vendor: "+sku.getVentorId()+"\n");
			sb.append("vendorName : "+sku.getVentorName()+"\n");
			sb.append("exBonus : "+sku.getExBonus()+"\n");
			sb.append("exPercent : "+sku.getExPercent());
			log.info("upd ===>"+sb.toString());
		}
	}
		
	private int  calAryLength(String[] arg){
		if(arg==null)return 0;
		else return arg.length;
	}
	/**
	 * 取得DisCountSku 頁面參數
	 * @return
	 */
	private Map getSkuParam(){
		Map map = new HashMap();
		String delOid = this.getRequest().getParameter("delOidObj");
		String oidObj = this.getRequest().getParameter("oidObj");
		String channelIdsObj = this.getRequest().getParameter("channelIdsObj");
		String classMappedObj = this.getRequest().getParameter("classMappedObj");
		String skuObj = this.getRequest().getParameter("skuObj");
		String skuNameObj = this.getRequest().getParameter("skuNameObj");
		String vendorObj = this.getRequest().getParameter("vendorObj");
		String vendorNameObj = this.getRequest().getParameter("vendorNameObj");
		String exBonusObj = this.getRequest().getParameter("exBonusObj");
		String exPercentObj = this.getRequest().getParameter("exPercentObj");

		String refOid = this.getRequest().getParameter("refOid");
		String totalCnt = this.getRequest().getParameter("totalCnt");
		
		String [] delOids = null;
		if(!BaseWebService.isEmpty(delOid.split(","))){
			delOids = delOid.split(",");
		}
		
		String [] oids = this.validateAndSplitAry(oidObj);
		String [] channelIds = this.validateAndSplitAry(channelIdsObj);
		String [] classMappeds = this.validateAndSplitAry(classMappedObj);
		String [] skus = this.validateAndSplitAry(skuObj);
		String [] skuNames = this.validateAndSplitAry(skuNameObj);
		String [] vendors =  this.validateAndSplitAry(vendorObj);
		String [] vendorNames = this.validateAndSplitAry(vendorNameObj);
		String [] exBonuss =  this.validateAndSplitAry(exBonusObj);
		String [] exPercents =  this.validateAndSplitAry(exPercentObj);		
		
		StringBuilder sblog = new StringBuilder();
		sblog.append("\n length => oid: "+calAryLength(oids)+"\n")
		.append("channelIdsObj: "			+calAryLength(channelIds)+"\n")
		.append("classMappedObj: "		+calAryLength(classMappeds)+"\n")
		.append("skuObj: "					+calAryLength(skus)+"\n")
		.append("skuNameObj: "			+calAryLength(skuNames)+"\n")
		.append("vendorObj : "				+ calAryLength(vendors)+"\n")
		.append("vendorNameObj : "		+ calAryLength(vendorNames)+"\n")
		.append("exBonusObj : "				+ calAryLength(exBonuss)+ "\n")
		.append("exPercentObj : "			+ calAryLength(exPercents)+"\n" )
		.append("totalCan: "					+totalCnt);
		log.info(sblog.toString());
		
		map.put("delOidObj",delOids);
		map.put("oidObj", oids);
		map.put("channelIdsObj",channelIds);
		map.put("classMappedObj",classMappeds);
		map.put("skuObj",skus);
		map.put("skuNameObj", skuNames);		
		map.put("vendorObj",vendors);
		map.put("vendorNameObj",vendorNames);
		map.put("exBonusObj",exBonuss);
		map.put("exPercentObj",exPercents);
		map.put("refOid",refOid);
		map.put("totalCnt", totalCnt);
		
		return map;
	}
	
	/**
	 * getAmtParam
	 * @return Map
	 */
	@SuppressWarnings("unchecked")
	private Map getAmtParam(){
		Map map = new HashMap();
		String delOid = this.getRequest().getParameter("delOidObj");
		String oidObj = this.getRequest().getParameter("oidObj");
		String amountFObj = this.getRequest().getParameter("amountFObject");
		String amountTObj = this.getRequest().getParameter("amountTObject");
		String exBonusObj = this.getRequest().getParameter("exBonusObj");

		String refOid = this.getRequest().getParameter("refOid");
		String totalCnt = this.getRequest().getParameter("totalCnt");
		
		String [] delOids = null;
		if(!BaseWebService.isEmpty(delOid.split(","))){
			delOids = delOid.split(",");
		}
		
		String [] oids = this.validateAndSplitAry(oidObj);
		String [] amountFs = this.validateAndSplitAry(amountFObj);
		String [] amountTs = this.validateAndSplitAry(amountTObj);
		String [] exBonuss =  this.validateAndSplitAry(exBonusObj);
		
		StringBuilder sblog = new StringBuilder();
		sblog.append("\n length => oid: "+calAryLength(oids)+"\n")
		.append("amountFObj: "				+calAryLength(amountFs)+"\n")
		.append("amountTObj: "				+calAryLength(amountTs)+"\n")
		.append("exBonusObj : "				+ calAryLength(exBonuss)+ "\n")
		.append("totalCan: "					+totalCnt);
		log.info(sblog.toString());
		
		map.put("delOidObj",delOids);
		map.put("oidObj", oids);
		map.put("amountFObj",amountFs);
		map.put("amountTObj",amountTs);
		map.put("exBonusObj",exBonuss);
		map.put("refOid",refOid);
		map.put("totalCnt", totalCnt);
		
		return map;
	}	
	private String[] validateAndSplitAry(String str){
		if(str==null || str.equals("")){
			return new String[0];
		}else return  str.split(","); 
	}
	
	/**
	 * 忽略字串'|'
	 * @param str
	 * @return
	 */
	private String passByIgnoreStr(String str){
		String ignoreStr = "|";
		if(str!=null&&!"".equalsIgnoreCase(str)){
			if(str.equalsIgnoreCase(ignoreStr)){
				return null;
			}
		}
		return str;
	}	
}
