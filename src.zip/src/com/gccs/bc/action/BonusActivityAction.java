package com.gccs.bc.action;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.PageBean;
import com.bnq.util.QueryResult;
import com.gccs.base.action.BaseAction;
import com.gccs.bc.service.BcExchangeService;
import com.gccs.bc.setting.vo.BcBonusSettingVo;
import com.opensymphony.xwork2.Action;

public class BonusActivityAction extends BaseAction {
	private static final long serialVersionUID = -3654468733890198646L;

	private static final Logger log = LogManager.getLogger(BonusActivityAction.class);	
	private static final String _session_PageBean = "_session_PageBean";
	private static final String _session_Query = "_session_Query";
	
	public static final Map<String,String> statusMap;
	public static final Map<String,String> detailActionMap;
	static{
		statusMap = new LinkedHashMap<String,String>();
		statusMap.put("4", "審核");
		statusMap.put("1", "生效");
		statusMap.put("2", "失效");	
		
		detailActionMap = new HashMap<String,String>();
		detailActionMap.put("1-0", "editBcExchangePos");
		detailActionMap.put("1-1", "editBcExchangeService");
		detailActionMap.put("1-2", "editBcExchangePosDis");
		detailActionMap.put("2-0", "editBcBonusGeneral");
		detailActionMap.put("2-1", "editBcBonusItem");
		detailActionMap.put("2-2", "editBcBonusAmt");
		detailActionMap.put("2-3", "editBcBonusPercentAmt");
		detailActionMap.put("2-4", "editBcBonusItemAmt");
	}
			
	private String _actionName;
	private BcExchangeService service;
	private BcBonusSettingVo condition;	
	
	public String get_action(String methodName) {
		return this._actionName + "!" + methodName;
	}		
	public String get_action_query() {
		return this.get_action("query");
	}
	public String get_action_exit() {
		return this.get_action("exit");
	}
	
	public String queryStatusTxt(String status) {
		return statusMap.get(status);
	}
	public String queryDetailAction(String type) {
		return detailActionMap.get(type);
	}
	
	public String execute() {
		this.getSessionMap().remove(_session_PageBean);
		this.getSessionMap().remove(_session_Query);	
		
		return Action.SUCCESS;
	}
	
	public String exit() {
		this.setPageBean((PageBean)this.getSessionMap().get(_session_PageBean));
		this.setCondition((BcBonusSettingVo)this.getSessionMap().get(_session_Query));
		
		return SUCCESS;
	}
		
	public String query() {				
		try {				
			if(!this.hasToCountTotal()) {				
				this.condition = (BcBonusSettingVo)this.getSessionMap().get(_session_Query);
			} else {
				this.getSessionMap().put(_session_Query, this.condition);
				this.getPageBean().setJumpPage("");
			}
						
			QueryResult result = service.findBonusActivity(this.condition, getQueryStartIndex(), getPageBean().getPageSize(), hasToCountTotal());						
			this.setPageBeanByQueryResult(result, this.get_action_query());
			
			this.getSessionMap().put(_session_PageBean, this.getPageBean());
		} catch(Exception e) {
			log.error(e);
		}
		
		return Action.SUCCESS;
	}		
		
	public String get_actionName() {
		return _actionName;
	}
	public void set_actionName(String name) {
		_actionName = name;
	}
	public BcExchangeService getService() {
		return service;
	}
	public void setService(BcExchangeService service) {
		this.service = service;
	}
	public BcBonusSettingVo getCondition() {
		return condition;
	}
	public void setCondition(BcBonusSettingVo condition) {
		this.condition = condition;
	}
}
