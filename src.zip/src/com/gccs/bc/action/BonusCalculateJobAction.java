package com.gccs.bc.action;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.StopWatch;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.cs.cc.batch.AmTxtJob;
import com.bnq.cs.cc.batch.ProductServiceMailJob;
import com.bnq.util.AppContext;
import com.bnq.util.DateTimeUtils;
import com.bnq.util.DateUtils;
import com.gccs.base.action.BaseAction;
import com.gccs.bc.job.BonusSettingJob;
import com.gccs.bc.service.BcBonusService;
import com.gccs.bc.service.BcSomService;
import com.gccs.bc.setting.service.BcBonusSettingService;
import com.gccs.bonus.job.BcBonusSummaryJob;
import com.gccs.bonus.job.MtSkuDiscountExcludeCbJob;
import com.gccs.bonus.service.BonusCountService;
import com.gccs.bonus.service.BonusCountSomService;
import com.gccs.bonus.service.BonusCountWageService;
import com.gccs.bonus.service.IBcBonusTemporalService;
import com.gccs.bonus.service.InactiveBonusService;
import com.gccs.marketing.IIntegrateImpoirtDataService;
import com.gccs.marketing.model.IntegrateImpoirtData;
import com.gccs.marketing.service.MarketingService;
import com.gccs.member.enums.TransStatus;
import com.gccs.member.job.AbnormalConsumptionJob;
import com.gccs.member.job.BussinessMemberCreditLimitJob;
import com.gccs.member.job.ChangDiscountJob;
import com.gccs.member.job.ModifyDecorSyncJob;
import com.gccs.member.model.MtGroupVip;
import com.gccs.member.service.AccountService;
import com.gccs.member.service.IMarketNoticeService;
import com.gccs.member.service.IMtGroupVipService;
import com.gccs.member.service.MemberCouponDetailService;
import com.gccs.member.service.MemberCouponOutboundService;
import com.gccs.member.service.MemberService;
import com.gccs.member.service.MemberWebInfoService;
import com.gccs.member.service.VipService;
import com.gccs.member.util.CalendarUtil;
import com.gccs.member.util.JsonResultTemplateErrorCode;
import com.gccs.mp.batch.MpStatusUpdate;
import com.gccs.pos.AbstractPosTextGenerator;
import com.gccs.pos.job.BillingJob;
import com.gccs.pos.service.PosService;
import com.gccs.util.cache.BsCompanyDefinition;
import com.gccs.util.quartz.IQuartzLogService;
import com.gccs.util.quartz.util.QuartzLogGlossary;
import com.gccs.util.web.SelectItem;
import com.opensymphony.xwork2.ActionContext;
import com.rfep.nm.service.INmProduceService;

public class BonusCalculateJobAction extends BaseAction {
	private static final long serialVersionUID = 5714888800275730903L;
	private static final Logger log = LogManager.getLogger(BonusCalculateJobAction.class);
	private static final Logger vipBatchlog = LogManager.getLogger("vipBatch"); 
	private IQuartzLogService logService;
	private BonusCountService bonusCountService;
	private BonusCountWageService bonusCountWageService;
	private InactiveBonusService inactiveBonusService;
	private MarketingService mtService;
	private ChangDiscountJob changDiscountJob;
	private ModifyDecorSyncJob modifyDecorSyncJob;
	private IBcBonusTemporalService bcBonusTemporalService;
	private AccountService accountService =(AccountService)AppContext.getBean("accountService");
	private MemberService memberService;
	private PosService posService;
	private IIntegrateImpoirtDataService integrateImpoirtDataService;
	private MemberWebInfoService memberWebInfoService;
	private IMarketNoticeService marketNoticeService;
	private MemberCouponDetailService memberCouponDetailService;
	private BcSomService bcSomService;
	private BonusCountSomService bonusCountSomService;
	private MemberCouponOutboundService memberCouponOutboundService;
	private INmProduceService nmProduceService;
	private BcBonusSettingService bcBonusSettingService;
	public BcBonusSettingService getBcBonusSettingService() {
		return bcBonusSettingService;
	}

	public void setBcBonusSettingService(BcBonusSettingService bcBonusSettingService) {
		this.bcBonusSettingService = bcBonusSettingService;
	}

	private VipService vipService;
	
	private String[] batchId = { 
			QuartzLogGlossary._id_bonus_wage_calculate, 
			QuartzLogGlossary._id_disbonus, 
			QuartzLogGlossary._id_pos_vip, 
			QuartzLogGlossary._id_bonus_calculate,
			QuartzLogGlossary._id_LastYearBonusClean,
			QuartzLogGlossary._id_LastYearBonusSummary};
	
	private String jobName;
	private String executionDate = DateUtils.cdateFormat(DateUtils.addDay(new Date(), -1));
	private String storeId;
	private String channelId;
	
	private String executionDateTo;
	private String executionDateForm;
	private String vipDay2;

	private IMtGroupVipService mtGroupVipService; 
	private List<MtGroupVip> mtGroupVipList;
	private String mtGroupVip; //channelGroupId
	private String mtGroupVipChannel; //channelId
	private String mtGroupVipChannelStore; //storeId
	
	private String memIdsTable;
	private String memIdsTableTRPlus;
	
	private String otherExecutionDate;
	
	//分組執行使用--------------------------------------------
	private String numOfGrp;
	private String grpNo;
	private String exeStartDate;
	private String exeEndDate;
	private String numOfGrpTrplus;
	private String grpNoTrplus;
	private String exeStartDateTrplus;
	private String exeEndDateTrplus;
	
	public String getNumOfGrpTrplus() {
		return numOfGrpTrplus;
	}

	public void setNumOfGrpTrplus(String numOfGrpTrplus) {
		this.numOfGrpTrplus = numOfGrpTrplus;
	}

	public String getGrpNoTrplus() {
		return grpNoTrplus;
	}

	public void setGrpNoTrplus(String grpNoTrplus) {
		this.grpNoTrplus = grpNoTrplus;
	}

	public String getExeStartDateTrplus() {
		return exeStartDateTrplus;
	}

	public void setExeStartDateTrplus(String exeStartDateTrplus) {
		this.exeStartDateTrplus = exeStartDateTrplus;
	}

	public String getExeEndDateTrplus() {
		return exeEndDateTrplus;
	}

	public void setExeEndDateTrplus(String exeEndDateTrplus) {
		this.exeEndDateTrplus = exeEndDateTrplus;
	}

	public String getNumOfGrp() {
		return numOfGrp;
	}

	public void setNumOfGrp(String numOfGrp) {
		this.numOfGrp = numOfGrp;
	}

	public String getGrpNo() {
		return grpNo;
	}

	public void setGrpNo(String grpNo) {
		this.grpNo = grpNo;
	}

	public String getExeStartDate() {
		return exeStartDate;
	}

	public void setExeStartDate(String exeStartDate) {
		this.exeStartDate = exeStartDate;
	}

	public String getExeEndDate() {
		return exeEndDate;
	}

	public void setExeEndDate(String exeEndDate) {
		this.exeEndDate = exeEndDate;
	}
	//分組執行使用--------------------------------------------

	@SuppressWarnings("unchecked")
	public String execute() {
		String flag = "";
		if("1050".equals(BsCompanyDefinition.getCompanyId())){
			flag = "2";
		}else{
			flag = "3";
		}
		this.mtGroupVipList = this.getMtGroupVipService().find(flag);
		
		MtGroupVip mgv = new MtGroupVip();
		mgv.setChannelGroupId("");
		mgv.setGroupCname("請選擇");
		mtGroupVipList.add(0, mgv);
		
		return SUCCESS;
	}
	
	public String save() {
		boolean succ=false;
		Map<String,Object> jsonMap=new HashMap<String,Object>();
		try {
			// 更新商務會員折扣
			if(StringUtils.equals(jobName, String.valueOf(SelectItem.ChangDiscountJob))){
				changDiscountJob.execute();
				jsonMap.put("msg","更新商務會員折扣執行完成！");
			} 
			// ModifyDecorSyncJob
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.ModifyDecorSyncJob))){
				modifyDecorSyncJob.execute();
				jsonMap.put("msg","DecorSyncJob執行完成！");
			}
			// 變動折扣處理
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.ChangDiscountJobTriggerBean))){
				if (StringUtils.isBlank(getOtherExecutionDate())) throw new Exception("必須輸入交易日期！");
				doChangDiscountJobTriggerBean();
				jsonMap.put("msg","變動折扣處理執行完成！");
			}
			// 企業卡及專業卡停卡作業
			else if (StringUtils.equals(jobName, String.valueOf(SelectItem.CancelCard))) {
				if (StringUtils.isBlank(getOtherExecutionDate())) throw new Exception("必須輸入交易日期！");
				doCancelCardJobTriggerBean();
				jsonMap.put("msg","企業卡及專業卡停卡作業執行完成！");
			}
			// 計算累積消費金額JOB
			else if (StringUtils.equals(jobName, String.valueOf(SelectItem.CulmSaleAmt))) {
				if (StringUtils.isBlank(getOtherExecutionDate())) throw new Exception("必須輸入交易日期！");
				doCulmSaleAmtJobTriggerBean();
				jsonMap.put("msg","計算累積消費金額JOB執行完成！");
			}
			// 異常卡處理
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.ErrorCardJobTriggerBean))){
				doErrorCardJobTriggerBean();
				jsonMap.put("msg","異常卡處理執行完成！");
			}
			// 更新商務會員之應收帳款
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.ArAmountJobTrigger))){
				doArAmountJobTrigger();
				jsonMap.put("msg","更新商務會員之應收帳款執行完成！");
			}
			// 批次產生紅利點數總表
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.BcBonusTemporalSum))){
				doBcBonusTemporalSum();
				jsonMap.put("msg","批次產生紅利點數總表執行完成！");
			}
			// 批次匯入作業
			else if(StringUtils.equals(jobName, String.valueOf(11))){
				new Thread() {
					public void run() {
						executeBatchImport();
					}
				}.start();
				jsonMap.put("msg","已於batch執行!");
			}
			// 商務會員異常通知
			else if(StringUtils.equals(jobName, String.valueOf(12))){
				executeAmountStatusChange();
				jsonMap.put("msg","商務會員異常通知執行完成！");
			}
			// 匯出檔案2-之後會取消，有可能會拿掉
//			else if(StringUtils.equals(jobName, String.valueOf(13))){
//				exportFile2();
//				jsonMap.put("msg","匯出檔案執行完成！");
//			}
			// smm 匯入
			else if(StringUtils.equals(jobName, String.valueOf(14))){
				executeSmmImport();
				jsonMap.put("msg","匯出檔案執行完成！");
			}
			// 會員登入資訊匯入
			else if(StringUtils.equals(jobName, String.valueOf(15))){
				executeWebInfoImport(); 
				jsonMap.put("msg","匯出檔案執行完成！");
			}
			// 會員網站資訊轉出
			else if(StringUtils.equals(jobName, String.valueOf(16))){
				executeWebInfoExport();
				jsonMap.put("msg","匯出檔案執行完成！");
			}
			//Mm_Market_Notice 最近一次消費日期
			else if(StringUtils.equals(jobName, String.valueOf(17))){
				executeLastConsumer(); 
				jsonMap.put("msg","匯出檔案執行完成！");
			}
			//Mm_Market_Notice 變更行銷意願日期
			else if(StringUtils.equals(jobName, String.valueOf(18))){
				executeChangeMarket();
				jsonMap.put("msg","匯出檔案執行完成！");
			}
			// TO SAS (MK)VIP名單
			else if(StringUtils.equals(jobName, String.valueOf(19))){
				toSasList();
				jsonMap.put("msg","匯出檔案執行完成！");
			}
			// TO HOLA贈品系統VIP名單
			else if(StringUtils.equals(jobName, String.valueOf(20))){
				toHolaVipList();
				jsonMap.put("msg","匯出檔案執行完成！");
			}
			// 折價卷贈品匯入
			else if(StringUtils.equals(jobName, String.valueOf(21))){
				doImportCoupon();
				jsonMap.put("msg","匯入作業執行完成！");
			}
			// 折價卷贈品匯出
			else if(StringUtils.equals(jobName, String.valueOf(22))){
				doExportCoupon();
				jsonMap.put("msg","匯出作業執行完成！");
			}
			// SOM訂單資料匯入
			else if(StringUtils.equals(jobName, String.valueOf(23))){
				doImportBcSom();
				jsonMap.put("msg","匯入作業執行完成！");
			}
			// 紅利點數活動設定失效檢核
			else if(StringUtils.equals(jobName, String.valueOf(30))){
				doBonusSetting();
				jsonMap.put("msg","紅利點數活動設定失效檢核完成！");
			}
			//更新多重促銷主檔及促銷手法狀態欄位
			else if(StringUtils.equals(jobName, String.valueOf(31))){
				doStatusUpdate();
				jsonMap.put("msg","更新多重促銷主檔及促銷手法狀態欄位完成！");
			}
			//商務會員信用額度控管
			else if(StringUtils.equals(jobName, String.valueOf(32))){
				doBsMemberCreditLimt();
				jsonMap.put("msg","商務會員信用額度控管完成！");
			}else if(StringUtils.equals(jobName, String.valueOf(33))){
				new Thread() {
					public void run() {
						batchNmSkuImport();
					}
				}.start();
				jsonMap.put("msg","已於batch執行!");
			}
			else {
				notNullValidate();
			}
			
			
			// HISU 工資計算
			if(StringUtils.equals(jobName,SelectItem.WAGE_BONUS)){
				doBonusCountWageProcess();
				jsonMap.put("msg","HISU 工資計算排程執行完成！");
			}
			// 紅利計算
			else if(StringUtils.equals(jobName,SelectItem.BONUS)){
				doBonusCountProcess(SelectItem.allProcess);
				jsonMap.put("msg","紅利點數計算排程執行完成！");
			}
			// 酷卡計算
			else if(StringUtils.equals(jobName,SelectItem.COOL_CARD)){
				doCreatePosVipProcess();
				jsonMap.put("msg","酷卡計算排程執行完成！");
			}
			// 點數清算
			else if(StringUtils.equals(jobName,SelectItem.INACTIVE_BONUS)){
				doInactiveBonusProcess();
				jsonMap.put("msg","點數清算排程執行完成！");
			}
			//年度紅利點數結算
			else if(StringUtils.equals(jobName,SelectItem.BONUS_SUMMARY)){
				doLastYearBonusSummaryProcess(false);
				jsonMap.put("msg","年度紅利點數結算執行完成！");
			}
			//年度紅利點數清算
			else if(StringUtils.equals(jobName,SelectItem.BONUS_CLEAN)){
				doLastYearBonusCleanProcess(false);
				jsonMap.put("msg","年度紅利點數清算執行完成！");
			}
			//年度紅利點數結算(先復原資料)
			else if(StringUtils.equals(jobName,SelectItem.BONUS_SUMMARY_BACKUP)){
				doLastYearBonusSummaryProcess(true);
				jsonMap.put("msg","年度紅利點數結算執行完成！");
			}
			//年度紅利點數清算(先復原資料)
			else if(StringUtils.equals(jobName,SelectItem.BONUS_CLEAN_BACKUP)){
				doLastYearBonusCleanProcess(true);
				jsonMap.put("msg","年度紅利點數清算執行完成！");
			}
			//正常交易
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.NormalProcess))){
				doBonusCountProcess(SelectItem.NormalProcess);
				jsonMap.put("msg","正常交易執行完成！");
			}
			//正常作廢
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.NormalCancelProcess))){
				doBonusCountProcess(SelectItem.NormalCancelProcess);
				jsonMap.put("msg","正常作廢執行完成！");
			}
			//退貨交易
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.RejectionProcess))){
				doBonusCountProcess(SelectItem.RejectionProcess);
				jsonMap.put("msg","退貨交易執行完成！");
			}
			//退貨作廢
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.RejectionCancelProcess))){
				doBonusCountProcess(SelectItem.RejectionCancelProcess);
				jsonMap.put("msg","退貨作廢執行完成！");
			} 
			//VIP計算
			else if(StringUtils.equals(jobName,SelectItem.VIP)){
				doVipSvipProcess(TransStatus.ALL, getVipTransDate());
				jsonMap.put("msg","VIP計算排程執行完成！");
			}
			//VIP all
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.VIP))){
				doVipSvipProcess(TransStatus.NORMAL, getVipTransDate());
				jsonMap.put("msg","VIP正常交易執行完成！");
			}
			//VIP正常交易
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.VipNormalProcess))){
				
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				Date exeStartDateD = sdf.parse(exeStartDate);
				Date exeEndDateD = sdf.parse(exeEndDate);
				Calendar c = Calendar.getInstance();
				c.setTime(exeStartDateD);
				do {
					Date transDate = c.getTime();
					vipBatchlog.info("start calculate VIPSVIP : " + sdf.format(transDate) + ", group number: " + grpNo);
					doVipSvipProcess(TransStatus.NORMAL, transDate);
					vipBatchlog.info("end calculate VIPSVIP : " + sdf.format(transDate) + ", group number: " + grpNo);
					c.add(Calendar.DATE, 1);
				} while(c.getTime().before(exeEndDateD) ||  c.getTime().equals(exeEndDateD));
				
//				doVipSvipProcess(TransStatus.NORMAL, getVipTransDate());
				jsonMap.put("msg","VIP正常交易執行完成！");
			}
			//VIP正常作廢
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.VipNormalCancelProcess))){
				doVipSvipProcess(TransStatus.NormalCancel, getVipTransDate());
				jsonMap.put("msg","VIP正常作廢執行完成！");
			}
			//VIP退貨交易
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.VipRejectionProcess))){
				doVipSvipProcess(TransStatus.Reject, getVipTransDate());
				jsonMap.put("msg","VIP退貨交易執行完成！");
			}
			//VIP退貨作廢
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.VipRejectionCancelProcess))){
				doVipSvipProcess(TransStatus.RejectCancel, getVipTransDate());
				jsonMap.put("msg","VIP退貨作廢執行完成！");
			}
			//TR Plus VIP計算
			else if(StringUtils.equals(jobName,SelectItem.VIP_TRPLUS)){
				doVipSvipProcessTRPlus(TransStatus.NORMAL, getVipTransDate());
				jsonMap.put("msg","TR Plus VIP計算排程執行完成！");
			}
			//TR Plus VIP正常交易
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.VipNormalProcess_TRPLUS))){
				
				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
				Date exeStartDateD = sdf.parse(exeStartDateTrplus);
				Date exeEndDateD = sdf.parse(exeEndDateTrplus);
				Calendar c = Calendar.getInstance();
				c.setTime(exeStartDateD);
				do {
					Date transDate = c.getTime();
					vipBatchlog.info("start calculate VIPSVIP(TRPlus) : " + sdf.format(transDate) + ", group number: " + grpNoTrplus);
					doVipSvipProcessTRPlus(TransStatus.NORMAL, transDate);
					vipBatchlog.info("end calculate VIPSVIP(TRPlus) : " + sdf.format(transDate) + ", group number: " + grpNoTrplus);
					c.add(Calendar.DATE, 1);
				} while(c.getTime().before(exeEndDateD) ||  c.getTime().equals(exeEndDateD));
				
//				doVipSvipProcessTRPlus(TransStatus.NORMAL, getVipTransDate());
				jsonMap.put("msg","TR Plus VIP正常交易執行完成！");
			}
			//TR Plus VIP正常作廢
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.VipNormalCancelProcess_TRPLUS))){
				doVipSvipProcessTRPlus(TransStatus.NormalCancel, getVipTransDate());
				jsonMap.put("msg","TR Plus VIP正常作廢執行完成！");
			}
			//TR Plus VIP退貨交易
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.VipRejectionProcess_TRPLUS))){
				doVipSvipProcessTRPlus(TransStatus.Reject, getVipTransDate());
				jsonMap.put("msg","TR Plus VIP退貨交易執行完成！");
			}
			//TR Plus VIP退貨作廢
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.VipRejectionCancelProcess_TRPLUS))){
				doVipSvipProcessTRPlus(TransStatus.RejectCancel, getVipTransDate());
				jsonMap.put("msg","TR Plus VIP退貨作廢執行完成！");
			}
			//第一次到店
			else if(StringUtils.equals(jobName, "99")){
				doFirstStore();
				jsonMap.put("msg","第一次到店完成！");
			}
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.BillingProcess))){
				doBillingJob();
				jsonMap.put("msg","專業卡帳單billingjob完成！");
			}
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.ProductServiceMailProcess))){
				doProductServiceJob();
				jsonMap.put("msg","寄送Email完成！");
			}
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.AmTxtProcess))){
				doAmTxtFileJob();
				jsonMap.put("msg","產生萬里通文字檔完成！");
			}
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.AbnormalConsumptionProcess))){
				doAbnormalConsumptionJob();
				jsonMap.put("msg","消費異常月報資料完成！");
			}
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.MtSkuDiscountProcess))){
				doMtSkuDiscountJob();
				jsonMap.put("msg","ZHNT 合營商品 ZTNT 專櫃商品完成！");
			}
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.FirstPurchase))){
				doFirstPurchaseJob();
				jsonMap.put("msg","首次消費日文字檔完成！");
			}
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.PhoneRegLog))){
				doPhoneRegLogJob();
				jsonMap.put("msg","產出手機認證的異動檔文字檔！");
			}
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.BcBonusSummary))) {
				doBcBonusSummaryJob();
				jsonMap.put("msg","會員月紅利現金積點批次計算完成！");
			}
			else if(StringUtils.equals(jobName, String.valueOf(SelectItem.LINE_DAILY))) {
				JsonResultTemplateErrorCode json = makeLineDailyJob();
				if ("008".equals(json.getErrorCode())) {
					jsonMap.put("msg","新增LINE會員綁定文字檔完成！");
				} else {
					jsonMap.put("msg", "新增LINE會員綁定文字檔失敗！");
					log.error(json.getMessage());
				}
			} 
			succ=true;
		} catch (Exception e) {
			succ=false;
			log.error(e.getMessage(), e);
			jsonMap.put("errmsg", e.getMessage());
		}
		jsonMap.put("succ",succ);
		getRequest().setAttribute("result",jsonMap);
		return "jsonData";
	}
	
	// 批次匯入作業
	public void executeBatchImport(){
		try {
			long l0 = System.currentTimeMillis();
			log.info("[IntergrateImportDataJob] launched.");
			
			// 初始化
			String seqNo = this.getIntegrateImpoirtDataService().initBatch();
			long l1 = System.currentTimeMillis();
			log.info("[IntergrateImportDataJob init] task finish. time cost : " + ((l1 - l0) / 1000));

			// 執行3041批次匯入
			this.getIntegrateImpoirtDataService().executeBatch("3041",seqNo);
			long l2 = System.currentTimeMillis();
			log.info("[IntergrateImportDataJob 3041] task finish. time cost : " + ((l2 - l1) / 1000));

			// 執行3042批次匯入
			this.getIntegrateImpoirtDataService().executeBatch("3042",seqNo);
			long l3 = System.currentTimeMillis();
			log.info("[IntergrateImportDataJob 3042] task finish. time cost : " + ((l3 - l2) / 1000));

			// 執行3023批次匯入
			this.getIntegrateImpoirtDataService().executeBatch("3023",seqNo);
			long l4 = System.currentTimeMillis();
			log.info("[IntergrateImportDataJob 3023] task finish. time cost : " + ((l4 - l3) / 1000));

			// 執行6603批次匯入
			this.getIntegrateImpoirtDataService().executeBatch("6603",seqNo);
			long l5 = System.currentTimeMillis();
			log.info("[IntergrateImportDataJob 6603] task finish. time cost : " + ((l5 - l4) / 1000));
			
			// 寄送email
			this.getIntegrateImpoirtDataService().sendMail(seqNo);
			long l6 = System.currentTimeMillis();
			log.info("[IntergrateImportDataJob Send mail] task finish. time cost : " + ((l6 - l5) / 1000));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
	}
	
	public void batchNmSkuImport() {
		try {
			System.out.println("NmSkuImportJob start... ");
			// 批次處理nm_sku_import的資料，先執行saveImport之前的相關準備動作
			if(getNmProduceService().checkNmSkuImport()){
				int batchSeq = getNmProduceService().updateNmSkuImportStatusW();
				
				//for 9012 90121 
				getNmProduceService().saveImport(batchSeq);
				
				//for 9016
				getNmProduceService().saveMyCostImport(batchSeq);
				
				//for 90161
				getNmProduceService().saveVendorCostImport(batchSeq);
				
				System.out.println("batchSeq = " + batchSeq);
				// 當處理完必需分別寄送失敗信件和成功信件通知user
				getNmProduceService().sendEmailToUser(batchSeq);
				
				getNmProduceService().sendMyCostEmailToUser(batchSeq);
			} else {
				System.out.println("NmSkuImportJob is not data");
			}
			System.out.println("NmSkuImportJob end... ");
		} catch (Exception e) {
			log.error("NmSkuImportJob : " + e.getMessage(), e);
		}
	}

	public void executeSmmImport() {
		log.info("entering executeSmmImport : " + new Date());
	    try {
	    	List<IntegrateImpoirtData> list = integrateImpoirtDataService.qrySmm();
	    	
	    	for(IntegrateImpoirtData data : list) {
	    		if(data.getSnNo() == null) {
	    			continue;
	    		}
	    		
		    	integrateImpoirtDataService.initBatchForSMM(data.getSnNo());
		    	integrateImpoirtDataService.execute912Batch(data.getSnNo());
	    	}
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		}
		log.info("executeSmmImport end : " + new Date());
	}
	
	public void executeWebInfoImport() {
		log.info("entering executeWebInfoImport : " + new Date());
	    try {
	    	memberWebInfoService.importExecute(this.executionDateForm);  
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		}
		log.info("executeWebInfoImport end : " + new Date());
	}
	
	//匯出
	public void executeWebInfoExport() {
		log.info("entering executeWebInfoExport : " + new Date());
	    try {
	    	ActionContext.getContext().getSession().put("executionDateForm", this.executionDateForm);
			AbstractPosTextGenerator task = (AbstractPosTextGenerator)AppContext.getBean("WEB_INFO");
			task.doTransferToPos();
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		}
		log.info("executeWebInfoExport end : " + new Date());
	}  
	 
	//TO SAS (MK)VIP名單
	public void toSasList() {
		log.info("entering toSasList : " + new Date());
	    try {
	    	ActionContext.getContext().getSession().put("executionDateForm", this.executionDateForm);
			AbstractPosTextGenerator task = (AbstractPosTextGenerator)AppContext.getBean("VIP");
			task.doTransferToPos();
			
			task = (AbstractPosTextGenerator)AppContext.getBean("VIP_UPDATE");
			task.doTransferToPos();
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		}
		log.info("toSasList end : " + new Date());
	}
	 
	//TO HOLA贈品系統VIP名單
	public void toHolaVipList() {
		log.info("entering toHolaVipList : " + new Date());
	    try {
	    	ActionContext.getContext().getSession().put("executionDateForm", this.executionDateForm);
			AbstractPosTextGenerator task = (AbstractPosTextGenerator)AppContext.getBean("HOLAVIP");
			task.doTransferToPos();

			task = (AbstractPosTextGenerator)AppContext.getBean("HOLAVIPOK");
			task.doTransferToPos();
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		}
		log.info("toHolaVipList end : " + new Date());
	}
	
	//折價卷匯入
	public void doImportCoupon() {
		log.info("entering doImportCoupon : " + new Date());
	    try {
	    	memberCouponDetailService.importExecute(true);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		}
		log.info("doImportCoupon end : " + new Date());
	}
	//折價卷匯出
	public void doExportCoupon() {
		log.info("entering doExportCoupon : " + new Date());
	    try {
	    	Date d = StringUtils.isNotBlank(executionDateForm) ? CalendarUtil.stringToDate(this.executionDateForm, "yyyy/MM/dd") : CalendarUtil.stringToDate(CalendarUtil.getYesterday(), "yyyyMMdd") ;
	    	memberCouponOutboundService.exportExecute(d);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		}
		log.info("doExportCoupon end : " + new Date());
	}
	//SOM訂單資料匯入
	public void doImportBcSom() {
		log.info("entering doImportBcSom : " + new Date());
	    try {
	    	bcSomService.importExecute(true);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		}
		log.info("doImportBcSom end : " + new Date());
	}

	public void executeLastConsumer() {
		log.info("entering executeLastConsumer : " + new Date());
	    try {
	    	marketNoticeService.updateLastConsumer(this.executionDateForm);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		}
		log.info("executeLastConsumer end : " + new Date());
	} 

	public void executeChangeMarket() {
		log.info("entering executeChangeMarket : " + new Date());
	    try {
	    	marketNoticeService.updateChangeNtoice(this.executionDateForm);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		}
		log.info("executeChangeMarket end : " + new Date());
	}
	// 商務會員異常通知
	public void executeAmountStatusChange() {
		log.info("AmountStatusChangeJob start : " + new Date());
	    try {
	    	accountService.sendEmailByAmountStatusChangeJob();
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		}
		log.info("AmountStatusChangeJob end : " + new Date());
	}
	
	// 匯出檔案
	// 之後要拿掉
//	private void exportFile2() throws Exception {
//		// 即時折抵table資料產生需在紅利點數計算完再產生
//		long start = System.currentTimeMillis();		
//		System.out.println("exportFile start.");
//		
//		getPosService().queryMmBillingLogFile();
//		
//		long end = System.currentTimeMillis();
//		System.out.println("exportFile end. time=" + ((end - start)/1000) + "sec.");
//	}
	
	private void doChangDiscountJobTriggerBean() throws Exception {
		log.info("開始時間: " + new Date());
		
		boolean doNExtJob = true;
		// 202010 更新
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		Date transDate = sdf.parse(getOtherExecutionDate());
		
		try {
			accountService.updateDiscount(transDate);
			
			log.info("完成時間: " + new Date());
		} catch (Exception e) {
			throw e;
		}
		
		// 每年1/1執行
		accountService.executeChangeDiscountByLastYearAmount(doNExtJob, transDate);
	}
	
	private void doCancelCardJobTriggerBean() throws Exception {
		log.info("[企業卡及專業卡停卡作業]開始時間: " + new Date());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		Date transDate = sdf.parse(getOtherExecutionDate());
		accountService.cancelCard(transDate);
		log.info("[企業卡及專業卡停卡作業]完成時間: " + new Date());
	}
	
	private void doCulmSaleAmtJobTriggerBean() throws Exception {
		log.info("[計算累積消費金額JOB]開始時間: " + new Date());
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
		Date transDate = sdf.parse(getOtherExecutionDate());
		accountService.culmSaleAmt(transDate);
		log.info("[計算累積消費金額JOB]完成時間: " + new Date());
	}
	
	private void doErrorCardJobTriggerBean() throws Exception {
		log.info("============ BEGIN: 異常卡BatchJob ============");
		log.info("開始時間: " + new Date());
		//異常卡處理: 依交易檔建立不存在MM_MEMBERS的會員並建立會員卡
		String transDate = DateTimeUtils.subtractDate(new Date(), 1);
		memberService.createNonExistsMembersAndCards(transDate);
		log.info("完成時間: " + new Date());
		log.info("============ END: 異常卡BatchJob ============");
	}
	
	private void doArAmountJobTrigger() throws Exception {
		log.info("task start : " + new Date());
		Date date = null ;
		Date today = null;
	    try {
	    	today = DateTimeUtils.getFormatSysDate();
	    	date = DateUtils.addDay(today, -1);
	    	accountService.updateArAmountByTrans(date);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		try {
	    	accountService.updateArAmountBySAP(date);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		try {
	    	accountService.arAmountWrittenOff(today);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		try {
	    	accountService.accountLockOrReOpen();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		log.info("task end : " + new Date());
	}
	
	// 批次產生紅利點數總表
	private void doBcBonusTemporalSum() throws Exception {
		// 即時折抵table資料產生需在紅利點數計算完再產生
		long start = System.currentTimeMillis();		
		log.info("BcBonusMonthSummaryJob start.");
		getBcBonusTemporalService().batchUpdateBcBonusTemporalSum();
		long end = System.currentTimeMillis();
		log.info("BcBonusMonthSummaryJob end. time=" + ((end - start)/1000) + "sec.");
	}
	
	/**
	 * 啟動點數清算排程
	 * @throws Exception
	 */
	public void doInactiveBonusProcess() throws Exception {
		try {
			if(!logService.checkPrecedingOperationCompleted(batchId[1]))
				throw new Exception("前一個點數清算排程正在執行中，請稍後再試！");
			
			Date beginDate = DateTimeUtils.getSysDate();
			//更新Batch Log
			this.getLogService().batchProcessBegin(batchId[1], beginDate);
			
			log.info("[inactiveBonusProcess] start. ") ;
			long l3 = System.currentTimeMillis();
			//紅利失效
			this.getInactiveBonusService().inactiveBonusProcess();
			long l4 = System.currentTimeMillis();
			
			Date endDate = DateTimeUtils.getSysDate();
			//更新Batch Log
			this.getLogService().batchProcessEnd(batchId[1], beginDate, endDate);
			
			log.info("[inactiveBonusProcess] end. total time : "+(l3-l4)/1000) ;
		} catch (Exception e) {
			log.error("doInactiveBonusProcess error." + e.getMessage());
			throw e;
		}
	}
	
	/**
	 * 啟動酷卡計算排程
	 * @throws Exception
	 */
	public void doCreatePosVipProcess() throws Exception {
		Date started = new Date() ;
		long l1 = System.currentTimeMillis() ;
		log.info("[CreatePosVip] launched.") ;
		try{
			log.info("Begin Process : "+this.getLogService().batchProcessBegin(batchId[2], started)) ;
			this.getMtService().createPosVip(getTransDat()) ;
			log.info("Finish Process : "+this.getLogService().batchProcessEnd(batchId[2], started,new Date())) ;
		}catch(Exception e){
			log.error(e.getMessage(),e) ;
		}
		long l2 = System.currentTimeMillis() ;
		log.info("[CreatePosVip]task finish. time cost : "+((l2-l1)/1000)) ;
	}
	
	/**
	 * 啟動VIP計算排程
	 * @throws Exception
	 */
	public void doVipProcess(TransStatus transStatus, Date transDate) throws Exception {
		try {
			long l1 = System.currentTimeMillis() ;
			log.info("[vipProcess] launched.") ; 
		
			Map<String, String> channelStoreMap = new HashMap<String, String>();
			channelStoreMap.put("channelGroupId", mtGroupVip);
			channelStoreMap.put("channelId", mtGroupVipChannel);
			channelStoreMap.put("storeId", mtGroupVipChannelStore);
			String flag="";
			if("1050".equals(BsCompanyDefinition.getCompanyId())){
				flag = "2";
				vipService.VipProcessTrcb(transDate, transStatus, isProcDay2(), channelStoreMap,flag);
			}else{
				flag = "1";
				vipService.vipProcess(transDate, transStatus, isProcDay2(), channelStoreMap,flag);
			}
			
			
			long l2 = System.currentTimeMillis() ;
			log.info("[vipProcess] task finish. time cost : "+((l2-l1)/1000));
		}catch(Exception e){
			log.error("doVipProcess error." + e.getMessage());
			throw e;
		}
	}
	
	/**
	 * 2019/10/28
	 * 啟動VIP與SVIP計算排程
	 * @throws Exception
	 */
	public void doVipSvipProcess(TransStatus transStatus, Date transDate) throws Exception {
		try {
			
			StopWatch watch = new StopWatch();
			watch.start();
			vipBatchlog.info("[vipSvipProcess] launched. Group Number: " + grpNo);
		
			Map<String, String> channelStoreMap = new HashMap<String, String>();
			channelStoreMap.put("channelGroupId", mtGroupVip);
			channelStoreMap.put("channelId", mtGroupVipChannel);
			channelStoreMap.put("storeId", mtGroupVipChannelStore);
			
			String flag="";
			
			if("1050".equals(BsCompanyDefinition.getCompanyId())) {
				flag = "2";
				vipService.VipProcessTrcb(transDate, transStatus, isProcDay2(), channelStoreMap, flag);
			} else {
				flag = "3";
				vipService.vipSvipProcess(transDate, transStatus, isProcDay2(), channelStoreMap, flag, memIdsTable, memIdsTableTRPlus, numOfGrp, grpNo);
			}
			
			watch.stop();
			vipBatchlog.info("[vipSvipProcess] task finish. Group Number: " + grpNo + ", time cost: " + watch.getTime());
			
		} catch(Exception e) {
			log.error("doVipSvipProcess error." + e.getMessage());
			throw e;
		}
	}
	
	/**
	 * 啟動TR Plus VIP計算排程
	 * @throws Exception
	 */
	public void doVipSvipProcessTRPlus(TransStatus transStatus, Date transDate) throws Exception {
		try {
			long l1 = System.currentTimeMillis() ;
			vipBatchlog.info("[vipSvipProcess TRPlus] launched. group number: " + grpNoTrplus) ; 
		
			Map<String, String> channelStoreMap = new HashMap<String, String>();
			channelStoreMap.put("channelGroupId", mtGroupVip);
			channelStoreMap.put("channelId", mtGroupVipChannel);
			channelStoreMap.put("storeId", mtGroupVipChannelStore);
			vipService.vipSvipProcessTRPlus(transDate, transStatus, isProcDay2(), channelStoreMap, "3", memIdsTable, memIdsTableTRPlus, numOfGrpTrplus, grpNoTrplus);
			
			
			long l2 = System.currentTimeMillis() ;
			vipBatchlog.info("[vipSvipProcess TRPlus] task finish. group number:" + grpNoTrplus + ", time cost : "+((l2-l1)/1000));
		}catch(Exception e){
			log.error("doVipSvipProcess TRPlus error." + e.getMessage());
			throw e;
		}
	}
	
	/**
	 * 啟動TR Plus VIP計算排程
	 * @throws Exception
	 */
	public void doVipProcessTRPlus(TransStatus transStatus, Date transDate) throws Exception {
		try {
			long l1 = System.currentTimeMillis() ;
			log.info("[vipProcess TRPlus] launched.") ; 
		
			Map<String, String> channelStoreMap = new HashMap<String, String>();
			channelStoreMap.put("channelGroupId", mtGroupVip);
			channelStoreMap.put("channelId", mtGroupVipChannel);
			channelStoreMap.put("storeId", mtGroupVipChannelStore);
			vipService.vipProcessTRPlus(transDate, transStatus, isProcDay2(), channelStoreMap, "1");
			
			
			long l2 = System.currentTimeMillis() ;
			log.info("[vipProcess TRPlus] task finish. time cost : "+((l2-l1)/1000));
		}catch(Exception e){
			log.error("doVipProcess TRPlus error." + e.getMessage());
			throw e;
		}
	}
	
	/**
	 * 是否執行每月2號job, vip 達標者壓上startDate endDate, 次年累積移轉至第一次累積
	 * @return Boolean
	 */
	private Boolean isProcDay2() {
		return StringUtils.isBlank(vipDay2) || "N".equals(vipDay2) ? false : true;
	}
	
	/**
	 * 啟動紅利計算排程
	 * @throws Exception
	 */
	public void doBonusCountProcess(int executeType) throws Exception {
		try {
			if(!logService.checkPrecedingOperationCompleted(batchId[3]))
				throw new Exception("前一個紅利計算排程正在執行中，請稍後再試！");
			
			Date beginDate = DateTimeUtils.getSysDate();
			//更新Batch Log
			logService.batchProcessBegin(batchId[3], beginDate);
			
			long l1 = System.currentTimeMillis() ;
			log.info("[bonusCountProcess] launched.") ;
			//紅利計算
			String actionField;
			if(StringUtils.isBlank(storeId)) {
				actionField = BcBonusService.FIELD_CHANNEL_ID + channelId;
			} else {
				actionField = BcBonusService.FIELD_STORE_ID + storeId;
			}
			
			//適用商品暫存檔
			bcBonusSettingService.initBonusCalSku(getTransDat());
			// 紅利計算
			bonusCountService.bonusCountProcess(getTransDat(), actionField, executeType);
			// 員工卡給點
			bonusCountService.bonusCountProcessForEmployee(getTransDat(), actionField, executeType);
			
//			bonusCountSomService.bonusCountProcess(getTransDat(), actionField, executeType);
			Date endDate = DateTimeUtils.getSysDate();
			//更新Batch Log
			logService.batchProcessEnd(batchId[3], beginDate, endDate);
			
			long l2 = System.currentTimeMillis() ;
			log.info("[bonusCountProcess] task finish. time cost : "+((l2-l1)/1000));
		}catch(Exception e){
			log.error("doBonusCountProcess error." + e.getMessage());
			throw e;
		}
	}
	
	/**
	 * 啟動進行年度紅利點數結算
	 * @throws Exception
	 */
	public void doLastYearBonusSummaryProcess(boolean isNeedToBackupData) throws Exception {
		try {						
			long l1 = System.currentTimeMillis() ;
			log.info("[lastYearBonusSummaryProcess] launched.") ;
			
			if(!logService.checkPrecedingOperationCompleted(batchId[5]))
				throw new Exception("紅利點數計算排程正在執行中，請稍後再試！");
			
			Date beginDate = DateTimeUtils.getSysDate();
			//更新Batch Log
			logService.batchProcessBegin(batchId[5], beginDate);
			
			//年度紅利點數結算			
			bonusCountService.lastYearBonusSummaryProcess(isNeedToBackupData);
			
			Date endDate = DateTimeUtils.getSysDate();
			//更新Batch Log
			logService.batchProcessEnd(batchId[5], beginDate, endDate);
			
			long l2 = System.currentTimeMillis() ;
			log.info("[lastYearBonusSummaryProcess] task finish. time cost : "+((l2-l1)/1000));
		}catch(Exception e){
			log.error("doLastYearBonusSummaryProcess error." + e.getMessage());
			throw e;
		}
	}
	
	/**
	 * 啟動進行年度紅利點數清算
	 * @throws Exception
	 */
	public void doLastYearBonusCleanProcess(boolean isNeedToBackupData) throws Exception {
		try {						
			long l1 = System.currentTimeMillis() ;
			log.info("[lastYearBonusCleanProcess] launched.") ;
			
			if(!logService.checkPrecedingOperationCompleted(batchId[4]))
				throw new Exception("紅利點數計算排程正在執行中，請稍後再試！");
			
			Date beginDate = DateTimeUtils.getSysDate();
			//更新Batch Log
			logService.batchProcessBegin(batchId[4], beginDate);
			
			//年度紅利點數清算			
			bonusCountService.lastYearBonusCleanProcess(isNeedToBackupData);
			
			Date endDate = DateTimeUtils.getSysDate();
			//更新Batch Log
			logService.batchProcessEnd(batchId[4], beginDate, endDate);
			
			long l2 = System.currentTimeMillis() ;
			log.info("[lastYearBonusCleanProcess] task finish. time cost : "+((l2-l1)/1000));
		}catch(Exception e){
			log.error("doLastYearBonusCleanProcess error." + e.getMessage());
			throw e;
		}
	}
	
	/**
	 * 啟動進行年度紅利點數清算
	 * @throws Exception
	 */
	public void doFirstStore() throws Exception {
		try {						
			//第一次到店		
			bonusCountService.doFirstStore();
		}catch(Exception e){
			throw e;
		}
	}
	
	/**
	 * 啟動專業卡帳單billingjob
	 * @throws Exception
	 */
	public void doBillingJob() throws Exception {
		try {						
			final BillingJob job = (BillingJob)AppContext.getBean("billingJob");
			job.runByUser(getVipTransDate());
		}catch(Exception e){
			throw e;
		}
	}
	/**
	 * 啟動寄送商品修維Job
	 * @throws Exception
	 */
	public void doProductServiceJob() throws Exception {
		try {						
			final ProductServiceMailJob job = (ProductServiceMailJob)AppContext.getBean("productServiceMailJob");
			job.setSystem_type(Arrays.asList("PM","PS"));
			job.execute();
//			job.createCsv();
		}catch(Exception e){
			throw e;
		}
	}
	/**
	 * 產生萬里通文字檔
	 * @throws Exception
	 */
	public void doAmTxtFileJob() throws Exception {
		try {						
			final AmTxtJob job = (AmTxtJob)AppContext.getBean("amTxtJob");
			if(StringUtils.isEmpty(executionDate)) throw new Exception("必須輸入執行日期！");
			job.setDerDate(DateUtils.getDate(executionDate));
			job.execute();
		}catch(Exception e){
			throw e;
		}
	}
	/**
	 * 啟動消費異常月報資料
	 * @throws Exception
	 */
	public void doAbnormalConsumptionJob() throws Exception {
		try {						
			final AbnormalConsumptionJob job = (AbnormalConsumptionJob)AppContext.getBean("abnormalConsumptionJob");
			job.execute(getVipTransDate());
		}catch(Exception e){
			throw e;
		}
	}
	
	/**
	 * 啟動ZHNT 合營商品 ZTNT 專櫃商品
	 * @throws Exception
	 */
	public void doMtSkuDiscountJob() throws Exception {
		try {						
			final MtSkuDiscountExcludeCbJob job = (MtSkuDiscountExcludeCbJob)AppContext.getBean("mtSkuDiscountExcludeCbJob");
			job.execute();
		}catch(Exception e){
			throw e;
		}
	}
	
	/**
	 * 啟動首次消費日文字檔
	 * @throws Exception
	 */
	public void doFirstPurchaseJob() throws Exception {
		try {						
			AbstractPosTextGenerator task = (AbstractPosTextGenerator)AppContext.getBean("FIRSTPURCHASE");
			task.doTransferToPos();
		}catch(Exception e){
			throw e;
		}
	}
	
	/**
	 * 產出手機認證的異動檔文字檔
	 * @throws Exception
	 */
	public void doPhoneRegLogJob() throws Exception {
		try {						
			AbstractPosTextGenerator task = (AbstractPosTextGenerator)AppContext.getBean("PHONE_REG_LOG");
			task.doTransferToPos();
		}catch(Exception e){
			throw e;
		}
	}
	
	/**
	 * 會員月紅利現金積點批次計算
	 * @throws Exception
	 */
	public void doBcBonusSummaryJob() throws Exception {
		try {						
			BcBonusSummaryJob task = (BcBonusSummaryJob)AppContext.getBean("bcBonusSummaryJob");
			task.executeBatch();
		}catch(Exception e){
			throw e;
		}
	}
	
	public void doBonusSetting() throws Exception {
		try {						
			final BonusSettingJob job = (BonusSettingJob)AppContext.getBean("exchangeJob");
			job.bonusSettingChange();
		}catch(Exception e){
			throw e;
		}
	}
	
	public void doStatusUpdate() throws Exception {
		try {						
			final MpStatusUpdate job = (MpStatusUpdate)AppContext.getBean("statusUpdateJob");
			job.executeBatch();
		}catch(Exception e){
			throw e;
		}
	}
	
	public void doBsMemberCreditLimt() throws Exception {
		try {						
			final BussinessMemberCreditLimitJob job = (BussinessMemberCreditLimitJob)AppContext.getBean("bussinessMemberCreditLimitJob");
			job.batchExecute();
		}catch(Exception e){
			throw e;
		}
	}
	
	/**
	 * 啟動HISU 工資計算排程
	 * @throws Exception
	 */
	public void doBonusCountWageProcess() throws Exception {
		try {
			if(!logService.checkPrecedingOperationCompleted(batchId[0])) {
				throw new Exception("前一個HISU 工資計算排程正在執行中，請稍後再試！");
			}
			this.getBonusCountWageService().executeBatch(getTransDat());
		} catch (Exception e) {
			log.error("doBonusCountWageProcess error." + e.getMessage());
			throw e;
		}
	}
	
	/**
	 * 啟動makeLineDailyJob
	 * @throws Exception
	 */
	public JsonResultTemplateErrorCode makeLineDailyJob() throws Exception {
		JsonResultTemplateErrorCode json = new JsonResultTemplateErrorCode();
		try {
			String date = executionDate.replace("/", "-") + " 00:00:00.0";
			json = memberService.makeLineDaily(date);
		}catch(Exception e){
			log.error(e.getMessage(), e);
			throw e;
		}
		return json;
	}
	
	public void notNullValidate() throws Exception {
		if(StringUtils.isBlank(jobName))
			throw new Exception("必須選擇排程！");
		if(StringUtils.isBlank(executionDate) && !StringUtils.equals(jobName,SelectItem.INACTIVE_BONUS) && !StringUtils.equals(jobName,String.valueOf(29)))
			throw new Exception("必須輸入執行日期！");
		if(StringUtils.equals(jobName,SelectItem.BONUS) && StringUtils.isBlank(channelId))
			throw new Exception("必須選擇通路別！");
	}
	
	/**
	 * 取系統日期前一天
	 * @return String
	 */
	private Date getTransDat() {
		if(StringUtils.isNotBlank(executionDate)){
			return DateUtils.getDate(executionDate);
		}else{
			Calendar c = Calendar.getInstance();
			c.add(Calendar.DAY_OF_YEAR, -1);
			return c.getTime();
		}
	}
	
	/**
	 * 取vip手動交易日
	 * @return Date
	 */
	private Date getVipTransDate() throws Exception{
		if(StringUtils.isBlank(executionDate)){
			throw new Exception("必須選擇交易日！");
		}

		return DateUtils.getDate(executionDate);
	}
	
	
	public String getExecutionDate() {
		return executionDate;
	}

	public void setExecutionDate(String executionDate) {
		this.executionDate = executionDate;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	
	public BonusCountService getBonusCountService() {
		return bonusCountService;
	}

	public void setBonusCountService(BonusCountService bonusCountService) {
		this.bonusCountService = bonusCountService;
	}

	public IQuartzLogService getLogService() {
		return logService;
	}

	public void setLogService(IQuartzLogService logService) {
		this.logService = logService;
	}

	public BonusCountWageService getBonusCountWageService() {
		return bonusCountWageService;
	}

	public void setBonusCountWageService(BonusCountWageService bonusCountWageService) {
		this.bonusCountWageService = bonusCountWageService;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public InactiveBonusService getInactiveBonusService() {
		return inactiveBonusService;
	}

	public void setInactiveBonusService(InactiveBonusService inactiveBonusService) {
		this.inactiveBonusService = inactiveBonusService;
	}

	public MarketingService getMtService() {
		return mtService;
	}

	public void setMtService(MarketingService mtService) {
		this.mtService = mtService;
	}

	public ChangDiscountJob getChangDiscountJob() {
		return changDiscountJob;
	}

	public void setChangDiscountJob(ChangDiscountJob changDiscountJob) {
		this.changDiscountJob = changDiscountJob;
	}

	public ModifyDecorSyncJob getModifyDecorSyncJob() {
		return modifyDecorSyncJob;
	}

	public void setModifyDecorSyncJob(ModifyDecorSyncJob modifyDecorSyncJob) {
		this.modifyDecorSyncJob = modifyDecorSyncJob;
	}

	public IBcBonusTemporalService getBcBonusTemporalService() {
		return bcBonusTemporalService;
	}

	public void setBcBonusTemporalService(
			IBcBonusTemporalService bcBonusTemporalService) {
		this.bcBonusTemporalService = bcBonusTemporalService;
	}

	public MemberService getMemberService() {
		return memberService;
	}

	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}

	public String getExecutionDateTo() {
		return executionDateTo;
	}

	public void setExecutionDateTo(String executionDateTo) {
		this.executionDateTo = executionDateTo;
	}

	public String getExecutionDateForm() {
		return executionDateForm;
	}

	public void setExecutionDateForm(String executionDateForm) {
		this.executionDateForm = executionDateForm;
	}

	public PosService getPosService() {
		return posService;
	}

	public void setPosService(PosService posService) {
		this.posService = posService;
	}

	public IIntegrateImpoirtDataService getIntegrateImpoirtDataService() {
		return integrateImpoirtDataService;
	}

	public void setIntegrateImpoirtDataService(
			IIntegrateImpoirtDataService integrateImpoirtDataService) {
		this.integrateImpoirtDataService = integrateImpoirtDataService;
	}

	public MemberWebInfoService getMemberWebInfoService() {
		return memberWebInfoService;
	}

	public void setMemberWebInfoService(MemberWebInfoService memberWebInfoService) {
		this.memberWebInfoService = memberWebInfoService;
	}

	public IMarketNoticeService getMarketNoticeService() {
		return marketNoticeService;
	}

	public void setMarketNoticeService(IMarketNoticeService marketNoticeService) {
		this.marketNoticeService = marketNoticeService;
	}

	public VipService getVipService() {
		return vipService;
	}

	public void setVipService(VipService vipService) {
		this.vipService = vipService;
	}

	public String getVipDay2() {
		return vipDay2;
	}

	public void setVipDay2(String vipDay2) {
		this.vipDay2 = vipDay2;
	}

	public IMtGroupVipService getMtGroupVipService() {
		return mtGroupVipService;
	}

	public void setMtGroupVipService(IMtGroupVipService mtGroupVipService) {
		this.mtGroupVipService = mtGroupVipService;
	}

	public List<MtGroupVip> getMtGroupVipList() {
		return mtGroupVipList;
	}

	public void setMtGroupVipList(List<MtGroupVip> mtGroupVipList) {
		this.mtGroupVipList = mtGroupVipList;
	}

	public String getMtGroupVip() {
		return mtGroupVip;
	}

	public void setMtGroupVip(String mtGroupVip) {
		this.mtGroupVip = mtGroupVip;
	}

	public String getMtGroupVipChannel() {
		return mtGroupVipChannel;
	}

	public void setMtGroupVipChannel(String mtGroupVipChannel) {
		this.mtGroupVipChannel = mtGroupVipChannel;
	}

	public String getMtGroupVipChannelStore() {
		return mtGroupVipChannelStore;
	}

	public void setMtGroupVipChannelStore(String mtGroupVipChannelStore) {
		this.mtGroupVipChannelStore = mtGroupVipChannelStore;
	}

	public MemberCouponDetailService getMemberCouponDetailService() {
		return memberCouponDetailService;
	}

	public void setMemberCouponDetailService(
			MemberCouponDetailService memberCouponDetailService) {
		this.memberCouponDetailService = memberCouponDetailService;
	}

	public BcSomService getBcSomService() {
		return bcSomService;
	}

	public void setBcSomService(BcSomService bcSomService) {
		this.bcSomService = bcSomService;
	}

	public void setBonusCountSomService(BonusCountSomService bonusCountSomService) {
		this.bonusCountSomService = bonusCountSomService;
	}

	public BonusCountSomService getBonusCountSomService() {
		return bonusCountSomService;
	}
	
	public void setMemberCouponOutboundService(
			MemberCouponOutboundService memberCouponOutboundService) {
		this.memberCouponOutboundService = memberCouponOutboundService;
	}

	public MemberCouponOutboundService getMemberCouponOutboundService() {
		return memberCouponOutboundService;
	}

	public INmProduceService getNmProduceService() {
		return nmProduceService;
	}

	public void setNmProduceService(INmProduceService nmProduceService) {
		this.nmProduceService = nmProduceService;
	}

	public String getMemIdsTable() {
		return memIdsTable;
	}

	public void setMemIdsTable(String memIdsTable) {
		this.memIdsTable = memIdsTable;
	}

	public String getMemIdsTableTRPlus() {
		return memIdsTableTRPlus;
	}

	public void setMemIdsTableTRPlus(String memIdsTableTRPlus) {
		this.memIdsTableTRPlus = memIdsTableTRPlus;
	}

	public String getOtherExecutionDate() {
		return otherExecutionDate;
	}

	public void setOtherExecutionDate(String otherExecutionDate) {
		this.otherExecutionDate = otherExecutionDate;
	}

}
