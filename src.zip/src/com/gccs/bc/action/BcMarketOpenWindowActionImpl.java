package com.gccs.bc.action;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gccs.bc.model.BcMarket;
import com.gccs.bc.service.BcMarketServiceI;
import com.rfep.base.BaseActionImpl;
import com.rfep.base.PageBean;
import com.rfep.base.QueryResultBean;

/**
 * 報表的處理
 * @author Johnson
 *
 */
public class BcMarketOpenWindowActionImpl extends BaseActionImpl {
	private static final long serialVersionUID = -1247272752665816368L;
	private static final Logger log = LogManager.getLogger(BcMarketOpenWindowActionImpl.class) ;
	private static final String SQL_PATH=CLASS_PATH+"com/gccs/bc/sql/";
	private static BcMarketServiceI operateService;
	protected Map result; //Ajax result data

	public BcMarketServiceI getOperateService() {
		return operateService;
	}

	public void setOperateService(BcMarketServiceI operateService) {
		this.operateService = operateService;
	}

	// 操作表格tableName
	private String tableName;

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}

	public Map getResult() {
		return result;
	}

	public void setResult(Map result) {
		this.result = result;
	}

	/**
	 * JSP進入點,如果不想一進來就執行query(),這個功能可以改用index()
	 * 
	 * @author Johnson
	 * @Date: 2010/10/01 上午 13:00:00
	 * @return
	 */
	public String index() {
		return SUCCESS;
	}
	
	//以上是進入點
	
	//以下是查詢
	public String query() {
		log.info(">>>>>>>>>>>>>>>>Query>>"+tableName);
		try {
			this.setPageBeanByQueryResult(getTableName()) ;
			return SUCCESS;	
		} catch (Exception ex) {
			ex.printStackTrace();
			this.setDspMessage("查詢其失敗原因："+handleError1(ex)+"<br>");
			return ERROR;
		}
	}
	
	
	/**
	 * 此method必需override,以配合query()的setPageBeanByQueryResult()
	 * @author Johnson
	 * @Date: 2010/10/01 上午 13:00:00
	 */
	protected  QueryResultBean getQueryResultBean(PageBean pageBean,Map<String,String> queryCondition,Boolean isCount) throws Exception{
		println(">>>>>>>>>>>>>>>>>>getQueryResult");
		return operateService.queryConditionBySQL(pageBean,queryCondition,isCount,SQL_PATH+"BcMarket.sql",BcMarket.class);	
	}
	//以上是查詢
	
	//-----------------------------------------------------------------------//
	
	public String findName(){
		this.result = new HashMap();
		result.put("success", true);
		try {
			this.getPageBean().setJumpPage(1);
			this.getPageBean().setPageSize(1);
			QueryResultBean resultBean = 
				operateService.queryConditionBySQL(this.getPageBean(),getQueryCondition(),false,SQL_PATH+"BcMarket.sql",BcMarket.class);
			if( resultBean != null ){
				List<BcMarket> resultList = resultBean.getResult();
				if( resultList != null && resultList.size() > 0 ){
					BcMarket bcMarket = resultList.get(0);
					result.put("id", bcMarket.getID());
					result.put("name", bcMarket.getNAME());
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			this.result = new HashMap();
			result.put("success", false);
			result.put("msg", ERROR_MSG);
		}
		return "json";
	}
	
}
