package com.gccs.bc.action;

import com.gccs.base.action.BaseAction;

/**
 * @author JL
 *
 */
public class BcExchangeAction extends BaseAction {
	
}
