package com.gccs.bc.model;
 
public class BcSomOrderDetlReq extends BcSomOrderDetlTxt{   
	public static final String OVERLEN_WORD = "%s長度不得超過%d, ";
	public static final String RECORDLEN_WORD = "資料長度不正確";

	public static final Integer ORDER_ID_LEN = 10;
	
	public static final Integer CHANNEL_ID_LEN = 5;
	
	public static final Integer STORE_ID_LEN = 5;
	
	public static final Integer ORDER_STATUS_ID_LEN = 5;
	
	public static final Integer TYPE_LEN = 2;
	
	public static final Integer MEMBER_CARD_ID_LEN = 13;
	
	public static final Integer DETL_SEQ_ID_LEN = 5;
	
	public static final Integer SKU_NO_LEN = 9;
	
	public static final Integer NSKU_FLAG_LEN = 1;
	
	public static final Integer NSKU_DETL_SEQ_ID_LEN = 5;
	
	public static final Integer SUB_DEPT_ID_LEN = 3;
	
	public static final Integer CLASS_ID_LEN = 3;
	
	public static final Integer SUB_CLASS_ID_LEN = 3;
	
	public static final Integer TAX_TYPE_LEN = 1;
	
	public static final Integer SKU_NAME_LEN = 50;
	
	public static final Integer POS_SEQ_NO_LEN = 4;
	
	/**錯誤訊息**/
	private StringBuffer errMsg = new StringBuffer();

	/**行數**/
	private Integer idx;

	public boolean isOrderIdOverLen() {
		return getOrderId().length() > ORDER_ID_LEN;
	}  

	public boolean isChannelIdOverLen() {
		return getChannelId().length() > CHANNEL_ID_LEN;
	} 
	
	public boolean isStoreIdOverLen() {
		return getStoreId().length() > STORE_ID_LEN;
	} 
	
	public boolean isOrderStatusIdOverLen() {
		return getOrderStatusId().length() > ORDER_STATUS_ID_LEN;
	} 
	
	public boolean isTypeOverLen() {
		return getType().length() > TYPE_LEN;
	} 
	
	public boolean isMemberCardIdOverLen() {
		return getMemberCardId().length() > MEMBER_CARD_ID_LEN;
	} 
	
	public boolean isDetlSeqIdOverLen() {
		return getDetlSeqId().length() > DETL_SEQ_ID_LEN;
	} 
	
	public boolean isSKuNoOverLen() {
		return getSkuNo().length() > SKU_NO_LEN;
	} 
	
	public boolean isNskuFlagOverLen() {
		return getNskuFlag().length() > NSKU_FLAG_LEN;
	} 
	
	public boolean isNskuDetlSeqIdOverLen() {
		return getNskuDetlSeqId().length() > NSKU_DETL_SEQ_ID_LEN;
	} 
	
	public boolean isSubDeptIdOverLen() {
		return getSubDeptId().length() > SUB_DEPT_ID_LEN;
	} 
	
	public boolean isClassIdOverLen() {
		return getClassId().length() > CLASS_ID_LEN;
	} 
	
	public boolean isSubClassIdOverLen() {
		return getSubClassId().length() > SUB_CLASS_ID_LEN;
	} 
	
	public boolean isTaxTypeOverLen() {
		return getTaxType().length() > TAX_TYPE_LEN;
	} 
	
	public boolean isSkuNameOverLen() {
		return getSkuName().length() > SKU_NAME_LEN;
	} 
	
	public boolean isPosSeqNoOverLen() {
		return getPosSeqNo().length() > POS_SEQ_NO_LEN;
	} 
	
	public void check() { 
		if(isOrderIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "order_id", ORDER_ID_LEN));
		}
		
		if(isChannelIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "channel_id", CHANNEL_ID_LEN));
		}
		
		if(isStoreIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "store_id", STORE_ID_LEN));
		}

		if(isOrderStatusIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "order_status_id", ORDER_STATUS_ID_LEN));
		} 

		if(isTypeOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "type", TYPE_LEN));
		}

		if(isMemberCardIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "member_card_id", MEMBER_CARD_ID_LEN));
		} 

		if(isDetlSeqIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "detl_seq_id", DETL_SEQ_ID_LEN));
		} 
		
		if(isSKuNoOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "sku_no", SKU_NO_LEN));
		} 
		
		if(isNskuFlagOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "nsku_flag", NSKU_FLAG_LEN));
		} 

		if(isNskuDetlSeqIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "nsku_detl_seq_id", NSKU_DETL_SEQ_ID_LEN));
		} 
		
		if(isSubDeptIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "sub_dept_id", SUB_DEPT_ID_LEN));
		} 
		
		if(isClassIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "class_id", CLASS_ID_LEN));
		}

		if(isSubClassIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "sub_class_Id", SUB_CLASS_ID_LEN));
		}

		if(isTaxTypeOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "tax_type", TAX_TYPE_LEN));
		}

		if(isSkuNameOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "sku_name", SKU_NAME_LEN));
		}
		
		if(isPosSeqNoOverLen()){
			errMsg.append(String.format(OVERLEN_WORD, "pos_seq_no",POS_SEQ_NO_LEN));
		}
	}

	public void recordCntError() {
		errMsg.append(RECORDLEN_WORD);
	}

	public StringBuffer getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(StringBuffer errMsg) {
		this.errMsg = errMsg;
	}

	public Integer getIdx() {
		return idx;
	}

	public void setIdx(Integer idx) {
		this.idx = idx;
	}
	
	public boolean hasError() {
		return errMsg.length() != 0;
	}
}
