package com.gccs.bc.model;
public class BcSomPaymentReq extends BcSomPaymentTxt{ 
	public static final String OVERLEN_WORD = "%s長度不得超過%d, ";
	public static final String RECORDLEN_WORD = "資料長度不正確";

	public static final Integer ORDER_ID_LEN = 10;

	public static final Integer CHANNEL_ID_LEN = 5;
	
	public static final Integer STORE_ID_LEN = 5;
	
	public static final Integer MEMBER_CARD_ID_LEN = 13;
	
	public static final Integer GUI_NO_LEN = 30;
	
	public static final Integer REFUND_ID_LEN = 20;
	
	public static final Integer TYPE_LEN = 5;
	
	public static final Integer STATUS_LEN = 2;
	
	public static final Integer POS_NO_LEN = 3;
	
	public static final Integer POS_SEQ_NO_LEN = 4;
	
	/**錯誤訊息**/
	private StringBuffer errMsg = new StringBuffer();

	/**行數**/
	private Integer idx; 

	public boolean isOrderIdOverLen() {
		return getOrderId().length() > ORDER_ID_LEN;
	}  

	public boolean isChannelIdOverLen() {
		return getChannelId().length() > CHANNEL_ID_LEN;
	} 
	
	public boolean isStoreIdOverLen() {
		return getStoreId().length() > STORE_ID_LEN;
	} 
	
	public boolean isMemberCardIdOverLen() {
		return getMemberCardId().length() > MEMBER_CARD_ID_LEN;
	} 
	
	public boolean isGuiNoOverLen() {
		return getGuiNo().length() > GUI_NO_LEN;
	} 
	
	public boolean isRefundIdOverLen() {
		return getRefundId().length() > REFUND_ID_LEN;
	} 
	
	public boolean isTypeOverLen() {
		return getType().length() > TYPE_LEN;
	} 

	public boolean isStatusOverLen() {
		return getStatus().length() > STATUS_LEN;
	} 
	
	public boolean isPosNoOverLen() {
		return getPosNo().length() > POS_NO_LEN;
	} 
	
	public boolean isPosSeqNoOverLen() {
		return getPosSeqNo().length() > POS_SEQ_NO_LEN;
	} 

	public void check() { 
		if(isOrderIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "order_id", ORDER_ID_LEN));
		}
		if(isChannelIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "channel_id", CHANNEL_ID_LEN));
		}
		if(isStoreIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "store_id", STORE_ID_LEN));
		}
		if(isMemberCardIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "member_card_id", MEMBER_CARD_ID_LEN));
		}
		if(isGuiNoOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "gui_no", GUI_NO_LEN));
		}
		if(isRefundIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "refund_id", REFUND_ID_LEN));
		}
		if(isTypeOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "type", TYPE_LEN));
		}
		if(isStatusOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "status", STATUS_LEN));
		}
		if(isPosNoOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "pos_no", POS_NO_LEN));
		}
		if(isPosSeqNoOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "pos_seq_no", POS_SEQ_NO_LEN));
		}
	}
	
	public void recordCntError() {
		errMsg.append(RECORDLEN_WORD);
	}

	public StringBuffer getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(StringBuffer errMsg) {
		this.errMsg = errMsg;
	}

	public Integer getIdx() {
		return idx;
	}

	public void setIdx(Integer idx) {
		this.idx = idx;
	}
	
	public boolean hasError() {
		return errMsg.length() != 0;
	}
}
