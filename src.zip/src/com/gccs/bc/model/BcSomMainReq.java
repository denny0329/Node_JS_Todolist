package com.gccs.bc.model;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class BcSomMainReq {
	public static final String STATUS_SUCC = "SUCCESS";
	public static final String STATUS_FAIL = "<span style='color:red'>Fail</span>";
	  
	public static final Integer TYPE_MASTER = 1;
	
	public static final Integer TYPE_ORDERDETL = 2;
	
	public static final Integer TYPE_PAYMENT = 3;
	
	private String fileName;
	//當天日期
	private String date;
	//檔案筆數
	private Integer count;
	//起始時間
	private String startDate;
	//結束時間
	private String endDate;
	//CRM筆數
	private Integer crmCount;
	
	private Integer type;
	
	private List<BcSomMasterReq> masterReqList = new LinkedList<BcSomMasterReq>();

	private List<BcSomOrderDetlReq> orderDetlReqList = new LinkedList<BcSomOrderDetlReq>();

	private List<BcSomPaymentReq> paymentReqList = new LinkedList<BcSomPaymentReq>();
	
	private List<String> errorMsg = new ArrayList<String>();
	
	private boolean checkDataError;
	
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	} 
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getStatus() {
		if(count.equals(crmCount))
			return STATUS_SUCC;
		
		return STATUS_FAIL;
	}
	public boolean isStatusSuccess() {
		if(count.equals(crmCount))
			return true;
		return false;
	}
	
	public Integer getCrmCount() {
		return crmCount;
	}
	public void setCrmCount(Integer crmCount) {
		this.crmCount = crmCount;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public boolean hasError() {
		if(masterReqList.size() == 0 && 
				orderDetlReqList.size() == 0 &&
				paymentReqList.size() == 0) {
			return true;
		}
		
		for(BcSomMasterReq req : masterReqList) {
			if(req.hasError()) {
				return true;
			}
		}
		
		for(BcSomOrderDetlReq req : orderDetlReqList) {
			if(req.hasError()) {
				return true;
			}
		}
		
		for(BcSomPaymentReq req : paymentReqList) {
			if(req.hasError()) {
				return true;
			}
		}
		if(!errorMsg.isEmpty()){
			return true;
		}
		
		return false;
	}
	public List<BcSomMasterReq> getMasterReqList() {
		return masterReqList;
	}
	
	public void setMasterReqList(List<BcSomMasterReq> masterReqList) {
		this.masterReqList = masterReqList;
	}
	
	public List<BcSomOrderDetlReq> getOrderDetlReqList() {
		return orderDetlReqList;
	}
	
	public void setOrderDetlReqList(List<BcSomOrderDetlReq> orderDetlReqList) {
		this.orderDetlReqList = orderDetlReqList;
	}
	
	public List<BcSomPaymentReq> getPaymentReqList() {
		return paymentReqList;
	}
	
	public void setPaymentReqList(List<BcSomPaymentReq> paymentReqList) {
		this.paymentReqList = paymentReqList;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public List<String> getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(List<String> errorMsg) {
		this.errorMsg = errorMsg;
	}
	public boolean isCheckDataError() {
		return checkDataError;
	}
	public void setCheckDataError(boolean checkDataError) {
		this.checkDataError = checkDataError;
	}
	
}
