package com.gccs.bc.model;

import java.io.Serializable;
import java.util.Date;

public class BcDisbonusLog implements Serializable {
	private static final long serialVersionUID = -7136377902113503039L;

	private String oid;
	private String memberOid;
	private String vipNo;
	private Date transDate;
	private String channelId;
	private String storeNo;
	private Integer bonusTotal;
	private Boolean nonSaleData = Boolean.FALSE;
	private Date createTime;
	private String creator;
	private String creatorName;
	private Date modifyTime;
	private String modifier;
	private String modifierName;
	public String getOid() {
		return oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getMemberOid() {
		return memberOid;
	}
	public void setMemberOid(String memberOid) {
		this.memberOid = memberOid;
	}
	public Date getTransDate() {
		return transDate;
	}
	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getStoreNo() {
		return storeNo;
	}
	public void setStoreNo(String storeNo) {
		this.storeNo = storeNo;
	}
	public Integer getBonusTotal() {
		return bonusTotal;
	}
	public void setBonusTotal(Integer bonusTotal) {
		this.bonusTotal = bonusTotal;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getCreatorName() {
		return creatorName;
	}
	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}
	public String getModifier() {
		return modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public String getModifierName() {
		return modifierName;
	}
	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public String getVipNo() {
		return vipNo;
	}
	public void setVipNo(String vipNo) {
		this.vipNo = vipNo;
	}
	public Boolean getNonSaleData() {
		return nonSaleData;
	}
	public void setNonSaleData(Boolean nonSaleData) {
		this.nonSaleData = nonSaleData;
	}
	
}
