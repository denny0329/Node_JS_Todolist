package com.gccs.bc.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class MmAccCulmMst implements Serializable {

	private static final long serialVersionUID = -6075103289506596396L;
	
	private String oid;
	private String accountId;
	private Long salesAmt;
	private String discCardOid;
	private Date discStartDate;
	private Date discEndDate;
	private Long nextThresholdAmt;
	private Date chgDate;
	private String bfDiscCardOid;
	private Date bfDiscStartDate;
	private Date bfDiscEndDate;
	private String companyId;
	private String creator;
	private Date createTime;
	private String modifier;
	private Date modifyTime;
	private Long nowThresholdAmt;
	private BigDecimal bfSaleAmt;
	
	public String getOid() {
		return oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public Long getSalesAmt() {
		return salesAmt;
	}
	public void setSalesAmt(Long salesAmt) {
		this.salesAmt = salesAmt;
	}
	public String getDiscCardOid() {
		return discCardOid;
	}
	public void setDiscCardOid(String discCardOid) {
		this.discCardOid = discCardOid;
	}
	public Date getDiscStartDate() {
		return discStartDate;
	}
	public void setDiscStartDate(Date discStartDate) {
		this.discStartDate = discStartDate;
	}
	public Date getDiscEndDate() {
		return discEndDate;
	}
	public void setDiscEndDate(Date discEndDate) {
		this.discEndDate = discEndDate;
	}
	public Long getNextThresholdAmt() {
		return nextThresholdAmt;
	}
	public void setNextThresholdAmt(Long nextThresholdAmt) {
		this.nextThresholdAmt = nextThresholdAmt;
	}
	public Date getChgDate() {
		return chgDate;
	}
	public void setChgDate(Date chgDate) {
		this.chgDate = chgDate;
	}
	public String getBfDiscCardOid() {
		return bfDiscCardOid;
	}
	public void setBfDiscCardOid(String bfDiscCardOid) {
		this.bfDiscCardOid = bfDiscCardOid;
	}
	public Date getBfDiscStartDate() {
		return bfDiscStartDate;
	}
	public void setBfDiscStartDate(Date bfDiscStartDate) {
		this.bfDiscStartDate = bfDiscStartDate;
	}
	public Date getBfDiscEndDate() {
		return bfDiscEndDate;
	}
	public void setBfDiscEndDate(Date bfDiscEndDate) {
		this.bfDiscEndDate = bfDiscEndDate;
	}
	public String getCompanyId() {
		return companyId;
	}
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getModifier() {
		return modifier;
	}
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}
	public Date getModifyTime() {
		return modifyTime;
	}
	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	public Long getNowThresholdAmt() {
		return nowThresholdAmt;
	}
	public void setNowThresholdAmt(Long nowThresholdAmt) {
		this.nowThresholdAmt = nowThresholdAmt;
	}
	public BigDecimal getBfSaleAmt() {
		return bfSaleAmt;
	}
	public void setBfSaleAmt(BigDecimal bfSaleAmt) {
		this.bfSaleAmt = bfSaleAmt;
	}
	
}
