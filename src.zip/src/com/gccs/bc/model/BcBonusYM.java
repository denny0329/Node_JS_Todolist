package com.gccs.bc.model;

import java.io.Serializable;

public class BcBonusYM implements Serializable , Cloneable {		
	private static final long serialVersionUID = -8198500377886405515L;

	private String oid;
	private String bonusYM;
	private Integer bonusAdd;
	private Integer bonusMins;
	private String storeNo;
	private Integer bonusTotal;
	
	public String getOid() {
		return oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getBonusYM() {
		return bonusYM;
	}
	public void setBonusYM(String bonusYM) {
		this.bonusYM = bonusYM;
	}
	public String getStoreNo() {
		return storeNo;
	}
	public void setStoreNo(String storeNo) {
		this.storeNo = storeNo;
	}
	public Integer getBonusAdd() {
		return bonusAdd;
	}
	public void setBonusAdd(Integer bonusAdd) {
		this.bonusAdd = bonusAdd;
	}
	public Integer getBonusMins() {
		return bonusMins;
	}
	public void setBonusMins(Integer bonusMins) {
		this.bonusMins = bonusMins;
	}
	public void setBonusTotal(Integer bonusTotal) {
		this.bonusTotal = bonusTotal;
	}
	public Integer getBonusTotal() {
		return bonusTotal;
	}
	
}