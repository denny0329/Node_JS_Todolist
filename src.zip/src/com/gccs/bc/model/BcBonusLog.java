package com.gccs.bc.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.gccs.bs.model.BsStore;
import com.gccs.util.cache.BsStoreDefinition;

@XmlRootElement
public class BcBonusLog implements Serializable, Cloneable {
	private static final long serialVersionUID = 170661933712023794L;

	public static final String MARKET_ID = "BSC201007053";
	public static final String REASON = "紅利點數補扣點機制";

	private String oid;

	private String channelId;
	private String storeId;
	private Date transDate;
	private String posNos;
	private String serNos;
	private String guiNo;
	private String memberOid;
	private Long memberId;
	private String soNos;
	private String accountId;
	private String vipNo;
	private String marketId;
	private Integer marketIdSeq;
	private String reason;
	private Integer bonusAdd;
	private Integer bonusMins;
	private Integer bonusTotal;
	private Integer bonusType;
	private String sourceOid;
	private Integer amount;

	private Date createTime;
	private String creator;
	private String creatorName;
	private String modifier;
	private String modifierName;
	private Date modifyTime;
	private String companyId;
	private String somDetlOid;

	/** 排序流水號-RTC3850 */
	private String serialNum;

	/** 折抵金額 */
	private Double discAmt;

	private String saleType;
	private String saleStatus;

	private Date recountDate;
	private Date cancelDate;

	// for debug
	public String toString() {
		return ToStringBuilder.reflectionToString(this,
				ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getOid() {
		return oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public String getChannelId() {
		if (channelId == null) {
			if (this.getStoreId() != null && !this.getStoreId().equals("")) {
				if (this.getCompanyId() != null && !this.getCompanyId().equals("")) {
					BsStore bsStore = BsStoreDefinition.getBsStoreByStoreNo(this.getStoreId(), this.getCompanyId());
					channelId = bsStore.getId().getChannelId();
				} else {
					BsStore bsStore = BsStoreDefinition.getBsStoreByStoreNo(this.getStoreId(), "1010");
					channelId = bsStore.getId().getChannelId();
				}
			}
		}
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public Date getTransDate() {
		return transDate;
	}

	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}

	public String getGuiNo() {
		return guiNo;
	}

	public void setGuiNo(String guiNo) {
		this.guiNo = guiNo;
	}

	public String getMemberOid() {
		return memberOid;
	}

	public void setMemberOid(String memberOid) {
		this.memberOid = memberOid;
	}

	public Long getMemberId() {
		return memberId;
	}

	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}

	public String getVipNo() {
		return vipNo;
	}

	public void setVipNo(String vipNo) {
		this.vipNo = vipNo;
	}

	public String getMarketId() {
		return marketId;
	}

	public void setMarketId(String marketId) {
		this.marketId = marketId;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Integer getBonusAdd() {
		return bonusAdd;
	}

	public void setBonusAdd(Integer bonusAdd) {
		this.bonusAdd = bonusAdd;
	}

	public Integer getBonusMins() {
		return bonusMins;
	}

	public void setBonusMins(Integer bonusMins) {
		this.bonusMins = bonusMins;
	}

	public Integer getBonusTotal() {
		return bonusTotal;
	}

	public void setBonusTotal(Integer bonusTotal) {
		this.bonusTotal = bonusTotal;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getModifierName() {
		return modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public String getSoNos() {
		return soNos;
	}

	public void setSoNos(String soNos) {
		this.soNos = soNos;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public Integer getMarketIdSeq() {
		return marketIdSeq;
	}

	public void setMarketIdSeq(Integer marketIdSeq) {
		this.marketIdSeq = marketIdSeq;
	}

	public Integer getBonusType() {
		return bonusType;
	}

	public void setBonusType(Integer bonusType) {
		this.bonusType = bonusType;
	}

	public String getSourceOid() {
		return sourceOid;
	}

	public void setSourceOid(String sourceOid) {
		this.sourceOid = sourceOid;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	public String getPosNos() {
		return posNos;
	}

	public void setPosNos(String posNos) {
		this.posNos = posNos;
	}

	public String getSerNos() {
		return serNos;
	}

	public void setSerNos(String serNos) {
		this.serNos = serNos;
	}

	public BcBonusLog copy() throws CloneNotSupportedException {
		return (BcBonusLog) this.clone();
	}

	/**
	 * 取回排序流水號
	 * 
	 * @return
	 */
	public String getSerialNum() {
		return serialNum;
	}

	/**
	 * 指定排序流水號
	 * 
	 * @param serialNum
	 */
	public void setSerialNum(String serialNum) {
		this.serialNum = serialNum;
	}

	/**
	 * 取回折抵金額
	 * 
	 * @return
	 */
	public Double getDiscAmt() {
		return discAmt;
	}

	/**
	 * 指定折抵金額
	 * 
	 * @param discAmt
	 */
	public void setDiscAmt(Double discAmt) {
		this.discAmt = discAmt;
	}

	public String getSaleType() {
		return saleType;
	}

	public void setSaleType(String saleType) {
		this.saleType = saleType;
	}

	public String getSaleStatus() {
		return saleStatus;
	}

	public void setSaleStatus(String saleStatus) {
		this.saleStatus = saleStatus;
	}

	public Date getRecountDate() {
		return recountDate;
	}

	public void setRecountDate(Date recountDate) {
		this.recountDate = recountDate;
	}

	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	public void setSomDetlOid(String somDetlOid) {
		this.somDetlOid = somDetlOid;
	}

	public String getSomDetlOid() {
		return somDetlOid;
	}
	
	public Date getCancelDate() {
		return cancelDate;
	}

	public void setCancelDate(Date cancelDate) {
		this.cancelDate = cancelDate;
	}

	public BcBonusLog() {
	};

	public BcBonusLog(Map map, Integer type, String reason, Integer bonustol) {
		this.channelId = (String) map.get("CHANNEL_ID");
		this.transDate = (Date) map.get("TRANS_DATE");
		this.storeId = (String) map.get("STORE_ID");
		this.posNos = (String) map.get("POS_NOS");
		this.serNos = (String) map.get("SER_NOS");
		this.guiNo = (String) map.get("GUI_NOS");
		this.marketId = (String) map.get("PROMOT_ID");
		this.vipNo = (String) map.get("CUST_NOS");
		this.bonusAdd = ((BigDecimal) map.get("BONUS_ADD")).intValue();
		this.bonusTotal = bonustol;
		this.reason = reason;
		this.serialNum = (String) map.get("SERIAL_NUM");
		this.companyId = (String) map.get("COMPANY_ID");
		this.bonusType = type;
		this.recountDate = (Date) map.get("REP_DATE");
		this.createTime = new Date();
		this.creator = "SYS_BATCH";
		this.creatorName = "SYS_BATCH";
		this.modifyTime = new Date();
		this.modifier = "SYS_BATCH";
		this.modifierName = "SYS_BATCH";

	}
}
