package com.gccs.bc.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class BcMarket implements Serializable {
	private static final long serialVersionUID = -7953971339763896543L;

	public BcMarket() {
		
	}
	  
	private BigDecimal ROWNUM_;
	private String ID,NAME;
//	private Character f4;
//	private BigDecimal f5,f6,f7,f8,f9,f10,f11,f12,f13,f14,f15,f16,f17,f18,f19,f20,f21,f22,PROMOTION,POG_FLAG;

	public BigDecimal getROWNUM_() {
		return ROWNUM_;
	}


	public void setROWNUM_(BigDecimal rOWNUM_) {
		ROWNUM_ = rOWNUM_;
	}
	
	
	public String getID() {
		return ID;
	}


	public void setID(String iD) {
		ID = iD;
	}


	public String getNAME() {
		return NAME;
	}


	public void setNAME(String nAME) {
		NAME = nAME;
	}
	
}