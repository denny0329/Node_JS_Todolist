package com.gccs.bc.model;
 
public class BcSomMasterReq extends BcSomMasterTxt{   
	public static final String OVERLEN_WORD = "%s長度不得超過%d, ";
	public static final String RECORDLEN_WORD = "資料長度不正確";
	 
	public static final Integer ORDER_ID_LEN = 10;
	 
	public static final Integer CHANNEL_ID_LEN = 5;
	 
	public static final Integer STORE_ID_LEN = 5;
	 
	public static final Integer ORDER_STATUS_ID_LEN = 5;
	 
	public static final Integer MEMBER_CARD_ID_LEN = 13;

	/**錯誤訊息**/
	private StringBuffer errMsg = new StringBuffer();

	/**行數**/
	private Integer idx;
	
	public boolean isOrderIdOverLen() {
		return getOrderId().length() > ORDER_ID_LEN;
	}  

	public boolean isChannelIdOverLen() {
		return getChannelId().length() > CHANNEL_ID_LEN;
	} 
	
	public boolean isStoreIdOverLen() {
		return getStoreId().length() > STORE_ID_LEN;
	} 
	
	public boolean isOrderStatusIdOverLen() {
		return getOrderStatusId().length() > ORDER_STATUS_ID_LEN;
	} 
	
	public boolean isMemberCardIdOverLen() {
		return getMemberCardId().length() > MEMBER_CARD_ID_LEN;
	} 

	public void recordCntError() {
		errMsg.append(RECORDLEN_WORD);
	}

	public void check() { 
		if(isOrderIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "order_id", ORDER_ID_LEN));
		}
		if(isChannelIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "channel_id", CHANNEL_ID_LEN));
		}
		if(isStoreIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "store_id", STORE_ID_LEN));
		}
		if(isOrderStatusIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "order_status_id", ORDER_STATUS_ID_LEN));
		}
		if(isMemberCardIdOverLen()) {
			errMsg.append(String.format(OVERLEN_WORD, "member_card_id", MEMBER_CARD_ID_LEN));
		}
	}

	public StringBuffer getErrMsg() {
		return errMsg;
	}

	public void setErrMsg(StringBuffer errMsg) {
		this.errMsg = errMsg;
	}

	public Integer getIdx() {
		return idx;
	}

	public void setIdx(Integer idx) {
		this.idx = idx;
	}

	public boolean hasError() {
		return errMsg.length() != 0;
	}
}
