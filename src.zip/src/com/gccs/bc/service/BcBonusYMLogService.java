
package com.gccs.bc.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.transaction.support.TransactionTemplate;

import com.gccs.bc.dao.hibernate.BcBonusYMDao;
import com.gccs.bc.model.BcBonusYM;

/**
 * @author Jack
 *
 */
public class BcBonusYMLogService {

	private static final Logger log = LogManager.getLogger(BcBonusYMLogService.class) ;
	private BcBonusYMDao dao ;
	private TransactionTemplate transactionTemplate ;

	public TransactionTemplate getTransactionTemplate() {
		return transactionTemplate;
	}
	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}
	public BcBonusYMDao getDao() {
		return dao;
	}
	public void setDao(BcBonusYMDao dao) {
		this.dao = dao;
	}

	public List<BcBonusYM> getBonusQTY(String YM) throws Exception{
		
		List<BcBonusYM> temp = dao.findBonusQTYByYM(YM);	
		return temp;
	}
	
	public void getMonthlyBonus(String YM) throws Exception{
			String month = YM.substring(4);
			String monthNew ="";
			Integer year1 = Integer.parseInt(YM.substring(0, 4));
			Integer year2 = Integer.parseInt(YM.substring(0, 4));
			
			Integer ThisMonth = Integer.parseInt(month);
			Integer LastMonth = ThisMonth-1;//
		
			Integer LastLastMonth = ThisMonth-2;
			if(ThisMonth.intValue()==1){
				LastMonth=12;
				LastLastMonth=11;
				year1=year1-1;
			}
			if(ThisMonth.intValue()==2){
				LastLastMonth=12;
				year2=year2-1;
			}
			monthNew = LastMonth.toString();
			if(LastMonth.intValue()<10){
				monthNew="0".concat(monthNew);
			}
			String lastlastM = LastLastMonth.toString();
			String lastlastMString = (year1.toString()).concat(lastlastM);
			List<BcBonusYM> lastlastMonthResultList = this.getBonusQTY(lastlastMString);
			String StringFrom = YM.substring(0, 4)+"/"+monthNew+"/"+"01";  
			String StringTo = (year1.toString())+"/"+month+"/"+"01"; 
			//Integer resultBonus = dao.findLastMonthTotal(StringFrom,StringTo)+QTY;
			List resultList = dao.findLastMonthTotal(StringFrom,StringTo);
			Iterator iterator = resultList.iterator();
			List<BcBonusYM> returnList = new ArrayList();
	        while(iterator.hasNext()) { 
	        	Object[] ObjectArray=(Object[]) iterator.next();
	        		String pa1= (java.lang.String) ObjectArray[0];
	        		BigDecimal pa2 =(BigDecimal) ObjectArray[1];
	        		BigDecimal pa3 =(BigDecimal) ObjectArray[2];
	        		//System.out.println("[par1:"+pa1+" par2:"+pa2+pa3+" par3:"+pa3+"]");
	        		if(lastlastMonthResultList!=null){
		        		for(BcBonusYM b:lastlastMonthResultList){
		        			if(b.getStoreNo().compareTo(pa1)==0){
		        				BcBonusYM vo = new BcBonusYM();
		        				vo.setBonusAdd(pa2.intValue());
		        				vo.setBonusMins(pa3.intValue());
		        				vo.setBonusTotal(b.getBonusTotal().intValue()+pa2.intValue()-pa3.intValue());
		        				vo.setStoreNo(b.getStoreNo());
		        				vo.setBonusYM(b.getBonusYM());
		        				returnList.add(vo);
		        			}
		        		}
	        		}else{
             			BcBonusYM vo = new BcBonusYM();
        				vo.setBonusAdd(pa2.intValue());
        				vo.setBonusMins(pa3.intValue());
        				vo.setStoreNo(pa1);
        				vo.setBonusYM(YM);
        				vo.setBonusTotal(pa2.intValue()-pa3.intValue());
        				returnList.add(vo);
        			}
	        	
	        	
	        }
	        List<BcBonusYM> delList=this.getBonusQTY(YM);
	        if (delList!=null){
	        	dao.delBcBonusAmtList(delList);
	        }
	        for(BcBonusYM b:returnList){
	        	//System.out.println(b.getStoreNo());
	        	saveBcBonusAmt(b);
	        }
	}

	public void saveBcBonusAmt(BcBonusYM amt) throws Exception{
		dao.saveBcBonusAmt(amt); 
	}
}
