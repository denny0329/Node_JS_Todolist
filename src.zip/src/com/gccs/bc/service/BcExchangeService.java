
package com.gccs.bc.service;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.apeo.sender.model.MessageContent;
import com.bnq.bs.model.BsArea;
import com.bnq.util.DateTimeUtils;
import com.bnq.util.QueryResult;
import com.bnq.util.mail.MailService;
import com.bnq.util.serial.SerialService;
import com.gccs.bc.dao.hibernate.BcExchangeDao;
import com.gccs.bc.model.BcBonusSettingDtl;
import com.gccs.bc.model.BcBonusSettingMst;
import com.gccs.bc.model.BcExchangeStore;
import com.gccs.bc.setting.vo.BcBonusSettingVo;
import com.gccs.bc.vo.BcStoreVo;
import com.gccs.bc.vo.BsChannelVo;
import com.gccs.bc.vo.BsStoreVo;
import com.gccs.bs.model.BsChannel;
import com.gccs.bs.model.BsCompany;
import com.gccs.bs.model.BsStore;
import com.gccs.bs.service.IBsChannelAuthorityService;
import com.gccs.marketing.action.DiscountSkuParamUtil;
import com.gccs.marketing.dao.hibernate.MarketingDao;
import com.gccs.marketing.model.DiscountSku;
import com.gccs.marketing.model.vo.DiscountSkuVo;
import com.gccs.marketing.model.vo.VoUtil;
import com.gccs.util.cache.BsCompanyDefinition;
import com.gccs.ws.service.BaseWebService;
import com.opensymphony.xwork2.ActionContext;
import com.rfep.util.sys.service.CassetteJobTimeAndMailNotifyService;

/**
 * @author JL
 *
 */
public class BcExchangeService {
	
	private static final Logger log = LogManager.getLogger(BcExchangeService.class) ;
	
	public static final String STATUS_CODE_0 = "0";//建立
	public static final String STATUS_CODE_1 = "1";//生效
	public static final String STATUS_CODE_2 = "2";//失效
	public static final String STATUS_CODE_3 = "3";//取消
	public static final String STATUS_CODE_4 = "4";//審核
	public static final String STATUS_CODE_5 = "5";//退回		
	
	public static final String TYPE_CODE_0 = "0";//POS-兌換商品設定
	public static final String TYPE_CODE_1 = "1";//Service
	public static final String TYPE_CODE_2 = "2";//折現設定
	public static final String TYPE_CODE_8 = "8";//紅利點數優惠商品
	public static final String TYPE_CODE_10 = "10";//
	
	
	public static final String SPLIT_SEQU_1 = ",";
	public static final String SPLIT_SEQU = "▲";
	
	private BcExchangeDao dao ;
	private MarketingDao mtDao ;
	private IBsChannelAuthorityService channelService ;

	public MarketingDao getMtDao() {
		return mtDao;
	}
	public void setMtDao(MarketingDao mtDao) {
		this.mtDao = mtDao;
	}

	private TransactionTemplate transactionTemplate ;
	
	public TransactionTemplate getTransactionTemplate() {
		return transactionTemplate;
	}
	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}
	public BcExchangeDao getDao() {
		return dao;
	}
	public void setDao(BcExchangeDao dao) {
		this.dao = dao;
	}
	public IBsChannelAuthorityService getChannelService() {
		return channelService;
	}
	public void setChannelService(IBsChannelAuthorityService channelService) {
		this.channelService = channelService;
	}
	/**
	 * query BC_BONUS_SETTING_MST
	 * @param vo : 欲查詢之條件
	 * @param index : 起始筆數
	 * @param rows : 總筆數
	 * @param countTotal : true:查詢總筆數,false:查詢詳細資料
	 * @return QueryResult : 查詢結果
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public QueryResult getQueryList(BcBonusSettingVo vo,int index,int rows,boolean countTotal,boolean lazy) throws Exception {
		QueryResult result = new QueryResult() ;
		if(countTotal) {
			List temp = getDao().findBcExchange(vo, index, rows, true,false);
			result.setCount((Integer)temp.get(0));
		}
		List<BcBonusSettingMst> queryResult = getDao().findBcExchange(vo, index, rows, false,lazy);	
		if(queryResult == null || queryResult.size() == 0){
			result.setResult(new ArrayList());
		}else{
			result.setResult(queryResult) ;
		}		
		return result ;
	}

	/**
	 *  saveOrUpdate BC_BONUS_SETTING_MST
	 * @param vo
	 * @param bcExchangeCashList
	 * @param bcExchangeDeskList
	 * @param bcExchangeSkuList
	 * @param executeCode 		
	 * @param actionSubmitType 	{0:pos,1:sevice}
	 * @param bcStoreVoList
	 * @param storeId
	 * @param userId
	 * @param userName
	 * @return
	 * @throws Exception
	 */
	public BcBonusSettingMst saveOrUpdateBcExchange(BcBonusSettingMst vo,List<BcBonusSettingDtl> bcExchangeCashList,
			List<BcBonusSettingDtl> bcExchangeDeskList,List<BcBonusSettingDtl> bcExchangeSkuList,String executeCode,
			String actionSubmitType,List<BcStoreVo> bcStoreVoList,String[] storeId,String userId,String userName,List<BsChannel> channelIdList) throws Exception {
		Timestamp sysdate = DateTimeUtils.getSysDate();
		final BcBonusSettingMst master;
		//BcExchangeCash
		final Collection<Object> delCashList = new ArrayList<Object>();
		Set<BcBonusSettingDtl> detailCashSet = new HashSet<BcBonusSettingDtl>();
		ArrayList<String> detailCashOidList = new ArrayList<String>();
		//BcExchangeDesk
		final Collection<Object> delDeskList = new ArrayList<Object>();
		Set<BcBonusSettingDtl> detailDeskSet = new HashSet<BcBonusSettingDtl>();
		ArrayList<String> detailDeskOidList = new ArrayList<String>();
		//BcExchangeSku
		final Collection<Object> delSkuList = new ArrayList<Object>();
		Set<BcBonusSettingDtl> detailSkuSet = new HashSet<BcBonusSettingDtl>();
		ArrayList<String> detailSkuOidList = new ArrayList<String>();
		//BcExchangeStore
		final Collection<Object> delStoreList = new ArrayList<Object>();
		Set<BcExchangeStore> detailStoreSet = new HashSet<BcExchangeStore>();
		ArrayList<String> detailStoreOidList = new ArrayList<String>();
		
		if (StringUtils.isBlank(vo.getOid())){
			master = vo;
			master.setBcExchangeCashs(new HashSet<BcBonusSettingDtl>());
			master.setBcExchangeDesks(new HashSet<BcBonusSettingDtl>());
			master.setBcExchangeSkus(new HashSet<BcBonusSettingDtl>());
			master.setBcExchangeStores(new HashSet<BcExchangeStore>());
			master.setBsType(StringUtils.isNotBlank(actionSubmitType)? Integer.parseInt(actionSubmitType):null);
			master.setCreator(userId);
			master.setCreatorName(userName);
			master.setCreateTime(sysdate);			
		}else{
			//TODO
			master = getBcExchange(vo.getOid(),null,channelIdList);
		}
		log.info(executeCode);
		if (STATUS_CODE_0.equals(executeCode) || STATUS_CODE_4.equals(executeCode)){
			//mster
			BeanUtils.copyProperties(master,vo);
			//detail
			processSaveExchangeCash(master, bcExchangeCashList, delCashList, detailCashSet, detailCashOidList, userId, userName, sysdate);
			processSaveExchangeDesk(master, bcExchangeDeskList, delDeskList, detailDeskSet, detailDeskOidList, userId, userName, sysdate);
			processSaveExchangeSku(master, bcExchangeSkuList, delSkuList, detailSkuSet, detailSkuOidList, userId, userName, sysdate);
			processSaveExchangeStore(master, bcStoreVoList,storeId,delStoreList, detailStoreSet, detailStoreOidList, userId, userName, sysdate);			
		}
		
		master.setStatus((StringUtils.isBlank(executeCode))? Integer.parseInt(STATUS_CODE_0):
			(STATUS_CODE_1.equals(master.getStatus()) && STATUS_CODE_0.equals(executeCode)? 
					Integer.parseInt(STATUS_CODE_1):Integer.parseInt(executeCode)));
		master.setModifyTime(sysdate);	
		master.setModifier(userId);
		master.setModifierName(userName);	
		String companyId = StringUtils.isNotEmpty(BsCompanyDefinition.getCompanyId())?
				BsCompanyDefinition.getCompanyId():"";
		master.setCompanyId(companyId);
		
		try{
			if (STATUS_CODE_2.equals(executeCode)){
				master.setExpDateT(DateTimeUtils.getDate(DateTimeUtils.getFormatDateStr(sysdate)));
			}
		}catch(Throwable t){
			throw new Exception(t);
		}
		
		try {
			transactionTemplate.execute(new TransactionCallback() {
				public Object doInTransaction(TransactionStatus txnStatus) {
					Boolean txnFail = false; 
					try{
						//master
						if (StringUtils.isBlank(master.getOid())){
							//get seq
							master.setPromotId(SerialService.getCategorySerial(SerialService.CATEGORY_BSR, SerialService.DATE_FORMAT_YYYYMM,3));
							getDao().insertObject(master);
						}else{
							getDao().updateObject(master);
						}
						//BcExchangeCash
						for(BcBonusSettingDtl detail:master.getBcExchangeCashs()){
							if (StringUtils.isBlank(detail.getOid())){
								getDao().insertObject(detail);
							}else{
								getDao().updateObject(detail);
							}
						}
						getDao().deleteCollection(delCashList);
						//BcExchangeDesk
						for(BcBonusSettingDtl detail:master.getBcExchangeDesks()){
							detail.setPromotOid(master.getOid());
							if (StringUtils.isBlank(detail.getOid())){
								getDao().insertObject(detail);
							}else{
								getDao().updateObject(detail);
							}
						}
						getDao().deleteCollection(delDeskList);						
						//BcExchangeSku
						for(BcBonusSettingDtl detail:master.getBcExchangeSkus()){
							if (StringUtils.isBlank(detail.getOid())){
								getDao().insertObject(detail);
							}else{
								getDao().updateObject(detail);
							}
						}
						getDao().deleteCollection(delSkuList);							
						//BcExchangeStore
						for(BcExchangeStore detail:master.getBcExchangeStores()){
							if (StringUtils.isBlank(detail.getOid())){
								detail.setRefOid(master.getOid());
								getDao().insertObject(detail);
							}else{
								detail.setRefOid(master.getOid());
								getDao().updateObject(detail);
							}
						}
						for (Iterator iterator = delStoreList.iterator(); iterator
								.hasNext();) {
							BcExchangeStore s = (BcExchangeStore) iterator.next();
							System.out.println("BcExchangeStore deleted : "+s.getChannelId()) ;
						}
						getDao().deleteCollection(delStoreList);							
					} catch(Exception ex) {
						txnFail = true;
						txnStatus.setRollbackOnly();
						throw new RuntimeException(ex);
					}
					return txnFail;
				}
			});
		}catch(Exception e){
			throw e ;
		}
		return getBcExchange(vo.getOid());
	}
	/**
	 * saveOrUpdateBcExchange
	 * @param vo
	 * @param bcExchangeCashList
	 * @param bcExchangeDeskList
	 * @param bcExchangeSkuList
	 * @param executeCode
	 * @param actionSubmitType
	 * @param bcStoreVoList
	 * @param storeId
	 * @param userId
	 * @param userName
	 * @param refOid
	 * @param addDiscountSkuVoList
	 * @param updDiscountSkuVoList
	 * @param delDiscountSkuVoList
	 * @return
	 * @throws Exception
	 */
	public BcBonusSettingMst saveOrUpdateBcExchange(BcBonusSettingMst vo,List<BcBonusSettingDtl> bcExchangeCashList,
			List<BcBonusSettingDtl> bcExchangeDeskList,List<BcBonusSettingDtl> bcExchangeSkuList,String executeCode,
			String actionSubmitType,List<BcStoreVo> bcStoreVoList,String[] storeId,String userId,String userName,
			String refOid,
			List <DiscountSkuVo> addDiscountSkuVoList,
			List<DiscountSkuVo> updDiscountSkuVoList,
			List<DiscountSkuVo> delDiscountSkuVoList) throws Exception {
		Timestamp sysdate = DateTimeUtils.getSysDate(); 
		final BcBonusSettingMst master;
		//BcExchangeCash
		final Collection<Object> delCashList = new ArrayList<Object>();
		Set<BcBonusSettingDtl> detailCashSet = new HashSet<BcBonusSettingDtl>();
		ArrayList<String> detailCashOidList = new ArrayList<String>();
		//BcExchangeDesk
		final Collection<Object> delDeskList = new ArrayList<Object>();
		Set<BcBonusSettingDtl> detailDeskSet = new HashSet<BcBonusSettingDtl>();
		ArrayList<String> detailDeskOidList = new ArrayList<String>();
		//BcExchangeSku
		final Collection<Object> delSkuList = new ArrayList<Object>();
		Set<BcBonusSettingDtl> detailSkuSet = new HashSet<BcBonusSettingDtl>();
		ArrayList<String> detailSkuOidList = new ArrayList<String>();
		//BcExchangeStore
		final Collection<Object> delStoreList = new ArrayList<Object>();
		Set<BcExchangeStore> detailStoreSet = new HashSet<BcExchangeStore>();
		ArrayList<String> detailStoreOidList = new ArrayList<String>();
		
		if (StringUtils.isBlank(vo.getOid())){
			master = vo;
			master.setBcExchangeCashs(new HashSet<BcBonusSettingDtl>());
			master.setBcExchangeDesks(new HashSet<BcBonusSettingDtl>());
			master.setBcExchangeSkus(new HashSet<BcBonusSettingDtl>());
			master.setBcExchangeStores(new HashSet<BcExchangeStore>());
			master.setBsType(StringUtils.isNotBlank(actionSubmitType)? Integer.parseInt(actionSubmitType):null);
			master.setCreator(userId);
			master.setCreatorName(userName);
			master.setCreateTime(sysdate);			
		}else{
			master = getBcExchange(vo.getOid());
		}
		log.info(executeCode);
		if (STATUS_CODE_0.equals(executeCode) || STATUS_CODE_4.equals(executeCode)){
			//mster
			BeanUtils.copyProperties(master,vo);
			//detail
			processSaveExchangeCash(master, bcExchangeCashList, delCashList, detailCashSet, detailCashOidList, userId, userName, sysdate);
			processSaveExchangeDesk(master, bcExchangeDeskList, delDeskList, detailDeskSet, detailDeskOidList, userId, userName, sysdate);
			processSaveExchangeSku(master, bcExchangeSkuList, delSkuList, detailSkuSet, detailSkuOidList, userId, userName, sysdate);
			processSaveExchangeStore(master, bcStoreVoList,storeId,delStoreList, detailStoreSet, detailStoreOidList, userId, userName, sysdate);			
		}
		
		master.setStatus((StringUtils.isBlank(executeCode))? Integer.parseInt(STATUS_CODE_0):
			(STATUS_CODE_1.equals(master.getStatus()) && STATUS_CODE_0.equals(executeCode)? 
					Integer.parseInt(STATUS_CODE_1):Integer.parseInt(executeCode)));
		master.setModifyTime(sysdate);	
		master.setModifier(userId);
		master.setModifierName(userName);
		String companyId = StringUtils.isNotEmpty(BsCompanyDefinition.getCompanyId())?
				BsCompanyDefinition.getCompanyId():"";
		master.setCompanyId(companyId);
		
		try{
			if (STATUS_CODE_2.equals(executeCode)){
				master.setExpDateT(DateTimeUtils.getDate(DateTimeUtils.getFormatDateStr(sysdate)));
			}
		}catch(Throwable t){
			throw new Exception(t);
		}
		
		final List <DiscountSku>addDiscountSkuList  =  VoUtil.convertedSku(addDiscountSkuVoList, userId, userName,refOid);
		final List <DiscountSku>updDiscountSkuList  =  VoUtil.convertedSku(updDiscountSkuVoList, userId, userName,refOid);
		final List <DiscountSku>delDiscountSkuList  =  VoUtil.convertedSku(delDiscountSkuVoList, userId, userName,refOid);
		
		try {
			transactionTemplate.execute(new TransactionCallback() {
				public Object doInTransaction(TransactionStatus txnStatus) {
					Boolean txnFail = false; 
					try{
						//master
						if (StringUtils.isBlank(master.getOid())){
							//get seq
							master.setPromotId(SerialService.getCategorySerial(SerialService.CATEGORY_BSR, SerialService.DATE_FORMAT_YYYYMM,3));
							getDao().insertObject(master);
						}else{
							getDao().updateObject(master);
						}
						//BcExchangeCash
						for(BcBonusSettingDtl detail:master.getBcExchangeCashs()){
							if (StringUtils.isBlank(detail.getOid())){
								getDao().insertObject(detail);
							}else{
								getDao().updateObject(detail);
							}
						}
						getDao().deleteCollection(delCashList);
						//BcExchangeDesk
						for(BcBonusSettingDtl detail:master.getBcExchangeDesks()){
							if (StringUtils.isBlank(detail.getOid())){
								getDao().insertObject(detail);
							}else{
								getDao().updateObject(detail);
							}
						}
						getDao().deleteCollection(delDeskList);						
						//BcExchangeSku
						for(BcBonusSettingDtl detail:master.getBcExchangeSkus()){
							if (StringUtils.isBlank(detail.getOid())){
								getDao().insertObject(detail);
							}else{
								getDao().updateObject(detail);
							}
						}
						getDao().deleteCollection(delSkuList);							
						//BcExchangeStore
						for(BcExchangeStore detail:master.getBcExchangeStores()){
							if (StringUtils.isBlank(detail.getOid())){
								detail.setRefOid(master.getOid());
								getDao().insertObject(detail);
							}else{
								detail.setRefOid(master.getOid());
								getDao().updateObject(detail);
							}
						}
						getDao().deleteCollection(delStoreList);
						
						
						
						DiscountSkuParamUtil.showLog(updDiscountSkuList, addDiscountSkuList);						
						for(DiscountSku sku :updDiscountSkuList){
							log.info("更新 DiscountSku by oid: "+sku.getOid());
							getMtDao().updateDiscountSkus(sku) ;
						}
						log.info("新增 DiscountSku size: "+addDiscountSkuList.size());
						for(DiscountSku sku :addDiscountSkuList){
							if(BaseWebService.isEmpty(sku.getRefOid()))
								sku.setRefOid(master.getOid());
							
							log.info("新增 DiscountSku by oid: "+sku.getOid());
							getMtDao().saveDiscountSku(sku) ;
						}
						log.info("刪除 DiscountSku size: "+delDiscountSkuList.size());
						for(DiscountSku sku :delDiscountSkuList){
							log.info("刪除 DiscountSku by oid: "+sku.getOid());
							getMtDao().delDiscountSku(sku) ;
						}	
						
					} catch(Exception ex) {
						txnFail = true;
						txnStatus.setRollbackOnly();
						throw new RuntimeException(ex);
					}
					return txnFail;
				}
			});
		}catch(Exception e){
			throw e ;
		}
		return getBcExchange(vo.getOid());
	}	
	/**
	 * process BcExchangeCash
	 * @param master
	 * @param bcExchangeCashList
	 * @param delCashList
	 * @param detailCashSet
	 * @param detailCashOidList
	 * @param userId
	 * @param userName
	 * @param sysdate
	 * @throws Exception
	 */
	public void processSaveExchangeCash(BcBonusSettingMst master,List<BcBonusSettingDtl> bcExchangeCashList,Collection<Object> delCashList,
			Set<BcBonusSettingDtl> detailCashSet,ArrayList<String> detailCashOidList,String userId,String userName,Timestamp sysdate)throws Exception{
		BcBonusSettingDtl newVo;
		Integer i=1;
		for(BcBonusSettingDtl ui:bcExchangeCashList){
			if (ui==null){
				continue;
			}
			if (StringUtils.isNotBlank(ui.getOid())){
				detailCashOidList.add(ui.getOid());
				ui.setDetailSeq(i.intValue());
				ui.setBcBonusSettingMst(master);
				ui.setModifier(userId);
				ui.setModifierName(userName);
				ui.setModifyTime(sysdate);
				ui.setDetailSeq(i.intValue());
				detailCashSet.add(ui);
				i++;
			}else{
				newVo = new BcBonusSettingDtl();
				ui.setDetailSeq(i.intValue());
				newVo.setCreator(userId);
				newVo.setCreatorName(userName);
				newVo.setCreateTime(sysdate);
				newVo.setModifier(userId);
				newVo.setModifierName(userName);
				newVo.setModifyTime(sysdate);
				newVo.setExBonus(ui.getExBonus());
				newVo.setExCash(ui.getExCash());
				newVo.setBcBonusSettingMst(master);
				newVo.setDetailSeq(i.intValue());
				detailCashSet.add(newVo);
				i++;
			}
		}
		for(BcBonusSettingDtl detail:master.getBcExchangeCashs()){
			if (StringUtils.isNotBlank(detail.getOid()) &&
					detailCashOidList.indexOf(detail.getOid())<0){
				detail.setBcBonusSettingMst(master);
				delCashList.add(detail);
			}
		}
		master.setBcExchangeCashs(detailCashSet);		
	}
	

	/**
	 * process BcExchangedest
	 * @param master
	 * @param bcExchangeDeskList
	 * @param delDeskList
	 * @param detailDeskhSet
	 * @param detailDeskOidList
	 * @param userId
	 * @param userName
	 * @param sysdate
	 * @throws Exception
	 */
	public void processSaveExchangeDesk(BcBonusSettingMst master,List<BcBonusSettingDtl> bcExchangeDeskList,Collection<Object> delDeskList,
			Set<BcBonusSettingDtl> detailDeskhSet,ArrayList<String> detailDeskOidList,String userId,String userName,Timestamp sysdate)throws Exception{
		BcBonusSettingDtl newVo;
		for(BcBonusSettingDtl ui:bcExchangeDeskList){
			if (ui==null){
				continue;
			}
			if (StringUtils.isNotBlank(ui.getOid())){
				detailDeskOidList.add(ui.getOid());
				ui.setBcBonusSettingMst(master);
				ui.setModifier(userId);
				ui.setModifierName(userName);
				ui.setModifyTime(sysdate);
				detailDeskhSet.add(ui);
			}else{
				newVo = new BcBonusSettingDtl();
				newVo.setCreator(userId);
				newVo.setCreatorName(userName);
				newVo.setCreateTime(sysdate);
				newVo.setModifier(userId);
				newVo.setModifierName(userName);
				newVo.setModifyTime(sysdate);
				newVo.setExBonus(ui.getExBonus());
				newVo.setExSku(ui.getExSku());
				newVo.setBcBonusSettingMst(master);
				newVo.setBonusType(ui.getBonusType());
				newVo.setDiscAmt(ui.getDiscAmt());
				detailDeskhSet.add(newVo);
			}
		}
		for(BcBonusSettingDtl detail:master.getBcExchangeDesks()){
			if (StringUtils.isNotBlank(detail.getOid()) &&
					detailDeskOidList.indexOf(detail.getOid())<0){
				detail.setBcBonusSettingMst(master);
				delDeskList.add(detail);
			}
		}
		master.setBcExchangeDesks(detailDeskhSet);		
	}	
	

	/**
	 *  process BcExchangeSku
	 * @param master
	 * @param bcExchangeSkuList
	 * @param delSkuList
	 * @param detailSkuhSet
	 * @param detailSkuOidList
	 * @param userId
	 * @param userName
	 * @param sysdate
	 * @throws Exception
	 */
	public void processSaveExchangeSku(BcBonusSettingMst master,List<BcBonusSettingDtl> bcExchangeSkuList,Collection<Object> delSkuList,
			Set<BcBonusSettingDtl> detailSkuhSet,ArrayList<String> detailSkuOidList,String userId,String userName,Timestamp sysdate)throws Exception{
		BcBonusSettingDtl newVo;
		Integer i=1;
		for(BcBonusSettingDtl ui:bcExchangeSkuList){
			if (ui==null){
				continue;
			}
			if (StringUtils.isNotBlank(ui.getOid())){
				detailSkuOidList.add(ui.getOid());
				ui.setBcBonusSettingMst(master);
				ui.setModifier(userId);
				ui.setModifierName(userName);
				ui.setModifyTime(sysdate);
				ui.setDetailSeq(i.intValue());
				detailSkuhSet.add(ui);
				i++;
			}else{
				newVo = new BcBonusSettingDtl();
				newVo.setCreator(userId);
				newVo.setCreatorName(userName);
				newVo.setCreateTime(sysdate);
				newVo.setModifier(userId);
				newVo.setModifierName(userName);
				newVo.setModifyTime(sysdate);
				newVo.setExBonus(ui.getExBonus());
				newVo.setExPrice(ui.getExPrice());
				//newVo.setChannelId(ui.getChannelId());
				newVo.setSkuId(ui.getSkuId());
				newVo.setSkuName(ui.getSkuName());
				newVo.setSkuId(ui.getSkuId());
				newVo.setBcBonusSettingMst(master);
				newVo.setDetailSeq(i.intValue());
				detailSkuhSet.add(newVo);
				i++;
			}
		}
		for(BcBonusSettingDtl detail:master.getBcExchangeSkus()){
			if (StringUtils.isNotBlank(detail.getOid()) &&
					detailSkuOidList.indexOf(detail.getOid())<0){
				detail.setBcBonusSettingMst(master);
				delSkuList.add(detail);
			}
		}
		master.setBcExchangeSkus(detailSkuhSet);		
	}		
	
	
	

	/**
	 *  process BcExchangeStore
	 * @param master
	 * @param bcStoreVo
	 * @param storeIdArray
	 * @param delStoreList
	 * @param detailStorehSet
	 * @param detailStoreOidList
	 * @param userId
	 * @param userName
	 * @param sysdate
	 * @throws Exception
	 */
	public void processSaveExchangeStore(BcBonusSettingMst master,List<BcStoreVo> bcStoreVoList,String[] storeIdArray,
			Collection<Object> delStoreList,Set<BcExchangeStore> detailStorehSet,ArrayList<String> detailStoreOidList,
			String userId,String userName,Timestamp sysdate)throws Exception{
		BcExchangeStore newVo;
		
		String[] storeTemp =null;
		String bcExchangeStoreOid = "";
		String channelId = "";
		String areaId = "";
		String storeId = "";
		if (storeIdArray!=null && storeIdArray.length>0){
			for(String storeString:storeIdArray){
				storeTemp = storeString.split(SPLIT_SEQU_1);
				bcExchangeStoreOid = StringUtils.isNotBlank(storeTemp[0])? storeTemp[0].trim():""; //id
				channelId = StringUtils.isNotBlank(storeTemp[1])? storeTemp[1].trim():""; //channelId
				areaId = StringUtils.isNotBlank(storeTemp[2])? storeTemp[2].trim():""; //areaId
				storeId = StringUtils.isNotBlank(storeTemp[3])? storeTemp[3].trim():""; //storeId	
				if (StringUtils.isNotBlank(bcExchangeStoreOid)){
					//don't update
					detailStoreOidList.add(bcExchangeStoreOid);			
				}else{
					//insert
					newVo = new BcExchangeStore();
					newVo.setCreator(userId);
					newVo.setCreatorName(userName);
					newVo.setCreateTime(sysdate);
					newVo.setModifier(userId);
					newVo.setModifierName(userName);
					newVo.setModifyTime(sysdate);
					newVo.setChannelId(channelId);
					newVo.setStoreId(storeId);
					newVo.setAreaId(areaId);
					newVo.setBcBonusSettingMst(master);
					detailStorehSet.add(newVo);					
				}
			}
		}
		System.out.println("master.getBcExchangeStores() : "+master.getBcExchangeStores().size()) ;
		for(BcExchangeStore detail:master.getBcExchangeStores()){
			if (StringUtils.isNotBlank(detail.getOid())){
				detail.setBcBonusSettingMst(master);
				if(detailStoreOidList.indexOf(detail.getOid())<0){
					delStoreList.add(detail);
					System.out.println("del : "+detail.getChannelId()) ;
				}else{
					System.out.println("add : "+detail.getChannelId()) ;
					detailStorehSet.add(detail);
				}
			}
		}
		//update
		for(BcExchangeStore detail:detailStorehSet){
			for(BcStoreVo vo:bcStoreVoList){
				if(detail.getChannelId().equals(vo.getChannelId())){
					detail.setPerAmt(vo.getPerAmt());
					detail.setPerBonus(vo.getPerBonus());
					detail.setDisType(vo.getDisType());
					detail.setDisSku(vo.getDisSku());
					detail.setDisSkuTaxed(vo.getDisSkuTaxed());
					detail.setModifier(userId);
					detail.setModifierName(userName);
					detail.setModifyTime(sysdate);					
					break;
				}
			}		
		}
		System.out.println("2 master.setBcExchangeStores : "+master.getBcExchangeStores().size()) ;
		master.setBcExchangeStores(detailStorehSet);		
	}	


	/**
	 * query BC_BONUS_SETTING_MST
	 * @param oid
	 * @param id
	 * @param channelIdList
	 * @return
	 * @throws Exception
	 */
	public BcBonusSettingMst getBcExchange(String oid,String id,List<BsChannel> channelIdList)throws Exception{
		BcBonusSettingVo vo = new BcBonusSettingVo();
		vo.setOid(oid);
		vo.setPromotId(id);
		if(channelIdList != null) {
			List<String> temp = new ArrayList() ;
			for (BsChannel bsChannel : channelIdList) {
				temp.add(bsChannel.getChannelId()) ;
			}
			vo.setAuthChannelList(temp) ;
		}
		QueryResult queryList = getQueryList(vo, 0, Integer.MAX_VALUE, false,true);
		List<BcBonusSettingMst> list = queryList.getResult();
		if(list!=null && list.size()>0){
			BcBonusSettingMst master = (BcBonusSettingMst)list.get(0);
			//file init		
			return master;
		}
		return null;
	}
	/**
	 * query BC_BONUS_SETTING_MST
	 * @param oid
	 * @return
	 * @throws Exception
	 */
	public BcBonusSettingMst getBcExchange(String oid)throws Exception{
		return getBcExchange(oid,null,null);
	}
	
	public BcBonusSettingMst getBcExchane(String oid,List<BsChannel> channelIdList) throws Exception {
		return getBcExchange(oid,null,channelIdList);
	}
	/**
	 * process merge (channel & store ) union  BcExchangeStore
	 * @param dataList
	 * @param storeList
	 * @param bcExchangeStoreList
	 * @return
	 * @throws Exception
	 */
	public static List<BsChannelVo> getFindActiveChannel(List<BsChannel> dataList,List<BsStore> storeList,
			List<BcExchangeStore> bcExchangeStoreList)throws Exception{
		BsChannelVo vo = null;
		BsStoreVo detailVo = null;
		List<BsChannelVo> returnList = new ArrayList<BsChannelVo>();
		ActionContext actionContext = ActionContext.getContext();
		try{
			for(BsChannel master:dataList){
				//2000428[加入實體通路判斷]
				if (master.getStatus() && master.getPhChannel() == 1 &&
						master.getCompanyId().equals(BsCompanyDefinition.getCompanyId())){
					vo = new BsChannelVo();
					returnList.add(vo);
					BeanUtils.copyProperties(vo, master);
					vo.setDisType(0);
					for(BcExchangeStore store:bcExchangeStoreList){
						if (vo.getChannelId().equals(store.getChannelId())){
							vo.setPerAmt(store.getPerAmt());
							vo.setPerBonus(store.getPerBonus());
							vo.setDisType(store.getDisType());
							vo.setDisSku(store.getDisSku());
							vo.setDisSkuName(store.getDisSkuName());
							vo.setDisSkuTaxed(store.getDisSkuTaxed());
							vo.setDisSkuTaxedName(store.getDisSkuTaxedName());
							break;
						}
					}					
					TreeMap<String,BsArea> bsAreaTempMap = new TreeMap<String,BsArea>();
					for(BsStore detail:storeList){
						//判斷是否總公司通路
						if(detail.getBsChannel().getChannelId().equals(BsChannel.HQ_CHANNEL)){ 
							if (StringUtils.isNotBlank(detail.getAreaId()) && detail.getId().getChannelId().equals(master.getChannelId())
									&&detail.getId().getCompanyId().equals(actionContext.getSession().get("SESSION_BS_COMPANY_ID"))){
								detailVo = new BsStoreVo();
								BeanUtils.copyProperties(detailVo, detail);
								bsAreaTempMap.put(detail.getAreaId(), detail.getBsArea());	
								vo.getBsStoreVo().add(detailVo);
								for(BcExchangeStore store:bcExchangeStoreList){
									if (store.getStoreId().equals(detail.getId().getStoreId()) && new Integer(1).equals(detail.getStatus())){
										detailVo.setBcExchangeStoreOid(store.getOid());
										detailVo.setChecked(Boolean.TRUE);
										break;
									}
								}
							}
						} else if (StringUtils.isNotBlank(detail.getAreaId()) && detail.getId().getChannelId().equals(master.getChannelId())){
							detailVo = new BsStoreVo();
							BeanUtils.copyProperties(detailVo, detail);
							bsAreaTempMap.put(detail.getAreaId(), detail.getBsArea());	
							vo.getBsStoreVo().add(detailVo);
							for(BcExchangeStore store:bcExchangeStoreList){
								if (store.getStoreId().equals(detail.getId().getStoreId()) && new Integer(1).equals(detail.getStatus())){
									detailVo.setBcExchangeStoreOid(store.getOid());
									detailVo.setChecked(Boolean.TRUE);
									break;
								}
							}
						}
					}
					vo.getBsAreas().addAll(bsAreaTempMap.values());
				}
			}
		}catch(Throwable t){
			log.info(t.getMessage());
		}		
		return returnList;
	}
	

	/**
	 * 檢核折現設定
	 * @param oid
	 * @param bsType
	 * @param activeDate
	 * @param inactiveDate
	 * @param channelId
	 * @param exBonus
	 * @return
	 * @throws Exception
	 */
	public Map<String,String> checkExchangeCash(String oid,String bsType,String activeDate,String inactiveDate,
			Map<String,Map<String,String>> channelId,String[] exBonus){
		Map<String,String> returnValue = new HashMap<String,String>();
		returnValue.put("returnFlag", "false");
		try{
			List<String> list = getDao().checkExchangeCash(oid, bsType, activeDate, inactiveDate, channelId, exBonus);
			if (list!=null && list.size()>0){
				returnValue.put("returnFlag", "true");
				returnValue.put("returnMessage",list.get(0));
			}
		}catch(Throwable t){
			log.info(t.getMessage());
		}
		return returnValue;		
	}
	
	/**
	 * @param nowDate
	 * @param status {STATUS_CODE_1:生效}
	 * @param bcType {TYPE_CODE_0:POS-兌換商品設定,TYPE_CODE_1:Service,TYPE_CODE_2:折現設定}
	 * @return
	 * @throws Exception
	 */
	public List<BcBonusSettingMst> getBcExchangeActive(Date nowDate,String status,String bcType)throws Throwable{
		return getBcExchangeActive(nowDate, status, bcType, true);
	}
	
	public List<BcBonusSettingMst> getBcExchangeActive(Date nowDate,String status,String bcType,boolean includeCompanyId)throws Throwable{
		BcBonusSettingVo condition = new BcBonusSettingVo();
		if (nowDate!=null){
			condition.setErpActiveDate(DateTimeUtils.getFormatDateStr(nowDate));
			condition.setErpInactiveDate(DateTimeUtils.getFormatDateStr(nowDate));
		}
		if (StringUtils.isNotBlank(status)){
			condition.setStatus(Integer.valueOf(status));
		}
		if (StringUtils.isNotBlank(bcType)){
			condition.setBsType(Integer.valueOf(bcType));
		}	
		return dao.findBcExchange(condition, 0, Integer.MAX_VALUE, false, true,includeCompanyId);
	}
	
	/**
	 * 檢核channel store exists
	 * @param oid
	 * @param bsType
	 * @param activeDate
	 * @param inactiveDate
	 * @param isExchange
	 * @param channelId
	 * @return
	 * @throws Exception
	 */
	public Map<String,String> checkExchangeStore(String oid,String bsType,String activeDate,String inactiveDate,boolean isExchange
			,Map<String,Map<String,String>> channelId){
		Map<String,String> returnValue = new HashMap<String,String>();
		returnValue.put("returnFlag", "false");
		try{
			List<String> list = getDao().checkExchangeStore(oid, bsType, activeDate, inactiveDate, channelId, isExchange);
			if (list!=null && list.size()>0){
				returnValue.put("returnFlag", "true");
				returnValue.put("returnMessage",list.get(0));
			}
		}catch(Throwable t){
			log.info(t.getMessage());
		}
		return returnValue;		
	}
	
	/**
	 * sku+channelsku+bouns+channelId+store
	 * @param oid
	 * @param bsType
	 * @param activeDate
	 * @param inactiveDate
	 * @param channelId
	 * @param channelSku
	 * @param sku
	 * @param exBonus
	 * @return
	 */
	public Map<String,String> checkExchangeSku(String oid,String bsType,String activeDate,String inactiveDate,
			Map<String,Map<String,String>> channelId , String[] channelSku, String[] sku,String[] exBonus){
		Map<String,String> returnValue = new HashMap<String,String>();
		returnValue.put("returnFlag", "false");
		try{
			List<String> list = getDao().checkExchangeSku(oid, bsType, activeDate, inactiveDate, channelId, channelSku, sku, exBonus);
			if (list!=null && list.size()>0){
				returnValue.put("returnFlag", "true");
				returnValue.put("returnMessage",list.get(0));
			}
		}catch(Throwable t){
			log.info(t.getMessage());
		}
		return returnValue;		
	}
	
	/**
	 * channel+sku+vendorId+dept+subDept+class+subClass
	 * @param oid
	 * @param bsType
	 * @param activeDate
	 * @param inactiveDate
	 * @param channelId
	 * @param roleString
	 * @return
	 * @throws Exception
	 */
	public Map<String,String> checkBonusSotreSku(String oid,String bsType,String activeDate,String inactiveDate,
			Map<String,Map<String,String>> channelId,String[] roleString){
		Map<String,String> returnValue = new HashMap<String,String>();
		returnValue.put("returnFlag", "false");
		try{
			List<String> list = getDao().checkBonusSotreSku(oid, bsType, activeDate, inactiveDate, channelId, roleString);
			if (list!=null && list.size()>0){
				returnValue.put("returnFlag", "true");
				returnValue.put("returnMessage",list.get(0));
			}
		}catch(Throwable t){
			log.info(t.getMessage());
		}
		return returnValue;	
	}
	
	/**
	 * 紅利點數-POS兌換商品設定排程
	 * @throws Exception
	 */
	public void processExchangeSkuScheduling()throws Exception{
		processExchangeScheduling(BcExchangeService.TYPE_CODE_0, 
				DateTimeUtils.getDate(DateTimeUtils.addDate(DateTimeUtils.getSysDate(), -1)));
	}
	
	/**
	 * 紅利點數-POS折現設定排程
	 * @throws Exception
	 */
	public void processExchangeCashScheduling()throws Exception{
		processExchangeScheduling(BcExchangeService.TYPE_CODE_2, 
				DateTimeUtils.getDate(DateTimeUtils.addDate(DateTimeUtils.getSysDate(), -1)));
	}
	
	/**
	 * 紅利點數-服務台兌換排程
	 * @throws Exception
	 */
	public void processExchangeServiceScheduling()throws Exception{
		processExchangeScheduling(BcExchangeService.TYPE_CODE_1, 
				DateTimeUtils.getDate(DateTimeUtils.addDate(DateTimeUtils.getSysDate(), -1)));
	}	

	/**
	 * 紅利點數過期更新
	 * @param typeCode
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	private void processExchangeScheduling(String typeCode,String date)throws Exception{
		BcBonusSettingVo condition	= new BcBonusSettingVo();	
		condition.setBsType(Integer.parseInt(typeCode));
		condition.setStatus(Integer.parseInt(BcExchangeService.STATUS_CODE_1));
		condition.setInactiveDate(date);
		for (BsCompany bsCompany : BsCompanyDefinition.getList()) {
			condition.setCompanyId(bsCompany.getCompanyId()); 
			final List<BcBonusSettingMst> list = getDao().findBcExchange(condition, 0, Integer.MAX_VALUE,Boolean.FALSE ,Boolean.FALSE);
			if (list!=null){
				try {
					transactionTemplate.execute(new TransactionCallback() {
						public Object doInTransaction(TransactionStatus txnStatus) {
							Boolean txnFail = false; 
							try{
								//master
								for(BcBonusSettingMst vo:list){
									vo.setStatus(Integer.parseInt(BcExchangeService.STATUS_CODE_2));
									vo.setModifier("SYS");
									vo.setModifierName("SYS");
									vo.setModifyTime(DateTimeUtils.getSysDate());
									getDao().updateObject(vo);
								}
							} catch(Exception ex) {
								txnFail = true;
								txnStatus.setRollbackOnly();
								throw new RuntimeException(ex);
							}
							return txnFail;
						}
					});
				}catch(Exception e){
					throw e ;
				}
			}
		}
	}
	
	//add by Tim 2010.05.06	
	public QueryResult findBonusActivity(BcBonusSettingVo condition, int index, int pageSize, boolean isCount) {				
		return this.dao.findBonusActivity(condition, index, pageSize, isCount);
	}
	
	public void expiredActivityReminder(){
		StringBuffer str = new StringBuffer();
		List list = new ArrayList();
		boolean isSend = false;
		SimpleDateFormat df = new SimpleDateFormat("yyyy/MM/dd");
		Calendar c = Calendar.getInstance() ;
		c.setTime(new Date());
		c.add(Calendar.DATE, +30);
		
		try {
			Date expDateT = df.parse(df.format(c.getTime()));
			
			// 編寫信件內容
			str.append("內容: <br>").append(" 活動即將到期,請儘速至CRM系統更新日期 <br>");
			
			// 第一段，3012-紅利點數-POS 折現設定
			list = dao.queryBcExchangeByExpDateT(expDateT);
			if(list.size() > 0){
				isSend = true;
				str.append("3012-紅利點數-POS 折現設定 <br>")
				   .append("<table border='1'><tr><th>兌換設定代號</th><th>說明</th><th>有效截止日期</th></tr>");
			}
			for(Object obj : list){
				Map data = (HashMap)obj;
				str.append("<tr>")
				   .append("<td>" + ((data.get("ID")==null)? "":data.get("ID").toString()) + "</td>")
				   .append("<td>" + ((data.get("EXPLANATION")==null)? "":data.get("EXPLANATION").toString()) + "</td>")
				   .append("<td>" + ((data.get("EXP_DATE_T")==null)? "":df.format((Date)data.get("EXP_DATE_T"))) + "</td>")
				   .append("</tr>");
			}
			if(list.size() > 0){
				str.append("</table><br>");
			}
			
			// 第二段，3013-紅利點數-服務台 兌換商品設定
			list = dao.findBcExchangeByExpDateT(expDateT);
			if(list.size() > 0){
				isSend = true;
				str.append("3013-紅利點數-服務台 兌換商品設定 <br>")
				   .append("<table border='1'><tr><th>兌換設定代號</th><th>說明</th><th>有效截止日期</th></tr>");
			}
			for(Object obj : list){
				Map data = (HashMap)obj;
				str.append("<tr>")
				   .append("<td>" + ((data.get("ID")==null)? "":data.get("ID").toString()) + "</td>")
				   .append("<td>" + ((data.get("EXPLANATION")==null)? "":data.get("EXPLANATION").toString()) + "</td>")
				   .append("<td>" + ((data.get("EXP_DATE_T")==null)? "":df.format((Date)data.get("EXP_DATE_T"))) + "</td>")
				   .append("</tr>");
			}
			if(list.size() > 0){
				str.append("</table><br>");
			}
			
			// 第三段，3014-紅利點數通用累積設定
			list = dao.queryBcBonusCumlByExpDateT(expDateT);
			if(list.size() > 0){
				isSend = true;
				str.append("3014-紅利點數通用累積設定 <br>")
				   .append("<table border='1'><tr><th>兌換設定代號</th><th>說明</th><th>有效截止日期</th></tr>");
			}
			for(Object obj : list){
				Map data = (HashMap)obj;
				str.append("<tr>")
				   .append("<td>" + ((data.get("ID")==null)? "":data.get("ID").toString()) + "</td>")
				   .append("<td>" + ((data.get("EXPLANATION")==null)? "":data.get("EXPLANATION").toString()) + "</td>")
				   .append("<td>" + ((data.get("EXP_DATE_T")==null)? "":df.format((Date)data.get("EXP_DATE_T"))) + "</td>")
				   .append("</tr>");
			}
			if(list.size() > 0){
				str.append("</table>");
			}
			
			if(isSend){
				// 取得郵件收件人列表
				String receiverList = CassetteJobTimeAndMailNotifyService.sysJobMailTo("ExpiredActivityReminder");
				MessageContent content = new MessageContent() ;
				// 郵件subject
				content.setSubject("活動即將到期通知");
				// 郵件內文
				content.setContent(str.toString());
				//送出郵件
				MailService.sendMessage(content.getContent(), content.getSubject(), receiverList, "", null);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
