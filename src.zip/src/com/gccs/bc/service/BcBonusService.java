
package com.gccs.bc.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.bnq.sc.model.ScSysuser;
import com.bnq.util.DateTimeUtils;
import com.bnq.util.QueryResult;
import com.bnq.util.serial.SerialService;
import com.gccs.bc.action.BcBonusParamUtil;
import com.gccs.bc.dao.hibernate.BcExchangeDao;
import com.gccs.bc.model.BcBonusSettingDtl;
import com.gccs.bc.model.BcBonusSettingMst;
import com.gccs.bc.model.BcBonusSku;
import com.gccs.bc.model.BcExchangeStore;
import com.gccs.bc.setting.vo.BcBonusSettingVo;
import com.gccs.bc.vo.BcStoreVo;
import com.gccs.bs.model.BsChannel;
import com.gccs.bs.model.BsCompany;
import com.gccs.util.cache.BsCompanyDefinition;
 
/**
 * @author JL
 *
 */
public class BcBonusService {

	private static final Logger log = LogManager.getLogger(BcBonusService.class) ;

	public static final String STATUS_CODE_0 = "0";//建立
	public static final String STATUS_CODE_1 = "1";//生效
	public static final String STATUS_CODE_2 = "2";//失效
	public static final String STATUS_CODE_3 = "3";//取消
	public static final String STATUS_CODE_4 = "4";//審核
	public static final String STATUS_CODE_5 = "5";//退回

	public static final String TYPE_CODE_0 = "0";//紅利點數通用累積設定
	public static final String TYPE_CODE_1 = "1";//紅利點數商品累積設定
	public static final String TYPE_CODE_2 = "2";//紅利點數發票累積設定
	public static final String TYPE_CODE_3 = "3";//紅利點數發票倍率累積設定
	public static final String TYPE_CODE_4 = "4";//紅利點數商品及發票累積
	public static final String TYPE_CODE_5 = "5";//紅利點數發票倍率設定
	public static final String TYPE_CODE_96 = "96";//群組匯入固定紅利(生日)
	public static final String TYPE_CODE_97 = "97";//群組匯入倍率紅利(生日)
	public static final String TYPE_CODE_98 = "98";//群組匯入固定紅利
	public static final String TYPE_CODE_99 = "99";//群組匯入倍率紅利

	public static final Integer CLASS_TYPE_1 = 1;//商品
	public static final Integer CLASS_TYPE_2 = 2;//商品分類
	public static final Integer CLASS_TYPE_3 = 3;//廠商

	public static final Integer BONUS_TYPE_0 = 0;//點數
	public static final Integer BONUS_TYPE_1 = 1;//倍率

	public static final String SPLIT_SEQU = ",";

	public static final String FIELD_STORE_ID = "storeId-";//依店別代碼執行
	public static final String FIELD_CHANNEL_ID ="channelId-";//依通路執行

	private BcExchangeDao dao ;
	private TransactionTemplate transactionTemplate ;

	public TransactionTemplate getTransactionTemplate() {
		return transactionTemplate;
	}
	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}
	public BcExchangeDao getDao() {
		return dao;
	}
	public void setDao(BcExchangeDao dao) {
		this.dao = dao;
	}


	/**
	 * query BC_BONUS_SETTING_MST
	 * @param vo : 欲查詢之條件
	 * @param index : 起始筆數
	 * @param rows : 總筆數
	 * @param countTotal : true:查詢總筆數,false:查詢詳細資料
	 * @return QueryResult : 查詢結果
	 * @throws Exception
	 */
	public QueryResult getQueryList(BcBonusSettingVo vo,int index,int rows,boolean countTotal,boolean lazy) throws Exception {
		QueryResult result = new QueryResult() ;
		if(countTotal) {
			List temp = getDao().findBcBonusCuml(vo, index, rows, true,false);
			result.setCount((Integer)temp.get(0));
		}
		List<BcBonusSettingMst> queryResult = getDao().findBcBonusCuml(vo, index, rows, false,lazy);
		if(queryResult == null || queryResult.size() == 0){
			result.setResult(new ArrayList());
		}else{
			result.setResult(queryResult) ;
		}
		return result ;
	}

	/**
	 * 依分頁查詢條件查詢BonusSku
	 * @param promotionOid
	 * @param index
	 * @param pageSize
	 * @return QueryResult
	 * @throws Exception
	 */
	public QueryResult findBonusSkuByCondition(final String promotionOid,final int index,final int pageSize)throws Exception{
		return this.findBonusSkuByCondition(promotionOid, index, pageSize,null);
	}
	/**
	 * 依分頁查詢條件查詢BonusSku
	 * @param promotionOid
	 * @param index
	 * @param pageSize
	 * @param channelList
	 * @return QueryResult
	 * @throws Exception
	 */
	public QueryResult findBonusSkuByCondition(final String promotionOid,final int index,final int pageSize,List<String> channelList)throws Exception{
		QueryResult queryResult = new QueryResult();

		List countList = this.getDao().findBonusSkuByCondition(promotionOid, index, pageSize,channelList, true);
		queryResult.setCount((Integer)countList.get(0));
		List reulstList = this.getDao().findBonusSkuByCondition(promotionOid, index, pageSize,channelList, false);
		queryResult.setResult(reulstList);
		return queryResult;
	}

	/**
	 * saveOrupdate BcBonusCuml
	 * @param vo
	 * @param bcBonusAmtList
	 * @param bcBonusSkuList
	 * @param bcBonusPercentAmtList
	 * @param executeCode
	 * @param actionSubmitType
	 * @param bcStoreVoList
	 * @param storeId
	 * @param userId
	 * @param userName
	 * @return
	 * @throws Exception
	 */
	public BcBonusSettingMst saveOrUpdateBcBonusCuml(BcBonusSettingMst vo,List<BcBonusSettingDtl> bcBonusAmtList,List<BcBonusSku> bcBonusSkuList,
			List<BcBonusSettingDtl> bcBonusPercentAmtList,String executeCode,String actionSubmitType,List<BcStoreVo> bcStoreVoList,
			String[] storeId,String userId,String userName) throws Exception {
		Timestamp sysdate = DateTimeUtils.getSysDate();
		final BcBonusSettingMst master;
		//BcBonusAmt
		final Collection<Object> delAmtList = new ArrayList<Object>();
		Set<BcBonusSettingDtl> detailAmtSet = new HashSet<BcBonusSettingDtl>();
		ArrayList<String> detailAmtOidList = new ArrayList<String>();
		//BcExchangeSku
		final Collection<Object> delSkuList = new ArrayList<Object>();
		//Set<BcBonusSku> detailSkuSet = new HashSet<BcBonusSku>();
		//ArrayList<String> detailSkuOidList = new ArrayList<String>();
		//BcBonusPercentAmt
		final Collection<Object> delPercentAmtList = new ArrayList<Object>();
		Set<BcBonusSettingDtl> detailPercentAmtSet = new HashSet<BcBonusSettingDtl>();
		ArrayList<String> detailPercentAmtOidList = new ArrayList<String>();

		//BcExchangeStore
		final Collection<Object> delStoreList = new ArrayList<Object>();
		Set<BcExchangeStore> detailStoreSet = new HashSet<BcExchangeStore>();
		ArrayList<String> detailStoreOidList = new ArrayList<String>();

		if (StringUtils.isBlank(vo.getOid())){
			master = vo;
			master.setBcBonusAmts(new HashSet<BcBonusSettingDtl>());
			master.setBcBonusSkus(new HashSet<BcBonusSku>());
			master.setBcExchangeStores(new HashSet<BcExchangeStore>());
			if(master.getBsType() == null) {
				master.setBsType(StringUtils.isNotBlank(actionSubmitType)? Integer.parseInt(actionSubmitType):null);
			}
			master.setCreator(userId);
			master.setCreatorName(userName);
			master.setCreateTime(sysdate);
		}else{
			master = getBcBonusCuml(vo.getOid());
		}

		if (STATUS_CODE_0.equals(executeCode) || STATUS_CODE_4.equals(executeCode)){
			//mster
			BeanUtils.copyProperties(master,vo);
			//detail
			processSaveBcBonusAmt(master, bcBonusAmtList, delAmtList, detailAmtSet, detailAmtOidList, userId, userName, sysdate);
			//processSaveBcBonusSku(master, bcBonusSkuList, delSkuList, detailSkuSet, detailSkuOidList, userId, userName, sysdate);
			processSaveBcBonusPercentAmt(master, bcBonusPercentAmtList, delPercentAmtList, detailPercentAmtSet,
					detailPercentAmtOidList, userId, userName, sysdate);
			processSaveExchangeStore(master, bcStoreVoList,storeId,delStoreList, detailStoreSet, detailStoreOidList, userId, userName, sysdate);
		}

		master.setStatus((StringUtils.isBlank(executeCode))? Integer.parseInt(STATUS_CODE_0):
			(STATUS_CODE_1.equals(master.getStatus()) && STATUS_CODE_0.equals(executeCode)?
					Integer.parseInt(STATUS_CODE_1):Integer.parseInt(executeCode)));
		master.setModifyTime(sysdate);
		master.setModifier(userId);
		master.setModifierName(userName);
		String companyId = StringUtils.isNotEmpty(BsCompanyDefinition.getCompanyId())?
				BsCompanyDefinition.getCompanyId():"";
		master.setCompanyId(companyId);

		try{
			if (STATUS_CODE_2.equals(executeCode)){
				master.setExpDateT(DateTimeUtils.getDate(DateTimeUtils.getFormatDateStr(sysdate)));
			}else if (STATUS_CODE_1.equals(executeCode)){
				if (master.getExpDateF().compareTo(DateTimeUtils.getDate(DateTimeUtils.getFormatDateStr(sysdate)))>0){
					master.setDownloadDate(master.getExpDateF());
				}else{
					master.setDownloadDate(DateTimeUtils.getDate(DateTimeUtils.getFormatDateStr(sysdate)));
				}

			}
		}catch(Throwable t){
			throw new Exception(t);
		}

		try {
			transactionTemplate.execute(new TransactionCallback() {
				public Object doInTransaction(TransactionStatus txnStatus) {
					Boolean txnFail = false;
					try{
						//master
						if (StringUtils.isBlank(master.getOid())){
							//get seq
							master.setPromotId(SerialService.getCategorySerial(SerialService.CATEGORY_BSC, SerialService.DATE_FORMAT_YYYYMM,3));
							getDao().insertObject(master);
						}else{
							getDao().updateObject(master);
						}
						//BcExchangeAmt
						for(BcBonusSettingDtl detail:master.getBcBonusAmts()){
							if (StringUtils.isBlank(detail.getOid())){
								getDao().insertObject(detail);
							}else{
								getDao().updateObject(detail);
							}
						}
						getDao().deleteCollection(delAmtList);
						//BcExchangeSku
						for(BcBonusSku detail:master.getBcBonusSkus()){
							if (StringUtils.isBlank(detail.getOid())){
								getDao().insertObject(detail);
							}else{
								getDao().updateObject(detail);
							}
						}
						getDao().deleteCollection(delSkuList);
						//BcExchangePercentAmt
						for(BcBonusSettingDtl detail:master.getBcBonusPercentAmts()){
							if (StringUtils.isBlank(detail.getOid())){
								getDao().insertObject(detail);
							}else{
								getDao().updateObject(detail);
							}
						}
						getDao().deleteCollection(delPercentAmtList);
						//BcExchangeStore
						for(BcExchangeStore detail:master.getBcExchangeStores()){
							if (StringUtils.isBlank(detail.getOid())){
								detail.setRefOid(master.getOid());
								getDao().insertObject(detail);
							}else{
								detail.setRefOid(master.getOid());
								getDao().updateObject(detail);
							}
						}
						getDao().deleteCollection(delStoreList);
					} catch(Exception ex) {
						txnFail = true;
						txnStatus.setRollbackOnly();
						throw new RuntimeException(ex);
					}
					return txnFail;
				}
			});
		}catch(Exception e){
			throw e ;
		}
		return getBcBonusCuml(vo.getOid());
	}
	/**
	 * saveOrUpdateBcBonusCuml
	 * @param vo
	 * @param bcBonusAmtList
	 * @param bcBonusSkuList
	 * @param bcBonusPercentAmtList
	 * @param executeCode
	 * @param actionSubmitType
	 * @param bcStoreVoList
	 * @param storeId
	 * @param userId
	 * @param userName
	 * @param addDiscountSkuVoList
	 * @param updDiscountSkuVoList
	 * @param delDiscountSkuVoList
	 * @return
	 * @throws Exception
	 */
	public BcBonusSettingMst saveOrUpdateBcBonusCuml(
			BcBonusSettingMst vo, 
			List<BcBonusSettingDtl> bcBonusAmtList,
			List<BcBonusSettingDtl> bcBonusPercentAmtList,
			String executeCode,
			String actionSubmitType,
			List<BcStoreVo> bcStoreVoList,
			String[] storeId,
			String userId,
			String userName,
			final List <BcBonusSku> addSkuVoList,
			final List<BcBonusSku> updSkuVoList,
			final List<BcBonusSku> delSkuVoList,
			List<BsChannel> channelIdList) throws Exception {
		Timestamp sysdate = DateTimeUtils.getSysDate();
		final BcBonusSettingMst master;
		
		final Collection<Object> delAmtList = new ArrayList<Object>();
		Set<BcBonusSettingDtl> detailAmtSet = new HashSet<BcBonusSettingDtl>();
		ArrayList<String> detailAmtOidList = new ArrayList<String>();
		
		final Collection<Object> delPercentAmtList = new ArrayList<Object>();
		Set<BcBonusSettingDtl> detailPercentAmtSet = new HashSet<BcBonusSettingDtl>();
		ArrayList<String> detailPercentAmtOidList = new ArrayList<String>();
		
		final Collection<Object> delStoreList = new ArrayList<Object>();
		Set<BcExchangeStore> detailStoreSet = new HashSet<BcExchangeStore>();
		ArrayList<String> detailStoreOidList = new ArrayList<String>();

		if (StringUtils.isBlank(vo.getOid())){
			master = vo;
			master.setBcBonusAmts(new HashSet<BcBonusSettingDtl>());
			master.setBcExchangeStores(new HashSet<BcExchangeStore>());
			master.setBsType(StringUtils.isNotBlank(actionSubmitType)? Integer.parseInt(actionSubmitType):null);
			master.setCreator(userId);
			master.setCreatorName(userName);
			master.setCreateTime(sysdate);
		}else{
			master = getBcBonusCuml(vo.getOid(),null,channelIdList);
		}

		if (STATUS_CODE_0.equals(executeCode) || STATUS_CODE_4.equals(executeCode)){
			//mster
			BeanUtils.copyProperties(master, vo);
			//detail
			processSaveBcBonusAmt(master, bcBonusAmtList, delAmtList, detailAmtSet, detailAmtOidList, userId, userName, sysdate);
			processSaveBcBonusPercentAmt(master, bcBonusPercentAmtList, delPercentAmtList, detailPercentAmtSet, detailPercentAmtOidList, userId, userName, sysdate);
			processSaveExchangeStore(master, bcStoreVoList, storeId, delStoreList, detailStoreSet, detailStoreOidList, userId, userName, sysdate);
		}

		master.setStatus((StringUtils.isBlank(executeCode))? Integer.parseInt(STATUS_CODE_0):(STATUS_CODE_1.equals(master.getStatus()) && STATUS_CODE_0.equals(executeCode)? Integer.parseInt(STATUS_CODE_1):Integer.parseInt(executeCode)));
		master.setModifyTime(sysdate);
		master.setModifier(userId);
		master.setModifierName(userName);
		String companyId = StringUtils.isNotEmpty(BsCompanyDefinition.getCompanyId())?
				BsCompanyDefinition.getCompanyId():"";
		master.setCompanyId(companyId);

		try{
			if (STATUS_CODE_2.equals(executeCode)){
				master.setExpDateT(DateTimeUtils.getDate(DateTimeUtils.getFormatDateStr(sysdate)));
			}else if (STATUS_CODE_1.equals(executeCode)){
				master.setDownloadDate(DateTimeUtils.getDate(DateTimeUtils.getFormatDateStr(sysdate)));
			}
		}catch(Throwable t){
			throw new Exception(t);
		}

		try {
			transactionTemplate.execute(new TransactionCallback() {
				public Object doInTransaction(TransactionStatus txnStatus) {
					Boolean txnFail = false;
					try{
						//master
						if (StringUtils.isBlank(master.getOid())){
							//get seq
							master.setPromotId(SerialService.getCategorySerial(SerialService.CATEGORY_BSC, SerialService.DATE_FORMAT_YYYYMM,3));
							getDao().insertObject(master);
						}else{
							getDao().updateObject(master);
						}

						//BcExchangeAmt
						for(BcBonusSettingDtl detail : master.getBcBonusAmts()){
							if (StringUtils.isBlank(detail.getOid())){
								getDao().insertObject(detail);
							}else{
								getDao().updateObject(detail);
							}
						}
						getDao().deleteCollection(delAmtList);

						//BcExchangeSku
						BcBonusParamUtil.showLog(addSkuVoList, addSkuVoList);

						System.out.println("修改 Sku size: "+updSkuVoList.size());
						for(BcBonusSku sku :updSkuVoList){
							if (sku.getSku() != null || sku.getVentorId() != null) {
								sku.setDept(null);
							}
							sku.setBcBonusSettingMst(master);
							getDao().updateBcBonusSkus(sku) ;
						}

						System.out.println("新增 Sku size: "+addSkuVoList.size());
						for(BcBonusSku sku :addSkuVoList){
							if (sku.getSku() != null || sku.getVentorId() != null) {
								sku.setDept(null);
							}
							sku.setBcBonusSettingMst(master);
							getDao().saveBcBonusSku(sku) ;
						}

						System.out.println("刪除 Sku size: "+delSkuVoList.size());
						for(BcBonusSku sku :delSkuVoList){
							if (sku.getSku() != null || sku.getVentorId() != null) {
								sku.setDept(null);
							}
							sku.setBcBonusSettingMst(master);
							 getDao().delBcBonusSku(sku);
						}
							
						System.out.println("master.getBcBonusPercentAmts() size: " + master.getBcBonusPercentAmts().size());
						for(BcBonusSettingDtl detail : master.getBcBonusPercentAmts()){
							if (StringUtils.isBlank(detail.getOid())){
								getDao().insertObject(detail);
							}else{
								getDao().updateObject(detail);
							}
						}
						getDao().deleteCollection(delPercentAmtList);
						
						//BcExchangeStore
						System.out.println("master.getBcExchangeStores() size: " + master.getBcExchangeStores().size());
						for(BcExchangeStore detail : master.getBcExchangeStores()){
							if (StringUtils.isBlank(detail.getOid())){
								detail.setRefOid(master.getOid());
								getDao().insertObject(detail);
							}else{
								detail.setRefOid(master.getOid());
								getDao().updateObject(detail);
							}
						}
						getDao().deleteCollection(delStoreList);
					} catch(Exception ex) {
						txnFail = true;
						txnStatus.setRollbackOnly();
						throw new RuntimeException(ex);
					}
					return txnFail;
				}
			});
		}catch(Exception e){
			throw e ;
		}
		return getBcBonusCuml(vo.getOid());
	}

	/**
	 * process BcBonusAmt
	 * @param master
	 * @param bcBonusAmtList
	 * @param delAmtList
	 * @param detailAmtSet
	 * @param detailAmtOidList
	 * @param userId
	 * @param userName
	 * @param sysdate
	 * @throws Exception
	 */
	public void processSaveBcBonusAmt(BcBonusSettingMst master,List<BcBonusSettingDtl> bcBonusAmtList,Collection<Object> delAmtList,
			Set<BcBonusSettingDtl> detailAmtSet,ArrayList<String> detailAmtOidList,String userId,String userName,Timestamp sysdate)throws Exception{
		BcBonusSettingDtl newVo;
		for(BcBonusSettingDtl ui:bcBonusAmtList){
			if (ui==null){
				continue;
			}
			if (StringUtils.isNotBlank(ui.getOid())){
				detailAmtOidList.add(ui.getOid());
				ui.setBcBonusSettingMst(master);
				ui.setModifier(userId);
				ui.setModifierName(userName);
				ui.setModifyTime(sysdate);
				detailAmtSet.add(ui);
			}else{
				newVo = new BcBonusSettingDtl();
				newVo.setCreator(userId);
				newVo.setCreatorName(userName);
				newVo.setCreateTime(sysdate);
				newVo.setModifier(userId);
				newVo.setModifierName(userName);
				newVo.setModifyTime(sysdate);
				newVo.setExBonus(ui.getExBonus());
				newVo.setAmountF(ui.getAmountF());
				newVo.setAmountT(ui.getAmountT());
				newVo.setBcBonusSettingMst(master);
				detailAmtSet.add(newVo);
			}
		}
		for(BcBonusSettingDtl detail:master.getBcBonusAmts()){
			if (StringUtils.isNotBlank(detail.getOid()) &&
					detailAmtOidList.indexOf(detail.getOid())<0){
				detail.setBcBonusSettingMst(master);
				delAmtList.add(detail);
			}
		}
		master.setBcBonusAmts(detailAmtSet);
	}

	/**
	 * process BcBonusPercentAmt
	 * @param master
	 * @param bcBonusPercentAmtList
	 * @param delPercentAmtList
	 * @param detailPercentAmtSet
	 * @param detailPercentAmtOidList
	 * @param userId
	 * @param userName
	 * @param sysdate
	 * @throws Exception
	 */
	public void processSaveBcBonusPercentAmt(BcBonusSettingMst master,List<BcBonusSettingDtl> bcBonusPercentAmtList,Collection<Object> delPercentAmtList,
			Set<BcBonusSettingDtl> detailPercentAmtSet,ArrayList<String> detailPercentAmtOidList,String userId,String userName,Timestamp sysdate)throws Exception{
		BcBonusSettingDtl newVo;
		for(BcBonusSettingDtl ui:bcBonusPercentAmtList){
			if (ui==null){
				continue;
			}
			if (StringUtils.isNotBlank(ui.getOid())){
				detailPercentAmtOidList.add(ui.getOid());
				ui.setBcBonusSettingMst(master);
				ui.setModifier(userId);
				ui.setModifierName(userName);
				ui.setModifyTime(sysdate);
				detailPercentAmtSet.add(ui);
			}else{
				newVo = new BcBonusSettingDtl();
				newVo.setCreator(userId);
				newVo.setCreatorName(userName);
				newVo.setCreateTime(sysdate);
				newVo.setModifier(userId);
				newVo.setModifierName(userName);
				newVo.setModifyTime(sysdate);
				newVo.setPercent(ui.getPercent());
				newVo.setAmountF(ui.getAmountF());
				newVo.setAmountT(ui.getAmountT());
				newVo.setBcBonusSettingMst(master);
				detailPercentAmtSet.add(newVo);
			}
		}
		for(BcBonusSettingDtl detail:master.getBcBonusPercentAmts()){
			if (StringUtils.isNotBlank(detail.getOid()) &&
					detailPercentAmtOidList.indexOf(detail.getOid())<0){
				detail.setBcBonusSettingMst(master);
				delPercentAmtList.add(detail);
			}
		}
		master.setBcBonusPercentAmts(detailPercentAmtSet);
	}


	/**
	 * process BcBonusSku
	 * @param master
	 * @param bcBonusSkuList
	 * @param delSkuList
	 * @param detailSkuhSet
	 * @param detailSkuOidList
	 * @param userId
	 * @param userName
	 * @param sysdate
	 * @throws Exception
	 */
	public void processSaveBcBonusSku(BcBonusSettingMst master,List<BcBonusSku> bcBonusSkuList,Collection<Object> delSkuList,
			Set<BcBonusSku> detailSkuhSet,ArrayList<String> detailSkuOidList,String userId,String userName,Timestamp sysdate)throws Exception{
		BcBonusSku newVo;
		for(BcBonusSku ui:bcBonusSkuList){
			if (ui==null){
				continue;
			}
			if (StringUtils.isNotBlank(ui.getOid())){
				detailSkuOidList.add(ui.getOid());
				ui.setBcBonusSettingMst(master);
				ui.setModifier(userId);
				ui.setModifierName(userName);
				ui.setModifyTime(sysdate);
				ui.setClassType(processClassType(ui));
				ui.setBonusType(processBonusType(ui));
				detailSkuhSet.add(ui);
			}else{
				newVo = new BcBonusSku();
				newVo.setCreator(userId);
				newVo.setCreatorName(userName);
				newVo.setCreateTime(sysdate);
				newVo.setModifier(userId);
				newVo.setModifierName(userName);
				newVo.setModifyTime(sysdate);
				newVo.setExBonus(ui.getExBonus());
				newVo.setExPercent(ui.getExPercent());
				newVo.setDept(ui.getDept());
				newVo.setSubDept(ui.getSubDept());
				newVo.setClass_(ui.getClass_());
				newVo.setSubClass(ui.getSubClass());
				newVo.setSku(ui.getSku());
				newVo.setVentorId(ui.getVentorId());
				newVo.setVentorName(ui.getVentorName());
				newVo.setSkuName(ui.getSkuName());
				newVo.setChannelId(ui.getChannelId());
				newVo.setClassType(processClassType(newVo));
				newVo.setBonusType(processBonusType(newVo));
				newVo.setBcBonusSettingMst(master);
				detailSkuhSet.add(newVo);
			}
		}
		for(BcBonusSku detail:master.getBcBonusSkus()){
			if (StringUtils.isNotBlank(detail.getOid()) &&
					detailSkuOidList.indexOf(detail.getOid())<0){
				detail.setBcBonusSettingMst(master);
				delSkuList.add(detail);
			}
		}
		master.setBcBonusSkus(detailSkuhSet);
	}

	/**
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	public Integer processClassType(BcBonusSku vo)throws Exception{
		if(StringUtils.isNotBlank(vo.getSku())){
			return CLASS_TYPE_1;
		}else if (StringUtils.isNotBlank(vo.getVentorId())){
			return CLASS_TYPE_3;
		}else{
			return CLASS_TYPE_2;
		}
	}

	/**
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	public Integer processBonusType(BcBonusSku vo)throws Exception{
		if(vo.getExBonus()!=null){
			return BONUS_TYPE_0;
		}else if (vo.getExPercent()!=null){
			return BONUS_TYPE_1;
		}
		return null;
	}

	/**
	 *  process BcExchangeStore
	 * @param master
	 * @param bcStoreVo
	 * @param storeIdArray
	 * @param delStoreList
	 * @param detailStorehSet
	 * @param detailStoreOidList
	 * @param userId
	 * @param userName
	 * @param sysdate
	 * @throws Exception
	 */
	public void processSaveExchangeStore(
			BcBonusSettingMst master, 
			List<BcStoreVo> bcStoreVoList, 
			String[] storeIdArray,
			Collection<Object> delStoreList,
			Set<BcExchangeStore> detailStorehSet,
			ArrayList<String> detailStoreOidList,
			String userId, 
			String userName, 
			Timestamp sysdate)throws Exception{
		BcExchangeStore newVo;
		String[] storeTemp =null;
		String bcExchangeStoreOid = "";
		String channelId = "";
		String areaId = "";
		String storeId = "";
		
		if (storeIdArray != null && storeIdArray.length > 0){
			for(String storeString : storeIdArray){
				storeTemp = storeString.split(SPLIT_SEQU);
				bcExchangeStoreOid = StringUtils.isNotBlank(storeTemp[0])? storeTemp[0].trim():""; //id
				channelId = StringUtils.isNotBlank(storeTemp[1])? storeTemp[1].trim():""; //channelId
				areaId = StringUtils.isNotBlank(storeTemp[2])? storeTemp[2].trim():""; //areaId
				storeId = StringUtils.isNotBlank(storeTemp[3])? storeTemp[3].trim():""; //storeId
				
				if (StringUtils.isNotBlank(bcExchangeStoreOid)){
					//don't update
					detailStoreOidList.add(bcExchangeStoreOid);
				}else{
					//insert
					newVo = new BcExchangeStore();
					newVo.setCreator(userId);
					newVo.setCreatorName(userName);
					newVo.setCreateTime(sysdate);
					newVo.setModifier(userId);
					newVo.setModifierName(userName);
					newVo.setModifyTime(sysdate);
					newVo.setChannelId(channelId);
					newVo.setStoreId(storeId);
					newVo.setAreaId(areaId);
					newVo.setBcBonusSettingMst(master);
					detailStorehSet.add(newVo);
				}
			}
		}
		
		System.out.println("master.getBcExchangeStores() : " + master.getBcExchangeStores().size()) ;
		for(BcExchangeStore detail : master.getBcExchangeStores()){
			if (StringUtils.isNotBlank(detail.getOid())){
				detail.setBcBonusSettingMst(master);
				if(detailStoreOidList.indexOf(detail.getOid()) < 0){
					delStoreList.add(detail);
					System.out.println("del : " + detail.getChannelId()) ;
				}else{
					System.out.println("add : " + detail.getChannelId()) ;
					detailStorehSet.add(detail);
				}
			}
		}
		//update
		for(BcExchangeStore detail : detailStorehSet){
			for(BcStoreVo vo : bcStoreVoList){
				if(detail.getChannelId().equals(vo.getChannelId())){
					detail.setPerAmt(vo.getPerAmt());
					detail.setPerBonus(vo.getPerBonus());
					detail.setDisType(vo.getDisType());
					detail.setDisSku(vo.getDisSku());
					detail.setModifier(userId);
					detail.setModifierName(userName);
					detail.setModifyTime(sysdate);
					break;
				}
			}
		}
		master.setBcExchangeStores(detailStorehSet);
	}


	/**
	 * query BC_BONUS_SETTING_MST
	 * @param oid
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public BcBonusSettingMst getBcBonusCuml(String oid,String id)throws Exception{
		return this.getBcBonusCuml(oid, id, null) ;
	}
	
	/**
	 * query BC_BONUS_SETTING_MST
	 * @param oid
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public BcBonusSettingMst getBcBonusCuml(String oid,String id,List<BsChannel> channelIdList)throws Exception{
		BcBonusSettingVo  vo = new BcBonusSettingVo();
		vo.setOid(oid);
		vo.setPromotId(id);
		if(channelIdList != null) {
			List<String> temp = new ArrayList() ;
			for (BsChannel bsChannel : channelIdList) {
				temp.add(bsChannel.getChannelId()) ;
			}
			vo.setAuthChannelList(temp) ;
		}
		QueryResult queryList = getQueryList(vo, 0, Integer.MAX_VALUE, false,true);
		List<BcBonusSettingMst> list = queryList.getResult();
		if(list!=null && list.size()>0){
			BcBonusSettingMst master = (BcBonusSettingMst)list.get(0);
			//file init
			return master;
		}
		return null;
	}
	
	public BcBonusSettingMst getBcBonusCuml(String oid,String id,List<BsChannel> channelIdList,String companyId)throws Exception{
		BcBonusSettingVo  vo = new BcBonusSettingVo();
		vo.setOid(oid);
		vo.setPromotId(id);
		vo.setCompanyId(companyId);
		if(channelIdList != null) {
			List<String> temp = new ArrayList() ;
			for (BsChannel bsChannel : channelIdList) {
				temp.add(bsChannel.getChannelId()) ;
			}
			vo.setAuthChannelList(temp) ;
		}
		QueryResult queryList = getQueryList(vo, 0, Integer.MAX_VALUE, false,true);
		List<BcBonusSettingMst> list = queryList.getResult();
		if(list!=null && list.size()>0){
			BcBonusSettingMst master = (BcBonusSettingMst)list.get(0);
			//file init
			return master;
		}
		return null;
	}
	
	/**
	 * query BC_BONUS_SETTING_MST
	 * @param oid
	 * @return
	 * @throws Exception
	 */
	public BcBonusSettingMst getBcBonusCuml(String oid)throws Exception{
		return getBcBonusCuml(oid,null,null);
	}

	/**
	 *
	 * @param nowDate
	 * @param status {STATUS_CODE_1:生效}
	 * @param bcType {
	 * 			TYPE_CODE_0:紅利點數通用累積設定,
	 * 			TYPE_CODE_1:紅利點數商品累積設定,
	 * 			TYPE_CODE_2:紅利點數發票累積設定,
	 * 			TYPE_CODE_3:紅利點數發票倍率累積設定,
	 * 			TYPE_CODE_4:紅利點數商品及發票累積
	 * }
	 * @return
	 * @throws Exception
	 */
	public List<BcBonusSettingMst> getBcBonusActive(Date nowDate,String status,String bcType)throws Throwable{
		return getBcBonusActive(nowDate, status, bcType,true);
	}
	
	public List<BcBonusSettingMst> getBcBonusActive(Date nowDate,String status,String bcType,boolean includeCompanyId)throws Throwable{
		BcBonusSettingVo condition = new BcBonusSettingVo();
		if (nowDate!=null){
			condition.setErpActiveDate(DateTimeUtils.getFormatDateStr(nowDate));
			condition.setErpInactiveDate(DateTimeUtils.getFormatDateStr(nowDate));
		}
		if (StringUtils.isNotBlank(status)){
			condition.setStatus(Integer.valueOf(status));
		}
		if (StringUtils.isNotBlank(bcType)){
			condition.setBsType(Integer.valueOf(bcType));
		}
		return dao.findBcBonusCuml(condition, 0, Integer.MAX_VALUE, false, true,includeCompanyId);
	}


	/**
	 * 紅利點數通用累積設定排程
	 * @throws Exception
	 */
	public void processBonusGeneralScheduling()throws Exception{
		processExchangeScheduling(BcBonusService.TYPE_CODE_0,
				DateTimeUtils.getDate(DateTimeUtils.addDate(DateTimeUtils.getSysDate(), -1)));
	}

	/**
	 * 紅利點數商品累積設定排程
	 * @throws Exception
	 */
	public void processBonusSkuScheduling()throws Exception{
		processExchangeScheduling(BcBonusService.TYPE_CODE_1,
				DateTimeUtils.getDate(DateTimeUtils.addDate(DateTimeUtils.getSysDate(), -1)));
	}

	/**
	 * 紅利點數發票累積設定排程
	 * @throws Exception
	 */
	public void processBonusAmtScheduling()throws Exception{
		processExchangeScheduling(BcBonusService.TYPE_CODE_2,
				DateTimeUtils.getDate(DateTimeUtils.addDate(DateTimeUtils.getSysDate(), -1)));
	}

	/**
	 * 紅利點數發票倍數累積設定排程
	 * @throws Exception
	 */
	public void processBonusPercentAmtScheduling()throws Exception{
		processExchangeScheduling(BcBonusService.TYPE_CODE_3,
				DateTimeUtils.getDate(DateTimeUtils.addDate(DateTimeUtils.getSysDate(), -1)));
	}

	/**
	 * 紅利點數商品及發票累積設定排程
	 * @throws Exception
	 */
	public void processBonusItemAmtScheduling()throws Exception{
		processExchangeScheduling(BcBonusService.TYPE_CODE_4,
				DateTimeUtils.getDate(DateTimeUtils.addDate(DateTimeUtils.getSysDate(), -1)));
	}

	/**
	 * 紅利點數累積過期更新
	 * @param typeCode
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	private void processExchangeScheduling(String typeCode,String date)throws Exception{
		BcBonusSettingVo condition	= new BcBonusSettingVo();
		condition.setBsType(Integer.parseInt(typeCode));
		condition.setStatus(Integer.parseInt(BcBonusService.STATUS_CODE_1));
		condition.setInactiveDate(date);
		for (BsCompany bsCompany : BsCompanyDefinition.getList()) {
			condition.setCompanyId(bsCompany.getCompanyId()); 
			final List<BcBonusSettingMst> list = getDao().findBcBonusCuml(condition, 0, Integer.MAX_VALUE,Boolean.FALSE ,Boolean.FALSE);
			if (list!=null){
				try {
					transactionTemplate.execute(new TransactionCallback() {
						public Object doInTransaction(TransactionStatus txnStatus) {
							Boolean txnFail = false;
							try{
								//master
								for(BcBonusSettingMst vo:list){
									vo.setStatus(Integer.parseInt(BcBonusService.STATUS_CODE_2));
									vo.setModifier("SYS");
									vo.setModifierName("SYS");
									vo.setModifyTime(DateTimeUtils.getSysDate());
									getDao().updateObject(vo);
								}
							} catch(Exception ex) {
								txnFail = true;
								txnStatus.setRollbackOnly();
								throw new RuntimeException(ex);
							}
							return txnFail;
						}
					});
				}catch(Exception e){
					throw e ;
				}
			}
		}
	}
	
	public BcBonusSettingMst saveBcBonusCuml(
			BcBonusSettingMst vo,
			final String executeCode,
			String actionSubmitType,
			final List<BcStoreVo> bcStoreVoList,
			final String[] storeIdArray, 
			final List<BcBonusSettingDtl> bcExchangeDeskList, 
			final ScSysuser user) throws Exception{
		Timestamp sysdate = DateTimeUtils.getSysDate();
		final BcBonusSettingMst master;
		
		final Collection<Object> delStoreList = new ArrayList<Object>();
		Set<BcExchangeStore> detailStoreSet = new HashSet<BcExchangeStore>();
		ArrayList<String> detailStoreOidList = new ArrayList<String>();
		
		final Collection<Object> delDeskList = new ArrayList<Object>();
		Set<BcBonusSettingDtl> detailDeskSet = new HashSet<BcBonusSettingDtl>();
		ArrayList<String> detailDeskOidList = new ArrayList<String>();
		
		if (StringUtils.isBlank(vo.getOid())){
			// 新增
			master = vo;
			master.setBcBonusAmts(new HashSet<BcBonusSettingDtl>());
			master.setBcExchangeStores(new HashSet<BcExchangeStore>());
			master.setBsType(StringUtils.isNotBlank(actionSubmitType)? Integer.parseInt(actionSubmitType):null);
			master.setCreator(user.getUserId());
			master.setCreatorName(user.getUserName());
			master.setCreateTime(sysdate);
		}else{
			// 修改
			master = getBcBonusCuml(vo.getOid(), null, user.getAuthChannel());
			master.setModifyTime(sysdate);
			master.setModifier(user.getUserId());
			master.setModifierName(user.getUserName());
		}
		String companyId = StringUtils.isNotEmpty(BsCompanyDefinition.getCompanyId())?
				BsCompanyDefinition.getCompanyId():"";
		master.setCompanyId(companyId);
		
		if (STATUS_CODE_0.equals(executeCode) || STATUS_CODE_4.equals(executeCode)){
			// mster(BC_BONUS_SETTING_MST資料)
			BeanUtils.copyProperties(master, vo);
			processSaveExchangeStore(master, bcStoreVoList, storeIdArray, delStoreList, detailStoreSet, detailStoreOidList, user.getUserId(), user.getUserName(), sysdate);
			processSaveExchangeDesk(master, bcExchangeDeskList, delDeskList, detailDeskSet, detailDeskOidList, user.getUserId(), user.getUserName(), sysdate);
		}
		// 變更狀態
		master.setStatus((StringUtils.isBlank(executeCode))? Integer.parseInt(STATUS_CODE_0):(STATUS_CODE_1.equals(master.getStatus()) && STATUS_CODE_0.equals(executeCode)? Integer.parseInt(STATUS_CODE_1):Integer.parseInt(executeCode)));
		
		try{
			if (STATUS_CODE_2.equals(executeCode)){
				master.setExpDateT(DateTimeUtils.getDate(DateTimeUtils.getFormatDateStr(sysdate)));
			}else if (STATUS_CODE_1.equals(executeCode)){
				master.setDownloadDate(DateTimeUtils.getDate(DateTimeUtils.getFormatDateStr(sysdate)));
			}
		}catch(Throwable t){
			throw new Exception(t);
		}
		
		try {
			transactionTemplate.execute(new TransactionCallback() {
				public Object doInTransaction(TransactionStatus txnStatus) {
					Boolean txnFail = false;
					try{
						// 處理BC_BONUS_SETTING_MST(master)資料
						if (StringUtils.isBlank(master.getOid())){
							//get seq
							master.setPromotId(SerialService.getCategorySerial(SerialService.CATEGORY_BSC, SerialService.DATE_FORMAT_YYYYMM,3));
							getDao().insertObject(master);
						}else{
							getDao().updateObject(master);
						}
						
						if (STATUS_CODE_0.equals(executeCode) || STATUS_CODE_4.equals(executeCode)){
							// 處理BC_EXCHANGE_STORE資料
							System.out.println("BC_EXCHANGE_STORE size: " + master.getBcExchangeStores().size());
							for(BcExchangeStore detail : master.getBcExchangeStores()){
								detail.setRefOid(master.getOid());
								if (StringUtils.isBlank(detail.getOid())){
									getDao().insertObject(detail);
								}else{
									getDao().updateObject(detail);
								}
							}
							getDao().deleteCollection(delStoreList);
							
							// 處理BC_BONUS_SETTING_DTL資料
							System.out.println("BC_BONUS_SETTING_DTL size: " + master.getBcExchangeDesks().size());
							for(BcBonusSettingDtl detail : master.getBcExchangeDesks()){
								detail.setBcBonusSettingMst(master);
								if (StringUtils.isBlank(detail.getOid())){
									getDao().insertObject(detail);
								}else{
									getDao().updateObject(detail);
								}
							}
							getDao().deleteCollection(delDeskList);
						}
					} catch(Exception ex) {
						txnFail = true;
						txnStatus.setRollbackOnly();
						throw new RuntimeException(ex);
					}
					return txnFail;
				}
			});
		}catch(Exception e){
			throw e ;
		}
		
		return getBcBonusCuml(vo.getOid());
	}
	 
	public void processSaveExchangeDesk(
			BcBonusSettingMst master, 
			List<BcBonusSettingDtl> bcExchangeDeskList,
			Collection<Object> delDeskList, //刪除的
			Set<BcBonusSettingDtl> detailDeskSet, //增加的
			ArrayList<String> detailDeskOidList, //判斷的
			String userId, 
			String userName, 
			Timestamp sysdate)throws Exception{
		
		BcBonusSettingDtl newVo;
		for(BcBonusSettingDtl data : bcExchangeDeskList){
			if (data == null){
				continue;
			}
			if(StringUtils.isNotBlank(data.getOid())){
				detailDeskOidList.add(data.getOid());
			} else {
				newVo = new BcBonusSettingDtl();
				newVo.setCreateTime(sysdate);
				newVo.setCreator(userId);
				newVo.setCreatorName(userName);
				newVo.setModifyTime(sysdate);
				newVo.setModifier(userId);
				newVo.setModifierName(userName);
				newVo.setExBonus(data.getExBonus());
				newVo.setExSku(data.getExSku());
				newVo.setBonusType(data.getBonusType());
				newVo.setBcBonusSettingMst(master);
				detailDeskSet.add(newVo);
			}
		}
		
		System.out.println("BcExchangeDesks size = " + master.getBcExchangeDesks().size());
		for(BcBonusSettingDtl detail : master.getBcExchangeDesks()){
			if (StringUtils.isNotBlank(detail.getOid())){
				detail.setBcBonusSettingMst(master);
				if(detailDeskOidList.indexOf(detail.getOid()) < 0){
					delDeskList.add(detail);
				} else {
					detailDeskSet.add(detail);
				}
			}
		}

		master.setBcExchangeDesks(detailDeskSet);
	}
	
}
