package com.gccs.bc.service;

import java.util.Map;
import com.rfep.base.PageBean;
import com.rfep.base.QueryResultBean;


/**
 * @author Johnson
 * @Date: 2010/10/01 上午 13:00:00
 */
public interface BcMarketServiceI {
	
	/**
	 * 根據畫面的查詢條件,來做查詢動作
	 * @author Johnson
 	 * @Date: 2010/10/01 上午 13:00:00
	 * @param pageBean
	 * @param queryCondition
	 * @param isCount
	 * @param sqlFileName
	 * @param entityClass
	 * @return
	 * @throws Exception
	 */
	public QueryResultBean queryConditionBySQL(PageBean pageBean,
			Map<String, String> queryCondition, Boolean isCount,String sqlFileName,Class entityClass)
			throws Exception ;

}
