package com.gccs.bc.service;
    
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.jfree.util.Log;

import com.apeo.sender.model.MessageContent;
import com.bnq.util.DateUtils;
import com.bnq.util.mail.MailService;
import com.gccs.bc.dao.hibernate.BcSomMasterDao;
import com.gccs.bc.dao.hibernate.BcSomMasterTxtDao;
import com.gccs.bc.dao.hibernate.BcSomOrderDetlDao;
import com.gccs.bc.dao.hibernate.BcSomOrderDetlTxtDao;
import com.gccs.bc.dao.hibernate.BcSomPaymentDao;
import com.gccs.bc.dao.hibernate.BcSomPaymentTxtDao;
import com.gccs.bc.model.BcSomMainReq;
import com.gccs.bc.model.BcSomMaster;
import com.gccs.bc.model.BcSomMasterReq;
import com.gccs.bc.model.BcSomMasterTxt;
import com.gccs.bc.model.BcSomOrderDetl;
import com.gccs.bc.model.BcSomOrderDetlReq;
import com.gccs.bc.model.BcSomOrderDetlTxt;
import com.gccs.bc.model.BcSomPayment;
import com.gccs.bc.model.BcSomPaymentReq;
import com.gccs.bc.model.BcSomPaymentTxt;
import com.gccs.member.dao.hibernate.MemberWebInfoDAO;
import com.gccs.member.util.CalendarUtil;
import com.gccs.member.util.WebInfoUtil;

public class BcSomService  {
	private static final Logger log = LogManager.getLogger("somImport");
   
	private MemberWebInfoDAO memberWebInfoDao;
	
	private BcSomMasterTxtDao bcSomMasterTxtDao;
	
	private BcSomOrderDetlTxtDao bcSomOrderDetlTxtDao;
	
	private BcSomPaymentTxtDao bcSomPaymentTxtDao; 
	
	private BcSomMasterDao bcSomMasterDao;
	
	private BcSomOrderDetlDao bcSomOrderDetlDao;
	
	private BcSomPaymentDao bcSomPaymentDao;
	 
	//測試用, 暫時改成本機的路徑
//	public static String PATH = "/Users/chungjuisun/oradata/oms/crm/SOM";
	public static String PATH = ResourceBundle.getBundle("crmCommon").getString("BcSomFile.Path");
	
	public static String SUCCESS_PATH = String.format("%s/SUCCESS", PATH);
	
	public static String FAIL_PATH = String.format("%s/FAIL", PATH);

	public static final String MASTER_FILENAME = "SOM_ORDER_MASTER";  
	
	public static final String DETEL_FILENAME = "SOM_ORDER_DETL";  
	
	public static final String PAYMENT_FILENAME = "SOM_PAYMENT";
	
	
	public void importExecute(boolean isFromWeb) {
		try{   
			
			List<BcSomMainReq> reqList = getReq();
			
			
			//寫入暫存TABLE
			for(BcSomMainReq mainReq : reqList) {  
				List<BcSomMasterReq> masterReqList = mainReq.getMasterReqList();
				List<BcSomOrderDetlReq> orderDetlReqList = mainReq.getOrderDetlReqList();
				List<BcSomPaymentReq> paymentReqList = mainReq.getPaymentReqList();
				
				mainReq.setStartDate(WebInfoUtil.getFormatDate());
				  
				switch(mainReq.getType()) { 
					case 1:
						int masterCnt = 1;
						bcSomMasterTxtDao.deleteByFileName(mainReq.getFileName());
				 		for(BcSomMasterReq masterReq : masterReqList) {
				 			BcSomMasterTxt po = new BcSomMasterTxt(); 
				 			
				 			//設定行數
				 			masterReq.setIdx(masterCnt++);
				 			
				 			if(masterReq.hasError()) {
				 				continue;
				 			}
				 			
				 			po.setOrderId(masterReq.getOrderId());
				 			po.setChannelId(masterReq.getChannelId());
				 			po.setStoreId(masterReq.getStoreId());
				 			po.setOrderStatusId(masterReq.getOrderStatusId());
				 			po.setMemberCardId(masterReq.getMemberCardId());
				 			po.setMasterOrderPrice(masterReq.getMasterOrderPrice());
				 			po.setMasterPayAmount(masterReq.getMasterPayAmount());
				 			po.setUpdateDate(DateUtils.addDay(masterReq.getUpdateDate(), -1));
				 			po.setFileName(masterReq.getFileName());
				 			po.setFileDate(masterReq.getFileDate());
				 			po.setCloseDate(masterReq.getCloseDate());
				 			po.setSaleSource(masterReq.getSaleSource());
				 			 
							bcSomMasterTxtDao.save(po);
						}
				 	break;		
					case 2: 
						int detlCnt = 1;
						bcSomOrderDetlTxtDao.deleteByFileName(mainReq.getFileName());
				 		for(BcSomOrderDetlReq detlReq : orderDetlReqList) {
				 			BcSomOrderDetlTxt po = new BcSomOrderDetlTxt(); 
				 			
				 			//設定行數
				 			detlReq.setIdx(detlCnt++);
				 			
				 			if(detlReq.hasError()) {
				 				continue;
				 			}
				 			
				 			po.setOrderId(detlReq.getOrderId()); 
				 			po.setTransDate(detlReq.getTransDate());
				 			po.setChannelId(detlReq.getChannelId());
				 			po.setStoreId(detlReq.getStoreId());
				 			po.setOrderStatusId(detlReq.getOrderStatusId());
				 			po.setType(detlReq.getType());
				 			po.setOrderTotalPrice(detlReq.getOrderTotalPrice());
				 			po.setMemberCardId(detlReq.getMemberCardId());
				 			po.setDetlSeqId(detlReq.getDetlSeqId());
				 			po.setSkuNo(detlReq.getSkuNo());
				 			po.setNskuFlag(detlReq.getNskuFlag());
				 			po.setNskuDetlSeqId(detlReq.getNskuDetlSeqId());
				 			po.setSubDeptId(detlReq.getSubDeptId());
				 			po.setClassId(detlReq.getClassId());
				 			po.setSubClassId(detlReq.getSubClassId());
				 			po.setTaxType(detlReq.getTaxType());
				 			po.setQuantity(detlReq.getQuantity());
				 			po.setActPosAmt(detlReq.getActPosAmt());
				 			po.setTotalPrice(detlReq.getTotalPrice());
				 			po.setUpdateDate(DateUtils.addDay(detlReq.getUpdateDate(), -1));
				 			po.setSkuName(detlReq.getSkuName());
				 			po.setFileName(detlReq.getFileName());
				 			po.setFileDate(detlReq.getFileDate());
				 			po.setPosSeqNo(detlReq.getPosSeqNo());
				 			 
							bcSomOrderDetlTxtDao.save(po);
						}
					break;
					case 3:
						int payMentCnt = 1;
						bcSomPaymentTxtDao.deleteByFileName(mainReq.getFileName());
				 		for(BcSomPaymentReq paymentReq : paymentReqList) {
				 			BcSomPaymentTxt po = new BcSomPaymentTxt(); 
				 			
				 			//設定行數
				 			paymentReq.setIdx(payMentCnt++);
				 			
				 			if(paymentReq.hasError()) {
				 				continue;
				 			}
				 			
				 			po.setOrderId(paymentReq.getOrderId()); 
				 			po.setTransDate(paymentReq.getTransDate());
				 			po.setGuiDate(paymentReq.getGuiDate());
				 			
				 			po.setChannelId(paymentReq.getChannelId());
				 			po.setStoreId(paymentReq.getStoreId());
				 			po.setMemberCardId(paymentReq.getMemberCardId());
				 			po.setGuiNo(paymentReq.getGuiNo());
				 			po.setRefundId(paymentReq.getRefundId());
				 			po.setType(paymentReq.getType());
				 			po.setStatus(paymentReq.getStatus());
				 			po.setPosNo(paymentReq.getPosNo());
				 			po.setPosSeqNo(paymentReq.getPosSeqNo());
				 			po.setTaxTotal(paymentReq.getTaxTotal());
				 			po.setSalesTotal(paymentReq.getSalesTotal());
				 			po.setUpdateDate(DateUtils.addDay(paymentReq.getUpdateDate(), -1));
				 			po.setFileName(paymentReq.getFileName());
				 			po.setFileDate(paymentReq.getFileDate());
				 			 
							bcSomPaymentTxtDao.save(po);
						}
					break;
					default: break;
				} 
		 		
		 		mainReq.setEndDate(WebInfoUtil.getFormatDate());
		 		

			}
			

			//轉入正式TABLE
			
			//先寫入master
			for(BcSomMainReq mainReq : reqList) {  
				if(!mainReq.hasError() && !mainReq.isCheckDataError()){
					switch(mainReq.getType()) { 
						case 1:
							int masterSuccess = 0; 
							String fileSuffix = mainReq.getFileName();
							fileSuffix = fileSuffix.substring(fileSuffix.lastIndexOf("_"));
							List<Map<String,Object>> bcSomMasterTxtList = bcSomMasterTxtDao.findAndSumAmt(mainReq.getFileName(),DETEL_FILENAME + fileSuffix ,PAYMENT_FILENAME + fileSuffix);
							for(Map<String,Object> bcSomMasterTxt : bcSomMasterTxtList ){
								BcSomMaster bcSomMaster = null;
								List<BcSomMaster> list = bcSomMasterDao.findByPk((String)bcSomMasterTxt.get("ORDER_ID"));
								if(list.size() > 0){
									bcSomMaster = list.get(0);
									SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
									bcSomMaster.setUpdateDate(DateUtils.addDay(sdf.parse(mainReq.getDate()), -1));
									bcSomMaster.setCulmBonusYn(null);//更新是否已計算品類贈點標記
								}else{
									bcSomMaster = new BcSomMaster();
									bcSomMaster.setOrderId((String)bcSomMasterTxt.get("ORDER_ID"));
									bcSomMaster.setCreateDate(new Date());
									SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
									bcSomMaster.setUpdateDate(DateUtils.addDay(sdf.parse(mainReq.getDate()), -1));
								}
								bcSomMaster.setOrderStatusId((String)bcSomMasterTxt.get("ORDER_STATUS_ID"));
								bcSomMaster.setMemberCardId((String)bcSomMasterTxt.get("MEMBER_CARD_ID"));
								bcSomMaster.setMasterOrderPrice((BigDecimal)bcSomMasterTxt.get("MASTER_ORDER_PRICE"));
								bcSomMaster.setMasterPayAmount((BigDecimal)bcSomMasterTxt.get("MASTER_PAY_AMOUNT"));
								bcSomMaster.setCloseDate((Date)bcSomMasterTxt.get("CLOSE_DATE"));
								bcSomMaster.setSaleSource((String)bcSomMasterTxt.get("SALE_SOURCE"));
								bcSomMaster.setStoreId((String)bcSomMasterTxt.get("STORE_ID"));
								
								bcSomMasterDao.saveOrUpdateObject(bcSomMaster);
								masterSuccess++;
							}
							mainReq.setCrmCount(masterSuccess);
						break;	
						default: break;	
					}
					mainReq.setEndDate(WebInfoUtil.getFormatDate());
				}

			}
			
			
			//寫入detail
			for(BcSomMainReq mainReq : reqList) {  
				List<String> errorMsg = new ArrayList<String>();
				if(!mainReq.hasError() && !mainReq.isCheckDataError()){
					switch(mainReq.getType()) { 
						case 2:
							int detlSuccess = 0;
							List<BcSomOrderDetlTxt> bcSomOrderDetlTxtList = bcSomOrderDetlTxtDao.findByImportFileName(mainReq.getFileName());
							for(BcSomOrderDetlTxt bcSomOrderDetlTxt : bcSomOrderDetlTxtList ){
								//檢查訂單號碼是否存在Master，沒有就不寫入
								List<BcSomMaster> mstList = bcSomMasterDao.findByPk(bcSomOrderDetlTxt.getOrderId());
								if(mstList.size() == 0){
									errorMsg.add("訂單號碼不存在Master，訂單號碼=" + bcSomOrderDetlTxt.getOrderId());
									mainReq.setCheckDataError(true);
									continue;
								}
								BcSomMaster master = mstList.get(0);
								
								BcSomOrderDetl bcSomOrderDetl = null;
								String posSeqNo = null;
								if("N".equals(bcSomOrderDetlTxt.getType()) || "VN".equals(bcSomOrderDetlTxt.getType())){
									posSeqNo = bcSomOrderDetlTxt.getDetlSeqId();
								}else if("B".equals(bcSomOrderDetlTxt.getType()) || "VB".equals(bcSomOrderDetlTxt.getType())){
									posSeqNo = bcSomOrderDetlTxt.getPosSeqNo();
								}
								List<BcSomOrderDetl> list = bcSomOrderDetlDao.findByPk(bcSomOrderDetlTxt.getOrderId(), bcSomOrderDetlTxt.getDetlSeqId(),bcSomOrderDetlTxt.getType(),bcSomOrderDetlTxt.getTransDate(),posSeqNo);
								if(list.size() > 0){
									bcSomOrderDetl = list.get(0);
									SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
									bcSomOrderDetl.setUpdateDate(DateUtils.addDay(sdf.parse(mainReq.getDate()), -1));
									// 若為null, 初始化為0
									if (master.getCulmOrderPrice() == null) {
										master.setCulmOrderPrice(new BigDecimal(0));
									}
									
									//加總金額存入master
								    master.setCulmOrderPrice(master.getCulmOrderPrice().subtract(bcSomOrderDetl.getTotalPrice()).add(bcSomOrderDetlTxt.getTotalPrice()));

								}else{
									bcSomOrderDetl = new BcSomOrderDetl();
									bcSomOrderDetl.setOrderId(bcSomOrderDetlTxt.getOrderId());
									bcSomOrderDetl.setDetlSeqId(bcSomOrderDetlTxt.getDetlSeqId());
									bcSomOrderDetl.setCreateDate(new Date());
									SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
									bcSomOrderDetl.setUpdateDate(DateUtils.addDay(sdf.parse(mainReq.getDate()), -1));
									//加總金額存入master
									if(master.getCulmOrderPrice() == null)
										master.setCulmOrderPrice(bcSomOrderDetlTxt.getTotalPrice());
									else
										master.setCulmOrderPrice(master.getCulmOrderPrice().add(bcSomOrderDetlTxt.getTotalPrice()));
								}
								
								bcSomOrderDetl.setStoreId(bcSomOrderDetlTxt.getStoreId());
								bcSomOrderDetl.setOrderStatusId(bcSomOrderDetlTxt.getOrderStatusId());
								bcSomOrderDetl.setType(bcSomOrderDetlTxt.getType());
								bcSomOrderDetl.setTransDate(bcSomOrderDetlTxt.getTransDate());
								bcSomOrderDetl.setSkuNo(bcSomOrderDetlTxt.getSkuNo());
								bcSomOrderDetl.setSkuName(bcSomOrderDetlTxt.getSkuName());
								bcSomOrderDetl.setSubDeptId(bcSomOrderDetlTxt.getSubDeptId());
								bcSomOrderDetl.setClassId(bcSomOrderDetlTxt.getClassId());
								bcSomOrderDetl.setSubClassId(bcSomOrderDetlTxt.getSubClassId());
								bcSomOrderDetl.setTaxType(bcSomOrderDetlTxt.getTaxType());
								bcSomOrderDetl.setQuantity(bcSomOrderDetlTxt.getQuantity());
								bcSomOrderDetl.setActPosAmt(bcSomOrderDetlTxt.getActPosAmt());
								bcSomOrderDetl.setTotalPrice(bcSomOrderDetlTxt.getTotalPrice());
								bcSomOrderDetl.setNskuFlag(bcSomOrderDetlTxt.getNskuFlag());
								bcSomOrderDetl.setNskuDetlSeqId(bcSomOrderDetlTxt.getNskuDetlSeqId());
								bcSomOrderDetl.setSource(bcSomOrderDetlTxt.getFileName().replace("SOM_", "").replace(".txt", ""));
								bcSomOrderDetl.setPosSeqNo(posSeqNo);
								
								
								bcSomOrderDetlDao.saveOrUpdateObject(bcSomOrderDetl);
								bcSomMasterDao.saveOrUpdateObject(master);
								detlSuccess++;
							}
							mainReq.setCrmCount(detlSuccess);
						break;	
						default: break;	
					}
					mainReq.setErrorMsg(errorMsg);
					mainReq.setEndDate(WebInfoUtil.getFormatDate());
				}

			}
			
			
			//再寫入payment
			for(BcSomMainReq mainReq : reqList) {  
				List<String> errorMsg = new ArrayList<String>();
				if(!mainReq.hasError()&& !mainReq.isCheckDataError()){
					switch(mainReq.getType()) { 
						case 3:	
							int payMentSuccess = 0; 
							List<Map<String,Object>> bcSomPaymentTxtList = bcSomPaymentTxtDao.findByImportFileName(mainReq.getFileName());
							for(Map<String,Object> bcSomPaymentTxt:bcSomPaymentTxtList){
								//檢查訂單號碼是否存在Master，沒有就不寫入
								List<BcSomMaster> mstList = bcSomMasterDao.findByPk((String)bcSomPaymentTxt.get("ORDER_ID"));
								if(mstList.size() == 0){
									errorMsg.add("訂單號碼不存在Master，訂單號碼=" + (String)bcSomPaymentTxt.get("ORDER_ID"));
									mainReq.setCheckDataError(true);
									continue;
								}
								BcSomMaster master = mstList.get(0);
								BcSomPayment bcSomPayment = null;
								List<BcSomPayment> list = bcSomPaymentDao.findByPk((String)bcSomPaymentTxt.get("ORDER_ID"), (Date)bcSomPaymentTxt.get("TRANS_DATE"), 
										(String)bcSomPaymentTxt.get("STORE_ID"), (String)bcSomPaymentTxt.get("POS_NO"), (String)bcSomPaymentTxt.get("POS_SEQ_NO"));
								if(list.size() > 0){
									bcSomPayment = list.get(0);
									SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
									bcSomPayment.setUpdateDate(DateUtils.addDay(sdf.parse(mainReq.getDate()), -1));
									//加總金額存入master
									master.setCulmPayAmount(master.getCulmPayAmount().subtract(bcSomPayment.getSalesTotal()).add((BigDecimal)bcSomPaymentTxt.get("SALES_TOTAL")));
								}else{
									bcSomPayment = new BcSomPayment();
									bcSomPayment.setOrderId((String)bcSomPaymentTxt.get("ORDER_ID"));
									bcSomPayment.setTransDate((Date)bcSomPaymentTxt.get("TRANS_DATE"));
									bcSomPayment.setStoreId((String)bcSomPaymentTxt.get("STORE_ID"));
									bcSomPayment.setPosNo((String)bcSomPaymentTxt.get("POS_NO"));
									bcSomPayment.setPosSeqNo((String)bcSomPaymentTxt.get("POS_SEQ_NO"));
									SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
									bcSomPayment.setUpdateDate(DateUtils.addDay(sdf.parse(mainReq.getDate()), -1));
									//加總金額存入master
									if(master.getCulmPayAmount() == null)
										master.setCulmPayAmount((BigDecimal)bcSomPaymentTxt.get("SALES_TOTAL"));
									else
										master.setCulmPayAmount(master.getCulmPayAmount().add((BigDecimal)bcSomPaymentTxt.get("SALES_TOTAL")));
								}
								
								bcSomPayment.setGuiDate((Date)bcSomPaymentTxt.get("GUI_DATE"));
								bcSomPayment.setChannelId((String)bcSomPaymentTxt.get("CHANNEL_ID"));
								bcSomPayment.setMemberCardId((String)bcSomPaymentTxt.get("MEMBER_CARD_ID"));
								bcSomPayment.setGuiNo((String)bcSomPaymentTxt.get("GUI_NO"));
								bcSomPayment.setRefundId((String)bcSomPaymentTxt.get("REFUND_ID"));
								bcSomPayment.setType((String)bcSomPaymentTxt.get("TYPE"));
								bcSomPayment.setStatus((String)bcSomPaymentTxt.get("STATUS"));
								bcSomPayment.setTaxTotal((BigDecimal)bcSomPaymentTxt.get("TAX_TOTAL"));
								bcSomPayment.setSalesTotal((BigDecimal)bcSomPaymentTxt.get("SALES_TOTAL"));
								bcSomPayment.setSomMasterOid((String)bcSomPaymentTxt.get("SOM_MASTER_OID"));
								
								bcSomPaymentDao.saveOrUpdateObject(bcSomPayment);
								bcSomMasterDao.saveOrUpdateObject(master);
								payMentSuccess++;
							}
							mainReq.setCrmCount(payMentSuccess);
						break;	
						default: break;	
					}
					mainReq.setErrorMsg(errorMsg);
					mainReq.setEndDate(WebInfoUtil.getFormatDate());
				}
				
		 		if(mainReq.isStatusSuccess()) {
		 			// move to success dir
		 			copyToDir(SUCCESS_PATH, mainReq.getFileName());
		 		} else {
		 			copyToDir(FAIL_PATH, mainReq.getFileName());
		 		}

			}	
			
			if(!reqList.isEmpty()) {
				sendMail(reqList); 
			}
			
		}catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		}
	}
	
	private void copyToDir(String newPath, String fileName) {
		try{
			 File file = new File(PATH + "/" + fileName);
			 
			 file.renameTo(new File(newPath + "/" + file.getName()));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}
	
	private String getFileNameType(String fileName) {
		String result = "";
		
		if(fileName.indexOf(MASTER_FILENAME) != -1) {
			result = "master";
		} else if(fileName.indexOf(DETEL_FILENAME) != -1) {
			result = "detel";
		} else if(fileName.indexOf(PAYMENT_FILENAME) != -1) {
			result = "payment";
		}
		return result;
	}
	
	private List<BcSomMainReq> getReq() throws Exception{
		Map<String, List<String>> fileMap = readFile();
		List<BcSomMainReq> result = new ArrayList<BcSomMainReq>();
		
		Iterator iter = fileMap.keySet().iterator();
		while(iter.hasNext()) {
			String key = (String)iter.next();
			
			List<String> fileDataList = fileMap.get(key);
			
			BcSomMainReq mainReq = new BcSomMainReq(); 
			mainReq.setFileName(key);

			List<BcSomMasterReq> masterReqList = new LinkedList<BcSomMasterReq>();
			List<BcSomOrderDetlReq> orderDetlReqList = new LinkedList<BcSomOrderDetlReq>();
			List<BcSomPaymentReq> paymentReqList = new LinkedList<BcSomPaymentReq>();
			 
			String type = getFileNameType(key);
			log.debug("PARSING SOM FILE=" + key);
		 
			for(int i = 0; i < fileDataList.size(); i++) {
				String str = fileDataList.get(i);
				
				if(i == 0) {
					String[] mainAry = str.split("\t", 100);
					mainReq.setDate(mainAry[0]);
					mainReq.setCount(Integer.parseInt(mainAry[1]));
					if(type.equals("master")) {
						mainReq.setType(BcSomMainReq.TYPE_MASTER);
					} else if(type.equals("detel")) {
						mainReq.setType(BcSomMainReq.TYPE_ORDERDETL);
					} else if(type.equals("payment")) {
						mainReq.setType(BcSomMainReq.TYPE_PAYMENT);
					}
				} else {
					String[] bodyAry = str.split("\t", 100);
					
					if(type.equals("master")) {
						BcSomMasterReq masterReq = new BcSomMasterReq();
						
						if(bodyAry.length != 10) {
							masterReq.recordCntError();
							masterReqList.add(masterReq);
							continue;
						}

						masterReq.setOrderId(bodyAry[0]);
						masterReq.setChannelId(bodyAry[1]);
						masterReq.setStoreId(bodyAry[2]);
						masterReq.setOrderStatusId(bodyAry[3]);
						masterReq.setMemberCardId(bodyAry[4]);
						masterReq.setMasterOrderPrice(new BigDecimal(bodyAry[5]));
						masterReq.setMasterPayAmount(new BigDecimal(bodyAry[6]));
						masterReq.setUpdateDate(CalendarUtil.stringToDate(bodyAry[7], "yyyyMMdd"));
						masterReq.setFileName(key);
						masterReq.setFileDate(new Date());
						if (bodyAry[8].length() > 0)
							masterReq.setSaleSource(bodyAry[8]);
						if (bodyAry[9].length() > 0)
							masterReq.setCloseDate(CalendarUtil.stringToDate(bodyAry[9], "yyyyMMdd"));
						  
						masterReq.check();
						
						masterReqList.add(masterReq);
						
					} else if(type.equals("detel")) {
						BcSomOrderDetlReq orderDetlReq = new BcSomOrderDetlReq();
						
						if(bodyAry.length != 22) {
							orderDetlReq.recordCntError();
							orderDetlReqList.add(orderDetlReq);
							continue;
						}

						orderDetlReq.setOrderId(bodyAry[0]); 
						orderDetlReq.setTransDate(CalendarUtil.stringToDate(bodyAry[1], "yyyyMMdd")); 
						orderDetlReq.setChannelId(bodyAry[2]); 
						orderDetlReq.setStoreId(bodyAry[3]); 
						orderDetlReq.setOrderStatusId(bodyAry[4]); 
						orderDetlReq.setType(bodyAry[5]); 
						orderDetlReq.setOrderTotalPrice(new BigDecimal(bodyAry[6])); 
						orderDetlReq.setMemberCardId(bodyAry[7]); 
						orderDetlReq.setDetlSeqId(bodyAry[8]); 
						orderDetlReq.setSkuNo(bodyAry[9]); 
						orderDetlReq.setNskuFlag(bodyAry[10]); 
						orderDetlReq.setNskuDetlSeqId(bodyAry[11]); 
						orderDetlReq.setSubDeptId(bodyAry[12]); 
						orderDetlReq.setClassId(bodyAry[13]); 
						orderDetlReq.setSubClassId(bodyAry[14]); 
						orderDetlReq.setTaxType(bodyAry[15]); 
						
						orderDetlReq.setQuantity(new BigDecimal(bodyAry[16])); 
						orderDetlReq.setActPosAmt(new BigDecimal(bodyAry[17])); 
						orderDetlReq.setTotalPrice(new BigDecimal(bodyAry[18])); 
						orderDetlReq.setUpdateDate(CalendarUtil.stringToDate(bodyAry[19], "yyyyMMdd")); 
						orderDetlReq.setSkuName( bodyAry[20]); 
						orderDetlReq.setPosSeqNo(bodyAry[21]);
						orderDetlReq.setFileName(key);
						orderDetlReq.setFileDate(new Date());
						  
						orderDetlReq.check();
						
						orderDetlReqList.add(orderDetlReq);
						
						
					} else if(type.equals("payment")) {
						BcSomPaymentReq paymentReq = new BcSomPaymentReq();
						
						if(bodyAry.length != 15) {
							paymentReq.recordCntError();
							paymentReqList.add(paymentReq);
							continue;
						}

						paymentReq.setOrderId(bodyAry[0]); 
						paymentReq.setTransDate(CalendarUtil.stringToDate(bodyAry[1], "yyyyMMdd"));
						paymentReq.setGuiDate(CalendarUtil.stringToDate(bodyAry[2], "yyyyMMdd"));
						paymentReq.setChannelId(bodyAry[3]);
						paymentReq.setStoreId(bodyAry[4]);
						paymentReq.setMemberCardId(bodyAry[5]);
						paymentReq.setGuiNo(bodyAry[6]);
						paymentReq.setRefundId(bodyAry[7]);
						paymentReq.setType(bodyAry[8]);
						paymentReq.setStatus(bodyAry[9]);
						paymentReq.setPosNo(bodyAry[10]);
						paymentReq.setPosSeqNo(bodyAry[11]);
						paymentReq.setTaxTotal(new BigDecimal(bodyAry[12]));
						paymentReq.setSalesTotal(new BigDecimal(bodyAry[13]));
						paymentReq.setUpdateDate(CalendarUtil.stringToDate(bodyAry[14], "yyyyMMdd"));
						paymentReq.setFileName(key);
						paymentReq.setFileDate(new Date());
						
						paymentReq.check(); 
						
						paymentReqList.add(paymentReq);
					} 
				}
			}
			mainReq.setMasterReqList(masterReqList);
			mainReq.setOrderDetlReqList(orderDetlReqList);
			mainReq.setPaymentReqList(paymentReqList);
			
			result.add(mainReq);
		}
		return result;
	} 
	
	private Map<String, List<String>> readFile() {
		Map<String, List<String>> result = new HashMap<String, List<String>>();
		try { 
			List<String> fileList = getFileList(PATH); 
			for(String fileName : fileList) {
				List<String> list = new LinkedList<String>(); 
				 
				
				BufferedReader in = new BufferedReader(
				           new InputStreamReader(
				                      new FileInputStream(new File(PATH + "/" + fileName)), "UTF-8"));
				
				String s = "";
				while ((s = in.readLine()) != null){  
					list.add(s);
				}
				in.close(); 
				
				result.put(fileName, list);
			}
		} catch(IOException e) {
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
		return result;
	}
	
	public static List<String> getFileList(String folderPath){
		List<String> fileList = new ArrayList<String>();
		try{
			File folder = new File(folderPath);
			String[] list = folder.list();           
			for(int i = 0; i < list.length; i++){
				File tempFile = new File(PATH + "/" + list[i]);
				
				if(tempFile.isFile() && (list[i].indexOf(MASTER_FILENAME) > -1 || list[i].indexOf(DETEL_FILENAME) > -1 || list[i].indexOf(PAYMENT_FILENAME) > -1)) {
					fileList.add(list[i]);
				}
			}
		} catch(Exception e) { 
             
		} 
		return fileList;
	} 
	 
	private void sendMail(List<BcSomMainReq> req) {
		try {
			//取得郵件收件人列表
			String userMail = getMailData();
			
			//組織郵件內文
			MessageContent content = new MessageContent();
			content.setSubject("SOM明細檔匯入");
			String mailContent = getImportMailContent(req);
			content.setContent(mailContent);
			//增加附件內容
			List attachments = new ArrayList();
			//送出郵件
			MailService.sendMessage(content.getContent(), content.getSubject(), userMail, "", attachments);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public String getImportMailContent(List<BcSomMainReq> reqList){
		MessageFormat contentFormat = new MessageFormat(
				"<html><body>{0}</body></html>");
		
		String tableHtml = 
				"[fileName]<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" width=\"90%\" align=\"center\">"
			    + "<tr><td>轉檔執行程式</td><td>起始時間</td><td>結束時間</td><td>狀態</td><td>檔案筆數</td><td>CRM筆數</td></tr>"
				+ "<tr><td>SOM匯入明細檔</td><td>[startDate]</td><td>[endDate]</td><td>[status]</td><td>[count]</td><td>[crmCount]</td></tr></table>"
				+ "<br><table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" width=\"90%\" align=\"center\"  style='display:[style]'>"
				+ "<tr><td>錯誤行數</td><td>錯誤內容描述</td></tr>"
				+ "[errMsg]</table>";
		
		String innerHtml = "<tr><td>%d</td><td>%s</td></tr>";
		String innerHtml2 = "<tr><td></td><td>%s</td></tr>";
		
		String html = "";
		for(BcSomMainReq req : reqList) { 
			List<BcSomMasterReq> masterReqList = req.getMasterReqList();
			List<BcSomOrderDetlReq> orderDetlReqList = req.getOrderDetlReqList();
			List<BcSomPaymentReq> paymentReqList = req.getPaymentReqList();
			
			String subHtml = "";
			for(BcSomMasterReq subReq : masterReqList) {
				if(subReq.hasError()) {
					subHtml += String.format(innerHtml, subReq.getIdx(), subReq.getErrMsg().toString());
				}
			}
			for(BcSomOrderDetlReq subReq : orderDetlReqList) {
				if(subReq.hasError()) {
					subHtml += String.format(innerHtml, subReq.getIdx(), subReq.getErrMsg().toString());
				}
			}
			for(BcSomPaymentReq subReq : paymentReqList) {
				if(subReq.hasError()) {
					subHtml += String.format(innerHtml, subReq.getIdx(), subReq.getErrMsg().toString());
				}
			}
			
			List<String> errorMsg = req.getErrorMsg();
			
			for(String errorStr : errorMsg){
				subHtml += String.format(innerHtml2, errorStr);;
			}
			
			html +=
					tableHtml.replace("[fileName]", req.getFileName())
							.replace("[startDate]", req.getStartDate())
							.replace("[endDate]", req.getEndDate())
							.replace("[status]", req.getStatus())
							.replace("[count]", String.valueOf(req.getCount()))
							.replace("[crmCount]", String.valueOf(req.getCrmCount()))
							.replace("[style]", req.hasError() ? "block" : "none")
							.replace("[errMsg]", req.hasError() ? subHtml : "");
				
		}
		
		String[] parameter = new String[1] ;
		parameter[0] = html ;
		
		return contentFormat.format(parameter) ;
	}
	
	private String getMailData() {
		List<Map<String,Object>> list = memberWebInfoDao.queryEmailList();
		
		StringBuffer mailTo = new StringBuffer(); 
		try{
			Map<String,String> userEmails = new HashMap<String,String>(); //key=email, value=userName
			_addUserEmails(userEmails, list);
		
			for(String email : userEmails.keySet()){
				mailTo.append(",").append(email);
			}
		
			if(mailTo.length()>0){
				mailTo.deleteCharAt(0);
			}
			
		}catch(Exception e){
			e.printStackTrace();
			Log.error(e.getMessage());
		}
		return mailTo.toString();
	}

	private void _addUserEmails(Map<String,String> userEmails, List<Map<String, Object>> mailList){
		if(mailList==null) return;
		
		for(Map<String, Object> vo : mailList){
			if(StringUtils.isBlank((String)vo.get("E_MAIL"))) {
				continue;
			}
			userEmails.put((String)vo.get("E_MAIL"), (String)vo.get("E_MAIL"));
		}
	}   
	
	
	public MemberWebInfoDAO getMemberWebInfoDao() {
		return memberWebInfoDao;
	}

	public void setMemberWebInfoDao(MemberWebInfoDAO memberWebInfoDao) {
		this.memberWebInfoDao = memberWebInfoDao;
	}

	public BcSomMasterTxtDao getBcSomMasterTxtDao() {
		return bcSomMasterTxtDao;
	}

	public void setBcSomMasterTxtDao(BcSomMasterTxtDao bcSomMasterTxtDao) {
		this.bcSomMasterTxtDao = bcSomMasterTxtDao;
	}

	public BcSomOrderDetlTxtDao getBcSomOrderDetlTxtDao() {
		return bcSomOrderDetlTxtDao;
	}

	public void setBcSomOrderDetlTxtDao(BcSomOrderDetlTxtDao bcSomOrderDetlTxtDao) {
		this.bcSomOrderDetlTxtDao = bcSomOrderDetlTxtDao;
	}

	public BcSomPaymentTxtDao getBcSomPaymentTxtDao() {
		return bcSomPaymentTxtDao;
	}

	public void setBcSomPaymentTxtDao(BcSomPaymentTxtDao bcSomPaymentTxtDao) {
		this.bcSomPaymentTxtDao = bcSomPaymentTxtDao;
	}

	public void setBcSomMasterDao(BcSomMasterDao bcSomMasterDao) {
		this.bcSomMasterDao = bcSomMasterDao;
	}

	public BcSomMasterDao getBcSomMasterDao() {
		return bcSomMasterDao;
	}

	public void setBcSomOrderDetlDao(BcSomOrderDetlDao bcSomOrderDetlDao) {
		this.bcSomOrderDetlDao = bcSomOrderDetlDao;
	}

	public BcSomOrderDetlDao getBcSomOrderDetlDao() {
		return bcSomOrderDetlDao;
	}

	public void setBcSomPaymentDao(BcSomPaymentDao bcSomPaymentDao) {
		this.bcSomPaymentDao = bcSomPaymentDao;
	}

	public BcSomPaymentDao getBcSomPaymentDao() {
		return bcSomPaymentDao;
	} 
}
