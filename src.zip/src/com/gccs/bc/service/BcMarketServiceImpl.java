package com.gccs.bc.service;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gccs.bc.model.BcMarket;
import com.rfep.base.BaseServiceImpl;
import com.rfep.base.BaseUtil;
import com.rfep.base.PageBean;
import com.rfep.base.QueryResultBean;

/**
 * @author Johnson
 * @Date: 2010/10/01 上午 13:00:00
 */
public class BcMarketServiceImpl extends BaseServiceImpl<BcMarket> implements BcMarketServiceI{

	private static final Logger log = LogManager.getLogger(BcMarketServiceImpl.class) ;
	public QueryResultBean queryConditionBySQL(PageBean pageBean,
			Map<String, String> queryCondition, Boolean isCount,String sqlFileName,Class entityClass)
			throws Exception {
		// 查詢條件
		StringBuilder textFile = new StringBuilder(BaseUtil.readTextFile(sqlFileName));
		StringBuilder W0=new StringBuilder();
		String id = BaseUtil.getMapValueToString(queryCondition, "id");
		if (StringUtils.isNotBlank(id)&&StringUtils.isNotBlank(id)) {
			W0.append(" and ID='"+id+"'");
		}
		
		String name = BaseUtil.getMapValueToString(queryCondition, "name");
		if (StringUtils.isNotBlank(name)&&StringUtils.isNotBlank(name)) {
			W0.append(" and NAME like '%"+name+"%'");
		}
		
		String sql=textFile.toString().replaceAll("\\?W0", W0.toString());
		BaseUtil.printSql(sql, null);

		return this.createSQLQueryPageNoManagerEntity4_1(pageBean.getJumpPage(),  pageBean.getPageSize(), isCount, sql,entityClass);
	}
}
