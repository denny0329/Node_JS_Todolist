package com.gccs.bc.vo;

import java.util.ArrayList;
import java.util.List;

import com.bnq.bs.model.BsArea;
import com.bnq.util.StringId;
import com.gccs.bs.model.BsChannel;
import com.gccs.util.web.SelectItem;

public class BsChannelVo extends BsChannel {
	private static final long serialVersionUID = -2355040735752374389L;

	private List<BsArea> bsAreas = new ArrayList<BsArea>();

	private List<BsStoreVo> bsStoreVo = new ArrayList<BsStoreVo>();
	
	private Integer perAmt;
	private Integer perBonus;
	private Integer disType;
	private String disSku;
	private String disSkuName;
	private String disSkuTaxed;
	private String disSkuTaxedName;

	public String getDisSkuTaxed() {
		return disSkuTaxed;
	}

	public void setDisSkuTaxed(String disSkuTaxed) {
		this.disSkuTaxed = disSkuTaxed;
	}

	public String getDisSkuTaxedName() {
		return disSkuTaxedName;
	}

	public void setDisSkuTaxedName(String disSkuTaxedName) {
		this.disSkuTaxedName = disSkuTaxedName;
	}

	public String getDisSkuName() {
		return disSkuName;
	}

	public void setDisSkuName(String disSkuName) {
		this.disSkuName = disSkuName;
	}	

	public Integer getPerAmt() {
		return perAmt;
	}

	public void setPerAmt(Integer perAmt) {
		this.perAmt = perAmt;
	}

	public Integer getPerBonus() {
		return perBonus;
	}

	public void setPerBonus(Integer perBonus) {
		this.perBonus = perBonus;
	}

	public Integer getDisType() {
		return disType;
	}

	public void setDisType(Integer disType) {
		this.disType = disType;
	}

	public String getDisSku() {
		return disSku;
	}

	public void setDisSku(String disSku) {
		this.disSku = disSku;
	}

	public List<BsStoreVo> getBsStoreVo() {
		return bsStoreVo;
	}
	
	public void setBsStoreVo(List<BsStoreVo> bsStoreVo) {
		this.bsStoreVo = bsStoreVo;
	}

	public List<BsArea> getBsAreas() {
		return bsAreas;
	}

	public void setBsAreas(List<BsArea> bsAreas) {
		this.bsAreas = bsAreas;
	}
	
	public String getDisTypeName(){
		if (disType!=null){
			List<StringId> statusList = SelectItem.getDisTypeList();
			for(StringId vo:statusList){
				if (vo.getId().equals(String.valueOf(disType))){
					return vo.getName();
				}
			}
		}
		return "";
	}	

}
