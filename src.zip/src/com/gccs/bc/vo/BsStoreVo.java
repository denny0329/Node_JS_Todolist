package com.gccs.bc.vo;

import com.gccs.bs.model.BsStore;

public class BsStoreVo extends BsStore{
	private static final long serialVersionUID = 3972329473196412583L;

	private boolean checked = Boolean.FALSE;
	private String bcExchangeStoreOid;
	private String perAmt;
	private String perBonus;
	private String disType;
	private String disSku;
	
	public String getPerAmt() {
		return perAmt;
	}

	public void setPerAmt(String perAmt) {
		this.perAmt = perAmt;
	}

	public String getPerBonus() {
		return perBonus;
	}

	public void setPerBonus(String perBonus) {
		this.perBonus = perBonus;
	}

	public String getDisType() {
		return disType;
	}

	public void setDisType(String disType) {
		this.disType = disType;
	}

	public String getDisSku() {
		return disSku;
	}

	public void setDisSku(String disSku) {
		this.disSku = disSku;
	}

	public String getBcExchangeStoreOid() {
		return bcExchangeStoreOid;
	}

	public void setBcExchangeStoreOid(String bcExchangeStoreOid) {
		this.bcExchangeStoreOid = bcExchangeStoreOid;
	}

	public boolean isChecked() {
		return checked;
	}

	public void setChecked(boolean checked) {
		this.checked = checked;
	}
}
