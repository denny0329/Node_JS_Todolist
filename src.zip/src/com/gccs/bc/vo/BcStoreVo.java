package com.gccs.bc.vo;

public class BcStoreVo {
	private Integer perAmt;
	private Integer perBonus;
	private Integer disType;
	private String disSku;
	private String channelId;
	private String disSkuTaxed;

	public String getDisSkuTaxed() {
		return disSkuTaxed;
	}

	public void setDisSkuTaxed(String disSkuTaxed) {
		this.disSkuTaxed = disSkuTaxed;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public Integer getPerAmt() {
		return perAmt;
	}

	public void setPerAmt(Integer perAmt) {
		this.perAmt = perAmt;
	}

	public Integer getPerBonus() {
		return perBonus;
	}

	public void setPerBonus(Integer perBonus) {
		this.perBonus = perBonus;
	}

	public Integer getDisType() {
		return disType;
	}

	public void setDisType(Integer disType) {
		this.disType = disType;
	}

	public String getDisSku() {
		return disSku;
	}

	public void setDisSku(String disSku) {
		this.disSku = disSku;
	}
}
