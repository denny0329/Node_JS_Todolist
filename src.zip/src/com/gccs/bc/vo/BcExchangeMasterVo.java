package com.gccs.bc.vo;

import java.util.Date;

public class BcExchangeMasterVo {

	//class
	private String dept;
	private String subDept;
	private String class_;
	private String subClass;
	
	//sku
//	private String exchangeId;
//	private String exchangeName;
	
	private String promotId;
	private String promotName;
	

	private String skuChannelPos;
	private String sku;
	private String storeChannelPos;
	private String storeId;
	private Integer exPrice;
	private Integer exBonus;
	private Integer disType;
	private String disSku;
	private String disSkuTaxed;
	private Date expDateF;
	private Date expDateT;
	private Integer transTimes;
	private Integer detailSeq;
	//cash
	public BcExchangeMasterVo(){
		
	}
	
	public BcExchangeMasterVo(String promotId, String promotName,
			String storeChannelPos, String storeId,
			Integer exPrice, Integer exBonus, Integer disType, String disSku,String disSkuTaxed,
			Date expDateF, Date expDateT, Integer transTimes, Integer detailSeq) {
		this.promotId = promotId;
		this.promotName = promotName;
		this.storeChannelPos = storeChannelPos;
		this.storeId = storeId;
		this.exPrice = exPrice;
		this.exBonus = exBonus;
		this.disType = disType;
		this.disSku = disSku;
		this.disSkuTaxed = disSkuTaxed;
		this.expDateF = expDateF;
		this.expDateT = expDateT;
		this.transTimes = transTimes;
		this.detailSeq = detailSeq;
	}	
	
	
	public BcExchangeMasterVo(String promotId, String promotName,
			String skuChannelPos, String sku, String storeChannelPos, String storeId,
			Integer exPrice, Integer exBonus, Integer disType, String disSku,String disSkuTaxed,
			Date expDateF, Date expDateT, Integer transTimes, Integer detailSeq) {
		this.promotId = promotId;
		this.promotName = promotName;
		this.skuChannelPos = skuChannelPos;
		this.sku = sku;
		this.storeChannelPos = storeChannelPos;
		this.storeId = storeId;
		this.exPrice = exPrice;
		this.exBonus = exBonus;
		this.disType = disType;
		this.disSku = disSku;
		this.disSkuTaxed = disSkuTaxed;
		this.expDateF = expDateF;
		this.expDateT = expDateT;
		this.transTimes = transTimes;
		this.detailSeq = detailSeq;
	}
	
	public BcExchangeMasterVo(String promotId, String promotName,
			String skuChannelPos, String sku, String storeChannelPos, String storeId,
			String dept,String subDept,String class_,String subClass,Date expDateF, Date expDateT) {
		this.promotId = promotId;
		this.promotName = promotName;
		this.skuChannelPos = skuChannelPos;
		this.sku = sku;
		this.storeChannelPos = storeChannelPos;
		this.storeId = storeId;
		this.dept = dept;
		this.subDept = subDept;
		this.class_ = class_;
		this.subClass = subClass;
		this.expDateF = expDateF;
		this.expDateT = expDateT;
	}	
	
	public String getDisSkuTaxed() {
		return disSkuTaxed;
	}

	public void setDisSkuTaxed(String disSkuTaxed) {
		this.disSkuTaxed = disSkuTaxed;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}
	
	public Integer getExPrice() {
		return exPrice;
	}

	public void setExPrice(Integer exPrice) {
		this.exPrice = exPrice;
	}

	public Integer getExBonus() {
		return exBonus;
	}

	public void setExBonus(Integer exBonus) {
		this.exBonus = exBonus;
	}

	public Integer getDisType() {
		return disType;
	}

	public void setDisType(Integer disType) {
		this.disType = disType;
	}

	public String getDisSku() {
		return disSku;
	}

	public void setDisSku(String disSku) {
		this.disSku = disSku;
	}

	public Date getExpDateF() {
		return expDateF;
	}

	public void setExpDateF(Date expDateF) {
		this.expDateF = expDateF;
	}

	public Date getExpDateT() {
		return expDateT;
	}

	public void setExpDateT(Date expDateT) {
		this.expDateT = expDateT;
	}

	public Integer getTransTimes() {
		return transTimes;
	}

	public void setTransTimes(Integer transTimes) {
		this.transTimes = transTimes;
	}

	public Integer getDetailSeq() {
		return detailSeq;
	}

	public void setDetailSeq(Integer detailSeq) {
		this.detailSeq = detailSeq;
	}

	public String getSkuChannelPos() {
		return skuChannelPos;
	}

	public void setSkuChannelPos(String skuChannelPos) {
		this.skuChannelPos = skuChannelPos;
	}

	public String getStoreChannelPos() {
		return storeChannelPos;
	}

	public void setStoreChannelPos(String storeChannelPos) {
		this.storeChannelPos = storeChannelPos;
	}
	
	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getSubDept() {
		return subDept;
	}

	public void setSubDept(String subDept) {
		this.subDept = subDept;
	}

	public String getClass_() {
		return class_;
	}

	public void setClass_(String class1) {
		class_ = class1;
	}

	public String getSubClass() {
		return subClass;
	}

	public void setSubClass(String subClass) {
		this.subClass = subClass;
	}

	public String getPromotId() {
		return promotId;
	}

	public void setPromotId(String promotId) {
		this.promotId = promotId;
	}

	public String getPromotName() {
		return promotName;
	}

	public void setPromotName(String promotName) {
		this.promotName = promotName;
	}
	
}
