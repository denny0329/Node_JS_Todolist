select ID,NAME from(
select PROMOT_ID as ID,PROMOT_NAME as NAME from BC_BONUS_SETTING_MST
)
where 1=1
?W0
/*
and ID=''
and NAME like '%mily%'
*/
