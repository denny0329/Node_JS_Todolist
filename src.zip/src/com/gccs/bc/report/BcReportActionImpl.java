package com.gccs.bc.report;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.AppContext;
import com.bnq.util.DateUtils;
import com.bnq.util.serial.SerialService;
import com.rfep.base.BaseUtil;
import com.rfep.base.ReportBean;
import com.rfep.base.ReportUtils;
import com.rfep.rm.model.RptPoolmgt;
import com.rfep.rm.model.RptPoolmgtFile;
import com.rfep.rm.service.RmService;

/**
 * 報表的處理
 * @author Johnson
 *
 */
public class BcReportActionImpl extends ReportUtils implements Serializable{
	private static final long serialVersionUID = -7129940984618728081L;

	private static final Logger log = LogManager.getLogger(BcReportActionImpl.class) ;
	private static final String REPORT_PATH=CLASS_PATH+"com/gccs/bc/report/jasper/";
	private static final String SQL_PATH=CLASS_PATH+"com/gccs/bc/report/sql/";
	private BcReportServiceI operateService;

	public BcReportServiceI getOperateService() {
//		if( operateService == null )
//			operateService = (BcReportServiceI)AppContext.getBean("bcReportServiceI");
		return operateService;
	}

	public void setOperateService(BcReportServiceI operateService) {
		log.info("#####################");
		log.info(" setOperateService : "+operateService);
		log.info("#####################");
		this.operateService = operateService;
	}

	// 操作表格tableName
	private String tableName;

	public String getTableName() {
		return tableName;
	}

	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	
	// 要產生的報表名稱
	private String reportFileName;
	
	public String getReportFileName() {
		return reportFileName;
	}

	public void setReportFileName(String reportFileName) {
		this.reportFileName = reportFileName;
	}

	/**
	 * JSP進入點,如果不想一進來就執行query(),這個功能可以改用index()
	 * 
	 * @author Johnson
	 * @Date: 2010/10/01 上午 13:00:00
	 * @return
	 */
	public String bcReport01Index() {
		this.getRequest().setAttribute("download", false);
		this.getRequest().removeAttribute("BCReportId");
		tableName = "bcReport01";
		reportFileName = "點數積點兌點總表";
		return SUCCESS;
	}
	
	//以上是進入點


	/**
	 * JSP執行
	 * 
	 * @author Johnson
	 * @Date: 2011/01/12 上午 13:00:00
	 * @return
	 */
	public String bcReport01Print() {
		log.info(">>>>>>>>>>>>>>>>Print:"+reportFileName);
		reportFileName = "點數積點兌點總表";
		String pName="BcReport01";
		
		String exportType = getMapValueToString(this.getQueryCondition(), "exportType");
		String pdfPrintType = getMapValueToString(this.getQueryCondition(), "pdfPrintType");
		String excelPrintType = getMapValueToString(this.getQueryCondition(), "excelPrintType");
						
		//設定報表頁面參數
		Map<String, Object> parameterMap = new HashMap<String, Object>();
		
		//設定表頭
		Map<String,String> iReportP = new HashMap<String,String>();
		iReportP.put("P1",  getShowChannelDesc(getMapValueToString(this.getQueryCondition(), "channelId")));
		iReportP.put("P2",  getShowStrorDesc(getMapValueToString(this.getQueryCondition(), "channelId"), getMapValueToString(this.getQueryCondition(), "storeId")));
		iReportP.put("P3",  getMapValueToString(this.getQueryCondition(), "marketId"));

		//日期
		iReportP.put("P4",  processStrDateBetween(this.getQueryCondition(),"dateStart","dateEnd"));
		//製表人員
		iReportP.put("P5",  this.getUser().getUserId()+"-"+this.getUser().getUserName());

		parameterMap.put("iReportP",iReportP);
		
		//設定子報表路徑
		if(processSubReportPath2(parameterMap,REPORT_PATH).equals(ERROR)){
			return ERROR;
		}
		//放置SQL
		try {
			String sql0=BaseUtil.readTextFile(SQL_PATH+pName+"_0.sql");
			String sql1=BaseUtil.readTextFile(SQL_PATH+pName+"_1.sql");
			sql0=sql0.replaceAll("\\?W0", getOperateService().queryConditionBySQL01_0(this.getQueryCondition()));
			sql1=sql1.replaceAll("\\?W1", getOperateService().queryConditionBySQL01_1(this.getQueryCondition()));
			
			BaseUtil.printSql(sql0, null);
			BaseUtil.printSql(sql1, null);
			
			parameterMap.put("sql0",sql0);
			parameterMap.put("sql1",sql1);
		} catch (Exception ex) {
			ex.printStackTrace();
			this.setDspMessage("放置sql其失敗原因："+handleError1(ex)+"<br>");
			return ERROR;
		}
		RmService rmService = (RmService)AppContext.getBean("rmService");
		RptPoolmgt rptPoolmgt = new RptPoolmgt();
		RptPoolmgtFile rptPoolmgtFile = new RptPoolmgtFile();
		//報表產生
		try {
//			InputStream logo = BaseUtil.getInputStreamSpring(REPORT_PATH+"titlePic1.jpg");
//			parameterMap.put("logo", logo);
			
			ReportBean reportBean=null;
			if(exportType.equals(EXPORT_TYPE_PDF)){
				reportBean=new ReportBean(
						this.getConnection(),
						this.REPORT_PATH+pName+"_0-PDF-"+pdfPrintType+this.JASPER,
						reportFileName,parameterMap,exportType);
			}else if(exportType.equals(EXPORT_TYPE_EXCEL)){
				reportBean=new ReportBean(
						this.getConnection(),
						this.REPORT_PATH+pName+"_0-Excel-"+excelPrintType+this.JASPER,
						reportFileName,parameterMap,exportType);
				reportBean.setIsIgnorePagination(true);//true:不要有分頁
			}
			//2011.09.05-使用Domain連結時無法操作但使用IP連結時可正常操作問題.
			//method.1
//			processJasperReport(reportBean);
			//method.2
//			super.setReportBean(reportBean);
//			if(reportBean.getParameterMap() == null)
//				reportBean.setParameterMap(new HashMap());
//			// 用於Excel匯出時的額外設定
//			if (reportBean.getExportType().equals(EXPORT_TYPE_EXCEL)) {
//				reportBean.getParameterMap().put(
//						JRParameter.IS_IGNORE_PAGINATION,
//						reportBean.getIsIgnorePagination());
//			}
//			log.info(">>>>>>>>>>>>>>>> create byteArrayOutputStream (Print:"+reportFileName+")");
//			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
//			JRXlsExporter exporter = new JRXlsExporter();
//			log.info(">>>>>>>>>>>>>>>> create JRXlsExporter (Print:"+reportFileName+")");
//			exporter.setParameter(
//					JRExporterParameter.JASPER_PRINT, super.getJasperPrint());
//			exporter.setParameter(
//					JRExporterParameter.OUTPUT_STREAM, byteArrayOutputStream);
//			exporter.setParameter(
//					JRXlsExporterParameter.IS_WHITE_PAGE_BACKGROUND,
//					reportBean.getIsWhitePageBackground());
//			//下面這行是讓excel的字串變成數值
//			exporter.setParameter(JRXlsExporterParameter.IS_DETECT_CELL_TYPE,Boolean.TRUE);
//			log.info(">>>>>>>>>>>>>>>> exportReport (Print:"+reportFileName+")");
//			exporter.exportReport();
//			byte bytes[];
//			bytes = byteArrayOutputStream.toByteArray();
//			log.info(">>>>>>>>>>>>>>>> genEXCELtoWeb (Print:"+reportFileName+")");
////			super.getResponse().reset();
//			super.getResponse().setContentType("application/vnd.ms-excel");
//			if (reportBean.getContentDisposition().equals(CONTENT_DISPOSITION_IN_LINE)) {
//				super.getResponse().setHeader("Content-disposition", "inline ; filename="
//						+ new String(reportFileName.getBytes(
//						"big5"), "ISO8859-1") + ".xls");// 內崁檔案
//			} else if (reportBean.getContentDisposition().equals(CONTENT_DISPOSITION_ATTACHMENT)) {
//				super.getResponse().setHeader("Content-disposition",
//						"attachment ; filename=" + new String(reportFileName.getBytes(
//						"big5"), "ISO8859-1") + ".xls");// 附加檔案
//			}
//			OutputStream ouputStream = super.getResponse().getOutputStream();
//			ouputStream.write(bytes, 0, bytes.length);
//			ouputStream.flush();
//			byteArrayOutputStream.close();
//			ouputStream.close();
			//method.3
			
			//0.準備DB寫入資料
			String reportId = "BC"+DateUtils.cdateFormat2(new Date())+SerialService.getSerial("RPT_POOL", "MGT_SEQ");
			
			Map conditionMap = this.getQueryCondition();
			conditionMap.put("rptId", reportId);
			conditionMap.put("userId", this.getUser().getUserId());
			conditionMap.put("userName", this.getUser().getUserName());
			rptPoolmgt=this.procDbData(
					"BC", conditionMap, rptPoolmgt, 
					reportFileName, ReportUtils.EXPORT_TYPE_EXCEL);
			rmService.save(rptPoolmgt);
			this.getRequest().setAttribute("BCReportId", rptPoolmgt.getOid());
			//3.寫入DB欄位
			rptPoolmgtFile.setRptfile(processJasperReportToDb(reportBean));
			rptPoolmgt.setStatus(1);//狀態(0.執行中 1.已完成 9.失敗)
		} catch (Exception ex) {
			ex.printStackTrace();
			this.setDspMessage("報表產生其失敗原因："+handleError1(ex)+"<br>");
			return ERROR;
		}
		//5.
		rmService.saveRptPoolmgtAndRptPoolmgtFile(rptPoolmgt,rptPoolmgtFile);
		this.getRequest().setAttribute("download", true);
		
		return SUCCESS;
	}
	
}
