package com.gccs.bc.report;

import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import com.bnq.util.DateTimeUtils;
import com.rfep.base.BaseServiceImpl;
import com.rfep.base.BaseUtil;
import com.rfep.base.UtilString;

/**
 * @author Johnson
 * @Date: 2010/10/01 上午 13:00:00
 */
public class BcReportServiceImpl extends BaseServiceImpl<Object> implements BcReportServiceI{
	private static final Logger log = LogManager.getLogger(BcReportServiceImpl.class) ;
	
	public String queryConditionBySQL01_0(Map<String, String> queryCondition) {
		StringBuilder W0=new StringBuilder();
			    
		//設定等於的欄位
		String[] dbField=new String[]{"BBL.CHANNEL_ID","BBL.STORE_ID"};
		String[] frontKey=new String[]{"channelId","storeId"};
		BaseUtil.addParams_EQ1(dbField,frontKey, queryCondition, W0, "");

		//日期
		BaseUtil.addParams_DateBetween1("BBL.TRANS_DATE", "dateStart", "dateEnd", DateTimeUtils.DEFAULT_DATE_PATTERN, queryCondition, W0, "");
		
		//in
		String marketId = queryCondition.get("marketId");
		if(StringUtils.isNotBlank(marketId)){
			W0.append(" and BBL.MARKET_ID in "+UtilString.uS003(marketId));
		}
		
		return W0.toString();
	}
	
	public String queryConditionBySQL01_1(Map<String, String> queryCondition) {
		StringBuilder W0=new StringBuilder();
			    
		//設定等於的欄位
		String[] dbField=new String[]{"BDL.CHANNEL_ID","BDL.STORE_NO"};
		String[] frontKey=new String[]{"channelId","storeId"};
		BaseUtil.addParams_EQ1(dbField,frontKey, queryCondition, W0, "");

		//日期
		BaseUtil.addParams_DateBetween1("BDL.CREATE_TIME", "dateStart", "dateEnd", DateTimeUtils.DEFAULT_DATE_PATTERN, queryCondition, W0, "");
		
		return W0.toString();
	}

}
