package com.gccs.bc.report;

import java.util.Map;

/**
 * @author Johnson
 * @Date: 2010/10/01 上午 13:00:00
 */
public interface BcReportServiceI {
	
	public String queryConditionBySQL01_0(Map<String, String> queryCondition) ;
	public String queryConditionBySQL01_1(Map<String, String> queryCondition) ;
}
