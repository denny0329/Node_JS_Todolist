package com.gccs.bc.job;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gccs.bc.service.BcBonusYMLogService;

/**
 * <b></b>
 * @author Jack Chou
 * @Date: 2010/5/11
 * @Project Name: RFEP
 */
public class BcBonusYMJob {
	private static final Logger log = LogManager.getLogger("batchJob") ;
	private BcBonusYMLogService service ;
	
	public BcBonusYMLogService getService() {
		return service;
	}
	public void setService(BcBonusYMLogService service) {
		this.service = service;
	}

	public void posBcBonusYMLog() {
		try {
			long l1 = System.currentTimeMillis() ;
			log.info("[posBcBonusYMLog] launched.");
			SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat("yyyyMM");
			String dateStr = gSimpleDateFormat.format(getSysDate());
			this.getService().getMonthlyBonus(dateStr);
			long l2 = System.currentTimeMillis() ;
			log.info("[posBcBonusYMLog] task finish. time cost : "+((l2-l1)/1000)) ;
		} catch (Exception e) {
			log.error("[posBcBonusYMLog] fail : "+e.getMessage(),e) ;
		}
	}
	public static Timestamp getSysDate() {
		
		Date today = Calendar.getInstance().getTime();
		return new Timestamp(today.getTime());
	}
	
}
