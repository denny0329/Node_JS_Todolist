package com.gccs.bc.job;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gccs.bc.service.BcSomService;

/**
 * <b></b>
 * @author Rong 
 */
public class BcSomJob {
	private static final Logger log = LogManager.getLogger("batchJob") ;
	
	private BcSomService bcSomService;
	
	public void execute() {
		long l1 = System.currentTimeMillis() ;
		log.info("Job launch.") ;
		bcSomService.importExecute(false);
		long l2 = System.currentTimeMillis() ;
		log.info("Job end ."+((l2-l1)/1000)+" sec.") ;
	}

	public BcSomService getBcSomService() {
		return bcSomService;
	}

	public void setBcSomService(BcSomService bcSomService) {
		this.bcSomService = bcSomService;
	}
}
