package com.gccs.bc.job;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gccs.bc.setting.service.BcBonusSettingService;

/**
 * <b></b>
 * @author kaychen
 * @Date: 2010/2/22 下午 5:08:35
 * @Project Name: RFEP
 */
public class BonusSettingJob {
	private static final Logger log = LogManager.getLogger("batchJob") ;
	
	private BcBonusSettingService bcBonusSettingService;
	
	public void setBcBonusSettingService(BcBonusSettingService bcBonusSettingService) {
		this.bcBonusSettingService = bcBonusSettingService;
	}
	public BcBonusSettingService getBcBonusSettingService() {
		return bcBonusSettingService;
	}

	public void bonusSettingChange() {
		try {
			long l1 = System.currentTimeMillis() ;
			log.info("[bonusSettingJob] launched.") ;
			bcBonusSettingService.processBonusSettingScheduling();
			long l2 = System.currentTimeMillis() ;
			log.info("[bonusSettingJob] task finish. time cost : "+((l2-l1)/1000)) ;
		} catch (Exception e) {
			log.error("[bonusSettingJob] fail : "+e.getMessage(),e) ;
		}
	}
	

}
