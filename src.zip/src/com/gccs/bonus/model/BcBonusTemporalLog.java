package com.gccs.bonus.model;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.gccs.bc.model.BcBonusLog;

/**
 * 紅利點數排程明細 
 */
public class BcBonusTemporalLog implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -1777690725861031673L;
	
	/**PK*/
	private BcBonusTemporalLogId id;

	/**身份證字號*/
	private String personId;
	
	/**發票號碼*/
	private String guiNos;
	
	/**新增紅利點數*/
	private long bonusAdd;
	
	/**折抵紅利點數*/
	private long bonusMins;
	
	/**異動日期時間*/
	private Date modifiedTime;
	
	public BcBonusTemporalLog() {
		super();
	}
	
	public BcBonusTemporalLog(BcBonusLog bcBonusLog) {
		this.setId(new BcBonusTemporalLogId(bcBonusLog.getStoreId(), 
				bcBonusLog.getTransDate(), 
				bcBonusLog.getPosNos(), 
				bcBonusLog.getSerNos()));
		this.setBonusAdd(bcBonusLog.getBonusAdd());
		this.setBonusMins(bcBonusLog.getBonusMins());
		this.setGuiNos(bcBonusLog.getGuiNo());
	}
	
	/**
	 * 取回PK
	 * @return
	 */
	public BcBonusTemporalLogId getId() {
		return id;
	}

	/**
	 * 指定PK
	 * @param id
	 */
	public void setId(BcBonusTemporalLogId id) {
		this.id = id;
	}

	/**
	 * 取回身份證字號
	 * @return
	 */
	public String getPersonId() {
		return personId;
	}

	/**
	 * 指定身份證字號
	 * @param personId
	 */
	public void setPersonId(String personId) {
		this.personId = personId;
	}

	/**
	 * 取回新增紅利積點
	 * @return
	 */
	public long getBonusAdd() {
		return bonusAdd;
	}

	/**
	 * 指定新增紅利積點
	 * @param bonusAdd
	 */
	public void setBonusAdd(long bonusAdd) {
		this.bonusAdd = bonusAdd;
	}

	/**
	 * 取回折抵紅利積點
	 * @return
	 */
	public long getBonusMins() {
		return bonusMins;
	}

	/**
	 * 指定折抵紅利積點
	 * @param bonusMins
	 */
	public void setBonusMins(long bonusMins) {
		this.bonusMins = bonusMins;
	}

	/**
	 * 取回發票號碼
	 * @return
	 */
	public String getGuiNos() {
		return guiNos;
	}

	/**
	 * 指定發票號碼
	 * @param guiNos
	 */
	public void setGuiNos(String guiNos) {
		this.guiNos = guiNos;
	}

	/**
	 * 取回異動日期時間
	 * @return
	 */
	public Date getModifiedTime() {
		return modifiedTime;
	}

	/**
	 * 指定異動日期時間
	 * @param modifiedTime
	 */
	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}

	public String toString() {
		return new ToStringBuilder(this)
			.append("id", getId())
			.append("personId", getPersonId())
			.append("guiNos", getGuiNos())
			.append("bonusAdd", getBonusAdd())
			.append("bonusMins", getBonusMins())
			.append("modifiedTime", getModifiedTime())
			.toString();
	}
}
