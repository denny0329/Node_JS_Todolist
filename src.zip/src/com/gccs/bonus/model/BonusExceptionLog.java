package com.gccs.bonus.model;

import java.io.Serializable;
import java.util.Date;

public class BonusExceptionLog implements Serializable {
	private static final long serialVersionUID = 3525190592371016906L;

	private String oid;
	private Date transferDate;	//轉紅利日期
	private Integer exceptionType;	//異常狀態
	private String exceptionDesc;	//異常描述
	private String channelId;	//通路別
	//交易資訊PK
	private String storeNo;	//店別
	private Date transDat;	//交易日
	private String posNos;	//機台序號
	private String serNos;	//交易序號
	//交易資訊PK end
	private String guiNo;	//發票號碼
	
	private String promotId;	//轉換促銷編號
	
	private Date createTime ;
	private String creator ;
	private String creatorName ;
	private String modifier ;
	private String modifierName ;
	private Date modifyTime ;
	
	public String getOid() {
		return oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public Date getTransferDate() {
		return transferDate;
	}

	public void setTransferDate(Date transferDate) {
		this.transferDate = transferDate;
	}

	public Integer getExceptionType() {
		return exceptionType;
	}

	public void setExceptionType(Integer exceptionType) {
		this.exceptionType = exceptionType;
	}

	public String getExceptionDesc() {
		return exceptionDesc;
	}

	public void setExceptionDesc(String exceptionDesc) {
		this.exceptionDesc = exceptionDesc;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getStoreNo() {
		return storeNo;
	}

	public void setStoreNo(String storeNo) {
		this.storeNo = storeNo;
	}

	public Date getTransDat() {
		return transDat;
	}

	public void setTransDat(Date transDat) {
		this.transDat = transDat;
	}

	public String getPosNos() {
		return posNos;
	}

	public void setPosNos(String posNos) {
		this.posNos = posNos;
	}

	public String getSerNos() {
		return serNos;
	}

	public void setSerNos(String serNos) {
		this.serNos = serNos;
	}

	public String getGuiNo() {
		return guiNo;
	}

	public void setGuiNo(String guiNo) {
		this.guiNo = guiNo;
	}

	public String getPromotId() {
		return promotId;
	}

	public void setPromotId(String promotId) {
		this.promotId = promotId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public String getModifier() {
		return modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getModifierName() {
		return modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public Date getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
	
}
