package com.gccs.bonus.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

/**
 * @Description 工資交易主檔Model
 * @Version 2.0 Jun 2, 2012
 * @author mgj
 */
public class BcBonusHisuMaster implements Serializable, Cloneable
{
	private static final long serialVersionUID = -450870304479495016L;
	private String store_no;	//店代號
	private Date trans_dat;		//交易日期
	private String pos_nos;		//收銀機號
	private String ser_nos;		//交易序號
	private String sale_type;	//交易類型
	private String sale_sta;	//交易狀態
	private String gui_nos;		//發票號碼
	private String cust_nos;	//交易會員卡號(13)
	private String cust_id;		//交易會員卡號(8)
	private Double trans_tot;	//交易金額
	private String so_nos;		//SO單號
	private String ret_nos;		//折讓單號
	private Date cancel_dat;	//作廢日期
	private Set detailSet;
	
	public String getStore_no()
	{
		return store_no;
	}
	public void setStore_no(String store_no)
	{
		this.store_no = store_no;
	}
	public Date getTrans_dat()
	{
		return trans_dat;
	}
	public void setTrans_dat(Date trans_dat)
	{
		this.trans_dat = trans_dat;
	}
	public String getPos_nos()
	{
		return pos_nos;
	}
	public void setPos_nos(String pos_nos)
	{
		this.pos_nos = pos_nos;
	}
	public String getSer_nos()
	{
		return ser_nos;
	}
	public void setSer_nos(String ser_nos)
	{
		this.ser_nos = ser_nos;
	}
	public String getSale_type()
	{
		return sale_type;
	}
	public void setSale_type(String sale_type)
	{
		this.sale_type = sale_type;
	}
	public String getSale_sta()
	{
		return sale_sta;
	}
	public void setSale_sta(String sale_sta)
	{
		this.sale_sta = sale_sta;
	}
	public String getGui_nos()
	{
		return gui_nos;
	}
	public void setGui_nos(String gui_nos)
	{
		this.gui_nos = gui_nos;
	}
	public String getCust_nos()
	{
		return cust_nos;
	}
	public void setCust_nos(String cust_nos)
	{
		this.cust_nos = cust_nos;
	}
	public String getCust_id()
	{
		return cust_id;
	}
	public void setCust_id(String cust_id)
	{
		this.cust_id = cust_id;
	}
	public Double getTrans_tot()
	{
		return trans_tot;
	}
	public void setTrans_tot(Double trans_tot)
	{
		this.trans_tot = trans_tot;
	}
	public String getSo_nos()
	{
		return so_nos;
	}
	public void setSo_nos(String so_nos)
	{
		this.so_nos = so_nos;
	}
	public String getRet_nos()
	{
		return ret_nos;
	}
	public void setRet_nos(String ret_nos)
	{
		this.ret_nos = ret_nos;
	}
	public Date getCancel_dat()
	{
		return cancel_dat;
	}
	public void setCancel_dat(Date cancel_dat)
	{
		this.cancel_dat = cancel_dat;
	}
	public Set getDetailSet()
	{
		return detailSet;
	}
	public void setDetailSet(Set detailSet)
	{
		this.detailSet = detailSet;
	}
}
