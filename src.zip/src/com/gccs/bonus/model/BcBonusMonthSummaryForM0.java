package com.gccs.bonus.model;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * 會員月紅利現金積點-鮮綠市集
 */
public class BcBonusMonthSummaryForM0 implements Serializable {

	private String oid;
	
	/**通路代碼*/
	private String channelId;
	
	/**店端代碼*/
	private String storeId;
	
	/**門店代碼*/
	private String siteId;
	
	/**POS機號*/
	private String posNos;
	
	/**新增積點*/
	private long bonusAdd;
	
	/**抵用積點*/
	private long bonusMins;
	
	/**抵用積點金額*/
	private double discAmt;
	
	/**清理積點*/
	private long bonusCln;
	
	/**年份*/
	private String year;
	
	/**月份*/
	private String month;
	
	/**建立者*/
	private String creator;
	
	/**建立日期時間*/
	private Date createTime;
	
	/**紅利積點類別*/
	private Integer bonusType;
	
	public BcBonusMonthSummaryForM0() {
		super();
	}
	
	public BcBonusMonthSummaryForM0(ResultSet rs) throws SQLException {
		this.setChannelId(rs.getString("CHANNEL_ID"));
		this.setStoreId(rs.getString("STORE_ID"));
		this.setSiteId(rs.getString("SITE_ID"));
		this.setPosNos(rs.getString("POS_NOS"));
		this.setBonusType(rs.getInt("BONUS_TYPE"));
		this.setBonusAdd(rs.getLong("BONUS_ADD"));
		this.setBonusMins(rs.getLong("BONUS_MINS"));
		this.setDiscAmt(rs.getDouble("DISC_AMT"));
	}

	public String getOid() {
		return oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}
	
	/**
	 * 取回通路代碼
	 * @return
	 */
	public String getChannelId() {
		return channelId;
	}

	/**
	 * 指定通路代碼
	 * @param channelId
	 */
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	/**
	 * 取回店端代碼
	 * @return
	 */
	public String getStoreId() {
		return storeId;
	}

	/**
	 * 指定店端代碼
	 * @param storeId
	 */
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	/**
	 * 取回門店代碼
	 * @return
	 */
	public String getSiteId() {
		return siteId;
	}

	/**
	 * 指定門店代碼
	 * @param siteId
	 */
	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}

	/**
	 * 取回會員代碼
	 * @return
	 */
	public String getPosNos() {
		return posNos;
	}

	/**
	 * 指定會員代碼
	 * @param memberId
	 */
	public void setPosNos(String posNos) {
		this.posNos = posNos;
	}
	
	/**
	 * 取回新增積點
	 * @return
	 */
	public long getBonusAdd() {
		return bonusAdd;
	}

	/**
	 * 指定新增積點
	 * @param bonusAdd
	 */
	public void setBonusAdd(long bonusAdd) {
		this.bonusAdd = bonusAdd;
	}

	/**
	 * 取回抵用積點
	 * @return
	 */
	public long getBonusMins() {
		return bonusMins;
	}

	/**
	 * 指定抵用積點
	 * @param bonusMins
	 */
	public void setBonusMins(long bonusMins) {
		this.bonusMins = bonusMins;
	}

	/**
	 * 取回抵用積點金額
	 * @return
	 */
	public double getDiscAmt() {
		return discAmt;
	}

	/**
	 * 指定抵用積點金額
	 * @param discAmt
	 */
	public void setDiscAmt(double discAmt) {
		this.discAmt = discAmt;
	}

	/**
	 * 取回清理積點
	 * @return
	 */
	public long getBonusCln() {
		return bonusCln;
	}

	/**
	 * 指定清理積點
	 * @param bonusCln
	 */
	public void setBonusCln(long bonusCln) {
		this.bonusCln = bonusCln;
	}

	/**
	 * 取回年份
	 * @return
	 */
	public String getYear() {
		return year;
	}

	/**
	 * 指定年份
	 * @param year
	 */
	public void setYear(String year) {
		this.year = year;
	}

	/**
	 * 取回月份
	 * @return
	 */
	public String getMonth() {
		return month;
	}

	/**
	 * 指定月份
	 * @param month
	 */
	public void setMonth(String month) {
		this.month = month;
	}

	/**
	 * 取回產生者
	 * @return
	 */
	public String getCreator() {
		return creator;
	}

	/**
	 * 指定產生者
	 * @param creator
	 */
	public void setCreator(String creator) {
		this.creator = creator;
	}

	/**
	 * 取回產生日期時間
	 * @return
	 */
	public Date getCreateTime() {
		return createTime;
	}

	/**
	 * 指定產生日期時間
	 * @param createTime
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	
	/**
	 * 取回紅利點數類別	
	 * @return
	 */
	public Integer getBonusType() {
		return bonusType;
	}

	/**
	 * 指定紅利點數類別
	 * @param bonusType
	 */
	public void setBonusType(Integer bonusType) {
		this.bonusType = bonusType;
	}
	
	public String toString() {
		return new ToStringBuilder(this)
				.append("channelId", getChannelId())
				.append("storeId", getStoreId())
				.append("siteId", getSiteId())
				.append("posNos", getPosNos())
				.append("bonusAdd", getBonusAdd())
				.append("bonusMins", getBonusMins())
				.append("discAmt", getDiscAmt())
				.append("bonusCln", getBonusCln())
				.append("year", getYear())
				.append("month", getMonth())
				.append("creator", getCreator())
				.append("createTime", getCreateTime())
				.append("bonusType", getBonusType())
				.toString();
	}
}
