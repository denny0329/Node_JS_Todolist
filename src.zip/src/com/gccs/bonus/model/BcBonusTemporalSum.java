package com.gccs.bonus.model;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * 批次產生紅利點數總表物件 
 */
public class BcBonusTemporalSum implements Serializable {
	
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 3672045002574416340L;

	/**身份證字號*/
	private String personId;
	
	/**會員代號*/
	private Long memberId;
	
	/**目前可用紅利點數*/
	private Long bonusTotal;
	
	/**產生日期時間*/
	private Date createTime;
	
	/**修改日期時間*/
	private Date modifiedTime;
	
	public BcBonusTemporalSum() {
		super();
	}
	
	public BcBonusTemporalSum(ResultSet rs) throws SQLException {
		this.setMemberId(rs.getLong("MEMBER_ID"));
		this.setBonusTotal(rs.getLong("BONUS_TOTAL"));
		this.setPersonId(rs.getString("PERSON_ID"));
	}
	
	/**
	 * 取回會員代號
	 * @return
	 */
	public Long getMemberId() {
		return memberId;
	}
	
	/**
	 * 指定會員代號
	 * @param memberId
	 */
	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}
	
	/**
	 * 取回目前可用紅利點數
	 * @return
	 */
	public Long getBonusTotal() {
		return bonusTotal;
	}
	
	/**
	 * 指定目前可用紅利點數
	 * @param bonusTotal
	 */
	public void setBonusTotal(Long bonusTotal) {
		this.bonusTotal = bonusTotal;
	}
	
	/**
	 * 取回身份證字號	
	 * @return
	 */
	public String getPersonId() {
		return personId;
	}

	/**
	 * 指定身份證字號
	 * @param personId
	 */
	public void setPersonId(String personId) {
		this.personId = personId;
	}

	/**
	 * 取回建立日期時間
	 * @return
	 */
	public Date getCreateTime() {
		return createTime;
	}

	/**
	 * 指定建立日期時間
	 * @param createTime
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	/**
	 * 取回修改日期時間
	 * @return
	 */
	public Date getModifiedTime() {
		return modifiedTime;
	}

	/**
	 * 指定修改日期時間
	 * @param modifiedTime
	 */
	public void setModifiedTime(Date modifiedTime) {
		this.modifiedTime = modifiedTime;
	}

	public String toString() {
		return new ToStringBuilder(this)
			.append("personId", getPersonId())
			.append("memberId", getMemberId())
			.append("bonusTotal", getBonusTotal())
			.append("createTime", getCreateTime())
			.append("modifiedTime", getModifiedTime())
			.toString();
	}
}
