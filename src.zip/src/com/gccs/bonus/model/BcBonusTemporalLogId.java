package com.gccs.bonus.model;

import java.io.Serializable;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * 紅利點數排程明細PK 
 */
public class BcBonusTemporalLogId implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7257280494492428290L;

	/**門店代號*/
	private String storeNo;
	
	/**交易日期*/
	private Date transDate;
	
	/**POS機碼*/
	private String posNos;
	
	/**交易代號*/
	private String serNos;
	
	public BcBonusTemporalLogId() {
		super();
	}
	
	public BcBonusTemporalLogId(String storeNo, Date transDate, String posNos, String serNos) {
		this.setStoreNo(storeNo);
		this.setTransDate(transDate);
		this.setPosNos(posNos);
		this.setSerNos(serNos);
	}

	/**
	 * 取回門店代號
	 * @return
	 */
	public String getStoreNo() {
		return storeNo;
	}

	/**
	 * 指定門店代號
	 * @param storeNo
	 */
	public void setStoreNo(String storeNo) {
		this.storeNo = storeNo;
	}

	/**
	 * 取回交易日期
	 * @return
	 */
	public Date getTransDate() {
		return transDate;
	}

	/**
	 * 指定交易日期
	 * @param transDate
	 */
	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}

	/**
	 * 取回POS機碼
	 * @return
	 */
	public String getPosNos() {
		return posNos;
	}

	/**
	 * 指定POS機碼
	 * @param posNos
	 */
	public void setPosNos(String posNos) {
		this.posNos = posNos;
	}

	/**
	 * 取回交易代號
	 * @return
	 */
	public String getSerNos() {
		return serNos;
	}

	/**
	 * 指定交易代號
	 * @param serNos
	 */
	public void setSerNos(String serNos) {
		this.serNos = serNos;
	}
	
	public String toString() {
		return new ToStringBuilder(this)
			.append("storeId", getStoreNo())
			.append("transDate", getTransDate())
			.append("posNos", getPosNos())
			.append("serNos", getSerNos())
			.toString();
	}
}
