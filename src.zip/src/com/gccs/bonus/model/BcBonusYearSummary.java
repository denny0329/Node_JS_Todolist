package com.gccs.bonus.model;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * 會員年紅利現金積點 
 */
public class BcBonusYearSummary implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -996981421412633157L;
	
	private String oid;

	/**年份*/
	private String year;
	
	/**月份*/
	private String month;
	
	/**總新增點數*/
	private double bonusAddTotal;
	
	/**總折抵點數*/
	private double bonusMinsTotal;
	
	/**總折抵金額*/
	private double discAmtTotal;
	
	/**總清理點數*/
	private double bonusClnTotal;
	
	/**產生者*/
	private String creator;
	
	/**產生日期時間*/
	private Date createTime;
	
	private double bonusAddLastYearTotal;
	
	/**公司代碼*/
	private String companyId;
	
	public BcBonusYearSummary() {
		super();
	}
	
	public BcBonusYearSummary(ResultSet rs) throws SQLException {
		setBonusAddTotal(rs.getLong("BONUS_ADD_TOTAL"));
		setBonusMinsTotal(rs.getLong("BONUS_MINS_TOTAL"));
		setDiscAmtTotal(rs.getLong("DISC_AMT_TOTAL"));
		setBonusClnTotal(rs.getLong("BONUS_CLN_TOTAL"));
		setCompanyId(rs.getString("COMPANY_ID"));
	}
	
	public String getOid() {
		return oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	/**
	 * 取回年份
	 * @return
	 */
	public String getYear() {
		return year;
	}

	/**
	 * 指定年份
	 * @param year
	 */
	public void setYear(String year) {
		this.year = year;
	}

	/**
	 * 取回月份	
	 * @return
	 */
	public String getMonth() {
		return month;
	}

	/**
	 * 指定月份
	 * @param month
	 */
	public void setMonth(String month) {
		this.month = month;
	}

	/**
	 * 取回總新增點數
	 * @return
	 */
	public double getBonusAddTotal() {
		return bonusAddTotal;
	}

	/**
	 * 指定總新增點數
	 * @param bonusAddTotal
	 */
	public void setBonusAddTotal(double bonusAddTotal) {
		this.bonusAddTotal = bonusAddTotal;
	}

	/**
	 * 取回總折抵點數
	 * @return
	 */
	public double getBonusMinsTotal() {
		return bonusMinsTotal;
	}

	/**
	 * 指定總折抵點數
	 * @param bonusMinsTotal
	 */
	public void setBonusMinsTotal(double bonusMinsTotal) {
		this.bonusMinsTotal = bonusMinsTotal;
	}

	/**
	 * 取回總折抵金額
	 * @return
	 */
	public double getDiscAmtTotal() {
		return discAmtTotal;
	}

	/**
	 * 指定總折抵金額
	 * @param discAmtTotal
	 */
	public void setDiscAmtTotal(double discAmtTotal) {
		this.discAmtTotal = discAmtTotal;
	}

	/**
	 * 取回總清理點數
	 * @return
	 */
	public double getBonusClnTotal() {
		return bonusClnTotal;
	}

	/**
	 * 指定總清理點數
	 * @param bonusClnTotal
	 */
	public void setBonusClnTotal(double bonusClnTotal) {
		this.bonusClnTotal = bonusClnTotal;
	}

	/**
	 * 取回產生者
	 * @return
	 */
	public String getCreator() {
		return creator;
	}

	/**
	 * 指定產生者
	 * @param creator
	 */
	public void setCreator(String creator) {
		this.creator = creator;
	}

	/**
	 * 取回產生日期時間
	 * @return
	 */
	public Date getCreateTime() {
		return createTime;
	}

	/**
	 * 指定產生日期時間
	 * @param createTime
	 */
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	
	public String getCompanyId() {
		return companyId;
	}

	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	//上年度剩餘點數
	public double getBonusAddLastYearTotal() {
		return bonusAddLastYearTotal;
	}

	public void setBonusAddLastYearTotal(double bonusAddLastYearTotal) {
		this.bonusAddLastYearTotal = bonusAddLastYearTotal;
	}

	public String toString() {
		return new ToStringBuilder(this)
				.append("year", getYear())
				.append("month", getMonth())
				.append("bonusAddTotal", getBonusAddTotal())
				.append("bonusMinsTotal", getBonusMinsTotal())
				.append("discAmtTotal", getDiscAmtTotal())
				.append("bonusClnTotal", getBonusClnTotal())
				.append("creator", getCreator())
				.append("createTime", getCreateTime())
				.append("bonusAddLastYearTotal", getBonusAddLastYearTotal())
				.toString();
	}
}
