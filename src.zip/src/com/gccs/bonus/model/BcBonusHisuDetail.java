/**
 * @(#)BcBonusHisuDetail.java
 * @Copyright (C) 2009-2012 Enjar,Inc.
 * all rights reserved
 */
package com.gccs.bonus.model;

import java.io.Serializable;
import java.util.Date;

/**
 * @Description 工資交易明細檔Model
 * @Version 2.0 Jun 2, 2012
 * @author mgj
 */
public class BcBonusHisuDetail implements Serializable, Cloneable
{
	private static final long serialVersionUID = 1563981813496222640L;
	private String storeNo;  //交易店別
	private Date transDat;   //交易日期
	private String posNos;   //POS機號
	private String serNos;   //交易序號
	private String itemSer;  //商品交易序號
	private String skuNo;    //SKU
	private String skuName;  //商品名稱
	private String skuType;  //商品類別
	private Integer transQty;//數量
	private Double actualAmt; //金額
	private String subDept;  //商品分類
	private String classStr; //商品分類
	private String subClass; //商品分類
	private String vendorId; //廠商編號
	private Integer vatType; //應/未稅
	private String skuStatus;//SKU狀態
	private String buyerCode;//採購代號
	
	public String getStoreNo()
	{
		return storeNo;
	}
	
	public void setStoreNo(String storeNo)
	{
		this.storeNo = storeNo;
	}
	
	public Date getTransDat()
	{
		return transDat;
	}
	
	public void setTransDat(Date transDat)
	{
		this.transDat = transDat;
	}
	
	public String getPosNos()
	{
		return posNos;
	}
	
	public void setPosNos(String posNos)
	{
		this.posNos = posNos;
	}
	
	public String getSerNos()
	{
		return serNos;
	}
	
	public void setSerNos(String serNos)
	{
		this.serNos = serNos;
	}
	
	public String getItemSer()
	{
		return itemSer;
	}
	
	public void setItemSer(String itemSer)
	{
		this.itemSer = itemSer;
	}
	
	public String getSkuNo()
	{
		return skuNo;
	}
	
	public void setSkuNo(String skuNo)
	{
		this.skuNo = skuNo;
	}
	
	public String getSkuName()
	{
		return skuName;
	}
	public void setSkuName(String skuName)
	{
		this.skuName = skuName;
	}
	
	public String getSkuType()
	{
		return skuType;
	}
	
	public void setSkuType(String skuType)
	{
		this.skuType = skuType;
	}
	
	public Integer getTransQty()
	{
		return transQty;
	}
	
	public void setTransQty(Integer transQty)
	{
		this.transQty = transQty;
	}

	public Double getActualAmt()
	{
		return actualAmt;
	}

	public void setActualAmt(Double actualAmt)
	{
		this.actualAmt = actualAmt;
	}

	public String getSubDept()
	{
		return subDept;
	}

	public void setSubDept(String subDept)
	{
		this.subDept = subDept;
	}

	public String getClassStr()
	{
		return classStr;
	}

	public void setClassStr(String classStr)
	{
		this.classStr = classStr;
	}

	public String getSubClass()
	{
		return subClass;
	}

	public void setSubClass(String subClass)
	{
		this.subClass = subClass;
	}

	public String getVendorId()
	{
		return vendorId;
	}

	public void setVendorId(String vendorId)
	{
		this.vendorId = vendorId;
	}

	public Integer getVatType()
	{
		return vatType;
	}

	public void setVatType(Integer vatType)
	{
		this.vatType = vatType;
	}

	public String getSkuStatus()
	{
		return skuStatus;
	}

	public void setSkuStatus(String skuStatus)
	{
		this.skuStatus = skuStatus;
	}

	public String getBuyerCode()
	{
		return buyerCode;
	}

	public void setBuyerCode(String buyerCode)
	{
		this.buyerCode = buyerCode;
	}
}
