package com.gccs.bonus.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.AppContext;
import com.gccs.marketing.IIntegrateImpoirtDataService;
import com.rfep.nm.service.INmSmmImportService;

public class SmmServlet extends HttpServlet {
	private static final long serialVersionUID = -5941146545170285214L;

	private final Logger log = LogManager.getLogger(this.getClass());
	private IIntegrateImpoirtDataService service = (IIntegrateImpoirtDataService)AppContext.getBean("integrateImpoirtDataService");	
	private INmSmmImportService smmImportService = (INmSmmImportService)AppContext.getBean("nmSmmImportService");	; 
	
	public void service(HttpServletRequest req, HttpServletResponse rep) throws ServletException, IOException {
		try{
			Integer snNo = Integer.parseInt(req.getParameter("snNo"));
			 
			long l0 = System.currentTimeMillis();
			Thread.sleep(5000);
			log.info("[IntergrateImportDataJob] launched.");
			String seqNo = service.initBatchForSMM(snNo);
			long l1 = System.currentTimeMillis();
			log.info("[IntergrateImportDataJob init] task finish. time cost : " + ((l1 - l0) / 1000));
			// 執行912批次匯入
			service.execute912Batch(snNo);
			long l2 = System.currentTimeMillis();
			log.info("[IntergrateImportDataJob 912] task finish. time cost : " + ((l2 - l1) / 1000));
			
			this.smmImportService.cleanExpiredData(snNo);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}	
}
