package com.gccs.bonus.service;

/**
 * 年度紅利積點計算共用服務介面
 * @param
 */
public interface IBcBonusSummarySerivce {
	
	/**
	 * 執行批次
	 */
	public void executeBatch();
	public void executeM0Batch(); 

}
