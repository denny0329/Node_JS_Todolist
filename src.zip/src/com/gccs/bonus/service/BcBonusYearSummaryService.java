package com.gccs.bonus.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gccs.bonus.dao.hibernate.BcBonusYearSummaryDAO;
import com.gccs.bonus.model.BcBonusYearSummary;
import com.gccs.bonus.util.BonusDateUtility;
import com.gccs.report.model.vo.Report42;

/**
 * 會員年紅利現金積點服務
 */
public class BcBonusYearSummaryService extends BcBonusSummaryService
	implements IBcBonusSummarySerivce {
	
	private static final Logger log = LogManager.getLogger(BcBonusYearSummaryService.class) ;

	private BcBonusYearSummaryDAO bcBonusYearSummaryDao;
	
	public BcBonusYearSummaryDAO getBcBonusYearSummaryDao() {
		return bcBonusYearSummaryDao;
	}

	public void setBcBonusYearSummaryDao(BcBonusYearSummaryDAO bcBonusYearSummaryDao) {
		this.bcBonusYearSummaryDao = bcBonusYearSummaryDao;
	}
	
	/**
	 * 執行批次
	 * (計算上一個月的資料)
	 */
	public void executeBatch() {
		
		Date now = new Date();
		final String datePattern = "yyyyMM";
		
		Calendar cal = Calendar.getInstance();
		String nowString = BonusDateUtility.getStringFromDate(now, datePattern);
		cal.setTime(BonusDateUtility.getDateFromString(nowString, datePattern));
		cal.add(Calendar.MONTH, -1);
		
		String year = BonusDateUtility.getStringFromDate(cal.getTime(), "yyyy");
		String month = BonusDateUtility.getStringFromDate(cal.getTime(), "MM");
		
		this.processBcBonusYearSummary(year, month);
	}
	
	/**
	 * 執行批次
	 * (計算上一個月的資料)
	 */
	public void executeM0Batch() {
		//
	}
	
	/**
	 * 執行存檔
	 * @param year
	 */
	public void processBcBonusYearSummary(String year) {
		
		if(StringUtils.isBlank(year)) {
			return;
		}
		
		List<BcBonusYearSummary> summaryList = 
			getBcBonusYearSummaryDao().findBcBonusYearSummaryFromMonthData(year);
		if(summaryList != null && summaryList.size() != 0) {
			try {
				getBcBonusYearSummaryDao().saveOrUpdateCollection(summaryList);
			} catch (Exception e) {
				e.printStackTrace();
				log.error("Save Data Error." + e.getMessage(), e);
			}
		}
	}
	
	/**
	 * 執行存檔
	 * @param year
	 * @param month
	 */
	public void processBcBonusYearSummary(String year, String month) {
		
		if(StringUtils.isBlank(year) || StringUtils.isBlank(month)) {
			return;
		}
		
		BcBonusYearSummary summary = getBcBonusYearSummaryDao().findBcBonusYearSummaryFromMonthData(year, month);
		if(summary != null) {
			try {
				if("01".equals(month)){
					Long tot = getBcBonusYearSummaryDao().countBonusYearSummartLastYearTotal(year);
					summary.setBonusAddLastYearTotal(tot);
				}
				getBcBonusYearSummaryDao().saveOrUpdateObject(summary);
			} catch (Exception e) {
				e.printStackTrace();
				log.error("Save Data Error." + e.getMessage(), e);
			}
		}
	}
	
	/**
	 * 依年度取紅利點數年度計算資料
	 * @param year
	 * @return
	 */
	public List<BcBonusYearSummary> getBcBonusYearSummaryByYear(String year) {
		if(StringUtils.isBlank(year)) {
			return null;
		}
		return getBcBonusYearSummaryDao().findBcBonusYearSummaryByYear(year);
	}
	
	/**
	 * 年度紅利點數積點兌點總表 - 總店 資料列表 (上年度加總)
	 * @param year 年份
	 * @return
	 */
	public List<Report42> getReport42ByLastYear(String year) {
			
		if(StringUtils.isBlank(year)) {
			return null;
		}
				
		List<Report42> reportList = bcBonusYearSummaryDao.getReport42LastYearData(year);
		
		return reportList;
	}
	
	/**
	 * 年度紅利點數積點兌點總表 - 總店 資料列表
	 * @param year 年份
	 * @return
	 */
	public List<Report42> getReport42ByYear(String year) {
			
		if(StringUtils.isBlank(year)) {
			return null;
		}
				
		List<Report42> reportList = bcBonusYearSummaryDao.getReport42Data(year);
		
		return reportList;
	}
	
	public void saveBcBonusYearSummaryLastYearTotal(BcBonusYearSummary bean) {
		if(bean != null) {
			try {
				getBcBonusYearSummaryDao().saveOrUpdateObject(bean);
			} catch (Exception e) {
				e.printStackTrace();
				log.error("Save Data Error." + e.getMessage(), e);
			}
		}
	}
	
	/**
	 * 依年度,月份取紅利點數年度,月份資料
	 * @param year,month
	 * @return
	 */
	public List<BcBonusYearSummary> findBcBonusYearSummaryByYearMonth(String year,String month) {
		if(StringUtils.isBlank(year)) {
			return null;
		}
		if(StringUtils.isBlank(month)) {
			return null;
		}
		return getBcBonusYearSummaryDao().findBcBonusYearSummaryByYearMonth(year,month);
	}
}
