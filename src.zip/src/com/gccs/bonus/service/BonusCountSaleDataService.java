package com.gccs.bonus.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.transaction.support.TransactionTemplate;

import com.bnq.util.sale.model.SaleMaster;
import com.gccs.bc.model.BcExchangeStore;
import com.gccs.bonus.condition.BonusCondition;
import com.gccs.bonus.dao.hibernate.BonusCountSaleDataDAO;
import com.gccs.mmbonus.model.MmMembersBonus;

@SuppressWarnings("all")
public class BonusCountSaleDataService {
	
	private static final Logger log = LogManager.getLogger(BonusCountSaleDataService.class) ;
	
	private BonusCountSaleDataDAO bonusCountSaleDataDAO;
	private TransactionTemplate transactionTemplate ;
	
	public TransactionTemplate getTransactionTemplate() {
		return transactionTemplate;
	}
	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}
	
	public BonusCountSaleDataDAO getBonusCountSaleDataDAO() {
		return bonusCountSaleDataDAO;
	}

	public void setBonusCountSaleDataDAO(BonusCountSaleDataDAO bonusCountSaleDataDAO) {
		this.bonusCountSaleDataDAO = bonusCountSaleDataDAO;
	}

	public void findSaleMasterListByStore(String mstOid,String storeId,Date transDate,String type,boolean isManual,boolean isExcludeSomData){
		bonusCountSaleDataDAO.findSaleMasterListByStore(mstOid,storeId,transDate,type,isManual,isExcludeSomData);
	}
	
	public void findSaleMasterListByStoreForEmployee(Map cardDiscountMap,String storeId,Date transDate,String type, String sale_type, String sale_sta){
		bonusCountSaleDataDAO.findSaleMasterListByStoreForEmployee(cardDiscountMap,storeId,transDate,type,sale_type,sale_sta);
	}	
	
	public List findBonusCalTransTempJoinMembersBonus(BonusCondition condition){
		return bonusCountSaleDataDAO.findBonusCalTransTempJoinMembersBonus(condition);
	}
	
	public List findBonusCalTransNewTempJoinMembersBonus(BonusCondition condition){
		return bonusCountSaleDataDAO.findBonusCalTransNewTempJoinMembersBonus(condition);
	}
	
	public List findBonusCalTransTempByCondition(BonusCondition condition){
		return bonusCountSaleDataDAO.findBonusCalTransTempByCondition(condition);
	}
	
	public List findBonusCalTransTempNewByCondition(BonusCondition condition){
		return bonusCountSaleDataDAO.findBonusCalTransTempNewByCondition(condition);
	}
	
	public void updateBonusCalTransTemp(Integer bonustol,Integer thisyeartot,Integer lastyeartot,Integer bonusmins,Integer bonusadd,String oid){
		bonusCountSaleDataDAO.updateBonusCalTransTemp(bonustol,thisyeartot,lastyeartot,bonusmins,bonusadd,oid);
	}
	
	public void updateBonusCalTransNew(Integer bonustol,Integer thisyeartot,Integer lastyeartot,Integer bonusmins,Integer bonusadd,String oid){
		bonusCountSaleDataDAO.updateBonusCalTransNew(bonustol,thisyeartot,lastyeartot,bonusmins,bonusadd,oid);
	}
	
	public void countBonusCalTransTemp(BonusCondition condition){
		bonusCountSaleDataDAO.countBonusCalTransTemp(condition);
	}
	
	public void minusDiscountAmt(BonusCondition condition){
		bonusCountSaleDataDAO.minusDiscountAmt(condition);
	}
	
	public void countBonusCalTransTempForEmployee(BonusCondition condition){
		bonusCountSaleDataDAO.countBonusCalTransTempForEmployee(condition);
	}
	
	public void insertBonuslog(BonusCondition condition){
		bonusCountSaleDataDAO.insertBonuslog(condition);
	}
	
	public void insertBonuslogForEmployee(BonusCondition condition){
		bonusCountSaleDataDAO.insertBonuslogForEmployee(condition);
	}
	
	public void updateMemberBonus(BonusCondition condition){
		bonusCountSaleDataDAO.updateMemberBonus(condition);
	}
	
	public boolean findExcludeSkuFor0(String mstOid,String storeId){
		return bonusCountSaleDataDAO.findExcludeSkuFor0(mstOid,storeId);
	}
	
	public void countEXcludeSkuFor0(BonusCondition condition){
		bonusCountSaleDataDAO.countEXcludeSkuFor0(condition);
	}
	
	public MmMembersBonus findMmMembersBonus(Long memberid,String companyId){
		return bonusCountSaleDataDAO.findMmMembersBonus(memberid,companyId);
	}
	
	public List<MmMembersBonus> findMmMembersBonusByMemberId(Long memberid){
		return bonusCountSaleDataDAO.findMmMembersBonusByMemberId(memberid);
	}
	
	public Double findBsType0ExcludeSkuAmt(BcExchangeStore exchangeStore, SaleMaster master){
		return bonusCountSaleDataDAO.findBsType0ExcludeSkuAmt(exchangeStore, master);
	}
	
	public List findBonusLogTypeNN(Date transDate, SaleMaster saleMaster){
		return bonusCountSaleDataDAO.findBonusLogTypeNN(transDate, saleMaster);
	}
	
	public List findBonusLogTypeBB(Date transDate, SaleMaster saleMaster){
		return bonusCountSaleDataDAO.findBonusLogTypeBB(transDate, saleMaster);
	}
	
	public List findBonusLogTypeBN(Date transDate, SaleMaster saleMaster){
		return bonusCountSaleDataDAO.findBonusLogTypeBN(transDate, saleMaster);
	}

}
