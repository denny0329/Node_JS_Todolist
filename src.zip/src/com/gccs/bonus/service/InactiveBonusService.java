package com.gccs.bonus.service;

import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import com.bnq.util.sale.model.SaleMaster;
import com.bnq.util.serial.dao.IBcBonusSerialNumDao;
import com.gccs.bc.model.BcBonusLog;
import com.gccs.bc.model.BcDisbonusLog;
import com.gccs.bonus.dao.hibernate.BonusLogDAO;
import com.gccs.bonus.model.vo.AccountVO;
import com.gccs.bonus.model.vo.BonusVO;
import com.gccs.bonus.model.vo.DisbonusVO;
import com.gccs.bonus.util.BonusGlossary;
import com.gccs.member.model.MembersBO2;
import com.gccs.member.service.IMemberService;

public class InactiveBonusService {
	private static final Log batchlog = LogFactory.getLog("batchJob");
	private BonusLogDAO bonusLogDAO;
	private IMemberService memberService;
	private IBcBonusSerialNumDao bcBonusSerialNumDao;
	private TransactionTemplate transactionTemplate;
	
	public BonusLogDAO getBonusLogDAO() {
		return bonusLogDAO;
	}

	public void setBonusLogDAO(BonusLogDAO bonusLogDAO) {
		this.bonusLogDAO = bonusLogDAO;
	}

	public TransactionTemplate getTransactionTemplate() {
		return transactionTemplate;
	}

	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}

	public IMemberService getMemberService() {
		return memberService;
	}

	public void setMemberService(IMemberService memberService) {
		this.memberService = memberService;
	}
	
	public IBcBonusSerialNumDao getBcBonusSerialNumDao() {
		return bcBonusSerialNumDao;
	}

	public void setBcBonusSerialNumDao(IBcBonusSerialNumDao bcBonusSerialNumDao) {
		this.bcBonusSerialNumDao = bcBonusSerialNumDao;
	}
	
	/**
	 * 執行點數清算時,回補及刪除資料
	 * @param transDate 交易日期
	 */
	public void inactiveBonusBeforeProcess(Date transDate) {
		try {
			this.getBonusLogDAO().inactiveBonusBeforeProcessByTransDate(transDate);
		} catch (Exception e) {
			e.printStackTrace();
			batchlog.error(e);
		}
	}

	/**
	 * 執行紅利點數歸零
	 * 條件 : 13個月未有消費記錄的會員
	 */
	public void inactiveBonusProcess() {
		long time1 = System.currentTimeMillis();
		try {
			batchlog.info(" start ");
			long time11 = System.currentTimeMillis();
			List dataList = this.getBonusLogDAO().findDisableBonusMemberOid();
			long time12 = System.currentTimeMillis();
			batchlog.info("query disbonus member time : "+(time12 - time11)/1000);
			if(dataList!=null) {
				int disbonusCount = 0;
				int bonusCount = 0;
				int memberCount = 0;
				for(Iterator iterator = dataList.iterator(); iterator.hasNext(); ) {
					String memberOid = (String)iterator.next();
					long time21 = System.currentTimeMillis();
					MembersBO2 member = this.getMemberService().getMembersBO2ByOid(memberOid);
					long time22 = System.currentTimeMillis();
					batchlog.info("query member time : "+(time22 - time21)/1000);
					if(member!=null) {
						AccountVO accountVO = new AccountVO();
						accountVO.setObject(member);
						accountVO.setAccountVoType(BonusGlossary._account_vo_type_member);
						long time31 = System.currentTimeMillis();
						List saleDataList = this.getBonusLogDAO().findLastSaleDataByMemberOid(member.getOid());
						long time32 = System.currentTimeMillis();
						batchlog.info("query sale time : "+(time32 - time31)/1000);
						SaleMaster master = null;
						if(saleDataList!=null&&!saleDataList.isEmpty()) {
							//有交易資訊，取得當天任一筆，無交易資訊，產生無交易紅利失效
							master = (SaleMaster)saleDataList.get(0);
						}
						
						//紅利失效紀錄
						DisbonusVO disVO = new DisbonusVO(member, master);
						final BcDisbonusLog disbonusLog = disVO.getLog();
						
						//紅利失效通路代碼塞"HQ", 店端代碼塞"99"
						disbonusLog.setChannelId(BonusGlossary.BONUS_INVALID_CHANNEL_ID);
						disbonusLog.setStoreNo(BonusGlossary.BONUS_INAVLID_STORE_ID); 
						
						//finalDisbonsuList.add(disbonusLog);
						disbonusCount++;
						//紅利扣除紀錄
						BonusVO vo = new BonusVO();
						vo.delCreate(accountVO.getBonusTotal());
						accountVO.setBonusTotal(accountVO.getBonusTotal()-vo.getExBonus());
						accountVO.setThisYearTot(accountVO.getThisYearTot()-vo.getExBonus());
						accountVO.setUpDateTime();
						vo.setDefaultInfo(accountVO, null, 
								BonusGlossary._disbonus, BonusGlossary._disbonus_market_id,
								getBcBonusSerialNumDao());
						final BcBonusLog bonusLog = vo.getLog();
						
						//紅利失效通路代碼塞"HQ", 店端代碼塞"99"
						bonusLog.setChannelId(BonusGlossary.BONUS_INVALID_CHANNEL_ID);
						bonusLog.setStoreId(BonusGlossary.BONUS_INAVLID_STORE_ID);
						
						bonusCount++;
						final MembersBO2 mmBO2 = (MembersBO2)accountVO.getObject();
						memberCount++;
						
						//執行DB儲存
						try {
							transactionTemplate.execute(new TransactionCallback() {
								public Object doInTransaction(TransactionStatus txnStatus) {
									Boolean txnFail = false; 
									try{
										if(disbonusLog!=null)
											getBonusLogDAO().insertObject(disbonusLog);
										if(bonusLog!=null)
											getBonusLogDAO().insertObject(bonusLog);
										if(mmBO2!=null)
											getBonusLogDAO().updateObject(mmBO2);
											
									} catch(Exception ex) {
										txnFail = true;
										txnStatus.setRollbackOnly();
										throw new RuntimeException(ex);
									}
									return txnFail;
								}
							});
						} catch(Exception e) {
							e.printStackTrace();
							batchlog.error(e);
						}
					} else {
						//無會員
					}
					long time23 = System.currentTimeMillis();
					batchlog.info("one time : "+(time23 - time21)/1000);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			batchlog.error(e);
		}
		long time2 = System.currentTimeMillis();
		batchlog.info("Inactivate bonus total time : " + (time2-time1)/1000);
		batchlog.info(" end ");
	}
}
