package com.gccs.bonus.service;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import org.apache.commons.lang.ObjectUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.apeo.sender.exception.MessageSenderException;
import com.apeo.sender.model.MessageContent;
import com.bnq.util.DateTimeUtils;
import com.bnq.util.mail.MailService;
import com.gccs.bc.service.BcBonusService;
import com.gccs.bonus.condition.BonusCondition;
import com.gccs.bonus.dao.hibernate.BonusLogDAO;
import com.gccs.bonus.model.BonusExceptionLog;
import com.gccs.bonus.service.process.BonusSettlementProcess;
import com.gccs.bonus.service.process.NormalCancelProcess;
import com.gccs.bonus.service.process.NormalSaleProcess;
import com.gccs.bonus.service.process.RejectionCancelProcess;
import com.gccs.bonus.service.process.RejectionSaleProcess;
import com.gccs.bonus.util.BonusExceptionGlossary;
import com.gccs.bonus.util.BonusUtility;
import com.gccs.util.web.SelectItem;
import com.rfep.nm.dao.hibernate.NmBonusCountCheckDAO;
import com.rfep.util.sys.service.CassetteJobTimeAndMailNotifyService;

public class BonusCountService {
	private final Logger log = LogManager.getLogger("bonusBatch");
	private static final String NM_BONUS_COUNT_CHECK_JOB = "nmBonusCountCheckJob";
	private NormalSaleProcess normalProcess;
	private NormalCancelProcess normalCancelProcess;
	private RejectionSaleProcess rejectionSaleProcess;
	private RejectionCancelProcess rejectionCancelProcess;
	private BonusSettlementProcess bonusSettlementProcess;
	private BonusLogDAO bonusLogDAO;
	private NmBonusCountCheckDAO nmBonusCountCheckDAO;
	private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
	
	public BonusSettlementProcess getBonusSettlementProcess() {
		return bonusSettlementProcess;
	}

	public void setBonusSettlementProcess(
			BonusSettlementProcess bonusSettlementProcess) {
		this.bonusSettlementProcess = bonusSettlementProcess;
	}

	public NormalSaleProcess getNormalProcess() {
		return normalProcess;
	}

	public void setNormalProcess(NormalSaleProcess normalProcess) {
		this.normalProcess = normalProcess;
	}

	public NormalCancelProcess getNormalCancelProcess() {
		return normalCancelProcess;
	}

	public void setNormalCancelProcess(NormalCancelProcess normalCancelProcess) {
		this.normalCancelProcess = normalCancelProcess;
	}

	public RejectionSaleProcess getRejectionSaleProcess() {
		return rejectionSaleProcess;
	}

	public void setRejectionSaleProcess(RejectionSaleProcess rejectionSaleProcess) {
		this.rejectionSaleProcess = rejectionSaleProcess;
	}

	public RejectionCancelProcess getRejectionCancelProcess() {
		return rejectionCancelProcess;
	}

	public void setRejectionCancelProcess(
			RejectionCancelProcess rejectionCancelProcess) {
		this.rejectionCancelProcess = rejectionCancelProcess;
	}

	public BonusLogDAO getBonusLogDAO() {
		return bonusLogDAO;
	}

	public void setBonusLogDAO(BonusLogDAO bonusLogDAO) {
		this.bonusLogDAO = bonusLogDAO;
	}

	/**
	 * @return the nmBonusCountCheckDAO
	 */
	public NmBonusCountCheckDAO getNmBonusCountCheckDAO() {
		return nmBonusCountCheckDAO;
	}

	/**
	 * @param nmBonusCountCheckDAO the nmBonusCountCheckDAO to set
	 */
	public void setNmBonusCountCheckDAO(NmBonusCountCheckDAO nmBonusCountCheckDAO) {
		this.nmBonusCountCheckDAO = nmBonusCountCheckDAO;
	}

	/** 紅利處理程序
	 * @param inputDate
	 * @param storeNo
	 */
	public void bonusCountProcess(Date inputDate, String storeNo, int executeType) {
		Date transferDate = null;
		if(inputDate!=null) {
			transferDate = inputDate;
		} else {
			try {
				//取得所要計算的交易日
				transferDate = DateTimeUtils.addDate(DateTimeUtils.getFormatSysDate(), -1);
			} catch(Exception e) {
				log.error(e.getStackTrace());
			} catch(Throwable t) {
				log.error(t.getStackTrace());
			}
		}

		if(transferDate!=null) {
			log.info("Transfer Bonus Beging time : "+DateTimeUtils.getSysDate());
			long time1 = DateTimeUtils.getSysDate().getTime();
			switch(executeType){
				case SelectItem.allProcess:
					if (StringUtils.isNotBlank(storeNo)) {
						//手動
						//依交易日期刪除資料
						BonusCondition condition = new BonusCondition();
						condition.setTransDate(transferDate);
						if (StringUtils.startsWithIgnoreCase(storeNo, BcBonusService.FIELD_STORE_ID)) {
							condition.setStoreNo(storeNo.replaceAll(BcBonusService.FIELD_STORE_ID, ""));
						} else if (StringUtils.startsWithIgnoreCase(storeNo, BcBonusService.FIELD_CHANNEL_ID)) {
							condition.setChannelId(storeNo.replaceAll(BcBonusService.FIELD_CHANNEL_ID, ""));
							condition.setStoreNo(null);
						}
						this.getBonusLogDAO().deleteBcBonusLogByTransDate(condition);
						long delUseTime = System.currentTimeMillis();
						log.info("delete bc_bonus_log process end total cost time : "+(delUseTime-time1)/1000);
					}
					
				case SelectItem.NormalProcess:
					//正常交易
					this.getNormalProcess().bonusProcess(transferDate, storeNo,executeType);
					long timeTemp1 = System.currentTimeMillis();
					log.info("normal process end total cost time : "+(timeTemp1-time1)/1000);
					
				case SelectItem.NormalCancelProcess:
					//正常作廢
					this.getNormalCancelProcess().bonusProcess(transferDate, storeNo, executeType);
					long timeTemp2 = System.currentTimeMillis();
					log.info("normal cancel process end total cost time : "+(timeTemp2-time1)/1000);
					
				case SelectItem.RejectionProcess:
					//退貨交易
					this.getRejectionSaleProcess().bonusProcess(transferDate, storeNo, executeType);
					long timeTemp3 = System.currentTimeMillis();
					log.info("rejection process end total cost time : "+(timeTemp3-time1)/1000);
					
				case SelectItem.RejectionCancelProcess:
					//退貨作廢
					this.getRejectionCancelProcess().bonusProcess(transferDate, storeNo, executeType);	
					long timeTemp4 = System.currentTimeMillis();
					log.info("rejection cancel process end total cost time : "+(timeTemp4-time1)/1000);
			}
			
			log.info("Transfer Bonus End time : "+DateTimeUtils.getSysDate());
			long time2 = DateTimeUtils.getSysDate().getTime();
			log.info("cost bonus count second : "+(time2-time1)/1000);

		} else {
			//日期無法取得
			BonusExceptionLog exceptionLog = BonusUtility.createExceptionLog(BonusExceptionGlossary._exception_type_non_transfer_date, new Date(), null);
			this.getBonusLogDAO().save(exceptionLog);
		}
	}
	
	/*
	 * 員工卡給點
	 * card_type in (2,3,7)
	 */
	public void bonusCountProcessForEmployee(Date inputDate, String storeNo, int executeType) {
		Date transferDate = null;
		if(inputDate!=null) {
			transferDate = inputDate;
		} else {
			try {
				//取得所要計算的交易日
				transferDate = DateTimeUtils.addDate(DateTimeUtils.getFormatSysDate(), -1);
			} catch(Exception e) {
				log.error(e.getStackTrace());
			} catch(Throwable t) {
				log.error(t.getStackTrace());
			}
		}
		
		if(transferDate!=null) {
			log.info("Transfer Bonus Beging time : "+DateTimeUtils.getSysDate());
			long time1 = DateTimeUtils.getSysDate().getTime();
			switch(executeType){
				case SelectItem.allProcess:
					if (StringUtils.isNotBlank(storeNo)) {
						//手動
						//依交易日期刪除資料
//						BonusCondition condition = new BonusCondition();
//						condition.setTransDate(transferDate);
//						if (StringUtils.startsWithIgnoreCase(storeNo, BcBonusService.FIELD_STORE_ID)) {
//							condition.setStoreNo(storeNo.replaceAll(BcBonusService.FIELD_STORE_ID, ""));
//						} else if (StringUtils.startsWithIgnoreCase(storeNo, BcBonusService.FIELD_CHANNEL_ID)) {
//							condition.setChannelId(storeNo.replaceAll(BcBonusService.FIELD_CHANNEL_ID, ""));
//							condition.setStoreNo(null);
//						}
//						this.getBonusLogDAO().deleteBcBonusLogByTransDate(condition);
//						long delUseTime = System.currentTimeMillis();
//						log.info("delete bc_bonus_log process end total cost time : "+(delUseTime-time1)/1000);
					}
					
				case SelectItem.NormalProcess:
					//正常交易
					this.getNormalProcess().bonusProcessForEmployee(transferDate,storeNo,executeType);
					long timeTemp1 = System.currentTimeMillis();
					log.info("normal process end total cost time : "+(timeTemp1-time1)/1000);
					
				case SelectItem.NormalCancelProcess:
					//正常作廢
					this.getNormalCancelProcess().bonusProcessForEmployee(transferDate, storeNo, executeType);
					long timeTemp2 = System.currentTimeMillis();
					log.info("normal cancel process end total cost time : "+(timeTemp2-time1)/1000);
					
				case SelectItem.RejectionProcess:
					//退貨交易
					this.getRejectionSaleProcess().bonusProcessForEmployee(transferDate, storeNo, executeType);
					long timeTemp3 = System.currentTimeMillis();
					log.info("rejection process end total cost time : "+(timeTemp3-time1)/1000);
					
				case SelectItem.RejectionCancelProcess:
					//退貨作廢
					this.getRejectionCancelProcess().bonusProcessForEmployee(transferDate, storeNo, executeType);	
					long timeTemp4 = System.currentTimeMillis();
					log.info("rejection cancel process end total cost time : "+(timeTemp4-time1)/1000);
			}
			
			log.info("Transfer Bonus End time : "+DateTimeUtils.getSysDate());
			long time2 = DateTimeUtils.getSysDate().getTime();
			log.info("cost bonus count second : "+(time2-time1)/1000);

		} else {
			//日期無法取得
			BonusExceptionLog exceptionLog = BonusUtility.createExceptionLog(BonusExceptionGlossary._exception_type_non_transfer_date, new Date(), null);
			this.getBonusLogDAO().save(exceptionLog);
		}
	}
	
	/** 進行年度紅利點數結算	
	 * @param inputDate
	 * @param storeNo
	 */
	public void lastYearBonusSummaryProcess(Boolean isNeedToBackupData){
		this.getBonusSettlementProcess().lastYearBonusSummaryProcess(isNeedToBackupData);
	}
	
	/** 進行年度紅利點數清算	
	 * @param inputDate
	 * @param storeNo
	 */
	public void lastYearBonusCleanProcess(Boolean isNeedToBackupData){
		this.getBonusSettlementProcess().lastYearBonusCleanProcess(isNeedToBackupData);
	}
	
	public void doFirstStore(){
		this.getBonusSettlementProcess().doFirstStore();
	}
	
	/** 紅利點數NR計算
	 * @throws IOException 
	 * @throws WriteException 
	 * @throws RowsExceededException 
	 * @throws MessageSenderException 
	 */
	public void nmBonusCountCheckProcess() throws RowsExceededException, WriteException, IOException, MessageSenderException {
		//取得郵件subject
		String subject = CassetteJobTimeAndMailNotifyService.getBatchJobInfo(NM_BONUS_COUNT_CHECK_JOB).getEmailSubject();
		//取得郵件收件人列表
		String receiverList = CassetteJobTimeAndMailNotifyService.sysJobMailTo(NM_BONUS_COUNT_CHECK_JOB);
		//組織郵件內文
		MessageContent content = new MessageContent() ;
		content.setSubject(subject) ;
		content.setContent(this.getContent());
		//增加附件內容
		List attachments = this.getAttachments();
		//送出郵件
		MailService.sendMessage(content.getContent(), subject, receiverList, "",attachments);
	}
	
	/**
	 * 產生郵件內容
	 * @return 回傳郵件內容 
	 */
	@SuppressWarnings("unchecked")
	private String getContent() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, -1); // 系統時間 - 1
		
		StringBuffer content = new StringBuffer();
		content.append("您好，這是" + dateFormat.format(calendar.getTime()) + "的紅利點數基本積分給點檢查：");
		content.append("<table width=\"200\" border=\"1\">");
		content.append("<tr><td>店號</td><td>未算筆數</td></tr>");
		
		//未計算紅利的店點與筆數
		List unCountBonusList = nmBonusCountCheckDAO.getUnCountBonus();
		for (Iterator iterator = unCountBonusList.iterator(); unCountBonusList != null && unCountBonusList.size() > 0 && iterator.hasNext();) {
			Map unCountBonus = (Map) iterator.next();
			content.append("<tr><td>" + ObjectUtils.toString(unCountBonus.get("STORE_NO")) + "</td>");
			content.append("<td align=\"right\">" + ObjectUtils.toString(unCountBonus.get("UNCOUNT_BONUS")) + "</td></tr>");
		}
		content.append("</table>");
		System.out.println("=================\n" + content.toString() + "\n=================");
		
		return content.toString();
	}
	
	/**
	 * 產生郵件附件
	 * @return 回傳郵件附件
	 * @throws IOException 
	 * @throws WriteException 
	 * @throws RowsExceededException 
	 */
	@SuppressWarnings("unchecked")
	private List getAttachments() throws IOException, RowsExceededException, WriteException {
		List attachmentsList = new ArrayList();
		
		//未算交易明細
		List unCountTransactionDetailList = nmBonusCountCheckDAO.getUnCountTransactionDetail();
		File attachFile = new File("未算交易明細.xls");			
		WritableWorkbook wb = Workbook.createWorkbook(attachFile);			
		WritableSheet ws = wb.createSheet("Sheet1", 0);
		ws.addCell(new Label(0, 0, "店號"));
		ws.addCell(new Label(1, 0, "卡號"));
		ws.addCell(new Label(2, 0, "發票號碼"));
		if(unCountTransactionDetailList != null && unCountTransactionDetailList.size() > 0) {
			for (int i = 0; i < unCountTransactionDetailList.size(); i++) {
				Map detail = (Map) unCountTransactionDetailList.get(i);
				ws.addCell(new Label(0, i+1, ObjectUtils.toString(detail.get("STORE_NO"))));
				ws.addCell(new Label(1, i+1, ObjectUtils.toString(detail.get("CUST_NOS"))));
				ws.addCell(new Label(2, i+1, ObjectUtils.toString(detail.get("GUI_NOS"))));
			}
		}
		wb.write(); 
		wb.close();
		attachmentsList.add(attachFile);
		
		//異常時間傳回交易
		List exceptTransactionReturnList = nmBonusCountCheckDAO.getExceptTransactionReturn();
		attachFile = new File("異常時間傳回交易.xls");			
		wb = Workbook.createWorkbook(attachFile);			
		ws = wb.createSheet("Sheet1", 0);
		ws.addCell(new Label(0, 0, "店號"));
		ws.addCell(new Label(1, 0, "卡號"));
		ws.addCell(new Label(2, 0, "發票號碼"));
		ws.addCell(new Label(3, 0, "POS機號"));
		ws.addCell(new Label(4, 0, "交易序號"));
		ws.addCell(new Label(5, 0, "交易金額"));
		ws.addCell(new Label(6, 0, "回傳時間點"));
		if(exceptTransactionReturnList != null && exceptTransactionReturnList.size() > 0) {
			for (int i = 0; i < exceptTransactionReturnList.size(); i++) {
				Map except = (Map) exceptTransactionReturnList.get(i);
				ws.addCell(new Label(0, i+1, ObjectUtils.toString(except.get("STORE_NO"))));
				ws.addCell(new Label(1, i+1, ObjectUtils.toString(except.get("CUST_NOS"))));
				ws.addCell(new Label(2, i+1, ObjectUtils.toString(except.get("GUI_NOS"))));
				ws.addCell(new Label(3, i+1, ObjectUtils.toString(except.get("POS_NOS"))));
				ws.addCell(new Label(4, i+1, ObjectUtils.toString(except.get("SER_NOS"))));
				ws.addCell(new Label(5, i+1, ObjectUtils.toString(except.get("TRANS_TOT"))));
				ws.addCell(new Label(6, i+1, ObjectUtils.toString(except.get("CRE_TIME"))));
			}
		}
		wb.write(); 
		wb.close();
		attachmentsList.add(attachFile);
		
		return attachmentsList;
	}
	
}
