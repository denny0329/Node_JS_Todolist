package com.gccs.bonus.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gccs.bonus.dao.hibernate.BcBonusMonthSummaryDAO;
import com.gccs.bonus.model.BcBonusMonthSummary;
import com.gccs.bonus.model.BcBonusMonthSummaryForM0;
import com.gccs.bonus.service.summary.AbstractBonusTransaction;
import com.gccs.bonus.service.summary.EBonusTransactionFactory;
import com.gccs.bonus.service.summary.IBonusTransaction;
import com.gccs.bonus.util.BonusDateUtility;
import com.gccs.report.model.vo.Report43;
import com.gccs.report.model.vo.Report45;

/**
 * 會員月紅利現金積點服務
 */
public class BcBonusMonthSummaryService extends BcBonusSummaryService implements IBcBonusSummarySerivce {
	
	private static final Logger log = LogManager.getLogger(BcBonusMonthSummaryService.class) ;
	
	private BcBonusMonthSummaryDAO bcBonusMonthSummaryDao;
	
	public BcBonusMonthSummaryDAO getBcBonusMonthSummaryDao() {
		return bcBonusMonthSummaryDao;
	}

	public void setBcBonusMonthSummaryDao(BcBonusMonthSummaryDAO bcBonusMonthSummaryDao) {
		this.bcBonusMonthSummaryDao = bcBonusMonthSummaryDao;
	}

	/**
	 * 執行批次
	 * (計算前一個月的資料)
	 */
	public void executeBatch() {
		Date now = new Date();
		final String datePattern = "yyyyMMdd";
				
		Calendar cal = Calendar.getInstance();
		String nowString = BonusDateUtility.getStringFromDate(now, datePattern);
		cal.setTime(BonusDateUtility.getDateFromString(nowString, datePattern));
		cal.add(Calendar.MONTH, -1);
		
		String firstDayOfMonth = BonusDateUtility.getFirstDayOfMonth(cal, datePattern) + " 000000";
		String endDayOfMonth = BonusDateUtility.getLastDayOfMonth(cal, datePattern) + " 235959";
		log.info("BcBonusMonthSummaryService executeBatch : firstDayOfMonth = " + firstDayOfMonth + ", endDayOfMonth = " + endDayOfMonth);
		
		//產生model物件List
		this.processBcBonusSummary(firstDayOfMonth, endDayOfMonth);
	}
	
	/**
	 * 執行批次
	 * (計算前一個月的資料)
	 */
	public void executeM0Batch() {
		Date now = new Date();
		final String datePattern = "yyyyMMdd";
				
		Calendar cal = Calendar.getInstance();
		String nowString = BonusDateUtility.getStringFromDate(now, datePattern);
		cal.setTime(BonusDateUtility.getDateFromString(nowString, datePattern));
		cal.add(Calendar.MONTH, -1);
		
		String firstDayOfMonth = BonusDateUtility.getFirstDayOfMonth(cal, datePattern) + " 000000";
		String endDayOfMonth = BonusDateUtility.getLastDayOfMonth(cal, datePattern) + " 235959";
		log.info("BcBonusMonthSummaryService executeM0Batch : firstDayOfMonth = " + firstDayOfMonth + ", endDayOfMonth = " + endDayOfMonth);
		
		// 鮮綠市集計算
		this.processBcBonusSummaryForM0(firstDayOfMonth, endDayOfMonth);
	}
	
	/**
	 * 產生BC_BONUS_MONTH_SUMMARY model物件List
	 * 
	 * @param beginDate 查詢開始日期時間
	 * @param endDate 查詢結束日期時間
	 * @return
	 */
	public void processBcBonusSummary(String beginDate, String endDate) {
		String me = getClass().getName() + ".processBcBonusSummary(String beginDate, String endDate)";
		
		if(StringUtils.isBlank(beginDate) || StringUtils.isBlank(endDate)) {
			log.info(me + ":beginDate/endDate is null, beginDate = " + beginDate + ", endDate = " + endDate);
			return;
		}
		
		//清理積點
		processBcBonusClnSummary(beginDate, endDate);
		
		//處理POS資料
		processPosData(beginDate, endDate);
	}
	
	/**
	 * 產生鮮綠市集 model物件List
	 * 
	 * @param beginDate 查詢開始日期時間
	 * @param endDate 查詢結束日期時間
	 * @return
	 */
	public void processBcBonusSummaryForM0(String beginDate, String endDate) {
		String me = getClass().getName() + ".processBcBonusSummaryForM0(String beginDate, String endDate)";
		
		if(StringUtils.isBlank(beginDate) || StringUtils.isBlank(endDate)) {
			log.info(me + ":beginDate/endDate is null, beginDate = " + beginDate + ", endDate = " + endDate);
			return;
		}
		
		//清理積點
		processBcBonusClnSummaryForM0(beginDate, endDate);
		
		//處理POS資料
		processPosDataForM0(beginDate, endDate);
	}
	
	/**
	 * 產生清理紅利積點資料，同時存檔
	 *
	 * @param isPos 是否為POS下來的資料
	 * @param beginDate 查詢開始日期時間
	 * @param endDate 查詢結束日期時間
	 * @return
	 */
	private void processBcBonusClnSummary(String beginDate, String endDate) {
		Map<String, Object> sqlConditionMap = new HashMap<String, Object>();
		sqlConditionMap.put(BcBonusMonthSummaryDAO.SQL_CONDITION_BEGIN_DATE, beginDate);
		sqlConditionMap.put(BcBonusMonthSummaryDAO.SQL_CONDITION_END_DATE, endDate);
		
		//清理積點
		IBonusTransaction bonusTxn = EBonusTransactionFactory.getInstance(AbstractBonusTransaction.TRANSACTION_TYPES_BONUS_CLN);
		sqlConditionMap.put(BcBonusMonthSummaryDAO.SQL_CONDITION_BONUS_TYPE, bonusTxn.getSqlBonusType());
		
 		List<BcBonusMonthSummary> bcBonusAddList = getBcBonusMonthSummaryDao().findBcBonusMonthSummary(sqlConditionMap);
 		
 		bonusTxn.execBcBonusMonthSummaryList(bcBonusAddList);
		
		//存檔
 		this.saveBcBonusMonthSummary(bonusTxn.getAllBcBonusMonthSummaryList());
	}
	
	/**
	 * 產生清理紅利積點資料，同時存檔
	 *
	 * @param isPos 是否為POS下來的資料
	 * @param beginDate 查詢開始日期時間
	 * @param endDate 查詢結束日期時間
	 * @return
	 */
	private void processBcBonusClnSummaryForM0(String beginDate, String endDate) {
		Map<String, Object> sqlConditionMap = new HashMap<String, Object>();
		sqlConditionMap.put(BcBonusMonthSummaryDAO.SQL_CONDITION_BEGIN_DATE, beginDate);
		sqlConditionMap.put(BcBonusMonthSummaryDAO.SQL_CONDITION_END_DATE, endDate);
		
		//清理積點
		IBonusTransaction bonusTxn = EBonusTransactionFactory.getInstance(AbstractBonusTransaction.TRANSACTION_TYPES_BONUS_CLN);
		sqlConditionMap.put(BcBonusMonthSummaryDAO.SQL_CONDITION_BONUS_TYPE, bonusTxn.getSqlBonusType());
		
 		List<BcBonusMonthSummaryForM0> bcBonusAddList = getBcBonusMonthSummaryDao().findBcBonusMonthSummaryForM0(sqlConditionMap);
 		
 		bonusTxn.execBcBonusMonthSummaryForM0List(bcBonusAddList);
		
		//存檔
 		this.saveBcBonusMonthSummaryForM0(bonusTxn.getAllBcBonusMonthSummaryForM0List());
	}
	
	/**
	 * 處理POS/非POS資料
	 * @param beginDate
	 * @param endDate
	 */
	private void processPosData(String beginDate, String endDate) {
		List<BcBonusMonthSummary> bcBonusMonthSummaryList = new ArrayList<BcBonusMonthSummary>();
		
		//非POS資料
		List<BcBonusMonthSummary> nonPosList = this.processBcBonusSummary(beginDate, endDate, false);
		if (nonPosList != null){
			bcBonusMonthSummaryList.addAll(nonPosList);
		}		
		
		//POS資料(起迄日期要+1)
		beginDate = this.getSecondDayOfDate(beginDate);
		endDate = this.getSecondDayOfDate(endDate);
		List<BcBonusMonthSummary> posList = this.processBcBonusSummary(beginDate, endDate, true);
		
		if (posList != null){
			bcBonusMonthSummaryList.addAll(posList);
		}		
				
		//存檔
 		this.saveBcBonusMonthSummary(bcBonusMonthSummaryList);
	}
	
	/**
	 * 處理POS/非POS資料
	 * @param beginDate
	 * @param endDate
	 */
	private void processPosDataForM0(String beginDate, String endDate) {
		List<BcBonusMonthSummaryForM0> bcBonusMonthSummaryForM0List = new ArrayList<BcBonusMonthSummaryForM0>();
		
		//非POS資料
		List<BcBonusMonthSummaryForM0> nonPosList = this.processBcBonusSummaryForM0(beginDate, endDate, false);
		if (nonPosList != null){
			bcBonusMonthSummaryForM0List.addAll(nonPosList);
		}		
		
		//POS資料(起迄日期要+1)
		beginDate = this.getSecondDayOfDate(beginDate);
		endDate = this.getSecondDayOfDate(endDate);
		List<BcBonusMonthSummaryForM0> posList = this.processBcBonusSummaryForM0(beginDate, endDate, true);
		
		if (posList != null){
			bcBonusMonthSummaryForM0List.addAll(posList);
		}		
				
		//存檔
 		this.saveBcBonusMonthSummaryForM0(bcBonusMonthSummaryForM0List);
	}
	
	/**
	 * 產生BC_BONUS_MONTH_SUMMARY model物件List，同時存檔
	 * 1. CREATOR = SYS_BATCH (由POS下來的資料)
	 * 2. CREATOR <> SYS_BATCH (其他非pos的資料)
	 * 
	 * @param isPos 是否為POS下來的資料
	 * @param beginDate 查詢開始日期時間
	 * @param endDate 查詢結束日期時間
	 * @return
	 */
	private List<BcBonusMonthSummary> processBcBonusSummary(String beginDate, String endDate, boolean isPos) {
		Map<String, Object> sqlConditionMap = new HashMap<String, Object>();
		sqlConditionMap.put(BcBonusMonthSummaryDAO.SQL_CONDITION_IS_POS, isPos);
		sqlConditionMap.put(BcBonusMonthSummaryDAO.SQL_CONDITION_BEGIN_DATE, beginDate);
		sqlConditionMap.put(BcBonusMonthSummaryDAO.SQL_CONDITION_END_DATE, endDate);
		
		IBonusTransaction bonusTxn = null;
		
		for(EBonusTransactionFactory factory : EBonusTransactionFactory.getBatchFactoryList()) {
			bonusTxn = EBonusTransactionFactory.getInstance(factory.name());
			sqlConditionMap.put(BcBonusMonthSummaryDAO.SQL_CONDITION_BONUS_TYPE, bonusTxn.getSqlBonusType());
			
	 		List<BcBonusMonthSummary> bcBonusAddList = getBcBonusMonthSummaryDao().findBcBonusMonthSummary(sqlConditionMap);
	 		bonusTxn.execBcBonusMonthSummaryList(bcBonusAddList);
		}
		
		return bonusTxn.getAllBcBonusMonthSummaryList();
	}
	
	/**
	 * 產生BC_BONUS_MONTH_SUMMARY model物件List，同時存檔
	 * 1. CREATOR = SYS_BATCH (由POS下來的資料)
	 * 2. CREATOR <> SYS_BATCH (其他非pos的資料)
	 * 
	 * @param isPos 是否為POS下來的資料
	 * @param beginDate 查詢開始日期時間
	 * @param endDate 查詢結束日期時間
	 * @return
	 */
	private List<BcBonusMonthSummaryForM0> processBcBonusSummaryForM0(String beginDate, String endDate, boolean isPos) {
		Map<String, Object> sqlConditionMap = new HashMap<String, Object>();
		sqlConditionMap.put(BcBonusMonthSummaryDAO.SQL_CONDITION_IS_POS, isPos);
		sqlConditionMap.put(BcBonusMonthSummaryDAO.SQL_CONDITION_BEGIN_DATE, beginDate);
		sqlConditionMap.put(BcBonusMonthSummaryDAO.SQL_CONDITION_END_DATE, endDate);
		
		IBonusTransaction bonusTxn = null;
		
		for(EBonusTransactionFactory factory : EBonusTransactionFactory.getBatchFactoryList()) {
			bonusTxn = EBonusTransactionFactory.getInstance(factory.name());
			sqlConditionMap.put(BcBonusMonthSummaryDAO.SQL_CONDITION_BONUS_TYPE, bonusTxn.getSqlBonusType());
			
	 		List<BcBonusMonthSummaryForM0> bcBonusAddList = getBcBonusMonthSummaryDao().findBcBonusMonthSummaryForM0(sqlConditionMap);
	 		bonusTxn.execBcBonusMonthSummaryForM0List(bcBonusAddList);
		}
		
		return bonusTxn.getAllBcBonusMonthSummaryForM0List();
	}
	
	/**
	 * 回傳傳入日期的第二天
	 * @param date
	 * @return
	 */
	private String getSecondDayOfDate(String date) {
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(BonusDateUtility.getDateFromString(date, "yyyyMMdd HHmmss"));
		cal.add(Calendar.DATE, 1);
		
		return BonusDateUtility.getStringFromDate(cal.getTime(), "yyyyMMdd HHmmss");
	}
	
	/**
	 * BcBonusMonthSummary存檔
	 * @param bcBonusMonthSummaryList
	 */
	private void saveBcBonusMonthSummary(List<BcBonusMonthSummary> bcBonusMonthSummaryList) {
		if(bcBonusMonthSummaryList == null || bcBonusMonthSummaryList.size() == 0) {
			log.info("bcBonusMonthSummaryList is null, save stop.");
			return ;
		}
		
		try {
			log.info("insert data num:" + bcBonusMonthSummaryList.size());
			getBcBonusMonthSummaryDao().saveOrUpdateCollection(bcBonusMonthSummaryList);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Save Data Error." + e.getMessage(), e);
		} finally {
			AbstractBonusTransaction.clear();
		}
	}
	
	/**
	 * BcBonusMonthSummary存檔
	 * @param bcBonusMonthSummaryList
	 */
	private void saveBcBonusMonthSummaryForM0(List<BcBonusMonthSummaryForM0> bcBonusMonthSummaryList) {
		if(bcBonusMonthSummaryList == null || bcBonusMonthSummaryList.size() == 0) {
			log.info("bcBonusMonthSummaryList is null, save stop.");
			return ;
		}
		
		try {
			log.info("insert data num:" + bcBonusMonthSummaryList.size());
			getBcBonusMonthSummaryDao().saveOrUpdateCollection(bcBonusMonthSummaryList);
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Save Data Error." + e.getMessage(), e);
		} finally {
			AbstractBonusTransaction.clear();
		}
	}
	
	/**
	 * 年度紅利點數積點兌點總表 - 分店 資料列表
	 * @param year 年份
	 * @param month 月份
	 * @param storeId 店端代號
	 * @return
	 */
	public List<Report43> getBcBonusMonthSummaryByCondition(String year, String month, String[] storeId) {
		Map<String, Object> sqlConditionMap = new HashMap<String, Object>();
		sqlConditionMap.put(Report43.CON_YEAR, StringUtils.trim(year));
		sqlConditionMap.put(Report43.CON_MONTH, StringUtils.trim(month));
		sqlConditionMap.put(Report43.CON_STORE_ID, storeId);
		
		List<Report43> list = bcBonusMonthSummaryDao.getReport43Data(sqlConditionMap);
		
		Map<String, Report43> map = new TreeMap<String, Report43>();
		for(Report43 report : list) {
			String key = report.getStoreId();
			
			if(map.containsKey(key)) {
				Report43 tempReport = map.get(key);
				tempReport.setBonusAdd(tempReport.getBonusAdd() + report.getBonusAdd());
				tempReport.setBonusMins(tempReport.getBonusMins() + report.getBonusMins());
				tempReport.setDiscAmt(tempReport.getDiscAmt() + report.getDiscAmt());
				
				map.put(key, tempReport);
			} else {
				map.put(key, report);
			}	
		}
		
		List<Report43> reportList = new ArrayList<Report43>();
		for(Report43 report : map.values()) {
			reportList.add(report);
		}
						
		return reportList;
	}
	
	/**
	 * 年度紅利點數積點兌點總表 - 分店 資料列表
	 * @param year 年份
	 * @param month 月份
	 * @param storeId 店端代號
	 * @return
	 */
	public List<Report45> getBcBonusMonthSummaryByConditionForM0(String year, String month) {
		Map<String, Object> sqlConditionMap = new HashMap<String, Object>();
		sqlConditionMap.put(Report45.CON_YEAR, StringUtils.trim(year));
		sqlConditionMap.put(Report45.CON_MONTH, StringUtils.trim(month));
		
		List<Report45> list = bcBonusMonthSummaryDao.getReport45Data(sqlConditionMap);
						
		return list;
	}
}
