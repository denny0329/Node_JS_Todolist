package com.gccs.bonus.service;

import java.util.Date;
import java.util.List;

import org.hibernate.Session;

import com.gccs.bc.model.BcBonusLog;
import com.gccs.bonus.model.BcBonusTemporalLog;

/**
 * 紅利點數報表服務介面 
 */
public interface IBcBonusTemporalService {

	/**
	 * 批次修改紅利點數總表資料
	 */
	public void batchUpdateBcBonusTemporalSum();
	
	/**
	 * 刪除7天前紅利點數明細資料
	 */
	public void batchDeleteBcBonusTemporalLog();
	
	/**
	 * 依會員代號取最近一筆交易日期資料
	 * @param memberId
	 * @return
	 */
	public Date getMaxTransDateByMemberId(Long memberId);
	
	/**
	 * 1050 for transDate
	 */
	public Date getMaxTransDateByTrcb(List<String> cardNum);
	
	/**
	 * 依會員代號取該會員可用紅利點數
	 * @param memberId
	 * @return
	 */
	public Long getBonusTotalByMemberId(Long memberId);
	
	/**
	 * 依VIP_NO取會員身份證字號
	 * @param vipNo
	 * @return
	 */
	public String getPersonIdByVipNo(String vipNo);
	
	/**
	 * 1. 新增資料至BC_BONUS_TEMPORAL_LOG
	 * 2. 更新BC_BONUS_TEMPORAL_SUM的BONUS_TOTAL欄位
	 * @param log
	 * @param memberId 會員代號
	 * @param personId 會員身份證字號
	 */
	public void transBcBonusTemporal(Session session, BcBonusTemporalLog bcBonusTemportalLog, Long memberId);
	
	/**
	 * 1. 計算bonusTotal後，更新MM_MEMBERS
	 * 2. 新增資料至BC_BONUS_LOG
	 * 3. 新增資料至BC_BONUS_TEMPORAL_LOG
	 * 4. 更新BC_BONUS_TEMPORAL_SUM的BONUS_TOTAL欄位
	 * @param bonusLog
	 */
	public int transBcBonusTemporal(final BcBonusLog bonusLog);
	
	public int transBcBonusTemporalForSom(final BcBonusLog bonusLog);
	
	/**
	 * 即時扣點查詢
	 * @param personId 
	 */
	public long getRealTimeBonusMinsTotal(String personId);
	
}
