package com.gccs.bonus.service;

import org.springframework.transaction.support.TransactionTemplate;

/**
 * 會員紅利現金積點批次計算共用服務
 */
public class BcBonusSummaryService {

	private TransactionTemplate transactionTemplate;
	
	public TransactionTemplate getTransactionTemplate() {
		return transactionTemplate;
	}

	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}

}
