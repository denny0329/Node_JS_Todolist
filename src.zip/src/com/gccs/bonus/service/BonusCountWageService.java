package com.gccs.bonus.service;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.apeo.sender.exception.MessageSenderException;
import com.apeo.sender.model.MessageContent;
import com.bnq.sc.model.ScSysuser;
import com.bnq.util.DateTimeUtils;
import com.bnq.util.StringId;
import com.bnq.util.ftp.FtpConfig;
import com.bnq.util.ftp.FtpFacade;
import com.bnq.util.ftp.dao.hibernate.FtpConfigDao;
import com.bnq.util.mail.MailService;
import com.gccs.base.action.BaseAction;
import com.gccs.bonus.dao.hibernate.BonusCountWageDAO;
import com.gccs.bonus.dao.hibernate.BonusLogDAO;
import com.gccs.bonus.model.BcBonusHisuDetail;
import com.gccs.bonus.model.BcBonusHisuMaster;
import com.gccs.bonus.model.BonusExceptionLog;
import com.gccs.bonus.service.wage.process.NormalCancelProcess;
import com.gccs.bonus.service.wage.process.NormalSaleProcess;
import com.gccs.bonus.service.wage.process.RejectionCancelProcess;
import com.gccs.bonus.service.wage.process.RejectionSaleProcess;
import com.gccs.bonus.util.BonusExceptionGlossary;
import com.gccs.bonus.util.BonusUtility;
import com.gccs.bonus.util.CsvFileUtil;
import com.gccs.util.quartz.IQuartzLogService;
import com.gccs.util.quartz.util.QuartzLogGlossary;

public class BonusCountWageService extends BaseAction {
	private static final long serialVersionUID = 8355200298609075322L;
	private static final Logger log = LogManager.getLogger(BonusCountWageService.class);
	private NormalSaleProcess normalProcess;
	private NormalCancelProcess normalCancelProcess;
	private RejectionSaleProcess rejectionSaleProcess;
	private RejectionCancelProcess rejectionCancelProcess;
	private BonusLogDAO bonusLogDAO;
	private BonusCountWageDAO bonusCountWageDAO;
	private FtpConfigDao ftpConfigDao;
	private IQuartzLogService logService;
	
	private static final String FILE_OK = ".ok";
	private static final String FILE_CSV = ".csv";
	private static final String FILE_DONE = ".done";
	private static final String FILE_FAIL = ".fail";
	private static final String SEP2 = "_";
	private static final String SEP3 = File.separator;
	private static final String HISU_MASTER = "HISU_MASTER";
	private static final String HISU_DETAIL = "HISU_DETAIL";
	private static final String HISU = "HISU";
	private static final String FTP_BEAN_ID = "HISU";
	private static final String NOT_FOUND        = "HISU交易主檔及明細檔未上傳，請重新上傳！";
	private static final String MASTER_NOT_FOUND = "{0} 交易主檔未上傳，請重新上傳！";
	private static final String MASTER_NO_DATA   = "{0} 交易主檔沒有資料，請重新上傳！";
	private static final String DETAIL_NOT_FOUND = "{0} 明細檔未上傳，請重新上傳！";
	private static final String DETAIL_NO_DATA   = "{0} 明細檔沒有資料，請重新上傳！";
	private static final String DOWNLOADING      = "正在下載 {0} ...";
	private static final String batch_id = QuartzLogGlossary._id_bonus_wage_calculate;
	private static final String HISU_BS_TEAM = "HISUBSTEAM";
	private static final int _RETRY_TIMES = 3;
    private int retry = 0;
    private static final SimpleDateFormat DF = new SimpleDateFormat("yyyy/MM/dd");
	private static final SimpleDateFormat DF2 = new SimpleDateFormat("yyyyMMdd");
	
	private FtpFacade ftpFacade = null;
	private String remotePath;
	private String downloadPath;
	
	public void executeBatch(Date inputDate) throws Exception {
		Date transferDate = null;
		if (inputDate != null) {
			transferDate = inputDate;
		} else {
			transferDate = DateTimeUtils.addDate(DateTimeUtils.getFormatSysDate(), -1);
		}
				
		List<BcBonusHisuMaster> mstList = null;
		List<BcBonusHisuDetail> dtlList = null;
		String okFileName = getFileName(HISU, transferDate) + FILE_OK;
		String mstFileName = getFileName(HISU_MASTER, transferDate) + FILE_CSV;
		String dtlFileName = getFileName(HISU_DETAIL, transferDate) + FILE_CSV;
		File mstFile = null;
		File dtlFile = null;
		File okFile = null;
		boolean result=true;
		
		List<FtpConfig> ftpConfigs = ftpConfigDao.loadConfig(FTP_BEAN_ID);
		if (ftpConfigs == null || ftpConfigs.size() == 0) {
			throw new Exception("無法取得FTP相關設定，請檢查SYS_FTP_CONFIG");
		}
		FtpConfig ftpConfig = ftpConfigs.get(0);
		
		try {
			//新建一個FTP客戶端連接 
			log.info("正在連接 " + ftpConfig.getServerIp() + "，請等待...");
			ftpFacade = new FtpFacade(ftpConfig);
			log.info("連接主机 " + ftpConfig.getServerIp() + " 成功");
		}catch(Exception e){
			result=false;
			log.error("無法與FTP("+ ftpConfig.getServerIp() + ") 建立連接，5秒後重試.....");
		}
		
		try {
			if(!result && retry < _RETRY_TIMES) {
	        	Thread.sleep(5000);
	        	retry ++;
	        	executeBatch(inputDate);
	        }
			
			if(retry >= _RETRY_TIMES) 
				throw new Exception("無法與FTP("+ ftpConfig.getServerIp() + ")建立連接，請檢查SYS_FTP_CONFIG");
			
			remotePath=ftpConfig.getDownload_path();
			downloadPath=ftpConfig.getRcv_awaiting_path();
			log.info("[bonusCountWageProcess] converting.... remotePath="+remotePath+",downloadPath="+downloadPath);
			
			try {
				log.info(getMessage(DOWNLOADING, okFileName));
				okFile = ftpFacade.receiveFile(remotePath, okFileName, downloadPath, okFileName);
				log.info("下載成功");
			}catch(IOException e){
				log.error("下載 " + okFileName + " 失敗，"+e.getMessage());
			}
			if (okFile == null) 
				throw new Exception(NOT_FOUND);
			
			try {
				log.info(getMessage(DOWNLOADING, mstFileName));
				mstFile = ftpFacade.receiveFile(remotePath, mstFileName, downloadPath, mstFileName);
				log.info("下載成功");
			}catch(IOException e){
				log.error("下載 " + mstFileName + " 失敗，"+e.getMessage());
			}
			if (mstFile == null) 
				throw new Exception(getMessage(MASTER_NOT_FOUND, mstFileName));
			
			try {
				log.info(getMessage(DOWNLOADING, dtlFileName));
				dtlFile = ftpFacade.receiveFile(remotePath, dtlFileName, downloadPath, dtlFileName);
				log.info("下載成功");
			}catch(IOException e){
				log.error("下載 " + dtlFileName + " 失敗，"+e.getMessage());
			} finally {
				if (ftpFacade != null){
					ftpFacade.disConnect();
					log.info("與主機連接已斷開");
				}
			}
			if (dtlFile == null)
				throw new Exception(getMessage(DETAIL_NOT_FOUND, dtlFileName));
			
			mstList = getBcBonusHisuMasterList(mstFile);
			if (mstList == null || mstList.size() == 0)
				throw new Exception(getMessage(MASTER_NO_DATA, mstFileName));
			
			dtlList = getBcBonusHisuDetailList(dtlFile);
			if (dtlList == null || dtlList.size() == 0)
				throw new Exception(getMessage(DETAIL_NO_DATA, dtlFileName));

			Date beginDate = DateTimeUtils.getSysDate();
			// 更新Batch Log
			logService.batchProcessBegin(batch_id, beginDate);

			long l1 = System.currentTimeMillis();
			log.info("[bonusCountWageProcess] launched.");
			// 紅利計算
			bonusCountWageProcess(transferDate, mstList, dtlList);
			Date endDate = DateTimeUtils.getSysDate();
			// 更新Batch Log
			logService.batchProcessEnd(batch_id, beginDate, endDate);

			long l2 = System.currentTimeMillis();
			log.info("[bonusCountWageProcess] task finish. time cost : " + ((l2 - l1) / 1000));

			FileUtils.deleteQuietly(okFile);
			if (mstFile!=null && mstFile.exists())
				mstFile.renameTo(new File(downloadPath+SEP3+mstFileName.replace(FILE_CSV,FILE_DONE)));
			if (dtlFile!=null && dtlFile.exists())
				dtlFile.renameTo(new File(downloadPath+SEP3+dtlFileName.replace(FILE_CSV,FILE_DONE)));

			try {
				//新建一個FTP客戶端連接 
				log.info("重新連接 " + ftpConfig.getServerIp() + "，請等待...");
				ftpFacade = new FtpFacade(ftpConfig);
				log.info("連接主机 " + ftpConfig.getServerIp() + " 成功");
				ftpFacade.delete(remotePath, mstFileName);
				ftpFacade.delete(remotePath, dtlFileName);
				ftpFacade.delete(remotePath, okFileName);
				log.info("刪除遠程文件成功");
			}catch(Exception e){
				log.error("刪除遠程文件失敗，" + e.getMessage(), e);
			} finally {
				if (ftpFacade != null){
					ftpFacade.disConnect();
					log.info("與主機連接已斷開");
				}
			}
		} catch (Exception e) {
			result=false;
			sendMailToHisuTeam("紅利批次執行作業，" + (StringUtils.isBlank(e.getMessage()) ? ERROR_MSG : e.getMessage()));
			throw e;
		} finally {
			if (ftpFacade != null){
				ftpFacade.disConnect();
				log.info("與主機連接已斷開");
			}
			if(!result){
				FileUtils.deleteQuietly(okFile);
				if (mstFile!=null && mstFile.exists())
					mstFile.renameTo(new File(downloadPath+SEP3+mstFileName.replace(FILE_CSV,FILE_FAIL)));
				if (dtlFile!=null && dtlFile.exists())
					dtlFile.renameTo(new File(downloadPath+SEP3+dtlFileName.replace(FILE_CSV,FILE_FAIL)));
			}
		}
		ftpFacade = null;
		mstList = null;
		dtlList = null;
	}
	
	/**
	 * 執行異常時發送Email
	 */
	public void sendMailToHisuTeam(final String exMessage) {
		try {
			final List<StringId> mailList=new ArrayList<StringId>();
			ScSysuser user = this.getScSysuserService().find(HISU_BS_TEAM,"1010");
			if (user != null && user.getEMail() != null) {
				user.setEMail(user.getEMail().replaceAll("\\，",","));
				for(String mail:user.getEMail().split(",")) {
					mailList.add(new StringId(mail,mail.split("@")[0]));
				}
				new Thread() {   
					public void run() {
						for(StringId str:mailList){
							MessageContent content = new MessageContent();
							content.setSubject("會員紅利點數計算-HISU 工資計算通知");
							content.setContent(exMessage);
							content.setReceiverInfo(str.getId());
							content.setReveiverName(str.getName());
							try {
								MailService.sendMessage(content.getContent(), content.getSubject(), 
										content.getReceiverInfo(), content.getReveiverName(), new ArrayList());
							} catch (MessageSenderException e) {
								e.printStackTrace();
								log.error("寄件失敗:["+str.getId()+"]"+e.getMessage());
							}
							content=null;
						}
					}
				}.start();
			} else {
				log.error("無法取得HISUBSTEAM的Email，請檢查SC_SYS_USER");
			}
		} catch (Exception e) {
			log.error("取出HISUBSTEAM的Email失敗，"+e.getMessage());
		}
	}
	
	public static List<BcBonusHisuMaster> getBcBonusHisuMasterList(File file) throws Exception {
		List<BcBonusHisuMaster> masterList = null;
		BcBonusHisuMaster master = null;
		try {
			masterList = new ArrayList<BcBonusHisuMaster>();
			List<String[]> dataList = CsvFileUtil.readCsvFile(file);
			for (String[] tempData : dataList) {
				master = new BcBonusHisuMaster();
				master.setStore_no(tempData[0]);// 交易店別
				if (tempData[1] != null)
					master.setTrans_dat(DF.parse(tempData[1].replaceAll("\\-", "/")));// 交易日期
				master.setPos_nos(tempData[2]);// POS機號
				master.setSer_nos(tempData[3]);// 交易序號
				master.setSale_type(tempData[4]);// 交易類別
				master.setSale_sta(tempData[5]);// 交易狀態
				master.setGui_nos(tempData[6]);// 發票號碼
				master.setCust_nos(com.bnq.util.StringUtils.formatNumber(tempData[7]));// 會員卡號
				master.setCust_id(com.bnq.util.StringUtils.formatNumber(tempData[8]));// 身份證號碼
				if (tempData[9] != null)
					master.setTrans_tot(Double.valueOf(com.bnq.util.StringUtils.formatNumber(tempData[9])));// 交易總額
				master.setSo_nos(com.bnq.util.StringUtils.formatNumber(tempData[10]));// SO單號
				master.setRet_nos(com.bnq.util.StringUtils.formatNumber(tempData[11]));// 折讓單號
				if (tempData.length >= 12 && StringUtils.isNotEmpty(tempData[12])) 
					master.setCancel_dat(DF.parse(tempData[12].replaceAll("\\-", "/")));
				masterList.add(master);
				master = null;
			}
		} catch (Exception e) {
			log.error("getBcBonusHisuMasterList error." + e.getMessage());
			throw new Exception("獲取工資交易主檔失敗：" + e.getMessage());
		}
		return masterList;
	}

	public static List<BcBonusHisuDetail> getBcBonusHisuDetailList(File file) throws Exception {
		List<BcBonusHisuDetail> detailList = null;
		BcBonusHisuDetail detail = null;
		try {
			detailList = new ArrayList<BcBonusHisuDetail>();
			List<String[]> dataList = CsvFileUtil.readCsvFile(file);
			for (String[] tempData : dataList) {
				detail = new BcBonusHisuDetail();
				detail.setStoreNo(tempData[0]);// 交易店別
				if (StringUtils.isNotBlank(tempData[1]))
					detail.setTransDat(DF.parse(tempData[1].replaceAll("\\-", "/")));// 交易日期
				detail.setPosNos(tempData[2]);// POS機號
				detail.setSerNos(tempData[3]);// 交易序號
				detail.setItemSer(tempData[4]);// 商品交易序號
				detail.setSkuNo(com.bnq.util.StringUtils.formatNumber(tempData[5]));// SKU
				detail.setSkuName(tempData[6]);// 商品名稱
				detail.setSkuType(tempData[7]);// 商品類別
				if (tempData[8] != null)
					detail.setTransQty(Integer.valueOf(tempData[8]));// 數量
				if (tempData[9] != null)
					detail.setActualAmt(Double.valueOf(com.bnq.util.StringUtils.formatNumber(tempData[9])));// 金額
				detail.setSubDept(tempData[10]);// 商品分類
				detail.setClassStr(tempData[11]);// 商品分類
				detail.setSubClass(tempData[12]);// 商品分類
				detail.setVendorId(tempData[13]);// 廠商編號
				if (tempData[14] != null)
					detail.setVatType(Integer.valueOf(tempData[14]));// 應/未稅
				detail.setSkuStatus(tempData[15]);// SKU狀態
				detailList.add(detail);
				detail = null;
			}
		} catch (Exception e) {
			log.error("getBcBonusHisuDetailList error." + e.getMessage());
			throw new Exception("獲取工資交易明细失敗：" + e.getMessage());
		}
		return detailList;
	}
	
	private String getFileName(String code,Date date) {
		StringBuilder sb = new StringBuilder();
		sb.append(code).append(SEP2).append(DF2.format(date));
		return sb.toString();
	}
	
	/** HISU工資處理程序
	 * @param inputDate
	 * @param storeNo
	 */
	public void bonusCountWageProcess(Date inputDate,List mstList,List dtlList) throws Exception {
		Date transferDate = null;
		if(inputDate!=null) {
			transferDate = inputDate;
		} else {
			try {
				//取得所要計算的交易日
				transferDate = DateTimeUtils.addDate(DateTimeUtils.getFormatSysDate(), -1);
			} catch(Exception e) {
				log.error(e.getStackTrace());
			} catch(Throwable t) {
				log.error(t.getStackTrace());
			}
		}

		if(transferDate!=null) {
			log.info("Transfer Wage_Bonus Beging time : "+DateTimeUtils.getSysDate());
			//依交易日期刪除資料
			this.getBonusCountWageDAO().deleteHisuMasterByTransDate(transferDate);
			//將工資主檔、明細檔保存至資料庫
			this.getBonusCountWageDAO().saveHisuMasterByList(mstList, dtlList);
			long time1 = DateTimeUtils.getSysDate().getTime();
			//正常交易
			this.getNormalProcess().bonusProcess(transferDate, null);
			long timeTemp1 = System.currentTimeMillis();
			log.info("normal process end total cost time : "+(timeTemp1-time1)/1000);
			//正常作廢
			this.getNormalCancelProcess().bonusProcess(transferDate, null);
			long timeTemp2 = System.currentTimeMillis();
			log.info("normal cancel process end total cost time : "+(timeTemp2-time1)/1000);
			//退貨交易
			this.getRejectionSaleProcess().bonusProcess(transferDate, null);
			long timeTemp3 = System.currentTimeMillis();
			log.info("rejection process end total cost time : "+(timeTemp3-time1)/1000);
			//退貨作廢
			this.getRejectionCancelProcess().bonusProcess(transferDate, null);
			long timeTemp4 = System.currentTimeMillis();
			log.info("rejection cancel process end total cost time : "+(timeTemp4-time1)/1000);

			log.info("Transfer Wage_Bonus End time : "+DateTimeUtils.getSysDate());
			long time2 = DateTimeUtils.getSysDate().getTime();
			log.info("cost Wage_Bonus count second : "+(time2-time1)/1000);
		} else {
			//日期無法取得
			BonusExceptionLog exceptionLog = BonusUtility.createExceptionLog(BonusExceptionGlossary._exception_type_non_transfer_date, new Date(), null);
			this.getBonusLogDAO().save(exceptionLog);
		}
	}
	
	public NormalSaleProcess getNormalProcess() {
		return normalProcess;
	}

	public void setNormalProcess(NormalSaleProcess normalProcess) {
		this.normalProcess = normalProcess;
	}

	public NormalCancelProcess getNormalCancelProcess() {
		return normalCancelProcess;
	}

	public void setNormalCancelProcess(NormalCancelProcess normalCancelProcess) {
		this.normalCancelProcess = normalCancelProcess;
	}

	public RejectionSaleProcess getRejectionSaleProcess() {
		return rejectionSaleProcess;
	}

	public void setRejectionSaleProcess(RejectionSaleProcess rejectionSaleProcess) {
		this.rejectionSaleProcess = rejectionSaleProcess;
	}

	public RejectionCancelProcess getRejectionCancelProcess() {
		return rejectionCancelProcess;
	}

	public void setRejectionCancelProcess(RejectionCancelProcess rejectionCancelProcess) {
		this.rejectionCancelProcess = rejectionCancelProcess;
	}
	
	public BonusLogDAO getBonusLogDAO() {
		return bonusLogDAO;
	}

	public void setBonusLogDAO(BonusLogDAO bonusLogDAO) {
		this.bonusLogDAO = bonusLogDAO;
	}
	
	public BonusCountWageDAO getBonusCountWageDAO() {
		return bonusCountWageDAO;
	}

	public void setBonusCountWageDAO(BonusCountWageDAO bonusCountWageDAO) {
		this.bonusCountWageDAO = bonusCountWageDAO;
	}

	public FtpConfigDao getFtpConfigDao() {
		return ftpConfigDao;
	}

	public void setFtpConfigDao(FtpConfigDao ftpConfigDao) {
		this.ftpConfigDao = ftpConfigDao;
	}

	public IQuartzLogService getLogService() {
		return logService;
	}

	public void setLogService(IQuartzLogService logService) {
		this.logService = logService;
	}
}
