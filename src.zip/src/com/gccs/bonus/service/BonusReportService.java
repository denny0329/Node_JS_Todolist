package com.gccs.bonus.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.math.NumberUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gccs.bonus.dao.hibernate.BonusLogDAO;
import com.gccs.bonus.model.vo.RptEpos05;
import com.gccs.bonus.model.vo.RptEpos11;

public class BonusReportService {
	
	private static final Logger log = LogManager.getLogger(BonusReportService.class);
	
	private BonusLogDAO dao;

	public BonusLogDAO getDao() {
		return dao;
	}

	public void setDao(BonusLogDAO dao) {
		this.dao = dao;
	}
	
	/**
	 * 積點活動效益表
	 * @author JL
	 * @param dataYearMonth
	 * @param costPercent
	 * @return
	 * @throws Throwable
	 */
	public List<RptEpos05> processEposRpt05(String dataYearMonth,String costPercent)throws Throwable{
		List<Object[]> list = getDao().getEposRpt05Data(dataYearMonth);
		ArrayList<RptEpos05> dataList = new ArrayList<RptEpos05>();
		if (list!=null){
			RptEpos05 tempVo = null;
			Double percent = (NumberUtils.isNumber(costPercent)? Double.valueOf(costPercent):0d);
			for(Object[] obj: list){
				tempVo = new RptEpos05(
						(String)obj[0], (String)obj[1], (Double)obj[2], (Double)obj[3], (Double)obj[4], (Double)obj[5]);
				tempVo.setPercent(percent);
				dataList.add(tempVo);
			}
		}
		return dataList;
		
	}
	
	/**
	 * 取得點數級距表
	 * @author JL
	 * @return
	 * @throws Throwable
	 */
	public List<RptEpos11> processEposRpt11()throws Throwable{
		List<Object[]> list = getDao().getEposRpt11Data();
		ArrayList<RptEpos11> dataList = new ArrayList<RptEpos11>();
		if (list!=null){
			RptEpos11 tempVo = null;
			for(Object[] obj: list){
				tempVo = new RptEpos11(
						(String)obj[0],(Double)obj[1],(Double)obj[2],(Double)obj[3],(Double)obj[4]
						, (Double)obj[5], (Double)obj[6]);
				dataList.add(tempVo);
			}
		}
		return dataList;
		
	}
}
