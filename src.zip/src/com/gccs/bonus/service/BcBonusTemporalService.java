package com.gccs.bonus.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.orm.hibernate3.HibernateCallback;

import com.bnq.util.serial.dao.IBcBonusSerialNumDao;
import com.gccs.bc.model.BcBonusLog;
import com.gccs.bonus.dao.hibernate.BcBonusTemporalLogDAO;
import com.gccs.bonus.dao.hibernate.BcBonusTemporalSumDAO;
import com.gccs.bonus.dao.hibernate.BonusLogDAO;
import com.gccs.bonus.model.BcBonusTemporalLog;
import com.gccs.bonus.model.BcBonusTemporalSum;
import com.gccs.bonus.util.BonusUtility;
import com.gccs.bs.dao.hibernate.BsManagerDao;
import com.gccs.member.card.model.MmCard;
import com.gccs.member.model.Members;
import com.gccs.mmbonus.dao.hibernate.MmBonusDAO;
import com.gccs.mmbonus.model.MmMembersBonus;
import com.gccs.ws.service.BaseWebService;

/**
 * 紅利點數報表服務實作 
 */
@SuppressWarnings("all")
public class BcBonusTemporalService implements IBcBonusTemporalService {

	private static final Logger log = LogManager.getLogger(BcBonusTemporalService.class);
	private static final int reduce_bonus = 1107;
	private static final int reduce_bonus1 = 1110;
	private static final int add_bonus = 1172;
	
	private static final int bs_type_10 = 10;
	private static final int bs_type_9 = 9;
	private static final int bs_type_8 = 8;
	
	private BcBonusTemporalSumDAO bcBonusTemporalSumDao;
	private BcBonusTemporalLogDAO bcBonusTemporalLogDao;
	private MmBonusDAO mmBonusDAO;
	private BonusLogDAO bonusLogDao;
	public BsManagerDao bsManagerDao;
	private IBcBonusSerialNumDao bcBonusSerialNumDao;
	
	public BcBonusTemporalSumDAO getBcBonusTemporalSumDao() {
		return bcBonusTemporalSumDao;
	}

	public void setBcBonusTemporalSumDao(BcBonusTemporalSumDAO bcBonusTemporalSumDao) {
		this.bcBonusTemporalSumDao = bcBonusTemporalSumDao;
	}
	
	public BcBonusTemporalLogDAO getBcBonusTemporalLogDao() {
		return bcBonusTemporalLogDao;
	}

	public void setBcBonusTemporalLogDao(BcBonusTemporalLogDAO bcBonusTemporalLogDao) {
		this.bcBonusTemporalLogDao = bcBonusTemporalLogDao;
	}
	
	public BonusLogDAO getBonusLogDao() {
		return bonusLogDao;
	}

	public void setBonusLogDao(BonusLogDAO bonusLogDao) {
		this.bonusLogDao = bonusLogDao;
	}

	public BsManagerDao getBsManagerDao() {
		return bsManagerDao;
	}

	public void setBsManagerDao(BsManagerDao bsManagerDao) {
		this.bsManagerDao = bsManagerDao;
	}
	public MmBonusDAO getMmBonusDAO() {
		return mmBonusDAO;
	}
	public void setMmBonusDAO(MmBonusDAO mmBonusDAO) {
		this.mmBonusDAO = mmBonusDAO;
	}
	public IBcBonusSerialNumDao getBcBonusSerialNumDao() {
		return bcBonusSerialNumDao;
	}

	public void setBcBonusSerialNumDao(IBcBonusSerialNumDao bcBonusSerialNumDao) {
		this.bcBonusSerialNumDao = bcBonusSerialNumDao;
	}

	/**
	 * 批次修改紅利點數總表資料
	 */
	public void batchUpdateBcBonusTemporalSum() {
		//清空紅利點數總表資料 使用truncate
		getBcBonusTemporalSumDao().truncateBcBonusTemporalSum();
		//新增紅利點數總表資料 使用insert into select
		getBcBonusTemporalSumDao().insertBcBonusTemporalSum();		
	}
	
	/**
	 * 刪除30天前紅利點數明細資料
	 */
	public void batchDeleteBcBonusTemporalLog() {
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.DATE, -30);
		
		getBcBonusTemporalLogDao().deleteInvalidBcBonusTemporalLog(cal.getTime());
	}
	
	/**
	 * 依會員代號取最近一筆交易日期資料
	 * @param memberId
	 * @return
	 */
	public Date getMaxTransDateByMemberId(Long memberId) {
		if(memberId != null) {
			return getBonusLogDao().getMaxTransDateByMemberId(memberId);
		}
		return null;
	}
	
	public Date getMaxTransDateByTrcb(List<String> cardNum) {
		if(cardNum != null) {
			return getBonusLogDao().getMaxTransDateByTrcb(cardNum);
		}
		return null;
	}
	
	/**
	 * 依會員代號取該會員可用紅利點數
	 * @param memberId
	 * @return
	 */
	public Long getBonusTotalByMemberId(Long memberId) {
		if(memberId != null) {
			return getBcBonusTemporalSumDao().getBonusTotalByMemberId(memberId);
		}
		return null;
	}
	
	/**
	 * 依VIP_NO取會員身份證字號
	 * @param vipNo
	 * @return
	 */
	public String getPersonIdByVipNo(String vipNo) {
		if(StringUtils.isNotBlank(vipNo)) {
			return getBcBonusTemporalLogDao().getPersonIdByVipNo(vipNo);
		}
		return null;
	}
	
	/**
	 * 1. 新增資料至BC_BONUS_TEMPORAL_LOG
	 * 2. 更新BC_BONUS_TEMPORAL_SUM的BONUS_TOTAL欄位
	 * @param log
	 * @param memberId 會員代號
	 * @param personId 會員身份證字號
	 */
	public void transBcBonusTemporal(Session session, BcBonusTemporalLog bcBonusTemportalLog, Long memberId) {
		String me = getClass().getName() + ".transBcBonusTemporal()";
		
		if(bcBonusTemportalLog == null) {
			log.error(me + ":bcBonusTemporalLog is null");
			return;
		}
		
		if(memberId == null || memberId == 0) {
			log.error(me + ":memberId is null");
			return;
		}
		
		getBcBonusTemporalLogDao().addBcBonusTemporalLog(session, bcBonusTemportalLog, memberId);
	}
	
	/**
	 * 1. 計算bonusTotal後，更新MM_MEMBERS
	 * 2. 新增資料至BC_BONUS_LOG
	 * 3. 新增資料至BC_BONUS_TEMPORAL_LOG
	 * 4. 更新BC_BONUS_TEMPORAL_SUM的BONUS_TOTAL欄位
	 * @param bonusLog
	 */
	public int transBcBonusTemporal(final BcBonusLog bonusLog) {
		
		final String userId = "SYSTEM";
		final String userName = "系統";
		final Date now = new Date();
		
		return (Integer)getBonusLogDao().getHibernateTemplate().execute(
	        new HibernateCallback() {
	        	public Object doInHibernate(Session session) {
	        		
	        		Transaction tx = session.beginTransaction();
	        		
	        		Members member = getBsManagerDao().loadMemberByVipNo(bonusLog.getVipNo());
	        		
	        		//channel bonuslog.
	        		BcBonusTemporalSum bcBonusTemporalSum = null;
	        		if(member == null) {
	        			BaseWebService.throwError("1", "vip_no(" + bonusLog.getVipNo() + ")查無會員");
	        		} else {
	        			bcBonusTemporalSum = getBcBonusTemporalSumDao().queryBcBonusTemporalSum(session, member.getMemberId(), member.getPersonId());
	        		}
	        		MmMembersBonus mmMembersBonus = null;
	        		try{
	        			  MmCard mmCard =  getBsManagerDao().loadCardByVipno(bonusLog.getVipNo());
	        			  mmMembersBonus = mmBonusDAO.findMmMembersBonusByParms(mmCard.getCompanyId(), member.getMemberId());
	        			  if(mmMembersBonus==null) mmMembersBonus = new MmMembersBonus(mmCard.getCompanyId(),bonusLog.getChannelId(),member.getMemberId());
	        		}catch(Exception e){ 
	        			log.error("get bonustotal error", e);
	        			BaseWebService.throwError("PERSON_ID:" + member.getPersonId() + "addBonuslog失敗\n"+e.getMessage());
	        		}
	        		
	        		// 未避免即時折抵和會員bonusTotal不一致，所以二個bonusTotal必須分開計算
	        		int membersTotal = 0;
	        		int membersBonusTotal = 0;
	        		int bcBonusTemporalSumTotal = 0;
	        		int bcBonusTemporalSumBonusTotal = 0;
	        		
	        		//不分type計算方式改成相同
	        		membersBonusTotal = mmMembersBonus.getBonusTotal();
    				membersTotal = membersBonusTotal + bonusLog.getBonusAdd() - bonusLog.getBonusMins();
//	        		switch(bonusLog.getBonusType()){
//	        			case reduce_bonus:
//	        			case reduce_bonus1:
//	        				if(bcBonusTemporalSum != null){
//	        					bcBonusTemporalSumBonusTotal = (bcBonusTemporalSum.getBonusTotal() == null) ? 0 : (int)(long)bcBonusTemporalSum.getBonusTotal();
//	        				}
//	        				//membersBonusTotal = (member.getBonusTotal() == null) ? 0 : member.getBonusTotal();
//	        				membersBonusTotal = mmMembersBonus.getBonusTotal();
//	        				
//	        				bcBonusTemporalSumTotal = bcBonusTemporalSumBonusTotal - bonusLog.getBonusMins();
//	        				membersTotal = membersBonusTotal - bonusLog.getBonusMins();
//	        				break;
//	        			case add_bonus:
//	        				if(bcBonusTemporalSum != null){
//	        					bcBonusTemporalSumBonusTotal = (bcBonusTemporalSum.getBonusTotal() == null) ? 0 : (int)(long)bcBonusTemporalSum.getBonusTotal();
//	        				}
//	        				//membersBonusTotal = (member.getBonusTotal() == null) ? 0 : member.getBonusTotal();
//	        				membersBonusTotal = mmMembersBonus.getBonusTotal();
//	        				
//	        				bcBonusTemporalSumTotal = bcBonusTemporalSumBonusTotal + bonusLog.getBonusAdd();
//	        				membersTotal = membersBonusTotal + bonusLog.getBonusAdd();
//	        				break;
//	        				
//	        			default:
//	        				//membersBonusTotal = (member.getBonusTotal() == null) ? 0 : member.getBonusTotal();
//	        				membersBonusTotal = mmMembersBonus.getBonusTotal();
//	        				membersTotal = membersBonusTotal + bonusLog.getBonusAdd() - bonusLog.getBonusMins();
//	        				break;
//	        		}
	        		
	        		try {
		        		//新增BC_BONUS_LOG資料，記錄以members的bonusTotal為準
		        		bonusLog.setMemberOid(member.getOid());
		        		bonusLog.setMemberId(member.getMemberId());
		        		bonusLog.setBonusTotal(membersTotal);	        		
		        		bonusLog.setCreator(userId);
		        		bonusLog.setCreatorName(userName);
		        		bonusLog.setCreateTime(now);
		        		bonusLog.setModifier(userId);
		        		bonusLog.setModifierName(userName);
		        		bonusLog.setModifyTime(now);	        		
		        		session.save(bonusLog);
		        		
		        		//修改MM_MEMBERS_BONUS資料
		        		Map<String, Integer> map = BonusUtility.CalculateBonus(bonusLog.getBonusAdd(), bonusLog.getBonusMins(), mmMembersBonus.getThisYearTot(), 
		        				mmMembersBonus.getLastYearTot());
		        		mmMembersBonus.setBonusTotalYday(mmMembersBonus.getBonusTotal());
		        		mmMembersBonus.setThisYearTotYday(mmMembersBonus.getThisYearTot());
		        		mmMembersBonus.setLastYearTotYday(mmMembersBonus.getLastYearTot());
		        		mmMembersBonus.setThisYearTot(map.get("thisYearTot"));
		        		mmMembersBonus.setLastYearTot(map.get("lastYearTot"));
		        		mmMembersBonus.setBonusTotal(membersTotal);
		        		mmMembersBonus.setModifyTime(new Date());
		        		session.saveOrUpdate(mmMembersBonus);
		        		
		        		if(bonusLog.getBonusType() == reduce_bonus || bonusLog.getBonusType() == reduce_bonus1 || bonusLog.getBonusType() == add_bonus){
		        			
		        			//更新BC_BONUS_TEMPORAL_SUM資料
		        			getBcBonusTemporalSumDao().updateSumBonusTotal(
		        					session, 
		        					new Long(bcBonusTemporalSumTotal), 
		        					bonusLog.getMemberId(), 
		        					member.getPersonId()
		        			);
			        		
		        			//新增BC_BONUS_TEMPORAL_LOG資料
			        		BcBonusTemporalLog log = new BcBonusTemporalLog(bonusLog);
			        		log.setPersonId(member.getPersonId());
			        		log.setModifiedTime(now);
			        		session.save(log);
		        		}
		        		
		        		tx.commit();
	        		} catch (Exception e) {
	        			log.error("transBcBonusTemporal error", e);
	        			tx.rollback();
	        			BaseWebService.throwError("PERSON_ID:" + member.getPersonId() + "addBonuslog失敗\n"+e.getMessage());
	        		} finally {
	        			if(session != null) {
	        				session.close();
	        			}
	        		}
	        		
	        		return membersTotal;
	        	}		        	
	        }
		);
	}
	
	/**
	 * 1. 計算bonusTotal後，更新MM_MEMBERS
	 * 2. 新增資料至BC_BONUS_LOG
	 * 3. 新增資料至BC_BONUS_TEMPORAL_LOG
	 * 4. 更新BC_BONUS_TEMPORAL_SUM的BONUS_TOTAL欄位
	 * @param bonusLog
	 */
	public int transBcBonusTemporalForSom(final BcBonusLog bonusLog) {
		return (Integer)getBonusLogDao().getHibernateTemplate().execute(
	        new HibernateCallback() {
	        	public Object doInHibernate(Session session) {
	        		
	        		Transaction tx = session.beginTransaction();
	        		
	        		Members member = getBsManagerDao().loadMemberByVipNo(bonusLog.getVipNo());
	        		
	        		//channel bonuslog.
	        		BcBonusTemporalSum bcBonusTemporalSum = null;
	        		if(member == null) {
	        			BaseWebService.throwError("1", "vip_no(" + bonusLog.getVipNo() + ")查無會員");
	        		} else {
	        			bcBonusTemporalSum = getBcBonusTemporalSumDao().queryBcBonusTemporalSum(session, member.getMemberId(), member.getPersonId());
	        		}
	        		MmMembersBonus mmMembersBonus = null;
	        		try{
	        			  MmCard mmCard =  getBsManagerDao().loadCardByVipno(bonusLog.getVipNo());
	        			  mmMembersBonus = mmBonusDAO.findMmMembersBonusByParms(mmCard.getCompanyId(), member.getMemberId());
	        			  if(mmMembersBonus==null) mmMembersBonus = new MmMembersBonus(mmCard.getCompanyId(),bonusLog.getChannelId(),member.getMemberId());
	        		}catch(Exception e){ 
	        			log.error("get bonustotal error", e);
	        			BaseWebService.throwError("PERSON_ID:" + member.getPersonId() + "addBonuslog失敗\n"+e.getMessage());
	        		}
	        		
	        		// 未避免即時折抵和會員bonusTotal不一致，所以二個bonusTotal必須分開計算
	        		int membersTotal = 0;
	        		int membersBonusTotal = 0;
	        		int bcBonusTemporalSumTotal = 0;
	        		int bcBonusTemporalSumBonusTotal = 0;
	        		
	        		Integer bs_type = getBonusLogDao().findBsTypeByMarketId(bonusLog.getMarketId());
	        		findBonustype(bs_type, bonusLog);
	        		
	        		if(bs_type==8||bs_type==9||bs_type==10){
	        			bonusLog.setDiscAmt(getBonusLogDao().findSettingDtlType(bs_type,bonusLog.getMarketId()));
	        			
	        			if(bonusLog.getBonusAdd()!=0){
	        				if(bcBonusTemporalSum != null){
	        					bcBonusTemporalSumBonusTotal = (bcBonusTemporalSum.getBonusTotal() == null) ? 0 : (int)(long)bcBonusTemporalSum.getBonusTotal();
	        				}
	        				membersBonusTotal = mmMembersBonus.getBonusTotal();
	        				
	        				bcBonusTemporalSumTotal = bcBonusTemporalSumBonusTotal + bonusLog.getBonusAdd();
	        				membersTotal = membersBonusTotal + bonusLog.getBonusAdd();
	        			}else{
	        				if(bcBonusTemporalSum != null){
	        					bcBonusTemporalSumBonusTotal = (bcBonusTemporalSum.getBonusTotal() == null) ? 0 : (int)(long)bcBonusTemporalSum.getBonusTotal();
	        				}
	        				membersBonusTotal = mmMembersBonus.getBonusTotal();
	        				
	        				bcBonusTemporalSumTotal = bcBonusTemporalSumBonusTotal - bonusLog.getBonusMins();
	        				membersTotal = membersBonusTotal - bonusLog.getBonusMins();
	        			}
	        		}else{
	        			membersBonusTotal = mmMembersBonus.getBonusTotal();
        				membersTotal = membersBonusTotal + bonusLog.getBonusAdd() - bonusLog.getBonusMins();
	        		}
	        		
	        		try {
		        		//新增BC_BONUS_LOG資料，記錄以members的bonusTotal為準
		        		bonusLog.setMemberOid(member.getOid());
		        		bonusLog.setMemberId(member.getMemberId());
		        		bonusLog.setBonusTotal(membersTotal);	        		
		        		bonusLog.setCreator(bonusLog.getCreator());
		        		bonusLog.setCreatorName(bonusLog.getCreator());
		        		bonusLog.setModifier(bonusLog.getCreator());
		        		bonusLog.setModifierName(bonusLog.getCreator());
		        		bonusLog.setSerialNum(getBcBonusSerialNumDao().getSerialNum());
		        		Date now = new Date();
		        		bonusLog.setModifyTime(now);
		        		bonusLog.setCreateTime(now);
		        		session.save(bonusLog);
		        		
		        		//修改MM_MEMBERS_BONUS資料
		        		Map<String, Integer> map = BonusUtility.CalculateBonus(bonusLog.getBonusAdd(), bonusLog.getBonusMins(), mmMembersBonus.getThisYearTot(), 
		        				mmMembersBonus.getLastYearTot());
		        		mmMembersBonus.setBonusTotalYday(mmMembersBonus.getBonusTotal());
		        		mmMembersBonus.setThisYearTotYday(mmMembersBonus.getThisYearTot());
		        		mmMembersBonus.setLastYearTotYday(mmMembersBonus.getLastYearTot());
		        		mmMembersBonus.setThisYearTot(map.get("thisYearTot"));
		        		mmMembersBonus.setLastYearTot(map.get("lastYearTot"));
		        		mmMembersBonus.setBonusTotal(membersTotal);
		        		mmMembersBonus.setModifyTime(new Date());
		        		session.saveOrUpdate(mmMembersBonus);
		        		
		        		if(bs_type==8||bs_type==9||bs_type==10){
		        			
		        			//更新BC_BONUS_TEMPORAL_SUM資料
		        			getBcBonusTemporalSumDao().updateSumBonusTotal(
		        					session, 
		        					new Long(bcBonusTemporalSumTotal), 
		        					bonusLog.getMemberId(), 
		        					member.getPersonId()
		        			);
			        		
		        			//新增BC_BONUS_TEMPORAL_LOG資料
			        		BcBonusTemporalLog log = new BcBonusTemporalLog(bonusLog);
			        		log.setPersonId(member.getPersonId());
			        		log.setModifiedTime(now);
			        		session.save(log);
		        		}
		        		
		        		tx.commit();
	        		} catch (Exception e) {
	        			log.error("transBcBonusTemporal error", e);
	        			tx.rollback();
	        			BaseWebService.throwError("PERSON_ID:" + member.getPersonId() + "addBonuslog失敗\n"+e.getMessage());
	        		} finally {
	        			if(session != null) {
	        				session.close();
	        			}
	        		}
	        		
	        		return membersTotal;
	        	}		        	
	        }
		);
	}
	
	public void findBonustype(Integer bsType,BcBonusLog log){
		String type="";
		switch (bsType) {
		case 0:
			type = log.getBonusAdd()!=0?"1":"18";
			break;
		case 1:
			type = log.getBonusAdd()!=0?"62":"6";
			break;
		case 2:
			type = log.getBonusAdd()!=0?"1":"18";
			break;
		case 3:
			type = log.getBonusAdd()!=0?"1":"18";
			break;
		case 4:
			type = log.getBonusAdd()!=0?"1":"18";
			break;
		case 5:
			type = log.getBonusAdd()!=0?"1":"18";
			break;
		case 6:
			type = log.getBonusAdd()!=0?"1":"18";
			break;
		case 96:
			type = log.getBonusAdd()!=0?"1":"18";
			break;
		case 97:
			type = log.getBonusAdd()!=0?"1":"19";
			break;
		case 98:
			type = log.getBonusAdd()!=0?"1243":"1244";
			break;
		case 99:
			type = log.getBonusAdd()!=0?"103":"1032";
			break;
		case 8:
			type = log.getBonusAdd()!=0?"62":"6";
			break;
		case 9:
			type = log.getBonusAdd()!=0?"1107":"1107";
			break;
		case 10:
			type = log.getBonusAdd()!=0?"72":"7";
			break;
		default:
			type ="0";
			break;
		}
		log.setBonusType(Integer.parseInt(type));
	}
	
	/**
	 * 即時扣點查詢
	 * @param personId 
	 */
	public long getRealTimeBonusMinsTotal(String personId){
		return getBcBonusTemporalLogDao().getRealTimeBonusMinsTotal(personId);
	}
	
}
