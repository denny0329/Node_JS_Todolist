package com.gccs.bonus.condition;

import java.io.Serializable;
import java.util.Date;

public class LogCondition implements Serializable {
	private static final long serialVersionUID = -4476662039442184076L;

	private Date transDate;
	private String storeId;
	private Integer bonusType;
	private String marketId;
	private String creator;
	private Date createTime;
	private String guiNo;
	private String posNos;
	private String serNos;
	public Date getTransDate() {
		return transDate;
	}
	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}
	public Integer getBonusType() {
		return bonusType;
	}
	public void setBonusType(Integer bonusType) {
		this.bonusType = bonusType;
	}
	public String getMarketId() {
		return marketId;
	}
	public void setMarketId(String marketId) {
		this.marketId = marketId;
	}
	public String getStoreId() {
		return storeId;
	}
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getGuiNo() {
		return guiNo;
	}
	public void setGuiNo(String guiNo) {
		this.guiNo = guiNo;
	}
	public String getPosNos() {
		return posNos;
	}
	public void setPosNos(String posNos) {
		this.posNos = posNos;
	}
	public String getSerNos() {
		return serNos;
	}
	public void setSerNos(String serNos) {
		this.serNos = serNos;
	}
	
}
