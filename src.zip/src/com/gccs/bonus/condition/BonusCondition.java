package com.gccs.bonus.condition;

import java.io.Serializable;
import java.util.Date;

public class BonusCondition implements Serializable {
	private static final long serialVersionUID = 699387329175585135L;

	private String storeNo;
	private Date transDate;
	private String posNos;
	private String serNos;
	private String saleType;
	private String saleSta;
	private Date cancelDate;
	private String guiNos;
	private String channelId;
	private Boolean isJDBC;
	private int executeType;
	private String promotId;
	private String bstype;

	public int getExecuteType() {
		return executeType;
	}

	public void setExecuteType(int executeType) {
		this.executeType = executeType;
	}

	public Date getTransDate() {
		return transDate;
	}

	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}

	public String getSaleType() {
		return saleType;
	}

	public void setSaleType(String saleType) {
		this.saleType = saleType;
	}

	public String getSaleSta() {
		return saleSta;
	}

	public void setSaleSta(String saleSta) {
		this.saleSta = saleSta;
	}

	public String getStoreNo() {
		return storeNo;
	}

	public void setStoreNo(String storeNo) {
		this.storeNo = storeNo;
	}

	public String getPosNos() {
		return posNos;
	}

	public void setPosNos(String posNos) {
		this.posNos = posNos;
	}

	public String getSerNos() {
		return serNos;
	}

	public void setSerNos(String serNos) {
		this.serNos = serNos;
	}

	public Date getCancelDate() {
		return cancelDate;
	}

	public void setCancelDate(Date cancelDate) {
		this.cancelDate = cancelDate;
	}

	public String getGuiNos() {
		return guiNos;
	}

	public void setGuiNos(String guiNos) {
		this.guiNos = guiNos;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public Boolean getIsJDBC() {
		return isJDBC;
	}

	public void setIsJDBC(Boolean isJDBC) {
		this.isJDBC = isJDBC;
	}

	public String getPromotId() {
		return promotId;
	}

	public void setPromotId(String promotId) {
		this.promotId = promotId;
	}

	public String getBstype() {
		return bstype;
	}

	public void setBstype(String bstype) {
		this.bstype = bstype;
	}
	
}
