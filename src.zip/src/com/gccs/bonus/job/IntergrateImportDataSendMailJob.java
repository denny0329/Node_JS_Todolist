package com.gccs.bonus.job;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gccs.marketing.IIntegrateImpoirtDataService;

public class IntergrateImportDataSendMailJob {
	private static final Logger log = LogManager.getLogger("IntergrateImportDataSendMailJob");
	private IIntegrateImpoirtDataService integrateImpoirtDataService;

	public IIntegrateImpoirtDataService getIntegrateImpoirtDataService() {
		return integrateImpoirtDataService;
	}

	public void setIntegrateImpoirtDataService(IIntegrateImpoirtDataService integrateImpoirtDataService) {
		this.integrateImpoirtDataService = integrateImpoirtDataService;
	}

	public void execute() {
		try {
			long l0 = System.currentTimeMillis();
			log.info("[IntergrateImportDataSendMailJob] launched.");
			
			// 發送email
			this.getIntegrateImpoirtDataService().sendEmail();
			
			long l1 = System.currentTimeMillis();
			log.info("[IntergrateImportDataSendMailJob] task finish. time cost : " + ((l1 - l0) / 1000));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
	}

}
