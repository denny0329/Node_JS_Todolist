package com.gccs.bonus.job;

import java.util.Date;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.DateTimeUtils;
import com.gccs.bonus.service.IBcBonusTemporalService;
import com.gccs.bonus.service.process.BonusSettlementProcess;
import com.gccs.util.quartz.IQuartzLogService;
import com.gccs.util.quartz.util.QuartzLogGlossary;

/**
 * <b></b>
 * 
 * @author kaychen
 * @Project Name: RFEP
 */
public class LastYearBonusCleanJob {
	private static final Logger log = LogManager.getLogger("batchJob");
	private String batch_id = QuartzLogGlossary._id_LastYearBonusClean;
	private IQuartzLogService logService;
	private BonusSettlementProcess bonusSettlementProcess;
	private IBcBonusTemporalService bcBonusTemporalService;
	
	public IBcBonusTemporalService getBcBonusTemporalService() {
		return bcBonusTemporalService;
	}

	public void setBcBonusTemporalService(
			IBcBonusTemporalService bcBonusTemporalService) {
		this.bcBonusTemporalService = bcBonusTemporalService;
	}

	public IQuartzLogService getLogService() {
		return logService;
	}

	public void setLogService(IQuartzLogService logService) {
		this.logService = logService;
	}
	
	public BonusSettlementProcess getBonusSettlementProcess() {
		return bonusSettlementProcess;
	}

	public void setBonusSettlementProcess(
			BonusSettlementProcess bonusSettlementProcess) {
		this.bonusSettlementProcess = bonusSettlementProcess;
	}

	private void checkBatchProcess() throws Exception {
		while (!this.getLogService().checkPrecedingOperationCompleted(batch_id)) {
			log.info("[LastYearBonusCleanJob execute] wait preceding batch.");
			Thread.sleep(300 * 1000);
		}
	}
	
	/**
	 * 進行年度紅利點數清算
	 */
	public void execute() {
		try {
			long l1 = System.currentTimeMillis();
			log.info("[LastYearBonusCleanJob execute] launched.");
			
			// 檢核前置作業
			checkBatchProcess();
			
			// 更新Batch Log
			Date beginDate = DateTimeUtils.getSysDate();
			this.getLogService().batchProcessBegin(batch_id, beginDate);

			this.getBonusSettlementProcess().lastYearBonusCleanProcess(false);
			
			// 更新Batch Log
			Date endDate = DateTimeUtils.getSysDate();
			this.getLogService().batchProcessEnd(batch_id, beginDate, endDate);
			
			long start = System.currentTimeMillis();		
			log.info("batchUpdateBcBonusTemporalSum start.");
			getBcBonusTemporalService().batchUpdateBcBonusTemporalSum();
			long end = System.currentTimeMillis();
			log.info("batchUpdateBcBonusTemporalSum end. time=" + ((end - start)/1000) + "sec.");
			
			long l2 = System.currentTimeMillis();
			log.info("[LastYearBonusCleanJob execute] task finish. time cost : " + ((l2 - l1) / 1000));
		} catch (Exception e) {
			log.error("[LastYearBonusCleanJob execute] fail : " + e.getMessage(), e);
		}
	}
}
