package com.gccs.bonus.job;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gccs.marketing.IIntegrateImpoirtDataService;
import com.rfep.nm.service.INmSmmImportService;

public class CleanExpiredImportDataJob {
	private static final Logger log = LogManager.getLogger("CleanExpiredImportDataJob");
	private IIntegrateImpoirtDataService integrateImpoirtDataService;
	private INmSmmImportService nmSmmImportService;

	public IIntegrateImpoirtDataService getIntegrateImpoirtDataService() {
		return integrateImpoirtDataService;
	}

	public void setIntegrateImpoirtDataService(IIntegrateImpoirtDataService integrateImpoirtDataService) {
		this.integrateImpoirtDataService = integrateImpoirtDataService;
	}

	public INmSmmImportService getNmSmmImportService() {
		return nmSmmImportService;
	}

	public void setNmSmmImportService(INmSmmImportService nmSmmImportService) {
		this.nmSmmImportService = nmSmmImportService;
	}

	public void execute() {
		try {
			long l1 = System.currentTimeMillis();
			log.info("[CleanExpiredImportDataJob] launched.");
			
			// 每月15號清理上個月的檔案
			this.getIntegrateImpoirtDataService().cleanImportData();
			// del nmSmm data
			this.getNmSmmImportService().cleanSmmData(); //nn_smm
			
			long l2 = System.currentTimeMillis();
			log.info("[CleanExpiredImportDataJob] task finish. time cost : " + ((l2 - l1) / 1000));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
	}

}
