package com.gccs.bonus.job;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gccs.marketing.IIntegrateImpoirtDataService;

public class IntergrateImportDataJob {
	private static final Logger log = LogManager.getLogger("IntergrateImportDataJob");
	private IIntegrateImpoirtDataService integrateImpoirtDataService;

	public IIntegrateImpoirtDataService getIntegrateImpoirtDataService() {
		return integrateImpoirtDataService;
	}

	public void setIntegrateImpoirtDataService(IIntegrateImpoirtDataService integrateImpoirtDataService) {
		this.integrateImpoirtDataService = integrateImpoirtDataService;
	}

	public void execute() {
		try {
			long l0 = System.currentTimeMillis();
			log.info("[IntergrateImportDataJob] launched.");
			
			// 初始化
			String seqNo = this.getIntegrateImpoirtDataService().initBatch();
			long l1 = System.currentTimeMillis();
			log.info("[IntergrateImportDataJob init] task finish. time cost : " + ((l1 - l0) / 1000));

			// 執行3041批次匯入
			this.getIntegrateImpoirtDataService().executeBatch("3041",seqNo);
			long l2 = System.currentTimeMillis();
			log.info("[IntergrateImportDataJob 3041] task finish. time cost : " + ((l2 - l1) / 1000));

			// 執行3042批次匯入
			this.getIntegrateImpoirtDataService().executeBatch("3042",seqNo);
			long l3 = System.currentTimeMillis();
			log.info("[IntergrateImportDataJob 3042] task finish. time cost : " + ((l3 - l2) / 1000));

			// 執行3023批次匯入
			this.getIntegrateImpoirtDataService().executeBatch("3023",seqNo);
			long l4 = System.currentTimeMillis();
			log.info("[IntergrateImportDataJob 3023] task finish. time cost : " + ((l4 - l3) / 1000));

			// 執行6603批次匯入
			this.getIntegrateImpoirtDataService().executeBatch("6603",seqNo);
			long l5 = System.currentTimeMillis();
			log.info("[IntergrateImportDataJob 6603] task finish. time cost : " + ((l5 - l4) / 1000));
			
			// 寄送email
			this.getIntegrateImpoirtDataService().sendMail(seqNo);
			long l6 = System.currentTimeMillis();
			log.info("[IntergrateImportDataJob Send mail] task finish. time cost : " + ((l6 - l5) / 1000));
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
	}

}
