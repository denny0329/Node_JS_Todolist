package com.gccs.bonus.job;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.DateTimeUtils;
import com.gccs.member.service.MemberService;
import com.gccs.mmbonus.model.MmMembersBonus;

public class CleanBonusDailyJob {
	private static final Logger log = LogManager.getLogger("batchJob");
	
	public void execute(MemberService memberService) {
		try {
			long start = System.currentTimeMillis();
			log.info("[CleanBonusDailyJob execute] launched.");
			Date date = DateTimeUtils.getYearMonth(DateTimeUtils.addMonth(new Date(), -1));
			SimpleDateFormat sdf = new SimpleDateFormat(DateTimeUtils.YYYYMM);
			String yearMonth = sdf.format(date);
			List<MmMembersBonus> mmBonusList = memberService.selectMmBonusForCleanJob(yearMonth);
			for (MmMembersBonus mmMembersBonus : mmBonusList) {
				memberService.updateBonusForClean(mmMembersBonus);
			}
			
			memberService.clearBonusLog(mmBonusList);
			
			long end = System.currentTimeMillis();
			log.info("[CleanBonusDailyJob execute] task finish. time cost : " + ((end - start) / 1000));
		} catch (Exception e) {
			log.error("[CleanBonusDailyJob execute] fail : " + e.getMessage(), e);
		}
	}


}
