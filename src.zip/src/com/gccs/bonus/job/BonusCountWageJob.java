package com.gccs.bonus.job;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gccs.bonus.service.BonusCountWageService;
import com.gccs.util.quartz.IQuartzLogService;
import com.gccs.util.quartz.util.QuartzLogGlossary;

/**
 * 會員紅利點數計算-HISU交易計算
 */
public class BonusCountWageJob {
	private final Logger log = LogManager.getLogger(BonusCountWageJob.class);
	private BonusCountWageService service;
	private IQuartzLogService logService;
	private static final String batch_id = QuartzLogGlossary._id_bonus_wage_calculate;
	
	public IQuartzLogService getLogService() {
		return logService;
	}

	public void setLogService(IQuartzLogService logService) {
		this.logService = logService;
	}
	
	public BonusCountWageService getService() {
		return service;
	}

	public void setService(BonusCountWageService service) {
		this.service = service;
	}

	public void checkBatchBonusCountWageProcess() throws Exception {
		while (!this.getLogService().checkPrecedingOperationCompleted(batch_id)) {
			log.info("[bonusCountWageProcess] wait preceding batch.");
			Thread.sleep(60 * 1000);
		}
	}
	
	public void bonusCountWageProcess() {
		try {
			//檢核前置作業
			checkBatchBonusCountWageProcess();
			this.getService().executeBatch(null);
		} catch (Exception e) {
			log.error("[bonusCountWageProcess] fail : " + e.getMessage(), e);
		}
	}
}
