package com.gccs.bonus.job;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gccs.bs.service.BsManagerService;
import com.gccs.member.service.IDecorSyncService;
import com.gccs.ws.service.IBcBonusSerialNumService;

/**
 * 紅點點數排序流水號歸零服務
 */
public class BcBonusSeqZeroJob {

	private static final Logger log = LogManager.getLogger(BcBonusSeqZeroJob.class);

	private IBcBonusSerialNumService service;
	private IDecorSyncService decorSyncService;
	private BsManagerService bsManagerService;

	public IBcBonusSerialNumService getService() {
		return service;
	}

	public void setService(IBcBonusSerialNumService service) {
		this.service = service;
	}

	public IDecorSyncService getDecorSyncService() {
		return decorSyncService;
	}

	public void setDecorSyncService(IDecorSyncService decorSyncService) {
		this.decorSyncService = decorSyncService;
	}

	public BsManagerService getBsManagerService() {
		return bsManagerService;
	}

	public void setBsManagerService(BsManagerService bsManagerService) {
		this.bsManagerService = bsManagerService;
	}

	/**
	 * 執行批次
	 */
	public void executeBatch() {
		try {
			long start = System.currentTimeMillis();
			log.info("BcBonusSeqZeroJob start.");
			getService().processSerialNumZero();
			long end = System.currentTimeMillis();
			log.info("BcBonusSeqZeroJob end. time=" + ((end - start) / 1000) + "sec.");

			log.info("delete DecorSync data start...");
			getDecorSyncService().deleteDecorSync();
			log.info("delete DecorSync data end...");

			log.info("delete mm_account_disc_log data start...");
			getDecorSyncService().deleteAccountDiscLog();
			log.info("delete mm_account_disc_log data end...");
			
		} catch (Exception e) {
			e.printStackTrace();
			log.error("UpdateDecorSyncJob : " + e.getMessage(), e);
		}
	}
}
