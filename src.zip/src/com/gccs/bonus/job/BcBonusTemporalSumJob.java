package com.gccs.bonus.job;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import com.gccs.bonus.service.IBcBonusTemporalService;

/**
 * 批次產生紅利點數總表 
 */
public class BcBonusTemporalSumJob {

	private static final Logger log = LogManager.getLogger(BcBonusTemporalSumJob.class) ;
	
	private IBcBonusTemporalService bcBonusTemporalService;
	
	public IBcBonusTemporalService getBcBonusTemporalService() {
		return bcBonusTemporalService;
	}

	public void setBcBonusTemporalService(
			IBcBonusTemporalService bcBonusTemporalService) {
		this.bcBonusTemporalService = bcBonusTemporalService;
	}

	/**
	 * 執行
	 */
	public void executeBatch() {
		
		long start = System.currentTimeMillis();		
		log.info("BcBonusMonthSummaryJob start.");
		
		getBcBonusTemporalService().batchUpdateBcBonusTemporalSum();
		
		long end = System.currentTimeMillis();
		log.info("BcBonusMonthSummaryJob end. time=" + ((end - start)/1000) + "sec.");
	}
}
