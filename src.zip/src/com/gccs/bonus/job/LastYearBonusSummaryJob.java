package com.gccs.bonus.job;

import java.util.Date;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.DateTimeUtils;
import com.gccs.bonus.service.process.BonusSettlementProcess;
import com.gccs.util.quartz.IQuartzLogService;
import com.gccs.util.quartz.util.QuartzLogGlossary;

/**
 * <b></b>
 * 
 * @author kaychen
 * @Project Name: RFEP
 */
public class LastYearBonusSummaryJob {
	private static final Logger log = LogManager.getLogger("batchJob");
	private String batch_id = QuartzLogGlossary._id_LastYearBonusSummary;
	private IQuartzLogService logService;
	private BonusSettlementProcess bonusSettlementProcess;
	
	public IQuartzLogService getLogService() {
		return logService;
	}

	public void setLogService(IQuartzLogService logService) {
		this.logService = logService;
	}
	
	public BonusSettlementProcess getBonusSettlementProcess() {
		return bonusSettlementProcess;
	}

	public void setBonusSettlementProcess(
			BonusSettlementProcess bonusSettlementProcess) {
		this.bonusSettlementProcess = bonusSettlementProcess;
	}

	private void checkBatchProcess() throws Exception {
		while (!this.getLogService().checkPrecedingOperationCompleted(batch_id)) {
			log.info("[LastYearBonusSummaryJob execute] wait preceding batch.");
			Thread.sleep(300 * 1000);
		}
	}
	
	/**
	 * 進行年度紅利點數結算
	 */
	public void execute() {
		try {
			long l1 = System.currentTimeMillis();
			log.info("[LastYearBonusSummaryJob execute] launched.");
			
			// 檢核前置作業
			checkBatchProcess();
			
			// 更新Batch Log
			Date beginDate = DateTimeUtils.getSysDate();
			this.getLogService().batchProcessBegin(batch_id, beginDate);

			this.getBonusSettlementProcess().lastYearBonusSummaryProcess(false);
			
			// 更新Batch Log
			Date endDate = DateTimeUtils.getSysDate();
			this.getLogService().batchProcessEnd(batch_id, beginDate, endDate);

			long l2 = System.currentTimeMillis();
			log.info("[LastYearBonusSummaryJob execute] task finish. time cost : " + ((l2 - l1) / 1000));
		} catch (Exception e) {
			log.error("[LastYearBonusSummaryJob execute] fail : " + e.getMessage(), e);
		}
	}
}
