package com.gccs.bonus.job;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.DateTimeUtils;
import com.gccs.member.service.MemberService;
import com.rfep.trans.dao.NrTransTMstDaoI;

public class UpdateBonusExpireDailyJob {
	private static final Logger log = LogManager.getLogger("batchJob");
	
	public void execute(NrTransTMstDaoI nrTransTMstDaoI, MemberService memberService) {
		boolean doNExtJob = true;
		try {
			long start = System.currentTimeMillis();
			log.info("[UpdateBonusExpireDailyJob execute] launched.");
			
			List<Object[]> list = nrTransTMstDaoI.selectMemberHasTransaction();
			for (Object[] object : list) {
				BigDecimal memberId = (BigDecimal) object[0];
				Date transDate = (Date) object[1];
				memberService.updateBonusForHasTransaction(transDate, memberId.toString());
			}
			
			long end = System.currentTimeMillis();
			log.info("[UpdateBonusExpireDailyJob execute] task finish. time cost : " + ((end - start) / 1000));
		} catch (Exception e) {
			log.error("[UpdateBonusExpireDailyJob execute] fail : " + e.getMessage(), e);
			doNExtJob = false;
		}
		if (doNExtJob) {
			if (isFirstDatOfMonth()) {
				CleanBonusDailyJob cleanBonusJob = new CleanBonusDailyJob();
				cleanBonusJob.execute(memberService);
			}
		}
	}

	private boolean isFirstDatOfMonth() {
		Calendar now = Calendar.getInstance();
		Calendar now2 = Calendar.getInstance();
		Calendar firstDayofMonth = DateTimeUtils.getFirstDayofMonth(now2);
		return DateTimeUtils.isSameDate(now.getTime(), firstDayofMonth.getTime());
	}
}