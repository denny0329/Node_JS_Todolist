package com.gccs.bonus.job;

import java.util.Date;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.DateTimeUtils;
import com.bnq.util.DateUtils;
import com.gccs.bonus.service.InactiveBonusService;
import com.gccs.util.quartz.IQuartzLogService;
import com.gccs.util.quartz.util.QuartzLogGlossary;

public class InactiveBonusJob {
	private static final Logger log = LogManager.getLogger("batchJob");
	private InactiveBonusService service;
	private IQuartzLogService logService;
	private String batch_id = QuartzLogGlossary._id_disbonus;
	
	public InactiveBonusService getService() {
		return service;
	}
	
	public void setService(InactiveBonusService service) {
		this.service = service;
	}
	
	public IQuartzLogService getLogService() {
		return logService;
	}

	public void setLogService(IQuartzLogService logService) {
		this.logService = logService;
	}

	public void inactiveBonusProcess() {
		try {//2013/01/01後不跑舊的清算
			if (DateUtils.after(DateUtils.getDate("2013/01/01"), DateUtils.getToday())){
				//檢核前置作業
				checkBatchProcess();
				Date beginDate = DateTimeUtils.getSysDate();
				//更新Batch Log
				this.getLogService().batchProcessBegin(batch_id, beginDate);
				
				log.info("[inactiveBonusProcess] start. ") ;
				long l1 = System.currentTimeMillis();
				//紅利失效
				this.getService().inactiveBonusProcess();
				long l2 = System.currentTimeMillis();
				
				Date endDate = DateTimeUtils.getSysDate();
				//更新Batch Log
				this.getLogService().batchProcessEnd(batch_id, beginDate, endDate);
				
				log.info("[inactiveBonusProcess] end. total time : "+(l2-l1)/1000) ;
			}			
		} catch (Exception e) {
			log.error("[inactiveBonusProcess] fail : "+e.getMessage(),e) ;
		}
	}
	
	private void checkBatchProcess() throws Exception {
		while(!this.getLogService().checkPrecedingOperationCompleted(batch_id)) {
			log.info("[inactiveBonusProcess] wait preceding batch.") ;
			Thread.sleep(120*1000);
		}
	}
	
}
