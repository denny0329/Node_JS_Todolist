package com.gccs.bonus.job;

import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.DateUtils;
import com.gccs.bc.setting.service.BcBonusSettingService;

public class MtSkuDiscountExcludeCbJob {
	private static final Logger log = LogManager.getLogger("bonusBatch");
	private BcBonusSettingService bcBonusSettingService;

	public BcBonusSettingService getBcBonusSettingService() {
		return bcBonusSettingService;
	}
	public void setBcBonusSettingService(BcBonusSettingService bcBonusSettingService) {
		this.bcBonusSettingService = bcBonusSettingService;
	}
	public void execute() {
		try {
			/**
			 * 排除合營專櫃商品
			 * 1.delete mt_sku_discount ref_oid
			 * 2.insert into mt_sku_discount
			 */
			Date dt = DateUtils.getDateTime("2016/04/01 23:59:59");
			Calendar cal = Calendar.getInstance();
			if(cal.getTime().compareTo(dt)>0){
				bcBonusSettingService.deleteMtSkuDiscountByZHNT();
				bcBonusSettingService.addMtSkuDiscountByZHNT();
			}
			log.error("[MtSkuDiscountExcludeCbJob] success");
		} catch (Exception e) {
			log.error("[MtSkuDiscountExcludeCbJob] fail : " + e.getMessage(), e);
		}
	}
}
