package com.gccs.bonus.job;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gccs.bonus.service.IBcBonusSummarySerivce;

/**
 * 會員月紅利現金積點批次計算
 * 
 * 1. 由BC_BONUS_LOG取出資料，經過計算後存入BC_MONTH_BONUS_SUMMARY
 * 2. 只考慮現金折抵部份
 * 3. 有效資料由201003開始
 * 4. 每個月2日AM06:00執行
 */
public class BcBonusSummaryJob {

	private static final Logger log = LogManager.getLogger(BcBonusSummaryJob.class) ;
	
	private IBcBonusSummarySerivce monthSummaryService;
	private IBcBonusSummarySerivce yearSummaryService;
	
	public IBcBonusSummarySerivce getMonthSummaryService() {
		return monthSummaryService;
	}

	public void setMonthSummaryService(IBcBonusSummarySerivce monthSummaryService) {
		this.monthSummaryService = monthSummaryService;
	}

	public IBcBonusSummarySerivce getYearSummaryService() {
		return yearSummaryService;
	}

	public void setYearSummaryService(IBcBonusSummarySerivce yearSummaryService) {
		this.yearSummaryService = yearSummaryService;
	}

	/**
	 * 執行
	 */
	public void executeBatch() {
		this.executeMonthBatch();
		this.executeYearBatch();
		this.executeMonthBatchForM0();
	}
	
	/**
	 * 執行
	 */
	public void executeMonthBatch() {
		long start = System.currentTimeMillis();		
		log.info("BcBonusMonthSummaryJob start.");
		
		getMonthSummaryService().executeBatch();
		
		long end = System.currentTimeMillis();
		log.info("BcBonusMonthSummaryJob end. time=" + ((end - start)/1000) + "sec.");
	}
	
	/**
	 * 執行
	 */
	public void executeYearBatch() {
		long start = System.currentTimeMillis();		
		log.info("BcBonusYearSummaryJob start.");
		
		getYearSummaryService().executeBatch();
		
		long end = System.currentTimeMillis();
		log.info("BcBonusYearSummaryJob end. time=" + ((end - start)/1000) + "sec.");
	}
	
	/**
	 * 執行鮮綠市集(CHANNEL_ID = 'M0')的計算
	 */
	public void executeMonthBatchForM0() {
		long start = System.currentTimeMillis();		
		log.info("BcBonusMonthSummaryJob start.");
		
		getMonthSummaryService().executeM0Batch();
		
		long end = System.currentTimeMillis();
		log.info("BcBonusMonthSummaryJob end. time=" + ((end - start)/1000) + "sec.");
	}
}
