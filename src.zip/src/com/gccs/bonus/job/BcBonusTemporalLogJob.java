package com.gccs.bonus.job;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import com.gccs.bonus.service.IBcBonusTemporalService;

/**
 * 批次刪除紅利點數明細資料
 */
public class BcBonusTemporalLogJob {

	private static final Logger log = LogManager.getLogger(BcBonusTemporalSumJob.class) ;
	
	private IBcBonusTemporalService bcBonusTemporalService;
	
	public IBcBonusTemporalService getBcBonusTemporalService() {
		return bcBonusTemporalService;
	}

	public void setBcBonusTemporalService(
			IBcBonusTemporalService bcBonusTemporalService) {
		this.bcBonusTemporalService = bcBonusTemporalService;
	}

	/**
	 * 執行
	 */
	public void executeBatch() {
		
		long start = System.currentTimeMillis();		
		log.info("BcBonusMonthSummaryJob start.");
		
		getBcBonusTemporalService().batchDeleteBcBonusTemporalLog();
		
		long end = System.currentTimeMillis();
		log.info("BcBonusMonthSummaryJob end. time=" + ((end - start)/1000) + "sec.");
	}
}
