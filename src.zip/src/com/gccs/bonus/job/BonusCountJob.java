package com.gccs.bonus.job;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.apeo.sender.exception.MessageSenderException;
import com.bnq.util.DateTimeUtils;
import com.bnq.util.mail.MailService;
import com.gccs.bc.setting.service.BcBonusSettingService;
import com.gccs.bonus.service.BonusCountService;
import com.gccs.bonus.service.BonusCountSomService;
import com.gccs.bonus.service.IBcBonusTemporalService;
import com.gccs.member.service.MemberService;
import com.gccs.pos.PosTextService;
import com.gccs.util.quartz.IQuartzLogService;
import com.gccs.util.quartz.util.QuartzLogGlossary;
import com.gccs.util.web.SelectItem;
import com.rfep.trans.dao.NrTransTMstDaoI;
import com.rfep.util.sys.vo.EmailNotifyVo;

/**
 * <b></b>
 * 
 * @author kaychen
 * @Date: 2010/2/23 上午 10:01:08
 * @Project Name: RFEP
 */
public class BonusCountJob {
	private static final Logger log = LogManager.getLogger("bonusBatch");
	private PosTextService pService = new PosTextService();
	private static final String[] jobId = { "CBONUS", "HBONUS" };
	private BonusCountService service;
	private IQuartzLogService logService;
	private String batch_id = QuartzLogGlossary._id_bonus_calculate;
	private IBcBonusTemporalService bcBonusTemporalService;
	private BonusCountSomService somService;
	private BcBonusSettingService bcBonusSettingService;
	private NrTransTMstDaoI nrTransTMstDaoI;
	private MemberService memberService;

	public BcBonusSettingService getBcBonusSettingService() {
		return bcBonusSettingService;
	}

	public void setBcBonusSettingService(BcBonusSettingService bcBonusSettingService) {
		this.bcBonusSettingService = bcBonusSettingService;
	}

	public IBcBonusTemporalService getBcBonusTemporalService() {
		return bcBonusTemporalService;
	}

	public void setBcBonusTemporalService(
			IBcBonusTemporalService bcBonusTemporalService) {
		this.bcBonusTemporalService = bcBonusTemporalService;
	}

	public BonusCountService getService() {
		return service;
	}

	public void setService(BonusCountService service) {
		this.service = service;
	}

	public IQuartzLogService getLogService() {
		return logService;
	}

	public void setLogService(IQuartzLogService logService) {
		this.logService = logService;
	}

	private void checkBatchProcess() throws Exception {
		while (!this.getLogService().checkPrecedingOperationCompleted(batch_id)) {
			log.info("[bonusCountProcess] wait preceding batch.");
			Thread.sleep(60 * 1000);
		}
	}

	public void bonusCountProcess() {
		boolean doNExtJob = true;
		try {
			// 檢核前置作業
			checkBatchProcess();
			Date beginDate = DateTimeUtils.getSysDate();
			// 更新Batch Log
			this.getLogService().batchProcessBegin(batch_id, beginDate);

			long l1 = System.currentTimeMillis();
			log.info("[bonusCountProcess] launched.");
			//適用商品暫存檔
			this.bcBonusSettingService.initBonusCalSku(null);
			// 紅利計算
			this.getService().bonusCountProcess(null, null, SelectItem.allProcess);
			// 員工卡給點
			this.getService().bonusCountProcessForEmployee(null, null, SelectItem.allProcess);
			// SOM紅利計算
//			this.getSomService().bonusCountProcess(null, null, SelectItem.allProcess);
			Date endDate = DateTimeUtils.getSysDate();
			// 更新Batch Log
			this.getLogService().batchProcessEnd(batch_id, beginDate, endDate);

			long l2 = System.currentTimeMillis();
			log.info("[bonusCountProcess] task finish. time cost : " + ((l2 - l1) / 1000));
			
			// 即時折抵table資料產生需在紅利點數計算完再產生
			long start = System.currentTimeMillis();		
			log.info("batchUpdateBcBonusTemporalSum start.");
			getBcBonusTemporalService().batchUpdateBcBonusTemporalSum();
			long end = System.currentTimeMillis();
			log.info("batchUpdateBcBonusTemporalSum end. time=" + ((end - start)/1000) + "sec.");
		} catch (Exception e) {
			log.error("[bonusCountProcess] fail : " + e.getMessage(), e);
			mailNotify("紅利點數計算異常", e.getMessage());
			doNExtJob = false;
		}
		if (doNExtJob) {
			UpdateBonusExpireDailyJob bonusExpireDailyJob = new UpdateBonusExpireDailyJob();
			bonusExpireDailyJob.execute(nrTransTMstDaoI, memberService);
		}
		
		mailNotify("紅利點數計算結束", "");
	}
	
	private void mailNotify(String subject, String msg) {

		String userMailString2 = "Ken-DF.Chang@testritegroup.com";
		String userMailString3 = "Beatrice.Chen@testritegroup.com";
		String userMailString4 = "danise.wei@testritegroup.com";
		
		EmailNotifyVo emailNotifyVo = new EmailNotifyVo();
		emailNotifyVo.setEmailContent(subject);
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		String now = sdf.format(new Date());
		
		String content = subject + "<p>時間: " + now;
		if (StringUtils.isNotBlank(msg)) {
			content += "<p>錯誤訊息: " + msg;
		}
		
		try {
			MailService.sendMessage(content, subject, userMailString2, "", null);
			MailService.sendMessage(content, subject, userMailString3, "", null);
			MailService.sendMessage(content, subject, userMailString4, "", null);
			
		} catch (MessageSenderException e) {
			log.error("寄件失敗:[" + subject + "]" + e.getMessage(), e);
		}
	}

	public void bonusLogRestore(String date, String storeNo) {
		try {
			int[] bonusTypeCollections = new int[] { 7, 72 };
			for (int i = 0; i < bonusTypeCollections.length; i++) {
				// this.getService().restoreBonus(DateTimeUtils.getDate(date),
				// storeNo, null, bonusTypeCollections[i]);
			}
		} catch (Exception e) {
			log.error("[bonusLogRestore] fail : " + e.getMessage(), e);
		}
	}

	public void bonusReCount(String date, String storeNo) {
		try {
			// this.getService().bonusCountProcess(DateTimeUtils.getDate(date),
			// storeNo) ;
			// this.getService().reCountCashExchange(DateTimeUtils.getDate(date),
			// storeNo) ;
		} catch (Exception e) {
			log.error("[bonusReCount] fail : " + e.getMessage(), e);
		}
	}

	public void setSomService(BonusCountSomService somService) {
		this.somService = somService;
	}

	public BonusCountSomService getSomService() {
		return somService;
	}

	public NrTransTMstDaoI getNrTransTMstDaoI() {
		return nrTransTMstDaoI;
	}

	public void setNrTransTMstDaoI(NrTransTMstDaoI nrTransTMstDaoI) {
		this.nrTransTMstDaoI = nrTransTMstDaoI;
	}

	public MemberService getMemberService() {
		return memberService;
	}

	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}
}
