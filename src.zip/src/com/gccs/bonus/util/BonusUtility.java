package com.gccs.bonus.util;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.AppContext;
import com.bnq.util.DateTimeUtils;
import com.bnq.util.sale.model.SaleDetail;
import com.bnq.util.sale.model.SaleDisc;
import com.bnq.util.sale.model.SaleMaster;
import com.gccs.bc.model.BcBonusLog;
import com.gccs.bc.model.BcBonusSettingDtl;
import com.gccs.bc.model.BcBonusSku;
import com.gccs.bc.model.BcExchangeStore;
import com.gccs.bc.service.BcBonusService;
import com.gccs.bonus.model.BonusExceptionLog;
import com.gccs.bonus.model.vo.AccountVO;
import com.gccs.bonus.model.vo.BonusVO;
import com.gccs.marketing.IMarketingService;
import com.gccs.marketing.model.vo.DiscountChannelVo;
import com.gccs.marketing.model.vo.DiscountVo;
import com.gccs.marketing.model.vo.PromotionGroupVo;
import com.gccs.marketing.service.MarketingService;
import com.gccs.member.card.model.MmCard;
import com.gccs.member.model.Account;
import com.gccs.member.model.MembersBO2;
import com.gccs.member.util.MemberGlossary;
import com.gccs.util.cache.BsStoreDefinition;

@SuppressWarnings("all")
public class BonusUtility {
	private static final Logger log = LogManager.getLogger("bonusBatch");
	
	/** 計算總金額可取得之紅利
	 * @param exchangeStore
	 * @param guiAmount
	 * @return
	 */
	private static Integer getStoreBonus(BcExchangeStore exchangeStore, Double guiAmount) {
		Integer exBonus = new Integer(0);
		BigDecimal perAmt = new BigDecimal(String.valueOf(exchangeStore.getPerAmt()));
		BigDecimal perBonus = new BigDecimal(String.valueOf(exchangeStore.getPerBonus()));
		BigDecimal amount = new BigDecimal(String.valueOf(guiAmount));
		BigDecimal divideCount = amount.divide(perAmt, 0, BigDecimal.ROUND_DOWN);	//無條件捨去
		exBonus = divideCount.multiply(perBonus).setScale(0, BigDecimal.ROUND_DOWN).intValue();//無條件捨去
		return exBonus;
	}
	
	/** 計算總金額可取得之紅利與Log
	 * @param exchangeStore
	 * @param guiAmount
	 * @param isAdd	true : 加點 / false : 扣點
	 * @return
	 */
	public static BonusVO getExchangeStoreBonus(BcExchangeStore exchangeStore, SaleMaster master, boolean isAdd) {
		
		return getExchangeStoreBonus(exchangeStore, master, isAdd, 0.0);
	}
	
	
	/** 計算總金額可取得之紅利與Log
	 * @param exchangeStore
	 * @param guiAmount
	 * @param isAdd	true : 加點 / false : 扣點
	 * @param bsType0ExcludeSkuAmt 排外商品金額
	 * @return
	 */
	public static BonusVO getExchangeStoreBonus(BcExchangeStore exchangeStore, SaleMaster master, boolean isAdd, Double bsType0ExcludeSkuAmt) {
		BonusVO vo = new BonusVO();
		Double guiAmount = Math.abs(master.getTrans_tot() - bsType0ExcludeSkuAmt);
		
		
		if (master.getTrans_tot().equals(new Double(0.0)) || (guiAmount <= 0 && Math.abs(bsType0ExcludeSkuAmt) > 0)) {
			guiAmount = 0.0;
		}
		
		Integer exBonus = getStoreBonus(exchangeStore, guiAmount);
		if (master.getTrans_tot().equals(new Double(0.0)) || (guiAmount <= 0 && Math.abs(bsType0ExcludeSkuAmt) > 0)) {
			vo.addCreate(exBonus, exchangeStore.getBcBonusSettingMst().getPromotId(), null);
		}else if(exBonus>0) {
			if(isAdd)
				vo.addCreate(exBonus, exchangeStore.getBcBonusSettingMst().getPromotId(), null);
			else
				vo.delCreate(exBonus, exchangeStore.getBcBonusSettingMst().getPromotId(), null);
		} 
		
		return vo;
	}
	
	public static BonusVO getExchangeStoreBonusNew(boolean isAdd, String promotid, Integer exBonus) {
		BonusVO vo = new BonusVO();
		if(isAdd) {
			vo.addCreate(exBonus, promotid, null);
		} else {
			vo.delCreate(exBonus, promotid, null);
		}
		
		return vo;
	}
	
	/** 取得適合區間的加倍率
	 * @param guiPercentSet
	 * @param guiAmount
	 * @return
	 */
	//private static Double getGuiAmtRangePercent(Set guiPercentSet, Double guiAmount) {
	private static BcBonusSettingDtl getGuiAmtRangePercent(Set guiPercentSet, Double guiAmount) {
		//BcBonusPercentAmt bcBonusPercentAmt = null;
		BcBonusSettingDtl bcBonusSettingDtl = null;
		Double percent = new Double(0);
		for(Iterator iterator = guiPercentSet.iterator(); iterator.hasNext(); ) {
			BcBonusSettingDtl amt = (BcBonusSettingDtl)iterator.next();
			if(checkValidationRange(amt, guiAmount)) {
				bcBonusSettingDtl = amt;
				break;
			}
		}
		return bcBonusSettingDtl;
	}
	
	/** 取得在適合區間的兌換紅利
	 * @param bonusAmtSet
	 * @param guiAmount
	 * @return
	 */
	//private static Integer getGuiAmtRangeBonus(Set bonusAmtSet, Double guiAmount) {
	private static BcBonusSettingDtl getGuiAmtRangeBonus(Set bonusAmtSet, Double guiAmount) {
		BcBonusSettingDtl bcBonusAmt = null;
		for(Iterator iterator = bonusAmtSet.iterator(); iterator.hasNext(); ) {
			BcBonusSettingDtl amt = (BcBonusSettingDtl)iterator.next();
			if(checkValidationRange(amt, guiAmount)) {
				bcBonusAmt = amt;
				break;
			}
		}
		return bcBonusAmt;
	}
	
	/** 取得在適合區間的兌換紅利
	 * @param bonusAmtSet
	 * @param guiAmount
	 * @param isAdd
	 * @return isAdd	true : 加點 / false : 扣點
	 */
	public static BonusVO getGuiBonusAmt(Set bonusAmtSet, Double guiAmount, boolean isAdd) {
		BcBonusSettingDtl bonusAmt = getGuiAmtRangeBonus(bonusAmtSet, guiAmount);
		BonusVO vo = new BonusVO();
		Integer exBonus = new Integer(0);
		if(bonusAmt!=null) {
			exBonus = bonusAmt.getExBonus();
			if(exBonus>0) {
				if(isAdd)
					vo.addCreate(exBonus, bonusAmt.getBcBonusSettingMst().getPromotId(), null);
				else
					vo.delCreate(exBonus, bonusAmt.getBcBonusSettingMst().getPromotId(), null);
			}
		}
		
		return vo;
	}
	
	/** 取得在退貨後適合區間的兌換紅利與Log
	 * @param bonusAmtSet
	 * @param normalMaster
	 * @param rejectionMaster
	 * @return
	 */
	public static BonusVO getRejectionGuiBonusAmt(Set bonusAmtSet, SaleMaster normalMaster, Double rejectionTotal, boolean isAdd) {
		//原區間紅利
		//Integer oldBonus = getGuiAmtRangeBonus(bonusAmtSet, normalMaster.getTrans_tot());
		BcBonusSettingDtl oldBonusAmt = getGuiAmtRangeBonus(bonusAmtSet, normalMaster.getTrans_tot());
		Integer oldBonus = new Integer(0);
		if(oldBonusAmt!=null)
			oldBonus = oldBonusAmt.getExBonus();
		//取得退貨後的消費金額
		Double newTrans_tot = normalMaster.getTrans_tot().doubleValue() + rejectionTotal.doubleValue();
		//Integer newBonus = getGuiAmtRangeBonus(bonusAmtSet, newTrans_tot);
		BcBonusSettingDtl newBonusAmt = getGuiAmtRangeBonus(bonusAmtSet, newTrans_tot);
		Integer newBonus = new Integer(0);
		if(newBonusAmt!=null)
			newBonus = newBonusAmt.getExBonus();
		//需吐回的紅利
		Integer exBonus = oldBonus - newBonus;
		BonusVO vo = new BonusVO();
		if(exBonus>0) {
			if(isAdd)
				vo.addCreate(exBonus, oldBonusAmt.getBcBonusSettingMst().getPromotId(), null);
			else
				vo.delCreate(exBonus, oldBonusAmt.getBcBonusSettingMst().getPromotId(), null);
		}
		return vo;
	}
	
	public static BonusVO getRejectionGuiAmtPercentBonus(BcExchangeStore store, Set guiPercentSet, SaleMaster master, Double rejectionTotal, boolean isAdd) {
		Double transTot = master.getTrans_tot()+rejectionTotal;
		Integer singleBonus = getStoreBonus(store, transTot);
		BonusVO vo = getGuiAmtPercentBonus(guiPercentSet, transTot, singleBonus, isAdd);
		return vo;
	}
	
	/** 取得加倍紅利
	 * @param guiPercentSet
	 * @param guiAmount
	 * @param bonus
	 * @param isAdd
	 * @return
	 */
	public static BonusVO getGuiAmtPercentBonus(Set guiPercentSet, Double guiAmount, Integer bonus, boolean isAdd) {
		//Double percent = getGuiAmtRangePercent(guiPercentSet, guiAmount);
		BcBonusSettingDtl percentAmt = getGuiAmtRangePercent(guiPercentSet, guiAmount);
		BonusVO vo = new BonusVO();
		Double percent = new Double(0);
		if(percentAmt!=null) {
			percent = percentAmt.getPercent();
			if(percent>0) {
				vo.setPercent(percent);
				BigDecimal exBonus = getGuiAmtPercentBonus(new BigDecimal(String.valueOf(percent)), new BigDecimal(String.valueOf(bonus)));
				if(exBonus.intValue()>0) {
					if(isAdd)
						vo.addCreate(exBonus.intValue(), percentAmt.getBcBonusSettingMst().getPromotId(), null);
					else
						vo.delCreate(exBonus.intValue(), percentAmt.getBcBonusSettingMst().getPromotId(), null);
				}
			}
		}
		
		return vo;
	}
	
	/** 特惠帳戶紅利加倍
	 * @param percent
	 * @param bonus
	 * @param isAdd
	 * @return
	 */
	public static BonusVO getSpecialBonus(Double percent, Integer bonus, boolean isAdd) {
		BonusVO vo = new BonusVO();
		vo.setPercent(percent);
		BigDecimal exBonus = getGuiAmtPercentBonus(new BigDecimal(String.valueOf(percent)), new BigDecimal(String.valueOf(bonus)));
		if(exBonus.intValue()>0) {
			if(isAdd)
				vo.addCreate(exBonus.intValue());
			else
				vo.delCreate(exBonus.intValue());
		}
		return vo;
	}
	
	/** 紅利倍率計算
	 * @param percent
	 * @param bonus
	 * @return
	 */
	private static BigDecimal getGuiAmtPercentBonus(BigDecimal percent, BigDecimal bonus) {
		BigDecimal exBonus = percent.multiply(bonus).setScale(0, BigDecimal.ROUND_DOWN);
		return exBonus;
	}
	
	/** 取得商品累積紅利
	 * @param skuBonus
	 * @param detail
	 * @return
	 */
	private static Integer getChannelSkuBonus(BcBonusSku skuBonus, BcExchangeStore exchangeStore, SaleDetail detail) {
		Integer exBonus = new Integer(0);
		//取出店點所對應的通路
		if(skuBonus.getClassType().intValue()==BcBonusService.CLASS_TYPE_1.intValue()) {
			//商品累積紅利
			if(detail.getSku_nos().equals(skuBonus.getSku())) {
				if(skuBonus.getBonusType().intValue() == BcBonusService.BONUS_TYPE_0)
					exBonus = skuBonus.getExBonus()*(Math.abs(detail.getTrans_qty()));
				else if(skuBonus.getBonusType().intValue() == BcBonusService.BONUS_TYPE_1)
					exBonus = getChannelSkuPercentBonus(skuBonus, exchangeStore, detail);
			}
		} else if(skuBonus.getClassType().intValue()==BcBonusService.CLASS_TYPE_2.intValue()) {
			//商品分類紅利
			if(skuBonus.getSubClass()!=null&&!skuBonus.getSubClass().trim().equals("")) {
				//商品分類四!=null，四項分類有值
				if(detail.getDept_code().equals(skuBonus.getDept())
						&&detail.getSdept_code().equals(skuBonus.getSubDept())
						&&detail.getClas_code().equals(skuBonus.getClass_())
						&&detail.getSclas_code().equals(skuBonus.getSubClass())) {
					//exBonus = skuBonus.getExBonus()*detail.getTrans_qty();
					if(skuBonus.getBonusType().intValue() == BcBonusService.BONUS_TYPE_0)
						exBonus = skuBonus.getExBonus()*(Math.abs(detail.getTrans_qty()));
					else if(skuBonus.getBonusType().intValue() == BcBonusService.BONUS_TYPE_1)
						exBonus = getChannelSkuPercentBonus(skuBonus, exchangeStore, detail);
				}
			} else if(skuBonus.getClass_()!=null&&!skuBonus.getClass_().trim().equals("")) {
				//商品分類三!=null，三項分類有值
				if(detail.getDept_code().equals(skuBonus.getDept())
						&&detail.getSdept_code().equals(skuBonus.getSubDept())
						&&detail.getClas_code().equals(skuBonus.getClass_())) {
					//exBonus = skuBonus.getExBonus()*detail.getTrans_qty();
					if(skuBonus.getBonusType().intValue() == BcBonusService.BONUS_TYPE_0)
						exBonus = skuBonus.getExBonus()*(Math.abs(detail.getTrans_qty()));
					else if(skuBonus.getBonusType().intValue() == BcBonusService.BONUS_TYPE_1)
						exBonus = getChannelSkuPercentBonus(skuBonus, exchangeStore, detail);
				}
			} else if(skuBonus.getSubDept()!=null&&!skuBonus.getSubDept().trim().equals("")) {
				//商品分類二!=null，二項分類有值
				if(detail.getDept_code().trim().equals(skuBonus.getDept())
						&&detail.getSdept_code().trim().equals(skuBonus.getSubDept())) {
					//exBonus = skuBonus.getExBonus()*detail.getTrans_qty();
					if(skuBonus.getBonusType().intValue() == BcBonusService.BONUS_TYPE_0)
						exBonus = skuBonus.getExBonus()*(Math.abs(detail.getTrans_qty()));
					else if(skuBonus.getBonusType().intValue() == BcBonusService.BONUS_TYPE_1)
						exBonus = getChannelSkuPercentBonus(skuBonus, exchangeStore, detail);
				}
			} else if(skuBonus.getDept()!=null&&!skuBonus.getDept().trim().equals("")) {
				//商品分類一!=null，一項分類有值
				if(detail.getDept_code().equals(skuBonus.getDept())) {
					//exBonus = skuBonus.getExBonus()*detail.getTrans_qty();
					if(skuBonus.getBonusType().intValue() == BcBonusService.BONUS_TYPE_0)
						exBonus = skuBonus.getExBonus()*(Math.abs(detail.getTrans_qty()));
					else if(skuBonus.getBonusType().intValue() == BcBonusService.BONUS_TYPE_1)
						exBonus = getChannelSkuPercentBonus(skuBonus, exchangeStore, detail);
				}
			}
		} else if(skuBonus.getClassType().intValue()==BcBonusService.CLASS_TYPE_3.intValue()) {
			//廠商紅利
			if(detail.getVendor_id().equals(skuBonus.getVentorId())) {
				//exBonus = skuBonus.getExBonus()*detail.getTrans_qty();
				if(skuBonus.getBonusType().intValue() == BcBonusService.BONUS_TYPE_0)
					exBonus = skuBonus.getExBonus()*(Math.abs(detail.getTrans_qty()));
				else if(skuBonus.getBonusType().intValue() == BcBonusService.BONUS_TYPE_1)
					exBonus = getChannelSkuPercentBonus(skuBonus, exchangeStore, detail);
			}
		}
		return exBonus;
	}
	
	/** 取得商品累積紅利(SOM)
	 * @param skuBonus
	 * @param detail
	 * @return
	 */
	private static Integer getChannelSkuBonus(BcBonusSku skuBonus, BcExchangeStore exchangeStore, Map<String,Object> detail) {
		Integer exBonus = new Integer(0);
		
		//取出店點所對應的通路
		if(skuBonus.getClassType().intValue()==BcBonusService.CLASS_TYPE_1.intValue()) {
			//商品累積紅利
			if(((String)detail.get("SKU_NO")).equals(skuBonus.getSku())){
				if(skuBonus.getBonusType().intValue() == BcBonusService.BONUS_TYPE_1)
					exBonus = getChannelSkuPercentBonus(skuBonus, exchangeStore, ((BigDecimal)detail.get("ACT_POS_AMT")).doubleValue(),((BigDecimal)detail.get("QUANTITY")).intValue());
			}
		} else if(skuBonus.getClassType().intValue()==BcBonusService.CLASS_TYPE_2.intValue()) {
			//商品分類紅利
			if(skuBonus.getSubClass()!=null&&!skuBonus.getSubClass().trim().equals("")) {
				//商品分類四!=null，四項分類有值
				if(((String)detail.get("SUB_DEPT_ID")).equals(skuBonus.getSubDept())
						&&((String)detail.get("CLASS_ID")).equals(skuBonus.getClass_())
						&&((String)detail.get("SUB_CLASS_ID")).equals(skuBonus.getSubClass())) {
					if(skuBonus.getBonusType().intValue() == BcBonusService.BONUS_TYPE_1)
						exBonus = getChannelSkuPercentBonus(skuBonus, exchangeStore, ((BigDecimal)detail.get("ACT_POS_AMT")).doubleValue(),((BigDecimal)detail.get("QUANTITY")).intValue());
				}
			} else if(skuBonus.getClass_()!=null&&!skuBonus.getClass_().trim().equals("")) {
				//商品分類三!=null，三項分類有值
				if(((String)detail.get("SUB_DEPT_ID")).equals(skuBonus.getSubDept())
						&&((String)detail.get("CLASS_ID")).equals(skuBonus.getClass_())) {
					if(skuBonus.getBonusType().intValue() == BcBonusService.BONUS_TYPE_1)
						exBonus = getChannelSkuPercentBonus(skuBonus, exchangeStore, ((BigDecimal)detail.get("ACT_POS_AMT")).doubleValue(),((BigDecimal)detail.get("QUANTITY")).intValue());
				}
			} else if(skuBonus.getSubDept()!=null&&!skuBonus.getSubDept().trim().equals("")) {
				//商品分類二!=null，二項分類有值
				if(((String)detail.get("SUB_DEPT_ID")).trim().equals(skuBonus.getSubDept())) {
					if(skuBonus.getBonusType().intValue() == BcBonusService.BONUS_TYPE_1)
						exBonus = getChannelSkuPercentBonus(skuBonus, exchangeStore, ((BigDecimal)detail.get("ACT_POS_AMT")).doubleValue(),((BigDecimal)detail.get("QUANTITY")).intValue());
				}
			} else if(skuBonus.getDept()!=null&&!skuBonus.getDept().trim().equals("")) {
				//商品分類一!=null，一項分類有值
				if(skuBonus.getBonusType().intValue() == BcBonusService.BONUS_TYPE_1)
					exBonus = getChannelSkuPercentBonus(skuBonus, exchangeStore, ((BigDecimal)detail.get("ACT_POS_AMT")).doubleValue(),((BigDecimal)detail.get("QUANTITY")).intValue());
			}
		} else if(skuBonus.getClassType().intValue()==BcBonusService.CLASS_TYPE_3.intValue()) {
			//廠商紅利
			if(((String)detail.get("VENDOR_ID")).equals(skuBonus.getVentorId())) {
				if(skuBonus.getBonusType().intValue() == BcBonusService.BONUS_TYPE_1)
					exBonus = getChannelSkuPercentBonus(skuBonus, exchangeStore, ((BigDecimal)detail.get("ACT_POS_AMT")).doubleValue(),((BigDecimal)detail.get("QUANTITY")).intValue());
			}
		}
		return exBonus;
	}
	
	/** 取得商品累積紅利與Log
	 * @param skuBonus
	 * @param detail
	 * @param isAdd	true : 加點 / false : 扣點
	 * @return
	 */
	public static BonusVO getSkuBonus(BcBonusSku skuBonus, BcExchangeStore exchangeStore, SaleDetail detail, boolean isAdd, AccountVO accountVO) {
		Integer exBonus = getChannelSkuBonus(skuBonus, exchangeStore, detail);
		BonusVO vo = new BonusVO();
		if(exBonus>0) {
			if(isAdd){
				vo.addCreate(exBonus, skuBonus.getBcBonusSettingMst().getPromotId(), null);
			    accountVO.setBonusTotal(accountVO.getBonusTotal() + vo.getExBonus());
			} else {
				vo.delCreate(exBonus, skuBonus.getBcBonusSettingMst().getPromotId(), null);
				accountVO.setBonusTotal(accountVO.getBonusTotal() - vo.getExBonus());
			}
		}
		return vo;
	}
	
	/** 取得商品累積紅利與Log(SOM)
	 * @param skuBonus
	 * @param detail
	 * @return
	 */
	public static Integer getSkuBonus(BcBonusSku skuBonus, BcExchangeStore exchangeStore, Map<String,Object> detail, AccountVO accountVO) {
		return getChannelSkuBonus(skuBonus, exchangeStore, detail);
	}
	
	public static BonusVO getSkuBonus(BcBonusSku skuBonus, Map<String,Object> detail,boolean isAdd,Integer exBonus, AccountVO accountVO) {
		BonusVO vo = new BonusVO();
		vo.setActivate(true);
		if(isAdd){
			vo.addCreate(exBonus, skuBonus.getBcBonusSettingMst().getPromotId(), null);
		    accountVO.setBonusTotal(accountVO.getBonusTotal() + vo.getExBonus());
		} else {
			vo.delCreate(exBonus, skuBonus.getBcBonusSettingMst().getPromotId(), null);
			accountVO.setBonusTotal(accountVO.getBonusTotal() - vo.getExBonus());
		}
		return vo;
	}
	
	public static BonusVO getRejectSkuBonus(BcBonusSku skuBonus, BcExchangeStore exchangeStore, SaleDetail detail) {
		Integer exBonus = getChannelSkuBonus(skuBonus, exchangeStore, detail);
		BonusVO vo = new BonusVO();
		if(exBonus>0)
			vo.delCreate(exBonus);
		return vo;
	}
	
	/** 通用商品累積百分比計算
	 * @param skuBonus
	 * @param exchangeStore
	 * @param detail
	 * @return
	 */
	private static Integer getChannelSkuPercentBonus(BcBonusSku skuBonus, BcExchangeStore exchangeStore, SaleDetail detail) {
		Integer exBonus = new Integer(0);
		Double total = detail.getActual_amt()*(Math.abs(detail.getTrans_qty()));
		if(exchangeStore!=null) {
			BigDecimal basicBonus = new BigDecimal(String.valueOf(getStoreBonus(exchangeStore, total)));	//基礎紅利
			//System.err.println("基礎紅利 : "+basicBonus);
			BigDecimal percent = new BigDecimal(String.valueOf(skuBonus.getExPercent()));
			//System.err.println("percent : "+percent);
			try {
				exBonus = basicBonus.multiply(percent).setScale(0, BigDecimal.ROUND_DOWN).intValue();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		return exBonus;
	}
	
	/**
	 * 通用商品累積百分比計算
	 * @param skuBonus
	 * @param exchangeStore
	 * @param amt
	 * @param qty
	 * @return
	 */
	private static Integer getChannelSkuPercentBonus(BcBonusSku skuBonus, BcExchangeStore exchangeStore, double amt,int qty) {
		Integer exBonus = new Integer(0);
		Double total = amt*(Math.abs(qty));
		if(exchangeStore!=null) {
			BigDecimal basicBonus = new BigDecimal(String.valueOf(getStoreBonus(exchangeStore, total)));	//基礎紅利
			//System.err.println("基礎紅利 : "+basicBonus);
			BigDecimal percent = new BigDecimal(String.valueOf(skuBonus.getExPercent()));
			//System.err.println("percent : "+percent);
			try {
				exBonus = basicBonus.multiply(percent).setScale(0, BigDecimal.ROUND_DOWN).intValue();
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		return exBonus;
	}
	
	
	/** 取得紅利兌換商品扣抵點數與Log
	 * @param exchangeSkuMst
	 * @param disc
	 * @param isAdd true : 加點 / false : 扣點
	 * @return
	 */
	public static BonusVO getDelExchangeSkuBonus(Map exchangeSkuMst, SaleDisc disc, boolean isAdd) {
		BonusVO vo = new BonusVO();
		Set exchangeSkuSet = (Set)exchangeSkuMst.get(disc.getDiscNos1());
		if(exchangeSkuSet!=null) {
			for(Iterator iterator = exchangeSkuSet.iterator(); iterator.hasNext(); ) {
				BcBonusSettingDtl exchangeSku = (BcBonusSettingDtl)iterator.next();
				if(disc.getDiscNos2()!=null&&
						exchangeSku.getDetailSeq().intValue()==disc.getDiscNos2().intValue()) {
					Integer exBonus = Math.abs(exchangeSku.getExBonus()*disc.getTransQty());
					if(isAdd)
						vo.addCreate(exBonus, disc.getDiscNos1(), exchangeSku.getDetailSeq());
					else
						vo.delCreate(exBonus, disc.getDiscNos1(), exchangeSku.getDetailSeq());
					
					break;
				}
			}
		}
		return vo;
	}
	
	/** 取得紅利扣抵現金與Log
	 * @param exchangeCashMst
	 * @param disc
	 * @param isAdd true : 加點 / false : 扣點
	 * @return
	 */
	public static BonusVO getDelExchangeCashBonus(Map exchangeCashMst, SaleDisc disc, boolean isAdd) {
		BonusVO vo = new BonusVO();
		Set exchangeCashSet = (Set)exchangeCashMst.get(disc.getDiscNos1());
		if(exchangeCashSet!=null) {
			for(Iterator iterator = exchangeCashSet.iterator(); iterator.hasNext(); ) {
				BcBonusSettingDtl exchangeCash = (BcBonusSettingDtl)iterator.next();
				if(disc.getDiscNos2()!=null&&
						exchangeCash.getDetailSeq().intValue()==disc.getDiscNos2().intValue()) {
					Integer exBonus = getCashExchangeBonus(exchangeCash, disc);
					vo.setPerCash(exchangeCash.getExCash());
					vo.setPerBonus(exchangeCash.getExBonus());
					if(isAdd) {
						vo.addCreate(exBonus, disc.getDiscNos1(), exchangeCash.getDetailSeq());
					} else {
						vo.delCreate(exBonus, disc.getDiscNos1(), exchangeCash.getDetailSeq());
					}
					
					//帶入折抵金額至BC_BONUS_LOG(BONUS_TYPE=7, BONUS_TYPE=72)
					vo.getLog().setDiscAmt(disc.getDscAmt());
					
					break;
				}
			}
		}
		return vo;
	}
	
	/** MtGroup群組紅利
	 * @param group
	 * @param exchangeStore
	 * @param master
	 * @param isAdd
	 * @return
	 */
	public static BonusVO getMtGroupBonus(PromotionGroupVo group, BcExchangeStore exchangeStore, SaleMaster master, boolean isAdd) {
		BonusVO vo = new BonusVO();
		//符合活動的VIP NO
		Set<String> vipNoSet = group.getVipNoSet();
		if(vipNoSet.contains(master.getCust_nos())) {//查找cust_nos是否在vip裡
			if(group.getType().intValue() == PromotionGroupVo._TYPE_GROUP.intValue()) {	//以MtGroup設定判定
				//活動通路
				List<DiscountChannelVo> discountChannelList = group.getDiscountChannel();
				//發票所屬通路
				String saleChannel = BsStoreDefinition.getChannelIdByStoreNo(master.getStore_no());
				if(discountChannelList!=null) {
					for(Iterator subIter = discountChannelList.iterator(); subIter.hasNext(); ) {
						DiscountChannelVo channel  = (DiscountChannelVo)subIter.next();
						if(channel.getChannelId().equals(saleChannel)) {//通路比對
							if(channel.getActivate() && channel.getAccumulate()) {//是否累積紅利
								Integer bonus = new Integer(0);
								if(!"0".equals(channel.getBonus()) && "0".equals(channel.getMultiply())) {
									//固定紅利
									bonus = new Integer(channel.getBonus());
								} else if("0".equals(channel.getBonus()) && !"0".equals(channel.getMultiply())) {
									//倍數加乘
									if(exchangeStore!=null) {
										BigDecimal basicBonus = new BigDecimal(String.valueOf(getStoreBonus(exchangeStore, master.getTrans_tot())));	//基礎紅利
										bonus = basicBonus.multiply(new BigDecimal(String.valueOf(channel.getMultiply()))).setScale(0, BigDecimal.ROUND_DOWN).intValue();
									}
								}
								if(bonus>0) {
									if(isAdd) {
										vo.addCreate(bonus, group.getGroupId(), null);
										vo.getLog().setReason(group.getGroupName());
									} else {
										vo.delCreate(bonus, group.getGroupId(), null);
										vo.getLog().setReason(group.getGroupName());
									}
								}
							}
						}
					}
				}
			} else {	//以BcBonus設定判定
				for(Iterator storeIter = group.getExchangeStore().iterator(); storeIter.hasNext(); ) {
					BcExchangeStore store = (BcExchangeStore)storeIter.next();
					if(store.getStoreId().equals(master.getStore_no())) {	//判斷是否紅利參予店
						if(group.getType().intValue() == PromotionGroupVo._TYPE_AMT.intValue()
								||group.getType().intValue() == PromotionGroupVo._TYPE_AMT_FOR_BIRTHDAY.intValue()) {
							//固定點數
							vo = BonusUtility.getGuiBonusAmt(group.getBonusAmt(), master.getTrans_tot(), isAdd);
						} else if(group.getType().intValue() == PromotionGroupVo._TYPE_PERCENT_AMT.intValue()
								||group.getType().intValue() == PromotionGroupVo._TYPE_PERCENT_AMT_FOR_BIRTHDAY.intValue()){
							//基礎點數
							Integer basicBonus = getStoreBonus(exchangeStore, master.getTrans_tot());	//基礎紅利
							//倍率
							vo = BonusUtility.getGuiAmtPercentBonus(group.getBonusPercentAmt(), master.getTrans_tot(), basicBonus, isAdd);
						}
						if(vo!=null&&vo.isActivate())
							vo.getLog().setReason(group.getGroupName());
						break;
					}
				}
			}
		}
		return vo;
	}
	
	/** MtGroup群組紅利
	 * @param group
	 * @param master
	 * @param isAdd
	 * @return BonusVO
	 */
	public static BonusVO getMtGroupWageBonus(PromotionGroupVo group, BcExchangeStore exchangeStore, SaleMaster master, boolean isAdd) {
		BonusVO vo = new BonusVO();
		//符合活動的VIP NO
		Set<String> vipNoSet = group.getVipNoSet();
		if (vipNoSet.contains(master.getCust_nos())) {//查找cust_nos是否在vip裡
			for (Iterator storeIter = group.getExchangeStore().iterator(); storeIter.hasNext();) {
				BcExchangeStore store = (BcExchangeStore) storeIter.next();
				if (store != null && "TLW".equals(store.getChannelId())) {
					if(store.getStoreId().equals(master.getStore_no())) { //判斷是否紅利參予店
						//基礎點數
						Integer basicBonus = getStoreBonus(exchangeStore, master.getTrans_tot());	//基礎紅利
						//倍率
						vo = BonusUtility.getGuiAmtPercentBonus(group.getBonusPercentAmt(),  Math.abs(master.getTrans_tot()),  Math.abs(basicBonus), isAdd);
						if (vo != null && vo.isActivate())
							vo.getLog().setReason(group.getGroupName());
						break;
					}
				}
			}
		}
		return vo;
	}
	
	/** 匯入群組紅利退貨(cuml and cuml+birthday)
	 * @param group
	 * @param exchangeStore
	 * @param master
	 * @param rejectionTotal
	 * @param isAdd
	 * @return
	 */
	public static BonusVO getRejectionMtGroupCumlBonus(PromotionGroupVo group, BcExchangeStore exchangeStore, SaleMaster master,
			Double todayRejectionTotal, Double oldRejectionTotal, boolean isAdd) {
		BonusVO vo = new BonusVO();
		boolean isVipExist = false;
		IMarketingService marketingService = (IMarketingService)AppContext.getBean("mtService");
		for(Iterator storeIter = group.getExchangeStore().iterator(); storeIter.hasNext(); ) {
			BcExchangeStore store = (BcExchangeStore)storeIter.next();
			if(store.getStoreId().equals(master.getStore_no())) {	//判斷是否紅利參予店
				try {
					isVipExist = marketingService.isGroupContainVip(group.getGroupId(), master.getTrans_dat(), master.getCust_nos());
					if(isVipExist) {	//vip no 存在於活動
						Double oldTransTot = master.getTrans_tot()+oldRejectionTotal;	//前一次所剩消費總額
						Double newTransTot = master.getTrans_tot()+oldRejectionTotal+todayRejectionTotal;	//新的消費總額
						if(group.getType().intValue() == PromotionGroupVo._TYPE_AMT.intValue()
								||group.getType().intValue() == PromotionGroupVo._TYPE_AMT_FOR_BIRTHDAY.intValue()) {
							Integer exBonus = new Integer(0);
							Integer oldBonus = new Integer(0);
							Integer newBonus = new Integer(0);
							//固定紅利點數
							BcBonusSettingDtl oldBonusAmt = getGuiAmtRangeBonus(group.getBonusAmt(), oldTransTot);	//前一次區間
							if(oldBonusAmt!=null) {
								oldBonus = oldBonusAmt.getExBonus();	//舊-區間點數
								BcBonusSettingDtl newBonusAmt = getGuiAmtRangeBonus(group.getBonusAmt(), newTransTot);	//新區間
								if(newBonusAmt!=null)
									newBonus = newBonusAmt.getExBonus();	//新-區間點數
								exBonus = oldBonus - newBonus;
								if(exBonus>0) {
									if(isAdd)
										vo.addCreate(exBonus, oldBonusAmt.getBcBonusSettingMst().getPromotId(), null);
									else
										vo.delCreate(exBonus, oldBonusAmt.getBcBonusSettingMst().getPromotId(), null);
								}
							}
						} else if(group.getType().intValue() == PromotionGroupVo._TYPE_PERCENT_AMT.intValue()
								||group.getType().intValue() == PromotionGroupVo._TYPE_PERCENT_AMT_FOR_BIRTHDAY.intValue()) {
							//倍率紅利
							Integer oldSingleBonus = getStoreBonus(exchangeStore, oldTransTot);	//前一次基礎點數
							BonusVO oldVo = getGuiAmtPercentBonus(group.getBonusPercentAmt(), oldTransTot, oldSingleBonus, true);
							Integer newSingleBonus = getStoreBonus(exchangeStore, newTransTot);	//新的基礎點數
							BonusVO newVo = getGuiAmtPercentBonus(group.getBonusPercentAmt(), newTransTot, newSingleBonus, true);
							Integer exBonus = new Integer(oldVo.getExBonus() - newVo.getExBonus());
							if(exBonus>0) {
								if(isAdd)
									vo.addCreate(exBonus.intValue(), group.getGroupId(), null);
								else
									vo.delCreate(exBonus.intValue(), group.getGroupId(), null);
							}
						}
					}
				} catch(Exception e) {
					e.printStackTrace();
					log.error(e);
				}
			}
		}
		return vo;
	}
	
	/** 群組紅利退貨處理
	 * @param bean
	 * @param mtGroupList
	 * @param exchangeStore
	 * @param master
	 * @param isAdd
	 * @return
	 */
	public static BonusVO getRejectionMtGroupBonus(MtSkuCalculateBean bean, PromotionGroupVo group, BcExchangeStore exchangeStore, SaleMaster master, boolean isAdd) {
		BonusVO vo = new BonusVO();
		boolean isVipExist = false;
		//群組紅利
		IMarketingService marketingService = (IMarketingService)AppContext.getBean("mtService");
		if(group.getType().intValue() == PromotionGroupVo._TYPE_GROUP.intValue()) {	//以MtGroup設定判定
			//活動通路
			List<DiscountChannelVo> discountChannelList = group.getDiscountChannel();
			//發票所屬通路
			String saleChannel = BsStoreDefinition.getChannelIdByStoreNo(master.getStore_no());
			if(discountChannelList!=null) {
				for(Iterator subIter = discountChannelList.iterator(); subIter.hasNext(); ) {
					DiscountChannelVo channel  = (DiscountChannelVo)subIter.next();
					if(channel.getChannelId().equals(saleChannel)) {//通路比對
						if(channel.getActivate() && channel.getAccumulate()) {//是否累積紅利
							try {
								isVipExist = marketingService.isGroupContainVip(group.getGroupId(), bean.getMaster().getTrans_dat(), bean.getMaster().getCust_nos());
								if(isVipExist) {	//vip no 存在於活動
									Integer bonus = new Integer(0);
									if(!"0".equals(channel.getBonus()) && "0".equals(channel.getMultiply())) {
										if(bean.checkSkuRejectionCompletion())	//判斷是否退完物品
											bonus = new Integer(channel.getBonus());	//固定紅利
									} else if("0".equals(channel.getBonus()) && !"0".equals(channel.getMultiply())) {
										//倍數加乘
										if(exchangeStore!=null) {
											BigDecimal basicBonus = new BigDecimal(String.valueOf(getStoreBonus(exchangeStore, Math.abs(master.getTrans_tot()))));	//基礎紅利
											bonus = basicBonus.multiply(new BigDecimal(String.valueOf(channel.getMultiply()))).setScale(0, BigDecimal.ROUND_DOWN).intValue();
										}
									}
									if(bonus>0) {
										if(isAdd) {
											vo.addCreate(bonus, group.getGroupId(), null);
											vo.getLog().setReason(group.getGroupName());
										} else {
											vo.delCreate(bonus, group.getGroupId(), null);
											vo.getLog().setReason(group.getGroupName());
										}
									}
								}
							} catch(Exception e) {
								e.printStackTrace();
								log.error(e);
							}
						}
					}
				}
			}
		} else {	//以BcBonus設定判定
			//由getRejectionMtGroupCumlBonus處理
		}
		return vo;
	}
	
	/** 發票通路是否符合活動群組累積紅利條件
	 * @param group
	 * @param master
	 * @return
	 */
	private static boolean mtGroupChannelValidator(PromotionGroupVo group, SaleMaster master) {
		boolean result = false;
		//發票所屬通路
		String saleChannel = BsStoreDefinition.getChannelIdByStoreNo(master.getStore_no());
		//活動通路
		List<DiscountChannelVo> discountChannelList = group.getDiscountChannel();
		if(discountChannelList!=null) {
			for(Iterator subIter = discountChannelList.iterator(); subIter.hasNext(); ) {
				DiscountChannelVo channel  = (DiscountChannelVo)subIter.next();
				if(channel.getChannelId().equals(saleChannel)) {//通路比對
					if(channel.getActivate() && channel.getAccumulate()) {//是否累積紅利
						result = true;
					}
				}
			}
		}
		return result;
	}
	
	/** 判斷卡片在該通路是否累積紅利
	 * @param card
	 * @param storeNo
	 * @return
	 */
	public static boolean checkMmCardByChannel(MmCard card, String guiStoreNo) {
		boolean result = false;
		if(card!=null) {
			if(card.getCardType().intValue()!=MemberGlossary._mm_card_type_normal) {
				//非一般卡判斷是否在店點通路累積紅利
				MarketingService mtService = (MarketingService)AppContext.getBean("mtService");
				try {
					//取得發票所屬通路
					String guiChannel = BsStoreDefinition.getChannelIdByStoreNo(guiStoreNo);
					//會員卡對應的折扣卡
					DiscountVo discount = mtService.getDiscountVoByOid(card.getDisCardOid(),true,false);
					List channelList = discount.getDiscountChannel();
					for(Iterator iterator = channelList.iterator(); iterator.hasNext(); ) {
						//折扣卡通路
						DiscountChannelVo channel = (DiscountChannelVo)iterator.next();
						if(guiChannel.equals(channel.getChannelId())) {
							//通路是否累積紅利
							if(channel.getActivate()&&channel.getAccumulate())
								result = true;
						}
					}
				} catch(Exception e) {
					e.printStackTrace();
					log.error(e);
				}
			} else {
				//一般卡可累積
				result = true;
			}
		}
		return result;
	}
	
	private static Integer getCashExchangeBonus(BcBonusSettingDtl exchangeCash, SaleDisc disc) {
		Integer exBonus = new Integer(0);
		BigDecimal perCash = new BigDecimal(String.valueOf(exchangeCash.getExCash()));
		BigDecimal perBonus = new BigDecimal(String.valueOf(exchangeCash.getExBonus()));
		BigDecimal transQty = new BigDecimal(disc.getTransQty());
		exBonus = perBonus.multiply(transQty).setScale(0, BigDecimal.ROUND_DOWN).intValue();
		return exBonus;
	}
	
	private static boolean checkValidationRange(Object amt, Double guiAmount) {
		boolean result = false;
		Double amountF = new Double(((BcBonusSettingDtl)amt).getAmountF());
		Double amountT = new Double(((BcBonusSettingDtl)amt).getAmountT());
		result = (guiAmount.compareTo(amountF)>=0&&guiAmount.compareTo(amountT)<=0);
		return result;
	}
	
	public static BcBonusLog createBonusLog(AccountVO accountVO, SaleMaster saleInfo, 
			int addBonus, int delBonus, int exchangeType, String otherDesc) {
		BcBonusLog log = new BcBonusLog();
		Date date = DateTimeUtils.getSysDate();
		log.setTransDate(date);
		log.setChannelId(null);
		log.setStoreId(saleInfo.getStore_no());
		log.setVipNo(saleInfo.getCust_nos());
		log.setGuiNo(saleInfo.getGui_nos());
		log.setBonusAdd(addBonus);
		log.setBonusMins(delBonus);
		log.setBonusTotal(accountVO.getBonusTotal());
		if(accountVO.getAccountVoType()==BonusGlossary._account_vo_type_member)
			log.setMemberId(((MembersBO2)accountVO.getObject()).getMemberId());
		else if(accountVO.getAccountVoType()==BonusGlossary._account_vo_type_account)
			log.setAccountId(((Account)accountVO.getObject()).getAccountId());
		if(otherDesc!=null) {
			log.setReason(BonusGlossary.getBonusExchangeReason(exchangeType)+"-"+otherDesc);
		} else {
			log.setReason(BonusGlossary.getBonusExchangeReason(exchangeType));
		}
		log.setCreateTime(date);
		log.setCreator("SYS_BATCH");
		log.setCreatorName("SYS_BATCH");
		log.setModifyTime(date);
		log.setModifier("SYS_BATCH");
		log.setModifierName("SYS_BATCH");
		return log;
	}
	
	public static BonusExceptionLog createExceptionLog(int type, Date transferDate, SaleMaster saleInfo) {
		Date date = DateTimeUtils.getSysDate();
		BonusExceptionLog log = new BonusExceptionLog();
		log.setTransferDate(transferDate);
		log.setExceptionType(type);
		log.setExceptionDesc(BonusExceptionGlossary.getExceptionDesc(type));
		log.setChannelId(null);
		if(saleInfo!=null) {
			log.setStoreNo(saleInfo.getStore_no());//DETAIL.STORE_ID
			log.setTransDat(saleInfo.getTrans_dat());//MATSER.TRANS_DATE
			log.setPosNos(saleInfo.getPos_nos());//PAY.POS_NO
			log.setSerNos(saleInfo.getSer_nos());//PAY.POS_SEQ_NO
			log.setGuiNo(saleInfo.getGui_nos());//PAY.GUI_NO
		}
		log.setCreateTime(date);
		log.setCreator("SYS_BATCH");
		log.setCreatorName("SYS_BATCH");
		log.setModifyTime(date);
		log.setModifier("SYS_BATCH");
		log.setModifierName("SYS_BATCH");
		return log;
	}
	
	public static BcBonusLog createBonusLog(String channelId, String storeId, String memberOid, Long memberId, 
			String marketId, String reason, Integer bonusMins, Integer bonusTotal, Integer bonusType, String serialNum){
		Date date = DateTimeUtils.getSysDate();
		BcBonusLog log = new BcBonusLog();
		
		log.setChannelId(channelId);
		log.setStoreId(storeId);
		log.setMemberOid(memberOid);
		log.setMemberId(memberId);
		log.setMarketId(marketId);
		log.setReason(reason);
		log.setBonusMins(bonusMins);
		log.setBonusTotal(bonusTotal);
		log.setBonusType(bonusType);
		log.setSerialNum(serialNum);
		
		log.setTransDate(date);
		log.setCreateTime(date);
		log.setCreator("SYS_BATCH");
		log.setCreatorName("SYS_BATCH");
		log.setModifyTime(date);
		log.setModifier("SYS_BATCH");
		log.setModifierName("SYS_BATCH");
		
		return log;
	}
	
	public static Map<String, Integer> CalculateBonus(int bonusAddSum, int bonusMinsSum, int thisYearTot, int lastYearTot){
		
		if(bonusAddSum > 0){
			thisYearTot += bonusAddSum;
		} 
		
		if(bonusMinsSum > 0){
			if (lastYearTot > 0){
				if (bonusMinsSum < lastYearTot){
					lastYearTot -= bonusMinsSum;
				} else {
					thisYearTot = thisYearTot + lastYearTot - bonusMinsSum;
					lastYearTot = 0;
				}
			} else {
				thisYearTot -= bonusMinsSum;
			}
		}
		
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("thisYearTot", thisYearTot);
		map.put("lastYearTot", lastYearTot);
		
		return map;
	}
}
