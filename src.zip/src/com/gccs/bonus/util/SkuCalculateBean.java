package com.gccs.bonus.util;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Iterator;
import java.util.Set;

import com.bnq.util.sale.model.SaleDetail;
import com.gccs.bc.model.BcBonusSettingMst;
import com.gccs.bc.model.BcBonusSku;
import com.gccs.bc.service.BcBonusService;
import com.gccs.bonus.model.vo.BonusVO;

public class SkuCalculateBean implements Serializable {
	private static final long serialVersionUID = 6883053045458110867L;

	private BcBonusSettingMst cuml;
	private BonusVO vo = new BonusVO();
	private BigDecimal total = new BigDecimal(0);
	
	public BonusVO getBonusVOAdd() {
		if(this.getTotal()>0) {
			vo = BonusUtility.getGuiBonusAmt(cuml.getBcBonusAmts(), this.getTotal(), true);
		}
		return vo;
	}
	
	public BonusVO getBonusVODel() {
		if(this.getTotal()>0) {
			vo = BonusUtility.getGuiBonusAmt(cuml.getBcBonusAmts(), this.getTotal(), false);
		}
		return vo;
	}
	
	public void checkSkuCondition(SaleDetail detail) {
		//取出店點所對應的通路
//		String detailCannelId = BsStoreDefinition.getChannelIdByStoreNo(detail.getStore_no());
		if(cuml!=null) {
			Set skuSet = cuml.getBcBonusSkus();
			for(Iterator iterator = skuSet.iterator(); iterator.hasNext(); ) {
				BcBonusSku skuBonus = (BcBonusSku)iterator.next();
				if(skuBonus.getClassType().intValue()==BcBonusService.CLASS_TYPE_1.intValue()) {
					//商品編號+通路
//					if(skuBonus.getChannelId().equals(detailCannelId)&&detail.getSku_nos().equals(skuBonus.getSku())) {
					//商品編號	change 商品無須再搭配通路		2011/3/17
					if(detail.getSku_nos().equals(skuBonus.getSku())) {
						this.addAmount(detail.getTrans_qty(), detail.getActual_amt());
					}
				} else if(skuBonus.getClassType().intValue()==BcBonusService.CLASS_TYPE_2.intValue()) {
					//商品分類
					if(skuBonus.getSubClass()!=null&&!skuBonus.getSubClass().trim().equals("")) {
						//商品分類四!=null，四項分類有值
						if(detail.getDept_code().equals(skuBonus.getDept())
								&&detail.getSdept_code().equals(skuBonus.getSubDept())
								&&detail.getClas_code().equals(skuBonus.getClass_())
								&&detail.getSclas_code().equals(skuBonus.getSubClass())) {
							this.addAmount(detail.getTrans_qty(), detail.getActual_amt());
						}
					} else if(skuBonus.getClass_()!=null&&!skuBonus.getClass_().trim().equals("")) {
						//商品分類三!=null，三項分類有值
						if(detail.getDept_code().equals(skuBonus.getDept())
								&&detail.getSdept_code().equals(skuBonus.getSubDept())
								&&detail.getClas_code().equals(skuBonus.getClass_())) {
							this.addAmount(detail.getTrans_qty(), detail.getActual_amt());
						}
					} else if(skuBonus.getSubDept()!=null&&!skuBonus.getSubDept().trim().equals("")) {
						//商品分類二!=null，二項分類有值
						if(detail.getDept_code().trim().equals(skuBonus.getDept())
								&&detail.getSdept_code().trim().equals(skuBonus.getSubDept())) {
							this.addAmount(detail.getTrans_qty(), detail.getActual_amt());
						}
					} else if(skuBonus.getDept()!=null&&!skuBonus.getDept().trim().equals("")) {
						//商品分類一!=null，一項分類有值
						if(detail.getDept_code().equals(skuBonus.getDept())) {
							this.addAmount(detail.getTrans_qty(), detail.getActual_amt());
						}
					}
				} else if(skuBonus.getClassType().intValue()==BcBonusService.CLASS_TYPE_3.intValue()) {
					//廠商紅利
					if(detail.getVendor_id().equals(skuBonus.getVentorId())) {
						this.addAmount(detail.getTrans_qty(), detail.getActual_amt());
					}
				}
			}
		}
	}
	
	public SkuCalculateBean(BcBonusSettingMst cuml) {
		this.cuml = cuml;
	}
	
	public Double getTotal() {
		return total.doubleValue();
	}
	
	public void addAmount(Integer qty, Double amount) {
		BigDecimal detailAmount = new BigDecimal(qty).multiply(new BigDecimal(amount));
		total = total.add(detailAmount);
	}
	
	public BcBonusSettingMst getCuml() {
		return cuml;
	}
	
	public void setCuml(BcBonusSettingMst cuml) {
		this.cuml = cuml;
	}
		
}
