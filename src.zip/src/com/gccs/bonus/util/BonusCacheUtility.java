package com.gccs.bonus.util;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.gccs.bc.model.BcBonusSettingMst;
import com.gccs.bc.model.BcExchangeStore;

/** 暫時快取配置
 * @author Administrator
 *
 */
public class BonusCacheUtility {
	
	/** 通用累積紅利單筆消費
	 * @param bonusList
	 * @return
	 */
	@SuppressWarnings("all")
	public static Map getSingleCostBonus(List bonusList) {
		Map bonusMap = new HashMap();
		for(Iterator iterator = bonusList.iterator(); iterator.hasNext(); ) {
			BcBonusSettingMst cuml = (BcBonusSettingMst)iterator.next();
			Set stores = cuml.getBcExchangeStores();	//通用累積適用店點
			for(Iterator subIter = stores.iterator(); subIter.hasNext(); ) {
				BcExchangeStore store = (BcExchangeStore)subIter.next();
				//bonusMap.put(store.getChannelId()+_SPLIT_STR+store.getStoreId(), store);
				bonusMap.put(store.getStoreId(), store);
			}
		}
		return bonusMap;
	}
	
	/** 通用累積紅利發票金額額外加點
	 * @param bonusList
	 * @return
	 */
//	public static Map getGuiBonus(List bonusList) {
//		Map amtBonusMap = new HashMap();
//		for(Iterator iterator = bonusList.iterator(); iterator.hasNext(); ) {
//			BcBonusCuml cuml = (BcBonusCuml)iterator.next();
//			//System.err.println(cuml.getPromotId());
//			Set stores = cuml.getBcExchangeStores();	//通用累積適用店點
//			for(Iterator subIter = stores.iterator(); subIter.hasNext(); ) {
//				BcExchangeStore store = (BcExchangeStore)subIter.next();
//				//通用累積適用店點，額外金額累積
//				if(!amtBonusMap.containsKey(store.getStoreId())) {
//					Set amtBonusSet = cuml.getBcBonusAmts();
//					amtBonusMap.put(store.getStoreId(), amtBonusSet);
//				} else {
//					Set amtBonusSet = (Set)amtBonusMap.get(store.getStoreId());
//					amtBonusSet.addAll(cuml.getBcBonusAmts());
//				}
//			}
//		}
//		return amtBonusMap;
//	}
	
	/** 通用累積紅利發票金額額外加點(多重活動)
	 * @param bonusList
	 * @return
	 */
	@SuppressWarnings("all")
	public static Map getGuiAmtBonus(List bonusList) {
		Map amtBonusCumlMap = new HashMap();
		for(Iterator iterator = bonusList.iterator(); iterator.hasNext(); ) {
			BcBonusSettingMst cuml = (BcBonusSettingMst)iterator.next();
			Set stores = cuml.getBcExchangeStores();	//通用累積適用店點
			for(Iterator subIter = stores.iterator(); subIter.hasNext(); ) {
				BcExchangeStore store = (BcExchangeStore)subIter.next();
				//通用累積適用店點，額外金額累積
				if(!amtBonusCumlMap.containsKey(store.getStoreId())) {
					Set cumlSet = new HashSet();
					cumlSet.add(cuml);
					amtBonusCumlMap.put(store.getStoreId(), cumlSet);
				} else {
					Set cumlSet = (Set)amtBonusCumlMap.get(store.getStoreId());
					cumlSet.add(cuml);
				}
			}
		}
		return amtBonusCumlMap;
	}
	
	/** 通用發票倍數(生日加倍)
	 * @param guiPercentList
	 * @return
	 */
	@SuppressWarnings("all")
	public static Map getGuiPercentBonus(List guiPercentList) {
		Map guiPercentBonusMap = new HashMap();
		for(Iterator iterator = guiPercentList.iterator(); iterator.hasNext(); ) {
			BcBonusSettingMst cuml = (BcBonusSettingMst)iterator.next();
			Set stores = cuml.getBcExchangeStores();	//通用發票倍數適用店點
			for(Iterator subIter = stores.iterator(); subIter.hasNext(); ) {
				BcExchangeStore store = (BcExchangeStore)subIter.next();
				//通用累積適用店點，額外金額累積
				if(!guiPercentBonusMap.containsKey(store.getStoreId())) {
					Set cumlSet = new HashSet();
					cumlSet.add(cuml);
					guiPercentBonusMap.put(store.getStoreId(), cumlSet);
				} else {
					Set cumlSet = (Set)guiPercentBonusMap.get(store.getStoreId());
					cumlSet.add(cuml);
				}
			}
		}
		return guiPercentBonusMap;
	}
	
	/** 商品累積設定
	 * @param bonusSkuList
	 * @return
	 */
	@SuppressWarnings("all")
	public static Map getBonusSku(List bonusSkuList) {
		Map skuBonusMap = new HashMap();
		for(Iterator iterator = bonusSkuList.iterator(); iterator.hasNext(); ) {
			BcBonusSettingMst cuml = (BcBonusSettingMst)iterator.next();
			Set stores = cuml.getBcExchangeStores();	//商品累積適用店點
			for(Iterator subIter = stores.iterator(); subIter.hasNext(); ) {
				BcExchangeStore store = (BcExchangeStore)subIter.next();
				if(!skuBonusMap.containsKey(store.getStoreId())) {
					Set skuBonusSet = cuml.getBcBonusSkus();
					skuBonusMap.put(store.getStoreId(), skuBonusSet);
				} else {
					Set skuBonusSet = (Set)skuBonusMap.get(store.getStoreId());
					skuBonusSet.addAll(cuml.getBcBonusSkus());
				}
			}
		}
		return skuBonusMap;
	}
	
	/** 紅利兌換商品
	 * @param exchangeSkuList
	 * @return
	 */
	@SuppressWarnings("all")
	public static Map getExchangeSku(List exchangeSkuList) {
		Map exchangeSkuMap = new HashMap();
		for(Iterator iterator = exchangeSkuList.iterator(); iterator.hasNext(); ) {
			BcBonusSettingMst exchange = (BcBonusSettingMst)iterator.next();
			Set stores = exchange.getBcExchangeStores();	//適用店點
			for(Iterator subIter = stores.iterator(); subIter.hasNext(); ) {
				BcExchangeStore store = (BcExchangeStore)subIter.next();
				//exchangeSkuMap.put(store.getChannelId()+_SPLIT_STR+store.getStoreId(), exchange.getBcExchangeSkus());
				if(!exchangeSkuMap.containsKey(store.getStoreId())) {
					Map exchangeMst = new HashMap();
					Set exchangeSkuSet = exchange.getBcExchangeSkus();
					//依據兌換ID放置兌換設定Detail
					exchangeMst.put(exchange.getPromotId(), exchangeSkuSet);
					//按店點存放該店之所有紅利兌換商品設定
					exchangeSkuMap.put(store.getStoreId(), exchangeMst);
				} else {
					Map exchangeMstMap = (Map)exchangeSkuMap.get(store.getStoreId());
					Set exchangeSkuSet = exchange.getBcExchangeSkus();
					exchangeMstMap.put(exchange.getPromotId(), exchangeSkuSet);
				}
				
			}
		}
		return exchangeSkuMap;
	}
	
	/** 紅利折抵現金
	 * @param exchangeCashList
	 * @return
	 */
	@SuppressWarnings("all")
	public static Map getExchangeCash(List exchangeCashList) {
		Map exchangeCashMap = new HashMap();
		for(Iterator iterator = exchangeCashList.iterator(); iterator.hasNext(); ) {
			BcBonusSettingMst exchange = (BcBonusSettingMst)iterator.next();
			Set stores = exchange.getBcExchangeStores();	//適用店點
			for(Iterator subIter = stores.iterator(); subIter.hasNext(); ) {
				BcExchangeStore store = (BcExchangeStore)subIter.next();
				if(!exchangeCashMap.containsKey(store.getStoreId())) {
					Map exchangeMst = new HashMap();
					Set exchangeCashSet = exchange.getBcExchangeCashs();
					exchangeMst.put(exchange.getPromotId(), exchangeCashSet);
					exchangeCashMap.put(store.getStoreId(), exchangeMst);
				} else {
					Map exchangeMstMap = (Map)exchangeCashMap.get(store.getStoreId());
					Set exchangeCashSet = exchange.getBcExchangeCashs();
					exchangeMstMap.put(exchange.getPromotId(), exchangeCashSet);
				}
				
			}
		}
		return exchangeCashMap;
	}
	
	/** 取得限制商品金額累積
	 * @param bonusGuiSkuAmtList
	 * @return
	 */
	@SuppressWarnings("all")
	public static Map getBonusGuiSkuAmt(List bonusGuiSkuAmtList) {
		Map bonusMap = new HashMap();
		for(Iterator iterator = bonusGuiSkuAmtList.iterator(); iterator.hasNext(); ) {
			BcBonusSettingMst cuml = (BcBonusSettingMst)iterator.next();
			Set stores = cuml.getBcExchangeStores();	//限制商品金額累積適用店點
			for(Iterator subIter = stores.iterator(); subIter.hasNext(); ) {
				BcExchangeStore store = (BcExchangeStore)subIter.next();
				if(!bonusMap.containsKey(store.getStoreId())) {
					Set cumlSet = new HashSet();
					cumlSet.add(cuml);
					bonusMap.put(store.getStoreId(), cumlSet);
				} else {
					Set cumlSet = (Set)bonusMap.get(store.getStoreId());
					cumlSet.add(cuml);
				}
			}
		}
		return bonusMap;
	}
	
}
