package com.gccs.bonus.util;

public class BonusExceptionGlossary {
	public static final int _exception_type_non_member = 1;
	public static final int _exception_type_member_disabled = 10;
	public static final int _exception_type_member_exception = 12;
	public static final int _exception_type_member_cancel = 19;
	public static final int _exception_type_non_card = 2;
	public static final int _exception_type_non_account = 4;
	public static final int _exception_type_account_disabled = 40;
	public static final int _exception_type_account_petition = 41;
	public static final int _exception_type_account_examine = 42;
	public static final int _exception_type_account_cancel = 49;
	public static final int _excetpion_type_hibernate_error = 5;
	public static final int _excetpion_type_transfer_error = 9;
	public static final int _exception_type_non_transfer_date = 98;
	public static final int _exception_type_non_cache = 99;
	
	private static final String _exception_type_non_member_desc = "發票查無會員";
	private static final String _exception_type_member_disabled_desc = "會員停用";
	private static final String _exception_type_member_exception_desc = "會員異常";
	private static final String _exception_type_member_cancel_desc = "會員刪除";
	private static final String _exception_type_non_card_desc = "發票查無會員卡號/商務帳號";
	private static final String _excetpion_type_hibernate_error_desc = "儲存程序失敗";
	private static final String _excetpion_type_transfer_error_desc = "交易資訊程序失敗";
	private static final String _exception_type_non_transfer_date_desc = "無法取得轉換紅利日期";
	private static final String _exception_type_non_cache_desc = "紅利設定讀取失敗";
	private static final String _exception_type_non_account_desc = "發票查無商務會員";
	private static final String _exception_type_account_disabled_desc = "商務帳號申請中";
	private static final String _exception_type_account_petition_desc = "商務帳號申請中";
	private static final String _exception_type_account_examine_desc = "商務帳號審核中";
	private static final String _exception_type_account_cancel_desc = "商務帳號刪除";
	
	public static String getExceptionDesc(int type) {
		switch(type) {
			case _exception_type_non_member : {
				return _exception_type_non_member_desc;
			}
			case _exception_type_member_disabled : {
				return _exception_type_member_disabled_desc;
			}
			case _exception_type_member_exception : {
				return _exception_type_member_exception_desc;
			}
			case _exception_type_member_cancel : {
				return _exception_type_member_cancel_desc;
			}
			case _exception_type_non_card : {
				return _exception_type_non_card_desc;
			}
			case _excetpion_type_hibernate_error : {
				return _excetpion_type_hibernate_error_desc;
			}
			case _excetpion_type_transfer_error : {
				return _excetpion_type_transfer_error_desc;
			}
			case _exception_type_non_cache : {
				return _exception_type_non_cache_desc;
			}
			case _exception_type_non_transfer_date : {
				return _exception_type_non_transfer_date_desc;
			}
			case _exception_type_non_account : {
				return _exception_type_non_account_desc;
			}
			case _exception_type_account_disabled : {
				return _exception_type_account_disabled_desc;
			}
			case _exception_type_account_petition : {
				return _exception_type_account_petition_desc;
			}
			case _exception_type_account_examine : {
				return _exception_type_account_examine_desc;
			}
			case _exception_type_account_cancel : {
				return _exception_type_account_cancel_desc;
			}
		}
		return "";
	}
}
