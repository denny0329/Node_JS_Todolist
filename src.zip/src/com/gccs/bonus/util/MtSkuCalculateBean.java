package com.gccs.bonus.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.bnq.util.sale.model.SaleDetail;
import com.bnq.util.sale.model.SaleMaster;

public class MtSkuCalculateBean implements Serializable {
	private static final long serialVersionUID = -3993275830645066142L;

	private SaleMaster master;
	private List normalSkuList = new ArrayList();
	private List rejectionSkuList = new ArrayList();
	public SaleMaster getMaster() {
		return master;
	}
	public void setMaster(SaleMaster master) {
		this.master = master;
	}
	private List getNormalSkuList() {
		return normalSkuList;
	}
	private void setNormalSkuList(List normalSkuList) {
		this.normalSkuList = normalSkuList;
	}
	private List getRejectionSkuList() {
		return rejectionSkuList;
	}
	private void setRejectionSkuList(List rejectionSkuList) {
		this.rejectionSkuList = rejectionSkuList;
	}
	
	public void addNormalDetail(List saleDetailList) {
		if(saleDetailList!=null) {
			for(Iterator iterator = saleDetailList.iterator(); iterator.hasNext(); ) {
				SaleDetail detail = (SaleDetail)iterator.next();
				SaleDetail newDetail = this.copyDetail(detail);
				this.getNormalSkuList().add(newDetail);
			}
		}
	}
	
	public void addRejectionDetail(List saleDetailList) {
		if(saleDetailList!=null) {
			for(Iterator iterator = saleDetailList.iterator(); iterator.hasNext(); ) {
				SaleDetail detail = (SaleDetail)iterator.next();
				SaleDetail newDetail = this.copyDetail(detail);
				this.getRejectionSkuList().add(newDetail);
			}
		}
	}
	
	public boolean checkSkuRejectionCompletion() {
		boolean result = false;
		for(Iterator normalIter = this.getNormalSkuList().iterator(); normalIter.hasNext(); ) {
			SaleDetail normal = (SaleDetail)normalIter.next();
			for(Iterator rejectionIter = this.getRejectionSkuList().iterator(); rejectionIter.hasNext(); ) {
				SaleDetail rejection = (SaleDetail)rejectionIter.next();
				if(this.checkSkuInfo(normal, rejection))
					normalIter.remove();
			}
		}
		if(this.getNormalSkuList().isEmpty())
			result = true;
		return result;
	}
	
	private boolean checkSkuInfo(SaleDetail normal, SaleDetail rejection) {
		//if(normal.getStore_no().equals(rejection.getStore_no())
		//		&&normal.getTrans_dat().equals(rejection.getTrans_dat())
		//		&&normal.getPos_nos().equals(rejection.getPos_nos())
		//		&&normal.getSer_nos().equals(rejection.getSer_nos())
		//		&&normal.getItem_ser().equals(rejection.getItem_ser()))
		if(normal.getItem_ser().equals(rejection.getItem_ser()))
			return true;
		else
			return false;
	}
	
	private SaleDetail copyDetail(SaleDetail old){
		SaleDetail newDetail = new SaleDetail();
		newDetail.setStore_no(old.getStore_no());
		newDetail.setTrans_dat(old.getTrans_dat());
		newDetail.setPos_nos(old.getPos_nos());
		newDetail.setSer_nos(old.getSer_nos());
		newDetail.setItem_ser(old.getItem_ser());
		
		return newDetail;
	}
}
