package com.gccs.bonus.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * 流水號產生器
 * (ex : 20110101000001)
 * @deprecated
 */
public class SerialNoGenerator {

	private static int serialNum;
	private static Date date;
	
	private Lock lock = new ReentrantLock();
	
	private final String DATE_FORMAT = "yyyyMMdd";
	
	/**
	 * 產生流水號
	 * @return
	 */
	public String getSerailNo() {
		
		lock.lock();
		StringBuffer sb = new StringBuffer();
		try {
			Date now = new Date();
			String nowDateString = this.getDateFormatString(now, DATE_FORMAT);
			
			if(date == null || !nowDateString.equals(this.getDateFormatString(date, DATE_FORMAT))) {
				this.clearNum();
				date = now;
			} 	
			
			sb.append(nowDateString);
			
			String serialno = new Integer(++serialNum).toString();
			for(int x = 0; x < (6 - serialno.length()); x++) {
				sb.append("0");
			}
			sb.append(serialno);
			
		} finally {
			lock.unlock();
		}
		
		return sb.toString();
	}
	
	/**
	 * 產生日期字串
	 * @param date
	 * @param pattern
	 * @return
	 */
	private String getDateFormatString(Date date, String pattern) {
		return new SimpleDateFormat(pattern).format(date);
	}
	
	/**
	 * 歸零流水號
	 */
	private void clearNum() {
		serialNum = 0;
	}
}