package com.gccs.bonus.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

/**
 * 紅利點數計算使用日期處理工具類別
 */
public class BonusDateUtility {

	private static final Logger log = LogManager.getLogger(BonusDateUtility.class);
	
	/**
	 * 日期物件轉成日期字串
	 * 
	 * @param date 日期物件
	 * @param pattern 日期格式
	 * @return
	 */
	public static String getStringFromDate(Date date, String pattern) {
		return new SimpleDateFormat(pattern).format(date);
	}
	
	/**
	 * 日期字串轉成日期物件
	 * 
	 * @param dateString 日期字串
	 * @param pattern 日期格式
	 * @return
	 */
	public static Date getDateFromString(String dateString, String pattern) {
		
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		Date date = null;
		try {
			date = sdf.parse(dateString);
		} catch (ParseException e) {
			e.printStackTrace();
			log.error("日期字串轉物件失敗.dateString=" 
					+ dateString + ",pattern=" + pattern + ". " + e.getMessage(), e);
		}
		return date;
	}
	
	/**
	 * 取回每個月1號
	 * @param cal
	 * @param pattern 日期格式
	 * @return
	 */
	public static String getFirstDayOfMonth(Calendar cal, String pattern) {
		
		Calendar calclone = (Calendar)cal.clone();
		calclone.setTime(cal.getTime());
		calclone.set(Calendar.DATE, cal.getActualMinimum(Calendar.DATE));
		calclone.set(Calendar.HOUR, 0);
		calclone.set(Calendar.MINUTE, 0);
		calclone.set(Calendar.SECOND, 0);
		
		return getStringFromDate(calclone.getTime(), pattern);
	}
	
	/**
	 * 取回每個月最後1天日期
	 * @param cal
	 * @param pattern 日期格式
	 * @return
	 */
	public static String getLastDayOfMonth(Calendar cal, String pattern) {
		
		Calendar calclone = (Calendar)cal.clone();
		calclone.setTime(cal.getTime());
		calclone.set(Calendar.DATE, cal.getActualMaximum(Calendar.DATE));
		calclone.set(Calendar.HOUR, 23);
		calclone.set(Calendar.MINUTE, 59);
		calclone.set(Calendar.SECOND, 59);
		
		return getStringFromDate(calclone.getTime(), pattern);
	}
}
