package com.gccs.bonus.util;

public class BonusGlossary { 
	public static final String _sale_type_normal = "N";
	public static final String _sale_type_rejection = "B";
	public static final String _sale_type_rejection_cancel = "VB";
	public static final String _sale_type_normal_cancel = "VN";
	
	public static final int _account_vo_type_account = 1;	//集團卡
	public static final int _account_vo_type_member = 2;	//其他個人卡

	public static final String _sale_sta_normal = "N";
	//public static final String _sale_sta_cancel1 = "C";
	//public static final String _sale_sta_cancel2 = "V";
	public static final String _sale_sta_return = "B";
	
	public static final String _sale_master_key = "sale_master";
	public static final String _sale_master_trans_total_key = "gui_amount_key";
	
	public static final String _cuml_master_object_key = "_cuml_master_object_key";
	public static final String _cuml_store_key = "_cuml_store_key";
	
	public static final String _cache_gui_sku_bonus = "_cache_gui_sku_bonus";
	public static final String _cache_gui_amt_bonus = "_cache_gui_amt_bonus";
	
	public static final int _log_restore = 999;	//紅利還原
	
	public static final int _disbonus = 1999;	//紅利失效
	public static final String _disbonus_market_id = "BSC201007054";	//紅利失效活動代號
	
	public static final int _bonus_add_status_single_exchange = 1;						//通用單筆消費紅利
	public static final int _bonus_add_status_single_exchange_cancel = 12;				//通用單筆消費紅利作廢
	public static final int _bonus_add_status_single_exchange_rejection = 18;			//通用單筆消費紅利扣回
	public static final int _bonus_add_status_single_exchange_rejection_cancel = 19;	//通用單筆消費紅利扣回作廢
	
	public static final int _bonus_add_status_additional_amt = 2;						//通用累積金額紅利
	public static final int _bonus_add_status_additional_amt_cancel = 22;				//通用累積金額紅利作廢
	public static final int _bonus_add_status_additional_amt_rejection = 28;			//通用累積金額紅利扣回
	public static final int _bonus_add_status_additional_amt_rejection_temp = 27;		//通用累積金額紅利扣回暫行回補
	public static final int _bonus_add_status_additional_amt_rejection_cancel = 29;		//通用累積金額紅利扣回作廢
	
	public static final int _bonus_add_status_sku_no = 3;						//通用累積商品紅利(商品編號)
	public static final int _bonus_add_status_sku_no_cancel = 32;				//通用累積商品紅利作廢(商品編號)
	public static final int _bonus_add_status_sku_no_rejection = 38;			//通用累積商品紅利扣回(商品編號)
	public static final int _bonus_add_status_sku_no_rejection_cancel = 39;		//通用累積商品紅利扣回作廢(商品編號)
	
	public static final int _bonus_add_status_sku_type = 4;						//通用累積商品紅利(商品分類)
	public static final int _bonus_add_status_sku_type_cancel = 42;				//通用累積商品紅利作廢(商品分類)
	public static final int _bonus_add_status_sku_type_rejection = 48;			//通用累積商品紅利扣回(商品分類)
	public static final int _bonus_add_status_sku_type_rejection_cancel = 49;	//通用累積商品紅利扣回作廢(商品分類)
	
	public static final int _bonus_add_status_vendor_no = 5;					//通用累積商品紅利(廠商編號)
	public static final int _bonus_add_status_vendor_no_cancel = 52;			//通用累積商品紅利作廢(廠商編號)
	public static final int _bonus_add_status_vendor_no_rejection = 58;			//通用累積商品紅利扣回(廠商編號)
	public static final int _bonus_add_status_vendor_no_rejection_cancel = 59;	//通用累積商品紅利扣回作廢(廠商編號)
	
	public static final int _bonus_add_status_gui_sku_amt = 55;							//限制商品累積金額紅利
	public static final int _bonus_add_status_gui_sku_amt_cancel = 552;					//限制商品累積金額紅利作廢
	public static final int _bonus_add_status_gui_sku_amt_rejection_del = 557;			//限制商品累積金額紅利扣回(扣除)
	public static final int _bonus_add_status_gui_sku_amt_rejection_add = 558;			//限制商品累積金額紅利扣回(回補)
	public static final int _bonus_add_status_gui_sku_amt_rejection_cancel_del = 559;	//限制商品累積金額紅利扣回作廢(扣除)
	public static final int _bonus_add_status_gui_sku_amt_rejection_cancel_add = 550;	//限制商品累積金額紅利扣回作廢(回補)
	
	public static final int _bonus_del_status_exchange_sku = 6;				//紅利兌換商品
	public static final int _bonus_del_status_exchange_sku_cancel = 62;		//紅利兌換商品作廢
	
	public static final int _bonus_del_status_exchange_cash = 7;			//紅利折抵現金
	public static final int _bonus_del_status_exchange_cash_cancel = 72;	//紅利折抵現金作廢
	
	public static final int _bonus_add_status_birthday_grant = 8;					//生日加倍
	public static final int _bonus_add_status_birthday_grant_cancel = 82;			//生日加倍作廢
	public static final int _bonus_add_status_birthday_grant_rejection_del = 87;	//生日加倍退貨(扣除)
	public static final int _bonus_add_status_birthday_grant_rejection_add = 88;	//生日加倍退貨(回補)
	public static final int _bonus_add_status_birthday_grant_rejection_cancel_del = 89;	//生日加倍退貨做廢(扣除)
	public static final int _bonus_add_status_birthday_grant_rejection_cancel_add = 80;	//生日加倍退貨做廢(回補)
	
	public static final int _bonus_add_status_special_vip = 9;						//特惠帳戶紅利加倍
	public static final int _bonus_add_status_special_vip_cancel = 92;				//特惠帳戶紅利加倍作廢
	public static final int _bonus_add_status_special_vip_rejection = 98;			//特惠帳戶紅利加倍扣回
	public static final int _bonus_add_status_special_vip_rejection_cancel = 99;	//特惠帳戶紅利加倍扣回作廢
	
	public static final int _bonus_mt_group_add = 109;					//群組紅利
	public static final int _bonus_mt_group_cancel = 1092;				//群組紅利做廢
	public static final int _bonus_mt_group_rejection = 1098;			//群組紅利退貨
	public static final int _bonus_mt_group_rejection_cancel = 1099;	//群組紅利退貨作廢
	
	public static final int _bonus_mt_group_cuml_amt = 102;						//群組發票固定紅利
	public static final int _bonus_mt_group_cuml_amt_cancel = 1022;				//群組發票固定紅利做廢
	public static final int _bonus_mt_group_cuml_amt_rejection = 1028;			//群組發票固定紅利退貨
	public static final int _bonus_mt_group_cuml_amt_rejection_cancel = 1029;	//群組發票固定紅利退貨作廢
	
	public static final int _bonus_mt_group_cuml_percent_amt = 103;						//群組發票倍率紅利
	public static final int _bonus_mt_group_cuml_percent_amt_cancel = 1032;				//群組發票倍率紅利做廢
	public static final int _bonus_mt_group_cuml_percent_amt_rejection = 1038;			//群組發票倍率紅利退貨
	public static final int _bonus_mt_group_cuml_percent_amt_rejection_cancel = 1039;	//群組發票倍率紅利退貨作廢
	
	public static final int _bonus_mt_group_birth_amt = 104;					//群組(生日)發票固定紅利
	public static final int _bonus_mt_group_birth_amt_cancel = 1042;			//群組(生日)發票固定紅利作廢
	public static final int _bonus_mt_group_birth_amt_rejection = 1048;			//群組(生日)發票固定紅利退貨
	public static final int _bonus_mt_group_birth_amt_rejection_cancel = 1049;	//群組(生日)發票固定紅利退貨作廢
	
	public static final int _bonus_mt_group_birth_percent = 105;					//群組(生日)發票倍率紅利
	public static final int _bonus_mt_group_birth_percent_cancel = 1052;			//群組(生日)發票倍率紅利作廢
	public static final int _bonus_mt_group_birth_percent_rejection = 1058;			//群組(生日)發票倍率紅利退貨
	public static final int _bonus_mt_group_birth_percent_rejection_cancel = 1059;	//群組(生日)發票倍率紅利退貨作廢
	
	private static final String _log_restore_desc = "紅利還原";
	private static final String _disbonus_desc = "十二個月未消費紅利點數失效";
	
	private static final String _bonus_add_status_single_exchange_desc = "通用累積單筆消費紅利";
	private static final String _bonus_add_status_single_exchange_cancel_desc = "通用累積單筆消費紅利作廢";
	private static final String _bonus_add_status_single_exchange_rejection_desc = "通用累積單筆消費紅利退貨扣回";
	private static final String _bonus_add_status_single_exchange_rejection_cancel_desc = "紅利回補：通用累積單筆消費紅利退貨扣回作廢";
	
	private static final String _bonus_add_status_sku_no_desc = "通用累積商品紅利(商品編號)";
	private static final String _bonus_add_status_sku_no_cancel_desc = "通用累積商品紅利作廢(商品編號)";
	private static final String _bonus_add_status_sku_no_rejection_desc = "通用累積商品紅利退貨扣回(商品編號)";
	private static final String _bonus_add_status_sku_no_rejection_cancel_desc = "紅利回補：通用累積商品紅利退貨扣回作廢(商品編號)";
	
	
	private static final String _bonus_add_status_sku_type_desc = "通用累積商品紅利(商品分類)";
	private static final String _bonus_add_status_sku_type_cancel_desc = "通用累積商品紅利作廢(商品分類)";
	private static final String _bonus_add_status_sku_type_rejection_desc = "通用累積商品紅利退貨扣回(商品分類)";
	private static final String _bonus_add_status_sku_type_rejection_cancel_desc = "紅利回補：通用累積商品紅利退貨扣回作廢(商品分類)";
	
	
	private static final String _bonus_add_status_vendor_no_desc = "通用累積商品紅利(廠商編號)";
	private static final String _bonus_add_status_vendor_no_cancel_desc = "通用累積商品紅利作廢(廠商編號)";
	private static final String _bonus_add_status_vendor_no_rejection_desc = "通用累積商品紅利退貨扣回(廠商編號)";
	private static final String _bonus_add_status_vendor_no_rejection_cancel_desc = "紅利回補：通用累積商品紅利退貨扣回作廢(廠商編號)";
	
	private static final String _bonus_del_status_exchange_sku_desc = "紅利兌換商品";
	private static final String _bonus_del_status_exchange_sku_cancel_desc = "紅利兌換商品作廢";
	
	private static final String _bonus_del_status_exchange_cash_desc = "紅利折抵現金";
	private static final String _bonus_del_status_exchange_cash_cancel_desc = "紅利折抵現金作廢";
	
	private static final String _bonus_add_status_special_vip_desc = "特惠帳戶紅利加倍";
	private static final String _bonus_add_status_special_vip_cancel_desc = "特惠帳戶紅利加倍作廢";
	private static final String _bonus_add_status_special_vip_rejection_desc = "特惠帳戶紅利加倍扣回";
	private static final String _bonus_add_status_special_vip_rejection_cancel_desc = "特惠帳戶紅利加倍扣回作廢";
	
	/**紅利失效使用的通路代碼*/
	public static final String BONUS_INVALID_CHANNEL_ID = "HQ";
	
	/**紅利失效使用的店端代碼*/
	public static final String BONUS_INAVLID_STORE_ID = "99";
	
	/**分隔號 - 逗號*/
	public final static String COMMA_SEPARATOR = ",";
	
    public final static String BONUS_REASON_HISU = "HISU商品";
	
	public final static String BONUS_REASON_HISU_WAGE = "HISU工資";
	
	/**交易類型 - 正常交易*/
	public static final String BONUS_TYPES_NORMAL = new StringBuffer()
				.append(_bonus_add_status_single_exchange).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_additional_amt).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_sku_no).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_sku_type).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_vendor_no).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_gui_sku_amt).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_birthday_grant).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_special_vip).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_cuml_amt).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_cuml_percent_amt).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_birth_amt).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_birth_percent).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_add)
				.toString();
	
	/**交易類型 - 退貨作廢*/
	public static final String BONUS_TYPES_REFUND_INVALID = new StringBuffer()
				.append(_bonus_add_status_single_exchange_rejection_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_additional_amt_rejection_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_sku_no_rejection_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_sku_type_rejection_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_vendor_no_rejection_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_special_vip_rejection_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_cuml_amt_rejection_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_cuml_percent_amt_rejection_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_birth_amt_rejection_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_birth_percent_rejection_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_rejection_cancel)
				.toString();
	
	/**交易類型 - 退貨交易*/
	public static final String BONUS_TYPES_REFUND_TRANSATION = new StringBuffer()
				.append(_bonus_add_status_single_exchange_rejection).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_additional_amt_rejection).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_sku_no_rejection).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_sku_type_rejection).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_vendor_no_rejection).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_special_vip_rejection).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_cuml_amt_rejection).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_cuml_percent_amt_rejection).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_birth_amt_rejection).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_birth_percent_rejection).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_rejection)
				.toString();
	
	/**交易類型 - 退貨扣除*/
	public static final String BONUS_TYPES_REFUND_DEDUCTION = new StringBuffer()
				.append(_bonus_add_status_birthday_grant_rejection_del).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_gui_sku_amt_rejection_del)
				.toString();
	
	/**交易類型 - 退貨回補*/
	public static final String BONUS_TYPES_REFUND_COVER = new StringBuffer()
				.append(_bonus_add_status_additional_amt_rejection_temp).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_birthday_grant_rejection_add).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_gui_sku_amt_rejection_add)
				.toString();
	
	/**交易類型 - 作廢交易*/
	public static final String BONUS_TYPES_INVALID_TRANSATION = new StringBuffer()
				.append(_bonus_add_status_single_exchange_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_additional_amt_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_sku_no_cancel).append(COMMA_SEPARATOR)
				.append(43).append(COMMA_SEPARATOR)
				.append(54).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_birthday_grant_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_special_vip_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_add_status_gui_sku_amt_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_cuml_amt_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_cuml_percent_amt_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_birth_amt_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_birth_percent_cancel).append(COMMA_SEPARATOR)
				.append(_bonus_mt_group_cancel)
				.toString();
	
	/**交易類型 - 客訴補點*/
	public static final String BONUS_TYPES_CUSTOMER_COMPLAIN_COVER = "1243";
				
	/**交易類型 - 客訴扣點*/
	public static final String BONUS_TYPES_CUSTOMER_COMPLAIN_DEDUCTION = "1244";
	
	/**交易類型 - EC活動給點*/
	public static final String BONUS_TYPES_EC_ACTIVITY_GIVEN = "1101";
	
	/**交易類型 - EC活動扣點*/
	public static final String BONUS_TYPES_EC_ACTIVITY_COVER = "1110";
	
	/**交易類型 - EC退貨給點*/
	public static final String BONUS_TYPES_EC_REFUND_GIVEN = "1118";
	
	/**交易類型 - EC客怨補點*/
	public static final String BONUS_TYPES_EC_CUSTOMER_COMPLAIN_COVER = "1143";
	
	/**交易類型 - EC購物紅利折抵現金*/
	public static final String BONUS_TYPES_EC_BONUS_MINS_CASH = "1107";
	
	/**交易類型 - EC購物紅利折抵現金作廢*/
	public static final String BONUS_TYPES_EC_BONUS_MINS_CASH_INVALID = "1172";
	
	public static String getBonusExchangeReason(int exchangeType) {
		switch(exchangeType) {
			case _bonus_add_status_single_exchange :
				return _bonus_add_status_single_exchange_desc;
			case _bonus_add_status_single_exchange_cancel :
				return _bonus_add_status_single_exchange_cancel_desc;
			case _bonus_add_status_single_exchange_rejection :
				return _bonus_add_status_single_exchange_rejection_desc;
			case _bonus_add_status_single_exchange_rejection_cancel :
				return _bonus_add_status_single_exchange_rejection_cancel_desc;
				
			case _bonus_add_status_sku_no :
				return _bonus_add_status_sku_no_desc;
			case _bonus_add_status_sku_no_cancel :
				return _bonus_add_status_sku_no_cancel_desc;
			case _bonus_add_status_sku_no_rejection :
				return _bonus_add_status_sku_no_rejection_desc;
			case _bonus_add_status_sku_no_rejection_cancel :
				return _bonus_add_status_sku_no_rejection_cancel_desc;
				
			case _bonus_add_status_sku_type :
				return _bonus_add_status_sku_type_desc;
			case _bonus_add_status_sku_type_cancel :
				return _bonus_add_status_sku_type_cancel_desc;
			case _bonus_add_status_sku_type_rejection :
				return _bonus_add_status_sku_type_rejection_desc;
			case _bonus_add_status_sku_type_rejection_cancel :
				return _bonus_add_status_sku_type_rejection_cancel_desc;
				
			case _bonus_add_status_vendor_no :
				return _bonus_add_status_vendor_no_desc;
			case _bonus_add_status_vendor_no_cancel :
				return _bonus_add_status_vendor_no_cancel_desc;
			case _bonus_add_status_vendor_no_rejection :
				return _bonus_add_status_vendor_no_rejection_desc;
			case _bonus_add_status_vendor_no_rejection_cancel :
				return _bonus_add_status_vendor_no_rejection_cancel_desc;
				
			case _bonus_del_status_exchange_sku :
				return _bonus_del_status_exchange_sku_desc;
			case _bonus_del_status_exchange_sku_cancel :
				return _bonus_del_status_exchange_sku_cancel_desc;
				
			case _bonus_del_status_exchange_cash :
				return _bonus_del_status_exchange_cash_desc;
			case _bonus_del_status_exchange_cash_cancel :
				return _bonus_del_status_exchange_cash_cancel_desc;
				
			case _bonus_add_status_special_vip :
				return _bonus_add_status_special_vip_desc;
			case _bonus_add_status_special_vip_cancel :
				return _bonus_add_status_special_vip_cancel_desc;
			case _bonus_add_status_special_vip_rejection :
				return _bonus_add_status_special_vip_rejection_desc;
			case _bonus_add_status_special_vip_rejection_cancel :
				return _bonus_add_status_special_vip_rejection_cancel_desc;
				
			case _log_restore :
				return _log_restore_desc;
				
			case _disbonus :
				return _disbonus_desc;
		}
		return null;
	}
}
