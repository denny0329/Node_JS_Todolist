package com.gccs.gf.dao;

import java.util.Map;

import com.bnq.util.PageBean;

public interface IGiftDao {
	/**
	 * 查詢贈品資料
	 * @param queryCondition
	 * @param inPageBean
	 * @return
	 * @throws Exception
	 */
	public PageBean findGiftByQueryCondition(Map queryCondition, PageBean inPageBean) throws Exception ;
	/**
	 * 查詢信用卡卡號
	 * @param queryCondition
	 * @param inPageBean
	 * @return
	 * @throws Exception
	 */
	public PageBean findCardNoByQueryCondition(Map queryCondition,String codeClass, PageBean inPageBean) throws Exception;

	public long getTotalAllotAmtByStore(String giftId, String channelId, String storeId);
}
