package com.gccs.gf.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;

/**
 * GfGift entity. @author MyEclipse Persistence Tools
 */

public class GfGift extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = -1227124152188705273L;

	private String oid;
	private String giftId;
	private String giftName;
	private String vendorId;
	private Date storeDate;
	private BigDecimal giftAmt;
	private String note;
	private Date createTime;
	private String creator;
	private String creatorName;
	private String modifier;
	private String modifierName;
	private Date modifyTime;

	private Set<GfGiftAllot> allots;
	private String vendorName;
	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	private Integer allotAmt;
	private Integer exchangedAmt;

	public Integer getExchangedAmt() {
		return exchangedAmt;
	}

	public void setExchangedAmt(Integer exchangedAmt) {
		this.exchangedAmt = exchangedAmt;
	}

	public Integer getAllotAmt() {
		return allotAmt;
	}

	public void setAllotAmt(Integer allotAmt) {
		this.allotAmt = allotAmt;
	}

	public Set<GfGiftAllot> getAllots() {
		return allots;
	}

	public void setAllots(Set<GfGiftAllot> allots) {
		this.allots = allots;
	}

	/** default constructor */
	public GfGift() {
	}

	/** minimal constructor */
	public GfGift(String oid) {
		this.oid = oid;
	}

	/** full constructor */
	public GfGift(String oid, String giftId, String giftName, String vendorId,
			Date storeDate, BigDecimal giftAmt, String note, Date createTime,
			String creator, String creatorName, String modifier,
			String modifierName, Date modifyTime) {
		this.oid = oid;
		this.giftId = giftId;
		this.giftName = giftName;
		this.vendorId = vendorId;
		this.storeDate = storeDate;
		this.giftAmt = giftAmt;
		this.note = note;
		this.createTime = createTime;
		this.creator = creator;
		this.creatorName = creatorName;
		this.modifier = modifier;
		this.modifierName = modifierName;
		this.modifyTime = modifyTime;
	}

	// Property accessors

	public String getOid() {
		return this.oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public String getGiftId() {
		return this.giftId;
	}

	public void setGiftId(String giftId) {
		this.giftId = giftId;
	}

	public String getGiftName() {
		return this.giftName;
	}

	public void setGiftName(String giftName) {
		this.giftName = giftName;
	}

	public String getVendorId() {
		return this.vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public Date getStoreDate() {
		return this.storeDate;
	}

	public void setStoreDate(Date storeDate) {
		this.storeDate = storeDate;
	}

	public BigDecimal getGiftAmt() {
		return this.giftAmt;
	}

	public void setGiftAmt(BigDecimal giftAmt) {
		this.giftAmt = giftAmt;
	}

	public String getNote() {
		return this.note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreator() {
		return this.creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreatorName() {
		return this.creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public String getModifier() {
		return this.modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getModifierName() {
		return this.modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public Date getModifyTime() {
		return this.modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}
}