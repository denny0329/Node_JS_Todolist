package com.gccs.gf.model;

import java.math.BigDecimal;
import java.util.Date;

/**
 * GfGiftTransferLog entity. @author MyEclipse Persistence Tools
 */

public class GfGiftTransferLog  extends com.gccs.ws.model.BaseVo  {
	private static final long serialVersionUID = -5523918787655709587L;

	private String oid;
	private String giftOid;
	private String channelIdF;
	private String storeIdF;
	private String channelIdT;
	private String storeIdT;
	private BigDecimal origAmt;
	private BigDecimal transferAmt;
	private BigDecimal surplusAmt;
	private Date createTime;
	private String creator;
	private String creatorName;
	private String modifier;
	private String modifierName;
	private Date modifyTime;

	// Constructors

	/** default constructor */
	public GfGiftTransferLog() {
	}

	/** minimal constructor */
	public GfGiftTransferLog(String oid, String giftOid) {
		this.oid = oid;
		this.giftOid = giftOid;
	}

	/** full constructor */
	public GfGiftTransferLog(String oid, String giftOid, String channelIdF,
			String storeIdF, String channelIdT, String storeIdT,
			BigDecimal origAmt, BigDecimal transferAmt, BigDecimal surplusAmt,
			Date createTime, String creator, String creatorName,
			String modifier, String modifierName, Date modifyTime) {
		this.oid = oid;
		this.giftOid = giftOid;
		this.channelIdF = channelIdF;
		this.storeIdF = storeIdF;
		this.channelIdT = channelIdT;
		this.storeIdT = storeIdT;
		this.origAmt = origAmt;
		this.transferAmt = transferAmt;
		this.surplusAmt = surplusAmt;
		this.createTime = createTime;
		this.creator = creator;
		this.creatorName = creatorName;
		this.modifier = modifier;
		this.modifierName = modifierName;
		this.modifyTime = modifyTime;
	}

	// Property accessors

	public String getOid() {
		return this.oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public String getGiftOid() {
		return this.giftOid;
	}

	public void setGiftOid(String giftOid) {
		this.giftOid = giftOid;
	}

	public String getChannelIdF() {
		return this.channelIdF;
	}

	public void setChannelIdF(String channelIdF) {
		this.channelIdF = channelIdF;
	}

	public String getStoreIdF() {
		return this.storeIdF;
	}

	public void setStoreIdF(String storeIdF) {
		this.storeIdF = storeIdF;
	}

	public String getChannelIdT() {
		return this.channelIdT;
	}

	public void setChannelIdT(String channelIdT) {
		this.channelIdT = channelIdT;
	}

	public String getStoreIdT() {
		return this.storeIdT;
	}

	public void setStoreIdT(String storeIdT) {
		this.storeIdT = storeIdT;
	}

	public BigDecimal getOrigAmt() {
		return this.origAmt;
	}

	public void setOrigAmt(BigDecimal origAmt) {
		this.origAmt = origAmt;
	}

	public BigDecimal getTransferAmt() {
		return this.transferAmt;
	}

	public void setTransferAmt(BigDecimal transferAmt) {
		this.transferAmt = transferAmt;
	}

	public BigDecimal getSurplusAmt() {
		return this.surplusAmt;
	}

	public void setSurplusAmt(BigDecimal surplusAmt) {
		this.surplusAmt = surplusAmt;
	}

	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreator() {
		return this.creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreatorName() {
		return this.creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public String getModifier() {
		return this.modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getModifierName() {
		return this.modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public Date getModifyTime() {
		return this.modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

}