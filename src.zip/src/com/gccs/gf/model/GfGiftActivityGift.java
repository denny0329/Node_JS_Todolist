package com.gccs.gf.model;

import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * GfGiftActivityGift entity. @author MyEclipse Persistence Tools
 */

public class GfGiftActivityGift implements java.io.Serializable {
	private static final long serialVersionUID = -1430491515099633170L;

	private String oid;
	private String activityOid;
	private String giftOid;
	private String giftId;
	private String giftName;
	private Date createTime;
	private String creator;
	private String creatorName;
	private String modifier;
	private String modifierName;
	private Date modifyTime;

	// Constructors

	/** default constructor */
	public GfGiftActivityGift() {
	}

	/** minimal constructor */
	public GfGiftActivityGift(String oid) {
		this.oid = oid;
	}

	/** full constructor */
	public GfGiftActivityGift(String oid, String activityOid, String giftOid,
			String giftId, String giftName, Date createTime, String creator,
			String creatorName, String modifier, String modifierName,
			Date modifyTime) {
		this.oid = oid;
		this.activityOid = activityOid;
		this.giftOid = giftOid;
		this.giftId = giftId;
		this.giftName = giftName;
		this.createTime = createTime;
		this.creator = creator;
		this.creatorName = creatorName;
		this.modifier = modifier;
		this.modifierName = modifierName;
		this.modifyTime = modifyTime;
	}

	// Property accessors

	public String getOid() {
		return this.oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public String getActivityOid() {
		return this.activityOid;
	}

	public void setActivityOid(String activityOid) {
		this.activityOid = activityOid;
	}

	public String getGiftOid() {
		return this.giftOid;
	}

	public void setGiftOid(String giftOid) {
		this.giftOid = giftOid;
	}

	public String getGiftId() {
		return this.giftId;
	}

	public void setGiftId(String giftId) {
		this.giftId = giftId;
	}

	public String getGiftName() {
		return this.giftName;
	}

	public void setGiftName(String giftName) {
		this.giftName = giftName;
	}

	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreator() {
		return this.creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreatorName() {
		return this.creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public String getModifier() {
		return this.modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getModifierName() {
		return this.modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public Date getModifyTime() {
		return this.modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
}