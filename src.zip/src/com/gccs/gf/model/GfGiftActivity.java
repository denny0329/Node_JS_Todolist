package com.gccs.gf.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.gccs.cg.model.GrantConfig;

/**
 * GfGiftActivity entity. @author MyEclipse Persistence Tools
 */

public class GfGiftActivity extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = 4154543906055948358L;

	private static final Logger log = LogManager.getLogger(GfGiftActivity.class) ;
	// Fields

	private String oid;
	private String activityId;
	private String activityName;
	private Integer status;
	private String channelId;

	private Date createTime;
	private String creator;
	private String creatorName;
	private String modifier;
	private String modifierName;
	private Date modifyTime;

	private String approver;
	private String approverName;
	private Date approveTime;

	private GrantConfig utGrantConfig;

	private Set<GfGiftActivityGift> gifts;
	private Set<GfGiftActivityCardno> cardNos;

	private String findListType;

	public String getFindListType() {
		return findListType;
	}


	public void setFindListType(String findListType) {
		this.findListType = findListType;
	}

	private final int OBJECT_STATUS_INSERT = 0;
	private final int OBJECT_STATUS_UPDATE = 1;


	// Constructors


	public GrantConfig getUtGrantConfig() {
		return utGrantConfig;
	}


	public void setUtGrantConfig(GrantConfig utGrantConfig) {
		this.utGrantConfig = utGrantConfig;
	}




	public Set<GfGiftActivityCardno> getCardNos() {
		return cardNos;
	}


	public void setCardNos(Set<GfGiftActivityCardno> cardNos) {
		this.cardNos = cardNos;
	}

	public Set<GfGiftActivityGift> getGifts() {
		return gifts;
	}


	public void setGifts(Set<GfGiftActivityGift> gifts) {
		this.gifts = gifts;
	}

	/** default constructor */
	public GfGiftActivity() {
	}


	/** minimal constructor */
	public GfGiftActivity(String oid) {
		this.oid = oid;
	}

	/** full constructor */
	public GfGiftActivity(String oid, String activityId, String activityName,
			Integer status, String channelId, BigDecimal skuAval,
			Date createTime, String creator, String creatorName,
			String modifier, String modifierName, Date modifyTime) {
		this.oid = oid;
		this.activityId = activityId;
		this.activityName = activityName;
		this.status = status;
		this.channelId = channelId;

		this.createTime = createTime;
		this.creator = creator;
		this.creatorName = creatorName;
		this.modifier = modifier;
		this.modifierName = modifierName;
		this.modifyTime = modifyTime;
	}

	// Property accessors

	public String getOid() {
		return this.oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public String getActivityId() {
		return this.activityId;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	public String getActivityName() {
		return this.activityName;
	}

	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	public Integer getStatus() {
		return this.status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getChannelId() {
		return this.channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}



	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreator() {
		return this.creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreatorName() {
		return this.creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public String getModifier() {
		return this.modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getModifierName() {
		return this.modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public Date getModifyTime() {
		return this.modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public String getApprover() {
		return approver;
	}


	public void setApprover(String approver) {
		this.approver = approver;
	}


	public String getApproverName() {
		return approverName;
	}


	public void setApproverName(String approverName) {
		this.approverName = approverName;
	}


	public Date getApproveTime() {
		return approveTime;
	}


	public void setApproveTime(Date approveTime) {
		this.approveTime = approveTime;
	}

	public static final Map statusMap;
	public static final Map grantSiteMap;
	static {
		statusMap = new LinkedHashMap<String,String>();
		statusMap.put("0", "建立");
		statusMap.put("1", "審核");
		statusMap.put("2", "生效");
		statusMap.put("3", "失效");

		grantSiteMap = new LinkedHashMap<String,String>();
		grantSiteMap.put("0","POS");
		grantSiteMap.put("1","服務台");
	}


	public static String getStatusTxt(String status) {
		return (String)statusMap.get(status);
	}
	public String getStatusTxt() {
		return (this.status!=null ? (String)statusMap.get(status.toString()) : "");
	}
}