package com.gccs.gf.model;

import java.util.Comparator;

public class GiftActivityGiftComp implements Comparator<GfGiftActivityGift>{

	public int compare(GfGiftActivityGift o1, GfGiftActivityGift o2) {
	    return o1.getGiftId().compareTo(o2.getGiftId());
	}

}
