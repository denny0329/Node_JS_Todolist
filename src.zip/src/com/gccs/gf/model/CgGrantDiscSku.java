package com.gccs.gf.model;

import java.util.Date;

/**
 * CgGrantDiscSku entity. @author MyEclipse Persistence Tools
 */

public class CgGrantDiscSku implements java.io.Serializable {
	private static final long serialVersionUID = -381674055973868933L;

	private String oid;
	private String configOid;
	private String sku;
	private String skuName;
	private String vendorId;
	private String vendorName;
	private String dept;
	private String subDept;
	private String class_;
	private String subClass;
	private String className;
	private Date createTime;
	private String creator;
	private String creatorName;
	private String modifier;
	private String modifierName;
	private Date modifyTime;

	// Constructors

	/** default constructor */
	public CgGrantDiscSku() {
	}

	/** minimal constructor */
	public CgGrantDiscSku(String oid) {
		this.oid = oid;
	}

	/** full constructor */
	public CgGrantDiscSku(String oid, String configOid, String sku,
			String skuName, String vendorId, String vendorName, String dept,
			String subDept, String class_, String subClass, String className,
			Date createTime, String creator, String creatorName,
			String modifier, String modifierName, Date modifyTime) {
		this.oid = oid;
		this.configOid = configOid;
		this.sku = sku;
		this.skuName = skuName;
		this.vendorId = vendorId;
		this.vendorName = vendorName;
		this.dept = dept;
		this.subDept = subDept;
		this.class_ = class_;
		this.subClass = subClass;
		this.className = className;
		this.createTime = createTime;
		this.creator = creator;
		this.creatorName = creatorName;
		this.modifier = modifier;
		this.modifierName = modifierName;
		this.modifyTime = modifyTime;
	}

	// Property accessors

	public String getOid() {
		return this.oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public String getConfigOid() {
		return this.configOid;
	}

	public void setConfigOid(String configOid) {
		this.configOid = configOid;
	}

	public String getSku() {
		return this.sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getSkuName() {
		return this.skuName;
	}

	public void setSkuName(String skuName) {
		this.skuName = skuName;
	}

	public String getVendorId() {
		return this.vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return this.vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getDept() {
		return this.dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getSubDept() {
		return this.subDept;
	}

	public void setSubDept(String subDept) {
		this.subDept = subDept;
	}

	public String getClass_() {
		return this.class_;
	}

	public void setClass_(String class_) {
		this.class_ = class_;
	}

	public String getSubClass() {
		return this.subClass;
	}

	public void setSubClass(String subClass) {
		this.subClass = subClass;
	}

	public String getClassName() {
		return this.className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreator() {
		return this.creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreatorName() {
		return this.creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public String getModifier() {
		return this.modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getModifierName() {
		return this.modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public Date getModifyTime() {
		return this.modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

}