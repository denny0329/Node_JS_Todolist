package com.gccs.gf.model;

import java.util.Date;

/**
 * GfGiftActivityCardno entity. @author MyEclipse Persistence Tools
 */

public class GfGiftActivityCardno extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = 6050304355920829452L;

	private String oid;
	private String activityOid;
	private String cardClass;
	private String cardNo;
	private String note;
	private Date createTime;
	private String creator;
	private String creatorName;
	private String modifier;
	private String modifierName;
	private Date modifyTime;

	// Constructors

	/** default constructor */
	public GfGiftActivityCardno() {
	}

	/** minimal constructor */
	public GfGiftActivityCardno(String oid) {
		this.oid = oid;
	}

	/** full constructor */
	public GfGiftActivityCardno(String oid,String activityOid,
			String cardClass, String cardNo, String note, Date createTime,
			String creator, String creatorName, String modifier,
			String modifierName, Date modifyTime) {
		this.oid = oid;
		this.activityOid = activityOid;
		this.cardClass = cardClass;
		this.cardNo = cardNo;
		this.note = note;
		this.createTime = createTime;
		this.creator = creator;
		this.creatorName = creatorName;
		this.modifier = modifier;
		this.modifierName = modifierName;
		this.modifyTime = modifyTime;
	}

	// Property accessors

	public String getOid() {
		return this.oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public String getActivityOid() {
		return this.activityOid;
	}

	public void setActivityOid(String activityOid) {
		this.activityOid = activityOid;
	}

	public String getCardClass() {
		return this.cardClass;
	}

	public void setCardClass(String cardClass) {
		this.cardClass = cardClass;
	}

	public String getCardNo() {
		return this.cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getNote() {
		return this.note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreator() {
		return this.creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreatorName() {
		return this.creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public String getModifier() {
		return this.modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getModifierName() {
		return this.modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public Date getModifyTime() {
		return this.modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

}