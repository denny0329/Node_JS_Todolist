package com.gccs.gf.model;

import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.bnq.util.AppContext;
import com.gccs.bs.model.BsStore;
import com.gccs.gf.sevice.GiftService;
import com.gccs.util.cache.BsChannelDefinition;
import com.gccs.util.cache.BsStoreDefinition;

/**
 * GfGiftAllot entity. @author MyEclipse Persistence Tools
 */

public class GfGiftAllot extends com.gccs.ws.model.BaseVo {
	private static final long serialVersionUID = 1394191092812099619L;

	private String oid;
	private String giftOid;
	private String channelId;
	private String storeId;
	private Integer allotAmt;
	private Date createTime;
	private String creator;
	private String creatorName;
	private String modifier;
	private String modifierName;
	private Date modifyTime;

	private long totalAmtIn;
	private long totalAmtOut;
	private long exchangedAmt;
	private long totalAllotAmtByStore;
	private long avlTransferAmt;

	public long getAvlTransferAmt() {
		return avlTransferAmt;
	}

	public void setAvlTransferAmt(long avlTransferAmt) {
		this.avlTransferAmt = avlTransferAmt;
	}

	public long getTotalAllotAmtByStore() {
		return totalAllotAmtByStore;
	}

	public void setTotalAllotAmtByStore(long totalAllotAmtByStore) {
		this.totalAllotAmtByStore = totalAllotAmtByStore;
	}

	public long getExchangedAmt() {
		return exchangedAmt;
	}

	public void setExchangedAmt(long exchangedAmt) {
		this.exchangedAmt = exchangedAmt;
	}

	public long getTotalAmtIn() {
		return totalAmtIn;
	}

	public void setTotalAmtIn(long totalAmtIn) {
		this.totalAmtIn = totalAmtIn;
	}

	public long getTotalAmtOut() {
		return totalAmtOut;
	}

	public void setTotalAmtOut(long totalAmtOut) {
		this.totalAmtOut = totalAmtOut;
	}

	public String getChannelName() {
		if(StringUtils.isNotBlank(channelId)) {
			return BsChannelDefinition.getChannelName1(this.getChannelId());
	    } else {
	    	return null;
	    }
	}

	public String getStoreName() {
		String rtv = null;

		if(StringUtils.isNotBlank(storeId)) {
			BsStore bsStore = BsStoreDefinition.getBsStoreByStoreNo(storeId);
			if(bsStore != null)
				rtv = bsStore.getStoreName2();
		}
		return rtv;
	}

	/** default constructor */
	public GfGiftAllot() {
	}

	/** minimal constructor */
	public GfGiftAllot(String oid) {
		this.oid = oid;
	}

	/** full constructor */
	public GfGiftAllot(String oid, String giftOid, String channelId,
			String storeId, Integer allotAmt, Date createTime,
			String creator, String creatorName, String modifier,
			String modifierName, Date modifyTime) {
		this.oid = oid;
		this.giftOid = giftOid;
		this.channelId = channelId;
		this.storeId = storeId;
		this.allotAmt = allotAmt;
		this.createTime = createTime;
		this.creator = creator;
		this.creatorName = creatorName;
		this.modifier = modifier;
		this.modifierName = modifierName;
		this.modifyTime = modifyTime;
	}

	// Property accessors

	public String getOid() {
		return this.oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public String getGiftOid() {
		return this.giftOid;
	}

	public void setGiftOid(String giftOid) {
		this.giftOid = giftOid;
	}

	public String getChannelId() {
		return this.channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getStoreId() {
		return this.storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public Integer getAllotAmt() {
		return this.allotAmt;
	}

	public void setAllotAmt(Integer allotAmt) {
		this.allotAmt = allotAmt;
	}

	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getCreator() {
		return this.creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreatorName() {
		return this.creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public String getModifier() {
		return this.modifier;
	}

	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	public String getModifierName() {
		return this.modifierName;
	}

	public void setModifierName(String modifierName) {
		this.modifierName = modifierName;
	}

	public Date getModifyTime() {
		return this.modifyTime;
	}

	public void setModifyTime(Date modifyTime) {
		this.modifyTime = modifyTime;
	}

	public GfGift getGfGift() {
		GfGift rtv = null;
		if(StringUtils.isNotBlank(giftOid)) {
			try {
				GiftService giftService = (GiftService)AppContext.getBean("gfService");
				rtv = giftService.findGiftByOid(giftOid);
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		return rtv;
	}

}