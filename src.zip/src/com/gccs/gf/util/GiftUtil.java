package com.gccs.gf.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.AppContext;
import com.bnq.util.StringId;
import com.gccs.gf.sevice.GiftService;
import com.gccs.gf.sevice.IGiftService;


public class GiftUtil {
	private static final Logger log = LogManager.getLogger(GiftUtil.class) ;

	public static final int _STATUS_CREATE = 0 ;
	public static final int _STATUS_APPROVE = 1 ;
	public static final int _STATUS_ACTIVATE = 2 ;
	public static final int _STATUS_PASSIVATE = 3 ;


	private static final String _STATUS_CREATE_DESC = "建立" ;
	private static final String _STATUS_APPROVE_DESC = "審核" ;
	private static final String _STATUS_ACTIVATE_DESC = "生效" ;
	private static final String _STATUS_PASSIVATE_DESC = "失效" ;

	public static final int WITHOUT_CREATE = 1;
	public static final int NO_RESTRICTION = 0;

	public static final int _GRANT_SITE_POS = 0;
	public static final int _GRANT_SITE_SERVICE_COUNTER = 1;

	public static final String _GRANT_SITE_POS_DESC = "POS";
	public static final String _GRANT_SITE_SERVICE_COUNTER_DESC = "服務台";

	@SuppressWarnings("unchecked")
	public static List<StringId> getStatusType() {
		List list = new ArrayList() ;
		list.add(new StringId(String.valueOf(_STATUS_CREATE),_STATUS_CREATE_DESC)) ;
		list.add(new StringId(String.valueOf(_STATUS_APPROVE),_STATUS_APPROVE_DESC)) ;
		list.add(new StringId(String.valueOf(_STATUS_ACTIVATE),_STATUS_ACTIVATE_DESC)) ;
		list.add(new StringId(String.valueOf(_STATUS_PASSIVATE),_STATUS_PASSIVATE_DESC)) ;
		return list ;
	}

	@SuppressWarnings("unchecked")
	public static List<StringId> getStatusTypeWithoutCreate() {
		List list = new ArrayList() ;
		list.add(new StringId(String.valueOf(_STATUS_APPROVE),_STATUS_APPROVE_DESC)) ;
		list.add(new StringId(String.valueOf(_STATUS_ACTIVATE),_STATUS_ACTIVATE_DESC)) ;
		list.add(new StringId(String.valueOf(_STATUS_PASSIVATE),_STATUS_PASSIVATE_DESC)) ;
		return list ;
	}

	public static List<StringId> getGrantSite(){
		List <StringId> list = new ArrayList<StringId>();
		list.add(new StringId(String.valueOf(_GRANT_SITE_POS),_GRANT_SITE_POS_DESC));
		list.add(new StringId(String.valueOf(_GRANT_SITE_SERVICE_COUNTER),_GRANT_SITE_SERVICE_COUNTER_DESC));
		return list;
	}

	private static String getStatusDesc(int status) {
		switch(status) {
			case _STATUS_CREATE : {
				return _STATUS_CREATE_DESC ;
			}
			case _STATUS_APPROVE : {
				return _STATUS_APPROVE_DESC ;
			}
			case _STATUS_ACTIVATE : {
				return _STATUS_ACTIVATE_DESC ;
			}
			case _STATUS_PASSIVATE : {
				return _STATUS_PASSIVATE_DESC ;
			}
			default : {
				return "unknown" ;
			}
		}
	}

	public static Map queryChannelMap(String activityOid) {
		GiftService service = (GiftService)AppContext.getBean("gfService");
		return service.queryChannelMap(activityOid);
	}

	public static long getTotalAllotAmtByStore(String giftId,String channelId, String storeId){
		long rtv = 0;

		if(StringUtils.isNotBlank(channelId) &&
				StringUtils.isNotBlank(storeId)) {
			IGiftService giftService = (IGiftService)AppContext.getBean("gfService");
			rtv = giftService.getTotalAllotAmtByStore(giftId, channelId, storeId);
		}
		return rtv;
	}
}
