package com.gccs.gf.sevice;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;
import com.bnq.sc.model.ScSysuser;
import com.bnq.util.PageBean;
import com.bnq.util.QueryResult;
import com.gccs.cg.model.GrantThreshold;
import com.gccs.cp.dao.hibernate.CouponDao;
import com.gccs.gf.action.GiftParamUtil;
import com.gccs.gf.dao.hibernate.GiftDao;
import com.gccs.gf.model.GfGift;
import com.gccs.gf.model.GfGiftActivity;
import com.gccs.gf.model.GfGiftActivityCardno;
import com.gccs.gf.model.GfGiftActivityGift;
import com.gccs.gf.model.GfGiftActivitySku;
import com.gccs.gf.model.GfGiftAllot;
import com.gccs.gf.model.GfGiftTransferLog;
import com.gccs.util.web.SelectItem;

public class GiftService implements IGiftService {
	private static final Logger log = LogManager.getLogger(GiftService.class) ;

	private GiftDao gfDao;
	private CouponDao couponDao;

	private TransactionTemplate transactionTemplate;

	public CouponDao getCouponDao() {
		return couponDao;
	}
	public void setCouponDao(CouponDao couponDao) {
		this.couponDao = couponDao;
	}

	public GiftDao getGfDao() {
		return gfDao;
	}
	public void setGfDao(GiftDao gfDao) {
		this.gfDao = gfDao;
	}
	public TransactionTemplate getTransactionTemplate() {
		return transactionTemplate;
	}
	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}
	public GfGiftActivity findGiftActivityByOid(String oid){
		return gfDao.findGiftActivityByOid(oid);
	}
	public PageBean findGiftByQueryCondition(Map queryCondition, PageBean inPageBean) throws Exception {
		return gfDao.findGiftByQueryCondition(queryCondition, inPageBean);
	}

	public PageBean findActivityByQueryCondition(Map queryCondition, PageBean inPageBean,int findListType) throws Exception {
		return gfDao.findActivityByQueryCondition(queryCondition, inPageBean,findListType);
	}

	public PageBean findStoreByQueryCondition(Map queryCondition, PageBean inPageBean) throws Exception {
		PageBean p= gfDao.findStoreByQueryCondition(queryCondition, inPageBean);
		return p;
	}

	public PageBean findTransferByQueryCondition(Map queryCondition, PageBean inPageBean) throws Exception {
		PageBean p= gfDao.findTransferByQueryCondition(queryCondition, inPageBean);
		Collection col = p.getQueryList();
		Iterator it = col.iterator();
		while(it.hasNext()){
			GfGiftAllot allot = (GfGiftAllot)it.next();

			allot.setExchangedAmt(this.getExchangedAmt());
			allot.setTotalAllotAmtByStore(this.getTotalAllotAmtByStore(allot.getGfGift().getGiftId(),allot.getChannelId(),allot.getStoreId()));
			allot.setTotalAmtIn(this.getTotalAmtInByTransfer(allot.getGfGift().getGiftId(),allot.getChannelId(),allot.getStoreId()));
			allot.setTotalAmtOut(this.getTotalAmtOutByTransfer(allot.getGfGift().getGiftId(),allot.getChannelId(),allot.getStoreId()));
			allot.setAvlTransferAmt(
				caculateAvlTransferAmt(
					allot.getTotalAllotAmtByStore(),
					allot.getExchangedAmt(),
					allot.getTotalAmtIn(),
					allot.getTotalAmtOut()));
		}
		return p;
	}
	private long caculateAvlTransferAmt(long totalAmt,long exchangedAmt,long totalAmtIn,long totalAmtOut){
		long avlTransferAmt = 0;
		avlTransferAmt = totalAmt - exchangedAmt + totalAmtIn - totalAmtOut;
		return avlTransferAmt;
	}

	public PageBean findCardNoByQueryCondition(Map queryCondition, PageBean inPageBean) throws Exception {
		return gfDao.findCardNoByQueryCondition(queryCondition,SelectItem.CLASS_CODE_BANK ,inPageBean);
	}

	public PageBean findActivityNamesByQueryCondition(Map queryCondition,PageBean inPageBean)throws Exception{
		return gfDao.findActivityNamesByQueryCondition(queryCondition, inPageBean);
	}

	public String findActivityNameByActivityId(String activityId){
		if(StringUtils.isNotBlank(activityId)){
			log.info("findActivityId : "+activityId);
			return gfDao.findActivityNameByActivityId(activityId);
		}
		return null;
	}

	public GfGift findGiftByGiftId(String giftId){
		if(StringUtils.isNotBlank(giftId)){
			log.info("findGiftByGiftId : giftId -> "+giftId);
			return gfDao.findGiftByGiftId(giftId);
		}
		return null;
	}

	public GfGift findGiftByOid(String oid)throws Exception{
		return  gfDao.findGiftByOid(oid);
	}
	/*
	public List<GfGift> findGfitByGiftId(String giftId){
		return this.getGfDao().findGfitByGiftId(giftId);

	}
	*/
	public void saveGiftActivityByStatusType(String activityId,String status,ScSysuser user){
		gfDao.updateGiftActivityStatus(activityId, status, user);
	}

	public void saveGfitStore(final GfGift gift,final List<GfGiftAllot> allotList){
		transactionTemplate.execute(new TransactionCallback() {
			public Object doInTransaction(TransactionStatus txnStatus) {
				try{
					log.info(">>>>> gift Obj"+gift);
					if(StringUtils.isNotBlank(gift.getOid())){
						log.info(">>>> update GiftStore");
						getGfDao().updateObject(gift);
					}else{
						log.info(">>>> insert GiftStore");
						getGfDao().insertObject(gift);
					}
					if(allotList!=null && allotList.size()>0){
						for(GfGiftAllot allot:allotList){
							allot.setGiftOid(gift.getOid());
							if(allot.getAllotAmt() != null)
								getGfDao().insertObject(allot);
						}
					}

				} catch(Exception ex) {
					txnStatus.setRollbackOnly();
					throw new RuntimeException(ex);
				}
				return null;
			}
		});
	}

	public void saveGfitTransfer(final List<GfGiftTransferLog> transferList){
		transactionTemplate.execute(new TransactionCallback() {
			public Object doInTransaction(TransactionStatus txnStatus) {
				try{

					if(transferList!=null && transferList.size()>0){
						for(GfGiftTransferLog transfer:transferList){
								getGfDao().insertObject(transfer);
						}
					}
				} catch(Exception ex) {
					txnStatus.setRollbackOnly();
					throw new RuntimeException(ex);
				}
				return null;
			}
		});
	}

	public void saveGiftActivity(final GfGiftActivity activity,final Map giftSkuMap)throws Exception{
		transactionTemplate.execute(new TransactionCallback() {
			public Object doInTransaction(TransactionStatus txnStatus) {
				Boolean txnFail = false;
				try{
					if(StringUtils.isEmpty(activity.getOid())){
						log.info("開始執行新增....");
						//insert activity master
						getGfDao().insertObject(activity);
						resetDetailActivityId(activity);

						//insert grantConfig
						log.info(activity.getUtGrantConfig());
						getGfDao().insertObject(activity.getUtGrantConfig());


					}else{
						log.info("開始執行更新....");
						//activity.transferOp2object();
						gfDao.delActivityGiftByActivityOid(activity.getOid());

						gfDao.delActivityCardNoByActivityOid(activity.getOid());

						//CG_GRANT_THRESHOLD => delete and insert
						couponDao.deleteGrantThresholdByConfigOid(activity.getUtGrantConfig().getOid());

						gfDao.updateObject(activity);

						//insert grantConfig
						gfDao.updateObject(activity.getUtGrantConfig());
					}

					//insert cg_grant_threshold of cg_grantConfig
			    	List <GrantThreshold> thresholdList = activity.getUtGrantConfig().getGtList();
			    	if(thresholdList != null) {
						for(GrantThreshold gt : thresholdList) {
							gt.setConfigOid(activity.getUtGrantConfig().getOid());
							log.info("\n>>>>>>>>>>> GrantThreshold <<<<<<<<<<<<<\n"+gt);
							couponDao.saveGrantThreshold(gt);
						}
					}else log.info(" thresholdList is Null or size < 0 ");

					saveActivitySku(giftSkuMap,activity.getOid());

				} catch(Exception ex) {
					txnFail = true;
					txnStatus.setRollbackOnly();
					throw new RuntimeException(ex);
				}
				return txnFail;
			}
		});
	}

	@SuppressWarnings("unused")
	private void resetDetailActivityId(GfGiftActivity activity){
		try{
			activity.getUtGrantConfig().setActivityOid(activity.getOid());
			if(activity.getGifts()!=null&&activity.getGifts().size()>0){
				Iterator giftsIt = activity.getGifts().iterator();
				while(giftsIt.hasNext()){
					GfGiftActivityGift gift = (GfGiftActivityGift)giftsIt.next();
					gift.setActivityOid(activity.getOid());
				}
			}
			if(activity.getCardNos()!=null&&activity.getCardNos().size()>0){
				Iterator cardnosIt = activity.getCardNos().iterator();
				while(cardnosIt.hasNext()){
					GfGiftActivityCardno cardno = (GfGiftActivityCardno)cardnosIt.next();
					cardno.setActivityOid(activity.getOid());
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	private void saveActivitySku(Map giftSkuMap,String activityOid)throws Exception{
		List<GfGiftActivitySku> addSkuList = (List<GfGiftActivitySku>)giftSkuMap.get("addSkuVoList");
		List<GfGiftActivitySku> updSkuList = (List<GfGiftActivitySku>)giftSkuMap.get("updSkuVoList");
		List<GfGiftActivitySku> delSkuList = (List<GfGiftActivitySku>)giftSkuMap.get("delSkuVoList");

		GiftParamUtil.showLog(updSkuList, addSkuList);

		log.info("修改 Sku size: "+updSkuList.size());
		for(GfGiftActivitySku sku :updSkuList){
			sku.setActivityOid(activityOid);
			getGfDao().updateGiftActivitySku(sku);
		}
		log.info("新增 Sku size: "+addSkuList.size());
		for(GfGiftActivitySku sku :addSkuList){
			sku.setActivityOid(activityOid);
			getGfDao().saveGiftActivitySku(sku);
		}
		log.info("刪除 Sku size: "+delSkuList.size());
		for(GfGiftActivitySku sku :delSkuList){
			sku.setActivityOid(activityOid);
			getGfDao().delGiftActivitySku(sku);
		}
	}


	public String findActivityId(){
		String str = "BCS";
		int rand = (int)(Math.random()*10000000+1);
		return str+String.valueOf(rand);
	}



	public QueryResult findActivitySkuByActivityOid(final String activityOid,final int index,final int pageSize)throws Exception{
		QueryResult queryResult = new QueryResult();

		List countList = this.getGfDao().findActivitySkuByActivityOId(activityOid, index, pageSize, true);
		List reulstList = null;

		if(countList!=null && countList.size()>0){
			queryResult.setCount((Integer)countList.get(0));
			reulstList = this.getGfDao().findActivitySkuByActivityOId(activityOid, index, pageSize, false);
			queryResult.setResult(reulstList);
		}else{
			queryResult.setCount(0);
			queryResult.setResult(null);
		}

		return queryResult;
	}

	public long getTotalAllotAmtByStore(String giftId, String channelId, String storeId) {
		long rtv = 0;

		log.info("\n\n>>>>>>>>>>>>>>>>>>>>>>" +
				"giftId: "+giftId+"\n"+
				"channelId: "+channelId+"\n"+
				"storeId: "+storeId+"\n"+
				">>>>>>>>>>>>>>>>>>>>>>>>>>");

		if(StringUtils.isNotBlank(giftId) && StringUtils.isNotBlank(channelId)
				&& StringUtils.isNotBlank(storeId)) {
			rtv = this.getGfDao().getTotalAllotAmtByStore(giftId, channelId, storeId);

		}
		log.info("service 查詢 Total Amt : "+rtv);
		return rtv;
	}

	public long getTotalAmtInByTransfer(String giftId, String channelId, String storeId){
		long rtv = 0;
		if(StringUtils.isNotBlank(giftId) && StringUtils.isNotBlank(channelId)
				&& StringUtils.isNotBlank(storeId)) {
			rtv = this.getGfDao().getTotalAmtInByTransfer(giftId, channelId, storeId);
		}
		return rtv;
	}

	public long getTotalAmtOutByTransfer(String giftId, String channelId, String storeId){
		long rtv = 0;
		if(StringUtils.isNotBlank(giftId) && StringUtils.isNotBlank(channelId)
				&& StringUtils.isNotBlank(storeId)) {
			rtv = this.getGfDao().getTotalAmtOutByTransfer(giftId, channelId, storeId);
		}
		return rtv;
	}

	public long getExchangedAmt(){
		return new Long(0);
	}

	public long queryCanTransferAmount(final String giftId,final String  channelId,final String  storeId){
		return (Long)this.transactionTemplate.execute(new TransactionCallback() {
		    public Object doInTransaction(TransactionStatus status){
		    	long totalAllotAmount = getTotalAllotAmtByStore(giftId, channelId, storeId); //分配數量
		    	long exchangeAmt = getExchangedAmt(); //發放數量
		    	long inAmount = getTotalAmtInByTransfer(giftId, channelId, storeId); //調 入數量
		    	long outAmount = getTotalAmtOutByTransfer(giftId, channelId, storeId); //調 出數量
		    	long transferAmt = totalAllotAmount-exchangeAmt-outAmount+inAmount;
		    	log.info("\n>>>>>>>>>>>>>>查詢店點可調撥量<<<<<<<<<<<<<<<\n"+
		    			"condition giftId : "+giftId+"\n"+
		    			"condition channelId: "+channelId+"\n"+
		    			"condition storeId:"+ storeId+"\n"+
		    			"-----------------------------------\n"+
		    			"(A)分配數量(allot table): "+totalAllotAmount+"\n"+
		    			"(B)發放數量(allot table): "+exchangeAmt+"\n"+
		    			"(C)調入數量(trans talbe): "+inAmount+"\n"+
		    			"(D)調出數量(trans table): "+outAmount+"\n"+
		    			"-----------------------------------\n"+
		    			"計算可調撥數量=>(A)-(B)+(C)-(D) = "+transferAmt);

		    	return transferAmt;
		    }
		});
	}

	@SuppressWarnings("unchecked")
	public Map queryStoreMap(String giftOid, String channelId, String storeId) {
		log.info("\n>>>>>>>>>>>>>>>>>>>>>>\n"+
				"giftOid: "+giftOid+"\n"+
				"channelId: "+channelId+"\n"+
				"storeId: "+storeId+"\n"+
				">>>>>>>>>>>>>>>>>>>>>>>>>>\n");
		List<Map> list = this.gfDao.findStoreFromGiftAllot(giftOid, channelId, storeId);
		return convertList(list, true);
	}

	@SuppressWarnings("unchecked")
	public Map queryChannelMap(String giftOid) {
		List<Map> list = this.gfDao.findChannelFromGiftAllot(giftOid);
		return convertList(list, true);
	}

	@SuppressWarnings("unchecked")
	private Map convertList(List<Map>list, boolean hasFirst) {
		Map result = new LinkedHashMap();

		if(list.size() <= 0) {
			result.put("", "查無資料");
		} else {
			if(hasFirst) result.put("", "請選擇");
			for(Map map : list) {
				result.put(map.get("KEY"), map.get("VALUE"));
			}
		}

		return result;
	}
}
