package com.gccs.gf.sevice;

public interface IGiftService {

	public long getTotalAllotAmtByStore(String giftId, String channelId, String storeId);
	public long getExchangedAmt();
	public long getTotalAmtInByTransfer(String giftId, String channelId, String storeId);
	public long getTotalAmtOutByTransfer(String giftId, String channelId, String storeId);

}
