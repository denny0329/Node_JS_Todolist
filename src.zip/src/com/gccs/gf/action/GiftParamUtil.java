package com.gccs.gf.action;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.DateTimeUtils;
import com.gccs.gf.model.GfGiftActivitySku;
import com.gccs.ws.service.BaseWebService;

public class GiftParamUtil {
	private static final Logger log = LogManager.getLogger(GiftParamUtil.class) ;
	private HttpServletRequest request;

	public static final int SKU = 0;
	public static final int AMT = 1;



	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

	private String userId;
	private String userName;



	public HttpServletRequest getRequest() {
		return request;
	}
	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}


	public GiftParamUtil(HttpServletRequest request,String userId,String userName){
		this.request = request;
		this.userId = userId;
		this.userName = userName;
	}

	/**
	 * 重組Sku data
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public Map recombinationSkuDetailDataByItem() throws Exception{

		Map skuMap = getSkuParam();
		//String refOid = (String)skuMap.get("refOid");
		//log.info(">>>>>>>>>>>>>>>recombinationSkuDetailDataByItem activityOid: "+activityOid);
		//String refOid = activityOid;
		String [] delOids = (String[])skuMap.get("delOidObj");
		String [] oids = (String[])skuMap.get("oidObj");
		String [] classMappeds = (String[])skuMap.get("classMappedObj");
		String [] skus = (String[])skuMap.get("skuObj");
		String [] skuNames = (String[])skuMap.get("skuNameObj");
		String [] vendors = (String[])skuMap.get("vendorObj");
		String [] vendorNames = (String[])skuMap.get("vendorNameObj");



		GfGiftActivitySku sku = null;
		List<GfGiftActivitySku> addSkuVoList = new ArrayList<GfGiftActivitySku>();
		List<GfGiftActivitySku> updSkuVoList = new ArrayList<GfGiftActivitySku>();
		List<GfGiftActivitySku> delSkuVoList = new ArrayList<GfGiftActivitySku>();

		log.info("oids length: "+oids.length);
		for(int i=0;i<oids.length;i++){
			sku = new GfGiftActivitySku();
			if(!BaseWebService.isEmpty(passByIgnoreStr(oids[i]))){
				sku.setOid(oids[i]);
			}

			if(classMappeds!=null && classMappeds.length>0){
				String [] classmappedDtl = classMappeds[i].split("-");
				sku.setDept(passByIgnoreStr(classmappedDtl[0]));
				sku.setSubDept(passByIgnoreStr(classmappedDtl[1]));
				sku.setClass_(passByIgnoreStr(classmappedDtl[2]));
				sku.setSubClass(passByIgnoreStr(classmappedDtl[3]));
			}

			sku.setSku(passByIgnoreStr(skus[i]));
			sku.setSkuName(passByIgnoreStr(skuNames[i]));
			sku.setVendorId(passByIgnoreStr(vendors[i]));
			sku.setVendorName(passByIgnoreStr(vendorNames[i]));



			Timestamp sysdate = DateTimeUtils.getSysDate();
			sku.setCreator(this.getUserId());
			sku.setCreatorName(this.getUserName());
			sku.setCreateTime(sysdate);
			sku.setModifier(this.getUserId());
			sku.setModifierName(this.getUserName());
			sku.setModifyTime(sysdate);
			//sku.setActivityOid(refOid);

			if(!BaseWebService.isEmpty(sku.getOid())){
				//if(isValid(sku))
				log.info("加入第 "+i+" 筆sku至upd sku");
					updSkuVoList.add(sku);
			}else{
				log.info("加入第 "+i+" 筆sku至add sku");
				//if(isValid(sku))
					addSkuVoList.add(sku);
			}


		}
		if(addSkuVoList!=null && addSkuVoList.size()>0)
		log.info("顯示addSkuVoList Size (): "+addSkuVoList.size()+" 筆");

		if(delOids!=null&& delOids.length>0){
			for(int i=0;i<delOids.length;i++){
				sku = new GfGiftActivitySku();
				if(!BaseWebService.isEmpty(delOids[i])){
					sku.setOid(delOids[i]);
					delSkuVoList.add(sku);
					log.info("del Oids ===>  ["+i+"]: "+delOids[i]);
				}
			}
		}

		Map map = new HashMap();
		//map.put("refOid",refOid);
		map.put("addSkuVoList",addSkuVoList);
		map.put("updSkuVoList",updSkuVoList);
		map.put("delSkuVoList",delSkuVoList);
		return map;
	}

	private boolean isValid(GfGiftActivitySku sku) {
		if(  isNull(sku.getDept()) && isNull(sku.getSubDept()) && isNull(sku.getClass_()) && isNull(sku.getSubClass())
				    && isNull(sku.getSku()) ) {
			return false ;
		}else{
			return true ;
		}
	}
	private static boolean isNull(String value) {
		if(value == null || value.trim().equals("")) {
			return true ;
		}else{
			return false ;
		}
	}


	/**
	 * show log
	 * @param updDiscountSkuList
	 * @param addDiscountSkuList
	 */
	public static void showLog(List <GfGiftActivitySku>updSkuList,List <GfGiftActivitySku>addSkuList){
		log.info("更新 Sku size: "+updSkuList.size());
		StringBuilder sb = null;
		for(int i=0;i<updSkuList.size();i++){
			sb = new StringBuilder();
			GfGiftActivitySku sku = updSkuList.get(i);
			sb.append("\n第"+i+"筆\n");
			sb.append("activityOid: "+sku.getActivityOid()+"\n");
			sb.append("oid : "+ sku.getOid()+"\n");
			sb.append("dept: "+sku.getDept()+"\n");
			sb.append("subDept: "+sku.getSubDept()+"\n");
			sb.append("class: "+sku.getClass()+"\n");
			sb.append("subClass: "+sku.getSubClass()+"\n");
			sb.append("sku: "+sku.getSku()+"\n");
			sb.append("skuName : "+sku.getSkuName()+"\n");
			sb.append("vendor: "+sku.getVendorId()+"\n");
			sb.append("vendorName : "+sku.getVendorName()+"\n");
			log.info("upd ===>"+sb.toString());
		}
	}

	private int  calAryLength(String[] arg){
		if(arg==null)return 0;
		else return arg.length;
	}
	/**
	 * 取得DisCountSku 頁面參數
	 * @return
	 */
	private Map getSkuParam(){
		Map map = new HashMap();
		String delOid = this.getRequest().getParameter("delOidObj");
		String oidObj = this.getRequest().getParameter("oidObj");
		String classMappedObj = this.getRequest().getParameter("classMappedObj");
		String skuObj = this.getRequest().getParameter("skuObj");
		String skuNameObj = this.getRequest().getParameter("skuNameObj");
		String vendorObj = this.getRequest().getParameter("vendorObj");
		String vendorNameObj = this.getRequest().getParameter("vendorNameObj");


		String totalCnt = this.getRequest().getParameter("totalCnt");

		String [] delOids = null;
		if(!BaseWebService.isEmpty(delOid.split(","))){
			delOids = delOid.split(",");
		}

		String [] oids = this.validateAndSplitAry(oidObj);
		String [] classMappeds = this.validateAndSplitAry(classMappedObj);
		String [] skus = this.validateAndSplitAry(skuObj);
		String [] skuNames = this.validateAndSplitAry(skuNameObj);
		String [] vendors =  this.validateAndSplitAry(vendorObj);
		String [] vendorNames = this.validateAndSplitAry(vendorNameObj);

		log.info("顯示原始Sku資料\n" +
				"oidObj: "+oidObj+"\n"+
				"classMappedObj: "+classMappedObj+"\n"+
				"skuObj: "+skuObj+"\n"+
				"skuNameObj: "+skuNameObj+"\n"+
				"vendorObj: "+vendorObj+"\n"+
				"vendorNameObj: "+vendorNameObj+"\n"

		);

		StringBuilder sblog = new StringBuilder();
		sblog.append("\n length => oid: "+calAryLength(oids)+"\n")
		.append("classMappedObj: "		+calAryLength(classMappeds)+"\n")
		.append("skuObj: "					+calAryLength(skus)+"\n")
		.append("skuNameObj: "			+calAryLength(skuNames)+"\n")
		.append("vendorObj : "				+ calAryLength(vendors)+"\n")
		.append("vendorNameObj : "		+ calAryLength(vendorNames)+"\n")
		.append("totalCan: "					+totalCnt);
		log.info(sblog.toString());



		map.put("delOidObj",delOids);
		map.put("oidObj", oids);
		map.put("classMappedObj",classMappeds);
		map.put("skuObj",skus);
		map.put("skuNameObj", skuNames);
		map.put("vendorObj",vendors);
		map.put("vendorNameObj",vendorNames);
		map.put("totalCnt", totalCnt);

		return map;
	}


	private String[] validateAndSplitAry(String str){
		if(str==null || str.equals("")){
			return new String[0];
		}else return  str.split(",");
	}

	/**
	 * 忽略字串'|'
	 * @param str
	 * @return
	 */
	private String passByIgnoreStr(String str){
		String ignoreStr = "|";
		if(str!=null&&!"".equalsIgnoreCase(str)){
			if(str.equalsIgnoreCase(ignoreStr)){
				return null;
			}
		}
		return str;
	}
}
