package com.gccs.gf.action;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.PageBean;
import com.bnq.util.ViewPage;
import com.gccs.gf.model.GfGiftAllot;
import com.gccs.gf.model.GfGiftTransferLog;
import com.opensymphony.xwork2.Action;

public class GiftTransferAction extends GiftBaseAction {
	private static final long serialVersionUID = -5792120719480886701L;

	private static final Logger log = LogManager.getLogger(GiftTransferAction.class) ;
	protected static final String ALLOT_ENTITY = "ALLOT_ENTITY";
	protected static final String TRANSFER_ENTITY = "TRANSFER_ENTITY";

	public List<GfGiftTransferLog> getTransfers() {
		List<GfGiftTransferLog> rtv = getGfTransferFromSession();
		if(rtv == null) {
			rtv = new ArrayList<GfGiftTransferLog>();
			setTransfers(rtv);
		}
		return rtv;
	}

	public void setTransfers(List<GfGiftTransferLog> transfer) {
		if(transfer != null)
			getSessionMap().put(TRANSFER_ENTITY,transfer);
		else getSessionMap().remove(TRANSFER_ENTITY);
	}

	public GfGiftAllot getAllot() {
		GfGiftAllot rtv = getGfAllotFromSession();
		if(rtv == null) {
			rtv = new GfGiftAllot();
			setAllot(rtv);
		}
		return rtv;
	}

	public void setAllot(GfGiftAllot allot) {
		if(allot != null)
			getSessionMap().put(ALLOT_ENTITY,allot);
		else getSessionMap().remove(ALLOT_ENTITY);
	}

	protected GfGiftAllot getGfAllotFromSession() {
		return (GfGiftAllot)getSessionMap().get(ALLOT_ENTITY);
	}
	protected List<GfGiftTransferLog> getGfTransferFromSession() {
		return (List<GfGiftTransferLog>)getSessionMap().get(TRANSFER_ENTITY);
	}

	@Override
	public String create() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String edit() {
		int beanIdx = Integer.parseInt(this.getRequest().getParameter("beanIdx"));
		PageBean pagebean = (PageBean)this.getSessionMap().get(PAGE_BEAN);
		Collection c = pagebean.getQueryList();
		GfGiftAllot allot = (GfGiftAllot)((Object[])c.toArray())[beanIdx];
		log.info(allot);
		setAllot(allot);
		return SUCCESS;
	}

	@Override
	public String exit() {
		this.setAllot(null);
		super.exitProc();
		return SUCCESS;
	}

	public String find(){
		try{
			log.info("find begin\n"+
					"\n>>>>>>>>>>>>>>>>>>>>>>>\n" +
					"getIsBtnQuery()=> "+this.getIsBtnQuery()+
					"PageBean.page  => "+this.getPageBean().getPage()+
					"\n>>>>>>>>>>>>>>>>>>>>>>>");
			//當使用者進行換頁時，忽略畫面的查詢條件
			if(this.getIsBtnQuery().equals("no")){
				this.setQueryCondition((Map)getSessionMap().get(QUERY_CONDITION));
			}else{
				//當重新查詢時,初始化curren page 為1(表示第一頁)
				//初始化JumpPage為null
				this.getPageBean().setPage(1);
				this.getPageBean().setJumpPage(null);
			}

			Map queryCondition = getQueryCondition();

			//查詢結果
			this.setPageBean(this.getGfService().findTransferByQueryCondition(queryCondition, this.getPageBean()));
			this.getPageBean().setFormAction("transferFind");//表單action
			this.getPageBean().setToolsMenu(ViewPage.getToolsMenuByDefault(this.getPageBean()));

			//儲存查詢條件、結果
			getSessionMap().put(QUERY_CONDITION , queryCondition);
			getSessionMap().put(PAGE_BEAN, getPageBean());


		}catch(Exception e){
			e.printStackTrace();
			log.error(e);
			addActionError(e.getMessage());
		}
		return SUCCESS;
	}

	public String save(){
		log.info(">>>>>>>>>>>>>>>> to Save! ");

		result = new HashMap<String,String>();
		result.put(Action.SUCCESS, "Y");
		result.put("msg", "儲存完成!");

		try{
			List<GfGiftTransferLog> transferList = getTransfers();
			if(transferList!=null && transferList.size()>0){
				log.info("transfer size : "+transferList.size());
			}else log.info("transfer is NULL or transfer <= 0");
			for(GfGiftTransferLog transfer :transferList){
				transfer.setCreator(this.getUser().getUserId());
				transfer.setCreatorName(this.getUser().getUserName());
				transfer.setCreateTime(new Date());
				transfer.setModifier(this.getUser().getUserId());
				transfer.setModifierName(this.getUser().getUserName());
				transfer.setModifyTime(new Date());
				log.info(transfer);
			}

			this.getGfService().saveGfitTransfer(transferList);
		}catch(Exception e){
			e.printStackTrace();
			result.put(Action.SUCCESS, "N");
			result.put("msg", "error");
		}
		return "result";
	}
}
