package com.gccs.gf.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.CollectionUtils;
import com.bnq.util.ViewPage;
import com.gccs.cg.model.GrantConfig;
import com.gccs.gf.model.GfGiftActivity;
import com.gccs.gf.model.GfGiftActivityCardno;
import com.gccs.gf.model.GfGiftActivityGift;
import com.opensymphony.xwork2.Action;

public class GiftActivityAction extends GiftBaseAction{
	private static final long serialVersionUID = 4304434648907690937L;

	private static final Logger log = LogManager.getLogger(GiftActivityAction.class) ;
	private static final String ACTIVITY_GIFTLIST = "ACTIVITY_GIFTLIST";
	private static final String ACTIVITY_CARDNOLIST = "ACTIVITY_CARDNOLIST";

	public String getOperateId() {
		return (String)getSessionMap().get("operateId");
	}

	public void setOperateId(String operateId) {
		if(StringUtils.isEmpty(operateId))
			operateId = null;

		if(operateId != null)
			getSessionMap().put("operateId", operateId);
		else
			getSessionMap().remove("operateId");
	}

	public GfGiftActivity getGiftActivity() {
		GfGiftActivity rtv = getGfGiftActivityFromSession();
		if(rtv == null) {
			rtv = new GfGiftActivity();
			rtv.setUtGrantConfig(new GrantConfig(this.getUser()));
			setGiftActivity(rtv);
		}
		return rtv;
	}
	public void setGiftActivity(GfGiftActivity giftActivity) {
		if(giftActivity != null)
			getSessionMap().put(GIFT_ENTITY, giftActivity);
		else
			getSessionMap().remove(GIFT_ENTITY);
	}

	public void setGiftList(List<GfGiftActivityGift> giftList) {
		this.getSessionMap().put(ACTIVITY_GIFTLIST, giftList);
	}

	public List<GfGiftActivityGift> getGiftList() {
		List<GfGiftActivityGift> giftList = (List<GfGiftActivityGift>)getSessionMap().get(ACTIVITY_GIFTLIST);
		if(giftList == null) {
			giftList = new ArrayList<GfGiftActivityGift>();
			setGiftList(giftList);
		}
		return giftList;
	}

	public void setCardNoList(List<GfGiftActivityCardno> giftList) {
		this.getSessionMap().put(ACTIVITY_CARDNOLIST, giftList);
	}

	public List<GfGiftActivityCardno> getCardNoList(){
		List<GfGiftActivityCardno> giftList = (List<GfGiftActivityCardno>)getSessionMap().get(ACTIVITY_CARDNOLIST);
		if(giftList == null) {
			giftList = new ArrayList<GfGiftActivityCardno>();
			setCardNoList(giftList);
		}
		return giftList;
	}

	protected GfGiftActivity getGfGiftActivityFromSession() {
		return (GfGiftActivity)getSessionMap().get(GIFT_ENTITY);
	}

	public String load(){
		super.load();
		this.getSessionMap().put("findListType", getFindListType());
		return Action.SUCCESS;
	}

	public String create(){
		this.utGrantConfig = new GrantConfig(this.getUser());
		initCreate();
		return SUCCESS;
	}

	private void initCreate(){
		GfGiftActivity activity = getGiftActivity();
		activity.setCreator(this.getUser().getUserId());
		activity.setCreatorName(this.getUser().getUserName());
		activity.setCreateTime(new Date());
		activity.setModifier(this.getUser().getUserId());
		activity.setModifierName(this.getUser().getUserName());
		activity.setModifyTime(new Date());
		activity.setStatus(0);
	}


	public String save(){
		try{
			GfGiftActivity _activity = this.getGiftActivity();
			GiftParamUtil skuUtil = new GiftParamUtil(
					this.getRequest(),getCurrentUser().getUserId(),getCurrentUser().getUserName());
			_activity.setUtGrantConfig(this.getUtGrantConfig());
			transferMasterOP(_activity);


			Map giftSkuMap = skuUtil.recombinationSkuDetailDataByItem();
			this.getGfService().saveGiftActivity(this.getGiftActivity(),giftSkuMap);
			this.setGiftList(null);   //reset GiftList   (Note:must require)
			this.setCardNoList(null); //reset CardNoList (Note:must require)
		}catch(Exception e){
			log.error(e.getMessage(),e) ;
		}
		return SUCCESS;
	}

	public String approve(){
		String status = (String)this.getRequest().getAttribute("status");
		log.info("status :"+status);
		log.info("activityId: "+this.getGiftActivity().getActivityId());
		this.getGfService().saveGiftActivityByStatusType(
				this.getGiftActivity().getActivityId(), status, this.getUser());
		this.getGiftActivity().setStatus(Integer.parseInt(status));
		return SUCCESS;
	}



	public String edit(){
		log.info("activity Oid: "+this.getOperateId());
		String oid = this.getOperateId();
		if(StringUtils.isNotEmpty(oid)){
			GfGiftActivity activity = this.getGfService().findGiftActivityByOid(oid);
			this.setGiftActivity(activity);
			super.setUtGrantConfig(this.getGiftActivity().getUtGrantConfig());
		}

		return SUCCESS;
	}

	public String find()  {
		try{
			log.info("find begin\n"+
					"\n>>>>>>>>>>>>>>>>>>>>>>>\n" +
					"getIsBtnQuery()=> "+this.getIsBtnQuery()+
					"PageBean.page  => "+this.getPageBean().getPage()+
					"\n>>>>>>>>>>>>>>>>>>>>>>>");
			int findListType = Integer.parseInt((String)this.getSessionMap().get("findListType"));


			//當使用者進行換頁時，忽略畫面的查詢條件
			if(this.getIsBtnQuery().equals("no")){
				this.setQueryCondition((Map)getSessionMap().get(QUERY_CONDITION));
			}

			Map queryCondition = getQueryCondition();

			//查詢結果
			this.setPageBean(this.getGfService().findActivityByQueryCondition(queryCondition, this.getPageBean(),findListType));
			this.getPageBean().setFormAction("activityFind");//表單action
			this.getPageBean().setToolsMenu(ViewPage.getToolsMenuByDefault(this.getPageBean()));


			//儲存查詢條件、結果
			getSessionMap().put(QUERY_CONDITION , queryCondition);
			getSessionMap().put(PAGE_BEAN, getPageBean());

			this.getRequest().setAttribute("findListType", findListType);
		}catch(Exception e){
			e.printStackTrace();
			log.error(e);
			addActionError(e.getMessage());
		}
		return SUCCESS;
	}

	public String exit(){
		//清除舊的session值
		setGiftActivity(null);
		this.setUtGrantConfig(null);
		this.setGiftList(null);
		this.setCardNoList(null);
		exitProc();
		return SUCCESS;
	}

	private void transferMasterOP(GfGiftActivity _activity)throws Exception{
		if(StringUtils.isEmpty(_activity.getOid())){
			//carry out create/save process and generate activityId
			_activity.setActivityId(this.getGfService().findActivityId());
			_activity.setCreator(this.getUser().getUserId());
			_activity.setCreatorName(this.getUser().getUserName());
			_activity.setCreateTime(new Date());

			_activity.getUtGrantConfig().setCreator(_activity.getCreator());
			_activity.getUtGrantConfig().setCreateTime(_activity.getCreateTime());
			_activity.getUtGrantConfig().setCreatorName(_activity.getCreatorName());
		}
		//carry out update process
		//transfer operator info to model object
		_activity.setModifier(this.getUser().getUserId());
		_activity.setModifierName(this.getUser().getUserName());
		_activity.setModifyTime(new Date());

		_activity.getUtGrantConfig().setModifier(_activity.getModifier());
		_activity.getUtGrantConfig().setModifyTime(_activity.getModifyTime());
		_activity.getUtGrantConfig().setModifierName(_activity.getModifierName());

		//set new Gifts
		_activity.setGifts(transferToGiftSet(this.getGiftList()));
		_activity.setCardNos(transferToCardnoSet(this.getCardNoList()));
	}

	private Set<GfGiftActivityGift> transferToGiftSet(List<GfGiftActivityGift> list)throws Exception{
		Date modifyTime = new Date();
		Set<GfGiftActivityGift> _set = null;
		for(GfGiftActivityGift newObj: list) {
			newObj.setOid(null);
			newObj.setActivityOid(this.getGiftActivity().getActivityId());
			newObj.setCreator(this.getUser().getUserId());
			newObj.setCreatorName(this.getUser().getUserName());
			newObj.setCreateTime(this.getGiftActivity().getCreateTime());
			newObj.setModifier(this.getUser().getUserId());
			newObj.setModifierName(this.getUser().getUserName());
			newObj.setModifyTime(modifyTime);
			log.info(">>>>>>>>>>>>>>>>> new Gift <<<<<<<<<<<<<<<<<<<<<<<");
			log.info(newObj);
		}

		if(list!=null && list.size()>0)
			_set = CollectionUtils.listToSet(list);

		return _set;

	}
	private Set<GfGiftActivityCardno> transferToCardnoSet(List<GfGiftActivityCardno> list)throws Exception{
		Date modifyTime = new Date();
		Set<GfGiftActivityCardno> _set = null;
		for(GfGiftActivityCardno newObj: list) {
			newObj.setOid(null);
			newObj.setActivityOid(this.getGiftActivity().getActivityId());
			newObj.setCreator(this.getUser().getUserId());
			newObj.setCreatorName(this.getUser().getUserName());
			newObj.setCreateTime(this.getGiftActivity().getCreateTime());
			newObj.setModifier(this.getUser().getUserId());
			newObj.setModifierName(this.getUser().getUserName());
			newObj.setModifyTime(modifyTime);
			log.info(">>>>>>>>>>>>>>>>> new Cardnos <<<<<<<<<<<<<<<<<<<<<<<");
			log.info(newObj);
		}

		if(list!=null && list.size()>0)
			_set = CollectionUtils.listToSet(list);

		return _set;

	}

	public boolean isDisabled() {
		log.info("befare disabled -> status : "+this.getGiftActivity().getStatus());
		if(new Integer(0).equals(this.getGiftActivity().getStatus())) return false;
		return true;
	}
}
