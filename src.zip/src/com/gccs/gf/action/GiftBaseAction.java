package com.gccs.gf.action;

import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.PageBean;
import com.bnq.util.ViewPage;
import com.gccs.base.action.BaseAction;
import com.gccs.gf.sevice.GiftService;
import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;

public abstract class GiftBaseAction extends BaseAction{
	private static final long serialVersionUID = 2693680096891743661L;

	private static final Logger log = LogManager.getLogger(GiftBaseAction.class) ;
	protected static final String PAGE_BEAN = "PAGE_BEAN";
	protected static final String QUERY_CONDITION = "QUERY_CONDITION";
	protected static final String GIFT_ENTITY = "GIFT_ENTITY";
	private GiftService gfService;
	private String status;
	String findListType;

	public String getFindListType() {
		return findListType;
	}

	public void setFindListType(String findListType) {
		this.findListType = findListType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	protected Map<String,String> result;

	public Map<String,String> getResult() {
		return result;
	}

	public void setResult(Map<String,String> result) {
		this.result = result;
	}

	public GiftService getGfService() {
		return gfService;
	}
	public void setGfService(GiftService gfService) {
		this.gfService = gfService;
	}


	public String load(){
		this.setQueryCondition((Map)getSessionMap().put(QUERY_CONDITION,null));
		this.setPageBean((PageBean)getSessionMap().put(PAGE_BEAN,null));
		return Action.SUCCESS;
	}
	public abstract String create();
	public abstract String edit();
	public abstract String exit();
	public abstract String find();
	public abstract String save();

	protected  void exitProc(){
		this.setQueryCondition((Map)getSessionMap().get(QUERY_CONDITION));
		this.setPageBean((PageBean)getSessionMap().get(PAGE_BEAN));

	}




	@SuppressWarnings("unchecked")
	public String giftIdQuery(){
		try{
			//解決跳頁及下拉時,程式都會去抓畫面的查尋條件
			if(this.getIsBtnQuery().equals("no")){
				this.setQueryCondition((Map)ActionContext.getContext().getSession().get("giftQueryCondition"));
			}

			Map queryCondition = getQueryCondition();

			//查詢結果
			log.info("giftActivityAction => ok ");
			this.setPageBean(gfService.findGiftByQueryCondition(queryCondition, this.getPageBean()));
			this.getPageBean().setFormAction("giftIdQuery");//表單action
			this.getPageBean().setToolsMenu(ViewPage.getToolsMenuByDefault(this.getPageBean()));


			//儲存查詢結果
			ActionContext.getContext().getSession().put("giftQueryCondition" , queryCondition);
			ActionContext.getContext().getSession().put("giftPageBean" , this.getPageBean());


		} catch (Exception e) {
			e.printStackTrace();
			addActionError(getText("QUERY_FAIL")+"："+e.getMessage());

		}
		return SUCCESS;
	}

	@SuppressWarnings("unchecked")
	public String activityIdQuery(){
		try{
			//解決跳頁及下拉時,程式都會去抓畫面的查尋條件
			if(this.getIsBtnQuery().equals("no")){
				this.setQueryCondition((Map)ActionContext.getContext().getSession().get("activityQueryCondition"));
			}

			Map queryCondition = getQueryCondition();

			//查詢結果
			this.setPageBean(gfService.findActivityNamesByQueryCondition(queryCondition, this.getPageBean()));
			this.getPageBean().setFormAction("activityIdQuery");//表單action
			this.getPageBean().setToolsMenu(ViewPage.getToolsMenuByDefault(this.getPageBean()));


			//儲存查詢結果
			ActionContext.getContext().getSession().put("activityQueryCondition" , queryCondition);
			ActionContext.getContext().getSession().put("activityPageBean" , this.getPageBean());


		} catch (Exception e) {
			e.printStackTrace();
			addActionError(getText("QUERY_FAIL")+"："+e.getMessage());

		}
		return SUCCESS;
	}

	public String cardNoQuery(){
		try{
			//解決跳頁及下拉時,程式都會去抓畫面的查尋條件
			if(this.getIsBtnQuery().equals("no")){
				this.setQueryCondition((Map)ActionContext.getContext().getSession().get("cardNoQueryCondition"));
			}

			Map queryCondition = getQueryCondition();

			//查詢結果
			this.setPageBean(gfService.findCardNoByQueryCondition(queryCondition, this.getPageBean()));
			this.getPageBean().setFormAction("cardNoQuery");//表單action
			this.getPageBean().setToolsMenu(ViewPage.getToolsMenuByDefault(this.getPageBean()));


			//儲存查詢結果
			ActionContext.getContext().getSession().put("cardNoQueryCondition" , queryCondition);
			ActionContext.getContext().getSession().put("cardNoPageBean" , this.getPageBean());

		}catch(Exception e){
			e.printStackTrace();
			addActionError(getText("QUERY_FAIL")+"："+e.getMessage());
		}
		return SUCCESS;
	}
}
