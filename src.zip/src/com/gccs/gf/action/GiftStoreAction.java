package com.gccs.gf.action;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.ViewPage;
import com.gccs.gf.model.GfGift;
import com.gccs.gf.model.GfGiftAllot;
import com.opensymphony.xwork2.Action;

public class GiftStoreAction extends GiftBaseAction{
	private static final long serialVersionUID = -8986570553171654165L;

	private static final Logger log = LogManager.getLogger(GiftStoreAction.class) ;
	protected static final String ALLOT_ENTITY = "ALLOT_ENTITY";
	private GfGift gift;

	public List<GfGiftAllot> getAllot() {
		List<GfGiftAllot> rtv = getGfAllotFromSession();
		if(rtv == null) {
			rtv = new ArrayList<GfGiftAllot>();
			setAllot(rtv);
		}
		return rtv;
	}

	public void setAllot(List<GfGiftAllot> allot) {
		if(allot != null)
			getSessionMap().put(ALLOT_ENTITY,allot);
		else getSessionMap().remove(ALLOT_ENTITY);
	}

	public GfGift getGift() {
		GfGift rtv = getGfGiftFromSession();
		if(rtv == null) {
			rtv = new GfGift();
			setGift(rtv);
		}
		return rtv;
	}

	public void setGift(GfGift gift) {
		if(gift != null)
			getSessionMap().put(GIFT_ENTITY, gift);
		else
			getSessionMap().remove(GIFT_ENTITY);
	}

	protected GfGift getGfGiftFromSession() {
		if(!(getSessionMap().get(GIFT_ENTITY) instanceof  GfGift)){
			GfGift bean = new GfGift();
			setGift(bean);
		}
		return (GfGift)getSessionMap().get(GIFT_ENTITY);
	}
	protected List<GfGiftAllot> getGfAllotFromSession() {
		Object obj = getSessionMap().get(ALLOT_ENTITY);
		if((obj!=null && !((List)obj).isEmpty() && !(((List)obj).iterator().next() instanceof  GfGiftAllot))){
			List<GfGiftAllot> bean = new ArrayList<GfGiftAllot>();
			setAllot(bean);
		}
		return (List<GfGiftAllot>)getSessionMap().get(ALLOT_ENTITY);
	}
//##################################################################

	private void initCreate(){
		GfGift activity = getGift();
		activity.setCreator(this.getUser().getUserId());
		activity.setCreatorName(this.getUser().getUserName());
		activity.setCreateTime(new Date());
		activity.setModifier(this.getUser().getUserId());
		activity.setModifierName(this.getUser().getUserName());
		activity.setModifyTime(new Date());
	}

	public String create(){
		initCreate();
		return SUCCESS;
	}

	public String edit(){
		return SUCCESS;
	}

	public String find(){
		try{
			log.info("find begin\n"+
					"\n>>>>>>>>>>>>>>>>>>>>>>>\n" +
					"getIsBtnQuery()=> "+this.getIsBtnQuery()+
					"PageBean.page  => "+this.getPageBean().getPage()+
					"\n>>>>>>>>>>>>>>>>>>>>>>>");
			//當使用者進行換頁時，忽略畫面的查詢條件
			if(this.getIsBtnQuery().equals("no")){
				this.setQueryCondition((Map)getSessionMap().get(QUERY_CONDITION));
			}else{
				//當重新查詢時,初始化curren page 為1(表示第一頁)
				//初始化JumpPage為null
				this.getPageBean().setPage(1);
				this.getPageBean().setJumpPage(null);
			}

			Map queryCondition = getQueryCondition();

			//查詢結果
			this.setPageBean(this.getGfService().findStoreByQueryCondition(queryCondition, this.getPageBean()));
			this.getPageBean().setFormAction("storeFind");//表單action
			this.getPageBean().setToolsMenu(ViewPage.getToolsMenuByDefault(this.getPageBean()));

			//儲存查詢條件、結果
			getSessionMap().put(QUERY_CONDITION , queryCondition);
			getSessionMap().put(PAGE_BEAN, getPageBean());


		}catch(Exception e){
			e.printStackTrace();
			log.error(e);
			addActionError(e.getMessage());
		}
		return SUCCESS;
	}

	public String save(){
		log.info(">>>>>>>>>>>>>>>> to Save! ");

		result = new HashMap<String,String>();
		result.put(Action.SUCCESS, "Y");
		result.put("msg", "ok");

		try{
			transferOP(getGift(),getAllot());
			this.getGfService().saveGfitStore(getGift(), getAllot());
		}catch(Exception e){
			e.printStackTrace();
			result.put(Action.SUCCESS, "N");
			result.put("msg", "error");
		}
		return "result";
	}

	public String exit(){
		//清除舊的session值
		setGift(null);
		setAllot(null);
		super.exitProc();
		return SUCCESS;
	}

	public void transferOP(GfGift gift,List<GfGiftAllot> allotList){
		gift.setCreateTime(new Date());
		gift.setCreator(this.getUser().getUserId());
		gift.setCreatorName(this.getUser().getUserName());
		gift.setModifyTime(new Date());
		gift.setModifier(this.getUser().getUserId());
		gift.setModifierName(this.getUser().getUserName());
		log.info(">>>>> gift : "+ gift);

		if(allotList!=null && allotList.size()>0){
			for(GfGiftAllot allot:allotList){
				log.info(">>>> allot: "+allot);
				allot.setCreateTime(gift.getCreateTime());
				allot.setCreator(gift.getCreator());
				allot.setCreatorName(gift.getCreatorName());
				allot.setModifyTime(gift.getModifyTime());
				allot.setModifier(gift.getModifier());
				allot.setModifierName(gift.getModifierName());
			}
		}
	}
}
