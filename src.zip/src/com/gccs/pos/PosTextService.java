package com.gccs.pos;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.AppContext;

/**
 * <b></b>
 * @author kaychen
 * @Date: 2010/1/22 上午 10:28:57
 * @Project Name: RFEP
 */
public class PosTextService {
	private static final Logger log = LogManager.getLogger("batchJob.PosTextService") ;
	private static String[] beanNames = null ;
	private String fromTo;
	
	public String getFromTo() {
		return fromTo;
	}

	public void setFromTo(String fromTo) {
		this.fromTo = fromTo;
	}

	//TYPES,must be the same as bean ids in config file 
	public static final String _member_card_generator = "memberCardTextGenerator" ;
	
	public static String[] getBeanNames() {
		if (beanNames==null){
			beanNames = AppContext.getAppContext().getBeanNamesForType(AbstractPosTextGenerator.class);
		}
		return beanNames;
	}

	public static void setBeanNames(String[] beanNames) {
		PosTextService.beanNames = beanNames;
	}

	public void send() throws Exception {
		boolean hasThrowException = false ;
		for (int i = 0; i < getBeanNames().length; i++) {
			String name = getBeanNames()[i] ;
			log.info("[PosTextService] Task "+name+" launched.") ;
			AbstractPosTextGenerator task = (AbstractPosTextGenerator)AppContext.getBean(name) ;
			try {
				long l1 = System.currentTimeMillis() ;
				task.doTransferToPos() ;
				long l2 = System.currentTimeMillis() ;
				log.info("[PosTextService] "+name+" time cost : "+((l2-l1)/1000)+" sec.") ;
			} catch (Exception e) {
				log.error(e.getMessage(),e) ;
				hasThrowException = true ;
			}
		}
		if(hasThrowException) {
			throw new Exception("Error occurred,please check the log file to see more information.") ;
		}
	}
	
	public void send(String type) throws Exception {
		for (int i = 0; i < getBeanNames().length; i++) {
			String name = getBeanNames()[i] ;
			if(name.equals(type)) {
				log.info("[PosTextService] Task "+name+" launched.") ;
				AbstractPosTextGenerator task = (AbstractPosTextGenerator)AppContext.getBean(name) ;
				try {
					long l1 = System.currentTimeMillis() ;
					if("1".equals(getFromTo())&&"MPMST".equals(name)) task.setFromTo("1");
					task.doTransferToPos() ;
					long l2 = System.currentTimeMillis() ;
					log.info("[PosTextService] "+name+" time cost : "+((l2-l1)/1000)+" sec.") ;
					break ;
				} catch (Exception e) {
					e.printStackTrace();
					log.error(e.getMessage(),e) ;
					throw e ;
				}
			}
		}
	}

	public void create(String type) throws Exception {
		for (int i = 0; i < getBeanNames().length; i++) {
			String name = getBeanNames()[i] ;
			if(name.equals(type)) {
				log.info("[createMpJob] Task "+name+" launched.") ;
				AbstractPosTextGenerator task = (AbstractPosTextGenerator)AppContext.getBean(name) ;
				long l1 = System.currentTimeMillis();
				if ("1".equals(getFromTo()) && "MPMST".equals(name)) {
					task.setFromTo("1");
				}
				task.doTransfer();
				long l2 = System.currentTimeMillis();
				log.info("[createMpJob] " + name + " time cost : " + ((l2 - l1) / 1000) + " sec.");
				break;
			}
		}
	}

}
