package com.gccs.pos;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.ftp.FileUtils;
import com.bnq.util.ftp.FtpConfig;
import com.bnq.util.ftp.FtpFacade;
import com.bnq.util.ftp.dao.hibernate.FtpConfigDao;
import com.bnq.util.ftp.model.SysFtpconfigCompany;

import freemarker.template.utility.StringUtil;

/**
 * <b></b>
 * @author kaychen
 * @Date: 2010/1/22 上午 10:20:29
 * @Project Name: RFEP
 */
public abstract class AbstractPosTextGenerator {
	
	private static final Logger log = LogManager.getLogger(AbstractPosTextGenerator.class);
	
	private String beanId;
	private String FileName;
	protected FtpConfigDao ftpDao;
	protected String _defaultln = FileUtils._defaultln;
	protected String _defaultPath = FileUtils._defaultPath;
	protected String _defaultExt = FileUtils._defaultExt;
	protected String _encode = "MS950";
	protected String _encode1 = "UTF8";
	private String fromTo;
	private Map map;
	
	public String getFromTo() {
		return fromTo;
	}

	public void setFromTo(String fromTo) {
		this.fromTo = fromTo;
	}


	private String storeId;
	
	public FtpConfigDao getFtpDao() {
		return ftpDao;
	}

	public void setFtpDao(FtpConfigDao ftpDao) {
		this.ftpDao = ftpDao;
	}

	public String getFileName() {
		return FileName;
	}

	public void setFileName(String fileName) {
		FileName = fileName;
	}

	/** 產出專業卡(企業卡)報表
	 * @return
	 * @throws Exception
	 */
	protected abstract File createTextFile() throws Exception ;
	
//	protected abstract File createVipSvipTextFile() throws Exception;
	
	/** 產出專業卡(企業卡)報表
	 * @param local path
	 * @param 公司代碼
	 * @return
	 * @throws Exception
	 */
	protected abstract File createTextFile(String path,String companyId) throws Exception ;
	
	public String getBeanId() {
		return beanId;
	}

	public void setBeanId(String beanId) {
		this.beanId = beanId;
	}
	
	/**
	 * 傳回DB預設的path
	 * @return
	 * @throws Exception
	 */
	public String geTempPath()throws Exception{
		List<FtpConfig> ftpConfigList = getFtpAddress();
		if (ftpConfigList!=null && ftpConfigList.size()>0){	
			String path = (StringUtils.isNotBlank(ftpConfigList.get(0).getDownload_path())? ftpConfigList.get(0).getDownload_path():_defaultPath);
			// String path = _defaultPath;
			if(!path.endsWith("/")) {
				return path+"/" ;
			}
		}
		return _defaultPath;
	}

	/**
	 * 建立FtpConfig，需assign serverIp、port、loginId、loginPassword、snd_awaiting_path
	 * @return FtpConfig List
	 * @throws Exception
	 */
	protected List<FtpConfig> getFtpAddress() throws Exception {
		if (StringUtils.isNotBlank(beanId)){
			List<FtpConfig>  ftpConfigList = ftpDao.loadConfig(beanId);
			return ftpConfigList;
		}
		return null;
	}
	
	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	@SuppressWarnings("rawtypes")
	public void doTransferToPos() throws Exception {
		List<FtpConfig> ftpConfigList = getFtpAddress();
		if (ftpConfigList != null && ftpConfigList.size() > 0) {
			switch (Integer.parseInt(ftpConfigList.get(0).getFtp_company_Type())) {
			case 1:
				doTransferToPosDefault(ftpConfigList);
				break;
			default:
				map = new HashMap();
				List<SysFtpconfigCompany> templist = ftpDao.loadConfigByCompany(ftpConfigList.get(0).getOid());
				if(templist==null || templist.size()==0)
					log.error("search sys_ftpconfig_company not data : " + getBeanId());
				for (SysFtpconfigCompany sysFtpconfigCompany : templist) {
					doTransferToPosGroup(sysFtpconfigCompany,ftpConfigList.get(0).getFtp_company_Type());
				}
				break;
			}
		}
	}

	@SuppressWarnings("rawtypes")
	public void doTransfer() throws Exception {
		List<FtpConfig> ftpConfigList = getFtpAddress();
		if (ftpConfigList != null && !ftpConfigList.isEmpty()) {
			switch (Integer.parseInt(ftpConfigList.get(0).getFtp_company_Type())) {
			case 1:
				doTransferDefault(ftpConfigList);
				break;
			default:
				map = new HashMap();
				List<SysFtpconfigCompany> templist = ftpDao.loadConfigByCompany(ftpConfigList.get(0).getOid());
				if(templist == null || templist.isEmpty())
					log.error("createMpJob search sys_ftpconfig_company not data : " + getBeanId());
				for (SysFtpconfigCompany sysFtpconfigCompany : templist) {
					doTransferGroup(sysFtpconfigCompany,ftpConfigList.get(0).getFtp_company_Type());
				}
				break;
			}
		}
	}
	
	public void doTransferToPosDefault(List<FtpConfig> ftpConfigList) throws Exception {
		File file = this.createTextFile();
		for (FtpConfig config : ftpConfigList) {
			FtpFacade facade = new FtpFacade(config.getServerIp(), config
					.getPort(), config.getLoginId(), config
					.getLoginPassword());
			facade.sendToRemotePath(file, config.getSnd_awaiting_path());
		}
	}
	
	public void doTransferDefault(List<FtpConfig> ftpConfigList) throws Exception {
		createTextFile();
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void doTransferToPosGroup(SysFtpconfigCompany config,String type) throws Exception {
		File file = null;
		if("2".equals(type)){
			file = this.createTextFile(config.getDownloadPath(),config.getCompanyId());
		}else{			
			if(map.get("downloadpath")==null){
				file = this.createTextFile(config.getDownloadPath(),"");
				map.put("downloadpath", config.getDownloadPath());
			}else{
				String fromPath = "";
				if(!((String)map.get("downloadpath")).endsWith("/")){
					fromPath = (String)map.get("downloadpath")+"/" ;
				}else{
					fromPath = (String)map.get("downloadpath");
				}
				String toPath = "";
				if(!config.getDownloadPath().endsWith("/")){
					toPath = config.getDownloadPath()+"/" ;
				}else{
					toPath = config.getDownloadPath();
				} 
				file = new File(fromPath+getBeanId()+_defaultExt);
				FileUtils.copy(file, new File(toPath+getBeanId()+_defaultExt));
			}
		}
		FtpFacade facade = new FtpFacade(config.getServerIp(), config
					.getPort(), config.getLoginId(), config
					.getLoginPassword());
		facade.sendToRemotePath(file, config.getSndPath());
	}
	
	@SuppressWarnings({ "unchecked" })
	public void doTransferGroup(SysFtpconfigCompany config,String type) throws Exception {
		File file = null;
		if("2".equals(type)){
			file = this.createTextFile(config.getDownloadPath(),config.getCompanyId());
		}else{			
			if(map.get("downloadpath")==null){
				file = this.createTextFile(config.getDownloadPath(),"");
				map.put("downloadpath", config.getDownloadPath());
			}else{
				String fromPath = "";
				if(!((String)map.get("downloadpath")).endsWith("/")){
					fromPath = (String)map.get("downloadpath")+"/" ;
				}else{
					fromPath = (String)map.get("downloadpath");
				}
				String toPath = "";
				if(!config.getDownloadPath().endsWith("/")){
					toPath = config.getDownloadPath()+"/" ;
				}else{
					toPath = config.getDownloadPath();
				} 
				file = new File(fromPath+getBeanId()+_defaultExt);
				FileUtils.copy(file, new File(toPath+getBeanId()+_defaultExt));
			}
		}
	}
	

	protected String createString(String data,int digit) {
		int length = data.getBytes().length ;
		if(length > digit) {
			StringBuffer sb = new StringBuffer() ;
			for (int i = 0; i < data.length(); i++) {
				char c = data.charAt(i) ;
				String temp = String.valueOf(c) ;
				if((sb.toString().getBytes().length + temp.getBytes().length) <= digit) {
					sb.append(temp) ;
				}else{
					data = sb.toString() ;
					break ;
				}
			}
		}
		int pad = digit - (data.getBytes().length) + 1 ;
		return StringUtil.rightPad(data, pad) ;
	}
	
}
