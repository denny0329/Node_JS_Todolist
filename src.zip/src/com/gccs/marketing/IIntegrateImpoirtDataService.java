package com.gccs.marketing;

import java.io.File;
import java.util.List;
import java.util.Map;

import com.bnq.sc.model.ScSysuser;
import com.bnq.util.QueryResult;
import com.gccs.marketing.model.IntegrateImpoirtData;
import com.gccs.marketing.model.MtDmSendlog;
import com.gccs.marketing.model.vo.MtPosVipVo;
import com.rfep.nm.model.NmProduce;

public interface IIntegrateImpoirtDataService {
	public int createSMMLog(Integer snNo, File file, String fileFileName, String oid, NmProduce nmProduce, String creator, Integer cvsCount) throws Exception;
	public int createMtDmSendLog(File file, String fileFileName, MtDmSendlog mtDmSendlog, String sortNo) throws Exception;
	public int createMtPosVip(ScSysuser user, MtPosVipVo hbmObject) throws Exception;
	public int createBonusLog(Map parMap, String fileFileName, File file) throws Exception;
	public String initBatch()throws Exception;
	public String initBatchForSMM(Integer snNo)throws Exception;
	public String initBatchForAmountChange(Integer snNo)throws Exception;
	public void executeBatch(String program,String seqNO) throws Exception;
	public void sendMail(String seqNo) throws Exception;
	public void sendEmail() throws Exception;
	public void cleanImportData() throws Exception;
	public QueryResult queryByCondition(Map queryCondition, int queryStartIndex, int pageSize, boolean hasToCountTotal) throws Exception;
	public void execute912Batch(Integer snNo) throws Exception;
	public void execute9034Batch(String[] snNos) throws Exception;
	public List<IntegrateImpoirtData> qrySmm();
	//public List<IntegrateImpoirtData> qryAmountChange();
}
