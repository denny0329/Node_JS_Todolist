package com.gccs.marketing;

import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.bnq.util.PageBean;
import com.bnq.util.QueryResult;
import com.gccs.bc.model.BcExchangeStore;
import com.gccs.marketing.model.DiscountSku;
import com.gccs.marketing.model.FilterMarketNotice;
import com.gccs.marketing.model.MtDmSendlog;
import com.gccs.marketing.model.MtGroup;
import com.gccs.marketing.model.PromotionFilter;
import com.gccs.marketing.model.condition.DiscountCondition;
import com.gccs.marketing.model.condition.MtGroupCondition;
import com.gccs.marketing.model.condition.PromotionFilterCondition;
import com.gccs.marketing.model.vo.DiscountSkuAccountVo;
import com.gccs.marketing.model.vo.DiscountSkuVo;
import com.gccs.marketing.model.vo.DiscountVo;
import com.gccs.marketing.model.vo.MtGroupVo;
import com.gccs.marketing.model.vo.MtPosVipMasterVo;
import com.gccs.marketing.model.vo.MtPosVipVo;
import com.gccs.marketing.model.vo.PromotionFilterVo;
import com.gccs.marketing.model.vo.PromotionGroupVo;
import com.gccs.member.model.Account;

/**
 * <b></b>
 * @author kaychen
 * @Date: 2010/1/19 下午 4:05:17
 * @Project Name: RFEP
 */
public interface IMarketingService {
	/**
	 * 查詢DiscountSku Seq最大值
	 * @param refOid
	 * @return
	 * @throws Exception
	 */
	public int findDiscountSkuMaxSeq(final String refOid)throws Exception;
	
	/**
	 * 依分頁條件查詢DiscountSku
	 * @param refOid
	 * @param index
	 * @param pageSize
	 * @return
	 */
	public QueryResult findDiscountSkuByCondition(final String refOid,final int index,final int pageSize,String cid)throws Exception;
	/**
	 * 依分頁條件查詢DiscountSku
	 * @param queryCondition
	 * @param inPageBean
	 * @return
	 * @throws Exception
	 */
	public PageBean findDiscountSkuByCondition(Map queryCondition,PageBean inPageBean) throws Exception;
	

	/**
	 * 儲存DiskcountSku
	 * @param oldDiscountSkuList
	 * @param newDiscountSku
	 * @throws Exception
	 */
	public void saveDiscountSkus(final List<DiscountSku>oldDiscountSkuList,final List<DiscountSku>newDiscountSkuList)throws Exception;
	
	/**
	 * 儲存DiskcountSku
	 * @param vo
	 * @param userId
	 * @param userName
	 * @param refOid
	 * @param addDiscountSkuList
	 * @param updDiscountSkuList
	 * @param delDiscountSkuList
	 * @throws Exception
	 */
	public void saveDiscount(final DiscountVo vo,String userId,String userName,String refOid,List <DiscountSkuVo> addDiscountSkuVoList,List<DiscountSkuVo> updDiscountSkuVoList,List<DiscountSkuVo> delDiscountSkuVoList) throws Exception ;
	
	/**
	 * 生效
	 * @param vo
	 * @param userId
	 * @param userName
	 * @param refOid
	 * @param addDiscountSkuVoList
	 * @param updDiscountSkuVoList
	 * @param delDiscountSkuVoList
	 * @throws Exception
	 */
	public void activateDiscount(DiscountVo vo,String userId,String userName,String refOid,List <DiscountSkuVo> addDiscountSkuVoList,List<DiscountSkuVo> updDiscountSkuVoList,List<DiscountSkuVo> delDiscountSkuVoList) throws Exception; 
	/**
	 * 停用
	 * @param vo
	 * @param userId
	 * @param userName
	 * @param refOid
	 * @param addDiscountSkuVoList
	 * @param updDiscountSkuVoList
	 * @param delDiscountSkuVoList
	 * @throws Exception
	 */
	public void passivateDiscount(DiscountVo vo,String userId,String userName,String refOid,List <DiscountSkuVo> addDiscountSkuVoList,List<DiscountSkuVo> updDiscountSkuVoList,List<DiscountSkuVo> delDiscountSkuVoList) throws Exception ;
	/**
	 * 刪除DiscountSku by refOid
	 * @param refOid
	 * @throws Exception
	 */
	public void deleteDiscountByRefOid(final String refOid);
	
	/**
	 * 刪除DiscountSku by Boid
	 * @param oid
	 */
	public void deleteDiscountSkuByOid(final String[] oid);
	
	/**
	 * saveGroup
	 * @param vo
	 * @param userId
	 * @param userName
	 * @param refOid
	 * @param addDiscountSkuVoList
	 * @param updDiscountSkuVoList
	 * @param delDiscountSkuVoList
	 * @throws Exception
	 */
	public void saveGroup(MtGroupVo vo,String userId,String userName,String refOid,List <DiscountSkuVo> addDiscountSkuVoList,List<DiscountSkuVo> updDiscountSkuVoList,List<DiscountSkuVo> delDiscountSkuVoList) throws Exception ;
	
	/**
	 * savePromotionFilter
	 * @param vo
	 * @param notice
	 * @param store
	 * @param userId
	 * @param userName
	 * @param refOid
	 * @param addDiscountSkuVoList
	 * @param updDiscountSkuVoList
	 * @param delDiscountSkuVoList
	 * @throws Exception
	 */
	public void savePromotionFilter(final PromotionFilterVo vo,final Set<FilterMarketNotice> notice,final Set<BcExchangeStore> store,final String userId,final String userName,String refOid,List <DiscountSkuVo> addDiscountSkuVoList,List<DiscountSkuVo> updDiscountSkuVoList,List<DiscountSkuVo> delDiscountSkuVoList)throws Exception ;


	/**
	 * 複製折扣卡
	 * @param oid 被複製折扣卡OID
	 * @param userId
	 * @param userName
	 * @throws Exception
	 */
	public String copyDiscount(String oid) throws Exception ;

	public void saveDiscount(final DiscountVo vo,String userId,String userName) throws Exception ;

	public void activateDiscount(DiscountVo vo,String userId,String userName) throws Exception ;

	public void passivateDiscount(DiscountVo vo,String userId,String userName) throws Exception ; 
	 
	public void passivateDiscount(String oid,String userId,String userName) throws Exception ; 

	public void replaceMmCardDiscountOidForEmployeeDay(DiscountVo vo,String userId,String userName) throws Exception  ;
	
	public void passivateMmCard(DiscountVo vo,String userId,String userName) throws Exception ;
	
	public DiscountVo getDiscountVoByOid(String oid,boolean joinChannel,boolean joinSku) throws Exception ;
	
	public DiscountVo getDiscountVoByOid(String oid) throws Exception ;
	
	public QueryResult getDiscountList(DiscountCondition condition,int startRows,int rows,boolean countFlag) throws Exception ;
	
	public void saveGroup(MtGroupVo vo,String userId,String userName) throws Exception ;
	
	public void activateGroup(MtGroupVo vo,String userId,String userName) throws Exception ;
	
	public void passivateGroup(MtGroupVo vo,String userId,String userName) throws Exception ;
	
	public MtGroupVo getGroupVoByCondition(MtGroupCondition condition) throws Exception ;
	
	public QueryResult getGroupList(MtGroupCondition condition,int startRows,int rows,boolean countFlag) throws Exception ; 
	
	public String getNotEmployeeDayDiscountOid(String cardType,String companyId) ;
	
	public QueryResult findDiscountSkuByCondition(final String refOid,final int index,final int pageSize,final List<String> channelList,String cid)throws Exception ;
	
	public List queryClassMappedName(String deptId,String subDeptId,String classId,String subClassId)throws Exception ;

 	public Map<String, Object> insertMtDmSendlogByVipNoList(final List<String> vipNoList, final MtDmSendlog input) throws Exception; 
	
 	public QueryResult getFilterList(PromotionFilterCondition condition,int startRows,int rows,boolean countFlag) throws Exception ; 
		
	public void savePromotionFilter(final PromotionFilterVo vo,final Set<FilterMarketNotice> notice,final Set<BcExchangeStore> store,final String userId,final String userName) ; 
	
	public void activatePromotionFilter(PromotionFilterVo vo,Set<FilterMarketNotice> notice,Set<BcExchangeStore> store,final String userId,final String userName) ;
	
	public void passivatePromotionFilter(PromotionFilterVo vo,Set<FilterMarketNotice> notice,Set<BcExchangeStore> store,final String userId,final String userName) ;

	/**
	 * query Account exists discountSku
	 * @param vo : 欲查詢之條件
	 * @param index : 起始筆數
	 * @param rows : 總筆數
	 * @param countTotal : true:查詢總筆數,false:查詢詳細資料
	 * @return QueryResult : 查詢結果
	 * @throws Exception
	 * @author JL
	 */
	public QueryResult getQueryList(DiscountSkuAccountVo vo,int index,int rows,boolean countTotal,boolean lazy) throws Exception ;

	/**
	 * execute discountSku status = 0;
	 * @param delAccountOid
	 * @param userId
	 * @param userName
	 * @return
	 * @throws Exception
	 * @author JL
	 */
	public Integer delDiscountSkuAccount(final String[] delAccountOid,final DiscountSkuAccountVo vo,final String userId,final String userName)throws Exception ;


	/**
	 * insert discountSkuAccount
	 * @param hbmObject
	 * @param detailList
	 * @throws Exception
	 */
	public List<DiscountSkuAccountVo> insertDiscountSkuAccount(final DiscountSkuAccountVo hbmObject,List<DiscountSkuAccountVo> detailList,final String userId,final String userName)throws Exception ;
	
	public PromotionFilter getPromotionFilterByCondition(PromotionFilterCondition condition) throws Exception ;

	
	/**
	 * query distinct MtPosVipNo
	 * @param vo : 欲查詢之條件
	 * @param index : 起始筆數
	 * @param rows : 總筆數
	 * @param countTotal : true:查詢總筆數,false:查詢詳細資料
	 * @return QueryResult : 查詢結果
	 * @throws Exception
	 * @author JL
	 */
	public QueryResult getQueryList(MtPosVipVo vo,int index,int rows,boolean countTotal) throws Exception ;


	/**
	 * 檔案批次匯入
	 * @author JL
	 * @param hbmObject
	 * @param userId
	 * @param userName
	 * @param sysdate
	 * @throws Exception
	 */
	public Map<String, Object> saveMtPosVipProcessUpload(final MtPosVipVo hbmObject,final String userId,final String userName)throws Exception ;


	/**
	 * create MtPosVipEx
	 * @author JL
	 * @param exceptionId
	 * @param exportId
	 * @param groupId
	 * @param vipNo
	 * @param personId
	 * @param activateDate
	 * @param passivateDate
	 * @param transDay
	 * @param groupName
	 * @param memberName
	 * @param userId
	 * @param userName
	 * @param sysdate
	 * @throws Exception
	 */
	public void prcoessMtPosVipUpload(Integer exceptionId,String exportId,String groupId,String vipNo,String personId,Date activateDate,Date passivateDate,Integer transDay,String groupName,String memberName,String userId,String userName,Date sysdate)throws Exception ;

	/**
	 * create MtPosVipEx
	 * @author JL
	 * @param exportId
	 * @param groupId
	 * @param vipNo
	 * @param personId
	 * @param activateDate
	 * @param passivateDate
	 * @param transDay
	 * @param groupName
	 * @param memberName
	 * @param userId
	 * @param userName
	 * @param sysdate
	 * @throws Exception
	 */
	public void prcoessMtPosVipUpload(String exportId,String groupId,String vipNo,
			String personId,Date activateDate,Date passivateDate,Integer transDay,String groupName,
			String memberName,String userId,String userName,Date sysdate,String memberId)throws Exception ;
	
	public String createPosVip(String xml,String user,String userName) throws Exception ;
	
	public String queryPosVip(String xml) throws Exception ;

	/**
	 * @author JL
	 * @param vo
	 * @return
	 * @throws Exception
	 */
	public List<MtGroup> queryMtGroup(MtGroupVo vo)throws Exception ;
	
	public void createPosVip(Date transDate)  ;

	/**
	 * @author JL
	 * @param exportId
	 * @param index
	 * @param rows
	 * @param countTotal
	 * @return
	 * @throws Exception
	 */
	public QueryResult getMtPosVipQueryList(String exportId,int index,int rows,boolean countTotal) throws Exception ; 

	/**
	 * @author JL
	 * @param exportId
	 * @param index
	 * @param rows
	 * @param countTotal
	 * @return
	 * @throws Exception
	 */
	public QueryResult getMtPosVipExQueryList(String exportId,int index,int rows,boolean countTotal) throws Exception ; 

	
	/**
	 * query detail 
	 * @param groupId
	 * @return
	 * @throws Exception
	 */
	public MtPosVipMasterVo queryMtPosVipMasterVo(String exportId)throws Exception ;

	/**
	 * 刪除
	 * @author JL
	 * @param moveOid
	 * @throws Exception
	 */
	public void moveMtPosVip(String[] moveOid,String[] exportId)throws Exception ;

	/**
	 * insert discountSkuAccount
	 * @author JL
	 * @param hbmObject
	 * @param detailList
	 * @throws Exception
	 */
	public String insertDiscountSkuAccount(final DiscountSkuAccountVo hbmObject,File file,final String userId,final String userName)throws Exception ;

	/**
	 * for insert discountSkuAccount trans
	 * @author JL
	 * @param hbmObject
	 * @param account
	 * @throws Exception
	 */
	public void insertDiscountSkuAccountTrans(final DiscountSkuAccountVo hbmObject,final Account account)throws Exception ;

	/**
	 * 2064-商務會員卡折扣設定(匯入功能)
	 * @author JL
	 * @param hbmObject
	 * @param file
	 * @param userId
	 * @param userName
	 * @return
	 * @throws Exception
	 */
	public String importProcessDiscount(DiscountVo hbmObject, File file, String userId, String userName, String executeType)throws Exception;
	
	/**
	 * 取得當日活動生效中之活動及會員卡號資訊
	 * @param date 活動日期
	 * @return List of PromotionGroupVo
	 * @throws Exception
	 */
	public List<PromotionGroupVo> getPromotionGroupListByDate(Date date, String custNos, boolean joinVip) throws Exception ;
	public List<PromotionGroupVo> getPromotionGroupListByDate(Date date, String custNos, boolean joinVip, boolean includeCompanyId) throws Exception ;
	
	/**
	 * 取得當日活動生效中之活動及會員卡號資訊
	 * @param date 活動日期
	 * @return List of PromotionGroupVo
	 * @throws Exception
	 */
	public List<PromotionGroupVo> getPromotionGroupList(Date date, String custNos, boolean joinVip) throws Exception ;
	public List<PromotionGroupVo> getPromotionGroupList(Date date, String custNos, boolean joinVip, boolean includeComapnyId) throws Exception ;
	
	/**
	 * 判斷VIPNO是否於TransDate日存在於Group中
	 * @param groupId 群組代碼
	 * @param transDate 交易日期
	 * @param vipNo 會員卡號
	 * @return 存在:True , 不存在:False
	 * @throws Exception
	 */
	public boolean isGroupContainVip(String groupId,Date transDate,String vipNo) throws Exception ;
	
	/**
	 * 匯入 MT_DISCOUNT_SKU
	 * @author JL
	 * @param file
	 * @param refOid
	 * @param userId
	 * @param userName
	 * @return
	 * @throws Exception
	 */
	public String saveMtDiscountSkuProcessUpload(File file, String refOid, String userId, String userName, String executeType)throws Exception;
	
	/**
	 * 依輸入的卡別取得預設的折扣卡設定(除商務卡(cardType=1)皆可用, 商務卡需由商務帳號取得Discount)
	 * @param cardType 
	 * @return
	 */
	public DiscountVo getDefaultDiscountByCardType(int cardType);
}
