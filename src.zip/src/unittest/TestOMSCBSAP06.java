package unittest;


import java.util.Date;

import junit.framework.TestCase;

import org.apache.commons.lang.time.DateUtils;

import com.rfep.dataex.cb.outbound.OMSCBSAP06;

/**
 * OMS合營月結採購驗收資料拋轉SAP
 * </p>
 * (合營銷售月結作業)
 * 
 * @author leo.tu
 * @date 2012-07-19
 */
public class TestOMSCBSAP06 extends TestCase {

	@Override
	protected void setUp() throws Exception {
		super.setUp();
	}

	public void testOMSCBSAP06() {
		OMSCBSAP06 oms = new OMSCBSAP06();
		Date yearMonth = DateUtils.addMonths(new Date(), -1); 
		System.out.println("yearMonth=" + yearMonth);
		
		oms.execute();
	}
}
