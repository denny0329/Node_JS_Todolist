package unittest;



import junit.framework.TestCase;

import com.trg.oms.utils.service.SftpServerInfoEnum;
import com.trg.oms.utils.service.SftpService;

public class TestSftpService extends TestCase{
	public void testSendSftpFileName() {
        SftpService sftp = new SftpService();
        try {
        	sftp.setType(SftpServerInfoEnum.SEQ_1);
			sftp.sendByFileName("TEST","C:/oradata/oms/queue/sftp/abc.txt");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
	
}
