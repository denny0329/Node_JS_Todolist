package unittest;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.rfep.util.db.RfepConnUtil;
public class BcCodeTo {
	protected static final Logger log = LogManager.getLogger("dataex");
	
	
	//BS_CODE  手動轉入
	public static void main(String[] args) throws IOException{
		Connection conn = null;
		PreparedStatement psInsert = null;
		try{
			StringBuffer insertSql = new StringBuffer();
			insertSql.append("INSERT INTO RFEPDBA.BS_CODE(CODE_CLASS,CODE_NO,CODE_EXPLAIN," +
					"CLASS_EXPLAIN,PARENT_CODE_CLASS,PARENT_CODE_NO,SAP_KEY," +
					"CODE_STATUS,CREATE_TIME,CREATOR,CREATOR_NAME,MW_FLAG,MW_TIME) " +
					    " VALUES(?,?,?,?,?,?,?,'1',SYSDATE,'MW','MW','1',SYSDATE)");
		
			conn = RfepConnUtil.getConnection();	
			psInsert = conn.prepareStatement(insertSql.toString());
			
			
			
		List<String> list = FileUtils.readLines(new File(("E:/RFEP2/bsCode/mm代碼檔.txt")));
		for (String string : list) {
			String[] sa = string.split("\t", -1) ;
			String codeClass=sa[5];
			String code01 = sa[1];
			String codeN = sa[3];
			String classE = sa[8];
			String parentCodeClass = sa[9];
			String parantCodeNo = sa[10];
			String sapKey = sa[11];
			/*
			if(codeClass.equals("FD")){	
				System.out.println("第"+"項  "+codeClass+"-"+code01+"-"+codeN+"-"+classE +"-"+ parentCodeClass+"-"+ parantCodeNo+"-"+ sapKey);
				}
				*/
			/*已插入 *ZFRDL  AUREL  BANPR BANST BLCKD  EKGRP 
			 * EKORG    ESTKZ  *INSMK PRMOD RDTX SLINA T002T
			 * T016T T027B T035T T077Y T156T T161T T163M T438T
			 * T6WST TBSGT TMABC TMBWT TPFKT TSABT TSACT TVAVT
			 * TVBRT TVIPT TVPVT TWLVT TWPTT TWYAZ UC URZTP
			 * ZABFG ZBTCH ZBUYC ZDCXD ZDELF ZFRDL ZINST ZMESU
			 * ZRPCK ZSPEC ZSPOD ZTM26 ZTM27 ZTM28
			 * 
			 * PT
			 * 待確認      T157E   T16FD
			 * */
			
			//選擇條件~~~
			if(codeClass.equals("ZTM28")){
			
				psInsert.setString(1, sa[5]);
			if (StringUtils.isEmpty(sa[1])) {
				psInsert.setString(2,"0");
			}
			else{
				psInsert.setString(2, sa[1] );
			}
			psInsert.setString(3, sa[3]);
			psInsert.setString(4, sa[8]);
			psInsert.setString(5, sa[9]);
			psInsert.setString(6, sa[10]);
			psInsert.setString(7, sa[11]);
						
			psInsert.executeUpdate();
			
			}
		}
		
		}
		catch (Exception e)
		{
		e.printStackTrace();
		log.error(e.getMessage(),e);
		}  finally {
			try {
				psInsert.close() ;
				conn.close();
			} catch (Exception e2) {
			}
		}
	}
	
	
}
