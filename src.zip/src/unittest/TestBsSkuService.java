package unittest;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.product.bs.dao.hibernate.PdSkuDao;
import com.rfep.product.bs.model.BsSkuChannelPermission;
import com.rfep.product.bs.service.PdSkuService;

public class TestBsSkuService extends TestCase{
	PdSkuService service = null;
	PdSkuDao pdSkuDao = null;
	
	@Override
	protected void setUp() throws Exception {
		service = (PdSkuService)AppContext.getBean("pdService");
		pdSkuDao = (PdSkuDao)AppContext.getBean("pdSkuDao");
		super.setUp();
	}
	
	public void testSkuStoreChannelPermission()throws Exception{
		String channelId = "TLW";
		String titleId = "T0009";
		Integer typeId = 0;
		try{
		
		BsSkuChannelPermission bscPermission = new BsSkuChannelPermission();
		
		bscPermission.setChannelId(channelId);
		bscPermission.setTitleId(titleId);
		bscPermission.setTypeId(typeId);
		pdSkuDao.insertObject(bscPermission);
		
		BsSkuChannelPermission bscPermission2 = new BsSkuChannelPermission();
		
		bscPermission2.setChannelId(channelId);
		bscPermission2.setTitleId("T0011");
		bscPermission2.setTypeId(typeId);
		pdSkuDao.insertObject(bscPermission2);
		
		BsSkuChannelPermission bscPermission3 = new BsSkuChannelPermission();
		
		bscPermission3.setChannelId(channelId);
		bscPermission3.setTitleId("T0010");
		bscPermission3.setTypeId(typeId);
		pdSkuDao.insertObject(bscPermission3);
		}catch(Exception e){
			System.out.println(" Exception e: " + e);
		}
	}
}