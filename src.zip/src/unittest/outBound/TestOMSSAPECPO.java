package unittest.outBound;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.util.sys.dao.SysJobDao;
import com.trg.oms.dataex.outbound.OMSSAPECPO;
import com.trg.oms.utils.dao.SysInfoDao;

public class TestOMSSAPECPO extends TestCase {
	
	public void testFile() {
		try {
			SysJobDao sysJobDao=(SysJobDao)AppContext.getBean("sysJobDao");
			SysInfoDao sysInfoDao=(SysInfoDao)AppContext.getBean("sysInfoDao");
			OMSSAPECPO omsSap=new OMSSAPECPO();
			omsSap.setSysInfoDao(sysInfoDao);
			omsSap.setSysJobDao(sysJobDao);
			omsSap.execute();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
