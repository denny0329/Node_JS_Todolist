package unittest.outBound;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.util.sys.dao.SysJobDao;
import com.trg.oms.dataex.outbound.OMSECONYPO;

public class TestOMSECONYPO extends TestCase {
	
	public void testFile() {
		try {
			SysJobDao sysJobDao=(SysJobDao)AppContext.getBean("sysJobDao");
			OMSECONYPO omsSap=new OMSECONYPO();
			omsSap.setSysJobDao(sysJobDao);
			omsSap.execute();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
