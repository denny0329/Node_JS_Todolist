package unittest;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.trg.oms.common.service.EMarkSftpSenderService;
import com.trg.oms.dataex.ftp.OMSPRODUCTLABEL;

public class TestOMSPRODUCTLABEL extends TestCase{
	
	private OMSPRODUCTLABEL omslabel;
	public void testTrfOMSPRODUCTLABEL(){
		omslabel = new OMSPRODUCTLABEL();
		omslabel.seteMarkSftpSenderService((EMarkSftpSenderService)AppContext.getBean("eMarkSftpSenderService"));
		omslabel.execute();
	}

}
