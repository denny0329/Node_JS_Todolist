/**
 * 
 */
package unittest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.bnq.util.AppContext;
import com.rfep.trans.model.TransBsPos;
import com.rfep.trans.service.TransBsService;
import com.rfep.ws.TransSequenceService;

/**
 * <b></b>
 * @author peipei
 * @Date: 2009/4/9 �U�� 7:01:03
 * @Project Name: BNQRFEP
 * @Package Name: unittest
 * @File Name: TestTransGuiNosPosService.java
 */
public class TestTransBsService extends TestCase {
	
	public void testFindAllTransBsPosByCannelIdAndStoreId(){
		TransBsService service = (TransBsService)AppContext.getBean("transBsService");
		
		Map queryCondition = new HashMap();
		queryCondition.put("channelId", new String[]{"H-OLT"});
		queryCondition.put("storeId", new String[]{"00601"});
		queryCondition.put("activate", new String[]{"1"});
		
		List<TransBsPos> tmpListGrid = service.findAllTransBsPosByCannelIdAndStoreId(queryCondition);
		System.out.println("size="+tmpListGrid.size());
		for(TransBsPos bo: tmpListGrid){
			System.out.println(ToStringBuilder.reflectionToString(bo));
		}
	}
	
	public void testGetTransSequenceWebServiceUrl(){
		try{
			TransSequenceService transSequenceService = TransBsService.getTransSequenceWebServiceUrl("TLW", "00700");
			String serial = transSequenceService.getReFundSequence("TLW", "00700");
			System.out.println("TLW 00700 =" + serial);
			serial = transSequenceService.getReFundSequence("HOLA", "00617");
			System.out.println("HOLA 00617 =" + serial);
		}
		catch (Exception ex){
			System.out.println(ex);
		}
	}
}
