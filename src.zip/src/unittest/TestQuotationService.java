/**
 * 
 */
package unittest;

import java.util.Set;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.so.model.CouponUsage;
import com.rfep.so.model.FreightItem;
import com.rfep.so.model.FreightRecord;
import com.rfep.so.model.InstallationFee;
import com.rfep.so.model.Negotiation;
import com.rfep.so.model.OrderGoods;
import com.rfep.so.model.Quotation;
import com.rfep.so.model.SkuStatistics;
import com.rfep.so.model.SoWorkType;
import com.rfep.so.service.QuotationService;

/**
 * <b></b>
 * @author peipei
 * @Date: 2009/4/9 �U�� 7:01:03
 */
public class TestQuotationService extends TestCase {
	QuotationService quotationService = null;
	
	@Override
	protected void setUp() throws Exception {
		quotationService = (QuotationService)AppContext.getBean("quotationService");
		super.setUp();
	}
	
	public void testGetQuotationByOid() throws Exception{
		String oid = null;
		//oid = "def8358dde8e48e884e4f35ca204a399";
		//oid = "e90797128d754005b7abaad1410e067d";
		//oid = "7514e647e62c49d6a1f6c6c787a42144";
		//oid = "7dfc10df13db45f09ac7dbb994e37875";
		//oid = "730abb9ad6974722abf1f9b07a541be2";
		oid = "cac787bc573545558e1c1f4d82b397b1";
		////oid = "9a2417398e9f48a6bb739de998d20991";
		//oid = "4b3539392fb84c5f8c0328ca4e21f2ac";
//		oid = "c075fa769cb949588ecb021a61bcf435";
//		oid = "c795bb56124d4edcadb5377391a67c94";
//		oid = "e90797128d754005b7abaad1mcje9bop";
//		oid = "71a36fc4b744438ebfa859b2ce3cc331";
		
		Quotation quotation = quotationService.getQuotationByOid(oid, true, true, true);
		System.out.println("CaseInfo="+quotation.getCaseInfo().getCaseCode());
		System.out.println("Forms="+quotation.getForms());
		SkuStatistics skuStatistics = quotation.getStatistics();
		System.out.println("Statistics=�ӫ~�p�p:"+skuStatistics.getSkuSubtotal());
		
		int i=0;
		System.out.println("==== WorkTypeSet ====");
		if(skuStatistics.getWorkTypeSet()!=null){
			for(SoWorkType workType : skuStatistics.getWorkTypeSet()){
				System.out.println(++i + "=>" + workType.getWorkType());
				
				int j=0;
				//���u��
				System.out.println("==== WorkTypeSet.OrderGoods ====");
				if(workType.getGoodsSet()!=null){
					for(OrderGoods goods : workType.getGoodsSet()){
						System.out.println(i+"."+ (++j) + "��=>" + goods.getSku());
						
						System.out.println("==== WorkTypeSet.InstallFeeRecord ====");
						Set<InstallationFee> installFees = goods.getInstallationFee();
						int m = 0;
						for(InstallationFee ifee : installFees){
							System.out.println("     ifee["+ ++m +"]===>" + ifee.getInstallationSku()+"/qty:"+ifee.getInstallationQty()+"/amt:"+ifee.getAmount());
							
							if(ifee.getCouponSet()!=null){
								for(CouponUsage cu : ifee.getCouponSet()){
									System.out.println("   couponNo=" + cu.getCouponNo()+"/qty:"+cu.getQty()+"/discount:"+cu.getDiscount());
								}
							}
						}
					}
				}
				
				j=0;
				System.out.println("==== WorkTypeSet.FreightRecord ====");
				FreightRecord freightRecord = workType.getFreightRecord();
				if(freightRecord!=null){
					System.out.println(i+"."+ (++j) + "[goods]=>");
//					if(freightRecord.getGoodsSet()!=null){
//						int m=0;
//						for(OrderGoods gd : freightRecord.getGoodsSet()){
//							System.out.println("  goods["+ ++m +"]===>" + gd.getSku());
//							
//							if(gd.getInstallationFee()!=null){
//								int k=0;
//								for(InstallationFee ifee : gd.getInstallationFee()){
//									System.out.println("     ifee["+ ++k +"]===>" + ifee.getInstallationSku()+"/qty:"+ifee.getInstallationQty()+"/amt:"+ifee.getAmount());
//									
//									if(ifee.getCouponSet()!=null){
//										for(CouponUsage cu : ifee.getCouponSet()){
//											System.out.println("   couponNo=" + cu.getCouponNo()+"/qty:"+cu.getQty()+"/discount:"+cu.getDiscount());
//										}
//									}
//								}
//							}
//						}
//					}
					
					System.out.println(i+"."+ (j) + "[freightItem]=>");
					if(freightRecord.getItemSet()!=null){
						for(FreightItem item : freightRecord.getItemSet()){
							System.out.println("  ===>" + item.getName()+"/itemQty:"+item.getQty()+"/unitPrice:"+item.getUnitPrice());
						}
					}
					
				}
				
				j=0;
				System.out.println("==== WorkTypeSet.Negotiation ====");
				Negotiation negotiation = workType.getNegotiation();
				if(negotiation==null){
					System.out.println(i+"."+ (++j) + "=>null");
				}else{
					System.out.println(i+"."+ (++j) + "=>" + negotiation==null?null:negotiation.getSeqNo()); //�渹=seqNo,ĳ���H=negotiation.getNegotiatorId()
				}
				
			}
		}
		i=0;
		System.out.println("==== GoodsSet ====");
		if(skuStatistics.getGoodsSet()!=null){
			for(OrderGoods goods : skuStatistics.getGoodsSet()){
				System.out.println(++i + "����=>" + goods.getSku());
			}
		}
		i=0;
		System.out.println("==== CouponSet ====");
		if(skuStatistics.getCouponSet()!=null){
			for(CouponUsage coupon : skuStatistics.getCouponSet()){
				System.out.println(++i + "=>" + coupon.getCouponNo());
			}
		}
	}
}
