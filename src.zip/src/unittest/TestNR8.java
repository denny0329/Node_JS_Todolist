package unittest;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.trans.service.TransSalesWkService;

public class TestNR8 extends TestCase {
	public static void main(String[] args) throws Exception{
		TransSalesWkService tWkService = (TransSalesWkService)AppContext.getBean("transSalesWkService");
		tWkService.executeNR8wkSalesTrans();
	}
	public void testNR8() throws Exception{
		TransSalesWkService tWkService = (TransSalesWkService)AppContext.getBean("transSalesWkService");
		tWkService.executeNR8wkSalesTrans();
	}
}
