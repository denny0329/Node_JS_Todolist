package unittest;

import java.io.File;

import junit.framework.TestCase;

import com.rfep.dataex.sd.inbound.OMSBSSTORE;

public class TestOMSBSSTORE extends TestCase {
	
	private OMSBSSTORE omsTest;
	protected void setUp() throws Exception {
		super.setUp();
		omsTest = new OMSBSSTORE();
	}
	
	public void testFile() {
		try {
			File file = new File("C:\\OMS_TEST\\OMSBSSTORE\\OMSBSSTORE_2015071522051380_66434.csv");
			omsTest.execute(file);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
