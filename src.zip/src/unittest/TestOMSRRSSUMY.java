package unittest;

import java.io.File;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.dataex.iv.inbound.OMSRRSSUMY;
import com.rfep.util.sys.dao.SysEmailGroupDao;

public class TestOMSRRSSUMY extends TestCase {
	private OMSRRSSUMY omsTest;
	private SysEmailGroupDao sysEmailGroupDao;
	
	protected void setUp() throws Exception {
		super.setUp();
		sysEmailGroupDao = (SysEmailGroupDao)AppContext.getBean("sysEmailGroupDao");
		omsTest = new OMSRRSSUMY();
		omsTest.setSysEmailGroupDao(sysEmailGroupDao);
	}
	
	public void testFile() {
		try {
			File file = new File("C:\\OMS_TEST\\OMSRRSSUMY\\OMSRRSSUMY_201506301642036_66496.csv");
			omsTest.execute(file);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
