package unittest;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.gccs.bs.dao.hibernate.BsSkuDao;
import com.gccs.util.cache.BsCompanyDefinition;
import com.gccs.util.cache.BsStoreDefinition;
import com.rfep.iv.dao.InventoryDao;
import com.rfep.iv.model.IvStoreInventory;
import com.rfep.iv.model.IvStoreInventoryChange;
import com.rfep.iv.service.IInventoryService;
import com.rfep.iv.service.IvGoodsMvService;
import com.rfep.product.bs.dao.hibernate.BsSkuStoreDao;
import com.rfep.product.bs.model.BsSku;
import com.rfep.product.bs.model.BsSkuStore;
import com.rfep.product.bs.service.PdSkuService;
import com.rfep.product.bs.util.PdSkuUtil;

public class TestInventoryService extends TestCase{
	InventoryDao inventoryDao = null;
	BsSkuDao bsSkuDao = null;
	BsSkuStoreDao bsSkuStoreDao = null;
	IInventoryService inventoryService = null;
	PdSkuService pdService = null;
	IvGoodsMvService ivGoodsMvService = null;
	
	@Override
	protected void setUp() throws Exception {
		inventoryDao = (InventoryDao)AppContext.getBean("inventoryDao");
		bsSkuDao = (BsSkuDao)AppContext.getBean("bsSkuDao");
		bsSkuStoreDao = (BsSkuStoreDao)AppContext.getBean("bsSkuStoreDao");
		inventoryService = (IInventoryService)AppContext.getBean("inventoryService");
		pdService = (PdSkuService)AppContext.getBean("pdService");
		ivGoodsMvService = (IvGoodsMvService)AppContext.getBean("ivGoodsMvService");
		super.setUp();
	}
	
	/**
	 * �ˬdSKU_CAT��12(��), Display�B�l�w�s���t�̡A�����[�l
	 * @throws Exception
	 */
	public void testStoreInventoryNonEnough() throws Exception{
		List<Map> nonEnoughInventory = inventoryDao.findStoreInventoryNonEnoughByDisplay();
		int testCount = 0;
		for( Map item :  nonEnoughInventory){
			if( testCount > 0 ){
				System.out.println(" ��դ��� "+testCount+" �� ");
				break;
			}else{
				testCount++;
			}
			BigDecimal qty = (BigDecimal) item.get("SET_QTY");
			String parentSku = (String)item.get("PARENT_SKU");
			String childSku = (String)item.get("SKU");
			String storeId = (String)item.get("STORE_ID");
//			String channelId = (String)item.get("CHANNEL_ID");
			System.out.println(" pSku : " + parentSku+" cSku : " + childSku+" qty : " + qty.intValue() );
			IvStoreInventory  childStoreInventory = inventoryService.getIvStoreInventory(storeId, childSku);
			IvStoreInventory  parentStoreInventory = inventoryService.getIvStoreInventory(storeId, parentSku);
						
			Integer childOnHand =  childStoreInventory.getOnHand();
			Integer parentOnHand =  parentStoreInventory.getOnHand();
			Integer transQty = getTransQty(qty.intValue(),childOnHand,parentOnHand);
			
			System.out.println("[Before]transQty : "+transQty+" childOnHand : " + childOnHand + " parentOnHand : " + parentOnHand );
			if( transQty > 0 ){
				updateStoreInventory(transQty,qty.intValue(),childStoreInventory,parentStoreInventory);
//				parentStoreInventory.setOnHand(parentOnHand - transQty);
//				childStoreInventory.setOnHand(childOnHand+(qty.intValue()*transQty));
//				System.out.println("[After]transQty : "+transQty+" childOnHand : " + childStoreInventory.getOnHand() + " parentOnHand : " + parentStoreInventory.getOnHand() );
			}
		}
	}
	
	/**
	 * ��s�ӫ~�w�s[�l�w�s���t�̡A�����[�l]
	 * @param transQty
	 * @param setQty
	 * @param childStoreInventory
	 * @param parentStoreInventory
	 */
	public void updateStoreInventory(
			Integer transQty, Integer setQty ,  
			IvStoreInventory  childStoreInventory, IvStoreInventory  parentStoreInventory)
	{
		Integer childOnHand =  childStoreInventory.getOnHand();
		Integer parentOnHand =  parentStoreInventory.getOnHand();
		
		parentStoreInventory.setOnHand(parentOnHand - transQty);
		childStoreInventory.setOnHand(childOnHand+(setQty*transQty));
		System.out.println("[After]transQty : "+transQty+" childOnHand : " + childStoreInventory.getOnHand() + " parentOnHand : " + parentStoreInventory.getOnHand() );
		Date createTime = new Date(System.currentTimeMillis());
		
		//��s�w�s����
		inventoryDao.updateIvStoreInventory(parentStoreInventory);
		inventoryDao.updateIvStoreInventory(childStoreInventory);
		
		//�w�s���ʸ��
		this.createStoreInventoryChange(parentStoreInventory,parentStoreInventory.getOnHand());
		this.createStoreInventoryChange(childStoreInventory,childStoreInventory.getOnHand());
		
		//�s�Wgoods_mv���
		ivGoodsMvService.transferChildStock(
				createTime, BsStoreDefinition.storeIdToSiteId(parentStoreInventory.getStoreId()), 
				parentStoreInventory.getSku(), transQty,childStoreInventory.getSku(),setQty*transQty);
	}
	
	/**
	 * �إ߮w�s����
	 * @param storeInventory:	�ӫ~�w�s
	 * @param transQty		:	�ܰʼƶq
	 */
	public void createStoreInventoryChange(IvStoreInventory storeInventory, Integer transQty){
		IvStoreInventoryChange inventoryChange = new IvStoreInventoryChange();
		
		BsSku bsSku = bsSkuDao.find(storeInventory.getSku(), BsCompanyDefinition.getCompanyByStoreId(storeInventory.getStoreId())
				.getCompanyId());
		BsSkuStore bsSkuStore = bsSkuStoreDao.find(storeInventory.getStoreId(), storeInventory.getSku());
		
		Date createTime = new Date(System.currentTimeMillis());
		inventoryChange.setChannelId(storeInventory.getChannelId());
		inventoryChange.setStoreId(storeInventory.getStoreId());
		inventoryChange.setSku(storeInventory.getSku());
		
		inventoryChange.setStoreType("S");
		inventoryChange.setTxnType("319");
		inventoryChange.setTxnQty(transQty);
		inventoryChange.setTxnDate(createTime);
		Double unTaxPrice = 0.0;
		if( bsSku.getTaxType() == PdSkuUtil.TAX_TYPE_TAXABLE ){
			unTaxPrice = (Double)bsSkuStore.getPosPrice()/1.05;
		}else{
			unTaxPrice = (Double)bsSkuStore.getPosPrice();
		}
		inventoryChange.setReTail(unTaxPrice*transQty);
		inventoryChange.setCost(bsSkuStore.getAvgCost());
//		inventoryChange.setRefNo(refNo);
		inventoryChange.setProgramName("OMSGOODSMV");
		inventoryChange.setPosPrice(bsSkuStore.getPosPrice());
		inventoryChange.setRegularPrice(bsSkuStore.getRegularPrice());
		
		inventoryChange.setCreateTime(createTime);
		
		inventoryDao.saveOrUpdateObject(inventoryChange);
	}
	
	/**
	 * �����[�l���ഫ�ƶq
	 * @param setQty		: 	���l�ﴫ�ƶq
	 * @param childOnHand	:	�l�ƶq
	 * @param parentOnHand	:	���ƶq
	 * @return
	 */
	public static Integer getTransQty(
			Integer setQty, Integer childOnHand , Integer parentOnHand ){
		Integer transQty = 0;
		if( childOnHand < 0 && parentOnHand > 0 ){
			boolean transNoYet = true;
			while( transNoYet ){
				/* �l�ƶq���ഫ�쥿�� */
				if( (childOnHand + (setQty*transQty)) >= 0 && 
						(parentOnHand-transQty) >= 0  ){
					transNoYet = false;
				}
				/* ���ƶq���ഫ�W�� */
				else if( (parentOnHand-transQty) <= 0 ){
					transNoYet = false;
				}else{
					transQty++;
				}
			}
		}
		return transQty;
	}
	
	public void testDeductStockForSales() throws Exception {
		
		HawaSku sku = new HawaSku("", new Date(), "00900", "B", "N",
				"02700", null, "TB71804722", "000308479", new BigDecimal(-979), new BigDecimal(-1), null);
		
		
	}
	
	private class HawaSku {
		private String trackingNo;
		private Date transDate;	//������
		private String storeId;	//������O
		private String saleType;	//������O(N: �P��B�禬�F B: �P�h)
		private String saleStatus;
		private boolean cancelTxn = false;	//�@�o���(true: �@�o�F false: ���`)
		private String refundStoreId;
		private String soNo;
		private String guiNos;
		private String skuNos;
		private BigDecimal total;
		private BigDecimal qty;
		private BigDecimal physicalSku;
		private boolean goodsRtv = true;
		public HawaSku(String trackingNo, Date transDate, String storeId, String saleType,
				String saleStatus, String refundStoreId, String soNo, String guiNos,
				String skuNos, BigDecimal total, BigDecimal qty, BigDecimal physicalSku) {
			this.trackingNo = trackingNo;
			this.transDate = transDate;
			this.storeId = storeId;
			this.saleType = saleType;
			this.saleStatus = saleStatus;
			this.refundStoreId = refundStoreId;
			this.soNo = soNo;
			this.guiNos = guiNos;
			this.skuNos = skuNos;
			this.total = total;
			this.qty = qty;
			this.physicalSku = physicalSku;
		}
		public String getTrackingNo() {
			return trackingNo;
		}
		public void setTrackingNo(String trackingNo) {
			this.trackingNo = trackingNo;
		}
		public Date getTransDate() {
			return transDate;
		}
		public void setTransDate(Date transDate) {
			this.transDate = transDate;
		}
		public String getStoreId() {
			return storeId;
		}
		public void setStoreId(String storeId) {
			this.storeId = storeId;
		}
		public String getSaleType() {
			return saleType;
		}
		public void setSaleType(String saleType) {
			this.saleType = saleType;
		}
		public String getSaleStatus() {
			return saleStatus;
		}
		public void setSaleStatus(String saleStatus) {
			this.saleStatus = saleStatus;
		}
		public boolean isCancelTxn() {
			if(this.getSaleStatus().equals("B"))
				cancelTxn = true;
			return cancelTxn;
		}
		public void setCancelTxn(boolean cancelTxn) {
			this.cancelTxn = cancelTxn;
		}
		public String getRefundStoreId() {
			return refundStoreId;
		}
		public void setRefundStoreId(String refundStoreId) {
			this.refundStoreId = refundStoreId;
		}
		public String getGuiNos() {
			return guiNos;
		}
		public void setGuiNos(String guiNos) {
			this.guiNos = guiNos;
		}
		public BigDecimal getTotal() {
			return total;
		}
		public void setTotal(BigDecimal total) {
			this.total = total;
		}
		public String getSoNo() {
			return soNo;
		}
		public void setSoNo(String soNo) {
			this.soNo = soNo;
		}
		public String getSkuNos() {
			return skuNos;
		}
		public void setSkuNos(String skuNos) {
			this.skuNos = skuNos;
		}
		public BigDecimal getQty() {
			return qty;
		}
		public void setQty(BigDecimal qty) {
			this.qty = qty;
		}
		public BigDecimal getPhysicalSku() {
			return physicalSku;
		}
		public void setPhysicalSku(BigDecimal physicalSku) {
			this.physicalSku = physicalSku;
		}
		public boolean isGoodsRtv() {
			if(this.getPhysicalSku()!=null && this.getPhysicalSku().intValue()==0)
				goodsRtv = false;
			return goodsRtv;
		}
		public void setGoodsRtv(boolean goodsRtv) {
			this.goodsRtv = goodsRtv;
		}
		
	}
	
	public static void main(String[] arg)throws Exception{
		System.out.println(" test : " + TestInventoryService.getTransQty(25, -14, 1));
		System.out.println(" test : " + TestInventoryService.getTransQty(25, -30, 1));
		System.out.println(" test : " + TestInventoryService.getTransQty(10, -14, 3));
		System.out.println(" test : " + TestInventoryService.getTransQty(10, -30, 5));
	}
}