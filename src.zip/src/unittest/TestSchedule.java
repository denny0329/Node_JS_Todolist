/**
 * 
 */
package unittest;

import java.util.Calendar;

import org.quartz.Scheduler;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.scheduling.quartz.SimpleTriggerBean;

/**
 * <b></b>
 * 
 * @author kaychen
 * @Date: 2009/6/1 �U�� 5:28:22
 * @Project Name: RFEP
 * @Package Name: unittest
 * @File Name: TestSchedule.java
 */
public class TestSchedule {
	private static ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(
			new String[] { "classpath*:spring/schedule*.xml",
					"classpath*:spring/action*.xml",
					"classpath*:spring/commons*.xml",
					"classpath*:spring/base*.xml",
					"classpath*:spring/sqlmap*.xml",
					"classpath*:spring/service*.xml" });

	public void updateDayAllJob(long repeatInterval) throws Exception {
		Scheduler sch = (Scheduler) context.getBean("schedulerFactoryBean");
		SimpleTriggerBean dayAllTrigger = (SimpleTriggerBean) sch.getTrigger("dayAllTrigger", Scheduler.DEFAULT_GROUP);
		dayAllTrigger.setRepeatInterval(repeatInterval);
		sch.rescheduleJob("dayAllTrigger", Scheduler.DEFAULT_GROUP, dayAllTrigger);
	}

	public static void main(String[] args) {
		TestSchedule qt = new TestSchedule();
		try {
			while (true) {
				Calendar now = Calendar.getInstance();
				int hour = now.get(Calendar.HOUR_OF_DAY);
				if (hour == 16) {
					qt.updateDayAllJob(30000);
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
