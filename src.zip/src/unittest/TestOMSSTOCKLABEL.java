package unittest;

import com.bnq.util.AppContext;
import com.trg.oms.common.service.EMarkSftpSenderService;
import com.trg.oms.dataex.ftp.OMSSTOCKLABEL;
import junit.framework.TestCase;

public class TestOMSSTOCKLABEL extends TestCase {

    private OMSSTOCKLABEL omsstocklabel;

    public void testTrfOMSSTOCKLABEL_SES() {
        omsstocklabel = new OMSSTOCKLABEL();
        omsstocklabel.seteMarkSftpSenderService((EMarkSftpSenderService) AppContext.getBean("eMarkSftpSenderService"));
        omsstocklabel.executeSES();
    }

    public void testTrfOMSSTOCKLABE_ELSA() {
        omsstocklabel = new OMSSTOCKLABEL();
        omsstocklabel.seteMarkSftpSenderService((EMarkSftpSenderService) AppContext.getBean("eMarkSftpSenderService"));
        omsstocklabel.executeELSA();
    }
}
