package unittest;

import java.math.BigDecimal;
import java.util.Calendar;

import com.rfep.tts.sync.TTSSingleTableSync;
import com.rfep.tts.sync.TTSTblSousefDetlService;
import com.rfep.tts.sync.TTSTblTransSaleService;
import com.rfep.tts.sync.TtsConnUtils;
import com.rfep.tts.sync.tlw.dao.TBLSousefDetlDAO;
import com.rfep.tts.sync.tlw.dao.TBLTransSaleDAO;
import com.rfep.tts.sync.tlw.model.TBLSousefDetl;
import com.rfep.tts.sync.tlw.model.TBLTransSale;

public class TestTTSTableSyncService {
	
	public static void main(String[] args)throws Exception{
		TestTTSTableSyncService tts = new TestTTSTableSyncService();
//		tts.testTTSTransSale();
		tts.testTTSSousefDetl();
	}
	
	public void testTTSSousefDetl()throws Exception{
		TTSSingleTableSync tableSync = 
			new TTSTblSousefDetlService();
		/**set attribute**/
		TtsConnUtils ttsConnUtils = new TtsConnUtils();
		ttsConnUtils.setChannelId("TLW");
		ttsConnUtils.setStoreId("00100");
		
		TBLSousefDetlDAO dao = new TBLSousefDetlDAO();
		dao.setTtsConnUtils(ttsConnUtils);
		((TTSTblSousefDetlService)tableSync).setTblSousefDetlDAO(dao);
		
		/**create insert data**/
//		TBLTransSale data = new TBLTransSale();
		TBLSousefDetl data = new TBLSousefDetl();
		
		data.setStoreId("00100");
		data.setOrderId("19801229");
		data.setReOrderId("12291980");
		data.setSkuNo("196544");
		data.setStatus("RC");
		data.setQty(1);
		data.setInstallationId("000019801229");
		data.setOrderStoreId("00500");
		data.setUpdUser("SO");
		data.setUpdDate(Calendar.getInstance().getTime());
		data.setSyncDate(Calendar.getInstance().getTime());
		data.setUpdStoreId("00100");
		data.setReOrderCloseFlag("");
		
		/**insert data**/
		tableSync.insert(data);
		
		/**update data**/
//		data.setUpdDate(Calendar.getInstance().getTime());
//		data.setReOrderCloseFlag("Y");
//		tableSync.update(data);		
	}
	
	public void testTTSTransSale()throws Exception{
		TTSSingleTableSync tableSync = 
			new TTSTblTransSaleService();
		
		/**set attribute**/
		TtsConnUtils ttsConnUtils = new TtsConnUtils();
		ttsConnUtils.setChannelId("TLW");
		ttsConnUtils.setStoreId("00100");
		
		TBLTransSaleDAO dao = new TBLTransSaleDAO();
		dao.setTtsConnUtils(ttsConnUtils);
		((TTSTblTransSaleService)tableSync).setTblTransSaleDAO(dao);
		
		/**create insert data**/
		TBLTransSale data = new TBLTransSale();
//		TBLSousefDetl data = new TBLSousefDetl();
		
		//���հ����
		data.setInstallationId("666666666666");
		data.setOrderId("00100");
		data.setPosNos("129");
		data.setSerNos("129");
		data.setGuiNos("1980122900");
		data.setItemSer("02");
		data.setSkuNos("196544");
		data.setTransQty(1);
		data.setTransAmt(new BigDecimal(69));
		
		data.setTransDate(
				Calendar.getInstance().getTime());
		data.setInstallAcceptDate(
				Calendar.getInstance().getTime());
		
		data.setStoreId("00100");
		data.setDcStoreId("00100");
		data.setUploadDate(
				Calendar.getInstance().getTime());
		data.setUploadPos("123");
		data.setUploadSer("456");
		data.setVendorFlag("1");
		
		/**insert data**/
		tableSync.insert(data);
//		tableSync.update(data);
	}
}