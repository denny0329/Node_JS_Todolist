package unittest;

import junit.framework.TestCase;

import com.rfep.dataex.fi.voucher.AbstractVoucherProcess;
import com.rfep.dataex.fi.voucher.impl.nr.AdvanceSkuProcess;

public class TestAbstractVoucherProcess extends TestCase {

	@Override
	protected void setUp() throws Exception {
		super.setUp();
	}

	public void testAbstractVoucherProcess() {
		AbstractVoucherProcess oms = new AdvanceSkuProcess();
		oms.execute();
	}
}
