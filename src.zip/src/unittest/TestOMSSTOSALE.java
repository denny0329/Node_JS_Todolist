package unittest;

import junit.framework.TestCase;

import com.rfep.dataex.sd.outbound.OMSSTOSALE;

public class TestOMSSTOSALE extends TestCase {

	@Override
	protected void setUp() throws Exception {
		super.setUp();
	}

	public void testOMSSTOSALE() {
		OMSSTOSALE oms = new OMSSTOSALE();
		oms.execute();
	}
}
