package unittest;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.iv.po.dao.hibernate.PoDao;
import com.trg.oms.job.UploadPOAppliedToSAPJob;

public class TestUploadPOAppliedToSAPJob extends TestCase {
	private UploadPOAppliedToSAPJob uploadPOAppliedToSAPJob;
	
	private PoDao poDao;
	
	protected void setUp() throws Exception {
		super.setUp();
		poDao = (PoDao)AppContext.getBean("poDao");
		uploadPOAppliedToSAPJob = new UploadPOAppliedToSAPJob();
		uploadPOAppliedToSAPJob.setPoDao(poDao);
		
	}
	
	public void testUploadPOAppliedToSAPJob()throws Exception{
		setUp();
		uploadPOAppliedToSAPJob.execute();
	}
}
