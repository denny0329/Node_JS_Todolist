/**
 * @(#)TestTransStoreChangePriceJob.java.java May 18, 2015
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest;

import org.springframework.orm.hibernate3.HibernateTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import com.bnq.util.AppContext;
import com.gccs.bs.dao.hibernate.BsSkuDao;
import com.rfep.product.bs.dao.hibernate.BsPriceConditionDao;
import com.rfep.product.bs.dao.hibernate.BsSkuStoreDao;
import com.rfep.trans.dao.hibernate.TransStoreChangePriceDao;
import com.rfep.trans.job.TransStoreChangePriceJob;
import com.rfep.util.sys.dao.SysEmailGroupDao;
import com.rfep.util.sys.dao.SysJobDao;

import junit.framework.TestCase;

/**
 * @author T2482
 *
 */
public class TestTransStoreChangePriceJob extends TestCase {
	
	private TransStoreChangePriceJob job = new TransStoreChangePriceJob();

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		job.setTransStoreChangePriceDao((TransStoreChangePriceDao)AppContext.getBean("transStoreChangePriceDao"));
		job.setBsPriceConditionDao((BsPriceConditionDao)AppContext.getBean("priceConditionDao"));
		job.setBsSkuDao((BsSkuDao)AppContext.getBean("bsSkuDao"));
		job.setBsSkuStoreDao((BsSkuStoreDao)AppContext.getBean("bsSkuStoreDao"));
		job.setSysEmailGroupDao((SysEmailGroupDao)AppContext.getBean("sysEmailGroupDao"));
		job.setSysJobDao((SysJobDao)AppContext.getBean("sysJobDao"));
		
		TransactionTemplate transaction = new TransactionTemplate();
		transaction.setTransactionManager((HibernateTransactionManager)AppContext.getBean("dataSourceTxManager"));
		job.setTransactionTemplate(transaction);
	}

	public void testInvalidSku() {
		job.execute();
	}
}