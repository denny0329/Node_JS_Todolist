package unittest;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;

import com.bnq.util.AppContext;
import com.rfep.dataex.iv.inbound.OMSSMMSUMY;
import com.rfep.iv.dao.IvSmmSummaryDao;
import com.rfep.iv.report.IvReportActionImpl;
import com.rfep.iv.rtv.service.SmmRtvService;


import junit.framework.TestCase;

/**
 * 測試 OMSSMMSUMY
 * @author allen
 */
public class TestSmmReport extends TestCase {
	private IvReportActionImpl ivReportActionImpl;
	private SmmRtvService smmRtvService;
	private IvSmmSummaryDao ivSmmSummaryDao;

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
	    super.setUp();
//	    ivReportActionImpl = (IvReportActionImpl)AppContext.getBean("ivReportActionI");
//	    note = new OMSSMMSUMY();
	    ivReportActionImpl = new IvReportActionImpl();
//	    smmRtvService = new SmmRtvService();
//	    ivSmmSummaryDao = new IvSmmSummaryDao();
//	    
//	    smmRtvService.setIvSmmSummaryDao(ivSmmSummaryDao);
	}
		
	public void testImportSmm() {
		
//		File file = new File("C:\\OMSqueue\\inbound\\OMSSMMSUMY_20130715173243766_18577.csv");
//		note.execute(file);
//	    Map<String, String> queryCondition = new HashMap<String, String>();
//	    queryCondition.put("storeId", "00700");
//	    ivReportActionImpl.setQueryCondition(queryCondition);
//	    ivReportActionImpl.setSmmRtvService(smmRtvService);
	    ivReportActionImpl.ivReport37Print();
	}
}