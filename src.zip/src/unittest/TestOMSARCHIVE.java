package unittest;

import com.bnq.util.AppContext;
import com.rfep.dataex.archive.inbound.OMSARCHIVE;
import com.rfep.sap.dao.ArchSapSkuDao;
import com.rfep.sap.model.ArchSapSku;
import junit.framework.TestCase;

import java.io.File;

public class TestOMSARCHIVE extends TestCase {

    private OMSARCHIVE omsarchive;
    private ArchSapSkuDao archSapSkuDao;

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        omsarchive = (OMSARCHIVE) AppContext.getBean("OMSARCHIVE");
        archSapSkuDao = (ArchSapSkuDao) AppContext.getBean("archSapSkuDao");
    }

    public void testOMSARCHIVE() {
        String path = this.getClass().getResource("").getPath() + File.separator + "inBound" + File.separator + "file" + File.separator + "TestOMSARCHIVE_CASE01.csv";
        File file = new File(path.substring(1));
        omsarchive.execute(file);
    }

    public void testArchSapSkuDao() {
        String sku = "000106849";
        ArchSapSku archSapSku = archSapSkuDao.findArchSapSkuBySku(sku);
        System.out.println(archSapSku);
    }
}
