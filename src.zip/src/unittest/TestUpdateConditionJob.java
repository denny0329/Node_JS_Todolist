package unittest;

import com.bnq.util.AppContext;
import com.rfep.product.bs.service.CostPriceConditionService;
import com.rfep.product.bs.service.PriceConditionService;
import com.rfep.product.bs.service.RegularPriceConditionService;
import com.rfep.product.job.UpdateConditionJob;
import com.rfep.util.sys.dao.SysJobDao;

import junit.framework.TestCase;

/**
 * @author T2482
 */
public class TestUpdateConditionJob extends TestCase {
	private UpdateConditionJob conditionJob;
	
	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();

		conditionJob = new UpdateConditionJob();
		conditionJob.setCostPriceService((CostPriceConditionService)AppContext.getBean("costConditionService"));
		conditionJob.setPosPriceService((PriceConditionService)AppContext.getBean("conditionService"));
		conditionJob.setRegularPriceService((RegularPriceConditionService)AppContext.getBean("regularConditionService"));
		conditionJob.setSysJobDao((SysJobDao)AppContext.getBean("sysJobDao"));
	}
}