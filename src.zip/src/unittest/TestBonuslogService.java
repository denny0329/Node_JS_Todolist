/**
 * 
 */
package unittest;

import java.util.List;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.gccs.bc.model.BcBonusLog;
import com.gccs.bs.dao.hibernate.BsManagerDao;
import com.gccs.ws.model.CheckBonuslogExistRequest;

/**
 * Description
 * 
 * A brief description of the class/interface.
 * 
 * History 2012/7/3 Brian Han What has been changed.
 * 
 */
public class TestBonuslogService extends TestCase {

	private BsManagerDao bsManagerDao;
	private CheckBonuslogExistRequest request;

	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestCase#setUp()
	 */
	@Override
	protected void setUp() throws Exception {
		bsManagerDao = (BsManagerDao) AppContext.getBean("bsManagerDao");
		request = new CheckBonuslogExistRequest();
		request.setChannel_id("TLW");
		request.setStore_id("00700");
		request.setVip_no("2816930330128");
		request.setTrans_date("2011/05/22");
		request.setPos_nos("106");
		request.setSer_nos("0222");
		request.setBonus_add("10");
		request.setBonus_mins("0");
	}

	public void testQryBonslogForWebService() throws NumberFormatException, Exception {
		List<BcBonusLog> list = bsManagerDao.qryBonslogForWebService(request.getChannel_id(), request.getStore_id(), request.getVip_no(), request.getTrans_date(), request.getPos_nos(), request.getSer_nos(), Integer.valueOf(request.getBonus_add()), Integer.valueOf(request.getBonus_mins()));
		assertNotNull(list);
		assertTrue(list.size() >= 1);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see junit.framework.TestCase#tearDown()
	 */
	@Override
	protected void tearDown() throws Exception {
		bsManagerDao = null;
		request = null;
	}

}
