/**
 * @(#)TestOmsFromMwJob.java.java Jun 17, 2015
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest;

import com.bnq.util.AppContext;
import com.bnq.util.mq.QmTriReceiver;
import com.bnq.util.mq.job.OmsFromMwJob;
import com.rfep.dataex.InboundManager;

import junit.framework.TestCase;

/**
 * @author T2482
 *
 */
public class TestOmsFromMwJob extends TestCase {
	private OmsFromMwJob job = new OmsFromMwJob();

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		job.setQmTriReceiver((QmTriReceiver)AppContext.getBean("qmTriReceiver"));
		job.setInBoundManager((InboundManager)AppContext.getBean("inBoundManager"));
	}

	public void testExecute() {
		try {
			job.execute();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
