package unittest;

import java.io.File;

import junit.framework.TestCase;

import com.rfep.dataex.nm.inbound.CRMNMB2B02;

public class TestInbound extends TestCase {
	public TestInbound() {
	     //  super();
	    }
	   	
/*	public void testOMSDSB2B03() {
		//bean 
		//AppContext.getBean(name) ;
		//ServletContextWrapper servletContextWrapper = (ServletContextWrapper)AppContext.getBean("servletCtxWrapper");
		OMSDSB2B03  a = new OMSDSB2B03();
        a.execute() ;
    }*/
		
/*		public void testOMSDSEIP02() {
			//bean 
			//AppContext.getBean(name) ;
			//ServletContextWrapper servletContextWrapper = (ServletContextWrapper)AppContext.getBean("servletCtxWrapper");
			OMSDSEIP02  a = new OMSDSEIP02();
			File newfile = new File(DataExGlossary.INBOUND_DIR_PATH + "CRMNMB2B02_20110222095446.txt");
	        a.execute(newfile) ;
	    }
*/
		
		public void testCRMNMB2B02() {
			//bean 
			//AppContext.getBean(name) ;
			//ServletContextWrapper servletContextWrapper = (ServletContextWrapper)AppContext.getBean("servletCtxWrapper");
			CRMNMB2B02  a = new CRMNMB2B02();
			File newfile = new File("c:\\b.csv");
	        a.execute(newfile) ;
	    }
		public static void main(String[] args) {
	        junit.textui.TestRunner.run(TestInbound.class);
	    }
}
