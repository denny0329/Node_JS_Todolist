package unittest;

import java.io.File;

import com.rfep.dataex.cb.inbound.OMSCBEIP02;

import junit.framework.TestCase;

public class TestOMSDSEIP02 extends TestCase{

	@Override
	protected void setUp() throws Exception {
		super.setUp();
	}
	public void testOMSDSEIP02() throws Exception {
		OMSCBEIP02 oms = new OMSCBEIP02();
		oms.execute(new File("E:\\csv\\TEST\\OMSDSEIP02_20120718-163012706_1230999.csv"));
		oms.execute(new File("E:\\csv\\TEST\\OMSDSEIP02_20120718-164009755_1117620.csv"));
		oms.execute(new File("E:\\csv\\TEST\\OMSDSEIP02_20120718-171016406_1124414.csv"));
	}	

}
