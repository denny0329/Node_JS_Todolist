package unittest;

import java.net.URL;

import com.bnq.cs.cc.castor.XmlParser;
import com.bnq.cs.cc.model.CommentTransfer;

/**
 * @author kaychen
 * @Date: 2009/3/19 上午 10:43:02
 * @Project Name: bnq
 * @Package Name: unittest
 * @File Name: TestTransferService.java
 */
public class TestTransferService {
	
	public static void main(String args[]) {
		//String serviceURL = "http://localhost:8081/RFEP/service/TransferService";
		//Service serviceModel = new ObjectServiceFactory().create(ITransfer.class,null,"http://localhost:8080/bnq/service/TransferService?wsdl",null);
        //XFireProxyFactory serviceFactory = new XFireProxyFactory();
        try {
        	//ITransfer service = (ITransfer) serviceFactory.create(serviceModel, serviceURL);
        	//String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><CustomerComment><DeptId></DeptId><Tempflag>false</Tempflag><RelatedNo>W0902000001</RelatedNo><CommentType>意見</CommentType><CustomerVipNo>20102442401</CustomerVipNo><CustomerId>N123456789</CustomerId><CustomerName>洪XX</CustomerName><CustomerAddr>台北市內湖區</CustomerAddr><CustomerPhone>0223331233</CustomerPhone><CustomerPhoneExt>1234</CustomerPhoneExt><CustomerMobile>0910000111</CustomerMobile><CustomerEmail>aaa@aaa.com</CustomerEmail><CommentContent><![CDATA[輸入之意見內容]]></CommentContent><CreatorId>0704</CreatorId><CreatorName>柯OO</CreatorName></CustomerComment>" ;
        	String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
        			"<CustomerComment>" +
        			"<DeptId>01900</DeptId>" +
        			"<RelatedNo>32538366</RelatedNo>" +
        			"<CommentType>002</CommentType>" +
        			"<CustomerVipNo>2999999990363</CustomerVipNo>" +
        			"<CustomerId></CustomerId>" +
        			"<CustomerName>集團卡- <B&Q></CustomerName>" +
        			"<CustomerAddr>新店市永安街101號</CustomerAddr>" +
        			"<CustomerPhone>0919993832</CustomerPhone>" +
        			"<CustomerPhoneExt></CustomerPhoneExt>" +
        			"<CustomerMobile>0963361768</CustomerMobile>" +
        			"<CustomerEmail></CustomerEmail>" +
        			"<CommentContent><![CDATA[因客人一次購買多樣商品 故要求其中三樣商品改天待客人來電時再送貨]]></CommentContent>" +
        			"<CreatorId>J00245</CreatorId>" +
        			"<CreatorName>潘茹嵐</CreatorName>" +
        			"</CustomerComment>" ;
        	//String result = service.createComment(xml) ;
        	//System.out.println(" : "+result) ;
        	//xml = xml.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll("\"", "&quot;") ;
        	
        	String _mapping = "CommentMapping.xml" ;
        	URL url = Thread.currentThread().getContextClassLoader().getResource(_mapping);
        	CommentTransfer transfer = (CommentTransfer)XmlParser.getXmlObject(url, CommentTransfer.class, xml) ;
        	System.out.println(" : "+transfer.getCustomerName()) ;
        } catch (Exception e) {
			e.printStackTrace();
		}
	}
}
