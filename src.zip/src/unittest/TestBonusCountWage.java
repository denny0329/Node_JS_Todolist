package unittest;

import com.gccs.bonus.service.BonusCountWageService;
import com.gccs.util.quartz.IQuartzLogService;
import com.gccs.util.quartz.util.QuartzLogGlossary;
import junit.framework.TestCase;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.regex.Pattern;

public class TestBonusCountWage extends TestCase {

    private final Logger log = LogManager.getLogger(TestBonusCountWage.class);
    private BonusCountWageService service;
    private IQuartzLogService logService;
    private String batch_id = QuartzLogGlossary._id_bonus_wage_calculate;// 會員紅利點數計算-HISU交易計算
    private static final SimpleDateFormat DF = new SimpleDateFormat("yyyy/MM/dd");
    private static final SimpleDateFormat DF2 = new SimpleDateFormat("yyyyMMdd");
    private static final String regx = "^[-+]?(\\d+(\\.\\d*)?|\\.\\d+)([eE][-+]?\\d+)?[dD]?$";//科學計數法正則表達式
    private static Pattern pattern = Pattern.compile(regx);
    private static final String FILE_OK = ".ok";
    private static final String FILE_CSV = ".csv";
    private static final String FILE_TXT = ".txt";
    private static final String FILE_DONE = ".done";
    private static final String SEP1 = ",";
    private static final String SEP2 = "_";
    private static final String SEP3 = File.separator;
    private static String HISU_MASTER = "HISU_MASTER";
    private static String HISU_DETAIL = "HISU_DETAIL";
    private static String HISU = "HISU";

    protected void setUp() throws Exception {
        super.setUp();
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        service = (BonusCountWageService) context.getBean("bonusCountWageService");
        logService = (IQuartzLogService) context.getBean("quartzLogService");
    }

    /**
     * 會員紅利點數計算-HISU交易計算,檢核前置作業
     *
     * @throws Exception
     */
    private void checkBatchBonusCountWageProcess() throws Exception {
        while (!logService.checkPrecedingOperationCompleted(batch_id)) {
            log.info("[bonusCountWageProcess] wait preceding batch.");
            Thread.sleep(60 * 1000);
        }
    }

    /**
     * 會員紅利點數計算-HISU交易計算
     */
    public void testBonusCountWageProcess() {

    }
}
