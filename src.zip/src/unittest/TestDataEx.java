package unittest;

import java.io.File;
import java.util.Date;
import java.util.List;

import com.bnq.bs.model.BsCode;
import com.bnq.bs.model.BsCodeId;
import com.bnq.bs.service.BsCodeService;
import com.bnq.util.AppContext;
import com.bnq.util.DateTimeUtils;
import com.bnq.util.DateUtils;
import com.bnq.util.ZipUtils;
import com.gccs.member.service.AccountService;
import com.rfep.bs.dao.hibernate.BsVendorSkuDao;
import com.rfep.dataex.InboundProc;
import com.rfep.dataex.b2b.inbound.CRMCDEDUCT;
import com.rfep.dataex.b2b.outbound.CRMCOMMENT;
import com.rfep.dataex.co.inbound.OMSEXCRATE;
import com.rfep.dataex.co.inbound.OMSSTOREPC;
import com.rfep.dataex.cb.inbound.OMSDSEIP01;
import com.rfep.dataex.cb.inbound.OMSCBEIP02;
import com.rfep.dataex.ds.outbound.OMSDSB2B04;
import com.rfep.dataex.ds.outbound.OMSDSSAP06;
import com.rfep.dataex.fi.inbound.OMSACUNTAR;
import com.rfep.dataex.fi.inbound.OMSPAYTYPE;
import com.rfep.dataex.fi.inbound.OMSVRESULT;
import com.rfep.dataex.fi.outbound.OMSTRANPAY;
import com.rfep.dataex.fi.voucher.impl.ar.DailyArProcess;
import com.rfep.dataex.iv.inbound.OMSVENDRAP;
import com.rfep.dataex.iv.inbound.OMSVENDRTV;
import com.rfep.dataex.mm.inbound.OMSARSWKST;
import com.rfep.dataex.mm.inbound.OMSBSCALDR;
import com.rfep.dataex.mm.inbound.OMSBSCHARA;
import com.rfep.dataex.mm.inbound.OMSBSCLASS;
import com.rfep.dataex.mm.inbound.OMSBSVENDR;
import com.rfep.dataex.mm.inbound.OMSBUYERGP;
import com.rfep.dataex.mm.inbound.OMSCNDTION;
import com.rfep.dataex.mm.inbound.OMSGOODSCH;
import com.rfep.dataex.mm.inbound.OMSIVPOSAP;
import com.rfep.dataex.mm.inbound.OMSIVSTOCK;
import com.rfep.dataex.mm.inbound.OMSMMCODES;
import com.rfep.dataex.mm.inbound.OMSSKUCOST;
import com.rfep.dataex.mm.inbound.OMSSKUCTRL;
import com.rfep.dataex.mm.inbound.OMSSKUMSTR;
import com.rfep.dataex.mm.inbound.OMSSKUSSRC;
import com.rfep.dataex.mm.inbound.OMSXDPOSTO;
import com.rfep.dataex.nm.inbound.CRMNMB2B02;
import com.rfep.dataex.sd.inbound.OMSACARAMT;
import com.rfep.dataex.sd.inbound.OMSBSSTORE;
import com.rfep.dataex.sd.inbound.OMSSAPSALE;
import com.rfep.product.bs.dao.hibernate.BsPriceConditionDao;
import com.rfep.product.bs.service.CostPriceConditionService;
import com.rfep.product.bs.service.PriceConditionService;
import com.rfep.product.bs.service.RegularPriceConditionService;

public class TestDataEx {
	//private static final String _PATH = "C:\\saptest\\" ;
	private static final String _PATH = "C:\\OMSqueue\\inbound\\" ;
	public void testCalendar() throws Exception {
		String fileName = "OMSBSCALDR_201101181730086.csv" ;
		this.runInbound(fileName, new OMSBSCALDR()) ;
	}
	
	public void testBsClass() throws Exception {
		String fileName = "OMSBSCLASS_201101181706015.csv" ;
		this.runInbound(fileName, new OMSBSCLASS()) ;
	}
	
	public void testVendor() throws Exception {
		String fileName = "OMSBSVENDR_2011030815500899_238_20860.csv" ;
		this.runInbound(fileName, new OMSBSVENDR()) ;
	}
	
	public void testExRate() throws Exception {
		String fileName = "OMSEXCRATE_20110316113919687_215_13263.csv" ;
		this.runInbound(fileName, new OMSEXCRATE()) ;
	}
	
	//private static final String _MODIFIER = "SYSTEM" ;
	public void testCondition() throws Exception {
		//spring 在container起動才跟著啟動
		OMSCNDTION omscndition = (OMSCNDTION)AppContext.getBean("OMSCNDTION");
		omscndition.setPriceConditionService((PriceConditionService)AppContext.getBean("conditionService"));
		omscndition.setCostPriceConditionService((CostPriceConditionService)AppContext.getBean("costConditionService"));
		omscndition.setRegularConditionService((RegularPriceConditionService)AppContext.getBean("regularConditionService"));
		omscndition.setPriceConditionDao((BsPriceConditionDao)AppContext.getBean("priceConditionDao"));
//		omscndition.setPdSkuService((PdSkuService)AppContext.getBean("pdSkuService"));
		omscndition.setBsVendorSkuDao((BsVendorSkuDao)AppContext.getBean("bsVendorSkuDao"));
		String fileName = "OMSCNDTION_201201161903528_132299_PB00.csv" ;
		//this.runInbound(fileName, new OMSCNDTION()) ;
		this.runInbound(fileName, omscndition) ;
	}
	
	public void testComment() throws Exception {
		CRMCOMMENT c = new CRMCOMMENT() ;
		c.execute() ;
	}
	
	public void testSkuCost() throws Exception {
		String fileName = "OMSSKUCOST_20110505200030359_1216247.csv" ;
		this.runInbound(fileName, new OMSSKUCOST()) ;
	}
	
	public void testPayType() throws Exception {
		String fileName = "OMSPAYTYPE_20110114140704721.csv" ;
		this.runInbound(fileName, new OMSPAYTYPE()) ;
	}

	public void testAccountAr() throws Exception {
		String fileName = "OMSACUNTAR_20110117162342514.csv" ;
		this.runInbound(fileName, new OMSACUNTAR()) ;
	}
	
	public void testDailyArProcess() throws Exception {
		DailyArProcess process = new DailyArProcess() ;
		process.execute() ;
	}
	
	public void testSkuCtrl() throws Exception {
		String fileName = "OMSSKUCTRL_201101181754012.csv" ;
		this.runInbound(fileName, new OMSSKUCTRL()) ;
	}

	public void testDeduction() throws Exception {
		String fileName = "CRMCDEDUCT_20110310124400138_215_23975.csv" ;
		this.runInbound(fileName, new CRMCDEDUCT()) ;
	}
	
	public void testStorePc() throws Exception {
		String fileName = "OMSSTOREPC_20110209140524797.csv" ;
		this.runInbound(fileName, new OMSSTOREPC()) ;
	}
	
	public void importArea() throws Exception {
		File f = new File("D:\\sd.txt") ;
		List<String> list = org.apache.commons.io.FileUtils.readLines(f) ;
		for (String string : list) {
			//System.out.println(" : "+string) ;
			String[] sa = string.trim().split("\t",-1) ;
			BsCode code = new BsCode() ;
			BsCodeId id = new BsCodeId() ;
			id.setCodeClass("FD") ;
			id.setCodeNo(sa[0].trim()+" "+sa[1].trim()) ;
			code.setId(id) ;

			code.setCodeExplain(sa[2].trim()) ;
			code.setCodeStatus(1l) ;
			code.setClassExplain("外國地區") ;
			code.setCreateTime(new Date()) ;
			code.setCreator("MW") ;
			code.setCreatorName("MW") ;
			code.setModifier("MW") ;
			code.setModifierName("MW") ;
			code.setModifyTime(code.getCreateTime()) ;
			code.setParentCodeClass("COUNTRY") ;
			code.setParentCodeNo(sa[0].trim()) ;
			BsCodeService service = (BsCodeService)AppContext.getBean("bsCodeService") ;
			service.save(code) ;
		}
	}
	
	public void testBsStore() throws Exception {
		String fileName = "OMSBSSTORE_20110420133642389_123142.csv" ;
		this.runInbound(fileName, new OMSBSSTORE()) ;
	}
	
	public void testTransPay() throws Exception {
		OMSTRANPAY pay = new OMSTRANPAY() ;
		pay.execute() ;
	}
	
	public void testEip02() throws Exception {
		String fileName = "OMSDSEIP02_20110513-0955470_122339.csv" ;
		this.runInbound(fileName, new OMSCBEIP02()) ;
	}
	
	public void testSkuMst() throws Exception {
		String fileName = "OMSSKUMSTR_20110521203022856_51287.csv" ;
		this.runInbound(fileName, new OMSSKUMSTR()) ;
	}
	
	public void testVoucherResult() throws Exception {
		String fileName = "OMSVRESULT_20110221171218318.csv" ;
		this.runInbound(fileName, new OMSVRESULT()) ;
	}
	
	public void testCRM02() throws Exception {
		String fileName = "CRMNMB2B02_20110221191401.csv" ;
		this.runInbound(fileName, new CRMNMB2B02()) ;
	}
	
	public void testSapSale() throws Exception {
		String fileName = "OMSSAPSALE_20110223180601142.csv" ;
		this.runInbound(fileName, new OMSSAPSALE()) ;
	}
	
	public void testBuyer() throws Exception {
		String fileName = "OMSBUYERGP_2011022618033673.csv" ;
		this.runInbound(fileName, new OMSBUYERGP()) ;
	}
	
	public void testCharacter() throws Exception {
		String fileName = "OMSBSCHARA_20110316180336207_216_27277.csv" ;
		this.runInbound(fileName, new OMSBSCHARA()) ;
	}
	
	public void testVendorAp() throws Exception {
		String fileName = "OMSVENDRAP_20110303205658328.csv" ;
		this.runInbound(fileName, new OMSVENDRAP()) ;
	}
	
	public void testIvStock() {
		String fileName = "OMSIVSTOCK_20110511074146901_115821.csv" ;
		this.runInbound(fileName, new OMSIVSTOCK()) ;
	}
	
	public void testOpenSalesValue() throws Exception {
		String fileName = "OMSACARAMT_20110310115853207_236_17254.csv" ;
		this.runInbound(fileName, new OMSACARAMT()) ;
	}
	
	public void testAccountService() throws Exception {
		Date date = DateUtils.addDay(DateTimeUtils.getFormatSysDate(), -1);
		AccountService service = (AccountService)AppContext.getBean("accountService") ;
		//service.updateArAmountBySAP(date) ;
		//service.updateArAmountByTrans(date) ;
		service.arAmountWrittenOff(new Date());
	}
	
	public void testSkuSrc() throws Exception {
		String fileName = "OMSSKUSSRC_20110316120401224_216_27172.csv" ;
		this.runInbound(fileName, new OMSSKUSSRC()) ;
	}
	
	public void testZip() throws Exception {
		String path = "C:\\Documents and Settings\\kaychen\\桌面\\桌面\\ZSAPMM0003_20110406aa" ;
//		File dir = new File(path) ;
//		File[] dirs = dir.listFiles() ;
//		for (int i = 0; i < dirs.length; i++) {
//			if(dirs[i].getName().equals("src")) {
//				continue ;
//			}
//			if(dirs[i].isDirectory()) {
//				File[] dir2 = dirs[i].listFiles() ;
//				for (int j = 0; j < dir2.length; j++) {
//					File f = dir2[j] ;
//					FileUtils.moveFile(f, new File(path+"\\src\\"+f.getName())) ;
//				}
//			}
//		}
		File dir = new File(path) ;
		File[] dirs = dir.listFiles() ;
		for (int i = 0; i < dirs.length; i++) {
			File srcFile = dirs[i] ;
			if(srcFile.getName().equals("zips")) {
				continue ;
			}
			String fileName = srcFile.getName().replaceAll("csv", "ZIP") ;
			String zipDest = path+"\\zips\\"+fileName ;
			ZipUtils.zipFile(zipDest, srcFile);
			//System.out.println(" : "+zipDest) ;
		}
	}
	
	public void testArsWorkSheet() throws Exception {
		String fileName = "OMSARSWKST_20110330214101369_524627.csv" ;
		this.runInbound(fileName, new OMSARSWKST()) ;
	}
	
	public void testSap06() throws Exception {
		OMSDSSAP06 b = new OMSDSSAP06() ;
		b.execute() ;
	}
	
	public void testB2B04() throws Exception {
		OMSDSB2B04 b = new OMSDSB2B04() ;
		b.execute() ;
	}
	
	public void testPo() throws Exception {
		String fileName = "OMSIVPOSAP_11_PO.csv" ;
		this.runInbound(fileName, new OMSIVPOSAP()) ;
//		 fileName = "OMSIVPOSAP_12_PO.csv" ;
//		this.runInbound(fileName, new OMSIVPOSAP()) ;
//
		 fileName = "OMSIVPOSAP_46_退廠.csv" ;
		this.runInbound(fileName, new OMSIVPOSAP()) ;
//
//		 fileName = "OMSIVPOSAP_51_XD.csv" ;
//		this.runInbound(fileName, new OMSIVPOSAP()) ;
//
//		 fileName = "OMSIVPOSAP_52_DC.csv" ;
//		this.runInbound(fileName, new OMSIVPOSAP()) ;
//
//		 fileName = "OMSIVPOSAP_53_店對店.csv" ;
//		this.runInbound(fileName, new OMSIVPOSAP()) ;
//
//		 fileName = "OMSIVPOSAP_71_XD.csv" ;
//		this.runInbound(fileName, new OMSIVPOSAP()) ;
//
		 fileName = "OMSIVPOSAP_72_DC.csv" ;
		this.runInbound(fileName, new OMSIVPOSAP()) ;
//
//		 fileName = "OMSIVPOSAP_105_PO.csv" ;
//		this.runInbound(fileName, new OMSIVPOSAP()) ;
//
		 fileName = "OMSIVPOSAP_504.csv" ;
		this.runInbound(fileName, new OMSIVPOSAP()) ;

		 fileName = "OMSIVPOSAP_508.csv" ;
		//String fileName = "OMSIVPOSAP_20110505200030359_1216247.csv" ;
//		String fileName = "OMSIVPOSAP_20121018165947943_626538.csv" ;
		this.runInbound(fileName, new OMSIVPOSAP()) ;

	}
	
	public void testMMConfig() throws Exception {
		String fileName = "OMSMMCODES_20110418-172625363_1111714.csv" ;
		this.runInbound(fileName, new OMSMMCODES()) ;
	}
	
	public void testGoodsCh() throws Exception {
		//String fileName = "OMSGOODSCH_201104281534048_124991.csv" ;
		String fileName = "OMSGOODSCH_201209031726015_1211358_161.csv";
//		String fileName = "OMSGOODSCH_161_NoZR11.csv";
		this.runInbound(fileName, new OMSGOODSCH()) ;
	}

	public void testEIP01() throws Exception {
		String fileName = "OMSDSEIP01_20110504-120952610_1119173.csv" ;
		this.runInbound(fileName, new OMSDSEIP01()) ;
		
	}
	public void testVendorRtv() throws Exception {
		String fileName = "OMSVENDRTV_sample.csv" ;
		this.runInbound(fileName, new OMSVENDRTV()) ;
	}
	
	public void testXDPOSTO() throws Exception {
		String fileName = "OMSXDPOSTO_sample.csv" ;
		this.runInbound(fileName, new OMSXDPOSTO()) ;
	}
	
	private void runInbound(String fileName,InboundProc proc) {
		File dataFile = new File(_PATH + fileName) ;
		proc.execute(dataFile) ;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		TestDataEx test = new TestDataEx() ;
		try{
			//test.testBsClass() ;
			//test.testExRate() ;
			//test.testCalendar() ;
			//test.testInbound() ;
			//test.testComment() ;
			//test.testVendor() ;
//			test.testCondition() ;
			//test.testPayType() ;
			//test.testDcsh() ;
			//test.testAccountAr() ;
			//test.testOpenSalesValue() ;
			//test.testDailyArProcess() ;
			//test.testSkuCtrl() ;
			//test.testDeduction() ;
			//test.testPoNew() ;
			//test.testStorePc() ;
			//test.testTransPay() ;
			//test.testEip02() ;
			//test.testSkuMst() ;
			//test.testVoucherResult() ;
			//test.testCRM02() ;
			//test.testSapSale() ;
			//test.testBuyer() ;
			//test.testCharacter() ;
//			test.testVendorAp() ;
//			test.testVendorRtv();
			//test.testIvStock() ;
			//test.testAccountService() ;
			//test.testBsStore() ;
			//test.testPriceService() ;
			//test.testMMConfig() ;
			//test.testSkuSrc() ;
			//test.testPriceService() ;
			//test.testArsWorkSheet() ;
			//test.testZip() ;
			//test.testSap06() ;
			//test.testB2B04() ;
//			test.testPo() ;
//			test.testGoodsCh() ;
			//test.testEIP01() ;
			//test.testSkuCost() ;
			test.testXDPOSTO();
			
//			PdSkuDao dao = (PdSkuDao)AppContext.getBean("pdSkuDao") ;
//			String event = dao.findStoreEventBySku("00617", "000220981") ;
//			System.out.println(" : "+(event == null)) ;
			
//			PriceConditionService service = (PriceConditionService)AppContext.getBean("conditionService") ;
//			service.calculateVariation(new Date(), 0) ;
//			service.passivateCondition() ;


//			PriceConditionService service = (PriceConditionService)AppContext.getBean("conditionService") ;
//			service.calculateVariation(7) ;
			//PriceCondition n= service.getPriceConditionDao().loadConditionByOid("A31F0E5130C522C3E040007F01001F77") ;
			//PriceCondition o= service.getPriceConditionDao().loadConditionByOid("A320F020DDFD6A8BE040007F010059D8") ;
			//System.out.println(" : "+(n.compare(o)).getStartDate()) ;
			
			//service.changePrice() ;
			
			
//			CostPriceConditionService service = (CostPriceConditionService)AppContext.getBean("costConditionService") ;
//			service.changePrice() ;
			
			
			System.out.println("finish") ;
			System.exit(1) ;
		}catch(Exception e){
			e.printStackTrace() ;
			System.exit(1) ;
		}
	}

}
