/**
 * 
 */
package unittest;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.so.model.SpecialOrder;
import com.rfep.so.service.PoInfoService;
import com.rfep.so.service.TtsPoService;

/**
 * @author richard
 *
 */
public class TtsPoSyncTester extends TestCase {

	private TtsPoService service;
	private PoInfoService poInfoService;
	
	protected void setUp() throws Exception {
		super.setUp();
		this.service = (TtsPoService)AppContext.getBean("ttsPoService");
		this.poInfoService = (PoInfoService)AppContext.getBean("poInfoService");
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	private boolean test(){
		try{
			SpecialOrder order = this.poInfoService.getSpecialOrder("021c5ba372c54bcfb71884d2e357bc1d");
			this.service.deliverOrderToTtsPo(order);
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	
	public void testCreatePo(){
		assertEquals(true, test());
	}
}
