package unittest;

import java.util.Calendar;
import java.util.Map;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.nr.service.NrService;
import com.rfep.nr.util.NrUtils;
import com.rfep.trans.service.TransSalesWkService;

public class TestTransSalesWkService extends TestCase{
	
	public void testGetTrackingNo() throws Exception{
		NrService nService = (NrService)AppContext.getBean("nrService");
		TransSalesWkService tWkService = (TransSalesWkService)AppContext.getBean("transSalesWkService");
		String _storeId = "00601";
		String _trackingNo = null;
		String _processDate = null;
		
		Calendar calendar8ago = tWkService.asignPreviousWeeks(8);
		Calendar calendarNow = tWkService.createCalendar();
		while( calendarNow.getTimeInMillis() > calendar8ago.getTimeInMillis() )
		{
			//取得執行日期
//			String processDate = NrUtils.getTransferDateString(new Date());
			//取得該日的所有應執行的control data
			_processDate = NrUtils.getTransferDateString(calendar8ago.getTime());
			System.out.print(" store : " + _storeId +" processDate : " + _processDate );
//			_trackingNo = nService.getTransferTrackingNo(calendar8ago.getTime(), _storeId);
			System.out.println(" >> trackingNo : " + _trackingNo);
			
			if( _trackingNo != null ){
				
				Map wkSales = tWkService.findTransSalesWkTrackingNoLog(_storeId, _processDate);
				if( wkSales != null ){
					String logTrackingNo = (String)wkSales.get("TRACKING_NO");
					if( !logTrackingNo.equals(_trackingNo) ){
						System.out.println(" update  ");
						tWkService.updateTransSalesWkTrackingNoLog(_storeId, _processDate, _trackingNo);
					}
				}else{
					tWkService.createTransSalesWkTrackingNoLog(_storeId, _processDate, _trackingNo, "1");
				}
			}
			calendar8ago.add(Calendar.DATE, 1);
		}
	}
}