package unittest;


import com.rfep.dataex.cb.outbound.OMSDSB2B08;
import junit.framework.TestCase;

/**
 * OMS合營每日銷售明細拋轉B2B
 *
 * @author leo.tu
 * @date 2012-07-25
 */
public class TestOMSDSB2B08 extends TestCase {

	@Override
	protected void setUp() throws Exception {
		super.setUp();
	}

	public void testOMSARSWKST() {
		OMSDSB2B08 oms = new OMSDSB2B08();
		oms.execute();
	}

	public void testFileContent() {
		OMSDSB2B08 omsdsb2B08 = new OMSDSB2B08();
		System.out.println(omsdsb2B08.getFileContent(omsdsb2B08.getDataList(), "file1").getDataSegment());
	}
}
