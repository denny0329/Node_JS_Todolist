package unittest.pop;

import com.bnq.util.AppContext;
import com.gccs.bs.service.BsParaService;
import com.trg.oms.action.pop.PopForTlwAction;
import com.trg.oms.model.pop.BsSkuForProduct;
import com.trg.oms.service.pop.PopForTlwService;
import junit.framework.TestCase;
import org.apache.commons.io.IOUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class TestPopForTlw extends TestCase {

    private PopForTlwService popForTlwService;
    private BsParaService bsParaService;

    protected void setUp() throws Exception {
        super.setUp();
        popForTlwService = (PopForTlwService) AppContext.getBean("popForTlwService");
        bsParaService = (BsParaService) AppContext.getBean("bsParaService");
    }

    public void testT04() {
        BsSkuForProduct bsSkuForProduct = new BsSkuForProduct();
        bsSkuForProduct.setSku("016037439,016055106");
        Map queryCondition = new HashMap();
        queryCondition.put("channelId", "TLW");
        queryCondition.put("storeId", "00700");
        queryCondition.put("popSpecName", "TLW");
        queryCondition.put("popFormat", "T04");
        queryCondition.put("printQrCode", "0");
        testRun(bsSkuForProduct, queryCondition);
    }

    public void testT05() {
        BsSkuForProduct bsSkuForProduct = new BsSkuForProduct();
        bsSkuForProduct.setSku("016037439,016055106,014020395,016018944");
        Map queryCondition = new HashMap();
        queryCondition.put("channelId", "TLW");
        queryCondition.put("storeId", "00700");
        queryCondition.put("popSpecName", "TLW");
        queryCondition.put("popFormat", "T05");
        queryCondition.put("printQrCode", "0");
        testRun(bsSkuForProduct, queryCondition);
    }

    public void testT06() {
        BsSkuForProduct bsSkuForProduct = new BsSkuForProduct();
        bsSkuForProduct.setSku("016037439,016055106,014020395,016018944");
        Map queryCondition = new HashMap();
        queryCondition.put("channelId", "TLW");
        queryCondition.put("storeId", "00700");
        queryCondition.put("popSpecName", "TLW");
        queryCondition.put("popFormat", "T06");
        queryCondition.put("printQrCode", "0");
        testRun(bsSkuForProduct, queryCondition);
    }

    public void testT07() {
        BsSkuForProduct bsSkuForProduct = new BsSkuForProduct();
        bsSkuForProduct.setSku("016018945,016037439,016055106,016055106");
        Map queryCondition = new HashMap();
        queryCondition.put("channelId", "TLW");
        queryCondition.put("storeId", "00700");
        queryCondition.put("popSpecName", "TLW");
        queryCondition.put("popFormat", "T07");
        queryCondition.put("printQrCode", "0");
        testRun(bsSkuForProduct, queryCondition);
    }

    public void testT08() {
        BsSkuForProduct bsSkuForProduct = new BsSkuForProduct();
        bsSkuForProduct.setSku("016018945,016055106,014020395,016018944");
        Map queryCondition = new HashMap();
        queryCondition.put("channelId", "TLW");
        queryCondition.put("storeId", "00700");
        queryCondition.put("popSpecName", "TLW");
        queryCondition.put("popFormat", "T08");
        queryCondition.put("printQrCode", "0");
        testRun(bsSkuForProduct, queryCondition);
    }

    public void testT10() {
        BsSkuForProduct bsSkuForProduct = new BsSkuForProduct();
        bsSkuForProduct.setSku("016037439,016055106,016055106,016037439");
        Map queryCondition = new HashMap();
        queryCondition.put("channelId", "TLW");
        queryCondition.put("storeId", "00700");
        queryCondition.put("popSpecName", "TLW");
        queryCondition.put("popFormat", "T10");
        queryCondition.put("printQrCode", "0");
        testRun(bsSkuForProduct, queryCondition);
    }

    public void testRun(BsSkuForProduct bsSkuForProduct, Map queryCondition) {
        try {
            PopForTlwAction action = new PopForTlwAction();
            action.setPopForTlwService(popForTlwService);
            action.setBsParaService(bsParaService);
            action.setQueryCondition(queryCondition);
            action.setBsSkuForProduct(bsSkuForProduct);
            action.tlwExcel();
            InputStream inputStream = action.getInputStream();
            OutputStream outputStream = new FileOutputStream(new File("D:\\" + queryCondition.get("popFormat") + ".xls"));
            IOUtils.copy(inputStream, outputStream);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
