package unittest.pop;

import com.bnq.util.AppContext;
import com.gccs.bs.service.BsParaService;
import com.trg.oms.action.pop.PopForCasaAction;
import com.trg.oms.action.pop.PopForTlwAction;
import com.trg.oms.model.pop.BsSkuForProduct;
import com.trg.oms.service.pop.PopForCasaService;
import com.trg.oms.service.pop.PopForTlwService;
import junit.framework.TestCase;
import org.apache.commons.io.IOUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class TestPopForCasa extends TestCase {

    private PopForCasaService popForCasaService;
    private BsParaService bsParaService;

    protected void setUp() throws Exception {
        super.setUp();
        popForCasaService = (PopForCasaService) AppContext.getBean("popForCasaService");
        bsParaService = (BsParaService) AppContext.getBean("bsParaService");
    }

    public void testRun() {
        try {
            BsSkuForProduct bsSkuForProduct = new BsSkuForProduct();
            bsSkuForProduct.setSku("016014012,016014013");
            Map queryCondition = new HashMap();
            queryCondition.put("channelId", "A0");
            queryCondition.put("storeId", "00700");
            queryCondition.put("popSpecName", "TLW");
            queryCondition.put("popFormat", "C01");
            queryCondition.put("printQrCode", "0");
            PopForCasaAction action = new PopForCasaAction();
            action.setPopForCasaService(popForCasaService);
            action.setBsParaService(bsParaService);
            action.setQueryCondition(queryCondition);
            action.setBsSkuForProduct(bsSkuForProduct);
            action.casaExcel();
            InputStream inputStream = action.getInputStream();
            OutputStream outputStream = new FileOutputStream(new File("D:\\" + queryCondition.get("popFormat") + ".xls"));
            IOUtils.copy(inputStream, outputStream);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
