package unittest.pop;

import com.bnq.util.AppContext;
import com.trg.oms.action.pop.PopForHoiAction;
import com.trg.oms.model.pop.BsSkuForProduct;
import com.trg.oms.service.pop.PopForHoiService;
import junit.framework.TestCase;
import org.apache.commons.io.IOUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class TestPopForHoi extends TestCase {

    private PopForHoiService popForHoiService;

    protected void setUp() throws Exception {
        super.setUp();
        popForHoiService = (PopForHoiService) AppContext.getBean("popForHoiService");
    }

    public void testCase1() {
        try {
            BsSkuForProduct bsSkuForProduct = new BsSkuForProduct();
            bsSkuForProduct.setSku("016080077,016004672,016126948");
            Map queryCondition = new HashMap();
            queryCondition.put("channelId", "A0");
            queryCondition.put("storeId", "00700");
            queryCondition.put("popSpecName", "HOI");
            queryCondition.put("popFormat", "H04");
            queryCondition.put("printQrCode", "0");
            testRun(bsSkuForProduct, queryCondition);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void testRun(BsSkuForProduct bsSkuForProduct, Map queryCondition) {
        try {
            PopForHoiAction action = new PopForHoiAction();
            action.setPopForHoiService(popForHoiService);
            action.setQueryCondition(queryCondition);
            action.setBsSkuForProduct(bsSkuForProduct);
            action.hoiExcel();
            InputStream inputStream = action.getInputStream();
            OutputStream outputStream = new FileOutputStream(new File("D:\\" + queryCondition.get("popFormat") + ".xls"));
            IOUtils.copy(inputStream, outputStream);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
