package unittest.pop;

import com.bnq.util.AppContext;
import com.gccs.bs.service.BsParaService;
import com.trg.oms.action.pop.PopForHolaAction;
import com.trg.oms.model.pop.BsSkuForProduct;
import com.trg.oms.service.pop.PopForHolaService;
import junit.framework.TestCase;
import org.apache.commons.io.IOUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class TestPopForHola extends TestCase {

    private PopForHolaService popForHolaService;
    private BsParaService bsParaService;

    protected void setUp() throws Exception {
        super.setUp();
        popForHolaService = (PopForHolaService) AppContext.getBean("popForHolaService");
        bsParaService = (BsParaService) AppContext.getBean("bsParaService");
    }

    public void test1() {
        Map queryCondition = new HashMap();
        queryCondition.put("channelId", "HOLA");
        queryCondition.put("storeId", "00615");
        queryCondition.put("popFormat", "340");
        queryCondition.put("printQrCode", "0");
        queryCondition.put("start_date", "2019/08/14");
        queryCondition.put("slogans", "-1");

        BsSkuForProduct bsSkuForProduct = new BsSkuForProduct();
        bsSkuForProduct.setSku("014203662,014225363");

        testRun(queryCondition, bsSkuForProduct);
    }

    public void test2() {
        Map queryCondition = new HashMap();
        queryCondition.put("channelId", "A0");
        queryCondition.put("storeId", "00615");
        queryCondition.put("popFormat", "440");
        queryCondition.put("printQrCode", "0");
        queryCondition.put("start_date", "2019/08/14");
        queryCondition.put("slogans", "-1");

        BsSkuForProduct bsSkuForProduct = new BsSkuForProduct();
        bsSkuForProduct.setSku("014203662,014225363");

        testRun(queryCondition, bsSkuForProduct);
    }

    public void testRun(Map queryCondition, BsSkuForProduct bsSkuForProduct) {
        try {
            PopForHolaAction action = new PopForHolaAction();
            action.setPopForHolaService(popForHolaService);
            action.setBsParaService(bsParaService);
            action.setQueryCondition(queryCondition);
            action.setBsSkuForProduct(bsSkuForProduct);
            action.holaExcel();
            InputStream inputStream = action.getInputStream();
            OutputStream outputStream = new FileOutputStream(new File("D:\\" + queryCondition.get("popFormat") + ".xls"));
            IOUtils.copy(inputStream, outputStream);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
