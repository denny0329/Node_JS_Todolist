package unittest;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import junit.framework.TestCase;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.bnq.util.AppContext;
import com.bnq.util.PageBean;
import com.rfep.trans.dao.hibernate.TransGuiNosDao;
import com.rfep.trans.model.TransGuiNosDtl;
import com.rfep.trans.service.TransGuiNosService;
import com.rfep.trans.vo.TransGuiNosDtlVO;
import com.rfep.trans.vo.TransGuiNosPosVO;

/**
 * @author peipei
 * @Date: 2009/4/9 下午 7:01:03
 * @Project Name: BNQRFEP
 * @Package Name: unittest
 * @File Name: TestTransGuiNosPosService.java
 */
public class TestTransGuiNosService extends TestCase {
	
	public void testGetTransGuiNosPosByCondition() throws Exception {
		//this.getTransGuiNosPosService().getTransGuiNosPosByCondition(getQueryCondition(), this.getPageBean()
		//TransGuiNosPosDao dao = (TransGuiNosPosDao)AppContext.getBean("TransGuiNosPosDao");
		TransGuiNosService service = (TransGuiNosService)AppContext.getBean("transGuiNosService");
		Map queryCondition = new HashMap();
		queryCondition.put("channelId", new String[]{"H-OLT"});
		queryCondition.put("storeId", new String[]{"00601"});
		queryCondition.put("guiYm", new String[]{"201101"});
		//queryCondition.put("posNos", new String[]{"002"});
		
		PageBean pageBean = service.getTransGuiNosPosByCondition(queryCondition, new PageBean());
		for(Iterator iterator = pageBean.getQueryList().iterator(); iterator.hasNext(); ) {
			TransGuiNosPosVO dtl = (TransGuiNosPosVO)iterator.next();
			System.out.println(ToStringBuilder.reflectionToString(dtl));
//			System.err.println("dtl: "+dtl.getOid()+" -> "+dtl.getPosQuantity() + "/" + dtl.getPosBegin());
//			System.err.println("	mst:"+dtl.getMstOid().getOid()+"/"+dtl.getMstOid().getChannelId());
		}
	}

	//findTransGuiNosDtlVOById
	public void testFindTransGuiNosDtlVOById() throws Exception {
		TransGuiNosService service = (TransGuiNosService)AppContext.getBean("transGuiNosService");
		String oid = "402881bf2983019e0129830309ff0005"; //trans_gui_nos_dtl.oid
		TransGuiNosDtlVO vo = service.findTransGuiNosDtlVOById(oid);
		System.out.println(ToStringBuilder.reflectionToString(vo));
	}
	
	public void testFindTransGuiNosDtlVOByCondition(){
		TransGuiNosService service = (TransGuiNosService)AppContext.getBean("transGuiNosService");
		Map queryCondition = new HashMap();
		queryCondition.put("channelId", new String[]{"HOLA"});
		queryCondition.put("storeId", new String[]{"00603"});
		queryCondition.put("guiYm", new String[]{"201003"});
		queryCondition.put("activate", new String[]{"1"});
		TransGuiNosDtlVO transGuiNosDtlVO = service.findTransGuiNosDtlVOByCondition(queryCondition, true);
		
		System.out.println(transGuiNosDtlVO.getOid());
		System.out.println(transGuiNosDtlVO.getChannelId());
		System.out.println(ToStringBuilder.reflectionToString(transGuiNosDtlVO));
		
		service.initPosQuantityForAdd(transGuiNosDtlVO); //**
		
		System.out.println(transGuiNosDtlVO.getOid());
		System.out.println(transGuiNosDtlVO.getChannelId());
		System.out.println(ToStringBuilder.reflectionToString(transGuiNosDtlVO));
	}
	
	public void testGetExistSameYm(){
		TransGuiNosService service = (TransGuiNosService)AppContext.getBean("transGuiNosService");
		Map queryCondition = new HashMap();
		queryCondition.put("channelId", new String[]{"HOLA"});
		queryCondition.put("storeId", new String[]{"00606"});
		queryCondition.put("guiYm", new String[]{"201001"});
		queryCondition.put("activate", new String[]{"1"});
		
		TreeSet<String> existSameYm = service.getExistSameYm(queryCondition);
		System.out.println("existSameYm="+existSameYm);
		
	}
	
	public void testFindTransGuiNosDtlByCondition() throws Exception{
		TransGuiNosService service = (TransGuiNosService)AppContext.getBean("transGuiNosService");
		TransGuiNosDao dao = (TransGuiNosDao)AppContext.getBean("TransGuiNosDao");
		Map queryCondition = new HashMap();
		queryCondition.put("channelId", new String[]{"H-OLT"});
		queryCondition.put("storeId", new String[]{"00601"});
		queryCondition.put("guiYm", new String[]{"201101"});
		queryCondition.put("activate", new String[]{"1"});
		
		List<TransGuiNosDtl> tmpList = service.findTransGuiNosDtlByCondition(queryCondition);
		System.out.println(ToStringBuilder.reflectionToString(tmpList));
		
	}
}
