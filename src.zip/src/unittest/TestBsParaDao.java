/**
 * @(#)TestBsParaDao.java Jun 15, 2015
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest;

import org.hibernate.SessionFactory;

import com.bnq.util.AppContext;
import com.rfep.bs.dao.hibernate.BsParaDao;

import junit.framework.TestCase;

/**
 * @author T2482
 */
public class TestBsParaDao extends TestCase {
	private BsParaDao dao = new BsParaDao();

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		dao.setSessionFactory((SessionFactory)AppContext.getBean("sessionFactory"));
	}

	public void testGetLimitValues() {
		for(String value : dao.getLimitValues("PR", "BACKUP_SMALL_CHANNEL", "1010")) {
			System.out.println(value);
		}
	}
}
