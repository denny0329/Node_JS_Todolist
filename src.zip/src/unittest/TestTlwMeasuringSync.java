package unittest;

import com.rfep.so.model.Measuring;
import com.rfep.so.service.MeasuringService;
import com.rfep.tts.sync.tlw.TlwMeasuringSync;
import junit.framework.Assert;
import junit.framework.TestCase;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestTlwMeasuringSync extends TestCase {
    private TlwMeasuringSync tlwMeasuringSync;
    private MeasuringService measuringService;

    protected void setUp() throws Exception {
        super.setUp();
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        tlwMeasuringSync = (TlwMeasuringSync) context.getBean("tlwMeasuringSync");
        measuringService = (MeasuringService) context.getBean("measuringService");

    }

    public void testSyncCaseInfo() {

        String oid = "8332b14911bc4ef2ab7466196a56f170";

        try {
            Measuring measuring = measuringService.getMeasuringByOid(oid, false);
            tlwMeasuringSync.syncMeasuring(measuring);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("sync 失敗");
            Assert.assertTrue(false);
        } finally {
            tlwMeasuringSync.closeConnection();
        }

    }

}
