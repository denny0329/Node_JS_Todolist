package unittest;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.trans.service.TransFormService;

public class TestForm extends TestCase {
	public void testForm() throws Exception {
		TransFormService service = (TransFormService)AppContext.getBean("transFormService");
//		service.refundFormProcessAll("fafdafafafa");
		service.refundFormProcessSingle("EQREQRQREQR");
	}
}
