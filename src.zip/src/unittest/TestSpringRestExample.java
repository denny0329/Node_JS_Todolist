package unittest;

import java.nio.charset.Charset;

import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.bnq.util.AppContext;
import com.rfep.iv.po.dao.PoAppliedDao;

public class TestSpringRestExample {

//	public static final String SERVER_URI = "http://tlwnew.testritegroup.com/TLW/poSpecStatus";
	
	public static void main(String args[]){
		
		System.out.println("*****");
		testCreateEmployee();
	}

	

	private static void testCreateEmployee() {
		PoAppliedDao poAppliedDao = (PoAppliedDao) AppContext.getBean("poAppliedDao");
		RestTemplate restTemplate = new RestTemplate();
		String rejectReason = "哈阿拉伯但是擃脫穎而出螺絲起子阿爾巴尼亞嘎啦哭起來來不及及時";
		String specStatus = "N";
		String poNo = "1050114298";
		String SERVER_URI = "";
		String codeClass = "B2B";
		String codeNo = "poSpecStatus";
		
		SERVER_URI = poAppliedDao.findB2BWebserviceUrl(codeClass, codeNo);
		System.out.println("SERVER_URI = " + SERVER_URI);
		
		JSONObject test = new JSONObject(); 
		test.put("PO_NO", poNo);
		test.put("SPEC_STATUS", specStatus);
		
		if(specStatus == "N"){
			test.put("REJECT_REASON", rejectReason);
    	}
		System.out.println("test = " + test);
		HttpHeaders headers = new HttpHeaders();
	    MediaType mediaType = new MediaType("application", "json", Charset.forName("UTF-8"));
	    headers.setContentType(mediaType);
	    
	    HttpEntity<String> entity = new HttpEntity<String>(test.toString(), headers);
		System.out.println("entity = "+entity);
		ResponseEntity<String> response = restTemplate.postForEntity(SERVER_URI, entity, String.class);
		System.out.println("response = " + response);
	}

}