package unittest;

import java.util.Arrays;
import java.util.List;

import junit.framework.TestCase;

import org.springframework.orm.hibernate3.HibernateTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import com.bnq.util.AppContext;
import com.rfep.bs.dao.hibernate.BsParaDao;
import com.rfep.iv.dao.InventoryDao;
import com.rfep.iv.po.dao.hibernate.PoDao;
import com.rfep.iv.po.service.PoAppliedService;
import com.rfep.iv.rtv.dao.RtvDao;
import com.rfep.iv.rtv.service.RtvService;
import com.rfep.iv.service.InventoryService;
import com.rfep.iv.sto.dao.hibernate.StoDao;
import com.trg.oms.utils.dao.WsLogDao;
import com.trg.oms.ws.OmsResultVo;
import com.trg.oms.ws.impl.OmsWebServiceForEcImpl;

public class TestOmsWebServiceForEcImpl extends TestCase{
	
	private OmsWebServiceForEcImpl ws = new OmsWebServiceForEcImpl();
	private OmsResultVo vo = null;
	private String poId = null;
	private String formType = null;
	String empId = "EC";
	String empName = "EC";
	
	/**
	 * 
	 */
	protected void setUp() throws Exception {
		super.setUp();
		ws.setBsParaDao((BsParaDao)AppContext.getBean("bsParaDao"));
		ws.setPoAppliedService((PoAppliedService)AppContext.getBean("poAppliedService"));
		ws.setRtvService((RtvService)AppContext.getBean("rtvService"));
		ws.setInventoryService((InventoryService)AppContext.getBean("inventoryService"));
		ws.setPoDao((PoDao)AppContext.getBean("poDao"));
		ws.setInventoryDao((InventoryDao)AppContext.getBean("inventoryDao"));
		ws.setRtvDao((RtvDao)AppContext.getBean("rtvDao"));
		ws.setWsLogDao((WsLogDao)AppContext.getBean("wsLogDao"));
		ws.setStoDao((StoDao)AppContext.getBean("stoDao"));
		HibernateTransactionManager txnManager = (HibernateTransactionManager)AppContext.getBean("dataSourceTxManager");
		TransactionTemplate txnTemplate = new TransactionTemplate();
		txnTemplate.setTransactionManager(txnManager);
		ws.setTransactionTemplate(txnTemplate);
	}
	
	/**
	 * 
	 */
	public void testdeletePoByEc() {
		
		poId = "5500151740";
		formType = "stox";
		vo = ws.deletePoByEc(poId, formType);
		vo.getStatus();
		vo.getErrMsg();
	}

	/**
	 * 
	 */
	public void testoutPoRtvFile() {		
		String formNo = "4600000001";
		String storeId = "00620";
		vo = ws.outPoRtvFile(formNo, storeId);
		vo.getStatus();
		vo.getErrMsg();
	}
	
	/**
	 * 
	 */
	public void testupdateRCPOSTO() {		
		//PO
		String poId = "1102666499";
		String formType = "PO";
		String poType = "";
		String rcDate = "20171103112853";
		List<String> sku = Arrays.asList("016001984", "016065734", "016065735");
		List<String> quantity = Arrays.asList("24", "24", "24");
		vo = ws.updateRCPOSTO(poId, formType,poType,empId,empName,rcDate,sku,quantity);
		vo.getStatus();
		vo.getErrMsg();
		//STO
		String poId1 = "5200472959";
		String formType1 = "STO";
		String rcDate1 = "20171105132853";
		List<String> sku1 = Arrays.asList("000283672", "000193006");
		List<String> quantity1 = Arrays.asList("15", "70");
		vo = ws.updateRCPOSTO(poId1, formType1,poType,empId,empName,rcDate1,sku1,quantity1);
		vo.getStatus();
		vo.getErrMsg();
	}
	
	/**
	 * 
	 */
	public void testupdateRCPallet() {		
		String wave = "2016061401";
		String palletId = "DP1606140422";
		String toStore = "1A02";
		String rcDate = "20171103153158";
		List<String> trfNoList = Arrays.asList("5200473033", "5200473039");
		List<String> itemNoList = Arrays.asList("1", "1");
		List<String> skuList = Arrays.asList("000283671", "000294885");
		List<String> qtyList = Arrays.asList("12", "10");
		vo = ws.updateRCPallet(wave, palletId, toStore, empId, empName, rcDate, trfNoList, itemNoList, skuList, qtyList);
		vo.getStatus();
		vo.getErrMsg();
	}
	
	/**
	 * 
	 */
	public void testupdateSTORESTO() {	
		//調出
		String inSite = "1A17";
		String actType = "1";
		String outSite = "1WZ9";
		String upDate = "20171128111711";
		String trfNo = "5300599983";
		List<String> itemNoList = Arrays.asList("1", "2");
		List<String> skuList = Arrays.asList("000280051", "000276897");
		List<String> qtyList = Arrays.asList("10", "50");
		vo = ws.updateSTORESTO(inSite,actType,outSite,empId,empName,upDate,trfNo,itemNoList,skuList,qtyList);
		vo.getStatus();
		vo.getErrMsg();
		//驗收
		String inSite1 = "1AZ9";
		String actType1 = "2";
		String outSite1 = "1B03";
		String upDate1 = "20171129123456";
		String trfNo1 = "5300572820";
		List<String> itemNoList1 = Arrays.asList("1", "2", "3");
		List<String> skuList1 = Arrays.asList("014119278", "014119280", "016067178");
		List<String> qtyList1 = Arrays.asList("4", "3","1");
		vo = ws.updateSTORESTO(inSite1,actType1,outSite1,empId,empName,upDate1,trfNo1,itemNoList1,skuList1,qtyList1);
		vo.getStatus();
		vo.getErrMsg();
	}
	
	/**
	 * 
	 */
	public void testupdateOUTRTV() {	
		//
		String outSite = "1B15";
		formType = "1";
		String formNo = "4600765126";
		String poType = "ZS71";
		String outDate = "20171218123456";
		List<String> itemNo = Arrays.asList("1");
		List<String> sku = Arrays.asList("009444767");
		List<String> qty = Arrays.asList("1999");
		vo = ws.updateOUTRTV(outSite, formType, formNo, poType, empId, empName, outDate, itemNo, sku, qty);
		vo.getStatus();
		vo.getErrMsg();
		//
		String outSite1 = "1B03";
		formType = "2";
		String formNo1 = "7199295820";
		String poType1 = "ZS71";
		String outDate1 = "20171218123456";
		List<String> itemNo1 = Arrays.asList("1");
		List<String> sku1 = Arrays.asList("016026902");
		List<String> qty1 = Arrays.asList("1999");
		vo = ws.updateOUTRTV(outSite1, formType, formNo1, poType1, empId, empName, outDate1, itemNo1, sku1, qty1);
		vo.getStatus();
		vo.getErrMsg();
	}
}
