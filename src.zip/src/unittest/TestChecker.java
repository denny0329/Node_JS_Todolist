/**
 * @(#)TestChecker.java.java Jun 15, 2015
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest;

import com.trg.oms.checker.WsValueLengthTypeChecker;

import junit.framework.TestCase;

/**
 * @author T2482
 *
 */
public class TestChecker extends TestCase {

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
	}
	
	public void testSomValueLengthTypeChecker() {
		StringBuilder notes = new StringBuilder();
		notes
			.append("(1)\t貨到排安裝運送，免費標準安裝，非標準安裝現場收費(如價格須知表)")
			.append("\r\n(2)\t樓安裝，登高費50元店內吸收，有電梯免收登高費")
			.append("\r\n(3)\t跨區費A區免費，B區+100元，C區+200元 ，D區+300元，跨區費100元，店內吸收")
			.append("\r\n(4)\t現場有舊機要拆除並請師父回收不必收費，若只拆除舊機，不運棄，分離式加收600元，窗型加收200元")
			.append("\r\n(5)\t室外機供電，現場有預留220V電源及插座(窗型冷氣口) ，若無預留，加裝插座須收200元，加裝插頭須加收120元")
			.append("\r\n(6)\t現場有用到電源線會另外收費，電源線(3.5mm)每公尺150元 (5.5mm)每公尺180元")
			.append("\r\n(7)\t信號線5米不收費，超過5米，4芯1.25mm信號線每公尺100元，4芯2.0mm信號線每公尺120元")
			.append("\r\n(8)\t請師傅帶簡易型支撐架過去，再確認現場是否要安裝，若須安裝簡易型支撐架，牆內側一組(小)500元(大)800元，牆外側一組(小)1200元(大)1500元，現場收費")
			.append("\r\n(9)\t現場若須鐵窗裁切300元/窗，不鏽鋼裁切600/窗，切割玻璃走冷媒管不收費，但不負責玻璃完整性")
			.append("\r\n(10)\t若現場需穿牆鑽孔，RC牆、水泥磚牆，費用800元；木作、輕隔間牆、鋁板鑽孔每孔200元")
			.append("\r\n(11)\t若加裝雨棚工資一組500元，雨棚費用分離式一組760元，窗型一組629元");
		
		StringBuilder remark = new StringBuilder();
		remark
			.append("(1)	貨到排安裝運送，免費標準安裝，非標準安裝現場收費(如價格須知表)<br>")
			.append("(2)	樓安裝，登高費50元店內吸收，有電梯免收登高費<br>")
			.append("(3)	跨區費A區免費，B區+100元，C區+200元 ，D區+300元，跨區費100元，店內吸收<br>")
			.append("(4)	現場有舊機要拆除並請師父回收不必收費，若只拆除舊機，不運棄，分離式加收600元，窗型加收200元<br>")
			.append("(5)	室外機供電，現場有預留220V電源及插座(窗型冷氣口) ，若無預留，加裝插座須收200元，加裝插頭須加收120元<br>")
			.append("(6)	現場有用到電源線會另外收費，電源線(3.5mm)每公尺150元 (5.5mm)每公尺180元<br>")
			.append("(7)	信號線5米不收費，超過5米，4芯1.25mm信號線每公尺100元，4芯2.0mm信號線每公尺120元<br>")
			.append("(8)	請師傅帶簡易型支撐架過去，再確認現場是否要安裝，若須安裝簡易型支撐架，牆內側一組(小)500元(大)800元，牆外側一組(小)1200元(大)1500元，現場收費<br>")
			.append("(9)	現場若須鐵窗裁切300元/窗，不鏽鋼裁切600/窗，切割玻璃走冷媒管不收費，但不負責玻璃完整性<br>")
			.append("(10)	若現場需穿牆鑽孔，RC牆、水泥磚牆，費用800元；木作、輕隔間牆、鋁板鑽孔每孔200元<br>")
			.append("(11)	若加裝雨棚工資一組500元，雨棚費用分離式一組760元，窗型一組629元;");

		WsValueLengthTypeChecker checker = new WsValueLengthTypeChecker("remark", notes.toString(), 550, null);
		try {
			checker.execute();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
