package unittest;

import java.util.Date;

import org.springframework.orm.hibernate3.HibernateTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import com.bnq.util.AppContext;
import com.bnq.util.DateUtils;
import com.rfep.product.bs.dao.hibernate.BsPriceConditionDao;
import com.rfep.product.bs.dao.hibernate.BsSkuStoreDao;
import com.rfep.product.bs.service.PdSkuService;
import com.rfep.product.bs.service.PriceConditionService;
import com.rfep.product.bs.service.RegularPriceConditionService;
import com.rfep.product.bs.service.TransSkuVariationService;

public class TestTransSkuVariation {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		TestTransSkuVariation test = new TestTransSkuVariation();
		test.testCalculateVariation();
	}

	private void testCalculateVariation() {
		PriceConditionService service = (PriceConditionService)AppContext.getBean("conditionService");
		service.setSkuService((PdSkuService)AppContext.getBean("pdService"));
		service.setPriceConditionDao((BsPriceConditionDao)AppContext.getBean("priceConditionDao"));
		service.setTransSkuVariationService((TransSkuVariationService)AppContext.getBean("transSkuVariationService"));
		service.setRegularConditionService((RegularPriceConditionService)AppContext.getBean("regularConditionService"));
		
		TransactionTemplate transaction = new TransactionTemplate();
		transaction.setTransactionManager((HibernateTransactionManager)AppContext.getBean("dataSourceTxManager"));
		service.setTransactionTemplate(transaction);
		
		service.setBsSkuStoreDao((BsSkuStoreDao)AppContext.getBean("bsSkuStoreDao"));
		
		Date calDate = DateUtils.getDate("2013/02/09");
		String storeId = "00603";
		int days = 1;
		
		service.calculateVariation(calDate, storeId, days);
	}
}
