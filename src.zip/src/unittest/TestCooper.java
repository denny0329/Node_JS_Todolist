package unittest;

import java.awt.Toolkit;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.dataex.mm.outbound.OMSGOODSMV;
import com.rfep.iv.po.dao.hibernate.PoDao;
import com.rfep.iv.po.model.Po;
import com.rfep.iv.sa.dao.StockAdjustmentDao;
import com.rfep.iv.sa.model.StockAdjustment;
import com.rfep.iv.service.InventoryService;
import com.rfep.iv.service.IvGoodsMvService;
import com.rfep.util.cache.BsCostCenterDefinition;

public class TestCooper extends TestCase {
	//Cooper Test
	IvGoodsMvService ivGoodsMvService = null;
	StockAdjustmentDao stockAdjustmentDao = null;
	PoDao poDao= null;
	private final String OID = "d0b89e35718f4e90972ae9df15fe14d5";
	
	@Override
	protected void setUp() throws Exception {
		ivGoodsMvService = (IvGoodsMvService)AppContext.getBean("ivGoodsMvService");
		stockAdjustmentDao = (StockAdjustmentDao)AppContext.getBean("stockAdjustmentDao");
		poDao = (PoDao)AppContext.getBean("poDao");
		super.setUp();
	}
	
	public void testOMSGOODSMV(){
		OMSGOODSMV oms = new OMSGOODSMV();
		oms.execute();
	}
	
	public void testStoragePo() throws Exception{
			final Po po = poDao.loadByPoNo("1940000157");		
			ivGoodsMvService.storagePo(po,null);	
	}
	public void testStockAdjustment(){
		StockAdjustment stockAdjustment= stockAdjustmentDao.findById(StockAdjustment.class, "f54f4a2d80e2462ba17f505785a17a73");
		ivGoodsMvService.stockAdjustment(stockAdjustment);
	}
	
	public void testPoDao(){
		//List<PoSku> lists = poDao.findPoSkuListBySku("000103970");	
		//System.out.print(lists);
	}
	
	public void testSequence(){
		InventoryService inventoryService= (InventoryService)AppContext.getBean("inventoryService");
		System.out.println(">*>*> TS:"+ inventoryService.getTrfSummarySequence());
	}
	
	public void testCostCenter(){
		String ccId = BsCostCenterDefinition.getCcIdByDeptId("01900");
		System.out.print(ccId);
	}
	
	public void testAWT(){
		System.out.println(Toolkit.getDefaultToolkit().getScreenResolution());
	}

	public static void main(String[] args) {
		System.out.println(Toolkit.getDefaultToolkit().getScreenResolution());
		
//		String file ="OMSGOODSMV_20110221145032830.CSV";
//		System.out.print(StringUtils.substringBefore(file, "_"));
	}
}
