/**
 * 
 */
package unittest.iv;

import java.util.Date;

import junit.framework.TestCase;

import org.apache.commons.lang.builder.ToStringBuilder;

import unittest.util.TestUtil;

import com.bnq.util.AppContext;
import com.rfep.iv.service.InventoryService;
import com.rfep.iv.sto.service.StoService;
import com.rfep.iv.sto.util.StoGlossary;
import com.rfep.iv.trf.model.Trf;
import com.rfep.iv.trf.model.TrfSku;
import com.rfep.iv.trf.model.TrfSrc;
import com.rfep.iv.util.InventoryUtil;

/**
 * 
 * @author peipei
 *
 */
public class TestTrfService extends TestCase {
	InventoryService inventoryService = null;
	StoService stoService = null;
	private final String OID = "9c476620ee0242649a763e92c32361b0";
	
	@Override
	protected void setUp() throws Exception {
		inventoryService = (InventoryService)AppContext.getBean("inventoryService");
		stoService = (StoService)AppContext.getBean("stoService");
		super.setUp();
	}
	
	public void testSequence() throws Exception{
		System.out.println(">*>*>    PO:"+ inventoryService.getTrfSequence());
		System.out.println(">*>*> SO_PO:"+ inventoryService.getSoPoSequence());
		System.out.println(">*>*>PO_RTV:"+ inventoryService.getPoRtvSequence());
		System.out.println(">*>*>XD_TRF:"+ inventoryService.getXdTrfSequence());
		System.out.println(">*>*>DC_TRF:"+ inventoryService.getDcTrfSequence());
		System.out.println(">*>*>XD_RTV:"+ inventoryService.getXdRtvSequence());
		System.out.println(">*>*>DC_RTV:"+ inventoryService.getDcRtvSequence());
		System.out.println(">*>*>   TRF:"+ inventoryService.getTrfSequence());
		System.out.println(">*>*> SO_XD:"+ inventoryService.getSoXdSequence());
	}
	
	public void testCreateTrf_XD(String formId) {
		String userId = "H001";
		String userName = "H001 Name";
		String user2Id = "H002";
		String user2Name = "H002 Name";
		
		final Trf trf = new Trf();
		trf.setTrfNo(inventoryService.getXdTrfSequence());
		trf.setPoType(InventoryUtil.getPoType(InventoryUtil.SEQ_KEY_XD_TRF));
		trf.setType("3");
		trf.setInChannelId("TLW");
		trf.setInStoreId("01900");
		trf.setInStoreName("�s����");
		trf.setInUserId(userId);
		trf.setInUserName(userName);
		trf.setOutChannelId("C01");
		trf.setOutStoreId("S01");
		trf.setOutStoreName("S01 Name");
		trf.setOutUserId(user2Id);
		trf.setOutUserName(user2Name);
		trf.setOutDate(new Date());
		trf.setType("1,3");
		trf.setStatus(StoGlossary.TRF_STATUS_0_DRAFT);
		trf.setTrfType("XD");
		trf.setEstArrival(new Date());
		trf.setActArrival(null);
		trf.setRemark("Trf Remark");
		
		TestUtil.prepareDateInfoForCurrentUser(trf, 3, userId, userName);
		
		TrfSrc trfSrc1 = new TrfSrc();
		trfSrc1.setTrfOid(trf);
		trfSrc1.setSrcNo("SRC_001");
		trfSrc1.setSrcNote("SRC NOTE 01");
		TestUtil.prepareDateInfoForCurrentUser(trfSrc1, 3, "H00246", "������");
		
		//add TrfSrc to Trf
		trf.addTrfSrc(trfSrc1);
		
		//TrfSku 1
		TrfSku sku1 = new TrfSku();
		sku1.setTrfOid(trf);
		sku1.setTrfSrcOid(trfSrc1);
		sku1.setSeqNo(1);
		sku1.setSku("115835");
		sku1.setSkuName("115835 name");
		sku1.setUpc("115835000");
		sku1.setVendorId("V001");
		sku1.setVendorName("V001 Name");
		sku1.setApplyQty(1);
		sku1.setRegularPrice(11d);
		sku1.setPrice(200d);
		sku1.setBuyCost(100d);
		sku1.setCost(100d);
		sku1.setCustQty(1);
		sku1.setMinOrderQty(1d);
		sku1.setStdPack(1d);
		sku1.setInnerPack(null);
		sku1.setArsFlag(1);
		sku1.setHoldOrder(0);
		sku1.setAoh(10);
		sku1.setRemark("sku1 remark");
		TestUtil.prepareDateInfoForCurrentUser(sku1, 3, "H001", "H001 Name");
		trfSrc1.addTrfSku(sku1);
		
		//TrfSku 2
		TrfSku sku2 = new TrfSku();
		sku2.setTrfOid(trf);
		sku2.setTrfSrcOid(trfSrc1);
		sku2.setSeqNo(2);
		sku2.setSku("115836");
		sku2.setSkuName("115836 name");
		sku2.setUpc("115836000");
		sku2.setVendorId("V002");
		sku2.setVendorName("V002 Name");
		sku2.setApplyQty(2);
		sku2.setRegularPrice(22d);
		sku2.setPrice(400d);
		sku2.setBuyCost(200d);
		sku2.setCost(200d);
		sku2.setCustQty(2);
		sku2.setMinOrderQty(2d);
		sku2.setStdPack(2d);
		sku2.setInnerPack(null);
		sku2.setArsFlag(1);
		sku2.setHoldOrder(0);
		sku2.setAoh(20);
		sku2.setRemark("sku2 remark");
		TestUtil.prepareDateInfoForCurrentUser(sku2, 3, "H001", "H001 Name");
		trfSrc1.addTrfSku(sku2);
		
		TrfSrc trfSrc2 = new TrfSrc();
		trfSrc2.setTrfOid(trf);
		trfSrc2.setSrcNo("SRC_002");
		trfSrc2.setSrcNote("SRC NOTE 02");
		TestUtil.prepareDateInfoForCurrentUser(trfSrc2, 3, "H00246", "������");
		
		//add TrfSrc to Trf
		trf.addTrfSrc(trfSrc2);
		
		//TrfSku 3
		TrfSku sku3 = new TrfSku();
		sku3.setTrfOid(trf);
		sku3.setTrfSrcOid(trfSrc1);
		sku3.setSeqNo(3);
		sku3.setSku("115837");
		sku3.setSkuName("115837 name");
		sku3.setUpc("115837000");
		sku3.setVendorId("V003");
		sku3.setVendorName("V003 Name");
		sku3.setApplyQty(3);
		sku3.setRegularPrice(33d);
		sku3.setPrice(600d);
		sku3.setBuyCost(300d);
		sku3.setCost(300d);
		sku3.setCustQty(3);
		sku3.setMinOrderQty(3d);
		sku3.setStdPack(3d);
		sku3.setInnerPack(null);
		sku3.setArsFlag(1);
		sku3.setHoldOrder(0);
		sku3.setAoh(30);
		sku3.setRemark("sku3 remark");
		TestUtil.prepareDateInfoForCurrentUser(sku3, 3, "H001", "H001 Name");
		trfSrc2.addTrfSku(sku3);
		
		//TrfSku 4
		TrfSku sku4 = new TrfSku();
		sku4.setTrfOid(trf);
		sku4.setTrfSrcOid(trfSrc1);
		sku4.setSeqNo(4);
		sku4.setSku("115838");
		sku4.setSkuName("115838 name");
		sku4.setUpc("115838000");
		sku4.setVendorId("V004");
		sku4.setVendorName("V004 Name");
		sku4.setApplyQty(4);
		sku4.setRegularPrice(44d);
		sku4.setPrice(800d);
		sku4.setBuyCost(400d);
		sku4.setCost(400d);
		sku4.setCustQty(4);
		sku4.setMinOrderQty(4d);
		sku4.setStdPack(4d);
		sku4.setInnerPack(null);
		sku4.setArsFlag(1);
		sku4.setHoldOrder(0);
		sku4.setAoh(40);
		sku4.setRemark("sku4 remark");
		TestUtil.prepareDateInfoForCurrentUser(sku4, 3, "H001", "H001 Name");
		trfSrc2.addTrfSku(sku4);
		
		stoService.createTrf(trf, true, formId);
		
	}
	
	public void testLoad() {
		Trf trf = stoService.load(OID);
		super.assertNotNull(trf);
		System.out.println(ToStringBuilder.reflectionToString(trf));
	}
	
	/**
	 * 
	 * @param formId 功能代碼
	 */
	public void testDeleteTrf(String formId){
		Trf trf = stoService.load(OID);
		super.assertNotNull(trf);
		
		this.stoService.deleteTrf(trf, true, formId);
		
		trf = stoService.load(OID);
		super.assertNull(trf);
		
	}
	
}
