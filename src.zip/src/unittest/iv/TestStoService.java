/**
 * @(#)TestStoService.java.java Aug 5, 2015
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest.iv;

import org.springframework.orm.hibernate3.HibernateTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import com.bnq.util.AppContext;
import com.rfep.bs.dao.hibernate.BsParaDao;
import com.rfep.iv.dao.InventoryDao;
import com.rfep.iv.dao.IvPoRemarkDao;
import com.rfep.iv.dao.SkuLimitDao;
import com.rfep.iv.po.dao.hibernate.PoDao;
import com.rfep.iv.po.dao.hibernate.PoSkuDao;
import com.rfep.iv.rtv.dao.RtvDao;
import com.rfep.iv.service.InventoryService;
import com.rfep.iv.service.IvGoodsMvService;
import com.rfep.iv.sto.dao.hibernate.StoDao;
import com.rfep.iv.sto.service.StoService;
import com.trg.oms.externalWS.som.CallSomWebService;

import junit.framework.TestCase;

/**
 * @author T2482
 *
 */
public class TestStoService extends TestCase {
	private StoService stoService = new StoService();

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		stoService.setCallSomWebService((CallSomWebService)AppContext.getBean("callSomWebService"));
		stoService.setInventoryService((InventoryService)AppContext.getBean("inventoryService"));
		stoService.setBsParaDao((BsParaDao)AppContext.getBean("bsParaDao"));
		stoService.setInventoryDao((InventoryDao)AppContext.getBean("inventoryDao"));
		stoService.setPoDao((PoDao)AppContext.getBean("poDao"));
		stoService.setPoSkuDao((PoSkuDao)AppContext.getBean("poSkuDao"));
		stoService.setStoDao((StoDao)AppContext.getBean("stoDao"));
		stoService.setRtvDao((RtvDao)AppContext.getBean("rtvDao"));
		stoService.setSkuLimitDao((SkuLimitDao)AppContext.getBean("skuLimitDao"));
		stoService.setIvPoRemarkDao((IvPoRemarkDao)AppContext.getBean("ivPoRemarkDao"));
		stoService.setIvGoodsMvService((IvGoodsMvService)AppContext.getBean("ivGoodsMvService"));
		HibernateTransactionManager txnManager = (HibernateTransactionManager)AppContext.getBean("dataSourceTxManager");
		TransactionTemplate txnTemplate = new TransactionTemplate();
		txnTemplate.setTransactionManager(txnManager);
		stoService.setTransactionTemplate(txnTemplate);
	}

	public void testInTrf() {
		stoService.inTrf("X201203091", "01500");
	}
}
