/**
 * 
 */
package unittest;

import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.bnq.util.DateTimeUtils;
import com.bnq.util.sale.dao.hibernate.SaleDataDao;
import com.bnq.util.sale.model.SaleDisc;
import com.bnq.util.sale.service.SaleService;

/**
 * <b></b>
 * @author kaychen
 * @Date: 2009/4/9 �U�� 7:01:03
 * @Project Name: BNQRFEP
 * @Package Name: unittest
 * @File Name: TestSaleService.java
 */
public class TestSaleService extends TestCase {
	public void testSaleDisc() {
		SaleDataDao dao = (SaleDataDao)AppContext.getBean("SaleDataDao");
		List list = dao.findSaleDiscListByMasterPk("00700", DateTimeUtils.getDate("2010/3/1"), "108", "0099", "N");
		for(Iterator iterator = list.iterator(); iterator.hasNext(); ) {
			SaleDisc disc = (SaleDisc)iterator.next();
			System.err.println(disc.getDiscNos1());
			System.err.println(disc.getDiscNos2());
		}
	}
	/**
	 * Test method for {@link com.bnq.sale.service.SaleService#getSaleMasterBO2ListByGuiNo(java.lang.String)}.
	 * @throws InterruptedException 
	 */
	public void testGetSaleMasterBO2ListByGuiNo() throws InterruptedException {
		SaleService service = (SaleService)AppContext.getBean("saleService") ;
		String guiNo[] = new String[]{"EW61918890","EW61956333","EW61897663","DW62131955","EW52918657","EW52918736","EW53009642","EW53031008"} ;
		for(int j = 0; j<5; j++) {
			for (int i = 0; i < guiNo.length; i++) {
				long l1 = System.currentTimeMillis() ;
				service.getSaleMasterBO2ListByGuiNo(guiNo[i]) ;
				long l2 = System.currentTimeMillis() ;
				System.out.println(guiNo[i]+" : "+(l2 - l1)) ;
				//Thread.sleep(1000) ;
			}
		}
	}

}
