package unittest;

import java.util.List;

import org.hibernate.SessionFactory;

import com.bnq.util.AppContext;
import com.rfep.util.sys.dao.SysEmailInfoDao;
import com.rfep.util.sys.vo.EmailNotifyVo;

import junit.framework.TestCase;

public class TestSysEmailInfoDao extends TestCase {
	private SysEmailInfoDao dao;
	
	protected void setUp() throws Exception {
		super.setUp();
		dao = new SysEmailInfoDao();
		dao.setSessionFactory((SessionFactory)AppContext.getBean("sessionFactory"));
	}

	public void testUpdateLastNotifyTime1() {
		try {
			dao.updateLastNotifyTime("OMSDSSAP07");
		} catch(Exception e) {
			assertTrue(false);
		}
	}
	
	public void testUpdateLastNotifyTime2() {
		try {
			dao.updateLastNotifyTime("OMSDSSAP07", "CB_SAP_ERR_NOTIFY");
		} catch(Exception e) {
			assertTrue(false);
		}
	}
	
	public void testGetEmailInfoByEmailGroupId() {
		List<String> result = dao.getEmailInfoByEmailGroupId("CB_SAP_ERR_NOTIFY", "1010");
		for(String email : result) {
			assertEquals("pogi.lin@testritegroup.com", email);
		}
	}
	
	public void testQueryBatchJobNotifyEmailList1() {
		List<EmailNotifyVo> result = dao.queryBatchJobNotifyEmailList("OMSDSSAP07", null);
		for(EmailNotifyVo vo : result) {
			assertEquals("OMSDSSAP07", vo.getJobId());
			assertEquals("T2482", vo.getUserId());
		}
	}
	
	public void testQueryBatchJobNotifyEmailList2() {
		try {
			List<EmailNotifyVo> result = dao.queryBatchJobNotifyEmailList("OMSDSSAP07", "CB_SAP_ERR_NOTIFY", "1010");
			assertEquals(2, result.size());
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void testQuerySysJob() {
		EmailNotifyVo vo = dao.querySysJob("OMSDSSAP07");
		assertEquals("OMSDSSAP07", vo.getJobId());
		assertEquals("T2482", vo.getUserId());
	}
}
