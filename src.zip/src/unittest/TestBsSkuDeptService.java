/**
 * 
 */
package unittest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.util.CollectionUtils;

import com.bnq.util.AppContext;
import com.bnq.util.PageBean;
import com.gccs.bs.dao.hibernate.BsClassDao;
import com.gccs.bs.model.BsClass;
import com.gccs.bs.model.condition.BsSkuCondition;
import com.gccs.bs.service.BsClassService;
import com.rfep.product.bs.service.BsSkuDeptService;
import com.rfep.product.bs.vo.BsSkuDeptVO;

/**
 * <b></b>
 * @author peipei
 * @Date: 2009/4/9 下午 7:01:03
 */
public class TestBsSkuDeptService extends TestCase {
	BsClassService service = null;
	BsSkuDeptService bsSkuDeptService = null;
	BsClassDao dao = null;
	
	@Override
	protected void setUp() throws Exception {
		//service = (BsClassService)AppContext.getBean("bsBizDeptService");
		bsSkuDeptService = (BsSkuDeptService)AppContext.getBean("bsSkuDeptService");
		dao = (BsClassDao)AppContext.getBean("bsClassDao");
		super.setUp();
	}
	
	public void testGetAllBsClassForSubDeptNotUsedInSkuDept() throws Exception {
		
	}
	
	//query2
	public void testGetAllBsClass() throws Exception {
		BsSkuCondition bsSkuCondition = new BsSkuCondition();
		String[] keys = new String[]{"002","058"};
		if(keys!=null){
			if(keys.length>0 && StringUtils.isNotBlank(keys[0])){
				bsSkuCondition.setDept(keys[0]);
			}
			if(keys.length>1 && StringUtils.isNotBlank(keys[1])){
				bsSkuCondition.setSubDept(keys[1]);
			}
			bsSkuCondition.setClazz("null");
			bsSkuCondition.setSubClass("null");
		}
		System.out.println("bsSkuCondition="+ToStringBuilder.reflectionToString(bsSkuCondition));
		List<BsClass> bsClassList = this.service.getAllBsClass(bsSkuCondition);
		System.out.println(bsClassList.size());
		bsSkuCondition.setSubDept("null");
		List<BsClass> bsClassList2 = this.service.getAllBsClass(bsSkuCondition);
		System.out.println(bsClassList2.size());
	}
	
	//query
	public void testFindAllBsSkuDeptVOByCannelIdAndStoreId(){
		Map queryCondition = new HashMap();
		queryCondition.put("channelId", new String[]{"H-OLT"});
		queryCondition.put("storeId", new String[]{"00601"});
		PageBean bean = this.bsSkuDeptService.findAllBsSkuDeptVOByCannelIdAndStoreId(queryCondition, new PageBean());
		if(!CollectionUtils.isEmpty(bean.getQueryList())){
			for(Object o : bean.getQueryList()){
				BsSkuDeptVO vo = (BsSkuDeptVO)o;
				
				System.out.println("deptOid="+ToStringBuilder.reflectionToString(vo.getDeptOid()));
				System.out.println("areaOid="+ToStringBuilder.reflectionToString(vo.getAreaOid()));
				
				System.out.println("vo.getDept()="+vo.getDept());
				System.out.println("vo.getSubdept()="+vo.getSubdept());
				System.out.println("vo.getClazz()="+vo.getClazz());
				System.out.println("vo.getSubclass()="+vo.getSubclass());
				System.out.println("name2="+vo.getName2()); //name2
			}
		}
	}
}
