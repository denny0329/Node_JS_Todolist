package unittest;

import junit.framework.TestCase;

import org.apache.commons.collections.keyvalue.MultiKey;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.bnq.util.AppContext;
import com.gccs.marketing.model.vo.DiscountChannelVo;
import com.gccs.marketing.model.vo.DiscountVo;
import com.gccs.marketing.service.MarketingService;
import com.rfep.dataex.fi.voucher.AbstractVoucherProcess;
import com.rfep.dataex.fi.voucher.impl.ar.DailyArProcess;
import com.rfep.dataex.sd.outbound.OMSSTOSALE;
import com.rfep.nr.service.NrService;
import com.rfep.trans.util.TransBsPayCodeDefinition;

public class TestPayCode extends TestCase {
	protected static final Logger log = LogManager.getLogger(TestPayCode.class);
	
	public void testSAP() {
		OMSSTOSALE p = new OMSSTOSALE();
		p.execute();
	}
	
	public void testNr() {
//		AbstractVoucherProcess p = new GiftCouponProcess();
//		AbstractVoucherProcess p = new AdvanceSkuProcess();
		AbstractVoucherProcess p = new DailyArProcess();
		p.execute();
	}
	
	public void testNiRun() throws Exception {
		NrService s = (NrService)AppContext.getBean("nrService");
		s.nrTransferEr();
		
	}
	
	public void testUpdate() throws Exception {
		NrService s = (NrService)AppContext.getBean("nrService");
		//s.updateNrDataCtrl(new Date(), "00700", 8);
	}
	
	public void testMap() {
		org.apache.commons.collections.map.MultiKeyMap paymentTotalMultiKeyMap = new org.apache.commons.collections.map.MultiKeyMap();
		paymentTotalMultiKeyMap.put("1",null,"XXX", "asdf");
		for(Object key : paymentTotalMultiKeyMap.keySet()) {
			MultiKey k = (MultiKey)key;
			System.err.println(k.getKeys().length);
			for(int i=0; i<k.getKeys().length; i++) {
				System.err.println(k.getKey(i));
			}
		}
	}
	
	
	public void testDesc() {
//		System.err.println(TransBsPayCodeDefinition.getTransBsPayCodeWebDesc("TLW", "12"));
		System.err.println(TransBsPayCodeDefinition.getTransBsPayCodeByChannelIdAndCode("TLW", "31").getPayGroup());
	}
	
	public void testMemberDisc() throws Exception {
		MarketingService mService = (MarketingService)AppContext.getBean("mtService");
		String discOid = "DISC_01_10**********************";
		DiscountVo discVO = mService.getDiscountVoByOid(discOid, true, true);
		boolean isExpSkuType =  Boolean.valueOf(discVO.getExpSkuType());
		System.err.println(isExpSkuType);
		for(DiscountChannelVo channel : discVO.getDiscountChannel()) {
			if(channel.getChannelId().equals("TLW")) {
				System.err.println(channel.getRate());
			}
			
		}
	}
	
	public void testEan15() {
		String sku = "203456";
		String zero = "00000000";
		String no = sku + zero;
		System.err.println("length : "+no.length());
		int odd = 0;	//奇數
		int even = 0;	//偶數
		for(int i=0; i<no.length(); i++) {
			String str = no.substring(i, i+1);
			int num = Integer.parseInt(str);
			if((i+1)%2==0) {
				even += num;
			} else {
				odd += num;
			}
		}
		System.err.println("奇數和 : "+odd);
		System.err.println("偶數和 : "+even);
		odd *= 3;
		System.err.println("奇數*3 : "+odd);
		System.err.println("偶數*1 : "+even);
		odd %= 10;
		even %= 10;
		System.err.println("奇數%10 : "+odd);
		System.err.println("偶數%10 : "+even);
		odd += even;
		System.err.println("奇數+偶數 : "+odd);
		odd %= 10;
		System.err.println("奇數%10 : "+odd);
		odd = (10 - odd)%10;
		System.err.println("(10-奇數)%10 : "+odd);
	}
}
