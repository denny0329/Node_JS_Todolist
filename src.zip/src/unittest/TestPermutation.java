package unittest;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import junit.framework.TestCase;

import com.bnq.util.DateTimeUtils;
import com.gccs.ev.model.Activity;
import com.rfep.trans.model.trans.vo.CalculateBean;
import com.rfep.valuation.util.permutation.PermutationImp;

public class TestPermutation extends TestCase {
	public void testDisc() {
		CalculateBean bean1 = new CalculateBean();
		bean1.setQty(3);
		bean1.setSaleTotal(100);
		
		CalculateBean bean2 = new CalculateBean();
		bean2.setQty(5);
		bean2.setSaleTotal(150);
		
		CalculateBean bean3 = new CalculateBean();
		bean3.setQty(2);
		bean3.setSaleTotal(300);
		
		List<CalculateBean> list = new ArrayList<CalculateBean>();
		list.add(bean1);
		list.add(bean2);
		list.add(bean3);
		
		Integer disc = 50;
		
//		TransUtil.calculatePrice(list, disc);
		
		for(CalculateBean bean : list) {
			System.err.println("------------");
			System.err.println(bean.getDiscount());
			System.err.println(">>>>>>>>>>>>>>");
			for(Integer sdisc : bean.getSingleDiscount()) {
				System.err.println(sdisc);
			}
		}
	}
	
	
	private static Date parseDate(String date) {
		SimpleDateFormat gSimpleDateFormat = new SimpleDateFormat("yyyyMMdd") ;
		try {
			return gSimpleDateFormat.parse(date) ;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return new Date() ;
	}
	
	public void testDate() throws Exception {
		String dateStr = "20100812";
		Date date = DateTimeUtils.getDateFormat(dateStr, "yyyyMMdd");
		
		System.err.println(date);
	}
	
	
	
	public void testMod() {
		int qty = 8;
		int condition = 3;
		new BigDecimal(String.valueOf(qty)).divide(new BigDecimal(String.valueOf(condition)), 2, BigDecimal.ROUND_HALF_UP);
		System.err.println(new BigDecimal(String.valueOf(qty)).divide(new BigDecimal(String.valueOf(condition)), 2, BigDecimal.ROUND_HALF_UP));
		System.err.println(new BigDecimal(String.valueOf(qty)).divide(new BigDecimal(String.valueOf(condition)), 0, BigDecimal.ROUND_DOWN));
	}
	
	public List perm(Activity[] acts, int i) {
		List resultList = new ArrayList();
		if(i < acts.length - 1) { 
			for(int j = i; j <= acts.length - 1; j++) { 
				Activity tmp = acts[j]; 
				//旋轉該區段最右邊數字至最左邊 
				for(int k = j; k > i; k--) 
					acts[k] = acts[k-1]; 
				acts[i] = tmp; 
				
				List retList = perm(acts, i+1);
				if(!retList.isEmpty()) {
					resultList.add(retList);
				}

				//還原 
				for(int k = i; k < j; k++) 
					acts[k] = acts[k+1]; 
				acts[j] = tmp; 
			}
		} else {  // 顯示此次排列
			List retList = new ArrayList();
			for(int j = 1; j <= acts.length - 1; j++) {
//				System.err.print(acts[j].getActivityId());
				retList.add(acts[j]);
			}
//			System.err.println();
			return retList;
		} 
		return resultList;
	}

	public void testMain() {
		Activity[] acts = new Activity[5+1]; 
    	Activity act1 = new Activity();
    	act1.setActivityId("001");
    	Activity act2 = new Activity();
    	act2.setActivityId("002");
    	Activity act3 = new Activity();
    	act3.setActivityId("003");
    	Activity act4 = new Activity();
    	act4.setActivityId("004");
    	Activity act5 = new Activity();
    	act5.setActivityId("005");
    	List list = new ArrayList();
    	list.add(act1);
//    	list.add(act2);
//    	list.add(act3);
//    	list.add(act4);
    	PermutationImp.permutationImp(list);
//    	acts[1] = act1;
//    	acts[2] = act2;
//    	acts[3] = act3;
//    	acts[4] = act4;
//    	acts[5] = act5;
		 

//		List list = perm(acts, 1); 
//		
//		List result = new ArrayList();
//		result = loop(list, result);
//		for(Iterator iter = result.iterator(); iter.hasNext(); ) {
//			List list1 = (List)iter.next();
//			for(Iterator subIter = list1.iterator(); subIter.hasNext(); ) {
//				Activity act = (Activity)subIter.next();
//				System.err.print(act.getActivityId()+" ");
//			}
//			System.err.println("");
//		}
	}
	
	private List loop(List list, List result) {
		List retList = new ArrayList();
		for(Iterator iter = list.iterator(); iter.hasNext(); ) {
			Object obj = iter.next();
			if(obj instanceof List) {
				loop((List)obj, result);
			} else if(obj instanceof Activity) {
				retList.add((Activity)obj);
			}
		}
		if(!retList.isEmpty())
			result.add(retList);
		return result;
	}
	
	public void testLoop() {
		Integer qty = 2;
		String sku1 = "AAA";
		String sku2 = "BBB";
		List<String> skuList = new ArrayList<String>();
		skuList.add(sku1);
		skuList.add(sku2);
		List<Map<String, Integer>> list = new ArrayList<Map<String, Integer>>();
		
//		Map<String, Integer> map = new HashMap<String, Integer>();
//		int count = 0;
//		for(int j=0;j<skuList.size();j++){
//			
//			String sku = skuList.get(j);
//			
//			map.put(sku, new Integer(qty));
//		}
//		list.add(map);
		
		for(int i=qty; i>0; i--) {
			int count = 0;
			Map<String, Integer> map = new HashMap<String, Integer>();
			for(String sku : skuList) {
				
				
				map.put(sku, new Integer(i));
				count += i;
				list.add(map);
			}
			
		}
//		for(String sku : skuList) {
//			Map<String, Integer> map = new HashMap<String, Integer>();
//			System.err.println(">>>");
//			map.put(sku, new Integer(qty));
//			list.add(map);
//		}
		
		for(Map<String, Integer> map : list) {
			Set<String> keySet = map.keySet();
			System.err.println("--------------");
			for(String key : keySet) {
				System.err.println("sku "+key+" : count qty is "+map.get(key));
			}
		}
	}
}

