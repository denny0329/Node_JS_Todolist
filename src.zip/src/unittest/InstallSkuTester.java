package unittest;

import java.util.Date;
import java.util.List;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.product.bs.vo.BsSkuNewVO;
import com.rfep.so.bs.dao.hibernate.SoDeliverySkuDAO;
import com.rfep.util.SpringNamingRule;

public class InstallSkuTester extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}
	
	public boolean test(){		
		try{			
			SoDeliverySkuDAO dao = (SoDeliverySkuDAO)AppContext.getBean(SpringNamingRule.getBeanId(SoDeliverySkuDAO.class));
			System.out.println(new Date());
			List<BsSkuNewVO> list = dao.findInstallSkuAndPrice("TLW", "147675", "01900");
			for (BsSkuNewVO vo : list){
				System.out.println(vo.getSkuName());
				System.out.println(vo.getUpc());
				System.out.println(vo.getInstallPrice());
				
			}
			System.out.println(new Date());
			return true;
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
	}
	
	public void testInstallSkuFinder(){
		assertEquals(true, test());
	}

}
