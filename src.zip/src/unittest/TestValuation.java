package unittest;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.bnq.util.DateTimeUtils;
import com.gccs.ev.util.ActivityGlossary;
import com.rfep.trans.model.trans.vo.CalculateBean;
import com.rfep.trans.util.MathBean;
import com.rfep.valuation.model.vo.BaseInfoVO;
import com.rfep.valuation.model.vo.PromotionVO;
import com.rfep.valuation.model.vo.SkuVO;
import com.rfep.valuation.model.vo.TransVO;
import com.rfep.valuation.service.ValuateService;

public class TestValuation extends TestCase {
	public void testBean() {
		CalculateBean saleBean = this.createBean(12, 8.33, 100, 20, 30, 0);
		CalculateBean ontimeBean1 = this.createBean(2, 8.33, 17, 3, 5, 0);
		List<CalculateBean> list = new ArrayList<CalculateBean>();
		list.add(ontimeBean1);
		CalculateBean ontimeBean2 = this.createBean(3, 8.33, 25, 5, 8, 0);
		list.add(ontimeBean2);
		CalculateBean ontimeBean3 = this.createBean(7, 0, 0, 0, 0, 0);
		MathBean math = new MathBean(saleBean, ontimeBean3, list);
		
		CalculateBean bean = math.getResult();
		System.err.println(">>>>>>>>>>> amt price : "+bean.getAmtPrice());
		System.err.println(">>>>>>>>>>> sale total : "+bean.getSaleTotal());
		System.err.println(">>>>>>>>>>> member : "+bean.getMemberDiscount());
		System.err.println(">>>>>>>>>>> coupon : "+bean.getCouponDiscount());
		System.err.println(">>>>>>>>>>> so : "+bean.getSoDiscount());
	}
	
	public CalculateBean createBean(int qty, double amtPrice, int saleTotal,
			int member, int coupon, int so) {
		CalculateBean saleBean = new CalculateBean();
		saleBean.setQty(qty);
		saleBean.setAmtPrice(amtPrice);
		saleBean.setSaleTotal(saleTotal);
		saleBean.setMemberDiscount(member);
		saleBean.setCouponDiscount(coupon);
		saleBean.setSoDiscount(so);
		return saleBean;
	}
	
	public void testDivide() {
		Integer i = 5;
		Integer j = 6;
		BigDecimal result = new BigDecimal(String.valueOf(i)).divide(new BigDecimal(String.valueOf(j)), 0, BigDecimal.ROUND_DOWN);
		System.err.println(result);
	}
	
	private SkuVO createSku(String upc, String skuNos, Integer qty, Integer fixedPrice, Integer posPrice, Boolean storeDiscount,
			Boolean stampDiscount, String deptId, String subdeptId, String classId, String subclassId, String skuName, String eventNo) {
		SkuVO sku = new SkuVO();
		sku.setEventNo(eventNo);
		sku.setSkuName(skuName);
//		sku.setChannelId("TLW");
		sku.setUpc(upc);
		sku.setSkuNos(skuNos);
		sku.setDeptId(deptId);
		sku.setSubdeptId(subdeptId);
		sku.setClassId(classId);
		sku.setSubclassId(subclassId);
		sku.setStorePriceDown(storeDiscount);
		sku.setUsedStamp(stampDiscount);
		sku.setFixedPrice(fixedPrice);
		sku.setBaseFixedPrice(fixedPrice);
		sku.setPosPrice(posPrice);
		sku.setBasePosPrice(posPrice);
		sku.setAmtPrice(new BigDecimal(String.valueOf(sku.getPosPrice())).doubleValue());
		sku.setBaseAmtPrice(new BigDecimal(String.valueOf(sku.getPosPrice())).doubleValue());
		sku.setQty(qty);
		sku.setBaseQty(qty);
		sku.setRemainQty(qty);
		BigDecimal amtPrice = new BigDecimal(String.valueOf(sku.getAmtPrice()));
		BigDecimal qt = new BigDecimal(String.valueOf(sku.getQty()));
		
		sku.setSaleTotal(amtPrice.multiply(qt).setScale(0, BigDecimal.ROUND_HALF_UP).intValue());
		return sku;
	}
	
	private List createSkuList() {
		List<SkuVO> skuList = new ArrayList<SkuVO>();
//		SkuVO vo1 = this.createSku("1234567", "112233", 3, 125, 125, false);
//		SkuVO vo2 = this.createSku("2345678", "107884", 2, 600, 600, false);
//		SkuVO vo3 = this.createSku("3456789", "113322", 7, 500, 480, false);
//		SkuVO vo4 = this.createSku("1234567", "112233", 4, 125, 125, true);
//		SkuVO vo5 = this.createSku("2345678", "103320", 6, 100, 100, false);
//		SkuVO vo6 = this.createSku("AAAAAA", "AAAAAA", 4, 100, 100, false);
//		skuList.add(vo1);
//		skuList.add(vo2);
//		skuList.add(vo3);
//		skuList.add(vo4);
//		skuList.add(vo5);
//		skuList.add(vo6);
		
		
//		SkuVO vo11 = this.createSku("aaaaaaaa", "156731", 1, 30, 30, false, false, "001", "002", "003", "004", "�[��3�T�p�~�֮�-�����M", "3393099375");
//		skuList.add(vo11);
//		SkuVO vo3 = this.createSku("cccccccc", "281086", 1, 299, 299, false, false, "005", "006", "007", "008", "a", "3599210718");
//		skuList.add(vo3);
//		SkuVO vo4 = this.createSku("dddddddd", "281778", 1, 339, 339, false, false, "055", "066", "077", "088", "b", "3599210718");
//		skuList.add(vo4);
//		SkuVO vo5 = this.createSku("111111", "102376", 1, 3100, 3100, false, false, "001", "002", "003", "004", "���ŭ��3�إ|���\��", "4606526000");
//		skuList.add(vo5);
		SkuVO vo1 = this.createSku("aaaaaaaa", "279213", 1, 129, 129, false, false, "011", "022", "033", "044", "�����p�d�Ω٥�����2�J", "5412150796");
		skuList.add(vo1);
		SkuVO vo2 = this.createSku("bbb", "314279", 1, 609, 609, false, false, "011", "022", "033", "044", "���ÿ��O�A���ȱ��[�����ƶK", "");
		skuList.add(vo2);
		SkuVO vo3 = this.createSku("ccccc", "314279", 1, 559, 559, false, false, "011", "022", "033", "044", "���ÿ��h�γ~�m���[���x������", "");
		skuList.add(vo3);
		
		
		
//		SkuVO vo6 = this.createSku("22222222", "103493", 1, 250, 300, false, "011", "022", "033", "044");
//		skuList.add(vo6);
		
		
		return skuList;
	}
	
	public void testValuation() {
		ValuateService service = (ValuateService)AppContext.getBean("valuateService");
		List<SkuVO> skuList = this.createSkuList();
		
		int i=1;	//���սs��
		for(SkuVO vo : skuList) {
			vo.setItemSer(i);
			i++;
		}
		
		BaseInfoVO baseInfo = new BaseInfoVO("TLW", "01900", DateTimeUtils.getDate("2010/9/20"), "11:10", null, null);
		
		TransVO transVO = new TransVO(baseInfo, skuList, Boolean.TRUE);
		transVO.saleTotalCalculate();
		
//		System.err.println("==================== valuate before ====================");
//		for(SkuVO sku : transVO.getSkuList()) {
//			System.err.println("-------------------");
//			System.err.println("sku : "+sku.getSkuNos()+", qty : "+sku.getQty());
//			System.err.println("sku : "+sku.getSkuNos()+", fixed price : "+sku.getFixedPrice());
//			System.err.println("sku : "+sku.getSkuNos()+", pos price : "+sku.getPosPrice());
//			System.err.println("sku : "+sku.getSkuNos()+", amt price : "+sku.getAmtPrice());
//			System.err.println("sku : "+sku.getSkuNos()+", total : "+sku.getSaleTotal());
//		}
		
		if(!transVO.getIsSo()) {
			service.recombinationSku(transVO);
		}
		
		System.err.println("==================== recombination after ====================");
		System.err.println("gui total : "+transVO.getBaseInfo().getSaleTotal());
		for(SkuVO sku : transVO.getSkuList()) {
			System.err.println("-------------------");
			System.err.println("�~�W : "+sku.getSkuName()+" ���X : "+sku.getUpc());
			System.err.println("�ӫ~�s�� : "+sku.getSkuNos()+", item ser : "+sku.getItemSer()+" �ƶq : "+sku.getQty());
			System.err.println("�@���� : "+sku.getFixedPrice()+" POS��� : "+sku.getPosPrice()+" ��ڰ�� : "+sku.getAmtPrice());
			System.err.println("�O�_�ϥΦL�� : "+sku.isUsedStamp());
			System.err.println("�O�_�����ܻ� : "+sku.isStorePriceDown());
			System.err.println("�O�_���P�P�ӫ~ : "+(!sku.getActivityIdMap().isEmpty()));
			System.err.println("�p�p : "+sku.getSaleTotal());
		}
		
		service.valuator(transVO);
		
		System.err.println("==================== valuate after ====================");
		System.err.println("gui total : "+transVO.getBaseInfo().getSaleTotal());
		for(SkuVO sku : transVO.getSkuList()) {
			System.err.println("-------------------");
			System.err.println("�~�W : "+sku.getSkuName()+" ���X : "+sku.getUpc());
			System.err.println("�ӫ~�s�� : "+sku.getSkuNos()+", item ser : "+sku.getItemSer()+" �ƶq : "+sku.getQty());
			System.err.println("�@���� : "+sku.getFixedPrice()+" POS��� : "+sku.getPosPrice()+" ��ڰ�� : "+sku.getAmtPrice());
			System.err.println("�O�_�ϥΦL�� : "+sku.isUsedStamp());
			System.err.println("�O�_�����ܻ� : "+sku.isStorePriceDown());
			System.err.println("�O�_���P�P�ӫ~ : "+(!sku.getActivityIdMap().isEmpty()));
			System.err.println("�O�_������ӫ~ : "+(!sku.getConditionIdMap().isEmpty()));
			System.err.println("�p�p : "+sku.getSaleTotal()+" �馩 : "+sku.getDiscount());
			System.err.println(">>>>>>>>>>>>>>>�P�P<<<<<<<<<<<<<<<");
			for(PromotionVO promotion : sku.getPromotion()) {
				System.err.println(" �P�P : "+promotion.getPromotionId() +" "+promotion.getPromotionName());
				System.err.println(" �P�P�ƶq : "+promotion.getPromotionQty()+" �`�馩 : "+promotion.getTotalDiscount());
				System.err.println(" �u���覡 : "+ActivityGlossary.getProfitTypeDesc(promotion.getProfitType()));
			}
			System.err.println("");
		}
	}
}

