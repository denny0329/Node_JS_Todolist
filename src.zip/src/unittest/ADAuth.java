package unittest ;

import java.util.Hashtable ; 
import javax.naming.*;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;
import org.apache.commons.lang.StringUtils;

/**
 * [功能]
 *      1. 輸入帳號跟密碼，跟 AD 做認證。
 *      
 * [範例]
 *      1. ADAuth.checkAuth("帳號", "密碼") --> 回傳值:（成功:true / 失敗:false）
 * 
 * [對象]
 *      1. For B&Q User。
 *      
 * @author h00607
 */
public class ADAuth
{
	/**
	 * 認證
	 * @param username
	 * @param password
	 * @return
	 */
	public static boolean checkAuth(String username ,String password)
	{
		System.out.println(StringUtils.center(" checkAuth() START ", 50, "*"));
		
		if(StringUtils.isEmpty(username))
		{
			System.out.println("username Is Null / Empty String");
			return false;
		}
		
		if(StringUtils.isEmpty(password))
		{
			System.out.println("password Is Null / Empty String");
			return false;
		}
		
		username = StringUtils.trim(username);
		password = StringUtils.trim(password);
		
		boolean flag = false;
		
		try
		{
			if(initUserToADAuth(username ,password))
			{
				flag = true;
			}
		}
		catch (Exception e)
		{
			System.out.println("工號（"+username+"）AD認證失敗！！" + e);
		}
		
		System.out.println(StringUtils.center(" checkAuth() END ", 50, "*"));
		return flag;
	}
	
	private static boolean initUserToADAuth(String username ,String password) throws NamingException
	{
		System.out.println(StringUtils.center(" initUserToADAuth() START ", 50, "*"));
		
		boolean flag = true;
		
		Hashtable<String, String> env = new Hashtable<String, String>();
		LdapContext ctx = null;
		
		try
		{
			env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");    
			env.put(Context.PROVIDER_URL,            "ldap://BQAD2:389");                   // 這裡使用DNS，萬一AD IP變更，則程式碼設定不需異動。
			env.put(Context.SECURITY_AUTHENTICATION, "simple"); 
			env.put(Context.SECURITY_PRINCIPAL,      "B&Q\\" + username);
			env.put(Context.SECURITY_CREDENTIALS ,   password);
	
			ctx = new InitialLdapContext(env, null);
		}
		catch(NamingException e)
		{
			flag = false;
			throw new NamingException(e.getMessage());
		}
		finally
		{
			if(ctx != null)
			{
				try
				{
					ctx.close();
				}
				catch(NamingException e)
				{
					flag = false;
					throw new NamingException(e.getMessage());
				}
			}
		}
		
		System.out.println(StringUtils.center(" initUserToADAuth() END ", 50, "*"));
		return flag;
	}
	
}



