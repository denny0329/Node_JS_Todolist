package unittest;

import java.io.File;

import junit.framework.TestCase;

import com.rfep.dataex.iv.inbound.OMSVENDRAP;

public class TestOMSVENDRAP extends TestCase {
	private OMSVENDRAP omsTest;
	protected void setUp() throws Exception {
		super.setUp();
		omsTest = new OMSVENDRAP();
	}
	
	public void testFile() {
		try {
			File file = new File("C:\\OMS_TEST\\OMSVENDRAP\\OMSVENDRAP_20150716061057800_66318.csv");
			omsTest.execute(file);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
