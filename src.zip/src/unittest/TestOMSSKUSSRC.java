package unittest;

import java.io.File;

import junit.framework.TestCase;

import com.rfep.dataex.mm.inbound.OMSSKUSSRC;

public class TestOMSSKUSSRC extends TestCase {
	
	private OMSSKUSSRC omsTest;
	protected void setUp() throws Exception {
		super.setUp();
		omsTest = new OMSSKUSSRC();
	}
	
	public void testFile() {
		try {
			File file = new File("C:\\OMS_TEST\\OMSSKUSSRC\\OMSSKUSSRC_2015071500110823_622806.csv");
			omsTest.execute(file);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
