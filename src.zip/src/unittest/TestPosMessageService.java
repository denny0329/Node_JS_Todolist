package unittest;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import junit.framework.TestCase;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.util.CollectionUtils;

import com.bnq.util.AppContext;
import com.bnq.util.QueryResult;
import com.rfep.trans.model.PosMessage;
import com.rfep.trans.model.PosMessageDtl;
import com.rfep.trans.service.PosMessageService;
import com.rfep.trans.vo.PosMessageDtlVO;
import com.rfep.trans.vo.PosMessageVO;

/**
 * @author peipei
 */
public class TestPosMessageService extends TestCase {
	
	public void testGetPosMessageVOsByCondition() throws Exception {
		PosMessageService service = (PosMessageService)AppContext.getBean("posMessageService");
		Map queryCondition = new HashMap();
		queryCondition.put("channelId", new String[]{"H-OLT"});
		//queryCondition.put("storeId", new String[]{"00601"});
//		queryCondition.put("posNos", new String[]{"004"});
//		queryCondition.put("messageDate", new String[]{"2010/07/25"});
		
		QueryResult queryResult = service.findPosMessageVOsByCondition(queryCondition, 0, 20);
		System.out.println("find " + queryResult.getCount() + " rows!");
		if(queryResult.getResult()!=null){
			for(Iterator iterator = queryResult.getResult().iterator(); iterator.hasNext(); ) {
				PosMessageVO vo = (PosMessageVO)iterator.next();
				System.out.println(ToStringBuilder.reflectionToString(vo));
//				if(!CollectionUtils.isEmpty(vo.getPosMessageDtlVOList())){
//					for(PosMessageDtlVO dtlVo : vo.getPosMessageDtlVOList()){
//						System.out.println(ToStringBuilder.reflectionToString(dtlVo));
//					}
//				}
			}
		}else{
			System.out.println("No data found!!");
		}
		
	}
	public void testFindPosMessageById() throws Exception {
		PosMessageService service = (PosMessageService)AppContext.getBean("posMessageService");
		
		PosMessage posMessage = service.findPosMessageById("H-OLT00601d8590e63ea47413aa490d92e8f7ab19f");
		System.out.println(ToStringBuilder.reflectionToString(posMessage));
		if(!CollectionUtils.isEmpty(posMessage.getPosMessageDtls())){
			for(PosMessageDtl dtl : posMessage.getPosMessageDtls()){
				System.out.println(ToStringBuilder.reflectionToString(dtl));
			}
		}
		
	}
	
	public void testFindPosMessageVOById() throws Exception {
		PosMessageService service = (PosMessageService)AppContext.getBean("posMessageService");
		
		PosMessageVO posMessageVO = service.findPosMessageVOById("H-OLT00601d8590e63ea47413aa490d92e8f7ab19f");
		System.out.println(ToStringBuilder.reflectionToString(posMessageVO));
		if(!CollectionUtils.isEmpty(posMessageVO.getPosMessageDtlVOList())){
			for(PosMessageDtlVO dtlVo : posMessageVO.getPosMessageDtlVOList()){
				System.out.println(ToStringBuilder.reflectionToString(dtlVo));
			}
		}
		
	}
}
