package unittest;

import java.io.File;

import junit.framework.TestCase;

import com.rfep.dataex.co.inbound.OMSCOSTCTR;

public class TestOMSCOSTCTR extends TestCase {
	
	private OMSCOSTCTR omsTest;
	protected void setUp() throws Exception {
		super.setUp();
		omsTest = new OMSCOSTCTR();
	}
	
	public void testFile() {
		try {
			File file = new File("C:\\OMS_TEST\\OMSCOSTCTR\\OMSCOSTCTR_2015071522001673_66268.csv");
			omsTest.execute(file);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
