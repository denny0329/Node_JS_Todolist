package unittest.inBound;

import java.io.File;

//import org.hibernate.SessionFactory;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.cb.dao.CbCounterContractDAO;
import com.rfep.cb.dao.CbCreditCardDAO;
import com.rfep.cb.dao.CbDaySettlementDAO;
import com.rfep.cb.dao.CbMonthChargeDAO;
import com.rfep.cb.dao.CbMonthChargeTempDAO;
import com.rfep.cb.dao.CbSalesLogDAO;
import com.rfep.cb.service.CbService;
import com.rfep.dataex.cb.inbound.OMSCBEIP02;
import com.rfep.nm.dao.hibernate.NmInstallmentDAO;

public class TestOMSCBEIP02 extends TestCase {
	private OMSCBEIP02 note;

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		note = new OMSCBEIP02();
	}

	/**
	 * 測試合營的電文檔
	 * @throws Exception
	 */
	public void testOMSDSEIP02ForCB() throws Exception {
	    CbSalesLogDAO cbSalesLogDAO=(CbSalesLogDAO)AppContext.getBean("cbSalesLogDAO");
        CbCounterContractDAO cbCounterContractDAO=(CbCounterContractDAO)AppContext.getBean("cbCounterContractDAO");
        CbCreditCardDAO cbCreditCardDAO=(CbCreditCardDAO)AppContext.getBean("cbCreditCardDAO");
        NmInstallmentDAO nmInstallmentDAO=(NmInstallmentDAO)AppContext.getBean("nmInstallmentDAO");
        CbDaySettlementDAO cbDaySettlementDAO=(CbDaySettlementDAO)AppContext.getBean("cbDaySettlementDAO");
        CbMonthChargeDAO cbMonthChargeDAO=(CbMonthChargeDAO)AppContext.getBean("cbMonthChargeDAO");
        CbMonthChargeTempDAO cbMonthChargeTempDAO=(CbMonthChargeTempDAO)AppContext.getBean("cbMonthChargeTempDAO");

        CbService cbService = (CbService)AppContext.getBean("cbService");
     /*  
        cbSalesLogDAO.setSessionFactory((SessionFactory)AppContext.getBean("sessionFactory"));
        cbCounterContractDAO.setSessionFactory((SessionFactory)AppContext.getBean("sessionFactory"));
        cbCreditCardDAO.setSessionFactory((SessionFactory)AppContext.getBean("sessionFactory"));
        nmInstallmentDAO.setSessionFactory((SessionFactory)AppContext.getBean("sessionFactory"));
        cbDaySettlementDAO.setSessionFactory((SessionFactory)AppContext.getBean("sessionFactory"));
        cbMonthChargeDAO.setSessionFactory((SessionFactory)AppContext.getBean("sessionFactory"));
        cbMonthChargeTempDAO.setSessionFactory((SessionFactory)AppContext.getBean("sessionFactory"));
    */    
		String path = this.getClass().getResource("").getPath() + "file" + File.separator + "TestOMSCBEIP02_CASE03.csv";
		File file = new File(path.substring(1));
		
		note.setCbService(cbService);
		note.setCbCounterContractDAO(cbCounterContractDAO);
		note.setCbCreditCardDAO(cbCreditCardDAO);
		note.setCbDaySettlementDAO(cbDaySettlementDAO);
		note.setCbMonthChargeDAO(cbMonthChargeDAO);
		note.setCbMonthChargeTempDAO(cbMonthChargeTempDAO);
		note.setCbSalesLogDAO(cbSalesLogDAO);
		note.setNmInstallmentDAO(nmInstallmentDAO);
		
		note.execute(file);
	}
	
	/**
	 * 測試專櫃的電文檔
	 * @throws Exception
	 *
	public void testOMSDSEIP02ForDS() throws Exception {
		String path = this.getClass().getResource("").getPath() + "file" + File.separator + "TestOMSCBEIP02_CASE02.csv";
		File file = new File(path.substring(1));
		note.execute(file);
	}
	*/
}
