/**
 * @(#)TestOMSARSWKST.java.java Mar 20, 2015
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest.inBound;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bnq.util.AppContext;
import com.bnq.util.DateUtils;
import com.rfep.dataex.mm.inbound.OMSARSWKST;
import com.rfep.dataex.util.service.MessageCountService;
import com.rfep.iv.ars.dao.hibernate.ArsDao;
import com.rfep.iv.ars.model.ArsWorksheet;
import com.rfep.iv.service.InventoryService;

import junit.framework.TestCase;

/**
 * @author T2482
 */
public class TestOMSARSWKST extends TestCase {
	private MessageCountService messageCountService;
	private OMSARSWKST arsWkst = new OMSARSWKST();

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		arsWkst.setArsDao((ArsDao)AppContext.getBean("arsDao"));
		arsWkst.setInventoryService((InventoryService)AppContext.getBean("inventoryService"));
		messageCountService = (MessageCountService)AppContext.getBean("messageCountService");
	}

	/**
	 * 測試電文 EXCEP 欄位轉化 BS_CODE.code_class= AT 的正確性。
	 * @throws Exception 
	 */
	public void testBsCodeForAT() throws Exception {
		Date arsDate = DateUtils.trunc(DateUtils.addDay(new Date(), -1));
		ArsDao arsDao = (ArsDao)AppContext.getBean("arsDao");
		arsDao.executeSQL("delete iv_ars_worksheet where store_id = ? and ars_date = ? and sku in ('000133824', '000188160', '000188161', '000234999', '000100360', '000100361', '000235002')", new Object[]{"00610", arsDate});
		
		// 電文的第三個欄位日期要改為 sysdate - 1
		String path = this.getClass().getResource("").getPath() + "file" + File.separator + "TestOMSARSWKST_CASE01.csv";
		File file = new File(path.substring(1));
		messageCountStart(file.getName().replace(".csv", ".zip"), new Date(), new Date().getTime(), file.getName(), new Date(), "OMSARSWKST");
		arsWkst.execute(new File(path.substring(1)));
		messageCountEnd(file.getName().replace(".csv", ".zip"), file.getName(), new Date());
		
		Map<String, Object> condition = new HashMap<String, Object>();
		condition.put("storeId", "00610");
		condition.put("arsDate", DateUtils.cdateFormat(arsDate));
		condition.put("skus", new String[]{"000133824","000188160", "000188161", "000234999", "000100360", "000100361", "000235002"});
		List<ArsWorksheet> arsList = arsDao.findAllArsWorksheetByCondition(condition);
		
		for(ArsWorksheet ars : arsList) {
			if("000133824".equals(ars.getSku())) {
				assertEquals("ARS003", ars.getArsNo());
				assertEquals("下兩週即將促銷", ars.getArsType());
				assertEquals(7, ars.getCountdownDays().intValue());
				assertEquals(DateUtils.addDay(arsDate, 7), ars.getPromotionStart());
			} else if("000188160".equals(ars.getSku())) {
				assertEquals("ARS004", ars.getArsNo());
				assertEquals("異常銷售", ars.getArsType());
			} else if("000188161".equals(ars.getSku())) {
				assertEquals("ARS006", ars.getArsNo());
				assertEquals("MD上架", ars.getArsType());
			} else if("000234999".equals(ars.getSku())) {
				assertEquals("ARS007", ars.getArsNo());
				assertEquals("上架清單", ars.getArsType());
			} else if("000100360".equals(ars.getSku())) {
				assertEquals("ARS001", ars.getArsNo());
				assertEquals("一般商品", ars.getArsType());
			} else if("000100361".equals(ars.getSku())) {
				assertEquals("ARS002", ars.getArsNo());
				assertEquals("促銷品", ars.getArsType());
			} else if("000235002".equals(ars.getSku())) {
				// 未定義于 bs_code 的資料 default 帶 ARS001
				assertEquals("ARS001", ars.getArsNo());
				assertEquals("一般商品", ars.getArsType());
			}
		}
	}
	
	/**
	 * 測試電文 DC_AOH 欄位轉化的正確性。
	 * @throws Exception 
	 */
	public void testDcAoh() throws Exception {
		Date arsDate = DateUtils.trunc(DateUtils.addDay(new Date(), -1));
		ArsDao arsDao = (ArsDao)AppContext.getBean("arsDao");
		arsDao.executeSQL("delete iv_ars_worksheet where store_id = ? and ars_date = ? and sku = '014106406'", new Object[]{"00100", arsDate});
		
		// 電文的第三個欄位日期要改為 sysdate - 1
		String path = this.getClass().getResource("").getPath() + "file" + File.separator + "TestOMSARSWKST_CASE02.csv";
		File file = new File(path.substring(1));
		messageCountStart(file.getName().replace(".csv", ".zip"), new Date(), new Date().getTime(), file.getName(), new Date(), "OMSARSWKST");
		arsWkst.execute(new File(path.substring(1)));
		messageCountEnd(file.getName().replace(".csv", ".zip"), file.getName(), new Date());
		
		Map<String, Object> condition = new HashMap<String, Object>();
		condition.put("storeId", "00100");
		condition.put("arsDate", DateUtils.cdateFormat(arsDate));
		condition.put("skus", new String[]{"014106406"});
		List<ArsWorksheet> arsList = arsDao.findAllArsWorksheetByCondition(condition);
		
		assertNotNull(arsList);
		
		for(ArsWorksheet ars : arsList) {
			assertEquals(new Integer(18), ars.getDcQty());
		}
	}
	
	/**
	 * 仿照InboundManager處理邏輯，先寫入Message_Count資料
	 * @param zipFilename 壓縮檔案名稱
	 * @param unzipTime 解壓縮時間
	 * @param unzipDuration 檔案大小
	 * @param unzipFilename 解壓縮後的檔案名稱
	 * @param executeTime 執行的時間
	 * @param code 電文名稱
	 * @throws Exception
	 */
	private void messageCountStart(String zipFilename , Date unzipTime , Long unzipDuration ,String unzipFilename , Date executeTime, String code) throws Exception{
		messageCountService.addMessageCount(zipFilename , unzipTime , unzipDuration , unzipFilename , executeTime, code.substring(0,10));
	}

	/**
	 * 仿照InboundManager處理邏輯，處理後更新Message_Count的結束時間
	 * @param zipFilename 壓縮檔案名稱
	 * @param unzipFilename 解壓縮後的檔案名稱
	 * @param endTime 結束的時間
	 * @throws Exception
	 */
	private void messageCountEnd(String zipFilename , String unzipFilename , Date endTime) throws Exception{
		messageCountService.updateMessageCountEndTime(zipFilename , unzipFilename , new Date());
	}
}