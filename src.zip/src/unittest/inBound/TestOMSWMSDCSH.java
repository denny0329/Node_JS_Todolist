/**
 * @(#)TestOMSWMSDCSH.java 2015/11/26
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest.inBound;

import java.io.File;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.dataex.wms.inbound.OMSWMSDCSH;
import com.rfep.iv.model.IvStoreInventory;
import com.rfep.iv.service.InventoryService;
import com.rfep.iv.sto.dao.hibernate.StoDao;
import com.rfep.iv.trf.model.Trf;
import com.rfep.iv.trf.model.TrfSku;

public class TestOMSWMSDCSH extends TestCase {
	private StoDao stoDao;
	private InventoryService inventoryService;
	private OMSWMSDCSH omsTest;
	
	protected void setUp() throws Exception {
		super.setUp();
		stoDao = (StoDao)AppContext.getBean("stoDao");
		inventoryService = (InventoryService)AppContext.getBean("inventoryService");
		omsTest = new OMSWMSDCSH();
		omsTest.setStoDao(stoDao);
		omsTest.setInventoryService(inventoryService);
	}
	
	public void testInsertInventory() {
		String trfNo = "5200346345";
		Trf trf = stoDao.findTrfByTrfNo(trfNo);
		trf.setStatus(1);
		trf.setModifyTime(null);
		trf.setOutDate(null);
		for(TrfSku trfSku : trf.getTrfSkuList()) {
			trfSku.setOutQty(null);
			trfSku.setAllocateQty(null);
			trfSku.setMwTime(null);
			trfSku.setMwFlag(null);
			trfSku.setModifier(null);
			trfSku.setModifierName(null);
			trfSku.setModifyTime(null);
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), trfSku.getSku());
			stoDao.deleteObject(ivStoreInventory);
		}
		stoDao.updateObject(trf);
		
		stoDao.executeSQL("delete iv_trf_dc_ship where wave=?", "9999999901");
		
		String path = this.getClass().getResource("").getPath() + "file" + File.separator+ "TestOMSWMSDCSH_CASE01.csv";
		File file = new File(path.substring(1));
		omsTest.execute(file);
		
		trf = stoDao.findTrfByTrfNo(trfNo);
		assertEquals(2, trf.getStatus().intValue());
		assertNotNull(trf.getOutDate());
		assertNotNull(trf.getModifyTime());
		
		for(TrfSku sku : trf.getTrfSkuList()) {
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			if("000334472".equals(sku.getSku())) {
				assertNull(sku.getOutQty());
				assertEquals(0, sku.getAllocateQty().intValue());
				assertEquals(0, ivStoreInventory.getAllocateQty().intValue());
			} else {
				assertEquals(6, sku.getOutQty().intValue());
				assertEquals(6, sku.getAllocateQty().intValue());
				assertEquals(6, ivStoreInventory.getAllocateQty().intValue());
			}
			assertEquals("OMSWMSDCSH", sku.getModifier());
			assertNotNull(sku.getModifyTime());
			assertEquals(-6, ivStoreInventory.getOnTrf().intValue());
			assertNull(ivStoreInventory.getMwTime());
			assertNull(ivStoreInventory.getSyncTime());
		}
	}
	
	public void testStatusChangeTo2() {
		String trfNo1 = "5101141506";
		Trf trf1 = stoDao.findTrfByTrfNo(trfNo1);
		trf1.setStatus(1);
		trf1.setModifyTime(null);
		trf1.setOutDate(null);
		for(TrfSku trfSku1 : trf1.getTrfSkuList()) {
			trfSku1.setOutQty(null);
			trfSku1.setAllocateQty(null);
			trfSku1.setMwTime(null);
			trfSku1.setMwFlag(null);
			trfSku1.setModifier(null);
			trfSku1.setModifierName(null);
			trfSku1.setModifyTime(null);
			IvStoreInventory ivStoreInventory1 = inventoryService.getIvStoreInventory(trf1.getInStoreId(), trfSku1.getSku());
			ivStoreInventory1.setOnTrf(12);
			ivStoreInventory1.setAllocateQty(0);
			stoDao.updateObject(ivStoreInventory1);
		}
		stoDao.updateObject(trf1);
		
		String trfNo2 = "5101147322";
		Trf trf2 = stoDao.findTrfByTrfNo(trfNo2);
		trf2.setStatus(1);
		trf2.setModifyTime(null);
		trf2.setOutDate(null);
		for(TrfSku trfSku2 : trf2.getTrfSkuList()) {
			trfSku2.setOutQty(null);
			trfSku2.setAllocateQty(null);
			trfSku2.setMwTime(null);
			trfSku2.setMwFlag(null);
			trfSku2.setModifier(null);
			trfSku2.setModifierName(null);
			trfSku2.setModifyTime(null);
			IvStoreInventory ivStoreInventory2 = inventoryService.getIvStoreInventory(trf2.getInStoreId(), trfSku2.getSku());
			ivStoreInventory2.setOnTrf(6);
			ivStoreInventory2.setAllocateQty(0);
			stoDao.updateObject(ivStoreInventory2);
		}
		stoDao.updateObject(trf2);
		
		String trfNo3 = "5040142655";
		Trf trf3 = stoDao.findTrfByTrfNo(trfNo3);
		trf3.setStatus(1);
		trf3.setModifyTime(null);
		trf3.setOutDate(null);
		for(TrfSku trfSku3 : trf3.getTrfSkuList()) {
			trfSku3.setOutQty(null);
			trfSku3.setAllocateQty(null);
			trfSku3.setMwTime(null);
			trfSku3.setMwFlag(null);
			trfSku3.setModifier(null);
			trfSku3.setModifierName(null);
			trfSku3.setModifyTime(null);
			IvStoreInventory ivStoreInventory3 = inventoryService.getIvStoreInventory(trf3.getInStoreId(), trfSku3.getSku());
			if("016056771".equals(trfSku3.getSku())) {
				ivStoreInventory3.setOnTrf(4);
			} else {
				ivStoreInventory3.setOnTrf(12);
			}
			ivStoreInventory3.setAllocateQty(0);
			stoDao.updateObject(ivStoreInventory3);
		}
		stoDao.updateObject(trf3);
		
		stoDao.executeSQL("delete iv_trf_dc_ship where wave=?", "9999999902");
		
		String path = this.getClass().getResource("").getPath() + "file" + File.separator+ "TestOMSWMSDCSH_CASE02.csv";
		File file = new File(path.substring(1));
		omsTest.execute(file);
		
		trf1 = stoDao.findTrfByTrfNo(trfNo1);
		assertEquals(2, trf1.getStatus().intValue());
		assertNotNull(trf1.getOutDate());
		assertNotNull(trf1.getModifyTime());
		for(TrfSku trfSku1 : trf1.getTrfSkuList()) {
			assertEquals("OMSWMSDCSH", trfSku1.getModifier());
			assertNotNull(trfSku1.getModifyTime());
			assertEquals(12, trfSku1.getOutQty().intValue());
			assertEquals(12, trfSku1.getAllocateQty().intValue());
			
			IvStoreInventory ivStoreInventory1 = inventoryService.getIvStoreInventory(trf1.getInStoreId(), trfSku1.getSku());
			assertEquals(12, ivStoreInventory1.getAllocateQty().intValue());
			assertEquals(0, ivStoreInventory1.getOnTrf().intValue());
		}
		
		trf2 = stoDao.findTrfByTrfNo(trfNo2);
		assertEquals(2, trf2.getStatus().intValue());
		assertNotNull(trf2.getOutDate());
		assertNotNull(trf2.getModifyTime());
		for(TrfSku trfSku2 : trf2.getTrfSkuList()) {
			assertEquals("OMSWMSDCSH", trfSku2.getModifier());
			assertNotNull(trfSku2.getModifyTime());
			assertEquals(6, trfSku2.getOutQty().intValue());
			assertEquals(6, trfSku2.getAllocateQty().intValue());
			
			IvStoreInventory ivStoreInventory2 = inventoryService.getIvStoreInventory(trf2.getInStoreId(), trfSku2.getSku());
			assertEquals(6, ivStoreInventory2.getAllocateQty().intValue());
			assertEquals(0, ivStoreInventory2.getOnTrf().intValue());
		}
		
		trf3 = stoDao.findTrfByTrfNo(trfNo3);
		assertEquals(2, trf3.getStatus().intValue());
		assertNotNull(trf3.getOutDate());
		assertNotNull(trf3.getModifyTime());
		for(TrfSku trfSku3 : trf3.getTrfSkuList()) {
			assertEquals("OMSWMSDCSH", trfSku3.getModifier());
			assertNotNull(trfSku3.getModifyTime());
			
			IvStoreInventory ivStoreInventory3 = inventoryService.getIvStoreInventory(trf3.getInStoreId(), trfSku3.getSku());
			if("016056771".equals(trfSku3.getSku())) {
				assertEquals(4, trfSku3.getOutQty().intValue());
				assertEquals(4, trfSku3.getAllocateQty().intValue());
				assertEquals(4, ivStoreInventory3.getAllocateQty().intValue());
			} else {
				assertEquals(12, trfSku3.getOutQty().intValue());
				assertEquals(12, trfSku3.getAllocateQty().intValue());
				assertEquals(12, ivStoreInventory3.getAllocateQty().intValue());
			}
			assertEquals(0, ivStoreInventory3.getOnTrf().intValue());
		}
	}
}
