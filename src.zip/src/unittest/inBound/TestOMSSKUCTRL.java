/**
 * @(#)TestOMSSKUCTRL.java 2015/12/08
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest.inBound;

import java.io.File;
import java.util.Date;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.dataex.mm.inbound.OMSSKUCTRL;
import com.rfep.dataex.util.service.MessageCountService;

public class TestOMSSKUCTRL extends TestCase {
	private MessageCountService messageCountService;
	private OMSSKUCTRL note;
	
	protected void setUp() throws Exception {
		super.setUp();
		messageCountService = (MessageCountService)AppContext.getBean("messageCountService");
		note = new OMSSKUCTRL();
	}

	/**
	 * 讀取電文檔
	 * @throws Exception
	 */
	public void TestOMSSKUCTRLCASE01() throws Exception {
		String path = this.getClass().getResource("").getPath() + "file" + File.separator + "TestOMSSKUCTRL_CASE01.csv";
		File file = new File(path.substring(1));
		messageCountStart(file.getName().replace(".csv", ".zip"), new Date(), new Date().getTime(), file.getName(), new Date(), "OMSSKUCTRL");
		note.execute(file);
		messageCountEnd(file.getName().replace(".csv", ".zip"), file.getName(), new Date());
	}

	/**
	 * 仿照InboundManager處理邏輯，先寫入Message_Count資料
	 * @param zipFilename 壓縮檔案名稱
	 * @param unzipTime 解壓縮時間
	 * @param unzipDuration 檔案大小
	 * @param unzipFilename 解壓縮後的檔案名稱
	 * @param executeTime 執行的時間
	 * @param code 電文名稱
	 * @throws Exception
	 */
	private void messageCountStart(String zipFilename , Date unzipTime , Long unzipDuration ,String unzipFilename , Date executeTime, String code) throws Exception{
		messageCountService.addMessageCount(zipFilename , unzipTime , unzipDuration , unzipFilename , executeTime, code.substring(0,10));
	}

	/**
	 * 仿照InboundManager處理邏輯，處理後更新Message_Count的結束時間
	 * @param zipFilename 壓縮檔案名稱
	 * @param unzipFilename 解壓縮後的檔案名稱
	 * @param endTime 結束的時間
	 * @throws Exception
	 */
	private void messageCountEnd(String zipFilename , String unzipFilename , Date endTime) throws Exception{
		messageCountService.updateMessageCountEndTime(zipFilename , unzipFilename , new Date());
	}
}
