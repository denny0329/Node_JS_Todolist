package unittest.inBound;

import java.io.File;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.gccs.bs.dao.hibernate.BsSkuDao;
import com.rfep.bs.dao.hibernate.BsParaDao;
import com.rfep.bs.service.BsVendorService;
import com.rfep.dataex.mm.inbound.OMSIVPOSAP;
import com.rfep.iv.dao.SkuLimitDao;
import com.rfep.iv.po.dao.hibernate.PoDao;
import com.rfep.iv.rtv.dao.RtvDao;
import com.rfep.iv.service.InventoryService;
import com.rfep.iv.sto.dao.hibernate.StoDao;
import com.rfep.product.bs.dao.hibernate.BsSkuStoreDao;
import com.rfep.product.bs.dao.hibernate.BsSkuUnitDao;
import com.trg.oms.externalWS.crm.CallCrmWebService;
import com.trg.oms.utils.dao.OmsMailDao;

public class TestOMSIVPOSAP extends TestCase {
	private PoDao poDao;
	private BsSkuDao bsSkuDao;
	private StoDao stoDao;
	private RtvDao rtvDao;
	private SkuLimitDao skuLimitDao;
	private BsSkuStoreDao bsSkuStoreDao;
	private BsSkuUnitDao bsSkuUnitDao;
	private InventoryService inventoryService;
	private BsVendorService bsVendorService;
	private BsParaDao bsParaDao;
	private OmsMailDao omsMailDao;
	private CallCrmWebService callCrmWebService;
	
	private OMSIVPOSAP ivPoSAP;
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		
		poDao = (PoDao)AppContext.getBean("poDao");
		bsSkuDao = (BsSkuDao)AppContext.getBean("bsSkuDao");
		stoDao = (StoDao) AppContext.getBean("stoDao");
		rtvDao = (RtvDao)AppContext.getBean("rtvDao");
		skuLimitDao = (SkuLimitDao) AppContext.getBean("skuLimitDao");
		bsSkuStoreDao = (BsSkuStoreDao)AppContext.getBean("bsSkuStoreDao");
		inventoryService = (InventoryService) AppContext.getBean("inventoryService");
		bsVendorService = (BsVendorService) AppContext.getBean("bsVendorService");
		bsSkuUnitDao = (BsSkuUnitDao) AppContext.getBean("bsSkuUnitDao");
		bsParaDao = (BsParaDao) AppContext.getBean("bsParaDao");
		omsMailDao = (OmsMailDao)AppContext.getBean("omsMailDao");
		callCrmWebService = (CallCrmWebService)AppContext.getBean("callCrmWebService");
		
		ivPoSAP = new OMSIVPOSAP();
		
		ivPoSAP.setBsSkuDao(bsSkuDao);
		ivPoSAP.setPoDao(poDao);
		ivPoSAP.setStoDao(stoDao);
		ivPoSAP.setRtvDao(rtvDao);
		ivPoSAP.setSkuLimitDao(skuLimitDao);
		ivPoSAP.setBsSkuStoreDao(bsSkuStoreDao);
		ivPoSAP.setBsSkuUnitDao(bsSkuUnitDao);
		ivPoSAP.setBsParaDao(bsParaDao);
		ivPoSAP.setOmsMailDao(omsMailDao);
		ivPoSAP.setInventoryService(inventoryService);
		ivPoSAP.setBsVendorService(bsVendorService);
		ivPoSAP.setCallCrmWebService(callCrmWebService);
	}
	
	public void testCallCrmWebService(){
		try {
			String path = this.getClass().getResource("").getPath() + "file" + File.separator + "TestOMSIVPOSAP_CASE01.csv";
			File file = new File(path.substring(1));
			ivPoSAP.execute(file);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}