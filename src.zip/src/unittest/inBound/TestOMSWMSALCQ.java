/**
 * @(#)TestOMSWMSALCQ.java 2015/12/08
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest.inBound;

import java.io.File;
import java.util.Date;

import com.bnq.util.AppContext;
import com.rfep.dataex.util.service.MessageCountService;
import com.rfep.dataex.wms.inbound.OMSWMSALCQ;
import com.rfep.iv.model.IvStoreInventory;
import com.rfep.iv.service.InventoryService;
import com.rfep.iv.sto.dao.hibernate.StoDao;
import com.rfep.iv.trf.model.Trf;
import com.rfep.iv.trf.model.TrfSku;

import junit.framework.TestCase;

/**
 * 測試 OMSWMSALCQ
 * @author T2482
 */
public class TestOMSWMSALCQ extends TestCase {
	private StoDao stoDao;
	private InventoryService inventoryService;
	private OMSWMSALCQ note;
	private Date modifyTime = new Date();
	private MessageCountService messageCountService;

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		stoDao = (StoDao)AppContext.getBean("stoDao");
		inventoryService = (InventoryService)AppContext.getBean("inventoryService");
		note = (OMSWMSALCQ)AppContext.getBean("OMSWMSALCQ");
		note.setStoDao(stoDao);
		note.setInventoryService(inventoryService);
		
		messageCountService = (MessageCountService)AppContext.getBean("messageCountService");
	}
	
	/**
	 * 仿照InboundManager處理邏輯，先寫入Message_Count資料
	 * @param zipFilename 壓縮檔案名稱
	 * @param unzipTime 解壓縮時間
	 * @param unzipDuration 檔案大小
	 * @param unzipFilename 解壓縮後的檔案名稱
	 * @param executeTime 執行的時間
	 * @param code 電文名稱
	 * @throws Exception
	 */
	private void messageCountStart(String zipFilename , Date unzipTime , Long unzipDuration ,String unzipFilename , Date executeTime, String code) throws Exception{
		messageCountService.addMessageCount(zipFilename , unzipTime , unzipDuration , unzipFilename , executeTime, code.substring(0,10));
	}

	/**
	 * 仿照InboundManager處理邏輯，處理後更新Message_Count的結束時間
	 * @param zipFilename 壓縮檔案名稱
	 * @param unzipFilename 解壓縮後的檔案名稱
	 * @param endTime 結束的時間
	 * @throws Exception
	 */
	private void messageCountEnd(String zipFilename , String unzipFilename , Date endTime) throws Exception{
		messageCountService.updateMessageCountEndTime(zipFilename , unzipFilename , modifyTime);
	}
	
	/**
	 * 測試 ZSTO_STATUS = A，iv_trf.status != 1<br>
	 * 測試前先確定 trf 存在 DB，若不存在置換另一個 trf 且須一併修改 CASE01.csv 內容。
	 * @throws Exception 
	 */
	public void testAllocateIsA_StatusIsNot1() throws Exception {
		String trfNo = "5100948691";
		Trf trf = stoDao.findTrfByTrfNo(trfNo);
		trf.setStatus(0);
		trf.setModifyTime(modifyTime);
		for(TrfSku sku : trf.getTrfSkuList()) {
			sku.setAllocateQty(null);
			sku.setDelFlag(null);
			sku.setModifier("TesetOMSWMSALCQ");
			sku.setModifierName("TesetOMSWMSALCQ");
			sku.setModifyTime(modifyTime);
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			ivStoreInventory.setOnTrf(1);
			ivStoreInventory.setAllocateQty(0);
			inventoryService.updateIvStoreInventory(ivStoreInventory);
		}
		stoDao.updateObject(trf);
		
		// 電文傳入不會造成任何異動
		String path = this.getClass().getResource("").getPath() + "file" + File.separator+ "TestOMSWMSALCQ_CASE01.csv";
		File file = new File(path.substring(1));
		messageCountStart(file.getName().replace(".csv", ".zip"), modifyTime, modifyTime.getTime(), file.getName(), modifyTime, "OMSWMSALCQ");
		note.execute(file);
		messageCountEnd(file.getName().replace(".csv", ".zip"), file.getName(), modifyTime);
		
		trf = stoDao.findTrfByTrfNo(trfNo);
		assertEquals(0, trf.getStatus().intValue());
		for(TrfSku sku : trf.getTrfSkuList()) {
			assertNull(sku.getAllocateQty());
			assertEquals("TestOMSWMSALCQ", sku.getModifier());
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			assertEquals(1, ivStoreInventory.getOnTrf().intValue());
			assertEquals(0, ivStoreInventory.getAllocateQty().intValue());
		}
	}
	
	/**
	 * 測試 ZSTO_STATUS = A 且 iv_trf.status = 1 且所有 iv_trf_sku.del_flag = 1
	 * @throws Exception 
	 */
	public void testAllocateIsA_delFlagIs1() throws Exception {
		String trfNo = "5100948691";
		Trf trf = stoDao.findTrfByTrfNo(trfNo);
		trf.setStatus(1);
		trf.setModifyTime(modifyTime);
		for(TrfSku sku : trf.getTrfSkuList()) {
			sku.setAllocateQty(null);
			sku.setDelFlag(1);
			sku.setModifier("TesetOMSWMSALCQ");
			sku.setModifierName("TesetOMSWMSALCQ");
			sku.setModifyTime(modifyTime);
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			ivStoreInventory.setOnTrf(1);
			ivStoreInventory.setAllocateQty(0);
			inventoryService.updateIvStoreInventory(ivStoreInventory);
		}
		stoDao.updateObject(trf);
		
		// 電文傳入不會造成任何異動
		String path = this.getClass().getResource("").getPath() + "file" + File.separator+ "TestOMSWMSALCQ_CASE02.csv";
		File file = new File(path.substring(1));
		messageCountStart(file.getName().replace(".csv", ".zip"), modifyTime, modifyTime.getTime(), file.getName(), modifyTime, "OMSWMSALCQ");
		note.execute(file);
		messageCountEnd(file.getName().replace(".csv", ".zip"), file.getName(), modifyTime);
		
		trf = stoDao.findTrfByTrfNo(trfNo);
		assertEquals(1, trf.getStatus().intValue());
		for(TrfSku sku : trf.getTrfSkuList()) {
			assertNull(sku.getAllocateQty());
			assertEquals("TestOMSWMSALCQ", sku.getModifier());
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			assertEquals(1, ivStoreInventory.getOnTrf().intValue());
			assertEquals(0, ivStoreInventory.getAllocateQty().intValue());
		}
	}
	
	/**
	 * 測試 ZSTO_STATUS = A 且 iv_trf.status = 1 且所有 iv_trf_sku.del_flag != 1
	 * @throws Exception 
	 */
	public void testAllocateIsA_delFlagIsNot1() throws Exception {
		String trfNo = "5100948691";
		Trf trf = stoDao.findTrfByTrfNo(trfNo);
		trf.setStatus(1);
		trf.setModifyTime(modifyTime);
		for(TrfSku sku : trf.getTrfSkuList()) {
			sku.setAllocateQty(null);
			sku.setApplyQty(1);
			sku.setDelFlag(null);
			sku.setModifier("TesetOMSWMSALCQ");
			sku.setModifierName("TesetOMSWMSALCQ");
			sku.setModifyTime(modifyTime);
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			ivStoreInventory.setOnTrf(1);
			ivStoreInventory.setAllocateQty(0);
			inventoryService.updateIvStoreInventory(ivStoreInventory);
		}
		stoDao.updateObject(trf);
		
		// 全部 SKU 的庫存值都會異動
		String path = this.getClass().getResource("").getPath() + "file" + File.separator+ "TestOMSWMSALCQ_CASE03.csv";
		File file = new File(path.substring(1));
		messageCountStart(file.getName().replace(".csv", ".zip"), modifyTime, modifyTime.getTime(), file.getName(), modifyTime, "OMSWMSALCQ");
		note.execute(file);
		messageCountEnd(file.getName().replace(".csv", ".zip"), file.getName(), modifyTime);
		
		trf = stoDao.findTrfByTrfNo(trfNo);
		assertEquals(9, trf.getStatus().intValue());
		for(TrfSku sku : trf.getTrfSkuList()) {
			assertEquals(1, sku.getAllocateQty().intValue());
			assertEquals("TestOMSWMSALCQ", sku.getModifier());
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			assertEquals(0, ivStoreInventory.getOnTrf().intValue());
			assertEquals(1, ivStoreInventory.getAllocateQty().intValue());
		}
	}
	
	/**
	 * 測試 ZSTO_STATUS = A 且 iv_trf.status = 1 且所有 iv_trf_sku.del_flag != 1<br>
	 * 只有 iv_trf_sku.seq_no 為奇數的 SKU 在電文內
	 * @throws Exception 
	 */
	public void testAllocateIsA_sameSkuInCsv() throws Exception {
		String trfNo = "5100948691";
		Trf trf = stoDao.findTrfByTrfNo(trfNo);
		trf.setStatus(1);
		trf.setModifyTime(modifyTime);
		for(TrfSku sku : trf.getTrfSkuList()) {
			sku.setAllocateQty(null);
			sku.setApplyQty(1);
			sku.setDelFlag(null);
			sku.setModifier("TesetOMSWMSALCQ");
			sku.setModifierName("TesetOMSWMSALCQ");
			sku.setModifyTime(modifyTime);
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			ivStoreInventory.setOnTrf(1);
			ivStoreInventory.setAllocateQty(0);
			inventoryService.updateIvStoreInventory(ivStoreInventory);
		}
		stoDao.updateObject(trf);
		
		// 奇數 seq_no SKU 的庫存值 on_trf、allocate_qty 會異動，偶數只會動 on_trf
		String path = this.getClass().getResource("").getPath() + "file" + File.separator+ "TestOMSWMSALCQ_CASE04.csv";
		File file = new File(path.substring(1));
		messageCountStart(file.getName().replace(".csv", ".zip"), modifyTime, modifyTime.getTime(), file.getName(), modifyTime, "OMSWMSALCQ");
		note.execute(file);
		messageCountEnd(file.getName().replace(".csv", ".zip"), file.getName(), modifyTime);
		
		trf = stoDao.findTrfByTrfNo(trfNo);
		assertEquals(9, trf.getStatus().intValue());
		for(TrfSku sku : trf.getTrfSkuList()) {
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			assertEquals(0, ivStoreInventory.getOnTrf().intValue());
			if(sku.getSeqNo() % 2 == 0) {
				assertEquals("TesetOMSWMSALCQ", sku.getModifier());
				assertNull(sku.getAllocateQty());
				assertEquals(0, ivStoreInventory.getAllocateQty().intValue());
			} else {
				assertEquals("OMSWMSALCQ", sku.getModifier());
				assertEquals(1, sku.getAllocateQty().intValue());
				assertEquals(1, ivStoreInventory.getAllocateQty().intValue());
			}
		}
	}
	
	/**
	 * 測試 ZSTO_STATUS = O 且 iv_trf.status != 9
	 * @throws Exception 
	 */
	public void testAllocateIsO_StatusIsNot9() throws Exception {
		String trfNo = "5100948559";
		Trf trf = stoDao.findTrfByTrfNo(trfNo);
		trf.setStatus(0);
		trf.setModifyTime(modifyTime);
		for(TrfSku sku : trf.getTrfSkuList()) {
			sku.setAllocateQty(1);
			sku.setApplyQty(1);
			sku.setDelFlag(null);
			sku.setModifier("TesetOMSWMSALCQ");
			sku.setModifierName("TesetOMSWMSALCQ");
			sku.setModifyTime(modifyTime);
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			ivStoreInventory.setOnTrf(0);
			ivStoreInventory.setAllocateQty(1);
			inventoryService.updateIvStoreInventory(ivStoreInventory);
		}
		stoDao.updateObject(trf);
		
		// 電文傳入不會造成任何異動
		String path = this.getClass().getResource("").getPath() + "file" + File.separator+ "TestOMSWMSALCQ_CASE05.csv";
		File file = new File(path.substring(1));
		messageCountStart(file.getName().replace(".csv", ".zip"), modifyTime, modifyTime.getTime(), file.getName(), modifyTime, "OMSWMSALCQ");
		note.execute(file);
		messageCountEnd(file.getName().replace(".csv", ".zip"), file.getName(), modifyTime);
		
		trf = stoDao.findTrfByTrfNo(trfNo);
		assertEquals(0, trf.getStatus().intValue());
		for(TrfSku sku : trf.getTrfSkuList()) {
			assertEquals(1, sku.getAllocateQty().intValue());
			assertEquals(1, sku.getApplyQty().intValue());
			assertEquals("TesetOMSWMSALCQ", sku.getModifier());
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			assertEquals(0, ivStoreInventory.getOnTrf().intValue());
			assertEquals(1, ivStoreInventory.getAllocateQty().intValue());
		}
	}
	
	/**
	 * 測試 ZSTO_STATUS = O 且 iv_trf.status = 9 且所有 iv_trf_sku.del_flag = 1
	 * @throws Exception 
	 */
	public void testAllocateIsO_delFlagIs1() throws Exception {
		String trfNo = "5100948559";
		Trf trf = stoDao.findTrfByTrfNo(trfNo);
		trf.setStatus(9);
		trf.setModifyTime(modifyTime);
		for(TrfSku sku : trf.getTrfSkuList()) {
			sku.setAllocateQty(1);
			sku.setApplyQty(1);
			sku.setDelFlag(1);
			sku.setModifier("TesetOMSWMSALCQ");
			sku.setModifierName("TesetOMSWMSALCQ");
			sku.setModifyTime(modifyTime);
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			ivStoreInventory.setOnTrf(0);
			ivStoreInventory.setAllocateQty(1);
			inventoryService.updateIvStoreInventory(ivStoreInventory);
		}
		stoDao.updateObject(trf);
		
		// 電文傳入不會造成任何異動
		String path = this.getClass().getResource("").getPath() + "file" + File.separator+ "TestOMSWMSALCQ_CASE06.csv";
		File file = new File(path.substring(1));
		messageCountStart(file.getName().replace(".csv", ".zip"), modifyTime, modifyTime.getTime(), file.getName(), modifyTime, "OMSWMSALCQ");
		note.execute(file);
		messageCountEnd(file.getName().replace(".csv", ".zip"), file.getName(), modifyTime);
		
		trf = stoDao.findTrfByTrfNo(trfNo);
		assertEquals(9, trf.getStatus().intValue());
		for(TrfSku sku : trf.getTrfSkuList()) {
			assertEquals(1, sku.getAllocateQty().intValue());
			assertEquals(1, sku.getApplyQty().intValue());
			assertEquals("TesetOMSWMSALCQ", sku.getModifier());
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			assertEquals(0, ivStoreInventory.getOnTrf().intValue());
			assertEquals(1, ivStoreInventory.getAllocateQty().intValue());
		}
	}
	
	/**
	 * 測試 ZSTO_STATUS = O 且 iv_trf.status = 9 且 iv_trf_sku.del_flag != 1
	 * @throws Exception 
	 */
	public void testAllocateIsO_delFlagIsNot1() throws Exception {
		String trfNo = "5100948559";
		Trf trf = stoDao.findTrfByTrfNo(trfNo);
		trf.setStatus(9);
		trf.setModifyTime(modifyTime);
		for(TrfSku sku : trf.getTrfSkuList()) {
			sku.setAllocateQty(1);
			sku.setApplyQty(1);
			sku.setDelFlag(null);
			sku.setModifier("TesetOMSWMSALCQ");
			sku.setModifierName("TesetOMSWMSALCQ");
			sku.setModifyTime(modifyTime);
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			ivStoreInventory.setOnTrf(0);
			ivStoreInventory.setAllocateQty(1);
			inventoryService.updateIvStoreInventory(ivStoreInventory);
		}
		stoDao.updateObject(trf);
		
		String path = this.getClass().getResource("").getPath() + "file" + File.separator+ "TestOMSWMSALCQ_CASE07.csv";
		File file = new File(path.substring(1));
		messageCountStart(file.getName().replace(".csv", ".zip"), modifyTime, modifyTime.getTime(), file.getName(), modifyTime, "OMSWMSALCQ");
		note.execute(file);
		messageCountEnd(file.getName().replace(".csv", ".zip"), file.getName(), modifyTime);
		
		trf = stoDao.findTrfByTrfNo(trfNo);
		assertEquals(1, trf.getStatus().intValue());
		for(TrfSku sku : trf.getTrfSkuList()) {
			assertNull(sku.getAllocateQty());
			assertEquals("OMSWMSALCQ", sku.getModifier());
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			assertEquals(1, ivStoreInventory.getOnTrf().intValue());
			assertEquals(0, ivStoreInventory.getAllocateQty().intValue());
		}
	}
	
	/**
	 * 測試新建 Allocate時，無庫存資料時會新建一筆
	 */
	public void testTypeAInsertInventory() {
		String trfNo = "5100948691";
		Trf trf = stoDao.findTrfByTrfNo(trfNo);
		trf.setStatus(1);
		trf.setModifyTime(modifyTime);
		for(TrfSku sku : trf.getTrfSkuList()) {
			sku.setAllocateQty(null);
			sku.setApplyQty(1);
			sku.setDelFlag(null);
			sku.setModifier("TesetOMSWMSALCQ");
			sku.setModifierName("TesetOMSWMSALCQ");
			sku.setModifyTime(modifyTime);
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			stoDao.deleteObject(ivStoreInventory);
		}
		stoDao.updateObject(trf);
		
		// 全部 SKU 的庫存值都會異動
		String path = this.getClass().getResource("").getPath() + "file" + File.separator+ "TestOMSWMSALCQ_CASE03.csv";
		File file = new File(path.substring(1));
		note.execute(file);
		
		trf = stoDao.findTrfByTrfNo(trfNo);
		assertEquals(9, trf.getStatus().intValue());
		for(TrfSku sku : trf.getTrfSkuList()) {
			assertEquals(1, sku.getAllocateQty().intValue());
			assertEquals("OMSWMSALCQ", sku.getModifier());
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			assertEquals(-1, ivStoreInventory.getOnTrf().intValue());
			assertEquals(1, ivStoreInventory.getAllocateQty().intValue());
			assertEquals(1, ivStoreInventory.getMwFlag().intValue());
			assertNotNull(ivStoreInventory.getMwTime());
			assertNull(ivStoreInventory.getSyncTime());
		}
	}
	
	/**
	 * 測試刪除 Allocate時，無庫存資料時會新建一筆
	 */
	public void testTypeOInsertInventory() {
		String trfNo = "5100948559";
		Trf trf = stoDao.findTrfByTrfNo(trfNo);
		trf.setStatus(9);
		trf.setModifyTime(modifyTime);
		for(TrfSku sku : trf.getTrfSkuList()) {
			sku.setAllocateQty(1);
			sku.setApplyQty(1);
			sku.setDelFlag(null);
			sku.setModifier("TesetOMSWMSALCQ");
			sku.setModifierName("TesetOMSWMSALCQ");
			sku.setModifyTime(modifyTime);
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			stoDao.deleteObject(ivStoreInventory);
		}
		stoDao.updateObject(trf);
		
		String path = this.getClass().getResource("").getPath() + "file" + File.separator+ "TestOMSWMSALCQ_CASE07.csv";
		File file = new File(path.substring(1));
		note.execute(file);
		
		trf = stoDao.findTrfByTrfNo(trfNo);
		assertEquals(1, trf.getStatus().intValue());
		for(TrfSku sku : trf.getTrfSkuList()) {
			assertNull(sku.getAllocateQty());
			assertEquals("OMSWMSALCQ", sku.getModifier());
			IvStoreInventory ivStoreInventory = inventoryService.getIvStoreInventory(trf.getInStoreId(), sku.getSku());
			assertEquals(1, ivStoreInventory.getOnTrf().intValue());
			assertEquals(-1, ivStoreInventory.getAllocateQty().intValue());
			assertEquals(1, ivStoreInventory.getMwFlag().intValue());
			assertNotNull(ivStoreInventory.getMwTime());
			assertNull(ivStoreInventory.getSyncTime());
		}
	}
	/**
	 * 測試刪除 Allocate時，無庫存資料時會新建一筆
	 */
	public void testFile() {
		String path = this.getClass().getResource("").getPath() + "file" + File.separator+ "TestOMSWMSALCQ222.csv";
		File file = new File(path.substring(1));
		System.out.println(file.exists());
		System.out.println(file.isFile());
		System.out.println(file.length());
		
		note.execute(file);
	}

	/**
	 * 測試 接收到 狀態為O的電文 刪除allocate資料
	 */
	public void testDeleteAllocate() {
		String path = this.getClass().getResource("").getPath() + "file" + File.separator+ "TestOMSWMSALCQ_CASE08.csv";
		File file = new File(path.substring(1));

		note.execute(file);
	}
	
}