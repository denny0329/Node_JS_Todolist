package unittest.inBound;

import com.bnq.util.AppContext;
import com.rfep.dataex.mm.inbound.OMSINNESET;
import junit.framework.TestCase;

import java.io.File;

public class TestOMSINNESET extends TestCase {

    private OMSINNESET omsinneset;

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        omsinneset = (OMSINNESET) AppContext.getBean("OMSINNESET");
    }

    public void testOMSINNESET() {
        try {
            String path = this.getClass().getResource("").getPath() + "file" + File.separator + "TestOMSINNESET_CASE01.csv";
            File file = new File(path.substring(1));
            omsinneset.execute(file);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}
