/**
 * @(#)TestOMSSKUMSTR.java 2015/12/08
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest.inBound;

import java.io.File;
import java.util.Date;

import junit.framework.TestCase;

import org.springframework.orm.hibernate3.HibernateTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import com.bnq.util.AppContext;
import com.gccs.bs.dao.hibernate.BsSkuDao;
import com.rfep.bs.dao.hibernate.BsParaDao;
import com.rfep.bs.dao.hibernate.BsVendorSkuDao;
import com.rfep.dataex.mm.inbound.OMSSKUMSTR;
import com.rfep.dataex.util.service.MessageCountService;
import com.rfep.product.bs.dao.hibernate.BsSkuModifyDao;
import com.rfep.product.bs.dao.hibernate.BsSkuSpecDao;
import com.rfep.product.bs.dao.hibernate.BsSkuUnitDao;

public class TestOMSSKUMSTR extends TestCase {
	private BsParaDao bsParaDao;
	private BsSkuDao bsSkuDao;
	private BsSkuModifyDao bsSkuModifyDao;
	private BsSkuSpecDao bsSkuSpecDao;
	private BsSkuUnitDao bsSkuUnitDao;
	private BsVendorSkuDao bsVendorSkuDao;
	private TransactionTemplate transactionTemplate;
	private MessageCountService messageCountService;
	
	private OMSSKUMSTR note;
	/**
	 * 若執行junit有出錯，Run>Run configuration>JUnit->
	 * TestOMSXDDLVDC=>右邊頁籤(Arguments->arguments VM)->貼上-Xms64m -Xmx128m
	 */
	protected void setUp() throws Exception {
		super.setUp();
		bsParaDao = (BsParaDao)AppContext.getBean("bsParaDao");
		bsSkuDao = (BsSkuDao)AppContext.getBean("bsSkuDao");
		bsSkuModifyDao = (BsSkuModifyDao)AppContext.getBean("bsSkuModifyDao");
		bsSkuSpecDao = (BsSkuSpecDao)AppContext.getBean("bsSkuSpecDao");
		bsSkuUnitDao = (BsSkuUnitDao)AppContext.getBean("bsSkuUnitDao");
		bsVendorSkuDao = (BsVendorSkuDao)AppContext.getBean("bsVendorSkuDao");
		
		transactionTemplate = new TransactionTemplate();
		transactionTemplate.setTransactionManager((HibernateTransactionManager)AppContext.getBean("dataSourceTxManager"));
		
		note = new OMSSKUMSTR();
		note.setBsParaDao(bsParaDao);
		note.setBsSkuDao(bsSkuDao);
		note.setBsSkuModifyDao(bsSkuModifyDao);
		note.setBsSkuSpecDao(bsSkuSpecDao);
		note.setBsSkuUnitDao(bsSkuUnitDao);
		note.setBsVendorSkuDao(bsVendorSkuDao);
		note.setTransactionTemplate(transactionTemplate);
		
		messageCountService = (MessageCountService)AppContext.getBean("messageCountService");
	}
	
	public void TestOMSSKUMSTRCASE01() throws Exception {
		String path = this.getClass().getResource("").getPath() + "file" + File.separator + "TestOMSSKUMSTR_CASE01.csv";
		File file = new File(path.substring(1));
		messageCountStart(file.getName().replace(".csv", ".zip"), new Date(), new Date().getTime(), file.getName(), new Date(), "OMSSKUMSTR");
		note.execute(file);
		messageCountEnd(file.getName().replace(".csv", ".zip"), file.getName(), new Date());
	}

	public void testZEINA() {
		String path = this.getClass().getResource("").getPath() + "file" + File.separator + "TestOMSSKUMSTR_CASE_ZEINA.csv";
		File file = new File(path.substring(1));
		note.execute(file);
		System.out.println(path);
	}
	
	/**
	 * 仿照InboundManager處理邏輯，先寫入Message_Count資料
	 * @param zipFilename 壓縮檔案名稱
	 * @param unzipTime 解壓縮時間
	 * @param unzipDuration 檔案大小
	 * @param unzipFilename 解壓縮後的檔案名稱
	 * @param executeTime 執行的時間
	 * @param code 電文名稱
	 * @throws Exception
	 */
	private void messageCountStart(String zipFilename , Date unzipTime , Long unzipDuration ,String unzipFilename , Date executeTime, String code) throws Exception{
		messageCountService.addMessageCount(zipFilename , unzipTime , unzipDuration , unzipFilename , executeTime, code.substring(0,10));
	}

	/**
	 * 仿照InboundManager處理邏輯，處理後更新Message_Count的結束時間
	 * @param zipFilename 壓縮檔案名稱
	 * @param unzipFilename 解壓縮後的檔案名稱
	 * @param endTime 結束的時間
	 * @throws Exception
	 */
	private void messageCountEnd(String zipFilename , String unzipFilename , Date endTime) throws Exception{
		messageCountService.updateMessageCountEndTime(zipFilename , unzipFilename , new Date());
	}
}
