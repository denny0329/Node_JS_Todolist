package unittest.inBound;

import java.io.File;

import junit.framework.TestCase;

import com.rfep.dataex.iv.inbound.OMSSMMSUMY;

public class TestOMSSMMSUMY extends TestCase {
	private OMSSMMSUMY note;
	protected void setUp() throws Exception {
	    super.setUp();
	    note = new OMSSMMSUMY();
	}
	
	/**
	 * 測試電文中N_ACT(ACTOIN)的值為Z，刪除iv_smm_summary.action=’Z’ and iv_smm_summary.channel_id=電文通路代碼
	 * 該電文ACTOIN為Z的及非Z的不會同時存在於電文中。
	 */
	public void testActionIsZ() {
		try {
			String path = this.getClass().getResource("").getPath() + "file" + File.separator+ "TestOMSSMMSUMY_CASE01.csv";
			File file = new File(path.substring(1));
			note.execute(file);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 測試電文中N_ACT(ACTOIN)的值不為Z，刪除 iv_smm_summary.action<>’Z’的所有舊資料
	 * 該電文ACTOIN為Z的及非Z的不會同時存在於電文中。
	 */
	public void testActionIsNotZ() {
		try {
			String path = this.getClass().getResource("").getPath() + "file" + File.separator+ "TestOMSSMMSUMY_CASE02.csv";
			File file = new File(path.substring(1));
			note.execute(file);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}