package unittest.inBound;

import com.bnq.util.AppContext;
import com.rfep.dataex.st.inbound.OMSSTKTAKD;
import junit.framework.TestCase;

import java.io.File;

public class TestOMSSTKTAKD extends TestCase {
    private OMSSTKTAKD omsstktakd;

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        omsstktakd = (OMSSTKTAKD) AppContext.getBean("OMSSTKTAKD");
    }

    public void testOMSSTKTAKD() {
//        String path = this.getClass().getResource("").getPath() + File.separator + "inBound" + File.separator + "file" + File.separator + "TestOMSSTKTAKD_CASE01.csv";
        String path = "/D:\\workspace\\omscrm\\src\\unittest\\inBound\\file\\TestOMSSTKTAKD_CASE01.csv";
        File file = new File(path.substring(1));
        omsstktakd.execute(file);
    }
}
