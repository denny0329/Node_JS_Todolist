package unittest.inBound;

import java.io.File;
import java.util.Date;

import junit.framework.TestCase;

import org.hibernate.Query;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import com.bnq.util.AppContext;
import com.bnq.util.DateUtils;
import com.gccs.bs.dao.hibernate.BsSkuDao;
import com.gccs.bs.dao.hibernate.BsStoreDao;
import com.rfep.bs.dao.hibernate.BsParaDao;
import com.rfep.dataex.mm.inbound.OMSGOODSCH;
import com.rfep.iv.dao.InventoryDao;
import com.rfep.iv.dao.IvDcInventoryChangeDao;
import com.rfep.iv.dao.IvNoidocAllocInventoryDao;
import com.rfep.iv.dao.IvStorageInventoryDao;
import com.rfep.iv.model.IvStoreInventory;
import com.rfep.iv.model.IvStoreInventoryChange;
import com.rfep.iv.po.dao.hibernate.PoDao;
import com.rfep.iv.po.model.Po;
import com.rfep.iv.po.model.PoSku;
import com.rfep.iv.rtv.dao.RtvDao;
import com.rfep.iv.rtv.model.PoRtv;
import com.rfep.iv.rtv.model.PoRtvSku;
import com.rfep.iv.rtv.model.TrfRtv;
import com.rfep.iv.rtv.model.TrfRtvSku;
import com.rfep.iv.service.InventoryService;
import com.rfep.iv.sto.dao.hibernate.StoDao;
import com.rfep.product.bs.dao.hibernate.BsSkuSalesSetDao;
import com.rfep.product.bs.dao.hibernate.BsSkuStoreDao;
import com.trg.oms.utils.dao.OmsMailDao;

public class TestOMSGOODSCH extends TestCase {
	private PoDao poDao;
	private RtvDao rtvDao;
	private BsParaDao bsParaDao;
	private InventoryDao inventoryDao;
	private IvDcInventoryChangeDao ivDcInventoryChangeDao;
	private IvStorageInventoryDao ivStorageInventoryDao;
	private BsSkuDao bsSkuDao;
	private BsSkuStoreDao bsSkuStoreDao;
	private BsSkuSalesSetDao bsSkuSalesSetDao;
	private BsStoreDao bsStoreDao;
	private OmsMailDao omsMailDao;
	
	private OMSGOODSCH goodsCh;
	
	protected void setUp() throws Exception {
		super.setUp();
		poDao = (PoDao)AppContext.getBean("poDao");
		rtvDao = (RtvDao)AppContext.getBean("rtvDao");
		bsParaDao = (BsParaDao)AppContext.getBean("bsParaDao");
		inventoryDao = (InventoryDao)AppContext.getBean("inventoryDao");
		ivDcInventoryChangeDao = (IvDcInventoryChangeDao)AppContext.getBean("ivDcInventoryChangeDao");
		ivStorageInventoryDao = (IvStorageInventoryDao)AppContext.getBean("ivStorageInventoryDao");
		bsSkuDao = (BsSkuDao)AppContext.getBean("bsSkuDao");
		bsSkuStoreDao = (BsSkuStoreDao)AppContext.getBean("bsSkuStoreDao");
		bsSkuSalesSetDao = (BsSkuSalesSetDao)AppContext.getBean("bsSkuSalesSetDao");
		bsStoreDao = (BsStoreDao)AppContext.getBean("bsStoreDao");
		omsMailDao = (OmsMailDao)AppContext.getBean("omsMailDao");
		IvNoidocAllocInventoryDao ivNoidocAllocInventoryDao=(IvNoidocAllocInventoryDao) AppContext.getBean("ivNoidocAllocInventoryDao");
		TransactionTemplate transaction = new TransactionTemplate();
		transaction.setTransactionManager((HibernateTransactionManager)AppContext.getBean("dataSourceTxManager"));
		
		goodsCh = new OMSGOODSCH();
		goodsCh.setPoDao(poDao);
		goodsCh.setStoDao((StoDao)AppContext.getBean("stoDao"));
		goodsCh.setRtvDao(rtvDao);
		goodsCh.setBsParaDao(bsParaDao);
		goodsCh.setBsSkuDao(bsSkuDao);
		goodsCh.setBsSkuStoreDao(bsSkuStoreDao);
		goodsCh.setBsSkuSalesSetDao(bsSkuSalesSetDao);
		goodsCh.setBsStoreDao(bsStoreDao);
		goodsCh.setInventoryDao(inventoryDao);
		goodsCh.setInventoryService((InventoryService)AppContext.getBean("inventoryService"));
		goodsCh.setIvDcInventoryChangeDao(ivDcInventoryChangeDao);
		goodsCh.setIvStorageInventoryDao(ivStorageInventoryDao);
		goodsCh.setTransactionTemplate(transaction);
		goodsCh.setIvNoidocAllocInventoryDao(ivNoidocAllocInventoryDao);
		goodsCh.setOmsMailDao(omsMailDao);
	}
	
	public void testFile() {
		try {
			File file = new File("C:\\OMSqueue\\file\\OMSGOODSCH_201703311529050_1228782.csv");//641，Storage Is Null
			goodsCh.execute(file);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void testBsParaDao() {
		try {
			assertTrue(bsParaDao.hasBsParaData("161", "4600593404" ,""));
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public void test101Po(){
		//測試找不到PO
		assertFalse(goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_101_NoPo.csv")));
		
		//測試非ZP11
		Po oldPo = poDao.loadByPoNo("0000626936");
		oldPo.setPoType("ZP99");
		oldPo.setWhKeeper("300050");
		PoSku oldPoSku = oldPo.getSkuList().get(0);
		oldPoSku.setWhQty(20);
		oldPoSku.setModifier("300050");
		IvStoreInventory oldIvStoreInventory = inventoryDao.getIvStoreInventory(oldPo.getStoreId(), oldPoSku.getSku());
		oldIvStoreInventory.setOnHand(3);
		oldIvStoreInventory.setOnPo(0);
		inventoryDao.updateIvStoreInventory(oldIvStoreInventory);
		poDao.updateObject(oldPo);
		
		goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_101_NoZP11.csv"));
		Po po = poDao.loadByPoNo("0000626936");
		assertEquals("300050", po.getWhKeeper());
		
		PoSku poSku = po.getSkuList().get(0);
		assertEquals(20, poSku.getWhQty().intValue());
		assertEquals("300050", poSku.getModifier());
		
		IvStoreInventory ivStoreInventory = inventoryDao.getIvStoreInventory(po.getStoreId(), poSku.getSku());
		assertEquals(3, ivStoreInventory.getOnHand().intValue());
		assertEquals(0, ivStoreInventory.getOnPo().intValue());
		
		//測試ZP11, status = 3
		oldPo = poDao.loadByPoNo("0000626936");
		oldPo.setPoType("ZP11");
		oldPo.setStatus(3);
		oldPo.setWhKeeper("300050");
		oldPoSku = oldPo.getSkuList().get(0);
		oldPoSku.setWhQty(20);
		oldPoSku.setModifier("300050");
		oldIvStoreInventory = inventoryDao.getIvStoreInventory(oldPo.getStoreId(), oldPoSku.getSku());
		oldIvStoreInventory.setOnHand(3);
		oldIvStoreInventory.setOnPo(0);
		inventoryDao.updateIvStoreInventory(oldIvStoreInventory);
		poDao.updateObject(oldPo);
		
		goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_101_ZP11.csv"));
		
		po = poDao.loadByPoNo("0000626936");
		assertEquals("300050", po.getWhKeeper());
		
		poSku = po.getSkuList().get(0);
		assertEquals(20, poSku.getWhQty().intValue());
		assertEquals("300050", poSku.getModifier());
		
		ivStoreInventory = inventoryDao.getIvStoreInventory(po.getStoreId(), poSku.getSku());
		assertEquals(3, ivStoreInventory.getOnHand().intValue());
		assertEquals(0, ivStoreInventory.getOnPo().intValue());
		
		
		//測試ZP11, status != 3
		oldPo = poDao.loadByPoNo("0000658835");
		oldPo.setPoType("ZP11");
		oldPo.setStatus(1);
		oldPo.setWhKeeper("300050");
		//sku = 000173429
		oldPoSku = oldPo.getSkuList().get(0);
		oldPoSku.setWhQty(19);
		oldPoSku.setModifier("300050");
		oldIvStoreInventory = inventoryDao.getIvStoreInventory(oldPo.getStoreId(), oldPoSku.getSku());
		oldIvStoreInventory.setOnHand(8);
		oldIvStoreInventory.setOnPo(0);
		inventoryDao.updateIvStoreInventory(oldIvStoreInventory);
		//sku = 000280729
		oldPoSku = oldPo.getSkuList().get(1);
		oldPoSku.setWhQty(4);
		oldPoSku.setModifier("300050");
		oldIvStoreInventory = inventoryDao.getIvStoreInventory(oldPo.getStoreId(), oldPoSku.getSku());
		oldIvStoreInventory.setOnHand(2);
		oldIvStoreInventory.setOnPo(0);
		inventoryDao.updateIvStoreInventory(oldIvStoreInventory);
		poDao.updateObject(oldPo);
		
		goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_101_ZP11.csv"));
		
		po = poDao.loadByPoNo("0000658835");
		assertEquals(2, po.getStatus().intValue());
		assertEquals("MW", po.getWhKeeper());
		
		//sku = 000173429
		poSku = po.getSkuList().get(0);
		assertEquals(5, poSku.getWhQty().intValue());
		assertEquals("MW", poSku.getModifier());
		ivStoreInventory = inventoryDao.getIvStoreInventory(po.getStoreId(), poSku.getSku());
		assertEquals(13, ivStoreInventory.getOnHand().intValue());
		assertEquals(-5, ivStoreInventory.getOnPo().intValue());
		
		//sku = 000280729
		poSku = po.getSkuList().get(1);
		assertEquals(7, poSku.getWhQty().intValue());
		assertEquals("MW", poSku.getModifier());
		ivStoreInventory = inventoryDao.getIvStoreInventory(po.getStoreId(), poSku.getSku());
		assertEquals(9, ivStoreInventory.getOnHand().intValue());
		assertEquals(-7, ivStoreInventory.getOnPo().intValue());
	}
	
	public void test102Po(){
		//測試找不到PO
		assertFalse(goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_102_NoPo.csv")));
		
		//測試非ZP11
		Po oldPo = poDao.loadByPoNo("0000619121");
		oldPo.setPoType("ZP99");
		oldPo.setWhKeeper("TLW_TTS_SO");
		PoSku oldPoSku = oldPo.getSkuList().get(0);
		oldPoSku.setWhQty(1);
		oldPoSku.setModifier("TLW_TTS_SO");
		IvStoreInventory oldIvStoreInventory = inventoryDao.getIvStoreInventory(oldPo.getStoreId(), oldPoSku.getSku());
		oldIvStoreInventory.setOnHand(1);
		oldIvStoreInventory.setOnPo(0);
		inventoryDao.updateIvStoreInventory(oldIvStoreInventory);
		poDao.updateObject(oldPo);
		
		goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_102_NoZP11.csv"));
		Po po = poDao.loadByPoNo("0000619121");
		assertEquals("TLW_TTS_SO", po.getWhKeeper());
		
		PoSku poSku = po.getSkuList().get(0);
		assertEquals(1, poSku.getWhQty().intValue());
		assertEquals("TLW_TTS_SO", poSku.getModifier());
		
		IvStoreInventory ivStoreInventory = inventoryDao.getIvStoreInventory(po.getStoreId(), poSku.getSku());
		assertEquals(1, ivStoreInventory.getOnHand().intValue());
		assertEquals(0, ivStoreInventory.getOnPo().intValue());
		
		//測試ZP11, status != 2
		oldPo = poDao.loadByPoNo("0000619121");
		oldPo.setPoType("ZP11");
		oldPo.setStatus(3);
		oldPo.setWhKeeper("TLW_TTS_SO");
		oldPoSku = oldPo.getSkuList().get(0);
		oldPoSku.setWhQty(1);
		oldPoSku.setModifier("TLW_TTS_SO");
		oldIvStoreInventory = inventoryDao.getIvStoreInventory(oldPo.getStoreId(), oldPoSku.getSku());
		oldIvStoreInventory.setOnHand(1);
		oldIvStoreInventory.setOnPo(0);
		inventoryDao.updateIvStoreInventory(oldIvStoreInventory);
		poDao.updateObject(oldPo);
		
		goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_102_ZP11.csv"));
		
		po = poDao.loadByPoNo("0000619121");
		assertEquals("TLW_TTS_SO", po.getWhKeeper());
		
		poSku = po.getSkuList().get(0);
		assertEquals(1, poSku.getWhQty().intValue());
		assertEquals("TLW_TTS_SO", poSku.getModifier());
		
		ivStoreInventory = inventoryDao.getIvStoreInventory(po.getStoreId(), poSku.getSku());
		assertEquals(1, ivStoreInventory.getOnHand().intValue());
		assertEquals(0, ivStoreInventory.getOnPo().intValue());
		
		
		//測試ZP11, status = 2
		oldPo = poDao.loadByPoNo("0000879090");
		oldPo.setPoType("ZP11");
		oldPo.setStatus(2);
		oldPo.setWhKeeper("J00369");
		//sku = 000221410
		oldPoSku = oldPo.getSkuList().get(0);
		oldPoSku.setWhQty(null);
		oldPoSku.setModifier("J00369");
		oldIvStoreInventory = inventoryDao.getIvStoreInventory(oldPo.getStoreId(), oldPoSku.getSku());
		oldIvStoreInventory.setOnHand(0);
		oldIvStoreInventory.setOnPo(0);
		inventoryDao.updateIvStoreInventory(oldIvStoreInventory);
		//sku = 000234165
		oldPoSku = oldPo.getSkuList().get(1);
		oldPoSku.setWhQty(null);
		oldPoSku.setModifier("J00369");
		oldIvStoreInventory = inventoryDao.getIvStoreInventory(oldPo.getStoreId(), oldPoSku.getSku());
		oldIvStoreInventory.setOnHand(0);
		oldIvStoreInventory.setOnPo(0);
		inventoryDao.updateIvStoreInventory(oldIvStoreInventory);
		poDao.updateObject(oldPo);
		
		goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_102_ZP11.csv"));
		
		po = poDao.loadByPoNo("0000879090");
		assertEquals(0, po.getStatus().intValue());
		assertEquals("MW", po.getWhKeeper());
		//sku = 000221410
		poSku = po.getSkuList().get(0);
		assertEquals(-3, poSku.getWhQty().intValue());
		assertEquals("MW", poSku.getModifier());
		ivStoreInventory = inventoryDao.getIvStoreInventory(po.getStoreId(), poSku.getSku());
		assertEquals(-3, ivStoreInventory.getOnHand().intValue());
		assertEquals(3, ivStoreInventory.getOnPo().intValue());
		//sku = 000234165
		poSku = po.getSkuList().get(1);
		assertEquals(-4, poSku.getWhQty().intValue());
		assertEquals("MW", poSku.getModifier());
		ivStoreInventory = inventoryDao.getIvStoreInventory(po.getStoreId(), poSku.getSku());
		assertEquals(-4, ivStoreInventory.getOnHand().intValue());
		assertEquals(4, ivStoreInventory.getOnPo().intValue());
	}
	
	public void test101Wms(){
		//測試找不到TrfRtv
		assertFalse(goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_101_WMS_NoPo.csv")));
		
		//測試WMS, status != 3
		TrfRtv oldTrfRtv = rtvDao.findTrfRtvByFormNo("7100000015");
		oldTrfRtv.setPoType("ZS71");
		oldTrfRtv.setStatus(1);
		oldTrfRtv.setModifier("001019");
		TrfRtvSku oldTrfRtvSku = oldTrfRtv.getTrfRtvSkuList().get(0);
		oldTrfRtvSku.setActQty(null);
		oldTrfRtvSku.setDcQty(null);
		oldTrfRtvSku.setModifier("001019");
		rtvDao.updateObject(oldTrfRtv);
		
		goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_101_WMS_QtyError.csv"));
		
		TrfRtv trfRtv = rtvDao.findTrfRtvByFormNo("7100000015");
		assertEquals(1, trfRtv.getStatus().intValue());
		assertEquals("001019", trfRtv.getModifier());
		
		TrfRtvSku trfRtvSku = trfRtv.getTrfRtvSkuList().get(0);
		assertNull(trfRtvSku.getActQty());
		assertNull(trfRtvSku.getDcQty());
		assertEquals("001019", trfRtvSku.getModifier());
				
		//測試WMS, status = 3, iv_trf_rtv.act_qty < transQty
		oldTrfRtv = rtvDao.findTrfRtvByFormNo("7100000015");
		oldTrfRtv.setPoType("ZS71");
		oldTrfRtv.setStatus(3);
		oldTrfRtv.setModifier("001019");
		oldTrfRtvSku = oldTrfRtv.getTrfRtvSkuList().get(0);
		oldTrfRtvSku.setActQty(null);
		oldTrfRtvSku.setDcQty(null);
		oldTrfRtvSku.setModifier("001019");
		rtvDao.updateObject(oldTrfRtv);
		
		goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_101_WMS_QtyError.csv"));
		
		trfRtv = rtvDao.findTrfRtvByFormNo("7100000015");
		assertEquals(3, trfRtv.getStatus().intValue());
		assertEquals("001019", trfRtv.getModifier());
		
		trfRtvSku = trfRtv.getTrfRtvSkuList().get(0);
		assertNull(trfRtvSku.getActQty());
		assertNull(trfRtvSku.getDcQty());
		assertEquals("001019", trfRtvSku.getModifier());
		
		
		//測試WMS, status = 3, iv_trf_rtv.act_qty > transQty
		oldTrfRtv = rtvDao.findTrfRtvByFormNo("7100000015");
		oldTrfRtv.setPoType("ZS71");
		oldTrfRtv.setStatus(3);
		oldTrfRtv.setModifier("001019");
		oldTrfRtvSku = oldTrfRtv.getTrfRtvSkuList().get(0);
		oldTrfRtvSku.setActQty(10);
		oldTrfRtvSku.setDcQty(null);
		oldTrfRtvSku.setModifier("001019");
		rtvDao.updateObject(oldTrfRtv);
		
		goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_101_WMS_Success.csv"));
		
		trfRtv = rtvDao.findTrfRtvByFormNo("7100000015");
		assertEquals(4, trfRtv.getStatus().intValue());
		assertEquals("MW", trfRtv.getModifier());
		
		trfRtvSku = trfRtv.getTrfRtvSkuList().get(0);
		assertEquals(10, trfRtvSku.getActQty().intValue());
		assertEquals(2, trfRtvSku.getDcQty().intValue());
		assertEquals("MW", trfRtvSku.getModifier());
	}
	
	public void test102Wms(){
		//測試找不到TrfRtv
		assertTrue(goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_102_WMS_NoPo.csv")));
		
		//測試WMS, status != 4
		TrfRtv oldTrfRtv = rtvDao.findTrfRtvByFormNo("7100000106");
		oldTrfRtv.setPoType("ZS71");
		oldTrfRtv.setStatus(1);
		oldTrfRtv.setModifier("400593");
		TrfRtvSku oldTrfRtvSku = oldTrfRtv.getTrfRtvSkuList().get(0);
		oldTrfRtvSku.setActQty(null);
		oldTrfRtvSku.setDcQty(null);
		oldTrfRtvSku.setModifier("400593");
		rtvDao.updateObject(oldTrfRtv);
		
		goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_102_WMS_QtyError.csv"));
		
		TrfRtv trfRtv = rtvDao.findTrfRtvByFormNo("7100000106");
		assertEquals(1, trfRtv.getStatus().intValue());
		assertEquals("400593", trfRtv.getModifier());
		
		TrfRtvSku trfRtvSku = trfRtv.getTrfRtvSkuList().get(0);
		assertNull(trfRtvSku.getActQty());
		assertNull(trfRtvSku.getDcQty());
		assertEquals("400593", trfRtvSku.getModifier());
				
		//測試WMS, status = 4
		oldTrfRtv = rtvDao.findTrfRtvByFormNo("7100000106");
		oldTrfRtv.setPoType("ZS71");
		oldTrfRtv.setStatus(4);
		oldTrfRtv.setModifier("400593");
		oldTrfRtvSku = oldTrfRtv.getTrfRtvSkuList().get(0);
		oldTrfRtvSku.setActQty(null);
		oldTrfRtvSku.setDcQty(null);
		oldTrfRtvSku.setModifier("400593");
		rtvDao.updateObject(oldTrfRtv);
		
		goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_102_WMS_QtyError.csv"));
		
		trfRtv = rtvDao.findTrfRtvByFormNo("7100000106");
		assertEquals(3, trfRtv.getStatus().intValue());
		assertEquals("MW", trfRtv.getModifier());
		
		trfRtvSku = trfRtv.getTrfRtvSkuList().get(0);
		assertEquals(0, trfRtvSku.getDcQty().intValue());
		assertEquals("MW", trfRtvSku.getModifier());
	}
	
	public void test161CB(){
		//測試找不到PoRtv
		assertTrue(goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_161_NoRtv.csv")));
		
		//測試非ZR11
		PoRtv oldPoRtv = rtvDao.findPoRtvByFormNo("4600000003");
		oldPoRtv.setPoType("ZR06");
		oldPoRtv.setModifier("701451");
		PoRtvSku oldPoRtvSku = oldPoRtv.getPoRtvSkuList().get(0);
		oldPoRtvSku.setActQty(null);
		oldPoRtvSku.setModifier("701420");
		IvStoreInventory oldIvStoreInventory = inventoryDao.getIvStoreInventory(oldPoRtv.getStoreId(), oldPoRtvSku.getSku());
		oldIvStoreInventory.setOnHand(20);
		oldIvStoreInventory.setOnRtv(1);
		inventoryDao.updateIvStoreInventory(oldIvStoreInventory);
		rtvDao.updateObject(oldPoRtv);
		
		goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_161_NoZR11.csv"));
		PoRtv poRtv = rtvDao.findPoRtvByFormNo("4600000003");
		assertEquals("701451", poRtv.getModifier());
		
		PoRtvSku poRtvSku = poRtv.getPoRtvSkuList().get(0);
		assertNull(poRtvSku.getActQty());
		assertEquals("701420", poRtvSku.getModifier());
		
		IvStoreInventory ivStoreInventory = inventoryDao.getIvStoreInventory(poRtv.getStoreId(), poRtvSku.getSku());
		assertEquals(20, ivStoreInventory.getOnHand().intValue());
		assertEquals(1, ivStoreInventory.getOnRtv().intValue());
		
		//測試ZR11, status = 4
		oldPoRtv = rtvDao.findPoRtvByFormNo("4600006327");
		oldPoRtv.setPoType("ZR11");
		oldPoRtv.setStatus(4);
		oldPoRtv.setModifier("701451");
		oldPoRtvSku = oldPoRtv.getPoRtvSkuList().get(0);
		oldPoRtvSku.setActQty(null);
		oldPoRtvSku.setModifier("701420");
		oldIvStoreInventory = inventoryDao.getIvStoreInventory(oldPoRtv.getStoreId(), oldPoRtvSku.getSku());
		oldIvStoreInventory.setOnHand(20);
		oldIvStoreInventory.setOnRtv(1);
		inventoryDao.updateIvStoreInventory(oldIvStoreInventory);
		rtvDao.updateObject(oldPoRtv);
		
		goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_161_ZR11.csv"));
		
		poRtv = rtvDao.findPoRtvByFormNo("4600006327");
		assertEquals("701451", poRtv.getModifier());
		
		poRtvSku = poRtv.getPoRtvSkuList().get(0);
		assertNull(poRtvSku.getActQty());
		assertEquals("701420", poRtvSku.getModifier());
		
		ivStoreInventory = inventoryDao.getIvStoreInventory(poRtv.getStoreId(), poRtvSku.getSku());
		assertEquals(20, ivStoreInventory.getOnHand().intValue());
		assertEquals(1, ivStoreInventory.getOnRtv().intValue());
		
		
		//測試ZR11, status != 4
		oldPoRtv = rtvDao.findPoRtvByFormNo("4600006327");
		oldPoRtv.setPoType("ZR11");
		oldPoRtv.setStatus(1);
		oldPoRtv.setModifier("701400");
		//sku = 000197564
		oldPoRtvSku = oldPoRtv.getPoRtvSkuList().get(0);
		oldPoRtvSku.setActQty(1);
		oldPoRtvSku.setModifier("701392");
		oldIvStoreInventory = inventoryDao.getIvStoreInventory(oldPoRtv.getStoreId(), oldPoRtvSku.getSku());
		oldIvStoreInventory.setOnHand(21);
		oldIvStoreInventory.setOnRtv(4);
		inventoryDao.updateIvStoreInventory(oldIvStoreInventory);
		//sku = 000232754
		oldPoRtvSku = oldPoRtv.getPoRtvSkuList().get(1);
		oldPoRtvSku.setActQty(1);
		oldPoRtvSku.setModifier("701392");
		oldIvStoreInventory = inventoryDao.getIvStoreInventory(oldPoRtv.getStoreId(), oldPoRtvSku.getSku());
		oldIvStoreInventory.setOnHand(10);
		oldIvStoreInventory.setOnRtv(10);
		inventoryDao.updateIvStoreInventory(oldIvStoreInventory);
		rtvDao.updateObject(oldPoRtv);
		
		goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_161_ZR11.csv"));
		
		poRtv = rtvDao.findPoRtvByFormNo("4600006327");
		assertEquals(3, poRtv.getStatus().intValue());
		assertEquals("MW", poRtv.getModifier());
		//sku = 000197564
		poRtvSku = poRtv.getPoRtvSkuList().get(0);
		assertEquals(4, poRtvSku.getActQty().intValue());
		assertEquals("MW", poRtvSku.getModifier());
		ivStoreInventory = inventoryDao.getIvStoreInventory(poRtv.getStoreId(), poRtvSku.getSku());
		assertEquals(17, ivStoreInventory.getOnHand().intValue());
		assertEquals(0, ivStoreInventory.getOnRtv().intValue());
		IvStoreInventoryChange ivStoreInventoryChange = findIvStoreInventoryChange(poRtv.getStoreId(), poRtvSku.getSku(), DateUtils.getDate("2012/08/31"));
		assertEquals(-4, ivStoreInventoryChange.getTxnQty().intValue());
		
		//sku = 000232754
		poRtvSku = poRtv.getPoRtvSkuList().get(1);
		assertEquals(5, poRtvSku.getActQty().intValue());
		assertEquals("MW", poRtvSku.getModifier());
		ivStoreInventory = inventoryDao.getIvStoreInventory(poRtv.getStoreId(), poRtvSku.getSku());
		assertEquals(5, ivStoreInventory.getOnHand().intValue());
		assertEquals(5, ivStoreInventory.getOnRtv().intValue());
		ivStoreInventoryChange = findIvStoreInventoryChange(poRtv.getStoreId(), poRtvSku.getSku(), DateUtils.getDate("2012/08/31"));
		assertEquals(-5, ivStoreInventoryChange.getTxnQty().intValue());
	}
	
	public void test162CB(){
		//測試找不到PoRtv
		assertTrue(goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_162_NoRtv.csv")));
		
		//測試非ZR11
		PoRtv oldPoRtv = rtvDao.findPoRtvByFormNo("4600000529");
		oldPoRtv.setPoType("ZR06");
		oldPoRtv.setModifier("600169");
		PoRtvSku oldPoRtvSku = oldPoRtv.getPoRtvSkuList().get(0);
		oldPoRtvSku.setActQty(1);
		oldPoRtvSku.setModifier("600413");
		IvStoreInventory oldIvStoreInventory = inventoryDao.getIvStoreInventory(oldPoRtv.getStoreId(), oldPoRtvSku.getSku());
		oldIvStoreInventory.setOnHand(37);
		oldIvStoreInventory.setOnRtv(0);
		inventoryDao.updateIvStoreInventory(oldIvStoreInventory);
		rtvDao.updateObject(oldPoRtv);
		
		goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_162_NoZR11.csv"));
		PoRtv poRtv = rtvDao.findPoRtvByFormNo("4600000529");
		assertEquals("600169", poRtv.getModifier());
		
		PoRtvSku poRtvSku = poRtv.getPoRtvSkuList().get(0);
		assertEquals(1, poRtvSku.getActQty().intValue());
		assertEquals("600413", poRtvSku.getModifier());
		
		IvStoreInventory ivStoreInventory = inventoryDao.getIvStoreInventory(poRtv.getStoreId(), poRtvSku.getSku());
		assertEquals(37, ivStoreInventory.getOnHand().intValue());
		assertEquals(0, ivStoreInventory.getOnRtv().intValue());
		
		//測試ZR11, status != 3
		oldPoRtv = rtvDao.findPoRtvByFormNo("4600000870");
		oldPoRtv.setPoType("ZR11");
		oldPoRtv.setStatus(4);
		oldPoRtv.setModifier("600169");
		oldPoRtvSku = oldPoRtv.getPoRtvSkuList().get(0);
		oldPoRtvSku.setActQty(1);
		oldPoRtvSku.setModifier("600413");
		oldIvStoreInventory = inventoryDao.getIvStoreInventory(oldPoRtv.getStoreId(), oldPoRtvSku.getSku());
		oldIvStoreInventory.setOnHand(37);
		oldIvStoreInventory.setOnRtv(0);
		inventoryDao.updateIvStoreInventory(oldIvStoreInventory);
		rtvDao.updateObject(oldPoRtv);
		
		goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_162_ZR11.csv"));
		
		poRtv = rtvDao.findPoRtvByFormNo("4600000870");
		assertEquals("600169", poRtv.getModifier());
		
		poRtvSku = poRtv.getPoRtvSkuList().get(0);
		assertEquals(1, poRtvSku.getActQty().intValue());
		assertEquals("600413", poRtvSku.getModifier());
		
		ivStoreInventory = inventoryDao.getIvStoreInventory(poRtv.getStoreId(), poRtvSku.getSku());
		assertEquals(37, ivStoreInventory.getOnHand().intValue());
		assertEquals(0, ivStoreInventory.getOnRtv().intValue());
		
		
		//測試ZR11, status = 3
		oldPoRtv = rtvDao.findPoRtvByFormNo("4600000870");
		oldPoRtv.setPoType("ZR11");
		oldPoRtv.setStatus(3);
		oldPoRtv.setModifier("600169");
		//sku = 000307199
		oldPoRtvSku = oldPoRtv.getPoRtvSkuList().get(0);
		oldPoRtvSku.setActQty(1);
		oldPoRtvSku.setModifier("600096");
		oldIvStoreInventory = inventoryDao.getIvStoreInventory(oldPoRtv.getStoreId(), oldPoRtvSku.getSku());
		oldIvStoreInventory.setOnHand(21);
		oldIvStoreInventory.setOnRtv(0);
		inventoryDao.updateIvStoreInventory(oldIvStoreInventory);
		//sku = 000307201
		oldPoRtvSku = oldPoRtv.getPoRtvSkuList().get(1);
		oldPoRtvSku.setActQty(2);
		oldPoRtvSku.setModifier("600096");
		oldIvStoreInventory = inventoryDao.getIvStoreInventory(oldPoRtv.getStoreId(), oldPoRtvSku.getSku());
		oldIvStoreInventory.setOnHand(1);
		oldIvStoreInventory.setOnRtv(0);
		inventoryDao.updateIvStoreInventory(oldIvStoreInventory);
		rtvDao.updateObject(oldPoRtv);
		
		goodsCh.execute(new File("C:\\OMS_TEST\\OMSGOODSCH_162_ZR11.csv"));
		
		poRtv = rtvDao.findPoRtvByFormNo("4600000870");
		assertEquals(1, poRtv.getStatus().intValue());
		assertEquals("MW", poRtv.getModifier());
		//sku = 000307199
		poRtvSku = poRtv.getPoRtvSkuList().get(0);
		assertEquals(-5, poRtvSku.getActQty().intValue());
		assertEquals("MW", poRtvSku.getModifier());
		ivStoreInventory = inventoryDao.getIvStoreInventory(poRtv.getStoreId(), poRtvSku.getSku());
		assertEquals(27, ivStoreInventory.getOnHand().intValue());
		assertEquals(6, ivStoreInventory.getOnRtv().intValue());
		IvStoreInventoryChange ivStoreInventoryChange = findIvStoreInventoryChange(poRtv.getStoreId(), poRtvSku.getSku(), DateUtils.getDate("2012/08/31"));
		assertEquals(6, ivStoreInventoryChange.getTxnQty().intValue());
		//sku = 000307201
		poRtvSku = poRtv.getPoRtvSkuList().get(1);
		assertEquals(-5, poRtvSku.getActQty().intValue());
		assertEquals("MW", poRtvSku.getModifier());
		ivStoreInventory = inventoryDao.getIvStoreInventory(poRtv.getStoreId(), poRtvSku.getSku());
		assertEquals(8, ivStoreInventory.getOnHand().intValue());
		assertEquals(7, ivStoreInventory.getOnRtv().intValue());
		ivStoreInventoryChange = findIvStoreInventoryChange(poRtv.getStoreId(), poRtvSku.getSku(), DateUtils.getDate("2012/08/31"));
		assertEquals(7, ivStoreInventoryChange.getTxnQty().intValue());
	}
	
	private IvStoreInventoryChange findIvStoreInventoryChange(String storeId, String sku, Date txnDate) {
		Session session = null;
		IvStoreInventoryChange result = null;
		try {
			session = inventoryDao.getSessionFactory().openSession();
			String hql = "from IvStoreInventoryChange where storeId = :storeId and sku = :sku and txnDate = :txnDate";
			Query query = session.createQuery(hql);
			query.setString("storeId", storeId);
			query.setString("sku", sku);
			query.setDate("txnDate", txnDate);
			result = (IvStoreInventoryChange)query.uniqueResult();
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return result;
	}
}
