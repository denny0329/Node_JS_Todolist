package unittest.inBound;

import com.bnq.util.AppContext;
import com.rfep.dataex.mw.inbound.OMSAUTOINV;
import junit.framework.TestCase;

import java.io.File;

public class TestOMSAUTOINV extends TestCase {

    private OMSAUTOINV omsAutoInv;

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        omsAutoInv = (OMSAUTOINV) AppContext.getBean("OMSAUTOINV");
    }

    public void testOMSAUTOINV() {
        try {
            String path = this.getClass().getResource("").getPath() + "file" + File.separator + "TestOMSAUTOINV_01.csv";
            File file = new File(path.substring(1));
            omsAutoInv.execute(file);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
