/**
 * @(#) TestOMSDYSALES.java 2016/6/17
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest.inBound;

import java.io.File;

import com.trg.oms.dataex.inbound.OMSDYSALES;

import junit.framework.TestCase;

/**
 * @author T2482
 */
public class TestOMSDYSALES extends TestCase {
	private OMSDYSALES omsdysales = new OMSDYSALES();

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
	}

	public void testCase01() {
		try {
			//String path = this.getClass().getResource("").getPath() + "file" + File.separator + "TestOMSDYSALES_CASE01.csv";
			//File file = new File(path.substring(1));
		    File file = new File("C:\\oradata\\OMSDYSALES_201711291211950_1211760.csv");  //OMSDYSALES_201711291211963_1211760
			omsdysales.execute(file);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
