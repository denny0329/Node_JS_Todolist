package unittest;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.bnq.util.DateTimeUtils;
import com.bnq.util.ftp.FileUtils;
import com.bnq.util.sale.model.SaleDetail;
import com.bnq.util.sale.model.SaleMaster;
import com.bnq.util.sale.service.SaleService;
import com.gccs.bonus.condition.BonusCondition;
import com.gccs.ev.model.Activity;
import com.gccs.ev.service.EvService;
import com.gccs.util.cache.BsStoreDefinition;
import com.rfep.trans.dao.hibernate.TransDao;
import com.rfep.trans.model.trans.TransInfo;
import com.rfep.trans.model.trans.TransMaster;
import com.rfep.trans.model.trans.TransSale;
import com.rfep.trans.model.trans.TransSku;
import com.rfep.trans.model.trans.TransSoSku;
import com.rfep.trans.service.TransService;
import com.rfep.trans.util.TransInfoGlossary;
import com.rfep.valuation.model.vo.SkuVO;

public class TestSale extends TestCase {
	public void testSplit() {
		String eventStr = "";
		String[] array = eventStr.split(",");
		for(int i=0; i<array.length; i++) {
			System.err.println(array[i]);
		}
	}
	 
	public void testSaleValidator() {
		List<SkuVO> skuList = this.createSkuList();
		
//		BaseInfoVO baseInfo = new BaseInfoVO();
//		baseInfo.setChannelId("TLW");
//		baseInfo.setStoreId("00700");
//		baseInfo.setSaleTotal(1000);
//		baseInfo.setTransDate(DateTimeUtils.getDate("2010/8/5"));
//		baseInfo.setTransTime("11:10");
//		baseInfo.setSaleSource(null);
//		
//		TransVO transVO = new TransVO();
//		transVO.setBaseInfo(baseInfo);
//		transVO.setSkuList(skuList);
//		
//		ValuateService service = new ValuateService();
//		service.recombinationSku(transVO);
//		
//		for(SkuVO sku : transVO.getSkuList()) {
//			System.err.println("-------------------");
//			System.err.println("條碼 : "+sku.getUpc());
//			System.err.println("商品編號 : "+sku.getSkuNos()+", item ser : "+sku.getItemSer()+" 數量 : "+sku.getQty());
//			System.err.println("一般售價 : "+sku.getFixedPrice()+" POS售價 : "+sku.getPosPrice()+" 實際售價 : "+sku.getAmtPrice());
////			System.err.println("是否為促銷商品 : "+sku.getActivitySku());
//			System.err.println("小計 : "+sku.getSaleTotal());
//		}
//		
//		EvService eService = (EvService)AppContext.getBean("evService");
//		List activityList = eService.findActivityByDate(DateTimeUtils.getDate("2010/8/2"));
//		for(Iterator iter = activityList.iterator(); iter.hasNext(); ) {
//			Activity act = (Activity)iter.next();
//			System.err.println("----------------");
//			System.err.println("activity name :"+act.getActivityName());
//			boolean result = SaleValidatorUtils.guiConditionValidator(act, transVO);
//			System.err.println("validate result : "+result);
//		}
		
	}
	
	public void testSelect() throws Exception {
		TransDao dao = (TransDao)AppContext.getBean("transDao");
		dao.findTransChange(null, 0, 0, true);
	}
	
	public void testTime() throws Exception {
		Date actHoursFrom = DateTimeUtils.getDateFormat("10:00", "HH:mm");
		Date actHoursTo = DateTimeUtils.getDateFormat("14:00", "HH:mm");
		Date actHours = DateTimeUtils.getDateFormat("14:01", "HH:mm");
		System.err.println(actHoursFrom);
		System.err.println(actHoursTo);
		System.err.println(actHours);
		System.err.println("actHoursFrom compare actHours : "+(actHours.compareTo(actHoursFrom)));
		System.err.println("actHoursTo compare actHours : "+(actHours.compareTo(actHoursTo)));
		int compareFrom = actHours.compareTo(actHoursFrom);
		int compareTo = actHours.compareTo(actHoursTo);
		System.err.println(compareFrom>=0);
		System.err.println(compareTo<=0);
	}
	
	public void testSaleValidator2() {
		EvService eService = (EvService)AppContext.getBean("evService");
		List activityList = eService.findActivityByDate(DateTimeUtils.getDate("2010/8/2"));
		for(Iterator iter = activityList.iterator(); iter.hasNext(); ) {
			Activity act = (Activity)iter.next();
			System.err.println("----------------");
			System.err.println("activity name :"+act.getActivityName());
		
//			act.getActStoreList();
//			List memberConditionList = act.getMemberConditionList();
//			for(Iterator subIter = memberConditionList.iterator(); subIter.hasNext(); ) {
//				//會員條件
//			}
//			List guiConditionList = act.getGuiConditionList();
//			for(Iterator subIter = guiConditionList.iterator(); subIter.hasNext(); ) {
//				//消費條件
//			}
//			List discSkuList = act.getDiscSkuList();
//			for(Iterator subIter = discSkuList.iterator(); subIter.hasNext(); ) {
//				//負項商品
//			}
//			List guiSkuList = act.getGuiSkuList();
//			for(Iterator subIter = guiSkuList.iterator(); subIter.hasNext(); ) {
//				//條件商品
//			}
//			
//			//促銷
//			if(act.getSellType().intValue() == ActivityGlossary.SELL_TYPE_STAMP) {
//				//sell type 1
//				List promotionSkuList = act.getPromotionSkuList();
//				for(Iterator subIter = promotionSkuList.iterator(); subIter.hasNext(); ) {
//					//促銷商品
//				}
//			} else {
//				List guiamtList = act.getGuiamtList();
//				for(Iterator subIter = guiamtList.iterator(); subIter.hasNext(); ) {
//					Guiamt guiamt = (Guiamt) subIter.next();
//					if(act.getSellType().intValue() == ActivityGlossary.SELL_TYPE_PRICE_DISCOUNT) {
//						//sell type 3
//						PromotionSku sku = guiamt.getPromotionSku();
//						List guiamtQtyList = sku.getGuiamtQtyList();
//						for(Iterator subIter2 = guiamtQtyList.iterator(); subIter2.hasNext(); ) {
//							GuiamtQty qty = (GuiamtQty)subIter2.next();
//						}
//					} else {
//						//sell type 2 4
//						List promotionSkuList = guiamt.getPromotionSkuList();
//						for(Iterator subIter2 = promotionSkuList.iterator(); subIter2.hasNext(); ) {
//							PromotionSku sku = (PromotionSku)subIter2.next();
//						}
//					}
//				}
//				
//			}
			
		}
		//SaleValidatorUtils;
	}
	
	
	public void testRejectionMst() {
		TransService tService = (TransService)AppContext.getBean("transService");
		
	}
	
	public void testTranMst() throws Exception {
		SaleService service = (SaleService)AppContext.getBean("saleService") ;
		TransService tService = (TransService)AppContext.getBean("transService");
		BonusCondition condition = new BonusCondition();
		condition.setStoreNo("00900");
		condition.setTransDate(DateTimeUtils.getDate("2010/8/1"));
		condition.setSaleType("N");
		condition.setSaleSta("N");
		List mList = service.getSaleMasterListByTransDate(condition, 0, 9999);
		for(Iterator iter = mList.iterator(); iter.hasNext(); ) {
			SaleMaster master = (SaleMaster)iter.next();
			System.err.println(master.getStore_no());
			System.err.println(master.getTrans_dat());
			System.err.println(master.getPos_nos());
			System.err.println(master.getSer_nos());
			
			TransInfo i = this.createInfo(master, master.getSer_nos());
			TransSale s = this.createSale(master, master.getSer_nos());
			TransMaster m = this.createMaster(master, master.getSer_nos());
			
			m.setTransSale(s);
			s.getTransMaster().add(m);
			s.setTransInfo(i);
			i.getTransSale().add(s);
			
			List skuList = service.getSaleDetailListByMasterPk(master);
			for(Iterator iterator = skuList.iterator(); iterator.hasNext(); ) {
				SaleDetail detail = (SaleDetail)iterator.next();
				TransSku sku = this.createSku(detail);
				sku.setTransMaster(m);
				m.getTransSku().add(sku);
			}
			tService.getDao().insertObject(i);
		}
		
		
	}
	
	
	private TransSku createSku(SaleDetail d) {
		TransSku sku = new TransSku();
		sku.setChannelId(BsStoreDefinition.getChannelIdByStoreNo(d.getStore_no()));
		sku.setStoreId(d.getStore_no());
		sku.setTransDate(d.getTrans_dat());
		sku.setPosNos(d.getPos_nos());
		sku.setSerNos(Integer.parseInt(d.getSer_nos()));
		sku.setItemSer(Integer.parseInt(d.getItem_ser()));
		sku.setSkuSaleType(TransInfoGlossary._sku_trans_type_sale);
		sku.setSkuNos(d.getSku_nos());
		sku.setOldSkuNos(d.getSku_nos());
		sku.setUpc(d.getItem_nos());
		sku.setSkuName(d.getSku_desc());
		sku.setTaxType(1);
		
		sku.setTransQty(d.getTrans_qty());
		sku.setBaseQty(d.getTrans_qty());
		
		sku.setTransUnit("個");
		sku.setBaseUnit("個");
		
		sku.setFixedPrice(new BigDecimal(d.getReg_amt()).intValue());
		sku.setBaseFixedPrice(new BigDecimal(d.getReg_amt()).intValue());
		
		sku.setPosPrice(new BigDecimal(d.getPos_amt()).intValue());
		sku.setBasePosPrice(new BigDecimal(d.getPos_amt()).intValue());
		
		sku.setStampPrice(new Integer(0));
		sku.setBaseStampPrice(new Integer(0));
		
		sku.setAmtPrice(d.getActual_amt());
		sku.setBaseAmtPrice(d.getActual_amt());
		
		BigDecimal baseAmtPrice = new BigDecimal(String.valueOf(d.getActual_amt()));
		BigDecimal result = baseAmtPrice.multiply(new BigDecimal(String.valueOf(d.getTrans_qty())));
		
		BigDecimal posPrice = new BigDecimal(String.valueOf(sku.getPosPrice()));
		BigDecimal amtPrice = new BigDecimal(String.valueOf(sku.getAmtPrice()));
		BigDecimal qty = new BigDecimal(String.valueOf(sku.getTransQty()));
		
		
		sku.setSaleTotal(result.setScale(0, BigDecimal.ROUND_HALF_UP).intValue());
		BigDecimal discount = posPrice.subtract(amtPrice).multiply(qty);
		sku.setDiscount(discount.setScale(0, BigDecimal.ROUND_HALF_UP).intValue());
		sku.setDeptId(d.getDept_code());
		sku.setSubdeptId(d.getSdept_code());
		sku.setClassId(d.getClas_code());
		sku.setSubclassId(d.getSclas_code());
		sku.setVendorId(d.getVendor_id());
		sku.setInputPriceFlag("N");
		
		sku.setCreateTime(new Date());
		sku.setCreator("SYS");
		sku.setCreatorName("SYS");
		sku.setModifyTime(new Date());
		sku.setModifier("SYS");
		sku.setModifierName("SYS");
		return sku;
	}
	
	private TransInfo createInfo(SaleMaster s, String seqNo) throws Exception {
		TransInfo b = new TransInfo();
		b.setChannelId(BsStoreDefinition.getChannelIdByStoreNo(s.getStore_no()));
		b.setStoreId(s.getStore_no());
		b.setTransDate(s.getTrans_dat());
		b.setSaleNos(this.createSaleNos(s, seqNo));
		
		System.err.println(b.getChannelId());
		System.err.println(b.getStoreId());
		System.err.println(b.getTransDate());
		System.err.println(b.getSaleNos());
		
		b.setCreateTime(new Date());
		b.setCreator("SYS");
		b.setCreatorName("SYS");
		b.setModifyTime(new Date());
		b.setModifier("SYS");
		b.setModifierName("SYS");
		return b;
	}
	
	private TransSale createSale(SaleMaster s, String seqNo) throws Exception {
		TransSale b = new TransSale();
		b.setChannelId(BsStoreDefinition.getChannelIdByStoreNo(s.getStore_no()));
		b.setStoreId(s.getStore_no());
		b.setTransDate(s.getTrans_dat());
		b.setSaleSer(1);
		b.setSaleType(s.getSale_type());
		b.setSaleNos(this.createSaleNos(s, seqNo));
		
//		System.err.println(b.getChannelId());
//		System.err.println(b.getStoreId());
//		System.err.println(b.getTransDate());
//		System.err.println(b.getSaleNos());
		
		b.setCreateTime(new Date());
		b.setCreator("SYS");
		b.setCreatorName("SYS");
		b.setModifyTime(new Date());
		b.setModifier("SYS");
		b.setModifierName("SYS");
		return b;
	}
	
	private String createSaleNos(SaleMaster s, String seqNo) throws Exception {
		StringBuffer sb = new StringBuffer();
		sb.append(BsStoreDefinition.getChannelIdByStoreNo(s.getStore_no()))
			.append(s.getStore_no())
			.append(DateTimeUtils.getFormatDateStr(s.getTrans_dat(), "yyyyMMdd"))
			.append(s.getPos_nos())
			.append(seqNo);
		return sb.toString();
	}
	
	private TransMaster createMaster(SaleMaster s, String seqNo) throws Exception {
		TransMaster t = new TransMaster();
		t.setChannelId(BsStoreDefinition.getChannelIdByStoreNo(s.getStore_no()));
		t.setStoreId(s.getStore_no());
		t.setTransDate(s.getTrans_dat());
		t.setPosNos(s.getPos_nos());
		t.setSerNos(Integer.parseInt(s.getSer_nos()));
		StringBuffer sb = new StringBuffer();
		sb.append(FileUtils.stringPad(String.valueOf(new java.util.Random().nextInt(24)), 2, true));
		sb.append(":");
		sb.append(FileUtils.stringPad(String.valueOf(new java.util.Random().nextInt(60)), 2, true));
		sb.append(":");
		sb.append(FileUtils.stringPad(String.valueOf(new java.util.Random().nextInt(60)), 2, true));
		t.setTransTime(sb.toString());
		t.setSaleNos(this.createSaleNos(s, seqNo));
		t.setSaleType(s.getSale_type());
		t.setSaleStatus(s.getSale_sta());
		t.setGuiNos(s.getGui_nos());
		t.setTaxFlag(TransInfoGlossary._tax_type_normal);
		BigDecimal total = new BigDecimal(String.valueOf(s.getTrans_tot()));
		BigDecimal result = total.divide(new BigDecimal("1.05"),  0, BigDecimal.ROUND_HALF_UP);
		t.setTaxTotal(s.getTrans_tot() - result.doubleValue());
		t.setTransTotal(new BigDecimal(s.getTrans_tot()).setScale(0, BigDecimal.ROUND_HALF_UP).intValue());
		t.setVipNo(s.getCust_nos());
		
		t.setSaleEmpId("H111111");
		t.setSaleEmpName("H111111");
		t.setClassNo("001");
		t.setOptEmpId("H111111");
		t.setOptEmpName("H111111");
		t.setCancelDate(s.getCancel_dat());
		t.setCreateTime(new Date());
		t.setCreator("SYS");
		t.setCreatorName("SYS");
		t.setModifyTime(new Date());
		t.setModifier("SYS");
		t.setModifierName("SYS");

		return t;
	}
	
	public static Activity[][] perm(Activity[] acts, int i) {
		int n = 1;
		for(int c=1; c<acts.length; c++) {
			n = n*c;
		}
		Activity[][] ret = new Activity[n][acts.length - 1];
        if(i < acts.length - 1) { 
            for(int j = i; j <= acts.length - 1; j++) {
                //int tmp = num[j];
//            	System.err.println("i :"+i);
//            	System.err.println("j :"+j);
            	Activity act = acts[j];
                // 旋轉該區段最右邊數字至最左邊 
                for(int k = j; k > i; k--) {
//                	System.err.println("k :"+k);
                	acts[k] = acts[k-1]; 
                }
                acts[i] = act; 
                Activity[][] obj = perm(acts, i+1);
//               
//                System.err.println("obj is null : "+(obj==null));
                if(obj!=null&&obj[0][0]!=null) {
                	for(int a=0; a<ret.length; a++) {
                		boolean check = false;
                		for(int b=0; b<ret[a].length; b++) {
	                    	if(ret[a][b]==null) {
//	                    		System.err.println("---------- " +obj[0][b].getActivityId());
	                    		ret[a][b] = obj[0][b];
	                    		check = true;
	                    	} else {
	                    		break;
	                    	}
                		}
                		if(check)
                			break;
                    }
                }
                
//                if(obj!=null)
//                	System.err.println("obj[0][0] is null : "+(obj[0][0]==null));
                // 還原 
                for(int k = i; k < j; k++) 
                	acts[k] = acts[k+1]; 
                acts[j] = act; 
                
            } 
        } else {  // 顯示此次排列
        	Activity[][] activity = new Activity[1][acts.length - 1];
            for(int j = 1; j <= acts.length - 1; j++) {
//                System.err.print(acts[j].getActivityId() + " ");
                activity[0][j-1] = acts[j];
            }
            System.err.println();
            return activity;
//            System.out.println("-----");
        }
        return ret;
    }

    public static void main(String[] args) {
    	Activity[] acts = new Activity[3+1]; 
    	Activity act1 = new Activity();
    	act1.setActivityId("001");
    	Activity act2 = new Activity();
    	act2.setActivityId("002");
    	Activity act3 = new Activity();
    	act3.setActivityId("003");
    	Activity act4 = new Activity();
//    	act4.setActivityId("004");
    	acts[1] = act1;
    	acts[2] = act2;
    	acts[3] = act3;
//    	acts[4] = act4;
//        for(int i = 1; i <= num.length - 1; i++) 
//            num[i] = i; 

        Activity[][] act = perm(acts, 1);
        for(int i=0; i<act.length; i++) {
        	for(int j=0; j<act[i].length; j++) {
        		System.err.print(act[i][j].getActivityId()+" ");
        	}
        	System.err.println("----------");
        }
//        System.err.println(list.size());
//        for(Activity[] act:list) {
//        	for(int i=0; i<act.length; i++) {
//        		System.err.println(">>>>>");
//        		System.err.println(act[i].getActivityId()+" ");
//        		System.err.println(">>>>>");
//        	}
//        }
    }
    
    private SkuVO createSku(String upc, String skuNos, Integer qty, Integer fixedPrice, Integer posPrice, Boolean storeDiscount) {
		SkuVO sku = new SkuVO();
		sku.setChannelId("TLW");
		sku.setUpc(upc);
		sku.setSkuNos(skuNos);
//		sku.setStoreDiscount(storeDiscount);
		sku.setFixedPrice(fixedPrice);
		sku.setBaseFixedPrice(fixedPrice);
		sku.setPosPrice(posPrice);
		sku.setBasePosPrice(posPrice);
		sku.setAmtPrice(new BigDecimal(String.valueOf(sku.getPosPrice())).doubleValue());
		sku.setBaseAmtPrice(new BigDecimal(String.valueOf(sku.getPosPrice())).doubleValue());
		sku.setQty(qty);
		sku.setBaseQty(qty);
		BigDecimal amtPrice = new BigDecimal(String.valueOf(sku.getAmtPrice()));
		BigDecimal qt = new BigDecimal(String.valueOf(sku.getQty()));
		
		sku.setSaleTotal(amtPrice.multiply(qt).setScale(0, BigDecimal.ROUND_HALF_UP).intValue());
		return sku;
	}
	
	private List createSkuList() {
		List<SkuVO> skuList = new ArrayList<SkuVO>();
		SkuVO vo1 = this.createSku("1234567", "112233", 2, 125, 125, false);
		SkuVO vo2 = this.createSku("2345622", "245678", 3, 100, 100, false);
		SkuVO vo3 = this.createSku("3456789", "113322", 3, 500, 480, false);
		SkuVO vo4 = this.createSku("1234567", "112233", 4, 125, 125, false);
		SkuVO vo5 = this.createSku("2345678", "103320", 2, 700, 700, false);
		skuList.add(vo1);
		skuList.add(vo2);
		skuList.add(vo3);
		skuList.add(vo4);
		skuList.add(vo5);
		return skuList;
	}
	
	public void testMaster() {
		TransService tService = (TransService)AppContext.getBean("transService");
		TransInfo info = tService.getTransInfoByOid("e9b0007bf4474e1d9254b3c45ea3d089");
		System.err.println((info==null));
		TransSale sale = null;
		for(TransSale tsale : info.getTransSale()) {
			sale = tsale;
		}
		List<TransSku> skuList = tService.getTransSkuByMasterOid("31f99f3be4fd4a2d9010e8d01d1e5ba2");
		for(TransSku sku : skuList) {
			TransSoSku so = new TransSoSku();
			so.setChannelId(sku.getChannelId());
			so.setStoreId(sku.getStoreId());
			so.setTransDate(sku.getTransDate());
			so.setPosNos(sku.getPosNos());
			so.setSerNos(sku.getSerNos());
			so.setItemSer(sku.getItemSer());
			so.setSkuSaleType(sku.getSkuSaleType());
			so.setSkuNos(sku.getSkuNos());
			so.setOldSkuNos(sku.getOldSkuNos());
			so.setUpc(sku.getUpc());
			so.setBaseUpc(sku.getBaseUpc());
			so.setSkuName(sku.getSkuName());
			so.setTaxType(sku.getTaxType());
			so.setTransQty(sku.getTransQty());
			so.setTransUnit(sku.getTransUnit());
			so.setBaseQty(sku.getBaseQty());
			so.setBaseUnit(sku.getBaseUnit());
			so.setFixedPrice(sku.getFixedPrice());
			so.setPosPrice(sku.getPosPrice());
			so.setStampPrice(sku.getStampPrice());
			so.setAmtPrice(sku.getAmtPrice());
			so.setBaseFixedPrice(sku.getBaseFixedPrice());
			so.setPosPrice(sku.getPosPrice());
			so.setBaseStampPrice(sku.getBaseStampPrice());
			so.setBaseAmtPrice(sku.getBaseAmtPrice());
			so.setSaleTotal(sku.getSaleTotal());
			so.setDiscount(sku.getDiscount());
			so.setRefundNo(sku.getRefundNo());
			so.setRefundCode(sku.getRefundCode());
			so.setDeptId(sku.getDeptId());
			so.setSubdeptId(sku.getSubdeptId());
			so.setClassId(sku.getClassId());
			so.setSubclassId(sku.getSubclassId());
			so.setVendorId(sku.getVendorId());
			so.setInputPriceFlag("N");
			so.setTransInfo(info);
			so.setTransSale(sale);
			tService.getDao().insertObject(so);
		}
			
	}
}
