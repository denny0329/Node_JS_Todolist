package unittest;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

public class SslTest {
	protected InputStream connect(String strUrl) throws Exception {
		if(strUrl.startsWith("https")) {
			trustAllHttpsCertificates();

			HttpsURLConnection.setDefaultHostnameVerifier(
				new HostnameVerifier() {
					public boolean verify(String urlHostName, SSLSession session) {
						System.out.println("Warning: URL Host: " + urlHostName + " vs. " + session.getPeerHost());
						return true;
					}
				}
			);

		}
		URL url = new URL(strUrl);
		HttpURLConnection urlConn = (HttpURLConnection) url.openConnection();
		// connect to https server
/*
		BufferedReader reader = new BufferedReader(new InputStreamReader(urlConn.getInputStream())) ;
		String s = null ;
		while((s = reader.readLine()) != null) {
			System.out.println(s) ;
		}
		reader.close() ;
*/

		return urlConn.getInputStream() ;
		//return null ;

	}

	private static void trustAllHttpsCertificates() throws Exception {
		// Create a trust manager that does not validate certificate chains:
		TrustManager[] trustAllCerts = new TrustManager[1];
		trustAllCerts[0] = new MiTM() ;
		SSLContext sc = SSLContext.getInstance("SSL");
		sc.init(null, trustAllCerts, null);
		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	}

	private static class MiTM implements TrustManager, X509TrustManager {
		public X509Certificate[] getAcceptedIssuers() {
			return null;
		}

		public boolean isServerTrusted(X509Certificate[] certs) {
			return true;
		}

		public boolean isClientTrusted(X509Certificate[] certs) {
			return true;
		}

		public void checkServerTrusted(X509Certificate[] certs, String authType)
				throws CertificateException {
			return;
		}

		public void checkClientTrusted(X509Certificate[] certs, String authType)
				throws CertificateException {
			return;
		}
	}
	
	public static void main(String args[]) {
		SslTest test = new SslTest() ;
		try {
			test.connect("https://10.1.0.216/RFEP/jrxml/Rpt04.jrxml") ;
			//test.connect("http://127.0.0.1:8081/RFEP/jrxml/Rpt04.jrxml") ;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
