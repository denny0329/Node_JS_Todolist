package unittest;

import junit.framework.TestCase;

import org.hibernate.SessionFactory;

import com.bnq.util.AppContext;
import com.trg.oms.utils.dao.OmsMailDao;

public class TestOmsMailDao extends TestCase{
	
	private OmsMailDao dao;
	
	protected void setUp() throws Exception {
		super.setUp();
		dao = new OmsMailDao();
		dao.setSessionFactory((SessionFactory)AppContext.getBean("sessionFactory"));
	}
	
	
	public void testOmsMailDaoCreate() {
		try {
			setUp();
			String mailKind = "SOM_WS";
			String mailTitle = "Qoo測試";
			String mailBody = "Qoo測試填入系統title";
			String sendTo = "QOO_TEST";
			String companyId = "1010";
			
			dao.create(mailKind, mailTitle, mailBody, sendTo, companyId);
			
			
		} catch(Exception e) {
			assertTrue(false);
		}
	}

}
