package unittest.rfep;

import java.io.File;

import com.rfep.dataex.mm.inbound.OMSBUYERGP;

import junit.framework.TestCase;

public class TestOMSBUYERGP extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}

	public void testExcute() {
		File file = new File("C:\\OMS_TEST\\OMSBUYERGP_20150825001109777_66338.csv");
		OMSBUYERGP obj = new OMSBUYERGP();
		obj.execute(file);
	}
}
