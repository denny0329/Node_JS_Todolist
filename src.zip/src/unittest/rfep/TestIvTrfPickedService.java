/**
 * 
 */
package unittest.rfep;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import junit.framework.TestCase;
import com.bnq.util.AppContext;
import com.rfep.iv.dao.IvTrfPickedDAO;
import com.rfep.iv.model.IvTrfPicked;
import com.rfep.iv.service.IvTrfPickedService;

/**
 * 
 * @author allen
 *
 */
public class TestIvTrfPickedService extends TestCase {
	private IvTrfPickedService ivTrfPickedService;
	private IvTrfPickedDAO ivTrfPickedDAO;

	
	@Override
	protected void setUp() throws Exception {
		ivTrfPickedService = (IvTrfPickedService)AppContext.getBean("ivTrfPickedService");
		ivTrfPickedDAO = (IvTrfPickedDAO)AppContext.getBean("ivTrfPickedDAO");
	
		super.setUp();
	}
	
	/**
	 * 測試可寫入1筆資料,trfNo=0000000001,createTime=2012-03-02 20:25:58
	 */
	public void testCreateIvTrfPicked() {
			IvTrfPicked itp = new IvTrfPicked();
			String trfNo = "0000000001";			
			String dateString = "2012-03-02 20:25:58";
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date createTime = new Date();
			try {
				createTime = sdf.parse(dateString);
			} catch (ParseException e) {
			
				e.printStackTrace();
			}
			itp.setTrfNo(trfNo);
			itp.setCreateTime(createTime);
			
			ivTrfPickedDAO.deleteObject(itp);

			ivTrfPickedService.createIvTrfPicked(itp);
			
			String hsql = "FROM IvTrfPicked WHERE trfNo=? and createTime=? ";
			List<IvTrfPicked> list = 
				ivTrfPickedDAO.getHibernateTemplate().find(hsql, new Object[]{trfNo,createTime});
			if(list != null && list.size() > 0){
				assertEquals(trfNo, list.get(0).getTrfNo());
				assertEquals(createTime, list.get(0).getCreateTime());
			}
	}
	
}
