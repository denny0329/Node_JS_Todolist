package unittest.rfep.cb;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.bnq.sc.model.ScSysuser;
import com.rfep.cb.dao.jdbc.CbSalesLogJdbcDAO;
import com.rfep.cb.service.CbMonthSettlementService;


public class TestCbMonthSettlement extends TestCase { 
	public void testFile() {
		try {
		    CbSalesLogJdbcDAO cbSalesLogJdbcDAO=(CbSalesLogJdbcDAO)AppContext.getBean("cbSalesLogJdbcDAO");
		    CbMonthSettlementService cbService = (CbMonthSettlementService)AppContext.getBean("cbMonthSettlementService");
		    CbMonthSettlementService job=new CbMonthSettlementService();
		    
			String vendorId = "0000140701";
			int year = 2016;
			int month = 7;
			String contNo = "C00000003586";
			String newContNo = "C00000003586";
			ScSysuser user = new ScSysuser();
			boolean isExtendOldContract = false;
			job.monthSettlementPortal(vendorId, year, month, contNo, newContNo, user, isExtendOldContract);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
