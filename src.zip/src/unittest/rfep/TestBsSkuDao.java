package unittest.rfep;

import org.hibernate.SessionFactory;

import com.bnq.util.AppContext;
import com.gccs.bs.dao.hibernate.BsSkuDao;
import com.rfep.product.bs.model.BsSku;

import junit.framework.TestCase;

/**
 * 
 * @author T2482
 */
public class TestBsSkuDao extends TestCase {
	private SessionFactory factory;

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		factory = (SessionFactory)AppContext.getBean("sessionFactory");
	}
	
	public void testFindBsSkuBySkuId() {
		BsSkuDao dao = new BsSkuDao();
		dao.setSessionFactory(factory);
		BsSku bsSku = dao.findBySku("009003786", "1010");
		assertEquals("003786", bsSku.getOldSku());
		assertEquals("0000190018", bsSku.getVendorId());
	}
}