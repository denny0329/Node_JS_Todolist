package unittest.rfep;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

import org.hibernate.SessionFactory;

import com.bnq.util.AppContext;
import com.bnq.util.DateUtils;
import com.rfep.product.bs.dao.hibernate.BsSkuStoreDao;
import com.rfep.product.bs.dao.hibernate.PdSkuDao;
import com.rfep.product.bs.model.BsSkuStore;

import junit.framework.TestCase;

/**
 * 
 * @author T2482
 */
public class TestPdSkuDao extends TestCase {
	private SessionFactory factory;
	private BsSkuStoreDao dao;
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		dao = (BsSkuStoreDao)AppContext.getBean("bsSkuStoreDao");
		factory = (SessionFactory)AppContext.getBean("sessionFactory");
	}

	@SuppressWarnings("rawtypes")
	public void testFindTransSkuVariationInfo() {
		PdSkuDao dao = new PdSkuDao();
		dao.setSessionFactory(factory);
		String store_id = "00616";
		String sku = "014017126";
		Map map = dao.findTransSkuVariationInfo(store_id, sku);
		assertEquals("014017126", map.get("SKU"));
		assertEquals("雅各骨瓷馬克杯320ml", map.get("SKU_NAME"));
		assertEquals("A", map.get("SKU_STATUS"));
		assertEquals("071", map.get("SUB_DEPT_ID"));
		assertEquals("HOLA", map.get("CHANNEL_ID"));
		assertEquals("00616", map.get("STORE_ID"));
		assertNull(map.get("HOLD_ORDER"));
		assertNull(map.get("BAY_NO"));
		assertNull(map.get("PROJECT_ID"));
		assertEquals(0, ((BigDecimal)map.get("STORE_SELECTION")).intValue());
		assertEquals(0, ((BigDecimal)map.get("POG_FLAG")).intValue());
		assertEquals("ab092511353e4fd2a8d23d8b24e9a281", map.get("DEPT_OID"));
		assertEquals(10, ((BigDecimal)map.get("BOOK_QTY")).intValue());
		assertEquals(399, ((BigDecimal)map.get("REGULAR_PRICE")).intValue());
		assertNull(map.get("INSTALLATION_PRICE"));
	}
	
	public void testUpdateSkuStoreEvent() {
		String storeId="00603";
		String sku="000146300";
		String eventNo = "0002005777";
		Double posPrice = 199d;
		Date eventDay = DateUtils.trunc(new Date());

		try {
			dao.updateSkuStoreEvent(storeId, sku, eventNo, posPrice, eventDay, eventDay);
			
			BsSkuStore skuStore = dao.findSkuStore(storeId, sku);
			assertEquals("0002005777", skuStore.getEventNo());
			assertEquals(eventDay, skuStore.getEventStart());
			assertEquals(eventDay, skuStore.getEventEnd());
			assertEquals(199d, skuStore.getPosPrice());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
