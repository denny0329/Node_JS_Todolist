package unittest.rfep;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.bnq.util.AppContext;
import com.rfep.iv.model.IvStoreInventory;
import com.rfep.iv.po.model.Po;
import com.rfep.iv.po.model.PoSku;
import com.rfep.iv.po.model.PoStatus;
import com.rfep.iv.po.model.PoType;
import com.rfep.iv.rtv.model.PoRtv;
import com.rfep.iv.rtv.model.PoRtvSku;
import com.rfep.iv.rtv.model.PoRtvStatus;
import com.rfep.iv.rtv.model.TrfRtv;
import com.rfep.iv.rtv.model.TrfRtvSku;
import com.rfep.iv.rtv.model.TrfRtvStatus;
import com.rfep.iv.rtv.model.TrfSummary;
import com.rfep.iv.rtv.model.TrfSummaryDtl;
import com.rfep.iv.service.PurchaseService;
import com.rfep.iv.trf.model.Trf;
import com.rfep.iv.trf.model.TrfSku;
import com.rfep.iv.trf.model.TrfStatus;
import com.rfep.so.model.OrderGoods;
import com.rfep.util.SapPoType;

import junit.framework.TestCase;

/**
 * 
 * @author T2482
 */
public class TestPurchaseService extends TestCase {
	private PurchaseService service;

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		this.service = (PurchaseService)AppContext.getBean("purchaseService");
	}

	public void testDeletePo() {
		doPoTest("0000415638");
		doPoRtvTest("4020000012");
		doTrfTest("0001334607");
		doTrfRtvTest("7100000002");
	}
	
	/**
	 * 測試採購單刪除流程(不含電文檢核)<br>
	 * UT:4
	 * @param poNo 採購單代碼
	 */
	private void doPoTest(String poNo) {
		// 測試找不到 po number
		final PoType poType = PoType.PO;
		final String user = "PogiTest";
		SapPoType sapPoType = SapPoType.ZP04;
		boolean result = this.service.deletePurchaseOrder(poType, "", user);
		assertEquals(false, result);
		
		// 測試當 sapPoType = ZP04 時，不可以刪單
		Po po = this.service.getPoDao().loadByPoNo(poNo);
		po.setPoType(sapPoType.toString());
		updatePO(po);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(false, result);
		
		// 測試當 sapPoType = ZP04 及 status = Apply 時，不可刪單
		po.setStatus(PoStatus.APPLY.getValue());
		updatePO(po);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(false, result);
		
		// 測試當 sapPoType != ZP04 及 status = Apply 時，可以刪單
		// select * from iv_po where po_no='0000415638';
		// select * from iv_po_sku where po_oid=(select oid from iv_po where po_no='0000415638');
		// select * from iv_store_inventory where store_id='00700' and sku='000265821';
		sapPoType = SapPoType.ZP01;
		po.setPoType(sapPoType.toString());
		po.setStatus(PoStatus.APPLY.getValue());
		po.setModifier("Nobody");
		po.setModifierName("Nobody");
		
		for(PoSku poSku : po.getSkuList()) {
			poSku.setOrderQty(2);
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(po.getStoreId(), poSku.getSku());
			inventory.setOnPo(poSku.getOrderQty());
			this.service.getInventoryDao().updateIvStoreInventory(inventory);
			
			if(poSku.getGoodsOid() != null) {
				for(String goodsOid : poSku.getGoodsOid().split(",")) {
					OrderGoods orderGoods = this.service.getSoOrderGoodsDao().getObjectByOid(goodsOid);
					orderGoods.setSoTransferOnOrder(2);
					orderGoods.setModifier("Nobody");
					orderGoods.setModifierName("Nobody");
					this.service.getSoOrderGoodsDao().update(orderGoods);
				}
			}
		}
		updatePO(po);
		
		po = this.service.getPoDao().loadByPoNo(poNo);
		for(PoSku poSku : po.getSkuList()) {
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(po.getStoreId(), poSku.getSku());
			assertEquals(2, inventory.getOnPo().intValue());
			assertEquals(2, poSku.getOrderQty().intValue());
		}
		
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(true, result);
		
		po = this.service.getPoDao().loadByPoNo(poNo);
		assertEquals(sapPoType.toString(), po.getPoType());
		assertEquals(PoStatus.INVALID.getValue(), po.getStatus().intValue());
		assertEquals(user, po.getModifier());
		
		for(PoSku poSku : po.getSkuList()) {
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(po.getStoreId(), poSku.getSku());
			assertEquals(0, inventory.getOnPo().intValue());
			assertEquals(0, poSku.getOrderQty().intValue());
			
			if(poSku.getGoodsOid() != null) {
				for(String goodsOid : poSku.getGoodsOid().split(",")) {
					OrderGoods orderGoods = this.service.getSoOrderGoodsDao().getObjectByOid(goodsOid);
					assertEquals(2, orderGoods.getSoTransferOnOrder().intValue());
					assertEquals("Nobody", orderGoods.getModifier());
				}
			}
		}
		
		// 測試當 sapPoType != ZP04 且 sapPoType == ZP50 及 status = Apply 時，可以刪單，及 so_order_goods.so_transfer_on_order 設為 0
		// select * from iv_po where po_no='0000415638';
		// select * from iv_po_sku where po_oid=(select oid from iv_po where po_no='0000415638');
		// select * from iv_store_inventory where store_id='00700' and sku='000265821';
		sapPoType = SapPoType.ZP50;
		po.setPoType(sapPoType.toString());
		po.setStatus(PoStatus.APPLY.getValue());
		po.setModifier("Nobody");
		po.setModifierName("Nobody");
		
		for(PoSku poSku : po.getSkuList()) {
			poSku.setOrderQty(2);
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(po.getStoreId(), poSku.getSku());
			inventory.setOnPo(poSku.getOrderQty());
			this.service.getInventoryDao().updateIvStoreInventory(inventory);
			
			if(poSku.getGoodsOid() != null) {
				for(String goodsOid : poSku.getGoodsOid().split(",")) {
					OrderGoods orderGoods = this.service.getSoOrderGoodsDao().getObjectByOid(goodsOid);
					orderGoods.setSoTransferOnOrder(2);
					orderGoods.setModifier("Nobody");
					orderGoods.setModifierName("Nobody");
					this.service.getSoOrderGoodsDao().update(orderGoods);
				}
			}
		}
		updatePO(po);
		
		po = this.service.getPoDao().loadByPoNo(poNo);
		for(PoSku poSku : po.getSkuList()) {
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(po.getStoreId(), poSku.getSku());
			assertEquals(2, inventory.getOnPo().intValue());
			assertEquals(2, poSku.getOrderQty().intValue());
		}
		
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(true, result);
		
		po = this.service.getPoDao().loadByPoNo(poNo);
		assertEquals(sapPoType.toString(), po.getPoType());
		assertEquals(PoStatus.INVALID.getValue(), po.getStatus().intValue());
		assertEquals(user, po.getModifier());
		
		for(PoSku poSku : po.getSkuList()) {
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(po.getStoreId(), poSku.getSku());
			assertEquals(0, inventory.getOnPo().intValue());
			assertEquals(0, poSku.getOrderQty().intValue());
			
			if(poSku.getGoodsOid() != null) {
				for(String goodsOid : poSku.getGoodsOid().split(",")) {
					OrderGoods orderGoods = this.service.getSoOrderGoodsDao().getObjectByOid(goodsOid);
					assertEquals(0, orderGoods.getSoTransferOnOrder().intValue());
					assertEquals(user, orderGoods.getModifier());
				}
			}
		}
	}
	
	/**
	 * 測試退廠單刪除流程(不含電文檢核)<br>
	 * UT:6
	 * @param poNo 採購單代碼
	 */
	private void doPoRtvTest(String poNo) {
		final PoType poType = PoType.PO_RTV; 
		final String user = "PogiTest";
		
		// 測試查不到採購單的流程
		PoRtv poRtv = this.service.getRtvDao().findPoRtvByFormNo("");
		boolean result = this.service.deletePurchaseOrder(poType, "", user);
		assertEquals(false, result);
		
		// 測試 SapPoType = ZR01 時，不可刪單
		SapPoType sapPoType = SapPoType.ZR01;
		poRtv = this.service.getRtvDao().findPoRtvByFormNo(poNo);
		poRtv.setPoType(sapPoType.toString());
		this.service.getRtvDao().updateObject(poRtv);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(false, result);
		
		// 測試 SapPoType = ZR02, PoRtvStatus = CHECKOUT 時，不可刪單
		sapPoType = SapPoType.ZR02;
		poRtv.setPoType(sapPoType.toString());
		poRtv.setStatus(PoRtvStatus.CHECKOUT.getValue());
		this.service.getRtvDao().updateObject(poRtv);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(false, result);
		
		// 測試 SapPoType = ZR02, PoRtvStatus = INVALID 時，不可刪單
		poRtv.setStatus(PoRtvStatus.INVALID.getValue());
		this.service.getRtvDao().updateObject(poRtv);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(false, result);
		
		// 測試 SapPoType = ZR02, PoRtvStatus = APPLY 時，可以刪單，但是不能更新 IvStoreInventory 的 onRtv 值
		poRtv.setStatus(PoRtvStatus.APPLY.getValue());
		for(PoRtvSku poRtvSku : poRtv.getPoRtvSkuList()) {
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(poRtv.getStoreId(), poRtvSku.getSku());
			inventory.setOnRtv(2);
			this.service.getInventoryDao().updateIvStoreInventory(inventory);
		}
		this.service.getRtvDao().updateObject(poRtv);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(true, result);
		poRtv = this.service.getRtvDao().findPoRtvByFormNo(poNo);
		assertEquals(PoRtvStatus.INVALID.getValue(), poRtv.getStatus().intValue());
		assertEquals(user, poRtv.getModifier());
		for(PoRtvSku poRtvSku : poRtv.getPoRtvSkuList()) {
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(poRtv.getStoreId(), poRtvSku.getSku());
			assertEquals(2, inventory.getOnRtv().intValue());
		}
		
		// 測試 SapPoType = ZR02, PoRtvStatus = NOTIFY_VENDOR 時，可以刪單，以及更新 IvStoreInventory 的 onRtv 值
		poRtv.setStatus(PoRtvStatus.NOTIFY_VENDOR.getValue());
		poRtv.setModifier("Nobody");
		poRtv.setModifierName("Nobody");
		for(PoRtvSku poRtvSku : poRtv.getPoRtvSkuList()) {
			poRtvSku.setQty(2);
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(poRtv.getStoreId(), poRtvSku.getSku());
			inventory.setOnRtv(poRtvSku.getQty());
			this.service.getInventoryDao().updateIvStoreInventory(inventory);
		}
		this.service.getRtvDao().updateObject(poRtv);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(true, result);
		poRtv = this.service.getRtvDao().findPoRtvByFormNo(poNo);
		assertEquals(PoRtvStatus.INVALID.getValue(), poRtv.getStatus().intValue());
		assertEquals(user, poRtv.getModifier());
		for(PoRtvSku poRtvSku : poRtv.getPoRtvSkuList()) {
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(poRtv.getStoreId(), poRtvSku.getSku());
			assertEquals(2, poRtvSku.getQty().intValue());
			assertEquals(0, inventory.getOnRtv().intValue());
		}
	}

	/**
	 * 測試調撥單刪除流程(不含電文檢核)<br>
	 * UT:7
	 * @param poNo 採購單代碼
	 */
	private void doTrfTest(String poNo) {
		final PoType poType = PoType.TRF;
		final String user = "PoriTest";
		
		// 測試找不到調撥單的流程
		boolean result = this.service.deletePurchaseOrder(poType, "", user);
		assertEquals(false, result);
		
		// 測試 SapPoType = ZS04 時，不可刪單
		Trf trf = this.service.getStoDao().findTrfByTrfNo(poNo);
		trf.setPoType(SapPoType.ZS04.toString());
		this.service.getStoDao().updateObject(trf);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(false, result);
		
		// 測試 SapPoType = ZS03, TrfStatus != DRAFT 或 TrfStatus != APPLY 時，不可刪單
		trf.setPoType(SapPoType.ZS03.toString());
		trf.setStatus(TrfStatus.ALLOCATE.getValue());
		this.service.getStoDao().updateObject(trf);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(false, result);
		
		trf.setPoType(SapPoType.ZS03.toString());
		trf.setStatus(TrfStatus.INVALID.getValue());
		this.service.getStoDao().updateObject(trf);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(false, result);
		
		trf.setPoType(SapPoType.ZS03.toString());
		trf.setStatus(TrfStatus.WAREHOUSE_CHECK.getValue());
		this.service.getStoDao().updateObject(trf);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(false, result);
		
		trf.setPoType(SapPoType.ZS03.toString());
		trf.setStatus(TrfStatus.WAREHOUSE_IN.getValue());
		this.service.getStoDao().updateObject(trf);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(false, result);
		
		trf.setPoType(SapPoType.ZS03.toString());
		trf.setStatus(TrfStatus.WAREHOUSE_OUT.getValue());
		this.service.getStoDao().updateObject(trf);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(false, result);
		
		// 測試 SapPoType = ZS03, TrfStatus = DRAFT 時，可以刪單，但是 IV_STORE_INVENTORY 的 ON_TRF、ON_TRF_OUT 不會變
		trf.setPoType(SapPoType.ZS03.toString());
		trf.setStatus(TrfStatus.DRAFT.getValue());
		for(TrfSku trfSku : trf.getTrfSkuList()) {
			trfSku.setDelFlag(null);
			trfSku.setModifier("Nobody");
			trfSku.setModifierName("Nobody");
			trfSku.setApplyQty(6);
			
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(trf.getOutStoreId(), trfSku.getSku());
			inventory.setOnTrfOut(6);
			this.service.getInventoryDao().updateIvStoreInventory(inventory);
			
			inventory = this.service.getInventoryDao().getIvStoreInventory(trf.getInStoreId(), trfSku.getSku());
			inventory.setOnTrf(6);
			this.service.getInventoryDao().updateIvStoreInventory(inventory);
		}
		this.service.getStoDao().updateObject(trf);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(true, result);
		trf = this.service.getStoDao().findTrfByTrfNo(poNo);
		assertEquals(TrfStatus.INVALID.getValue(), trf.getStatus().intValue());
		assertEquals(user, trf.getModifier());
		for(TrfSku trfSku : trf.getTrfSkuList()) {
			assertEquals(new Integer(1), trfSku.getDelFlag());
			assertEquals(user, trfSku.getModifier());
			assertEquals(new Integer(6), trfSku.getApplyQty());
			
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(trf.getOutStoreId(), trfSku.getSku());
			assertEquals(new Integer(6), inventory.getOnTrfOut());
			
			inventory = this.service.getInventoryDao().getIvStoreInventory(trf.getInStoreId(), trfSku.getSku());
			assertEquals(new Integer(6), inventory.getOnTrf());
		}
		
		/*
		 * 測試 SapPoType = ZS03, TrfStatus = APPLY 時，可以刪單，
		 * 調出店 的 IV_STORE_INVENTORY.ON_TRF_OUT 及調入店的 IV_STORE_INVENTORY.ON_TRF 都要減掉對應的 IV_TRF_SKU.APPLY_QTY 
		 */
		trf.setPoType(SapPoType.ZS03.toString());
		trf.setStatus(TrfStatus.APPLY.getValue());
		trf.setModifier("Nobody");
		trf.setModifierName("Nobody");
		for(TrfSku trfSku : trf.getTrfSkuList()) {
			trfSku.setDelFlag(null);
			trfSku.setModifier("Nobody");
			trfSku.setModifierName("Nobody");
			trfSku.setApplyQty(6);
			
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(trf.getOutStoreId(), trfSku.getSku());
			inventory.setOnTrfOut(6);
			this.service.getInventoryDao().updateIvStoreInventory(inventory);
			
			inventory = this.service.getInventoryDao().getIvStoreInventory(trf.getInStoreId(), trfSku.getSku());
			inventory.setOnTrf(6);
			this.service.getInventoryDao().updateIvStoreInventory(inventory);
		}
		this.service.getStoDao().updateObject(trf);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(true, result);
		trf = this.service.getStoDao().findTrfByTrfNo(poNo);
		assertEquals(TrfStatus.INVALID.getValue(), trf.getStatus().intValue());
		assertEquals(user, trf.getModifier());
		for(TrfSku trfSku : trf.getTrfSkuList()) {
			assertEquals(new Integer(1), trfSku.getDelFlag());
			assertEquals(user, trfSku.getModifier());
			assertEquals(new Integer(6), trfSku.getApplyQty());
			
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(trf.getOutStoreId(), trfSku.getSku());
			assertEquals(new Integer(0), inventory.getOnTrfOut());
			inventory = this.service.getInventoryDao().getIvStoreInventory(trf.getInStoreId(), trfSku.getSku());
			assertEquals(new Integer(0), inventory.getOnTrf());
		}
		
		// 測試 SapPoType != ZS04 或 SapPoType != ZS03  且 TrfStatus != APPLY 時，不可刪單
		trf.setPoType(SapPoType.ZS07.toString());
		trf.setStatus(TrfStatus.WAREHOUSE_CHECK.getValue());
		this.service.getStoDao().updateObject(trf);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(false, result);
		
		/*
		 * 測試 SapPoType != ZS04 或 SapPoType != ZS03  且 TrfStatus = APPLY 時，可以刪單
		 * 調出店 的 IV_STORE_INVENTORY.ON_TRF_OUT 及調入店的 IV_STORE_INVENTORY.ON_TRF 都要減掉對應的 IV_TRF_SKU.APPLY_QTY
		 */
		trf.setPoType(SapPoType.ZS06.toString());
		trf.setStatus(TrfStatus.APPLY.getValue());
		trf.setModifier("Nobody");
		trf.setModifierName("Nobody");
		for(TrfSku trfSku : trf.getTrfSkuList()) {
			trfSku.setDelFlag(null);
			trfSku.setModifier("Nobody");
			trfSku.setModifierName("Nobody");
			trfSku.setApplyQty(6);
			
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(trf.getOutStoreId(), trfSku.getSku());
			inventory.setOnTrfOut(6);
			this.service.getInventoryDao().updateIvStoreInventory(inventory);
			
			inventory = this.service.getInventoryDao().getIvStoreInventory(trf.getInStoreId(), trfSku.getSku());
			inventory.setOnTrf(6);
			this.service.getInventoryDao().updateIvStoreInventory(inventory);
		}
		this.service.getStoDao().updateObject(trf);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(true, result);
		trf = this.service.getStoDao().findTrfByTrfNo(poNo);
		assertEquals(TrfStatus.INVALID.getValue(), trf.getStatus().intValue());
		assertEquals(user, trf.getModifier());
		for(TrfSku trfSku : trf.getTrfSkuList()) {
			assertEquals(new Integer(1), trfSku.getDelFlag());
			assertEquals(user, trfSku.getModifier());
			assertEquals(new Integer(6), trfSku.getApplyQty());
			
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(trf.getOutStoreId(), trfSku.getSku());
			assertEquals(new Integer(6), inventory.getOnTrfOut());
			inventory = this.service.getInventoryDao().getIvStoreInventory(trf.getInStoreId(), trfSku.getSku());
			assertEquals(new Integer(0), inventory.getOnTrf());
		}
	}
	
	/**
	 * 測試退調單刪除流程(不含電文檢核)<br>
	 * UT:6
	 * @param poNo 採購單代碼
	 */
	private void doTrfRtvTest(String poNo) {
		final PoType poType = PoType.TRF_RTV;
		final String user = "PogiTest";
		
		// 測試找不到退調單的流程
		boolean result = this.service.deletePurchaseOrder(poType, "", user);
		assertEquals(false, result);
		
		// 測試 SapPoType != ZS73 時，不可刪單
		TrfRtv trfRtv = this.service.getRtvDao().findTrfRtvByFormNo(poNo);
		trfRtv.setPoType(SapPoType.ZS71.toString());
		int oldStatus = trfRtv.getStatus();
		this.service.getStoDao().updateObject(trfRtv);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(false, result);
		trfRtv = this.service.getRtvDao().findTrfRtvByFormNo(poNo);
		assertEquals(oldStatus, trfRtv.getStatus().intValue());
		
		// 測試 SapPoType = ZS73 但 TrfRtvStatus != APPLY 或 TrfRtvStatus != PICK 時，不可刪單
		trfRtv.setPoType(SapPoType.ZS73.toString());
		trfRtv.setStatus(TrfRtvStatus.CHECKIN.getValue());
		oldStatus = trfRtv.getStatus();
		this.service.getStoDao().updateObject(trfRtv);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(false, result);
		trfRtv = this.service.getRtvDao().findTrfRtvByFormNo(poNo);
		assertEquals(oldStatus, trfRtv.getStatus().intValue());
		
		trfRtv.setPoType(SapPoType.ZS73.toString());
		trfRtv.setStatus(TrfRtvStatus.CHECKOUT.getValue());
		oldStatus = trfRtv.getStatus();
		this.service.getStoDao().updateObject(trfRtv);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(false, result);
		trfRtv = this.service.getRtvDao().findTrfRtvByFormNo(poNo);
		assertEquals(oldStatus, trfRtv.getStatus().intValue());
		
		trfRtv.setPoType(SapPoType.ZS73.toString());
		trfRtv.setStatus(TrfRtvStatus.INVALID.getValue());
		oldStatus = trfRtv.getStatus();
		this.service.getStoDao().updateObject(trfRtv);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(false, result);
		trfRtv = this.service.getRtvDao().findTrfRtvByFormNo(poNo);
		assertEquals(oldStatus, trfRtv.getStatus().intValue());
		
		// 測試 SapPoType = ZS73, TrfRtvStatus = PICK 但 TrfSummaryStatus != APPLY 時，不可刪單
		trfRtv.setPoType(SapPoType.ZS73.toString());
		trfRtv.setStatus(TrfRtvStatus.PICK.getValue());
		oldStatus = trfRtv.getStatus();
		TrfSummaryDtl trfSummaryDtl = this.service.getRtvDao().findTrfSummaryDtlByFormNo(trfRtv.getOid());
		trfSummaryDtl.setDelFlag(null);
		trfSummaryDtl.setModifier("Nobody");
		trfSummaryDtl.setModifierName("Nobody");
		TrfSummary trfSummary = trfSummaryDtl.getMstOid();
		trfSummary.setStatus(TrfRtvStatus.PICK.getValue());
		this.service.getStoDao().updateObject(trfSummaryDtl);
		this.service.getStoDao().updateObject(trfSummary);
		this.service.getStoDao().updateObject(trfRtv);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(false, result);
		trfRtv = this.service.getRtvDao().findTrfRtvByFormNo(poNo);
		assertEquals(oldStatus, trfRtv.getStatus().intValue());
		trfSummaryDtl = this.service.getRtvDao().findTrfSummaryDtlByFormNo(trfRtv.getOid());
		assertEquals(null, trfSummaryDtl.getDelFlag());
		assertEquals("Nobody", trfSummaryDtl.getModifier());
		
		/*
		 * 測試 SapPoType = ZS73, TrfRtvStatus = PICK, TrfSummaryStatus = APPLY 時，可以刪單
		 * IV_STORE_INVENTORY.ON_TRF_OUT 會減掉 IV_TRF_RTV_SKU.qty
		 * IV_TRF_SUMMARY_DTL.DEL_FLAG == 1 
		 */
		trfRtv.setPoType(SapPoType.ZS73.toString());
		trfRtv.setStatus(TrfRtvStatus.PICK.getValue());
		trfRtv.setModifier("Nobody");
		trfRtv.setModifierName("Nobody");
		oldStatus = trfRtv.getStatus();
		for(TrfRtvSku trfRtvSku : trfRtv.getTrfRtvSkuList()) {
			trfRtvSku.setQty(88);
			
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(trfRtv.getInStoreId(), trfRtvSku.getSku());
			inventory.setOnTrfOut(88);
			this.service.getInventoryDao().updateIvStoreInventory(inventory);
		}
		trfSummaryDtl = this.service.getRtvDao().findTrfSummaryDtlByFormNo(trfRtv.getOid());
		trfSummaryDtl.setDelFlag(null);
		trfSummaryDtl.setModifier("Nobody");
		trfSummaryDtl.setModifierName("Nobody");
		trfSummary = trfSummaryDtl.getMstOid();
		trfSummary.setStatus(TrfRtvStatus.APPLY.getValue());
		this.service.getStoDao().updateObject(trfSummaryDtl);
		this.service.getStoDao().updateObject(trfSummary);
		this.service.getStoDao().updateObject(trfRtv);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(true, result);
		trfRtv = this.service.getRtvDao().findTrfRtvByFormNo(poNo);
		assertEquals(TrfRtvStatus.INVALID.getValue(), trfRtv.getStatus().intValue());
		assertEquals(user, trfRtv.getModifier());
		for(TrfRtvSku trfRtvSku : trfRtv.getTrfRtvSkuList()) {
			assertEquals(88, trfRtvSku.getQty().intValue());
			
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(trfRtv.getInStoreId(), trfRtvSku.getSku());
			assertEquals(0, inventory.getOnTrfOut().intValue());
		}
		trfSummaryDtl = this.service.getRtvDao().findTrfSummaryDtlByFormNo(trfRtv.getOid());
		assertEquals(1, trfSummaryDtl.getDelFlag().intValue());
		assertEquals(user, trfSummaryDtl.getModifier());
		
		/*
		 * 測試 SapPoType = ZS73, TrfRtvStatus = APPLY 時，可以刪單
		 * IV_STORE_INVENTORY.ON_TRF_OUT 會減掉 IV_TRF_RTV_SKU.qty
		 */
		trfRtv.setPoType(SapPoType.ZS73.toString());
		trfRtv.setStatus(TrfRtvStatus.APPLY.getValue());
		trfRtv.setModifier("Nobody");
		trfRtv.setModifierName("Nobody");
		oldStatus = trfRtv.getStatus();
		for(TrfRtvSku trfRtvSku : trfRtv.getTrfRtvSkuList()) {
			trfRtvSku.setQty(88);
			
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(trfRtv.getInStoreId(), trfRtvSku.getSku());
			inventory.setOnTrfOut(88);
			this.service.getInventoryDao().updateIvStoreInventory(inventory);
		}
		trfSummaryDtl = this.service.getRtvDao().findTrfSummaryDtlByFormNo(trfRtv.getOid());
		trfSummaryDtl.setDelFlag(null);
		trfSummaryDtl.setModifier("Nobody");
		trfSummaryDtl.setModifierName("Nobody");
		this.service.getStoDao().updateObject(trfSummaryDtl);
		this.service.getStoDao().updateObject(trfSummary);
		this.service.getStoDao().updateObject(trfRtv);
		result = this.service.deletePurchaseOrder(poType, poNo, user);
		assertEquals(true, result);
		trfRtv = this.service.getRtvDao().findTrfRtvByFormNo(poNo);
		assertEquals(TrfRtvStatus.INVALID.getValue(), trfRtv.getStatus().intValue());
		assertEquals(user, trfRtv.getModifier());
		for(TrfRtvSku trfRtvSku : trfRtv.getTrfRtvSkuList()) {
			assertEquals(88, trfRtvSku.getQty().intValue());
			
			IvStoreInventory inventory = this.service.getInventoryDao().getIvStoreInventory(trfRtv.getInStoreId(), trfRtvSku.getSku());
			assertEquals(0, inventory.getOnTrfOut().intValue());
		}
		trfSummaryDtl = this.service.getRtvDao().findTrfSummaryDtlByFormNo(trfRtv.getOid());
		assertEquals(null, trfSummaryDtl.getDelFlag());
		assertEquals("Nobody", trfSummaryDtl.getModifier());
	}
	
	/**
	 * 更新採購單
	 * @param po 採購單
	 */
	private void updatePO(Po po) {
		Session session = null;
		Transaction tx = null;
		session = this.service.getSessionFactory().openSession();
		tx = session.beginTransaction();
		this.service.getPoDao().update(session, po);
		tx.commit();
		session.close();
	}
}