package unittest.rfep;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bnq.sc.model.ScSysuser;
import com.bnq.util.AppContext;
import com.bnq.util.QueryResult;
import com.gccs.bs.dao.hibernate.BsSkuDao;
import com.rfep.product.bs.model.BsSku;
import com.rfep.so.bs.action.SoDeliverySkuAction;
import com.rfep.so.bs.dao.hibernate.SoDeliverySkuDAO;
import com.rfep.so.bs.model.SoDeliverySku;
import com.rfep.so.bs.service.SoDeliverySkuService;
import com.rfep.so.bs.vo.SoDeliverySkuList;
import com.rfep.util.Classification;

import junit.framework.TestCase;

/**
 * 
 * @author T2482
 */
public class TestSoDeliverySkuService extends TestCase {
	
	private SoDeliverySkuAction sdsAction;
	private SoDeliverySkuService sdsService;

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		this.sdsAction = new SoDeliverySkuAction();
		this.sdsService = (SoDeliverySkuService)AppContext.getBean("soDeliverySkuService");
		this.sdsService.setDao((SoDeliverySkuDAO)AppContext.getBean("soDeliverySkuDAO"));
		this.sdsService.setBsSkuDao((BsSkuDao)AppContext.getBean("bsSkuDao"));
		sdsAction.setService(sdsService);
	}
	
	/**
	 * 初始化 queryCondition 所需的 Map 資料。
	 * @param skuId 商品代碼
	 * @param skuName 商品名稱
	 * @param installSkuId 安裝費商品代碼
	 * @param installSkuName 安裝費商品名稱
	 * @param subDept 商品品類2
	 * @param classId 商品品類3
	 * @param subClass 商品品類4
	 * @return
	 */
	private Map<String, String> initQueryCondition(
			String skuId, String skuName, String installSkuId, String installSkuName,
			String subDept, String classId, String subClass) {
		Map<String, String> result = new HashMap<String, String>();
		
		result.put("skuId", skuId);
		result.put("skuName", skuName);
		result.put("installSkuId", installSkuId);
		result.put("installSkuName", installSkuName);
		result.put("subDept", subDept);
		result.put("classId", classId);
		result.put("subClass", subClass);
		
		return result;
	}
	
	@SuppressWarnings("unchecked")
	public void testFindInstallSkuList() {
		//建立查詢所需資料
		this.sdsAction.setQueryCondition(initQueryCondition(null, null, "000202826", null, null, null, null));
		QueryResult result = this.sdsService.findInstallSkuList(this.sdsAction.getQueryCondition(), 0, 100);
		assertEquals(1, result.getCount().intValue());
		assertEquals("000202826", ((BsSku)result.getResult().get(0)).getSku());
	}
	
	@SuppressWarnings("unchecked")
	public void testFindByInstallClass() {
		//建立查詢所需資料
		this.sdsAction.setQueryCondition(initQueryCondition(null, null, "000202826", null, null, null, null));
		QueryResult result = this.sdsService.findInstallSkuList(this.sdsAction.getQueryCondition(), 0, 100);
		BsSku bsSku = (BsSku)result.getResult().get(0);
		SoDeliverySkuList soDeliverySkuList = this.sdsService.findByInstallClass(null, bsSku.getSku(), 0, 10);
		assertEquals(8, soDeliverySkuList.getVoList().size());
	}
	
	@SuppressWarnings("unchecked")
	public void testSoDeliverySkuListGetClassifyData() {
		//建立查詢所需資料
		this.sdsAction.setQueryCondition(initQueryCondition(null, null, "000202826", null, null, null, null));
		QueryResult result = this.sdsService.findInstallSkuList(this.sdsAction.getQueryCondition(), 0, 100);
		BsSku bsSku = (BsSku)result.getResult().get(0);
		SoDeliverySkuList originalList = this.sdsService.findByInstallClass(null, bsSku.getSku(), 0, 10);
		SoDeliverySkuList pageList = this.sdsService.findByInstallClass(null, bsSku.getSku(), 0, 10);
		
		pageList.getVoList().get(4).setSubClass("002");
		
		pageList.getDelList().add("OID_545_77xx");
		pageList.getDelList().add("2c9086c335a7e20d0135a814f8c90007");
		
		SoDeliverySku newRow = new SoDeliverySku();
		BsSku tempBsSku = new BsSku();
		tempBsSku.setSku("009043171");
		newRow.setBsSku(tempBsSku);
		pageList.getVoList().add(newRow);
		
		ScSysuser user = new ScSysuser("Pogi", "波吉");
		
		Map<Classification, List<SoDeliverySku>> resultData = pageList.getClassifyData(originalList, user);
		assertEquals(1, resultData.get(Classification.Create).size());
		assertEquals(2, resultData.get(Classification.Delete).size());
		assertEquals(1, resultData.get(Classification.Update_Modify).size());
		assertEquals(1, resultData.get(Classification.Update_Original).size());
	}

}
