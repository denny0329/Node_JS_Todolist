/**
 * @(#)TestOmsMailService.java.java Jan 25, 2015
 * <p>
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 * <p>
 * This software is the confidential and proprietary information of Test Rite
 * Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest.rfep;

import com.bnq.sc.dao.hibernate.ScSysuserDAO;
import com.bnq.util.AppContext;
import com.rfep.util.sys.dao.SysEmailGroupDao;
import com.rfep.util.sys.dao.SysJobDao;
import com.trg.oms.utils.dao.OmsMailDao;
import com.trg.oms.utils.service.OmsMailService;
import com.rfep.cb.dao.CbDaySettlementDAO;
import com.rfep.ds.dao.DsDaySettlementDAO;

import junit.framework.TestCase;
import org.apache.commons.io.FileUtils;

import javax.mail.internet.MimeUtility;
import java.io.File;

/**
 * @author T2482
 *
 */
public class TestOmsMailService extends TestCase {
    private OmsMailService service;

    /* (non-Javadoc)
     * @see junit.framework.TestCase#setUp()
     */
    protected void setUp() throws Exception {
        super.setUp();
        service = new OmsMailService();
        service.setOmsMailDao((OmsMailDao) AppContext.getBean("omsMailDao"));
        service.setScSysuserDAO((ScSysuserDAO) AppContext.getBean("scSysuserDAO"));
        service.setSysEmailGroupDao((SysEmailGroupDao) AppContext.getBean("sysEmailGroupDao"));
        service.setSysJobDao((SysJobDao) AppContext.getBean("sysJobDao"));
        service.setCbDaySettlementDAO((CbDaySettlementDAO) AppContext.getBean("cbDaySettlementDAO"));
        service.setDsDaySettlementDAO((DsDaySettlementDAO) AppContext.getBean("dsDaySettlementDAO"));

    }

    public void testExecute() {
        service.execute();
    }

    public void testAttachFile() {
        try {
            FileUtils.copyFileToDirectory(service.getCbComputeMonthDataAttachFile1(), new File("D:\\"));
            FileUtils.copyFileToDirectory(service.getCbComputeMonthDataAttachFile2(), new File("D:\\"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
