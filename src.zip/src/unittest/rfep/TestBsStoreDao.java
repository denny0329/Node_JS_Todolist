package unittest.rfep;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.bnq.util.AppContext;
import com.gccs.bs.dao.hibernate.BsStoreDao;
import com.gccs.bs.model.BsStore;

import junit.framework.TestCase;

/**
 * 
 * @author T2482
 */
public class TestBsStoreDao extends TestCase {
	private SessionFactory factory;

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		factory = (SessionFactory)AppContext.getBean("sessionFactory");
	}

	public void testFindByPK() {
		Session session = null;
		String storeId = "00606";
		String companyId = "1010";
		try {
			session = factory.openSession();
			
			BsStoreDao dao = new BsStoreDao();
			BsStore store = dao.findByPK(session, storeId, companyId);
			
			assertEquals("HOLA", store.getBsChannel().getChannelId());
			assertEquals("001", store.getAreaId());
			assertEquals("0222491188", store.getStoreTel());
			
		} finally {
			if(session != null) {
				session.close();
			}
		}
	}
}
