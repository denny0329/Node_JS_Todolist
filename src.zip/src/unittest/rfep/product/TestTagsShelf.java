package unittest.rfep.product;

import com.bnq.util.AppContext;
import com.gccs.bs.service.BsParaService;
import com.gccs.bs.service.BsSkuService;
import com.gccs.util.report.ReportUtils;
import com.rfep.product.bs.service.PdSkuService;
import com.rfep.product.bs.service.TransSkuVariationService;
import com.rfep.product.label.print.TagsShelfAction;
import com.rfep.rm.service.RmService;
import junit.framework.TestCase;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.rfep.product.label.print.TagsShelfAction.*;

public class TestTagsShelf extends TestCase {

    private ReportUtils reportUtils;
    private RmService rmService;
    private PdSkuService pdSkuService;
    private TransSkuVariationService transSkuVariationService;
    private BsParaService bsParaService;
    private BsSkuService bsSkuService;

    protected void setUp() throws Exception {
        super.setUp();
        reportUtils = (ReportUtils) AppContext.getBean("reportUtils");
        rmService = (RmService) AppContext.getBean("rmService");
        pdSkuService = (PdSkuService) AppContext.getBean("pdService");
        transSkuVariationService = (TransSkuVariationService) AppContext.getBean("transSkuVariationService");
        bsParaService = (BsParaService) AppContext.getBean("bsParaService");
        bsSkuService = (BsSkuService) AppContext.getBean("bsSkuService");
    }

    //TYPE=1(HOLA_SHELF_ROW_REPORT)
    public void testType1() throws Exception {
        String jasperFilePath = "D:\\Hola_A4_report.jasper";
        String outputFilePath = "D:\\test1.pdf";
        testReportLaserA4(jasperFilePath, outputFilePath, "1", false);
    }

    //TYPE=2(A4_report_5_8X10)
    public void testType2() throws Exception {
        String jasperFilePath = "D:\\A4_report_5_8X10.jasper";
        String outputFilePath = "D:\\test2.pdf";
        testReportLaserA4(jasperFilePath, outputFilePath, "2", false);
    }

    //TYPE=3(A4_report_5_8X5_8)
    public void testType3() throws Exception {
        String jasperFilePath = "D:\\A4_report_5_8X5_8.jasper";
        String outputFilePath = "D:\\test3.pdf";
        testReportLaserA4(jasperFilePath, outputFilePath, "3", false);
    }

    //TYPE=4(A4_report_4X5)
    public void testType4() throws Exception {
        String jasperFilePath = "D:\\A4_report_4X5.jasper";
        String outputFilePath = "D:\\test4.pdf";
        testReportLaserA4(jasperFilePath, outputFilePath, "4", false);
    }

    //TYPE=5(A4_qrCode_report_2_6X6)
    public void testType5() throws Exception {
        String jasperFilePath = "D:\\A4_qrCode_report_2_6X6.jasper";
        String outputFilePath = "D:\\test5.pdf";
        testReportLaserA4(jasperFilePath, outputFilePath, "5", false);
    }

    public void testReportLaserA4(String jasperFilePath, String outputFilePath, String labelType, boolean dataOrientation) throws Exception {
        TagsShelfAction action = new TagsShelfAction();
        String eposType = "LASERSKU";
        String eventType = "0";
        String rePrice = "0";
        String locationNo = "1";
        Map parameterMap = new HashMap();
        parameterMap.put("reportType", "2");
        parameterMap.put("exportType", "1");
        parameterMap.put("contentDisposition", "2");
        parameterMap.put("PrintOrientation", "PORTRAIT");

        Map<String, Map<String, String>> eposPrintTemp = new HashMap<>();
        Map<String, String> skuMap = new HashMap<>();
        skuMap.put("label_laser_5", "1");
        skuMap.put("label_laser_4", "1");
        skuMap.put("label_laser_3", "1");
        skuMap.put("label_laser_2", "1");
        skuMap.put("label_laser_1", "1");
        skuMap.put("seqNo", "1");
        skuMap.put("upc", "2001605604110");
        skuMap.put("storeId", "00700");
        skuMap.put("sku", "016056041");
        skuMap.put("deptOid", "28f372564dc54956a99e6fcc77deaadb");
        skuMap.put("channelId", "TLW");
        skuMap.put("eventNo", "");
        eposPrintTemp.put("016056041", skuMap);

        action.setReportUtils(this.reportUtils);
        action.setRmService(this.rmService);
        action.setPdSkuService(this.pdSkuService);
        action.setTransSkuVariationService(this.transSkuVariationService);
        action.setBsParaService(this.bsParaService);
        action.setBsSkuService(this.bsSkuService);
        action.setEposType(eposType);

        Map<String, Map<String, List>> labelTypeMap = action.printLaserTag(eposPrintTemp, eventType, rePrice, locationNo, labelType, NOT_PRINT_ALL_LASER_TAG, dataOrientation);

        //列印報表
        if (labelTypeMap.get(labelType).get(TYPE).size() > 0 && "0".equals(eventType)) {
            exportFromJasper(jasperFilePath, outputFilePath, labelTypeMap.get(labelType).get(TYPE), parameterMap);
        } else {
            if (labelTypeMap.get(labelType).get(UN_TYPE).size() > 0 && !"1".equals(eventType)) {
                exportFromJasper(jasperFilePath, outputFilePath, labelTypeMap.get(labelType).get(UN_TYPE), parameterMap);
            }
            if (labelTypeMap.get(labelType).get(ALL_TYPE).size() > 0 && !"2".equals(eventType)) {
                exportFromJasper(jasperFilePath, outputFilePath, labelTypeMap.get(labelType).get(ALL_TYPE), parameterMap);
            }
        }
        System.out.println("finish!");
    }

    public void exportFromJasper(String jasperFilePath, String outputFilePath, List list, Map parameterMap) throws Exception {
        InputStream jasperInputStream = new FileInputStream(jasperFilePath);
        JRBeanCollectionDataSource ds = new JRBeanCollectionDataSource(list);
        JasperPrint jasperPrint = JasperFillManager.fillReport(jasperInputStream, parameterMap, ds);
        new FileOutputStream(outputFilePath).write(JasperExportManager.exportReportToPdf(jasperPrint));
    }
}
