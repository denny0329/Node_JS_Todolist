/**
 * @(#)TestOMSBSSKUPG.java.java May 11, 2015
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest.rfep;

import java.io.File;

import org.hibernate.SessionFactory;

import com.bnq.util.AppContext;
import com.rfep.dataex.mm.inbound.OMSBSSKUPG;
import com.rfep.product.bs.dao.hibernate.BsSkuStoreDao;
import com.rfep.product.bs.model.BsSkuStore;

import junit.framework.TestCase;

/**
 * @author T2482
 */
public class TestOMSBSSKUPG extends TestCase {
	private BsSkuStoreDao dao;
	private String storeId = "01200";
	private String sku = "016047548";
	private BsSkuStore origObj;

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		dao = (BsSkuStoreDao)AppContext.getBean("bsSkuStoreDao");
		dao.setSessionFactory((SessionFactory)AppContext.getBean("sessionFactory"));
		origObj = dao.find(storeId, sku);
	}
	
	@Override
	protected void tearDown() throws Exception {
		super.tearDown();
		dao.updateObject(origObj);
	}

	public void testExecuteForNoUpdate() {
		File file = new File("C:\\OMS_TEST\\OMSBSSKUPG_201505102020583_noUpdate.csv");
		OMSBSSKUPG target = new OMSBSSKUPG();
		target.execute(file);
		
		BsSkuStore srcObj = dao.find(storeId, sku);
		assertEquals(origObj.getBayNo(), srcObj.getBayNo());
		assertEquals(origObj.getLfnr(), srcObj.getLfnr());
		assertEquals(origObj.getLocation(), srcObj.getLocation());
		assertEquals(origObj.getProjectId(), srcObj.getProjectId());
		assertEquals(origObj.getBand(), srcObj.getBand());
	}
	
	public void testExecuteForUpdBayNo() {
		File file = new File("C:\\OMS_TEST\\OMSBSSKUPG_201505102020583_updBayNo.csv");
		OMSBSSKUPG target = new OMSBSSKUPG();
		target.execute(file);
		
		BsSkuStore srcObj = dao.find(storeId, sku);
		assertEquals("06R06", srcObj.getBayNo());
		assertEquals(origObj.getLfnr(), srcObj.getLfnr());
		assertEquals(origObj.getLocation(), srcObj.getLocation());
		assertEquals(origObj.getProjectId(), srcObj.getProjectId());
		assertEquals(origObj.getBand(), srcObj.getBand());
	}
	
	public void testExecuteForUpdLfnr() {
		File file = new File("C:\\OMS_TEST\\OMSBSSKUPG_201505102020583_updLfnr.csv");
		OMSBSSKUPG target = new OMSBSSKUPG();
		target.execute(file);
		
		BsSkuStore srcObj = dao.find(storeId, sku);
		assertEquals(origObj.getBayNo(), srcObj.getBayNo());
		assertEquals(9.5d, srcObj.getLfnr());
		assertEquals(origObj.getLocation(), srcObj.getLocation());
		assertEquals(origObj.getProjectId(), srcObj.getProjectId());
		assertEquals(origObj.getBand(), srcObj.getBand());
	}
	
	public void testExecuteForUpdLocation() {
		File file = new File("C:\\OMS_TEST\\OMSBSSKUPG_201505102020583_updLocation.csv");
		OMSBSSKUPG target = new OMSBSSKUPG();
		target.execute(file);
		
		BsSkuStore srcObj = dao.find(storeId, sku);
		assertEquals(origObj.getBayNo(), srcObj.getBayNo());
		assertEquals(origObj.getLfnr(), srcObj.getLfnr());
		assertEquals("29", srcObj.getLocation());
		assertEquals(origObj.getProjectId(), srcObj.getProjectId());
		assertEquals(origObj.getBand(), srcObj.getBand());
	}
	
	public void testExecuteForUpdProjectId() {
		File file = new File("C:\\OMS_TEST\\OMSBSSKUPG_201505102020583_updProjectId.csv");
		OMSBSSKUPG target = new OMSBSSKUPG();
		target.execute(file);
		
		BsSkuStore srcObj = dao.find(storeId, sku);
		assertEquals(origObj.getBayNo(), srcObj.getBayNo());
		assertEquals(origObj.getLfnr(), srcObj.getLfnr());
		assertEquals(origObj.getLocation(), srcObj.getLocation());
		assertEquals("01010305", srcObj.getProjectId());
		assertEquals(origObj.getBand(), srcObj.getBand());
	}
	
	public void testExecuteForUpdBand() {
		File file = new File("C:\\OMS_TEST\\OMSBSSKUPG_201505102020583_updBand.csv");
		OMSBSSKUPG target = new OMSBSSKUPG();
		target.execute(file);
		
		BsSkuStore srcObj = dao.find(storeId, sku);
		assertEquals(origObj.getBayNo(), srcObj.getBayNo());
		assertEquals(origObj.getLfnr(), srcObj.getLfnr());
		assertEquals(origObj.getLocation(), srcObj.getLocation());
		assertEquals(origObj.getProjectId(), srcObj.getProjectId());
		assertEquals("2", srcObj.getBand());
	}
	
	public void testExecuteForUpdBayNoNull() {
		File file = new File("C:\\OMS_TEST\\OMSBSSKUPG_201505102020583_updBayNoNull.csv");
		OMSBSSKUPG target = new OMSBSSKUPG();
		target.execute(file);
		
		BsSkuStore srcObj = dao.find(storeId, sku);
		assertNull(srcObj.getBayNo());
		assertEquals(origObj.getLfnr(), srcObj.getLfnr());
		assertEquals(origObj.getLocation(), srcObj.getLocation());
		assertEquals(origObj.getProjectId(), srcObj.getProjectId());
		assertEquals(origObj.getBand(), srcObj.getBand());
	}
	
	public void testExecuteForUpdLfnrNull() {
		File file = new File("C:\\OMS_TEST\\OMSBSSKUPG_201505102020583_updLfnrNull.csv");
		OMSBSSKUPG target = new OMSBSSKUPG();
		target.execute(file);
		
		BsSkuStore srcObj = dao.find(storeId, sku);
		assertEquals(origObj.getBayNo(), srcObj.getBayNo());
		assertNull(srcObj.getLfnr());
		assertEquals(origObj.getLocation(), srcObj.getLocation());
		assertEquals(origObj.getProjectId(), srcObj.getProjectId());
		assertEquals(origObj.getBand(), srcObj.getBand());
	}
	
	public void testExecuteForUpdLocationNull() {
		File file = new File("C:\\OMS_TEST\\OMSBSSKUPG_201505102020583_updLocationNull.csv");
		OMSBSSKUPG target = new OMSBSSKUPG();
		target.execute(file);
		
		BsSkuStore srcObj = dao.find(storeId, sku);
		assertEquals(origObj.getBayNo(), srcObj.getBayNo());
		assertEquals(origObj.getLfnr(), srcObj.getLfnr());
		assertNull(srcObj.getLocation());
		assertEquals(origObj.getProjectId(), srcObj.getProjectId());
		assertEquals(origObj.getBand(), srcObj.getBand());
	}
	
	public void testExecuteForUpdProjectIdNull() {
		File file = new File("C:\\OMS_TEST\\OMSBSSKUPG_201505102020583_updProjectIdNull.csv");
		OMSBSSKUPG target = new OMSBSSKUPG();
		target.execute(file);
		
		BsSkuStore srcObj = dao.find(storeId, sku);
		assertEquals(origObj.getBayNo(), srcObj.getBayNo());
		assertEquals(origObj.getLfnr(), srcObj.getLfnr());
		assertEquals(origObj.getLocation(), srcObj.getLocation());
		assertNull(srcObj.getProjectId());
		assertEquals(origObj.getBand(), srcObj.getBand());
	}
	
	public void testExecuteForUpdBandNull() {
		File file = new File("C:\\OMS_TEST\\OMSBSSKUPG_201505102020583_updBandNull.csv");
		OMSBSSKUPG target = new OMSBSSKUPG();
		target.execute(file);
		
		BsSkuStore srcObj = dao.find(storeId, sku);
		assertEquals(origObj.getBayNo(), srcObj.getBayNo());
		assertEquals(origObj.getLfnr(), srcObj.getLfnr());
		assertEquals(origObj.getLocation(), srcObj.getLocation());
		assertEquals(origObj.getProjectId(), srcObj.getProjectId());
		assertNull(srcObj.getBand());
	}
}