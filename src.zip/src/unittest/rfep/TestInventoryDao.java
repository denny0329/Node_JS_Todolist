package unittest.rfep;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.bnq.util.AppContext;
import com.rfep.iv.dao.InventoryDao;
import com.rfep.iv.model.IvStoreInventory;

import junit.framework.TestCase;

/**
 * 
 * @author T2482
 */
public class TestInventoryDao extends TestCase {
	private SessionFactory factory;

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		factory = (SessionFactory)AppContext.getBean("sessionFactory");
	}
	
	public void testFindByStoreIdSku() {
		Session session = null;
		String storeId = "00701";
		String sku = "000184541";
		
		try {
			session = factory.openSession();
			InventoryDao dao = new InventoryDao();
			IvStoreInventory result = dao.findByStoreIdSku(session, storeId, sku);
			
			assertEquals("CASA", result.getChannelId());
		} finally {
			if(session != null) {
				session.close();
			}
		}
	}
}