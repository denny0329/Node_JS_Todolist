package unittest.rfep;

import java.util.Calendar;

import com.bnq.util.AppContext;
import com.rfep.product.bs.model.PriceCondition;
import com.rfep.product.bs.model.PriceModel;
import com.rfep.product.bs.model.RegularPriceCondition;
import com.rfep.product.bs.service.CostPriceConditionService;
import com.rfep.product.bs.service.PriceConditionService;
import com.rfep.product.bs.service.RegularPriceConditionService;
import com.rfep.product.job.UpdateConditionJob;

import junit.framework.TestCase;

/**
 * @author T2482
 *
 */
public class TestUpdateConditionJob extends TestCase {
	private UpdateConditionJob job;
	private PriceCondition priceCondition1;
	private PriceCondition priceCondition2;
	private PriceModel PriceModel;
	private RegularPriceCondition RegularPriceCondition1;
	private RegularPriceCondition RegularPriceCondition2;
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
		this.job = new UpdateConditionJob();
		this.job.setCostPriceService((CostPriceConditionService)AppContext.getBean("costConditionService"));
		this.job.setPosPriceService((PriceConditionService)AppContext.getBean("conditionService"));
		this.job.setRegularPriceService((RegularPriceConditionService)AppContext.getBean("regularConditionService"));
	}

	public void testExecute() {
		try {
			this.job.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	

	public void testPriceConditionComparEventAllNull() {
		try {
			//測試priceCondition1.eventNo  = null ,priceCondition2.eventNo=null,
			//執行compareSameEvent(),兩者sku有值,兩者channelId有值,執行dateCompare();
			//檢查兩者startDate是否相等,若相等則priceCondition1 createDate 在priceCondition2 createDate 之後回傳priceCondition1,反之回傳priceCondition2
			
			 Calendar calStartDate  = Calendar.getInstance();
			 calStartDate.set(Calendar.MONTH, 11);
			 calStartDate.set(Calendar.DAY_OF_MONTH, 10);
			 Calendar calEndDate  = Calendar.getInstance();
			 calEndDate.set(Calendar.YEAR, 13);
			 calEndDate.set(Calendar.MONTH, 1);
			 calEndDate.set(Calendar.DAY_OF_MONTH, 1);
			 Calendar calCreateDate  = Calendar.getInstance();
			 calCreateDate.set(Calendar.MONTH, 12);
			 calCreateDate.set(Calendar.DAY_OF_MONTH, 7);
			 priceCondition1 = new PriceCondition();
			 priceCondition1.setOid("ab15ebb333f54dd0bef882fb24ca2f5d");
			 priceCondition1.setPriceType("Z100");
			 priceCondition1.setChannelId("A0");
			 priceCondition1.setSku("000283219");
			 priceCondition1.setUnit("STR");
			// priceCondition1.setEventNo("0002005777");
			 priceCondition1.setStartDate(calStartDate.getTime());
			 priceCondition1.setEndDate(calEndDate.getTime());
			 priceCondition1.setPriority(4);
			 priceCondition1.setCreateTime(calCreateDate.getTime());
			 
			 priceCondition2 = new PriceCondition();
			 priceCondition2.setOid("9d59781abc1246b4b9991bab2abdd756");
			 priceCondition2.setPriceType("Z100");
			 priceCondition2.setChannelId("A0");
			 priceCondition2.setSku("000320734");
			 priceCondition2.setUnit("PKG");
			// priceCondition2.setEventNo("0002005802");
			 priceCondition2.setStartDate(calStartDate.getTime());
			 priceCondition2.setEndDate(calEndDate.getTime());
			 priceCondition2.setPriority(4);
			 priceCondition2.setCreateTime(calCreateDate.getTime());			 
			
			 PriceModel = priceCondition1.compare(priceCondition2);
			 assertEquals("9d59781abc1246b4b9991bab2abdd756", PriceModel.getOid());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void testPriceConditionComparEventAllNotNull() {
		try {
			//測試priceCondition1.eventNo  = 0002005777 ,priceCondition2.eventNo=0002005802,
			//若eventNo相等執行compareSameEvent(),反則執行compareNotSameEvent,
			
			 Calendar calStartDate  = Calendar.getInstance();
			 calStartDate.set(Calendar.MONTH, 11);
			 calStartDate.set(Calendar.DAY_OF_MONTH, 10);
			 Calendar calEndDate  = Calendar.getInstance();
			 calEndDate.set(Calendar.YEAR, 13);
			 calEndDate.set(Calendar.MONTH, 1);
			 calEndDate.set(Calendar.DAY_OF_MONTH, 1);
			 Calendar calCreateDate  = Calendar.getInstance();
			 calCreateDate.set(Calendar.MONTH, 12);
			 calCreateDate.set(Calendar.DAY_OF_MONTH, 7);
			 priceCondition1 = new PriceCondition();
			 priceCondition1.setOid("ab15ebb333f54dd0bef882fb24ca2f5d");
			 priceCondition1.setPriceType("Z100");
			 priceCondition1.setChannelId("A0");
			 priceCondition1.setSku("000283219");
			 priceCondition1.setUnit("STR");
			 priceCondition1.setEventNo("0002005777");
			 priceCondition1.setStartDate(calStartDate.getTime());
			 priceCondition1.setEndDate(calEndDate.getTime());
			 priceCondition1.setPriority(4);
			 priceCondition1.setCreateTime(calCreateDate.getTime());
			 
			 priceCondition2 = new PriceCondition();
			 priceCondition2.setOid("9d59781abc1246b4b9991bab2abdd756");
			 priceCondition2.setPriceType("Z100");
			 priceCondition2.setChannelId("A0");
			 priceCondition2.setSku("000320734");
			 priceCondition2.setUnit("PKG");
			 priceCondition2.setEventNo("0002005802");
			 priceCondition2.setStartDate(calStartDate.getTime());
			 priceCondition2.setEndDate(calEndDate.getTime());
			 priceCondition2.setPriority(5);
			 priceCondition2.setCreateTime(calCreateDate.getTime());
			 			
			 PriceModel = priceCondition1.compare(priceCondition2);
			 assertEquals("ab15ebb333f54dd0bef882fb24ca2f5d", PriceModel.getOid());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void testPriceConditionCompareEvent() {
		try {
			//測試priceCondition1.eventNo  = 0002005777 ,priceCondition2.eventNo=0002005777,
			//若eventNo相等執行compareSameEvent(),反則執行compareNotSameEvent,
			
			 Calendar calStartDate  = Calendar.getInstance();
			 calStartDate.set(Calendar.MONTH, 11);
			 calStartDate.set(Calendar.DAY_OF_MONTH, 10);
			 Calendar calEndDate  = Calendar.getInstance();
			 calEndDate.set(Calendar.YEAR, 13);
			 calEndDate.set(Calendar.MONTH, 1);
			 calEndDate.set(Calendar.DAY_OF_MONTH, 1);
			 Calendar calCreateDate  = Calendar.getInstance();
			 calCreateDate.set(Calendar.MONTH, 12);
			 calCreateDate.set(Calendar.DAY_OF_MONTH, 7);
			 priceCondition1 = new PriceCondition();
			 priceCondition1.setOid("ab15ebb333f54dd0bef882fb24ca2f5d");
			 priceCondition1.setPriceType("Z100");
			 priceCondition1.setChannelId("A0");
			 priceCondition1.setSku("000283219");
			 priceCondition1.setUnit("STR");
			 priceCondition1.setEventNo("0002005777");
			 priceCondition1.setStartDate(calStartDate.getTime());
			 priceCondition1.setEndDate(calEndDate.getTime());
			 priceCondition1.setPriority(4);
			 priceCondition1.setCreateTime(calCreateDate.getTime());
			 
			 priceCondition2 = new PriceCondition();
			 priceCondition2.setOid("9d59781abc1246b4b9991bab2abdd756");
			 priceCondition2.setPriceType("Z100");
			 priceCondition2.setChannelId("A0");
			 priceCondition2.setSku("000320734");
			 priceCondition2.setUnit("PKG");
			 priceCondition2.setEventNo("0002005777");
			 priceCondition2.setStartDate(calStartDate.getTime());
			 priceCondition2.setEndDate(calEndDate.getTime());
			 priceCondition2.setPriority(5);
			 priceCondition2.setCreateTime(calCreateDate.getTime());
			 		
			 PriceModel = priceCondition1.compare(priceCondition2);
			 assertEquals("9d59781abc1246b4b9991bab2abdd756", PriceModel.getOid());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void testComparePriceCondition1Null() {
		try {
			//測試priceCondition1.eventNo  = null ,priceCondition2.eventNo=0002005777,
			//若eventNo相等執行compareSameEvent(),反則執行compareNotSameEvent,
			
			 Calendar calStartDate  = Calendar.getInstance();
			 calStartDate.set(Calendar.MONTH, 11);
			 calStartDate.set(Calendar.DAY_OF_MONTH, 10);
			 Calendar calEndDate  = Calendar.getInstance();
			 calEndDate.set(Calendar.YEAR, 13);
			 calEndDate.set(Calendar.MONTH, 1);
			 calEndDate.set(Calendar.DAY_OF_MONTH, 1);
			 Calendar calCreateDate  = Calendar.getInstance();
			 calCreateDate.set(Calendar.MONTH, 12);
			 calCreateDate.set(Calendar.DAY_OF_MONTH, 7);
			 priceCondition1 = new PriceCondition();
			 priceCondition1.setOid("ab15ebb333f54dd0bef882fb24ca2f5d");
			 priceCondition1.setPriceType("Z100");
			 priceCondition1.setChannelId("A0");
			 priceCondition1.setSku("000283219");
			 priceCondition1.setUnit("STR");
			// priceCondition1.setEventNo("0002005777");
			 priceCondition1.setStartDate(calStartDate.getTime());
			 priceCondition1.setEndDate(calEndDate.getTime());
			 priceCondition1.setPriority(5);
			 priceCondition1.setCreateTime(calCreateDate.getTime());
			 
			 priceCondition2 = new PriceCondition();
			 priceCondition2.setOid("9d59781abc1246b4b9991bab2abdd756");
			 priceCondition2.setPriceType("Z100");
			 priceCondition2.setChannelId("A0");
			 priceCondition2.setSku("000320734");
			 priceCondition2.setUnit("PKG");
			 priceCondition2.setEventNo("0002005777");
			 priceCondition2.setStartDate(calStartDate.getTime());
			 priceCondition2.setEndDate(calEndDate.getTime());
			 priceCondition2.setPriority(4);
			 priceCondition2.setCreateTime(calCreateDate.getTime());
			 		
			 PriceModel = priceCondition1.compare(priceCondition2);
			 assertEquals("9d59781abc1246b4b9991bab2abdd756", PriceModel.getOid());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void testRegularPriceCondition() {
		try {
			//測試compare
			
			 Calendar calStartDate  = Calendar.getInstance();
			 calStartDate.set(Calendar.MONTH, 11);
			 calStartDate.set(Calendar.DAY_OF_MONTH, 10);
			 Calendar calEndDate  = Calendar.getInstance();
			 calEndDate.set(Calendar.YEAR, 13);
			 calEndDate.set(Calendar.MONTH, 1);
			 calEndDate.set(Calendar.DAY_OF_MONTH, 1);
			 Calendar calCreateDate  = Calendar.getInstance();
			 calCreateDate.set(Calendar.MONTH, 12);
			 calCreateDate.set(Calendar.DAY_OF_MONTH, 7);
			 RegularPriceCondition1 = new RegularPriceCondition();
			 RegularPriceCondition1.setOid("ab15ebb333f54dd0bef882fb24ca2f5d");
			 RegularPriceCondition1.setPriceType("Z100");

			 RegularPriceCondition1.setSku("000283219");
			 RegularPriceCondition1.setUnit("STR");
			 RegularPriceCondition1.setStartDate(calStartDate.getTime());
			 RegularPriceCondition1.setEndDate(calEndDate.getTime());
			 RegularPriceCondition1.setCreateTime(calCreateDate.getTime());
			 
			 RegularPriceCondition2 = new RegularPriceCondition();
			 RegularPriceCondition2.setOid("9d59781abc1246b4b9991bab2abdd756");
			 RegularPriceCondition2.setPriceType("Z100");
			 RegularPriceCondition2.setChannelId("A0");
			 RegularPriceCondition2.setSku("000320734");
			 RegularPriceCondition2.setUnit("PKG");
			 RegularPriceCondition2.setEventNo("0002005777");
			 RegularPriceCondition2.setStartDate(calStartDate.getTime());
			 RegularPriceCondition2.setEndDate(calEndDate.getTime());
			 RegularPriceCondition2.setCreateTime(calCreateDate.getTime());
			 		
			 PriceModel = RegularPriceCondition1.compare(RegularPriceCondition2);
			 assertEquals("9d59781abc1246b4b9991bab2abdd756", PriceModel.getOid());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
