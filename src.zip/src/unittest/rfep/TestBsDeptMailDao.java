/**
 * @(#)TestBsDeptMailDao.java.java Dec 24, 2014
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest.rfep;

import java.util.List;

import junit.framework.TestCase;

import org.hibernate.SessionFactory;

import com.bnq.bs.dao.hibernate.BsDeptMailDAO;
import com.bnq.bs.model.BsDeptMail;
import com.bnq.util.AppContext;

/**
 * @author T2482
 *
 */
public class TestBsDeptMailDao extends TestCase {
	private BsDeptMailDAO dao = new BsDeptMailDAO();

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		dao.setSessionFactory((SessionFactory)AppContext.getBean("sessionFactory"));
	}

	public void testFindByDeptId() {
		List<BsDeptMail> list = dao.findByDeptId("1010", "00100");
		
		assertEquals(5, list.size());
		for(BsDeptMail bsDeptMail : list) {
			if("HOPT".equals(bsDeptMail.getId().getBsTitle().getTitleId())) {
				fail();
			}
		}
	}
}
