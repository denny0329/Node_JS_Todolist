package unittest.job;

import junit.framework.TestCase;
import com.bnq.util.AppContext;
import com.rfep.nr.dao.hibernate.NrDao;
import com.rfep.nr.service.NrService;
import com.rfep.util.sys.dao.SysJobDao;
import com.trg.oms.job.NrEcDwJob;

public class TestNrEcDwJob extends TestCase {
	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
    private NrEcDwJob job=new NrEcDwJob();
	protected void setUp() throws Exception {
		super.setUp();
		NrDao nrDao=(NrDao)AppContext.getBean("nrDao");
		NrService nrService=(NrService)AppContext.getBean("nrService");
		SysJobDao sysJobDao=(SysJobDao)AppContext.getBean("sysJobDao");
        
		job.setNrDao(nrDao);
		job.setNrService(nrService);
		job.setSysJobDao(sysJobDao);

	}//setUp

	public void testJob() {
		try {
			job.execute();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}//testJob

	/* rollback data
	 update NR_DATA_CTRL
     set PROCESS_DATE = to_date(sysdate), STATUS=-90, EXE_TIME=SYSDATE, 
        SALE_DATE=to_date(sysdate), START_TIME=null,END_TIME=null,SD_START_TIME=null,SD_END_TIME=null,
        FI_START_TIME=null,FI_END_TIME=null, ROW_COUNT=null
     where STORE_ID ='00696' and TRACKING_NO='SD006962017111200001' 
    ;
    DELETE FROM AUTO_INV_CHANGE WHERE CREATE_TIME = SYSDATE; 
	 */
}
