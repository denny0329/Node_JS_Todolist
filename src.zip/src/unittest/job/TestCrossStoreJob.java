package unittest.job;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.gccs.bs.dao.hibernate.BsStoreDao;
import com.gccs.bs.service.BsParaService;
import com.rfep.bs.dao.hibernate.BsParaDao;
import com.rfep.iv.dao.AutoInvChangeDao;
import com.rfep.iv.dao.InventoryChangeDao;
import com.rfep.iv.dao.InventoryDao;
import com.rfep.iv.dao.IvGoodsMvDao;
import com.rfep.iv.service.AutoInvChangeService;
import com.rfep.iv.service.IvGoodsMvService;
import com.rfep.nr.dao.hibernate.NrDao;
import com.rfep.nr.service.NrService;
import com.rfep.product.bs.dao.hibernate.BsSkuUnitDao;
import com.rfep.util.sys.dao.SysJobDao;
import com.trg.oms.job.CrossStoreJob;

public class TestCrossStoreJob extends TestCase {
	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
    private CrossStoreJob job=new CrossStoreJob();
	protected void setUp() throws Exception {
		super.setUp();
		NrDao nrDao=(NrDao)AppContext.getBean("nrDao");
		NrService nrService=(NrService)AppContext.getBean("nrService");
		AutoInvChangeService autoInvChangeService=(AutoInvChangeService)AppContext.getBean("autoInvChangeService");
		AutoInvChangeDao autoInvChangeDao=(AutoInvChangeDao)AppContext.getBean("autoInvChangeDao");
		BsStoreDao bsStoreDao=(BsStoreDao)AppContext.getBean("bsStoreDao");
		InventoryChangeDao inventoryChangeDao=(InventoryChangeDao)AppContext.getBean("inventoryChangeDao");
		InventoryDao inventoryDao=(InventoryDao)AppContext.getBean("inventoryDao");
		IvGoodsMvService ivGoodsMvService=(IvGoodsMvService)AppContext.getBean("ivGoodsMvService");
		IvGoodsMvDao ivGoodsMvDao=(IvGoodsMvDao)AppContext.getBean("ivGoodsMvDao");
		BsSkuUnitDao bsSkuUnitDao=(BsSkuUnitDao)AppContext.getBean("bsSkuUnitDao");
		BsParaDao bsParaDao=(BsParaDao)AppContext.getBean("bsParaDao");
		BsParaService bsParaService=(BsParaService)AppContext.getBean("bsParaService");
		SysJobDao sysJobDao=(SysJobDao)AppContext.getBean("sysJobDao");
        
		job.setNrDao(nrDao);
		job.setNrService(nrService);
		job.setAutoInvChangeService(autoInvChangeService);
		job.setAutoInvChangeDao(autoInvChangeDao);
		job.setBsStoreDao(bsStoreDao);
		job.setInventoryChangeDao(inventoryChangeDao);
		job.setInventoryDao(inventoryDao);
		job.setIvGoodsMvService(ivGoodsMvService);
		job.setIvGoodsMvDao(ivGoodsMvDao);
		job.setBsSkuUnitDao(bsSkuUnitDao);
		job.setSysJobDao(sysJobDao);
		job.setBsParaDao(bsParaDao);
		job.setBsParaService(bsParaService);

	}//setUp

	public void testJob() {
		try {
			job.execute();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}//testJob

	/* rollback data
	 update NR_DATA_CTRL
     set PROCESS_DATE = to_date(sysdate), STATUS=-92, EXE_TIME=SYSDATE, 
        SALE_DATE=to_date(sysdate), START_TIME=null,END_TIME=null,SD_START_TIME=null,SD_END_TIME=null,
        FI_START_TIME=null,FI_END_TIME=null, ROW_COUNT=null
     where tracking_no='SD006962017111300001' and STORE_ID=00696
    ;
    delete from IV_STORE_INVENTORY_CHANGE where sku in (select sku from AUTO_INV_CHANGE where STORE_ID='02400') and PROGRAM_NAME='system';
    delete from IV_GOODS_MOVEMENT where XBLNR='WR52562412' and TCODE='MB11' and CREATE_TIME >= TO_DATE('2017/10/27', 'yyyy/mm/dd');
    delete from IV_GOODS_MOVEMENT_DTL where MST_OID in (select oid from IV_GOODS_MOVEMENT where XBLNR='WR52562412' and TCODE='MB11' and CREATE_TIME >= TO_DATE('2017/10/27', 'yyyy/mm/dd')); 
	 */
}
