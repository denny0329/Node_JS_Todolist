/**
 * @(#)TestSendDsNotifyMailJob.java.java Feb 18, 2016
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest.job;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.trg.oms.externalWS.epos.CallEposWebService;

/**
 * @author T2482
 */
public class TestSyncDisplayUPCJob extends TestCase {	

	public void testSyncDisplayUPCJob() {
		try {
			CallEposWebService service=(CallEposWebService)AppContext.getBean("callEposWebService");
			service.syncDisplayUPC();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}
