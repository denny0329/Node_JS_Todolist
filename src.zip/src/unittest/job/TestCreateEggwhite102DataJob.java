package unittest.job;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.util.sys.dao.SysJobDao;
import com.trg.oms.job.CreateEggwhite102DataJob;
import com.trg.oms.utils.dao.SysInfoDao;

public class TestCreateEggwhite102DataJob extends TestCase {
	
	public void testFile() {
		try {
			SysJobDao sysJobDao=(SysJobDao)AppContext.getBean("sysJobDao");
			SysInfoDao sysInfoDao=(SysInfoDao)AppContext.getBean("sysInfoDao");
			CreateEggwhite102DataJob job=new CreateEggwhite102DataJob();
			job.setSysInfoDao(sysInfoDao);
			job.setSysJobDao(sysJobDao);
			job.execute();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
