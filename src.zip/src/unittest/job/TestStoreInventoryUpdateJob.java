/**
 * @(#) TestStoreInventoryUpdateJob.java 2018/6/26
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest.job;

import com.bnq.util.AppContext;
import com.gccs.bs.dao.hibernate.BsSkuDao;
import com.rfep.iv.dao.InventoryDao;
import com.rfep.iv.job.StoreInventoryUpdateJob;
import com.rfep.iv.service.IInventoryService;
import com.rfep.iv.service.IvGoodsMvService;
import com.rfep.product.bs.dao.hibernate.BsSkuStoreDao;
import com.rfep.product.bs.service.PdSkuService;


import junit.framework.TestCase;

/**
 * @author T2586
 */
public class TestStoreInventoryUpdateJob extends TestCase{
	
	StoreInventoryUpdateJob job = new StoreInventoryUpdateJob();
	protected void setUp() throws Exception {
		super.setUp();
		InventoryDao inventoryDao = (InventoryDao)AppContext.getBean("inventoryDao");
		BsSkuDao bsSkuDao = (BsSkuDao)AppContext.getBean("bsSkuDao");
		BsSkuStoreDao bsSkuStoreDao = (BsSkuStoreDao)AppContext.getBean("bsSkuStoreDao");
		IInventoryService inventoryService = (IInventoryService)AppContext.getBean("inventoryService");
		PdSkuService pdService = (PdSkuService)AppContext.getBean("pdService");
		IvGoodsMvService ivGoodsMvService = (IvGoodsMvService)AppContext.getBean("ivGoodsMvService");
		job.setBsSkuDao(bsSkuDao);
		job.setBsSkuStoreDao(bsSkuStoreDao);
		job.setInventoryDao(inventoryDao);
		job.setInventoryService(inventoryService);
		job.setIvGoodsMvService(ivGoodsMvService);
		job.setPdService(pdService);
		
	}//s
	public void testFile() {
		try {
			job.execute();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
