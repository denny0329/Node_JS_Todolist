package unittest.job;

import junit.framework.TestCase;

import com.bnq.bs.dao.hibernate.BsDeptDAO;
import com.bnq.util.AppContext;
import com.rfep.bs.dao.hibernate.BsCostCenterDao;
import com.rfep.iv.dao.IvCodeDao;
import com.rfep.iv.disbursal.service.StoreDisbursalService;
import com.rfep.iv.job.StoreDisbursalJob;
import com.rfep.iv.service.InventoryService;
import com.rfep.product.bs.dao.hibernate.BsSkuStoreDao;
import com.rfep.util.sys.dao.SysEmailGroupDao;
import com.trg.oms.outside.dao.SomDao;
import com.trg.oms.utils.dao.OmsMailDao;


public class TestStoreDisbursalJob extends TestCase {
	
	public void testJob() {
		try {
			StoreDisbursalService sdService=(StoreDisbursalService)AppContext.getBean("storeDisbursalService");
			InventoryService inventoryService=(InventoryService)AppContext.getBean("inventoryService");
			SomDao somDao=(SomDao)AppContext.getBean("somDao");
			BsCostCenterDao bsCostCenterDao = (BsCostCenterDao)AppContext.getBean("bsCostCenterDao");
			BsSkuStoreDao bsSkuStoreDao=(BsSkuStoreDao)AppContext.getBean("bsSkuStoreDao");
			IvCodeDao ivCodeDao=(IvCodeDao)AppContext.getBean("ivCodeDao");
			SysEmailGroupDao sysEmailGroupDao = (SysEmailGroupDao)AppContext.getBean("sysEmailGroupDao");
			BsDeptDAO bsDeptDAO = (BsDeptDAO)AppContext.getBean("bsDeptDAO");
			OmsMailDao omsMailDao = (OmsMailDao)AppContext.getBean("omsMailDao");
			StoreDisbursalJob job=new StoreDisbursalJob();
			
			job.setSdService(sdService);
			job.setInventoryService(inventoryService);
			job.setBsCostCenterDao(bsCostCenterDao);
			job.setSomDao(somDao);
			job.setBsSkuStoreDao(bsSkuStoreDao);
			job.setIvCodeDao(ivCodeDao);
			job.setSysEmailGroupDao(sysEmailGroupDao);
			job.setBsDeptDAO(bsDeptDAO);
			job.setOmsMailDao(omsMailDao);
			
			job.execute();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
