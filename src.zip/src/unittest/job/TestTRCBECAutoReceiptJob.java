package unittest.job;

import com.trg.oms.externalWS.som.CallSomWebService;
import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.iv.dao.InventoryDao;
import com.rfep.iv.service.InventoryService;
import com.rfep.iv.service.IvGoodsMvService;
import com.rfep.iv.sto.dao.hibernate.StoDao;
import com.rfep.util.sys.dao.SysJobDao;
import com.trg.oms.job.TRCBECAutoReceiptJob;
import org.springframework.context.ApplicationContext;

public class TestTRCBECAutoReceiptJob extends TestCase {
	
	public void testFile() {
		try {
			SysJobDao sysJobDao=(SysJobDao)AppContext.getBean("sysJobDao");
			IvGoodsMvService ivGoodsMvService=(IvGoodsMvService)AppContext.getBean("ivGoodsMvService");
			InventoryService inventoryService=(InventoryService)AppContext.getBean("inventoryService");
			StoDao stoDao=(StoDao)AppContext.getBean("stoDao");
			InventoryDao inventoryDao=(InventoryDao)AppContext.getBean("inventoryDao");
			CallSomWebService callSomWebService= (CallSomWebService)AppContext.getBean("callSomWebService");
			TRCBECAutoReceiptJob job=new TRCBECAutoReceiptJob();
			job.setSysJobDao(sysJobDao);
			job.setIvGoodsMvService(ivGoodsMvService);
			job.setInventoryService(inventoryService);
			job.setInventoryDao(inventoryDao);
			job.setStoDao(stoDao);
			job.setCallSomWebService(callSomWebService);
			job.execute();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
