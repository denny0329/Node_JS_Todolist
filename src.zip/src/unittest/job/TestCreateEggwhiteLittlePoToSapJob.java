package unittest.job;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.util.sys.dao.SysJobDao;
import com.trg.oms.job.CreateEggwhiteLittlePoToSapJob;

public class TestCreateEggwhiteLittlePoToSapJob extends TestCase {
	
	public void testFile() {
		try {
			SysJobDao sysJobDao=(SysJobDao)AppContext.getBean("sysJobDao");
			CreateEggwhiteLittlePoToSapJob job=new CreateEggwhiteLittlePoToSapJob();
			job.setSysJobDao(sysJobDao);
			job.execute();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
