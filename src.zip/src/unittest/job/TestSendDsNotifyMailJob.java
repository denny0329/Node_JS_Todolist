/**
 * @(#)TestSendDsNotifyMailJob.java.java Feb 18, 2016
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest.job;

import com.bnq.util.AppContext;
import com.rfep.bs.dao.hibernate.BsParaDao;
import com.rfep.ds.dao.DsContCheckDAO;
import com.rfep.util.sys.dao.SysEmailGroupDao;
import com.trg.oms.job.SendDsNotifyMailJob;

import junit.framework.TestCase;

/**
 * @author T2482
 */
public class TestSendDsNotifyMailJob extends TestCase {
	private SendDsNotifyMailJob job = new SendDsNotifyMailJob();
	
	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		job.setBsParaDao((BsParaDao)AppContext.getBean("bsParaDao"));
		job.setDsContCheckDAO((DsContCheckDAO)AppContext.getBean("dsContCheckDAO"));
		job.setSysEmailGroupDao((SysEmailGroupDao)AppContext.getBean("sysEmailGroupDao"));
	}

	public void testCantConnectContract() {
		// 每次測試後會在 RFEP 目錄下產生 xls 檔，記得要移除
		try {
			job.cantConnectContract();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void testExtendOldContract() {
		// 每次測試後會在 RFEP 目錄下產生 xls 檔，記得要移除
		try {
			job.extendOldContract();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
