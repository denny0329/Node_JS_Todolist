package unittest;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import com.rfep.nm.util.BaseSapRfc;

public class TestOutbound extends TestCase  {
	public TestOutbound() {
     //  super();
    }
   	
	/*
	public void testOMSDSB2B03() {
		//bean 
		//AppContext.getBean(name) ;
		//ServletContextWrapper servletContextWrapper = (ServletContextWrapper)AppContext.getBean("servletCtxWrapper");
		OMSDSB2B03  a = new OMSDSB2B03();
        a.execute() ;
    }
    
	
	public void testOMSDSB2B04() {
		//bean 
		//AppContext.getBean(name) ;
		//ServletContextWrapper servletContextWrapper = (ServletContextWrapper)AppContext.getBean("servletCtxWrapper");
		OMSDSB2B04  a = new OMSDSB2B04();
        a.execute() ;
    }
	
	
	public void testOMSDSSAP06() {
		//bean 
		//AppContext.getBean(name) ;
		//ServletContextWrapper servletContextWrapper = (ServletContextWrapper)AppContext.getBean("servletCtxWrapper");
		OMSDSSAP06  a = new OMSDSSAP06();
        a.execute() ;
    }
	
	public void testCRMNMB2B01() {
		//bean 
		//AppContext.getBean(name) ;
		//ServletContextWrapper servletContextWrapper = (ServletContextWrapper)AppContext.getBean("servletCtxWrapper");
		CRMNMB2B01  a = new CRMNMB2B01();
        a.execute() ;
    }
	*/
	
	/*
	public void testOMSSTKTKSD() {
		//bean 
		//AppContext.getBean(name) ;
		//ServletContextWrapper servletContextWrapper = (ServletContextWrapper)AppContext.getBean("servletCtxWrapper");
		OMSSTKTKSD  a = new OMSSTKTKSD();
        a.execute() ;
    }	
    */
    
	
	/*
	public void testOMSSTKTKRU() {
		
		
		//bean 
		//AppContext.getBean(name) ;
		//ServletContextWrapper servletContextWrapper = (ServletContextWrapper)AppContext.getBean("servletCtxWrapper");
		OMSSTKTKRU  a = new OMSSTKTKRU();
        a.execute() ;
    }	
    */
    
	public void testSAP() throws Exception {
		
		BaseSapRfc ab = new BaseSapRfc();
		Object[] inputData1 = new Object[16];
		inputData1[0] = "0";
		inputData1[12] = "0";
		List<Object[]> table = new ArrayList<Object[]>();
		table.add(inputData1);
        
		ab.skuPriceUpdateBsPriceCondition(table) ;
    }	
	
	
	/*
	public void testNmZchangePromoHeadRfc() {
		//bean 
		//AppContext.getBean(name) ;
		//ServletContextWrapper servletContextWrapper = (ServletContextWrapper)AppContext.getBean("servletCtxWrapper");
		
		Map<String, List<Map<String, Object>>> nmEdit = new HashMap<String, List<Map<String, Object>>>();
		List<Map<String, Object>> datelist = new ArrayList<Map<String, Object>>();
		Map<String, Object> dataMap = new HashMap<String, Object>();
		String[] aa = {"a","b"} ;
		dataMap.put("oid", aa );		
		dataMap.put("event_no", "a");
		datelist.add(dataMap) ;
		nmEdit.put("1", datelist) ;
		Object abc = dataMap.get("pc") ;
		
		try {
        
        //String[] aa = {"a","b"} ;
        
        //String ab = a.arrayToString(aa,",") ;
	    NmEdit  a = new NmEdit();
        a.execute(datelist) ;
	    BaseSapRfc ab = new BaseSapRfc();
	    //ab.sapRfc("aa", null);
		
		} catch (Exception e) {		
			System.out.printf(e.toString());
		}
    }
	*/
	
	
	/*
	public void testNmZchangePromoHeadRfc() {
		//bean 
		//AppContext.getBean(name) ;
		//ServletContextWrapper servletContextWrapper = (ServletContextWrapper)AppContext.getBean("servletCtxWrapper");
		try{
		NmZchangePromoHeadRfc  a = new NmZchangePromoHeadRfc();
        //a.execute() ;
		}
		catch (Exception e) {

		}
    }	
	*/
	
	
	public static void main(String[] args) {
        junit.textui.TestRunner.run(TestOutbound.class);
    }
    
}
