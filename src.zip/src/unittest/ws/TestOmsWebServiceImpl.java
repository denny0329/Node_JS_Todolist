/**
 * @(#)TestOmsWebServiceImpl.java Oct 29, 2015
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest.ws;

import java.io.File;
import java.io.FileOutputStream;

import org.apache.commons.codec.binary.Base64;
import org.springframework.orm.hibernate3.HibernateTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import com.bnq.util.AppContext;
import com.gccs.bs.dao.hibernate.BsSkuDao;
import com.rfep.bs.dao.hibernate.BsExchangeRateDao;
import com.rfep.bs.dao.hibernate.BsParaDao;
import com.rfep.bs.dao.hibernate.BsVendorDao;
import com.rfep.bs.dao.hibernate.BsVendorSkuDao;
import com.rfep.iv.dao.InventoryDao;
import com.rfep.iv.dao.IvPoRemarkDao;
import com.rfep.iv.dao.SkuLimitDao;
import com.rfep.iv.po.dao.hibernate.PoDao;
import com.rfep.iv.report.IvReportActionImpl;
import com.rfep.iv.sto.dao.hibernate.StoDao;
import com.rfep.product.bs.dao.hibernate.BsSkuStoreDao;
import com.rfep.product.bs.dao.hibernate.PdSkuDao;
import com.trg.oms.service.bs.BsSkuSrcService;
import com.trg.oms.utils.dao.WsLogDao;
import com.trg.oms.ws.OmsResultVo;
import com.trg.oms.ws.WsStatus;
import com.trg.oms.ws.impl.OmsWebServiceImpl;

import junit.framework.TestCase;

/**
 * @author T2482
 */
public class TestOmsWebServiceImpl extends TestCase {
	private OmsWebServiceImpl ws = new OmsWebServiceImpl();
	private String poId = null;
	private String formType = null;
	private OmsResultVo vo = null;

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		ws.setPoDao((PoDao)AppContext.getBean("poDao"));
		ws.setStoDao((StoDao)AppContext.getBean("stoDao"));
		ws.setInventoryDao((InventoryDao)AppContext.getBean("inventoryDao"));
		ws.setIvPoRemarkDao((IvPoRemarkDao)AppContext.getBean("ivPoRemarkDao"));
		ws.setBsParaDao((BsParaDao)AppContext.getBean("bsParaDao"));
		ws.setBsSkuDao((BsSkuDao)AppContext.getBean("bsSkuDao"));
		ws.setBsSkuStoreDao((BsSkuStoreDao)AppContext.getBean("bsSkuStoreDao"));
		ws.setBsVendorDao((BsVendorDao)AppContext.getBean("bsVendorDao"));
		ws.setBsVendorSkuDao((BsVendorSkuDao)AppContext.getBean("bsVendorSkuDao"));
		ws.setSkuLimitDao((SkuLimitDao)AppContext.getBean("skuLimitDao"));
		ws.setPdSkuDao((PdSkuDao)AppContext.getBean("pdSkuDao"));
		ws.setWsLogDao((WsLogDao)AppContext.getBean("wsLogDao"));
		ws.setBsExchangeRateDao((BsExchangeRateDao)AppContext.getBean("bsExchangeRateDao"));
		ws.setBsSkuSrcService((BsSkuSrcService)AppContext.getBean("bsSkuSrcService"));
		ws.setIvReportActionI((IvReportActionImpl)AppContext.getBean("ivReportActionI"));
		HibernateTransactionManager txnManager = (HibernateTransactionManager)AppContext.getBean("dataSourceTxManager");
		TransactionTemplate txnTemplate = new TransactionTemplate();
		txnTemplate.setTransactionManager(txnManager);
		ws.setTransactionTemplate(txnTemplate);
	}

	/**
	 * 測試無 poId, formType
	 */
	public void testPrintPO_NoPoIdFormType() {
		poId = null;
		formType = null;
		vo = ws.printPO(poId, formType);
		assertEquals(WsStatus.FAIL.getStatus(), vo.getStatus());
		assertEquals("600", vo.getErrCode());
	}
	
	/**
	 * 測試有 poId, 無 formType
	 */
	public void testPrintPO_HasPoIdNoFormType() {
		poId = "5500151740";
		formType = null;
		vo = ws.printPO(poId, formType);
		assertEquals(WsStatus.FAIL.getStatus(), vo.getStatus());
		assertEquals("600", vo.getErrCode());
	}

	/**
	 * 測試無 poId, 有 formType
	 */
	public void testPrintPO_NoPoIdHasFormType() {
		poId = null;
		formType = "po";
		vo = ws.printPO(poId, formType);
		assertEquals(WsStatus.FAIL.getStatus(), vo.getStatus());
		assertEquals("600", vo.getErrCode());
	}

	/**
	 * 測試poId 格式不正確
	 */
	public void testPrintPO_PoIdError() {
		poId = "5500151740x";
		formType = "STO";
		vo = ws.printPO(poId, formType);
		assertEquals(WsStatus.FAIL.getStatus(), vo.getStatus());
		assertEquals("600", vo.getErrCode());
	}

	/**
	 * 測試 formType 內容不正確
	 */
	public void testPrintPO_FormTypeError() {
		poId = "5500151740";
		formType = "stox";
		vo = ws.printPO(poId, formType);
		assertEquals(WsStatus.FAIL.getStatus(), vo.getStatus());
		assertEquals("600", vo.getErrCode());
	}
	
	/**
	 * 測試 PO, 失效狀態(3)不產生報表
	 */
	public void testPrintPO_PoStatus3Error() {	
		poId = "1300427267";
		formType = "PO";
		vo = ws.printPO(poId, formType);
		assertEquals(WsStatus.FAIL.getStatus(), vo.getStatus());
		assertEquals("600", vo.getErrCode());
	}
	
	/**
	 * 測試 PO, ZP50, 申請狀態(0) 將 ivReport0809 表單轉化為 Base64
	 */
	public void testPrintPO_PoZP50Status0ToBase64() {	
		poId = "1050238620";
		formType = "PO";
		vo = ws.printPO(poId, formType);
		assertEquals(WsStatus.SUCCESS.getStatus(), vo.getStatus());
		assertEquals("100", vo.getErrCode());
		assertEquals("混合單", vo.getPrintPOVo().getFileName());
		assertEquals("PDF", vo.getPrintPOVo().getFileExtention());
		assertEquals("application/pdf", vo.getPrintPOVo().getMimeType());
		
		try {
			byte[] report = Base64.decodeBase64(new String(vo.getPrintPOVo().getAttachment()).getBytes());
			FileOutputStream fos = new FileOutputStream(new File("D:\\temp\\PoZP50Status0.pdf"));
			fos.write(report);
			fos.close();
		} catch(Exception e) {
			fail();
		}
	}
	
	/**
	 * 測試 PO, 非ZP50, 申請狀態(0) 將 ivReport09 表單轉化為 Base64
	 */
	public void testPrintPO_PoNotZP50Status0ToBase64() {	
		poId = "1300427901";
		formType = "PO";
		vo = ws.printPO(poId, formType);
		assertEquals(WsStatus.SUCCESS.getStatus(), vo.getStatus());
		assertEquals("100", vo.getErrCode());
		assertEquals("訂貨單", vo.getPrintPOVo().getFileName());
		assertEquals("PDF", vo.getPrintPOVo().getFileExtention());
		assertEquals("application/pdf", vo.getPrintPOVo().getMimeType());
		
		try {
			byte[] report = Base64.decodeBase64(new String(vo.getPrintPOVo().getAttachment()).getBytes());
			FileOutputStream fos = new FileOutputStream(new File("D:\\temp\\PoNotZP50Status0.pdf"));
			fos.write(report);
			fos.close();
		} catch(Exception e) {
			fail();
		}
	}
	
	/**
	 * 測試 PO, 已驗收未入庫狀態(1) 將 ivReport10 表單轉化為 Base64
	 */
	public void testPrintPO_PoStatus1ToBase64() {	
		poId = "1300017239";
		formType = "PO";
		vo = ws.printPO(poId, formType);
		assertEquals(WsStatus.SUCCESS.getStatus(), vo.getStatus());
		assertEquals("100", vo.getErrCode());
		assertEquals("驗收單", vo.getPrintPOVo().getFileName());
		assertEquals("PDF", vo.getPrintPOVo().getFileExtention());
		assertEquals("application/pdf", vo.getPrintPOVo().getMimeType());
		
		try {
			byte[] report = Base64.decodeBase64(new String(vo.getPrintPOVo().getAttachment()).getBytes());
			FileOutputStream fos = new FileOutputStream(new File("D:\\temp\\PoStatus1.pdf"));
			fos.write(report);
			fos.close();
		} catch(Exception e) {
			fail();
		}
	}
	
	/**
	 * 測試 PO, 已入庫狀態(2) 將 ivReport10 表單轉化為 Base64
	 */
	public void testPrintPO_PoStatus2ToBase64() {	
		poId = "1101043923";
		formType = "PO";
		vo = ws.printPO(poId, formType);
		assertEquals(WsStatus.SUCCESS.getStatus(), vo.getStatus());
		assertEquals("100", vo.getErrCode());
		assertEquals("驗收單", vo.getPrintPOVo().getFileName());
		assertEquals("PDF", vo.getPrintPOVo().getFileExtention());
		assertEquals("application/pdf", vo.getPrintPOVo().getMimeType());
		
		try {
			byte[] report = Base64.decodeBase64(new String(vo.getPrintPOVo().getAttachment()).getBytes());
			FileOutputStream fos = new FileOutputStream(new File("D:\\temp\\PoStatus2.pdf"));
			fos.write(report);
			fos.close();
		} catch(Exception e) {
			fail();
		}
	}
	
	/**
	 * 測試 STO, 失效狀態(0)不產生報表
	 */
	public void testPrintPO_StoStatus0Error() {	
		poId = "5300308347";
		formType = "STO";
		vo = ws.printPO(poId, formType);
		assertEquals(WsStatus.FAIL.getStatus(), vo.getStatus());
		assertEquals("600", vo.getErrCode());
	}
	
	/**
	 * 測試 STO, 失效狀態(5)不產生報表
	 */
	public void testPrintPO_StoStatus5Error() {	
		poId = "5500163294";
		formType = "STO";
		vo = ws.printPO(poId, formType);
		assertEquals(WsStatus.FAIL.getStatus(), vo.getStatus());
		assertEquals("600", vo.getErrCode());
	}
	
	/**
	 * 測試 STO, 申請狀態(1) 將 ivReport14 表單轉化為 Base64
	 */
	public void testPrintPO_StoStatus1ToBase64() {	
		poId = "5500166764";
		formType = "STO";
		vo = ws.printPO(poId, formType);
		assertEquals(WsStatus.SUCCESS.getStatus(), vo.getStatus());
		assertEquals("100", vo.getErrCode());
		assertEquals("調撥需求申請單", vo.getPrintPOVo().getFileName());
		assertEquals("PDF", vo.getPrintPOVo().getFileExtention());
		assertEquals("application/pdf", vo.getPrintPOVo().getMimeType());
		
		try {
			byte[] report = Base64.decodeBase64(new String(vo.getPrintPOVo().getAttachment()).getBytes());
			FileOutputStream fos = new FileOutputStream(new File("D:\\temp\\StoStatus1.pdf"));
			fos.write(report);
			fos.close();
		} catch(Exception e) {
			fail();
		}
	}
	
	/**
	 * 測試 STO, 調出出庫狀態(2) 將 ivReport14 表單轉化為 Base64
	 */
	public void testPrintPO_StoStatus2ToBase64() {	
		poId = "5500166792";
		formType = "STO";
		vo = ws.printPO(poId, formType);
		assertEquals(WsStatus.SUCCESS.getStatus(), vo.getStatus());
		assertEquals("100", vo.getErrCode());
		assertEquals("調撥需求申請單", vo.getPrintPOVo().getFileName());
		assertEquals("PDF", vo.getPrintPOVo().getFileExtention());
		assertEquals("application/pdf", vo.getPrintPOVo().getMimeType());
		
		try {
			byte[] report = Base64.decodeBase64(new String(vo.getPrintPOVo().getAttachment()).getBytes());
			FileOutputStream fos = new FileOutputStream(new File("D:\\temp\\StoStatus2.pdf"));
			fos.write(report);
			fos.close();
		} catch(Exception e) {
			fail();
		}
	}
	
	/**
	 * 測試 STO, 已驗收未入庫狀態(3) 將 ivReport14 表單轉化為 Base64
	 */
	public void testPrintPO_StoStatus3ToBase64() {	
		poId = "5300306149";
		formType = "STO";
		vo = ws.printPO(poId, formType);
		assertEquals(WsStatus.SUCCESS.getStatus(), vo.getStatus());
		assertEquals("100", vo.getErrCode());
		assertEquals("調撥需求申請單", vo.getPrintPOVo().getFileName());
		assertEquals("PDF", vo.getPrintPOVo().getFileExtention());
		assertEquals("application/pdf", vo.getPrintPOVo().getMimeType());
		
		try {
			byte[] report = Base64.decodeBase64(new String(vo.getPrintPOVo().getAttachment()).getBytes());
			FileOutputStream fos = new FileOutputStream(new File("D:\\temp\\StoStatus3.pdf"));
			fos.write(report);
			fos.close();
		} catch(Exception e) {
			fail();
		}
	}
	
	/**
	 * 測試 STO, 已入庫狀態(4) 將 ivReport14 表單轉化為 Base64
	 */
	public void testPrintPO_StoStatus4ToBase64() {	
		poId = "5500151740";
		formType = "STO";
		vo = ws.printPO(poId, formType);
		assertEquals(WsStatus.SUCCESS.getStatus(), vo.getStatus());
		assertEquals("100", vo.getErrCode());
		assertEquals("調撥需求申請單", vo.getPrintPOVo().getFileName());
		assertEquals("PDF", vo.getPrintPOVo().getFileExtention());
		assertEquals("application/pdf", vo.getPrintPOVo().getMimeType());
		
		try {
			byte[] report = Base64.decodeBase64(new String(vo.getPrintPOVo().getAttachment()).getBytes());
			FileOutputStream fos = new FileOutputStream(new File("D:\\temp\\StoStatus4.pdf"));
			fos.write(report);
			fos.close();
		} catch(Exception e) {
			fail();
		}
	}
	
	/**
	 * 測試 STO, 已配置狀態(9) 將 ivReport14 表單轉化為 Base64
	 */
	public void testPrintPO_StoStatus9ToBase64() {	
		poId = "5600004679";
		formType = "STO";
		vo = ws.printPO(poId, formType);
		assertEquals(WsStatus.SUCCESS.getStatus(), vo.getStatus());
		assertEquals("100", vo.getErrCode());
		assertEquals("調撥需求申請單", vo.getPrintPOVo().getFileName());
		assertEquals("PDF", vo.getPrintPOVo().getFileExtention());
		assertEquals("application/pdf", vo.getPrintPOVo().getMimeType());
		
		try {
			byte[] report = Base64.decodeBase64(new String(vo.getPrintPOVo().getAttachment()).getBytes());
			FileOutputStream fos = new FileOutputStream(new File("D:\\temp\\StoStatus9.pdf"));
			fos.write(report);
			fos.close();
		} catch(Exception e) {
			fail();
		}
	}
}