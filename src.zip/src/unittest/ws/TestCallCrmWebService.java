/**
 * @(#)TestCallCrmWebService.java.java Jan 14, 2016
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest.ws;

import com.bnq.sc.model.ScSysuser;
import com.bnq.util.AppContext;
import com.rfep.bs.dao.hibernate.BsParaDao;
import com.trg.oms.externalWS.crm.CallCrmWebService;
import com.trg.oms.utils.dao.WsLogDao;

import junit.framework.TestCase;

/**
 * @author T2482
 *
 */
public class TestCallCrmWebService extends TestCase {

	private CallCrmWebService service;
	
	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		service = new CallCrmWebService();
		service.setBsParaDao((BsParaDao)AppContext.getBean("bsParaDao"));
		service.setWsLogDao((WsLogDao)AppContext.getBean("wsLogDao"));
	}

	public void testUpdatePOCost() {
		service.updatePOCost(
				"PoNo1692978468", 
				"CrmPoNo1040697020", 
				"Sku-942980492", 
				100, 200, new ScSysuser("Test", "Test"));
	}
}
