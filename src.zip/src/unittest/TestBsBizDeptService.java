/**
 * 
 */
package unittest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.bnq.util.AppContext;
import com.gccs.bs.model.BsBizDept;
import com.gccs.bs.service.BsBizDeptService;

/**
 * <b></b>
 * @author peipei
 * @Date: 2009/4/9 �U�� 7:01:03
 */
public class TestBsBizDeptService extends TestCase {
	BsBizDeptService service = null;
	
	@Override
	protected void setUp() throws Exception {
		service = (BsBizDeptService)AppContext.getBean("bsBizDeptService");
		super.setUp();
	}
	public void testFindAllBsBizDeptByCannelIdAndStoreId(){
		
		Map queryCondition = new HashMap();
		queryCondition.put("channelId", new String[]{"H-OLT"});
		queryCondition.put("storeId", new String[]{"00601"});
//		queryCondition.put("channelId", new String[]{"TLW"});
//		queryCondition.put("storeId", new String[]{"00700"});
		
		List<BsBizDept> tmpListGrid = service.findAllBsBizDeptByCannelIdAndStoreId(queryCondition);
		System.out.println("size="+tmpListGrid.size());
		for(BsBizDept bo: tmpListGrid){
			System.out.println(ToStringBuilder.reflectionToString(bo));
			if(bo.getParentOid()!=null){
				System.out.println(ToStringBuilder.reflectionToString(bo.getParentOid()));
			}
		}
	}
	
	public void testFindBsBizDeptById(){
		BsBizDept tmpBsBizDept = service.findBsBizDeptById("H-OLT0060110a41eedb0ec48a09511b80f61ff4e5d"); //������
		System.out.println(ToStringBuilder.reflectionToString(tmpBsBizDept));
		if(tmpBsBizDept.getParentOid()!=null){
			System.out.println(ToStringBuilder.reflectionToString(tmpBsBizDept.getParentOid()));
		}
	}
}
