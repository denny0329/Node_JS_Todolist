package unittest;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import junit.framework.TestCase;

import com.trg.oms.job.BsSkuInstallJob;
import com.trg.oms.utils.dao.SysInfoDao;
import com.trg.oms.utils.model.SysInfo;

public class TestBsSkuInstall extends TestCase {
	// IvGoodsMvService ivGoodsMvService = null;
	// StockAdjustmentDao stockAdjustmentDao = null;

	private SysInfoDao sysInfoDao;

	public void setSysInfoDao(SysInfoDao sysInfoDao) {
		this.sysInfoDao = sysInfoDao;
	}

	@Override
	protected void setUp() throws Exception {
		// service
		// dao
		// ivGoodsMvService =
		// (IvGoodsMvService)AppContext.getBean("ivGoodsMvService");
		// stockAdjustmentDao =
		// (StockAdjustmentDao)AppContext.getBean("stockAdjustmentDao");
		super.setUp();
	}

	public void testBsSkuInstall() {
		System.out.println("testBsSkuInstall");
		BsSkuInstallJob job = new BsSkuInstallJob();
		job.execute();
	}
	
	public void testCurrentTime(){
		Date date = new Date();
		DateFormat dateFormat = 
		            new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");        
		System.out.println(dateFormat.format(date));
	}

	public void testExec() throws RuntimeException {
		List<SysInfo> sysInfos = sysInfoDao.querySysInfo("SCHEDULED_DATE",
				"bsSkuInstall");
		String mergeTime = "";
		if (sysInfos != null && sysInfos.size() > 0) {
			mergeTime = sysInfos.get(0).getNoteFirst();
		}
		System.out.println("-- mergeTime:"+mergeTime);

	}

}
