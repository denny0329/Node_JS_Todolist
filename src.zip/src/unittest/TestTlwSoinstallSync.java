package unittest;

import com.rfep.so.model.SoInstall;
import com.rfep.so.service.SeqService;
import com.rfep.tts.sync.tlw.TlwSoinstallSync;
import junit.framework.Assert;
import junit.framework.TestCase;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestTlwSoinstallSync extends TestCase {
    private TlwSoinstallSync tlwSoinstallSync;
    private SeqService seqService;

    protected void setUp() throws Exception {
        super.setUp();
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        tlwSoinstallSync = (TlwSoinstallSync) context.getBean("tlwSoinstallSync");
        seqService = (SeqService) context.getBean("seqService");

    }

    public void testSyncCaseInfo() {

        String oid = "7";

        try {
            SoInstall soInstall = seqService.loadSoInstallByOid(oid);
            if (soInstall != null) {

//				tlwSoinstallSync.syncSoInstall(soInstall);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("sync 失敗");
            Assert.assertTrue(false);
        } finally {
            tlwSoinstallSync.closeConnection();
        }

    }

}
