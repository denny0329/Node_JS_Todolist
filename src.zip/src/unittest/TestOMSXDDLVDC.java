package unittest;

import java.io.File;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.dataex.mm.inbound.OMSXDDLVDC;
import com.rfep.iv.ars.service.ArsOrderDayService;
import com.rfep.iv.ars.service.ArsOrderDayXDService;

public class TestOMSXDDLVDC extends TestCase {
	private OMSXDDLVDC xddlvdc;
	private ArsOrderDayXDService arsOrderDayXDService;
	private ArsOrderDayService arsOrderDayService;
	/**
	 * 若執行junit有出錯，Run>Run configuration>JUnit->
	 * TestOMSXDDLVDC=>右邊頁籤(Arguments->arguments VM)->貼上-Xms64m -Xmx128m
	 */
	protected void setUp() throws Exception {
		super.setUp();
		arsOrderDayXDService = (ArsOrderDayXDService)AppContext.getBean("arsOrderDayXDService");
		arsOrderDayService = (ArsOrderDayService)AppContext.getBean("arsOrderDayService");
		
		xddlvdc = new OMSXDDLVDC();
		xddlvdc.setArsOrderDayXDService(arsOrderDayXDService);
		xddlvdc.setArsOrderDayService(arsOrderDayService);
	}
	
	public void testFile() {
		try {
			File file = new File("C:\\OMS_TEST\\OMSXDDLVDC\\OMSXDDLVDC_20150603001100_513806.csv");
			xddlvdc.execute(file);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

}
