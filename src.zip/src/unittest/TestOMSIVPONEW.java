package unittest;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.dataex.mm.outbound.OMSIVPONEW;
import com.rfep.dataex.mm.outbound.SapPoBatch;
import com.rfep.iv.po.dao.hibernate.PoDao;
import com.rfep.iv.po.model.Po;
import com.rfep.iv.sto.dao.hibernate.StoDao;
import com.rfep.iv.trf.model.Trf;

public class TestOMSIVPONEW extends TestCase {
	private OMSIVPONEW omsivponew;
	private PoDao poDao = null;
	private StoDao stoDao;
	
	@Override
	protected void setUp() throws Exception {
		poDao = (PoDao)AppContext.getBean("poDao");
		stoDao = (StoDao)AppContext.getBean("stoDao");
		
		super.setUp();
	}

	public void testFindTrfByOid() throws Exception{
		Trf trf = stoDao.findTrfByOid("8654518531f046aebd5d04b4bc76b7da");
		trf.setTrfSkuList(stoDao.findTrfSkuListByTrfOid("8654518531f046aebd5d04b4bc76b7da"));
		System.out.println(trf);
	}
	
	public void testTrfOMSIVPONEW(){
		Trf trf = stoDao.findTrfByOid("8654518531f046aebd5d04b4bc76b7da");
		trf.setTrfSkuList(stoDao.findTrfSkuListByTrfOid("8654518531f046aebd5d04b4bc76b7da"));
		omsivponew = new OMSIVPONEW(trf);
		omsivponew.execute();
	}
	
	public void testPoOMSIVPONEW() throws Exception{
		Po po = poDao.loadByPoNo("1060000303");
		omsivponew = new OMSIVPONEW(po);
		omsivponew.execute();
	}
	
	public void testSapPoBatch() throws Exception{
		SapPoBatch sapPoBatch = new SapPoBatch();
		sapPoBatch.execute();
	}
}
