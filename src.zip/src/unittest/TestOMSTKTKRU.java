package unittest;

import com.rfep.dataex.st.outbound.OMSSTKTKRU;

import junit.framework.TestCase;

public class TestOMSTKTKRU extends TestCase {
	
	public void testTrfOMSSTKTKRU(){
		OMSSTKTKRU oms = new OMSSTKTKRU();
		oms.execute();
	}
}
