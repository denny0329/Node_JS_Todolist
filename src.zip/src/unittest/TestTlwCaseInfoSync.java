package unittest;

import com.rfep.so.model.CaseInfo;
import com.rfep.so.service.CaseInfoService;
import com.rfep.tts.sync.tlw.TlwCaseInfoSync;
import junit.framework.Assert;
import junit.framework.TestCase;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestTlwCaseInfoSync extends TestCase {
    private TlwCaseInfoSync tlwCaseInfoSync;
    private CaseInfoService caseInfoService;

    protected void setUp() throws Exception {
        super.setUp();
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        tlwCaseInfoSync = (TlwCaseInfoSync) context.getBean("tlwCaseInfoSync");
        caseInfoService = (CaseInfoService) context.getBean("caseInfoService");

    }

    public void testSyncCaseInfo() {
        // 201005200001
        String caseCode = "6100800101";
        CaseInfo caseInfo = caseInfoService.getCaseInfoByCaseCode(caseCode);

        try {
            tlwCaseInfoSync.syncCaseInfo(caseInfo);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("sync 失敗");
            Assert.assertTrue(false);
        } finally {
            tlwCaseInfoSync.closeConnection();
        }

    }

}
