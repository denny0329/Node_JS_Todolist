package unittest;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.rfep.trans.model.TransBsRefund;
import com.rfep.trans.model.trans.TransMaster;
import com.rfep.trans.model.trans.TransSku;
import com.rfep.trans.service.TransService;
import com.rfep.trans.util.TransBsRefundDefinition;
import com.rfep.valuation.util.ValuationUtils;

public class TestTransBs extends TestCase {
	
	public void testDefinition() {
		System.err.println(TransBsRefundDefinition.getReasonDesc("RT", "Z"));
	}
	
	public BigDecimal testCalculate(Integer sale) {
		BigDecimal skuSaleTotal = new BigDecimal(String.valueOf(sale));
//		BigDecimal newSkuSaleTotal = skuSaleTotal.multiply(percent).setScale(0, BigDecimal.ROUND_HALF_UP);
		BigDecimal newSkuSaleTotal = ValuationUtils.getSaleTotalByPercent(sale, new BigDecimal("0.9"));
		BigDecimal discount = skuSaleTotal.subtract(newSkuSaleTotal);
//		System.err.println(discount);
		return discount;
	}
	
	public void testC() {
		BigDecimal d1 = testCalculate(85);
		System.err.println("d1 :"+d1);
		BigDecimal d2 = testCalculate(289);
		System.err.println("d2 :"+d2);
		System.err.println(d1.add(d2));
	}
	
	public void testTransInfo() {
		TransService service = (TransService)AppContext.getBean("transService");
		List<TransMaster> list = service.findRefundTransInfoTemp("8ecf8f823f0f41a68451523eb872768a", true);
		for(TransMaster master : list) {
			System.err.println(master.getSerNos());
			for(TransSku sku : master.getTransSku()) {
				System.err.println(">>>>>>>>>>>>>>>>>");
				System.err.println(sku.getSkuName());
			}
		}
	}
	
	public void testDefintion() {
		List list = TransBsRefundDefinition.getReturnGoodsReasonList();
		for(Iterator iter = list.iterator(); iter.hasNext(); ) {
			System.err.println(((TransBsRefund)iter.next()).getDescription());
		}
	}
	
	public void testStack() {
		List opList = new ArrayList();
		opList.add("AND");
		opList.add("OR");
		opList.add("OR");
		opList.add("AND");
		opList.add("AND");
		
		List valList = new ArrayList();
		valList.add(Boolean.FALSE);
		valList.add(Boolean.FALSE);
		valList.add(Boolean.TRUE);
		valList.add(Boolean.FALSE);
//		
		valList.add(Boolean.TRUE);
		
		boolean result = true;
		if(opList.size() == 1) {
			result = (Boolean)valList.get(0);
		} else {
			for(int i=0; i<opList.size()-1; i++) {
				String op = (String)opList.get(i);
				Boolean check2 = (Boolean)valList.get(i+1);
				Boolean check1 = null;
				if(i==0)
					check1 = (Boolean)valList.get(i);
				else
					check1 = result;
				if(op.equals("AND")) {
					result = new Boolean(check1 && check2);
				} else if(op.equals("OR")) {
					result = new Boolean(check1 || check2);
				}
				System.err.println("temp : "+ result);
			}
		}
		
		System.err.println("-------------------------");
		System.err.println("result : "+ result);
	}
	
	//public 
	
}
