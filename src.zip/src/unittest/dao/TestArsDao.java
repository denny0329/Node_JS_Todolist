package unittest.dao;

import java.util.HashMap;
import java.util.Map;

import org.hibernate.SessionFactory;

import com.bnq.util.AppContext;
import com.rfep.iv.ars.dao.hibernate.ArsDao;

import junit.framework.TestCase;

public class TestArsDao extends TestCase {
	private ArsDao dao;

	protected void setUp() throws Exception {
		super.setUp();
		dao = new ArsDao();
		dao.setSessionFactory((SessionFactory)AppContext.getBean("sessionFactory"));
	}
	
	public void testQueryArsStoreSelForChkRepeat() {
//		Map<String, Object[]> params = new HashMap<String, Object[]>();
//		params.put("storeId", new Object[]{"00300"});
//		params.put("sku", new Object[]{"000279743"});
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("storeId", "00300");
		params.put("sku", "000279743");
		System.out.println(dao.queryArsStoreSelForChkRepeat(params));
	}

}
