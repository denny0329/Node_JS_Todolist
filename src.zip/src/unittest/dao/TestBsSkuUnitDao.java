package unittest.dao;

import org.hibernate.SessionFactory;

import com.bnq.util.AppContext;
import com.rfep.product.bs.dao.hibernate.BsSkuUnitDao;
import com.rfep.product.bs.model.BsSkuUnit;

import junit.framework.TestCase;

public class TestBsSkuUnitDao extends TestCase {
	private BsSkuUnitDao dao;

	protected void setUp() throws Exception {
		super.setUp();
		dao = new BsSkuUnitDao();
		dao.setSessionFactory((SessionFactory)AppContext.getBean("sessionFactory"));
	}
	
	public void testFindByUnitType() {
		try {
			BsSkuUnit bsu = dao.findByUnitType("1010", "2000031247717", "1");
			assertEquals("000312477", bsu.getSku());
			
			bsu = dao.findByUnitType("1010", "4715838910860", "1");
			assertEquals("000312477", bsu.getSku());			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
