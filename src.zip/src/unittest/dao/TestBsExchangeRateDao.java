package unittest.dao;

import org.hibernate.SessionFactory;

import com.bnq.util.AppContext;
import com.rfep.bs.dao.hibernate.BsExchangeRateDao;

import junit.framework.TestCase;

public class TestBsExchangeRateDao extends TestCase {
	private BsExchangeRateDao dao;

	protected void setUp() throws Exception {
		super.setUp();
		dao = new BsExchangeRateDao();
		dao.setSessionFactory((SessionFactory)AppContext.getBean("sessionFactory"));
	}
	
	public void testGetLatestBsExchangeRate() {
		try {
			System.out.println(dao.getLatestBsExchangeRate("USD"));
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}