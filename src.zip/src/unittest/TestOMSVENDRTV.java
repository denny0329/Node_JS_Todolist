package unittest;

import java.io.File;

import junit.framework.TestCase;

import com.rfep.dataex.iv.inbound.OMSVENDRTV;

public class TestOMSVENDRTV extends TestCase {
	
	private OMSVENDRTV omsTest;
	protected void setUp() throws Exception {
		super.setUp();
		omsTest = new OMSVENDRTV();
	}
	
	public void testFile() {
		try {
			File file = new File("C:\\OMS_TEST\\OMSVENDRTV\\OMSVENDRTV_20150716110011_66434.csv");
			omsTest.execute(file);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
