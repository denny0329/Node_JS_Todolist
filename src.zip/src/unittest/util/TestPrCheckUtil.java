package unittest.util;

import com.rfep.iv.pr.util.PrCheckUtil;

import junit.framework.TestCase;

public class TestPrCheckUtil extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}

	public void testChkBsVendor() {
		// 一般
		assertEquals("[0000191469]為已停用廠商", PrCheckUtil.chkBsVendor("009465164").trim());
		// XD
		assertEquals("[0000173588]為已停用廠商", PrCheckUtil.chkBsVendor("000145072").trim());
		assertEquals("商品[016055090]未設定採購成本", PrCheckUtil.chkBsVendor("016055090").trim());
		assertEquals("商品[095001418]的採購屬性(null)與廠商基本資訊的供應商類別(Z5)不一致", PrCheckUtil.chkBsVendor("095001418").trim());
		assertNull(PrCheckUtil.chkBsVendor("016038279"));
	}
}
