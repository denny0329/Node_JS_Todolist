package unittest.util;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;
import org.springframework.util.CollectionUtils;

public class TestUtil {

	/**
	 * type 1=set create only, 2=set modify only, 3=set create+modify both
	 * @param entity
	 * @param type
	 * @param userId
	 * @param userName
	 * @author pei
	 */
	public static void prepareDateInfoForCurrentUser(Object entity, int type){
		prepareDateInfoForCurrentUser(entity, type, "H00246", "������");
	}
	public static void prepareDateInfoForCurrentUser(Object entity, int type, String userId, String userName) {
		if(entity == null) return;
		
		Map map = new HashMap();
		try {
			if((type & 1) == 1){//create
				map.clear();
				map.put("creator", userId);
				map.put("creatorName", userName);
				map.put("createTime", new Date());
				org.apache.commons.beanutils.BeanUtils.populate(entity, map);
			}
			if((type & 2) == 2){ //modify
				map.clear();
				map.put("modifier", userId);
				map.put("modifierName", userName);
				map.put("modifyTime", new Date());
				org.apache.commons.beanutils.BeanUtils.populate(entity, map);
			}
			//System.out.println(ToStringBuilder.reflectionToString(entity));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public static void showList(String title, Collection collection, boolean builder){
		System.out.println("======== " + title + " --------------------");
		if(!CollectionUtils.isEmpty(collection)){
			for(Object o : collection){
				if(builder){
					System.out.println(ToStringBuilder.reflectionToString(o, ToStringStyle.MULTI_LINE_STYLE));
				}else{
					System.out.println(o);
				}
			}
		}else{
			System.out.println("NO DATA!!");
		}
		System.out.println("= " + title + " --"+(collection==null?0:collection.size())+" rows ------");
	}
	
}
