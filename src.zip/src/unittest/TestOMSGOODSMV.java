package unittest;

import java.util.Date;

import junit.framework.TestCase;
import unittest.util.TestUtil;

import com.bnq.util.AppContext;
import com.rfep.dataex.mm.outbound.OMSGOODSMV;
import com.rfep.iv.po.model.Po;
import com.rfep.iv.po.model.PoSku;
import com.rfep.iv.po.model.PoSrc;
import com.rfep.iv.po.util.PoUtil;
import com.rfep.iv.sa.dao.StockAdjustmentDao;
import com.rfep.iv.sa.model.StockAdjustment;
import com.rfep.iv.service.IvGoodsMvService;
import com.rfep.iv.util.InventoryUtil;

public class TestOMSGOODSMV extends TestCase {
	IvGoodsMvService ivGoodsMvService = null;
	StockAdjustmentDao stockAdjustmentDao = null;
	private final String OID = "d0b89e35718f4e90972ae9df15fe14d5";
	
	@Override
	protected void setUp() throws Exception {
		ivGoodsMvService = (IvGoodsMvService)AppContext.getBean("ivGoodsMvService");
		stockAdjustmentDao = (StockAdjustmentDao)AppContext.getBean("stockAdjustmentDao");
		super.setUp();
	}
	
	public void testOMSGOODSMV(){
		OMSGOODSMV oms = new OMSGOODSMV();
		oms.execute();
	}
	
	public void testStoragePo() throws Exception{
			final Po po = new Po();
			po.setChannelId("TLW");
			po.setStoreId("01900");
			po.setPoNo("CooperPO1");
			po.setPoType(InventoryUtil.getPoType(InventoryUtil.SEQ_KEY_PO));
			po.setType("3");
			po.setStatus(Po.PO_STATUS_0_APPLY);
			po.setVendorId("005353");
			po.setVendorName("Orgill, INC.");
			po.setBuyerId("AA");
			po.setBuyerNote("���Y��EXT:629");
			po.setUpdateDl(PoUtil.getPoUpdateDateLimit()); //"01900"
			po.setRemark("remark po");
			po.setEstArrival(new Date());
			po.setWhTime(new Date());
			TestUtil.prepareDateInfoForCurrentUser(po, 3, "H00246", "������");
			
			//PoSku 1
			PoSku sku1 = new PoSku();
			sku1.setPoOid(po);
			sku1.setSeqNo(1);
			sku1.setSku("000115835");
			sku1.setSkuName("000115835 name");
			sku1.setOrderQty(1);
			sku1.setOrderUnit("Unit 1");
			sku1.setRegularPrice(11d);
			sku1.setPrice(200d);
			sku1.setBuyCost(100d);
			sku1.setCost(100d);
			sku1.setCustQty(1);
			sku1.setPlanOty(1);
			sku1.setSoTransferQty(1);
			sku1.setMinOrderQty(1d);
			sku1.setStdPack(1d);
			sku1.setInnerPack(null);
			sku1.setArsFlag(1);
			sku1.setHoldOrder(0);
			sku1.setAoh(10);
			sku1.setLimitQty(11);
			sku1.setWhQty(1);
			sku1.setRemark("sku1 remark");
			TestUtil.prepareDateInfoForCurrentUser(sku1, 3, "H001", "H001 Name");
			
			//PoSku 2
			PoSku sku2 = new PoSku();
			sku2.setPoOid(po);
			sku2.setSeqNo(2);
			sku2.setSku("000115836");
			sku2.setSkuName("000115836 name");
			sku2.setOrderQty(2);
			sku2.setOrderUnit("Unit 2");
			sku2.setRegularPrice(22d);
			sku2.setPrice(400d);
			sku2.setBuyCost(200d);
			sku2.setCost(200d);
			sku2.setCustQty(2);
			sku2.setPlanOty(2);
			sku2.setSoTransferQty(2);
			sku2.setMinOrderQty(2d);
			sku2.setStdPack(2d);
			sku2.setInnerPack(null);
			sku2.setArsFlag(1);
			sku2.setHoldOrder(0);
			sku2.setAoh(20);
			sku2.setLimitQty(22);
			sku2.setWhQty(2);
			sku1.setRemark("sku2 remark");
			TestUtil.prepareDateInfoForCurrentUser(sku2, 3, "H001", "H001 Name");
	
			
			//PoSku 3
			PoSku sku3 = new PoSku();
			sku3.setPoOid(po);
			sku3.setSeqNo(3);
			sku3.setSku("000115837");
			sku3.setSkuName("000115837 name");
			sku3.setOrderQty(3);
			sku3.setOrderUnit("Unit 3");
			sku3.setRegularPrice(33d);
			sku3.setPrice(600d);
			sku3.setBuyCost(300d);
			sku3.setCost(300d);
			sku3.setCustQty(3);
			sku3.setPlanOty(3);
			sku3.setSoTransferQty(3);
			sku3.setMinOrderQty(3d);
			sku3.setStdPack(3d);
			sku3.setInnerPack(null);
			sku3.setArsFlag(1);
			sku3.setHoldOrder(0);
			sku3.setAoh(30);
			sku3.setLimitQty(33);
			sku3.setWhQty(3);
			sku1.setRemark("sku3 remark");
			TestUtil.prepareDateInfoForCurrentUser(sku3, 3, "H001", "H001 Name");
			
			//PoSku 4
			PoSku sku4 = new PoSku();
			sku4.setPoOid(po);
			sku4.setSeqNo(4);
			sku4.setSku("000115838");
			sku4.setSkuName("000115838 name");
			sku4.setOrderQty(4);
			sku4.setOrderUnit("Unit 4");
			sku4.setRegularPrice(44d);
			sku4.setPrice(800d);
			sku4.setBuyCost(400d);
			sku4.setCost(400.00d);
			sku4.setCustQty(4);
			sku4.setPlanOty(4);
			sku4.setSoTransferQty(4);
			sku4.setMinOrderQty(4d);
			sku4.setStdPack(4d);
			sku4.setInnerPack(null);
			sku4.setArsFlag(1);
			sku4.setHoldOrder(0);
			sku4.setAoh(40);
			sku4.setLimitQty(44);
			sku4.setWhQty(4);
			sku4.setRemark("sku4 remark");
			TestUtil.prepareDateInfoForCurrentUser(sku4, 3, "H001", "H001 Name");
			
			PoSrc poSrc1 = new PoSrc();
			poSrc1.setPoOid(po);
			poSrc1.setSrcNo("SRC_001");
			poSrc1.setSrcNote("SRC NOTE 01");
			TestUtil.prepareDateInfoForCurrentUser(poSrc1, 3, "H00246", "������");
			
			PoSrc poSrc2 = new PoSrc();
			poSrc2.setPoOid(po);
			poSrc2.setSrcNo("SRC_002");
			poSrc2.setSrcNote("SRC NOTE 02");
			TestUtil.prepareDateInfoForCurrentUser(poSrc2, 3, "H00246", "������");
			
			poSrc1.addPoSku(sku1);
			poSrc1.addPoSku(sku2);
			poSrc2.addPoSku(sku3);
			poSrc2.addPoSku(sku4);
			
			po.addPoSrc(poSrc1);
			po.addPoSrc(poSrc2);
			ivGoodsMvService.storagePo(po,null);	
	}
	public void testStockAdjustment(){
		StockAdjustment stockAdjustment= stockAdjustmentDao.findById(StockAdjustment.class, "f54f4a2d80e2462ba17f505785a17a73");
		ivGoodsMvService.stockAdjustment(stockAdjustment);
	}
}
