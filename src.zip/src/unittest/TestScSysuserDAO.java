/**
 * @(#) TestScSysuserDAO.java 2016/3/7
 *
 * Copyright (c) 2010-2020 Test Rite Group
 * No. 23, Hsin Hu 3rd Road, Nai Hu District Taipei 114, Taiwan
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Test Rite
 *  Int'l Co., Ltd ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Test Rite.
 */
package unittest;

import java.util.Date;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.HibernateTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import com.bnq.sc.dao.hibernate.ScSysuserDAO;
import com.bnq.sc.model.ScSysuser;
import com.bnq.util.AppContext;

import junit.framework.TestCase;

/**
 * @author T2482
 */
public class TestScSysuserDAO extends TestCase {
	private ScSysuserDAO dao = new ScSysuserDAO();
	private TransactionTemplate transactionTemplate;

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		dao.setSessionFactory((SessionFactory)AppContext.getBean("sessionFactory"));
		
		transactionTemplate = new TransactionTemplate();
		transactionTemplate.setTransactionManager((HibernateTransactionManager)AppContext.getBean("dataSourceTxManager"));
	}
	
	@SuppressWarnings("unchecked")
	public void tesUpdateTurnoverInfo() {
		ScSysuser modifier = new ScSysuser();
		modifier.setUserId("UTTest");
		modifier.setUserName("UTTest");
		dao.updateTurnoverInfo("T2515", modifier, new Date());
		
		DetachedCriteria criteria = DetachedCriteria.forClass(ScSysuser.class);
		criteria.add(Restrictions.eq("userId", "T2515"));
		
		List<ScSysuser> userList = dao.getHibernateTemplate().findByCriteria(criteria);
		for(ScSysuser t2515 : userList) {
			if("1050".equals(t2515.getCompanyId())) {
				assertEquals("Pogi", t2515.getModifier());
			} else {
				assertEquals("UTTest", t2515.getModifier());
			}
			assertEquals(new Long(2L), t2515.getUserStatus());
		}
	}

}
