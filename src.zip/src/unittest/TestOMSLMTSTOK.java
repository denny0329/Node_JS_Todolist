package unittest;

import java.io.File;

import junit.framework.TestCase;

import com.rfep.dataex.mm.inbound.OMSLMTSTOK;

public class TestOMSLMTSTOK extends TestCase {
	
	private OMSLMTSTOK omsTest;
	protected void setUp() throws Exception {
		super.setUp();
		omsTest = new OMSLMTSTOK();
	}
	
	public void testFile() {
		try {
			File file = new File("C:\\OMS_TEST\\OMSLMTSTOK\\OMSLMTSTOK_201507150651003_66434.csv");
			omsTest.execute(file);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
