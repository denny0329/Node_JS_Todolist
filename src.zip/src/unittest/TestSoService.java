package unittest;

import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.bnq.sc.model.ScSysuser;
import com.bnq.util.AppContext;
import com.bnq.util.FileTools;
import com.bnq.util.PageBean;
import com.bnq.util.StringId;
import com.gccs.member.model.condition.MemberCondition;
import com.gccs.member.service.CardService;
import com.rfep.so.service.SoService;
import com.rfep.so.util.SoGlossary;
import com.rfep.util.dwr.SoDwrAction;

/**
 * @author peipei
 * @Date: 2009/4/9 下午 7:01:03
 */
public class TestSoService extends TestCase {
	SoService service = null;
	CardService cardService = null;
	
	@Override
	protected void setUp() throws Exception {
		service = (SoService)AppContext.getBean("soService");
		cardService = (CardService)AppContext.getBean("cardService");
		super.setUp();
	}
	
	public void testGetDefaultDesigner() throws Exception{
		ScSysuser user = service.getDefaultDesigner("TLW", "00100");
		System.out.println(ToStringBuilder.reflectionToString(user));
	}
	public void testGetSystemTypeList() {
		List<StringId> list = service.getSystemTypeList("H00246");
		System.out.println("size="+list.size());
		for(StringId si : list){
			System.out.println(" - " + ToStringBuilder.reflectionToString(si));
		}
		Boolean soType=null;
		for(StringId si : list){
			if("SO".equals(si.getName())){
				soType = Boolean.parseBoolean(si.getId());
			}else if("TTS".equals(si.getName())){
				soType = Boolean.parseBoolean(si.getId());
			}
		}
		System.out.println("soType="+soType);
	}
	@SuppressWarnings("rawtypes")
	public void testFindMmCardByCondition() throws Exception {
		MemberCondition mCondition = new MemberCondition() ;
		mCondition.setName("呂淑蘭");
		PageBean pageBean = new PageBean();
		int index = FileTools.getStartRowIndex(pageBean.getPageNo(), pageBean.getPageSize());
		System.out.println("index="+index+", pageSize="+pageBean.getPageSize());
		
		PageBean result = this.cardService.findMmCardByCondition(mCondition, pageBean) ;
		
		System.out.println("result2="+result.getQueryList().size());
	}
	
	@SuppressWarnings("rawtypes")
	public void testPageBean(){
		PageBean inPageBean = new PageBean();
		System.out.println("inPageBean="+ToStringBuilder.reflectionToString(inPageBean));
		
		PageBean outPageBean=new PageBean(inPageBean);//import
	    outPageBean.setPageSize(inPageBean.getPageSize());
	    if(inPageBean.getJumpPage()==null || inPageBean.getJumpPage().trim().equals("")|| inPageBean.getJumpPage().trim().equals("0")){
	    	inPageBean.setJumpPage("1");
	    }
	    
	    outPageBean.setPage(new Integer(inPageBean.getJumpPage()));//將跳頁設給當前頁
	    System.out.println("outPageBean="+ToStringBuilder.reflectionToString(outPageBean));
	}
	
	@SuppressWarnings("rawtypes")
	public void testQueryCaseInfoDataBlockList(){
		List listProcLog = this.service.queryCaseInfoDataBlockList(SoGlossary._CASE_BLOCK_INDEX_0_PROCLOG, "bec3c3636bcf4b7984ea53f162a49569", 0, 10);
		System.out.println("listProcLog="+listProcLog);
		
	}
	
	public void testDwrFindTitleIdByUserId(){
		SoDwrAction soDwrAction = (SoDwrAction)AppContext.getBean("soDwrAction");
		
		String channelId = "TLW";
		String storeId = "01900";
		String userId = null;
		Map<String,String> mapPercent = null;
		
		userId = "J00372"; //2筆, 1 title
		String titleIds = soDwrAction.findTitleIdByUserId(channelId, storeId, userId);
		System.out.println("titleIds="+titleIds);
		mapPercent = soDwrAction.findVariationPercent(channelId, titleIds, "T");
		System.out.println("M mapPercent="+mapPercent);
		mapPercent = soDwrAction.findVariationPercent(channelId, titleIds, "D");
		System.out.println("D mapPercent="+mapPercent);
		
		System.out.println("=====================================");
		userId = "J00296"; //2筆, 2 title
		titleIds = soDwrAction.findTitleIdByUserId(channelId, storeId, userId);
		System.out.println("titleIds="+titleIds);
		mapPercent = soDwrAction.findVariationPercent(channelId, titleIds, "T");
		System.out.println("M mapPercent="+mapPercent);
		mapPercent = soDwrAction.findVariationPercent(channelId, titleIds, "D");
		System.out.println("D mapPercent="+mapPercent);
	}
}
