package unittest;

import java.util.ArrayList;

import junit.framework.TestCase;

import com.apeo.sender.exception.MessageSenderException;
import com.apeo.sender.model.MessageContent;
import com.bnq.util.mail.MailService;

/**
 * <b></b>
 * @author kaychen
 * @Date: 2008/11/12 �U�� 2:49:23
 * @Project Name: MessageSender
 * @Package Name: unittest
 * @File Name: TestSendService.java
 * @�\�໡��: 
 */
public class TestSendService extends TestCase {

	/**
	 * Test method for {@link com.apeo.sender.SendService#sendMessage(java.lang.String, com.apeo.sender.model.MessageContent)}.
	 */
	public void testSendMessage() {
		MessageContent content = new MessageContent() ;
		content.setContent("Test Content ����") ;
		content.setReceiverInfo("ghostwolfs@gmail.com") ;
		content.setReveiverName("GregGmail") ;
		content.setSenderInfo("ghostwolf@ms51.url.com.tw") ;
		content.setSenderName("GregUrlMailBox") ;
		content.setSubject("���D���Test") ;
		/*
		List attachFile = new ArrayList() ;
		attachFile.add(new File("C:/Documents and Settings/kaychen/�ୱ/YM/new/SignBox.mdl")) ;
		attachFile.add(new File("C:/Documents and Settings/kaychen/�ୱ/YM/new/�M�׵��c.doc")) ;
		content.setAttachFile(attachFile) ;
		*/
		try {
			//SendService.sendMessage(SendService._mail, null, content) ;
			MailService.sendMessage(content.getContent(), content.getSubject(), content.getReceiverInfo(), content.getReveiverName(), new ArrayList()) ;
			assertTrue(true) ;
		} catch (MessageSenderException e) {
			e.printStackTrace();
			assertTrue(false) ;
		}
	}

}
