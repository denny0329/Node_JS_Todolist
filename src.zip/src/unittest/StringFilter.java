package unittest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;

/**
 * <b></b>
 * 
 * @author kaychen
 * @Date: 2009/8/6 �U�� 2:15:01
 * @Project Name: RFEP
 * @Package Name: unittest
 * @File Name: StringFilter.java
 */
public class StringFilter {
	//private static final int _startRow = 54 ;
	//private static final int _limitRow = 60 ;
	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) {
		String path = "D:\\200908-statspack";
		File dir = new File(path);
		String filter1 = "db file sequential read";
		String filter2 = "db file scattered read";
		//int start = 74;
		//int end = 79;
		File[] f = dir.listFiles();
		for (int index = 0; index < f.length; index++) {
			File file = f[index] ;
			String fileName = file.getName() ;
			try{
				fileName = fileName.substring(0,fileName.indexOf(".")) ;
				System.out.print(fileName);
				List list = FileUtils.readLines(file) ;
				System.out.print(getResult((String)list.get(24),36,51)) ;
				System.out.print(getResult((String)list.get(25),36,51)) ;
				System.out.print(getResult((String)list.get(40),31,37)) ;
				System.out.print(getResult(file,filter1,74,79,54,60)) ;
				System.out.print(getResult(file,filter2,74,79,54,60)) ;
				System.out.print(getResult(file,filter1,65,71,73,111)) ;
				System.out.println(getResult(file,filter2,65,71,73,111)) ;
			}catch(Exception e){
				System.out.println() ;
				System.err.println("fileName : "+fileName) ;
				//e.printStackTrace() ;
			}
		}
	}
	
	private static String getResult(String s ,int start,int end) {
		String temp = s.substring(start, end).trim() ;
		if(!temp.equals("")) {
			return ("\t"+temp); 
		}
		return ("\t0");
		
	}
	
	private static String getResult(File f ,String filter,int start,int end,int _startRow,int _limitRow) {
		FileReader reader = null;
		BufferedReader buf = null;
		try {
			reader = new FileReader(f);
			buf = new BufferedReader(reader);
			String temp = "";
			int i = 0;
			while ((temp = buf.readLine()) != null) {
				if(i > _limitRow) {
					break ;
				}
				if (i >= (_startRow - 1) && temp != null) {
					if (temp.indexOf(filter) != -1) {
						return ("\t"+temp.substring(start-1, end-1).trim());
					}
				}
				i++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				buf.close();
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return "\t0" ;
	}
}
