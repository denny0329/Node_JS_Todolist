package unittest;

import java.io.File;

import junit.framework.TestCase;

import com.rfep.dataex.fi.inbound.OMSACUNTAR;

public class TestOMSACUNTAR extends TestCase {
	
	@Override
	protected void setUp() throws Exception {
		super.setUp();
	}
	
	public void testOMSACUNTAR() throws Exception {
		OMSACUNTAR oms = new OMSACUNTAR();
		oms.execute(new File("E:\\OMSACUNTAR_20110210130222708.csv"));
	}
}
