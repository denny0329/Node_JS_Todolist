package unittest;

import java.io.File;
import java.util.List;

import junit.framework.TestCase;

import org.hibernate.Query;
import org.hibernate.Session;

import com.bnq.util.AppContext;
import com.rfep.dataex.iv.inbound.OMSWMSPICK;
import com.rfep.iv.dao.IvTrfPickedDAO;
import com.rfep.iv.model.IvTrfPicked;
import com.rfep.iv.service.IvTrfPickedService;

/**
 * 測試 OMSWMSPICK
 * @author allen
 */
public class TestOMSWMSPICK extends TestCase {
	private IvTrfPickedService ivTrfPickedService;
	private IvTrfPickedDAO ivTrfPickedDAO;
	private OMSWMSPICK note;

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		ivTrfPickedService = (IvTrfPickedService)AppContext.getBean("ivTrfPickedService");
		note = new OMSWMSPICK();
		note.setIvTrfPickedService(ivTrfPickedService);
	}
	/**
	 * 測試電文檔案
	 */
	public void testFile() {
		try {
			File file = new File("C:\\OMS_TEST\\OMSWMSPICK\\OMSWMSPICK_2015071513480012_622806.csv");
			note.execute(file);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
		
	/**
	 * 測試 寫入IV_TRF_PICKED
	 */
	public void testCreateIvTrfPicked() {
		ivTrfPickedDAO = (IvTrfPickedDAO)AppContext.getBean("ivTrfPickedDAO");
		Session session = ivTrfPickedDAO.getSessionFactory().openSession();
		Query query = session.createSQLQuery("TRUNCATE TABLE IV_TRF_PICKED");
		query.executeUpdate();
		ivTrfPickedDAO.getSessionFactory().openSession().close();
		File file = new File("C:\\OMS_TEST\\OMSWMSPICK.csv");
		note.execute(file);
		List<IvTrfPicked> ivTrfPickedList= ivTrfPickedDAO.findByExample(IvTrfPicked.class, new IvTrfPicked());
		
		assertEquals(3,ivTrfPickedList.size());
		
		for(IvTrfPicked ivTrfPicked : ivTrfPickedList) {
			assertNotNull(ivTrfPicked.getTrfNo());
			assertNotNull(ivTrfPicked.getCreateTime());
		}
	}
}