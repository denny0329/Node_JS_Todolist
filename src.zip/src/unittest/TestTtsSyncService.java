/**
 * 
 */
package unittest;

import java.util.Date;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import org.apache.commons.lang.StringUtils;
import org.springframework.util.CollectionUtils;

import com.bnq.util.AppContext;
import com.bnq.util.QueryResult;
import com.rfep.bs.model.RfepIdGenerator;
import com.rfep.so.dao.hibernate.SeqDao;
import com.rfep.so.model.Measuring;
import com.rfep.so.model.Quotation;
import com.rfep.so.model.SoInstall;
import com.rfep.so.model.SoOrderAct;
import com.rfep.so.model.SoOrderActId;
import com.rfep.so.model.SpecialOrder;
import com.rfep.so.model.comdition.SeqCondition;
import com.rfep.so.model.comdition.SoCondition;
import com.rfep.so.model.vo.MeasuringVo;
import com.rfep.so.model.vo.QuotationVo;
import com.rfep.so.service.MeasuringService;
import com.rfep.so.service.OrderService;
import com.rfep.so.service.QuotationService;
import com.rfep.so.service.SeqService;
import com.rfep.so.service.SoOrderActService;
import com.rfep.tts.sync.TtsSyncService;

/**
 * 
 * @author peipei
 *
 */
public class TestTtsSyncService extends TestCase {
	private QuotationService quotationService = null;
	private OrderService orderService = null;
	private MeasuringService measuringService = null;
	private SeqService seqService;
	private TtsSyncService ttsSyncService = null;
	private SoOrderActService soOrderActService = null;
	
	
	@Override
	protected void setUp() throws Exception {
		quotationService = (QuotationService)AppContext.getBean("quotationService");
		orderService = (OrderService)AppContext.getBean("orderService");
		measuringService = (MeasuringService)AppContext.getBean("measuringService");
		ttsSyncService = (TtsSyncService)AppContext.getBean("ttsSyncService");
		seqService = (SeqService) AppContext.getBean("seqService");
		soOrderActService = (SoOrderActService) AppContext.getBean("soOrderActService");
		super.setUp();
	}
	
	public void testSyncQuotation() throws Exception{
		String oid = null;
//		oid = "81d195de7d69450a8eefd59b914eb37a";
//		oid = "aeed807636ea4038af239d5202cff5be"; //Q210080017901
		Quotation quotation = null;
		
		if(oid==null){
			SoCondition condition = new SoCondition();
//			condition.setFormSeqNo("Q210080010901");
//			condition.setFormSeqNo("Q210080017901");
//			condition.setFormSeqNo("Q210080018201");
			condition.setFormSeqNo("Q310100057401");
			QueryResult result = quotationService.getQuotationList(condition, 0, 10, false);
			if(!CollectionUtils.isEmpty(result.getResult())){
				QuotationVo quotationVo = (QuotationVo)result.getResult().iterator().next();
				oid = quotationVo.getOid();
				System.out.println("oid="+oid);
			}
		}
		if(oid!=null){
			quotation = quotationService.getQuotationByOid(oid, true, true, true);
		}
		
		System.out.println("quotation=" + quotation);
		//prepareSerialNo(quotation);
		ttsSyncService.syncQuotation(quotation);
		
	}

	public void testSyncOrder() throws Exception{
		String oid = null;
//		oid = "7be8f65d46d24f8398484f01fabf141c";
//		oid = "aa0eef04d8384231b40764bf40dff926"; //59 (SO)
//		oid = "021c5ba372c54bcfb71884d2e357bc1d"; //61 (SO)
//		oid = "19f7674ce55b4f1b97b9463870d922d2"; //HOLA
		
		SpecialOrder order = null;
		
		SoCondition condition = new SoCondition();
		//condition.setSoNo("200000059"); //SO
//		condition.setSoNo("200000061"); //SO
//		condition.setSoNo("600000064"); //TTS
//		condition.setSoNo("200000065"); //SO
		//condition.setSoNo("200000067"); //SO
		condition.setSoNo("35000214"); //SO
		if(oid==null){
			QueryResult result = orderService.getOrderList(condition, 0, 10, false);
			if(!CollectionUtils.isEmpty(result.getResult())){
				Map map = (Map)result.getResult().iterator().next();
				System.out.println("map="+map);
				List list = (List)map.get("LIST");
				if(!CollectionUtils.isEmpty(list)){
					oid = (String)((Map)list.iterator().next()).get("ORDER_OID");
				}
				System.out.println("oid="+oid);
			}
		}
		
		//oid = "aa0eef04d8384231b40764bf40dff926";
		if(oid != null){
			order = orderService.getOrderByOid(oid);
		}
		System.out.println("order=" + order);
		prepareSerialNo(order);
		
		ttsSyncService.syncOrder(order, true); //true=Insert, false=Update
		
	}
	public void testSyncMeasure() throws Exception {
		String oid = "ef50502d670343d1b3df1fabf3a6b3fe";
		
		SoCondition condition = new SoCondition();
		condition.setFormSeqNo("M210080018001");
		Measuring measuring = null;
		
		if(oid==null){
			QueryResult result = measuringService.getMeasuringList(condition, 0, 10, false);
			if(!CollectionUtils.isEmpty(result.getResult())){
				MeasuringVo vo = (MeasuringVo)result.getResult().iterator().next();
				oid = vo.getOid();
				System.out.println("oid=" + oid);
			}
		}

		if(oid!=null){
			measuring = measuringService.getMeasuringByOid(oid, true);
			System.out.println("measuring="+measuring);
		}
//		ttsSyncService.syncMeasuring(measuring);
	}
	public void testSyncInstallation() throws Exception {
		String oid = null;
		SoInstall soInstall = null;
		
		if(oid==null){
			SeqCondition condition = new SeqCondition();
			condition.setSeqNo("35000301I01");
			
			QueryResult result = seqService.findSoinstallByCondition(condition, 0, 10, false);
			if(!CollectionUtils.isEmpty(result.getResult())){
				Map map = (Map)result.getResult().iterator().next();
				oid = (String)map.get("OID");
				System.out.println("oid=" + oid);
			}
		}
		
		if(oid!=null){
			soInstall = seqService.loadSoInstallByOid(oid);
			//System.out.println("soInstall="+soInstall);
		}
		ttsSyncService.syncSoInstall(soInstall);
	}
	public void testSeqDaoFindSoinstallByOrderOid(){
		SeqDao seqDao = (SeqDao)AppContext.getBean("seqDao");
		List<SoInstall> soInsList = seqDao.findSoinstallByOrderOid("66e8f597439d422d81d48fe34985d7f5");
		System.out.println(soInsList.size());
		if(!CollectionUtils.isEmpty(soInsList)){
			for(SoInstall ins : soInsList){
				System.out.println(ins.getSeqNo());
				if("35000301I01".equals(ins.getSeqNo())){
					ttsSyncService.syncSoInstall(ins);
				}
			}
		}
	}
	
	public void testCreateSoOrderActService(){
		SoOrderAct soOrderAct = new SoOrderAct();
		soOrderAct.setChannelId("HOLA");
		soOrderAct.setStoreId("00603");
		soOrderAct.setSeqNo("A123");
		soOrderAct.setAction(SoOrderAct.ACTION_INSERT); // I/U
		String oid = (String)new RfepIdGenerator().generate(null, null);
		SoOrderActId id = new SoOrderActId(oid, new Date());
		soOrderAct.setId(id);
		
		soOrderActService.create(soOrderAct);
	}
	
	private void prepareSerialNo(Object obj) {
		if(obj == null) return;
		
		int seq = 1110;
		String no = "201008011090Q001"; 
		
		//quotation.setPayCardType
		
		if(obj instanceof Quotation){
			Quotation quotation = (Quotation)obj;
			//quotation.setSeqNo(no);
			
			//====�w��===================
			if(StringUtils.isBlank(quotation.getPayVipNo())){
				quotation.setPayVipNo(quotation.getCaseInfo().getCustomerVipNo());
			}
			//=====
			
//			SkuStatistics skuStatistics = quotation.getStatistics();
//			if(skuStatistics!=null){
//				if(skuStatistics.getGoodsSet()!=null){
//					for(OrderGoods goods : skuStatistics.getGoodsSet()){
//						goods.setSerial(("" + ++seq).substring(1));
//					}
//				}
//				if(skuStatistics.getCouponSet() != null) {
//					for(CouponUsage coupon : skuStatistics.getCouponSet()){
//						coupon.setSerial(("" + ++seq).substring(1));
//					}
//				}
//				
//				if(skuStatistics.getWorkTypeSet()!=null){
//					for(SoWorkType workType : skuStatistics.getWorkTypeSet()){
//						if(workType.getGoodsSet() != null){
//							for(OrderGoods goods : workType.getGoodsSet()){
//								goods.setSerial(("" + ++seq).substring(1));
//								
//								if(goods.getInstallationFee()!=null){
//									for(InstallationFee ifee : goods.getInstallationFee()){
//										ifee.setSerial(("" + ++seq).substring(1));
//										
//										if(ifee.getCouponSet() != null){
//											for(CouponUsage coupon : ifee.getCouponSet()){
//												coupon.setSerial(("" + ++seq).substring(1));
//											}
//										}
//									}
//								}
//							}
//						}
//						FreightRecord fr = workType.getFreightRecord();
//						if(fr != null && fr.getItemSet() != null){
//							for(FreightItem item : fr.getItemSet()){
//								item.setSerial(("" + ++seq).substring(1));
//							}
//						}
//						
//					}
//				}
//				
//			}
			
		}else if(obj instanceof SpecialOrder){
			SpecialOrder order = (SpecialOrder)obj;
			
			//====�w��===================
			if(StringUtils.isBlank(order.getPayVipNo())){
				order.setPayVipNo(order.getCaseInfo().getCustomerVipNo());
			}
			//=====
			
//			SkuStatistics skuStatistics = order.getStatistics();
//			if(skuStatistics!=null){
//				if(skuStatistics.getGoodsSet()!=null){
//					for(OrderGoods goods : skuStatistics.getGoodsSet()){
//						goods.setSerial(("" + ++seq).substring(1));
//					}
//				}
//				if(skuStatistics.getCouponSet() != null) {
//					for(CouponUsage coupon : skuStatistics.getCouponSet()){
//						coupon.setSerial(("" + ++seq).substring(1));
//					}
//				}
//				
//				if(skuStatistics.getWorkTypeSet()!=null){
//					for(SoWorkType workType : skuStatistics.getWorkTypeSet()){
//						if(workType.getGoodsSet() != null){
//							for(OrderGoods goods : workType.getGoodsSet()){
//								goods.setSerial(("" + ++seq).substring(1));
//								
//								if(goods.getInstallationFee()!=null){
//									for(InstallationFee ifee : goods.getInstallationFee()){
//										ifee.setSerial(("" + ++seq).substring(1));
//										
//										if(ifee.getCouponSet() != null){
//											for(CouponUsage coupon : ifee.getCouponSet()){
//												coupon.setSerial(("" + ++seq).substring(1));
//											}
//										}
//									}
//								}
//							}
//						}
//						FreightRecord fr = workType.getFreightRecord();
//						if(fr != null && fr.getItemSet() != null){
//							for(FreightItem item : fr.getItemSet()){
//								item.setSerial(("" + ++seq).substring(1));
//							}
//						}
//						
//					}
//				}
//				
//			}
		}
	}
	
	public static void main(String[] args) throws Exception {
		TestTtsSyncService serv = new TestTtsSyncService();
		serv.setUp();
		serv.testSyncQuotation();
		serv.tearDown();
	}
	
}
