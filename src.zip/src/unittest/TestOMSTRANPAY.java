package unittest;

import junit.framework.TestCase;

import com.rfep.dataex.fi.outbound.OMSTRANPAY;

public class TestOMSTRANPAY extends TestCase {

	@Override
	protected void setUp() throws Exception {
		super.setUp();
	}

	public void testOMSTRANPAY() {
		OMSTRANPAY oms = new OMSTRANPAY();
		oms.execute();
	}
}