package unittest;

import java.io.File;

import junit.framework.TestCase;

import com.bnq.util.AppContext;
import com.gccs.bs.dao.hibernate.BsBizDeptDao;
import com.gccs.bs.dao.hibernate.BsStoreDao;
import com.gccs.bs.service.BsClassService;
import com.gccs.bs.service.BsParaService;
import com.rfep.dataex.mm.inbound.OMSBSCLASS;
import com.rfep.iv.ars.service.ArsService;
import com.rfep.product.bs.service.BsSkuDeptService;

public class TestOMSBSCLASS extends TestCase {
	private BsClassService service;
	private BsParaService bsParaService;
	private BsSkuDeptService bsdService;
	private ArsService arsService;
	private BsStoreDao bsStoreDao;
	private BsBizDeptDao bsBizDeptDao;
	
	private OMSBSCLASS omsTest;
	
	protected void setUp() throws Exception {
		super.setUp();
		service = (BsClassService)AppContext.getBean("bsClassService");
		bsParaService = (BsParaService)AppContext.getBean("bsParaService");
		bsdService = (BsSkuDeptService)AppContext.getBean("bsSkuDeptService");
		arsService = (ArsService)AppContext.getBean("arsService");
		bsStoreDao = (BsStoreDao)AppContext.getBean("bsStoreDao");
		bsBizDeptDao = (BsBizDeptDao)AppContext.getBean("bsBizDeptDao");
		
		omsTest = new OMSBSCLASS();
		omsTest.setService(service);
		omsTest.setBsParaService(bsParaService);
		omsTest.setBsdService(bsdService);
		omsTest.setArsService(arsService);
		omsTest.setBsStoreDao(bsStoreDao);
		omsTest.setBsBizDeptDao(bsBizDeptDao);
	}
	
	public void testFile() {
		try {
			File file = new File("C:\\OMS_TEST\\OMSBSCLASS\\OMSBSCLASS_20150716001102585_66562.csv");
			omsTest.execute(file);
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
