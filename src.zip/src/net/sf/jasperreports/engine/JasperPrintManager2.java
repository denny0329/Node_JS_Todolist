/*
 * ============================================================================
 * GNU Lesser General Public License
 * ============================================================================
 *
 * JasperReports - Free Java report-generating library.
 * Copyright (C) 2001-2006 JasperSoft Corporation http://www.jaspersoft.com
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 *
 * JasperSoft Corporation
 * 303 Second Street, Suite 450 North
 * San Francisco, CA 94107
 * http://www.jaspersoft.com
 */
package net.sf.jasperreports.engine;

import java.awt.Image;
import java.awt.print.PrinterException;
import java.io.InputStream;

import javax.print.PrintService;

import net.sf.jasperreports.engine.export.JRPrintServiceExporter;
import net.sf.jasperreports.engine.print.JRPrinterAWT2;
import net.sf.jasperreports.engine.util.JRLoader;

public class JasperPrintManager2 {

	/**
	 * @throws PrinterException 
	 */
	public static boolean printReport(
		String sourceFileName,
		boolean withPrintDialog
		) throws JRException, PrinterException
	{
		JasperPrint jasperPrint = (JasperPrint)JRLoader.loadObject(sourceFileName);

		return printReport(jasperPrint, withPrintDialog);
	}

	/**
	 * @throws PrinterException 
	 */
	public static boolean printReport(
		InputStream inputStream,
		boolean withPrintDialog
		) throws JRException, PrinterException
	{
		JasperPrint jasperPrint = (JasperPrint)JRLoader.loadObject(inputStream);

		return printReport(jasperPrint, withPrintDialog);
	}

	/**
	 * @throws PrinterException 
	 */
	public static boolean printReport(
		JasperPrint jasperPrint,
		boolean withPrintDialog
		) throws JRException, PrinterException
	{
		//artf1936
		if (!checkAvailablePrinters()) {
			throw new JRException("No printer available.");
		}
		//END - artf1936
		
		return printPages(
			jasperPrint,
			0,
			jasperPrint.getPages().size() - 1,
			withPrintDialog
			);
	}
	
	public static boolean printReport(
			PrintService printService,
			JasperPrint jasperPrint,
			boolean withPrintDialog
			) throws JRException, PrinterException
		{
			//artf1936
			if (!checkAvailablePrinters()) {
				throw new JRException("No printer available.");
			}
			//END - artf1936
			
			return printPages(
				printService,
				jasperPrint,
				0,
				jasperPrint.getPages().size() - 1,
				withPrintDialog
				);
		}

	/**
	 * @throws PrinterException 
	 */
	public static boolean printPage(
		String sourceFileName,
		int pageIndex,
		boolean withPrintDialog
		) throws JRException, PrinterException
	{
		JasperPrint jasperPrint = (JasperPrint)JRLoader.loadObject(sourceFileName);

		return printPage(jasperPrint, pageIndex, withPrintDialog);
	}

	/**
	 * @throws PrinterException 
	 */
	public static boolean printPage(
		InputStream inputStream,
		int pageIndex,
		boolean withPrintDialog
		) throws JRException, PrinterException
	{
		JasperPrint jasperPrint = (JasperPrint)JRLoader.loadObject(inputStream);

		return printPage(jasperPrint, pageIndex, withPrintDialog);
	}

	/**
	 * @throws PrinterException 
	 */
	public static boolean printPage(
		JasperPrint jasperPrint,
		int pageIndex,
		boolean withPrintDialog
		) throws JRException, PrinterException
	{
		return printPages(
			jasperPrint,
			pageIndex,
			pageIndex,
			withPrintDialog
			);
	}

	/**
	 * @throws PrinterException 
	 */
	public static boolean printPages(
		String sourceFileName,
		int firstPageIndex,
		int lastPageIndex,
		boolean withPrintDialog
		) throws JRException, PrinterException
	{
		JasperPrint jasperPrint = (JasperPrint)JRLoader.loadObject(sourceFileName);

		return printPages(
			jasperPrint,
			firstPageIndex,
			lastPageIndex,
			withPrintDialog
			);
	}

	/**
	 * @throws PrinterException 
	 */
	public static boolean printPages(
		InputStream inputStream,
		int firstPageIndex,
		int lastPageIndex,
		boolean withPrintDialog
		) throws JRException, PrinterException
	{
		JasperPrint jasperPrint = (JasperPrint)JRLoader.loadObject(inputStream);

		return printPages(
			jasperPrint,
			firstPageIndex,
			lastPageIndex,
			withPrintDialog
			);
	}

	/**
	 * @throws PrinterException 
	 */
	public static boolean printPages(
		JasperPrint jasperPrint,
		int firstPageIndex,
		int lastPageIndex,
		boolean withPrintDialog
		) throws JRException, PrinterException
	{
		return JRPrinterAWT2.printPages(
			null,
			jasperPrint,
			firstPageIndex,
			lastPageIndex,
			withPrintDialog
			);
	}
	
	public static boolean printPages(
			PrintService printService,
			JasperPrint jasperPrint,
			int firstPageIndex,
			int lastPageIndex,
			boolean withPrintDialog
			) throws JRException, PrinterException
		{
			return JRPrinterAWT2.printPages(
				printService,
				jasperPrint,
				firstPageIndex,
				lastPageIndex,
				withPrintDialog
				);
		}

	public static Image printPageToImage(
		String sourceFileName,
		int pageIndex,
		float zoom
		) throws JRException
	{
		JasperPrint jasperPrint = (JasperPrint)JRLoader.loadObject(sourceFileName);

		return printPageToImage(jasperPrint, pageIndex, zoom);
	}

	public static Image printPageToImage(
		InputStream inputStream,
		int pageIndex,
		float zoom
		) throws JRException
	{
		JasperPrint jasperPrint = (JasperPrint)JRLoader.loadObject(inputStream);

		return printPageToImage(jasperPrint, pageIndex, zoom);
	}

	public static Image printPageToImage(
		JasperPrint jasperPrint,
		int pageIndex,
		float zoom
		) throws JRException
	{
		return JRPrinterAWT2.printPageToImage(jasperPrint, pageIndex, zoom);
	}


	/* http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=6604109 (artf2423) workaround */
	protected static final boolean unixSunJDK;
	static
	{
		boolean found = false;
		try
		{
			Class.forName("sun.print.UnixPrintServiceLookup");
			found = true;
		}
		catch (Throwable e)
		{
			found = false;
		}
		unixSunJDK = found;
	}
	
	// artf1936
	private static boolean checkAvailablePrinters() {
		return unixSunJDK ? true : JRPrintServiceExporter.checkAvailablePrinters();
	}
}
