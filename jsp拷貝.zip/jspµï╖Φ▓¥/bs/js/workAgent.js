function loadStoreDataList(channelId, elemId) {
	workAgentMappingDwrAction.getStoreItems(channelId, {
		callback : function(data) {
			dwr.util.removeAllOptions(elemId);
			dwr.util.addOptions(elemId, data);
		}
	});
}

//var checkArea = function() {
//	if (this.checked) {
//		if (this.value == 'A:ALL') {
//			dojo.query('#channelStoreList > input[type=checkbox]:checked')
//					.forEach(function(node, index, arr) {
//						node.checked = false;
//					});
//			this.checked = true;
//		} else {
//			dojo
//					.query(
//							'#channelStoreList [value^=S:' + this.value
//									.substring(2) + ']:checked').forEach(
//							function(node, index, arr) {
//								node.checked = false;
//							});
//		}
//	}
//};

//var checkStore = function() {
//	if (this.checked) {
//		var areaId = this.value.substring(2, this.value.indexOf('_'));
//		dojo.byId('Area_' + areaId).checked = false;
//		dojo.byId('Area_ALL').checked = false;
//	}
//};

//var showAreaStoreList = function(data) {
//	dojo.forEach(data, function(areaStore) {
//		var channelStoreListDIV = dojo.byId('channelStoreList');
//		dojo.create('input', {
//			id : 'Area_' + areaStore.areaId,
//			type : 'checkbox',
//			value : 'A:' + areaStore.areaId,
//			onclick : checkArea
//		}, channelStoreListDIV);
//		dojo.create('label', {
//			'for' : 'Area_' + areaStore.areaId,
//			innerHTML : areaStore.areaName
//		}, channelStoreListDIV);
//		dojo.create('span', {
//			innerHTML : ':'
//		}, channelStoreListDIV);
//		dojo.forEach(areaStore.storeList, function(store) {
//			dojo.create('input', {
//				id : 'Store_' + store.id.storeId,
//				type : 'checkbox',
//				value : 'S:' + store.areaId + "_" + store.id.storeId,
//				onclick : checkStore
//			}, channelStoreListDIV);
//			dojo.create('label', {
//				'for' : 'Store_' + store.id.storeId,
//				innerHTML : store.storeName2
//			}, channelStoreListDIV);
//			dojo.create('span', {
//				innerHTML : '&nbsp;'
//			}, channelStoreListDIV);
//		});
//		dojo.create('br', null, channelStoreListDIV);
//	});
//};

//function loadChannelStoreList(channelId) {
//	dojo.byId('channelStoreList').innerHTML = '';
//	if (channelId != null) {
//		workAgentMappingDwrAction.getAreaStoreList(channelId, {
//			callback : showAreaStoreList
//		});
//	}
//}

//function getChannelId() {
//	var result = null;
//	dojo.query('#channelList > input[type=radio]:checked').forEach(
//			function(node, index, arr) {
//				result = node.value;
//			});
//	return result;
//}

//function getStoreList() {
//	var result = [];
//	dojo.query('#channelStoreList > input[type=checkbox]:checked').forEach(
//			function(node, index, arr) {
//				result.push(node.value);
//			});
//	return result;
//}
//
//function addStoreMapping() {
//	var list = getStoreList();
//	workAgentMappingDwrAction.addStoreForMapping(getChannelId(),
//			getStoreList(), {
//				callback : function() {
//					showMappingList();
//				}
//			});
//}
//
//function getDeletedItems() {
//	var deletedItems = [];
//	dojo.query('.deletedItem:checked').forEach(function(node, idx, arr) {
//		deletedItems.push(node.value);
//	});
//	return deletedItems;
//}
//
//function createMappingTableBody() {
//	var storeMappingDIV = dojo.byId('channelStoreMappingList');
//	storeMappingDIV.innerHTML = '';
//	var table = dojo.create('table', {
//		'class' : 'BlackBorder',
//		width : '100%',
//		border : '0',
//		cellpadding : '0',
//		cellspacing : '0'
//	}, storeMappingDIV);
//	var tbody = dojo.create('tbody', null);
//	var tr = dojo.create('tr', null, tbody);
//	dojo.create('td', {
//		colSpan : '5',
//		align : 'left',
//		nowrap : 'true',
//		'class' : 'rowY',
//		width : '100%',
//		innerHTML : '支 援 之 工 種 設 定'
//	}, tr);
//	var tr1 = dojo.create('tr', null, tbody);
//	var td1 = dojo.create('td', {
//		colSpan : '5',
//		align : 'left',
//		nowrap : 'true',
//		width : '100%',
//		'class' : 'thTop_2'
//	}, tr1);
//	var deleteStoreMapping = function() {
//		workAgentMappingDwrAction.deleteStoreForMapping(getDeletedItems(), {
//			callback : function() {
//				showMappingList();
//			}
//		});
//	};
//	if (workAgentStatus == '1'){
//		var delButton = dojo.create('input', {
//			type : 'button',
//			'class' : 'submit',
//			value : '刪除',
//			onclick : deleteStoreMapping
//		}, td1);		
//	}
//	var tr2 = dojo.create('tr', null, tbody);
//	dojo.create('td', {
//		align : 'left',
//		width : '3%',
//		nowrap : 'true',
//		'class' : 'row12',
//		innerHTML : '選擇'
//	}, tr2);
//	dojo.create('td', {
//		align : 'left',
//		width : '3%',
//		nowrap : 'true',
//		'class' : 'row12',
//		innerHTML : '序號'
//	}, tr2);
//	dojo.create('td', {
//		align : 'left',
//		width : '9%',
//		nowrap : 'true',
//		'class' : 'row12',
//		innerHTML : '通路'
//	}, tr2);
//	dojo.create('td', {
//		align : 'left',
//		width : '45%',
//		'class' : 'row12',
//		innerHTML : '已選擇之通路店別'
//	}, tr2);
//	dojo.create('td', {
//		align : 'left',
//		width : '40%',
//		nowrap : 'true',
//		'class' : 'row12',
//		innerHTML : '工 種'
//	}, tr2);
//	dojo.place(tbody, table, 'first');
//	return tbody;
//}
//
//function getStoreValues(mappingVO) {
//	var result = '';
//	dojo.forEach(mappingVO.storeList, function(storeVO) {
//		result += storeVO.storeName + ', ';
//	});
//	return result;
//}
//
//function getJobTypeValues(mappingVO) {
//	var result = '';
//	var i = 0;
//	dojo.forEach(mappingVO.jobTypeList, function(jobTypeVO) {
//		if (i > 0) {
//			result += ', ';
//		}
//		result += jobTypeVO.jobTypeName;
//		i++;
//	});
//	return result;
//}
//
//function appendSelectJobTypeTag(serialNo, jobTypeDiv, jobTypes) {
//	var showDialog = function() {
//		var winSettings = 'center:yes;resizable:no;dialogHeight:700px;dialogWidth:1000px';
//		var jobTypeList = window.showModalDialog(
//				'selectSoJobType.action?serialNo=' + serialNo, '', winSettings);
//		var jobTypeValues = '';
//		if (jobTypeList != null) {
//			for ( var i = 0; i < jobTypeList.length; i++) {
//				if (i > 0) {
//					jobTypeValues += ', ';
//				}
//				jobTypeValues += jobTypeList[i];
//			}
//			var div = dojo.byId('jobType_' + serialNo);
//			div.innerHTML = '';
//			appendSelectJobTypeTag(serialNo, div, jobTypeValues);
//		}
//	};
//	if (jobTypes != null) {
//		dojo.create('span', {
//			innerHTML : jobTypes + '&nbsp;&nbsp;'
//		}, jobTypeDiv);
//	}
//	if (workAgentStatus == '1'){
//		var elem = dojo.create('img', {
//			border : '0',
//			src : '../../images/queryOpen.gif',
//			'class' : 'Cursor_hand',
//			onclick : showDialog
//		}, jobTypeDiv);	
//	}	
//}

//function showMappingList() {
//	var tbody = createMappingTableBody();
//	workAgentMappingDwrAction.getChannelMappingList( {
//		callback : function(data) {
//			var idx = 0;
//			dojo.forEach(data, function(mappingVO) {
//				var storeList = getStoreValues(mappingVO);
//				var tr = dojo.create('tr', null, tbody);
//				var td = dojo.create('td', {
//					align : 'left',
//					nowrap : 'true',
//					'class' : 'row3'
//				}, tr);
//				dojo.create('input', {
//					type : 'checkbox',
//					'class' : 'deletedItem',
//					name : 'deletedItems',
//					value : idx
//				}, td);
//				dojo.create('td', {
//					align : 'left',
//					nowrap : 'true',
//					'class' : 'row3',
//					innerHTML : idx + 1
//				}, tr);
//				dojo.create('td', {
//					align : 'left',
//					rowrap : 'true',
//					'class' : 'row3',
//					innerHTML : mappingVO.channelName
//				}, tr);
//				var storeTd = dojo.create('td', {
//					align : 'left',
//					rowrap : 'true',
//					'class' : 'row3',
//					innerHTML : storeList
//				}, tr);
//				var jobTypeTd = dojo.create('td', {
//					align : 'left',
//					rowrap : 'true',
//					'class' : 'row3'
//				}, tr);
//				var jobTypeDiv = dojo.create('div', {
//					id : 'jobType_' + idx,
//					align : 'left',
//					style : 'vertical-align:top'
//				}, jobTypeTd);
//				appendSelectJobTypeTag(idx, jobTypeDiv,
//						getJobTypeValues(mappingVO));
//				idx++;
//			});
//		}
//	});
//}

function findWorkAgent() {
	workAgentMappingDwrAction.getWorkAgentById(dojo.byId('workAgentId').value,
			{
				callback : function(data) {
					if (data != null){
						if (data.status == '0'){
							alert('您輸入的工班代號已停工,無法再設定.');
							window.open(
									'editBsWorkAgentMapping.action','_self');						
						}else{
							window.open(
									'editBsWorkAgentMapping.action?oid=' + data.oid,'_self');
						}
					}else{
						alert('您輸入的工班代號找不到資料!');
						dojo.byId('workAgentId').value = '';
						window.open(
								'editBsWorkAgentMapping.action','_self');
					}
				}
			});
}